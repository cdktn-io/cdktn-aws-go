import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfCrawlerConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_crawler#classifiers TfCrawler#classifiers}
    */
    readonly classifiers?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_crawler#configuration TfCrawler#configuration}
    */
    readonly configuration?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_crawler#database_name TfCrawler#database_name}
    */
    readonly databaseName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_crawler#description TfCrawler#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_crawler#id TfCrawler#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_crawler#name TfCrawler#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_crawler#region TfCrawler#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_crawler#role TfCrawler#role}
    */
    readonly role: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_crawler#schedule TfCrawler#schedule}
    */
    readonly schedule?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_crawler#security_configuration TfCrawler#security_configuration}
    */
    readonly securityConfiguration?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_crawler#table_prefix TfCrawler#table_prefix}
    */
    readonly tablePrefix?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_crawler#tags TfCrawler#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_crawler#tags_all TfCrawler#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * catalog_target block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_crawler#catalog_target TfCrawler#catalog_target}
    */
    readonly catalogTarget?: TfCrawler.CatalogTargetProperty[] | cdktn.IResolvable;
    /**
    * delta_target block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_crawler#delta_target TfCrawler#delta_target}
    */
    readonly deltaTarget?: TfCrawler.DeltaTargetProperty[] | cdktn.IResolvable;
    /**
    * dynamodb_target block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_crawler#dynamodb_target TfCrawler#dynamodb_target}
    */
    readonly dynamodbTarget?: TfCrawler.DynamodbTargetProperty[] | cdktn.IResolvable;
    /**
    * hudi_target block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_crawler#hudi_target TfCrawler#hudi_target}
    */
    readonly hudiTarget?: TfCrawler.HudiTargetProperty[] | cdktn.IResolvable;
    /**
    * iceberg_target block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_crawler#iceberg_target TfCrawler#iceberg_target}
    */
    readonly icebergTarget?: TfCrawler.IcebergTargetProperty[] | cdktn.IResolvable;
    /**
    * jdbc_target block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_crawler#jdbc_target TfCrawler#jdbc_target}
    */
    readonly jdbcTarget?: TfCrawler.JdbcTargetProperty[] | cdktn.IResolvable;
    /**
    * lake_formation_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_crawler#lake_formation_configuration TfCrawler#lake_formation_configuration}
    */
    readonly lakeFormationConfiguration?: TfCrawler.LakeFormationConfigurationProperty;
    /**
    * lineage_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_crawler#lineage_configuration TfCrawler#lineage_configuration}
    */
    readonly lineageConfiguration?: TfCrawler.LineageConfigurationProperty;
    /**
    * mongodb_target block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_crawler#mongodb_target TfCrawler#mongodb_target}
    */
    readonly mongodbTarget?: TfCrawler.MongodbTargetProperty[] | cdktn.IResolvable;
    /**
    * recrawl_policy block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_crawler#recrawl_policy TfCrawler#recrawl_policy}
    */
    readonly recrawlPolicy?: TfCrawler.RecrawlPolicyProperty;
    /**
    * s3_target block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_crawler#s3_target TfCrawler#s3_target}
    */
    readonly s3Target?: TfCrawler.S3TargetProperty[] | cdktn.IResolvable;
    /**
    * schema_change_policy block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_crawler#schema_change_policy TfCrawler#schema_change_policy}
    */
    readonly schemaChangePolicy?: TfCrawler.SchemaChangePolicyProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_crawler aws_glue_crawler}
*/
export declare class TfCrawler extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_glue_crawler";
    /**
    * Generates CDKTN code for importing a TfCrawler resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfCrawler to import
    * @param importFromId The id of the existing TfCrawler that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_crawler#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfCrawler to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_crawler aws_glue_crawler} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfCrawlerConfig
    */
    constructor(scope: Construct, id: string, config: TfCrawlerConfig);
    get arn(): string;
    private _classifiers?;
    get classifiers(): string[];
    set classifiers(value: string[]);
    resetClassifiers(): void;
    get classifiersInput(): string[] | undefined;
    private _configuration?;
    get configuration(): string;
    set configuration(value: string);
    resetConfiguration(): void;
    get configurationInput(): string | undefined;
    private _databaseName?;
    get databaseName(): string;
    set databaseName(value: string);
    get databaseNameInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _role?;
    get role(): string;
    set role(value: string);
    get roleInput(): string | undefined;
    private _schedule?;
    get schedule(): string;
    set schedule(value: string);
    resetSchedule(): void;
    get scheduleInput(): string | undefined;
    private _securityConfiguration?;
    get securityConfiguration(): string;
    set securityConfiguration(value: string);
    resetSecurityConfiguration(): void;
    get securityConfigurationInput(): string | undefined;
    private _tablePrefix?;
    get tablePrefix(): string;
    set tablePrefix(value: string);
    resetTablePrefix(): void;
    get tablePrefixInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _catalogTarget;
    get catalogTarget(): TfCrawler.CatalogTargetPropertyList;
    putCatalogTarget(value: TfCrawler.CatalogTargetProperty[] | cdktn.IResolvable): void;
    resetCatalogTarget(): void;
    get catalogTargetInput(): cdktn.IResolvable | TfCrawler.CatalogTargetProperty[] | undefined;
    private _deltaTarget;
    get deltaTarget(): TfCrawler.DeltaTargetPropertyList;
    putDeltaTarget(value: TfCrawler.DeltaTargetProperty[] | cdktn.IResolvable): void;
    resetDeltaTarget(): void;
    get deltaTargetInput(): cdktn.IResolvable | TfCrawler.DeltaTargetProperty[] | undefined;
    private _dynamodbTarget;
    get dynamodbTarget(): TfCrawler.DynamodbTargetPropertyList;
    putDynamodbTarget(value: TfCrawler.DynamodbTargetProperty[] | cdktn.IResolvable): void;
    resetDynamodbTarget(): void;
    get dynamodbTargetInput(): cdktn.IResolvable | TfCrawler.DynamodbTargetProperty[] | undefined;
    private _hudiTarget;
    get hudiTarget(): TfCrawler.HudiTargetPropertyList;
    putHudiTarget(value: TfCrawler.HudiTargetProperty[] | cdktn.IResolvable): void;
    resetHudiTarget(): void;
    get hudiTargetInput(): cdktn.IResolvable | TfCrawler.HudiTargetProperty[] | undefined;
    private _icebergTarget;
    get icebergTarget(): TfCrawler.IcebergTargetPropertyList;
    putIcebergTarget(value: TfCrawler.IcebergTargetProperty[] | cdktn.IResolvable): void;
    resetIcebergTarget(): void;
    get icebergTargetInput(): cdktn.IResolvable | TfCrawler.IcebergTargetProperty[] | undefined;
    private _jdbcTarget;
    get jdbcTarget(): TfCrawler.JdbcTargetPropertyList;
    putJdbcTarget(value: TfCrawler.JdbcTargetProperty[] | cdktn.IResolvable): void;
    resetJdbcTarget(): void;
    get jdbcTargetInput(): cdktn.IResolvable | TfCrawler.JdbcTargetProperty[] | undefined;
    private _lakeFormationConfiguration;
    get lakeFormationConfiguration(): TfCrawler.LakeFormationConfigurationPropertyOutputReference;
    putLakeFormationConfiguration(value: TfCrawler.LakeFormationConfigurationProperty): void;
    resetLakeFormationConfiguration(): void;
    get lakeFormationConfigurationInput(): TfCrawler.LakeFormationConfigurationProperty | undefined;
    private _lineageConfiguration;
    get lineageConfiguration(): TfCrawler.LineageConfigurationPropertyOutputReference;
    putLineageConfiguration(value: TfCrawler.LineageConfigurationProperty): void;
    resetLineageConfiguration(): void;
    get lineageConfigurationInput(): TfCrawler.LineageConfigurationProperty | undefined;
    private _mongodbTarget;
    get mongodbTarget(): TfCrawler.MongodbTargetPropertyList;
    putMongodbTarget(value: TfCrawler.MongodbTargetProperty[] | cdktn.IResolvable): void;
    resetMongodbTarget(): void;
    get mongodbTargetInput(): cdktn.IResolvable | TfCrawler.MongodbTargetProperty[] | undefined;
    private _recrawlPolicy;
    get recrawlPolicy(): TfCrawler.RecrawlPolicyPropertyOutputReference;
    putRecrawlPolicy(value: TfCrawler.RecrawlPolicyProperty): void;
    resetRecrawlPolicy(): void;
    get recrawlPolicyInput(): TfCrawler.RecrawlPolicyProperty | undefined;
    private _s3Target;
    get s3Target(): TfCrawler.S3TargetPropertyList;
    putS3Target(value: TfCrawler.S3TargetProperty[] | cdktn.IResolvable): void;
    resetS3Target(): void;
    get s3TargetInput(): cdktn.IResolvable | TfCrawler.S3TargetProperty[] | undefined;
    private _schemaChangePolicy;
    get schemaChangePolicy(): TfCrawler.SchemaChangePolicyPropertyOutputReference;
    putSchemaChangePolicy(value: TfCrawler.SchemaChangePolicyProperty): void;
    resetSchemaChangePolicy(): void;
    get schemaChangePolicyInput(): TfCrawler.SchemaChangePolicyProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfCrawlerCatalogTargetPropertyToTerraform(struct?: TfCrawler.CatalogTargetProperty | cdktn.IResolvable): any;
export declare function tfCrawlerCatalogTargetPropertyToHclTerraform(struct?: TfCrawler.CatalogTargetProperty | cdktn.IResolvable): any;
export declare function tfCrawlerDeltaTargetPropertyToTerraform(struct?: TfCrawler.DeltaTargetProperty | cdktn.IResolvable): any;
export declare function tfCrawlerDeltaTargetPropertyToHclTerraform(struct?: TfCrawler.DeltaTargetProperty | cdktn.IResolvable): any;
export declare function tfCrawlerDynamodbTargetPropertyToTerraform(struct?: TfCrawler.DynamodbTargetProperty | cdktn.IResolvable): any;
export declare function tfCrawlerDynamodbTargetPropertyToHclTerraform(struct?: TfCrawler.DynamodbTargetProperty | cdktn.IResolvable): any;
export declare function tfCrawlerHudiTargetPropertyToTerraform(struct?: TfCrawler.HudiTargetProperty | cdktn.IResolvable): any;
export declare function tfCrawlerHudiTargetPropertyToHclTerraform(struct?: TfCrawler.HudiTargetProperty | cdktn.IResolvable): any;
export declare function tfCrawlerIcebergTargetPropertyToTerraform(struct?: TfCrawler.IcebergTargetProperty | cdktn.IResolvable): any;
export declare function tfCrawlerIcebergTargetPropertyToHclTerraform(struct?: TfCrawler.IcebergTargetProperty | cdktn.IResolvable): any;
export declare function tfCrawlerJdbcTargetPropertyToTerraform(struct?: TfCrawler.JdbcTargetProperty | cdktn.IResolvable): any;
export declare function tfCrawlerJdbcTargetPropertyToHclTerraform(struct?: TfCrawler.JdbcTargetProperty | cdktn.IResolvable): any;
export declare function tfCrawlerLakeFormationConfigurationPropertyToTerraform(struct?: TfCrawler.LakeFormationConfigurationPropertyOutputReference | TfCrawler.LakeFormationConfigurationProperty): any;
export declare function tfCrawlerLakeFormationConfigurationPropertyToHclTerraform(struct?: TfCrawler.LakeFormationConfigurationPropertyOutputReference | TfCrawler.LakeFormationConfigurationProperty): any;
export declare function tfCrawlerLineageConfigurationPropertyToTerraform(struct?: TfCrawler.LineageConfigurationPropertyOutputReference | TfCrawler.LineageConfigurationProperty): any;
export declare function tfCrawlerLineageConfigurationPropertyToHclTerraform(struct?: TfCrawler.LineageConfigurationPropertyOutputReference | TfCrawler.LineageConfigurationProperty): any;
export declare function tfCrawlerMongodbTargetPropertyToTerraform(struct?: TfCrawler.MongodbTargetProperty | cdktn.IResolvable): any;
export declare function tfCrawlerMongodbTargetPropertyToHclTerraform(struct?: TfCrawler.MongodbTargetProperty | cdktn.IResolvable): any;
export declare function tfCrawlerRecrawlPolicyPropertyToTerraform(struct?: TfCrawler.RecrawlPolicyPropertyOutputReference | TfCrawler.RecrawlPolicyProperty): any;
export declare function tfCrawlerRecrawlPolicyPropertyToHclTerraform(struct?: TfCrawler.RecrawlPolicyPropertyOutputReference | TfCrawler.RecrawlPolicyProperty): any;
export declare function tfCrawlerS3TargetPropertyToTerraform(struct?: TfCrawler.S3TargetProperty | cdktn.IResolvable): any;
export declare function tfCrawlerS3TargetPropertyToHclTerraform(struct?: TfCrawler.S3TargetProperty | cdktn.IResolvable): any;
export declare function tfCrawlerSchemaChangePolicyPropertyToTerraform(struct?: TfCrawler.SchemaChangePolicyPropertyOutputReference | TfCrawler.SchemaChangePolicyProperty): any;
export declare function tfCrawlerSchemaChangePolicyPropertyToHclTerraform(struct?: TfCrawler.SchemaChangePolicyPropertyOutputReference | TfCrawler.SchemaChangePolicyProperty): any;
export declare namespace TfCrawler {
    interface CatalogTargetProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_crawler#connection_name TfCrawler#connection_name}
        */
        readonly connectionName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_crawler#database_name TfCrawler#database_name}
        */
        readonly databaseName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_crawler#dlq_event_queue_arn TfCrawler#dlq_event_queue_arn}
        */
        readonly dlqEventQueueArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_crawler#event_queue_arn TfCrawler#event_queue_arn}
        */
        readonly eventQueueArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_crawler#tables TfCrawler#tables}
        */
        readonly tables: string[];
    }
    class CatalogTargetPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CatalogTargetProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CatalogTargetProperty | cdktn.IResolvable | undefined);
        private _connectionName?;
        get connectionName(): string;
        set connectionName(value: string);
        resetConnectionName(): void;
        get connectionNameInput(): string | undefined;
        private _databaseName?;
        get databaseName(): string;
        set databaseName(value: string);
        get databaseNameInput(): string | undefined;
        private _dlqEventQueueArn?;
        get dlqEventQueueArn(): string;
        set dlqEventQueueArn(value: string);
        resetDlqEventQueueArn(): void;
        get dlqEventQueueArnInput(): string | undefined;
        private _eventQueueArn?;
        get eventQueueArn(): string;
        set eventQueueArn(value: string);
        resetEventQueueArn(): void;
        get eventQueueArnInput(): string | undefined;
        private _tables?;
        get tables(): string[];
        set tables(value: string[]);
        get tablesInput(): string[] | undefined;
    }
    class CatalogTargetPropertyList extends cdktn.ComplexList {
        internalValue?: CatalogTargetProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CatalogTargetPropertyOutputReference;
    }
    interface DeltaTargetProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_crawler#connection_name TfCrawler#connection_name}
        */
        readonly connectionName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_crawler#create_native_delta_table TfCrawler#create_native_delta_table}
        */
        readonly createNativeDeltaTable?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_crawler#delta_tables TfCrawler#delta_tables}
        */
        readonly deltaTables: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_crawler#write_manifest TfCrawler#write_manifest}
        */
        readonly writeManifest: boolean | cdktn.IResolvable;
    }
    class DeltaTargetPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DeltaTargetProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DeltaTargetProperty | cdktn.IResolvable | undefined);
        private _connectionName?;
        get connectionName(): string;
        set connectionName(value: string);
        resetConnectionName(): void;
        get connectionNameInput(): string | undefined;
        private _createNativeDeltaTable?;
        get createNativeDeltaTable(): boolean | cdktn.IResolvable;
        set createNativeDeltaTable(value: boolean | cdktn.IResolvable);
        resetCreateNativeDeltaTable(): void;
        get createNativeDeltaTableInput(): boolean | cdktn.IResolvable | undefined;
        private _deltaTables?;
        get deltaTables(): string[];
        set deltaTables(value: string[]);
        get deltaTablesInput(): string[] | undefined;
        private _writeManifest?;
        get writeManifest(): boolean | cdktn.IResolvable;
        set writeManifest(value: boolean | cdktn.IResolvable);
        get writeManifestInput(): boolean | cdktn.IResolvable | undefined;
    }
    class DeltaTargetPropertyList extends cdktn.ComplexList {
        internalValue?: DeltaTargetProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DeltaTargetPropertyOutputReference;
    }
    interface DynamodbTargetProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_crawler#path TfCrawler#path}
        */
        readonly path: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_crawler#scan_all TfCrawler#scan_all}
        */
        readonly scanAll?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_crawler#scan_rate TfCrawler#scan_rate}
        */
        readonly scanRate?: number;
    }
    class DynamodbTargetPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DynamodbTargetProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DynamodbTargetProperty | cdktn.IResolvable | undefined);
        private _path?;
        get path(): string;
        set path(value: string);
        get pathInput(): string | undefined;
        private _scanAll?;
        get scanAll(): boolean | cdktn.IResolvable;
        set scanAll(value: boolean | cdktn.IResolvable);
        resetScanAll(): void;
        get scanAllInput(): boolean | cdktn.IResolvable | undefined;
        private _scanRate?;
        get scanRate(): number;
        set scanRate(value: number);
        resetScanRate(): void;
        get scanRateInput(): number | undefined;
    }
    class DynamodbTargetPropertyList extends cdktn.ComplexList {
        internalValue?: DynamodbTargetProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DynamodbTargetPropertyOutputReference;
    }
    interface HudiTargetProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_crawler#connection_name TfCrawler#connection_name}
        */
        readonly connectionName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_crawler#exclusions TfCrawler#exclusions}
        */
        readonly exclusions?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_crawler#maximum_traversal_depth TfCrawler#maximum_traversal_depth}
        */
        readonly maximumTraversalDepth: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_crawler#paths TfCrawler#paths}
        */
        readonly paths: string[];
    }
    class HudiTargetPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): HudiTargetProperty | cdktn.IResolvable | undefined;
        set internalValue(value: HudiTargetProperty | cdktn.IResolvable | undefined);
        private _connectionName?;
        get connectionName(): string;
        set connectionName(value: string);
        resetConnectionName(): void;
        get connectionNameInput(): string | undefined;
        private _exclusions?;
        get exclusions(): string[];
        set exclusions(value: string[]);
        resetExclusions(): void;
        get exclusionsInput(): string[] | undefined;
        private _maximumTraversalDepth?;
        get maximumTraversalDepth(): number;
        set maximumTraversalDepth(value: number);
        get maximumTraversalDepthInput(): number | undefined;
        private _paths?;
        get paths(): string[];
        set paths(value: string[]);
        get pathsInput(): string[] | undefined;
    }
    class HudiTargetPropertyList extends cdktn.ComplexList {
        internalValue?: HudiTargetProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): HudiTargetPropertyOutputReference;
    }
    interface IcebergTargetProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_crawler#connection_name TfCrawler#connection_name}
        */
        readonly connectionName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_crawler#exclusions TfCrawler#exclusions}
        */
        readonly exclusions?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_crawler#maximum_traversal_depth TfCrawler#maximum_traversal_depth}
        */
        readonly maximumTraversalDepth: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_crawler#paths TfCrawler#paths}
        */
        readonly paths: string[];
    }
    class IcebergTargetPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): IcebergTargetProperty | cdktn.IResolvable | undefined;
        set internalValue(value: IcebergTargetProperty | cdktn.IResolvable | undefined);
        private _connectionName?;
        get connectionName(): string;
        set connectionName(value: string);
        resetConnectionName(): void;
        get connectionNameInput(): string | undefined;
        private _exclusions?;
        get exclusions(): string[];
        set exclusions(value: string[]);
        resetExclusions(): void;
        get exclusionsInput(): string[] | undefined;
        private _maximumTraversalDepth?;
        get maximumTraversalDepth(): number;
        set maximumTraversalDepth(value: number);
        get maximumTraversalDepthInput(): number | undefined;
        private _paths?;
        get paths(): string[];
        set paths(value: string[]);
        get pathsInput(): string[] | undefined;
    }
    class IcebergTargetPropertyList extends cdktn.ComplexList {
        internalValue?: IcebergTargetProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): IcebergTargetPropertyOutputReference;
    }
    interface JdbcTargetProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_crawler#connection_name TfCrawler#connection_name}
        */
        readonly connectionName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_crawler#enable_additional_metadata TfCrawler#enable_additional_metadata}
        */
        readonly enableAdditionalMetadata?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_crawler#exclusions TfCrawler#exclusions}
        */
        readonly exclusions?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_crawler#path TfCrawler#path}
        */
        readonly path: string;
    }
    class JdbcTargetPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): JdbcTargetProperty | cdktn.IResolvable | undefined;
        set internalValue(value: JdbcTargetProperty | cdktn.IResolvable | undefined);
        private _connectionName?;
        get connectionName(): string;
        set connectionName(value: string);
        get connectionNameInput(): string | undefined;
        private _enableAdditionalMetadata?;
        get enableAdditionalMetadata(): string[];
        set enableAdditionalMetadata(value: string[]);
        resetEnableAdditionalMetadata(): void;
        get enableAdditionalMetadataInput(): string[] | undefined;
        private _exclusions?;
        get exclusions(): string[];
        set exclusions(value: string[]);
        resetExclusions(): void;
        get exclusionsInput(): string[] | undefined;
        private _path?;
        get path(): string;
        set path(value: string);
        get pathInput(): string | undefined;
    }
    class JdbcTargetPropertyList extends cdktn.ComplexList {
        internalValue?: JdbcTargetProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): JdbcTargetPropertyOutputReference;
    }
    interface LakeFormationConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_crawler#account_id TfCrawler#account_id}
        */
        readonly accountId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_crawler#use_lake_formation_credentials TfCrawler#use_lake_formation_credentials}
        */
        readonly useLakeFormationCredentials?: boolean | cdktn.IResolvable;
    }
    class LakeFormationConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): LakeFormationConfigurationProperty | undefined;
        set internalValue(value: LakeFormationConfigurationProperty | undefined);
        private _accountId?;
        get accountId(): string;
        set accountId(value: string);
        resetAccountId(): void;
        get accountIdInput(): string | undefined;
        private _useLakeFormationCredentials?;
        get useLakeFormationCredentials(): boolean | cdktn.IResolvable;
        set useLakeFormationCredentials(value: boolean | cdktn.IResolvable);
        resetUseLakeFormationCredentials(): void;
        get useLakeFormationCredentialsInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface LineageConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_crawler#crawler_lineage_settings TfCrawler#crawler_lineage_settings}
        */
        readonly crawlerLineageSettings?: string;
    }
    class LineageConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): LineageConfigurationProperty | undefined;
        set internalValue(value: LineageConfigurationProperty | undefined);
        private _crawlerLineageSettings?;
        get crawlerLineageSettings(): string;
        set crawlerLineageSettings(value: string);
        resetCrawlerLineageSettings(): void;
        get crawlerLineageSettingsInput(): string | undefined;
    }
    interface MongodbTargetProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_crawler#connection_name TfCrawler#connection_name}
        */
        readonly connectionName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_crawler#path TfCrawler#path}
        */
        readonly path: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_crawler#scan_all TfCrawler#scan_all}
        */
        readonly scanAll?: boolean | cdktn.IResolvable;
    }
    class MongodbTargetPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): MongodbTargetProperty | cdktn.IResolvable | undefined;
        set internalValue(value: MongodbTargetProperty | cdktn.IResolvable | undefined);
        private _connectionName?;
        get connectionName(): string;
        set connectionName(value: string);
        get connectionNameInput(): string | undefined;
        private _path?;
        get path(): string;
        set path(value: string);
        get pathInput(): string | undefined;
        private _scanAll?;
        get scanAll(): boolean | cdktn.IResolvable;
        set scanAll(value: boolean | cdktn.IResolvable);
        resetScanAll(): void;
        get scanAllInput(): boolean | cdktn.IResolvable | undefined;
    }
    class MongodbTargetPropertyList extends cdktn.ComplexList {
        internalValue?: MongodbTargetProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): MongodbTargetPropertyOutputReference;
    }
    interface RecrawlPolicyProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_crawler#recrawl_behavior TfCrawler#recrawl_behavior}
        */
        readonly recrawlBehavior?: string;
    }
    class RecrawlPolicyPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RecrawlPolicyProperty | undefined;
        set internalValue(value: RecrawlPolicyProperty | undefined);
        private _recrawlBehavior?;
        get recrawlBehavior(): string;
        set recrawlBehavior(value: string);
        resetRecrawlBehavior(): void;
        get recrawlBehaviorInput(): string | undefined;
    }
    interface S3TargetProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_crawler#connection_name TfCrawler#connection_name}
        */
        readonly connectionName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_crawler#dlq_event_queue_arn TfCrawler#dlq_event_queue_arn}
        */
        readonly dlqEventQueueArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_crawler#event_queue_arn TfCrawler#event_queue_arn}
        */
        readonly eventQueueArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_crawler#exclusions TfCrawler#exclusions}
        */
        readonly exclusions?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_crawler#path TfCrawler#path}
        */
        readonly path: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_crawler#sample_size TfCrawler#sample_size}
        */
        readonly sampleSize?: number;
    }
    class S3TargetPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): S3TargetProperty | cdktn.IResolvable | undefined;
        set internalValue(value: S3TargetProperty | cdktn.IResolvable | undefined);
        private _connectionName?;
        get connectionName(): string;
        set connectionName(value: string);
        resetConnectionName(): void;
        get connectionNameInput(): string | undefined;
        private _dlqEventQueueArn?;
        get dlqEventQueueArn(): string;
        set dlqEventQueueArn(value: string);
        resetDlqEventQueueArn(): void;
        get dlqEventQueueArnInput(): string | undefined;
        private _eventQueueArn?;
        get eventQueueArn(): string;
        set eventQueueArn(value: string);
        resetEventQueueArn(): void;
        get eventQueueArnInput(): string | undefined;
        private _exclusions?;
        get exclusions(): string[];
        set exclusions(value: string[]);
        resetExclusions(): void;
        get exclusionsInput(): string[] | undefined;
        private _path?;
        get path(): string;
        set path(value: string);
        get pathInput(): string | undefined;
        private _sampleSize?;
        get sampleSize(): number;
        set sampleSize(value: number);
        resetSampleSize(): void;
        get sampleSizeInput(): number | undefined;
    }
    class S3TargetPropertyList extends cdktn.ComplexList {
        internalValue?: S3TargetProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): S3TargetPropertyOutputReference;
    }
    interface SchemaChangePolicyProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_crawler#delete_behavior TfCrawler#delete_behavior}
        */
        readonly deleteBehavior?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_crawler#update_behavior TfCrawler#update_behavior}
        */
        readonly updateBehavior?: string;
    }
    class SchemaChangePolicyPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SchemaChangePolicyProperty | undefined;
        set internalValue(value: SchemaChangePolicyProperty | undefined);
        private _deleteBehavior?;
        get deleteBehavior(): string;
        set deleteBehavior(value: string);
        resetDeleteBehavior(): void;
        get deleteBehaviorInput(): string | undefined;
        private _updateBehavior?;
        get updateBehavior(): string;
        set updateBehavior(value: string);
        resetUpdateBehavior(): void;
        get updateBehaviorInput(): string | undefined;
    }
}
