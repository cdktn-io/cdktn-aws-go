import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfMlTransformConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_ml_transform#description TfMlTransform#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_ml_transform#glue_version TfMlTransform#glue_version}
    */
    readonly glueVersion?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_ml_transform#id TfMlTransform#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_ml_transform#max_capacity TfMlTransform#max_capacity}
    */
    readonly maxCapacity?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_ml_transform#max_retries TfMlTransform#max_retries}
    */
    readonly maxRetries?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_ml_transform#name TfMlTransform#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_ml_transform#number_of_workers TfMlTransform#number_of_workers}
    */
    readonly numberOfWorkers?: number;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_ml_transform#region TfMlTransform#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_ml_transform#role_arn TfMlTransform#role_arn}
    */
    readonly roleArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_ml_transform#tags TfMlTransform#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_ml_transform#tags_all TfMlTransform#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_ml_transform#timeout TfMlTransform#timeout}
    */
    readonly timeout?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_ml_transform#worker_type TfMlTransform#worker_type}
    */
    readonly workerType?: string;
    /**
    * input_record_tables block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_ml_transform#input_record_tables TfMlTransform#input_record_tables}
    */
    readonly inputRecordTables: TfMlTransform.InputRecordTablesProperty[] | cdktn.IResolvable;
    /**
    * parameters block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_ml_transform#parameters TfMlTransform#parameters}
    */
    readonly parameters: TfMlTransform.ParametersProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_ml_transform aws_glue_ml_transform}
*/
export declare class TfMlTransform extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_glue_ml_transform";
    /**
    * Generates CDKTN code for importing a TfMlTransform resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfMlTransform to import
    * @param importFromId The id of the existing TfMlTransform that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_ml_transform#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfMlTransform to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_ml_transform aws_glue_ml_transform} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfMlTransformConfig
    */
    constructor(scope: Construct, id: string, config: TfMlTransformConfig);
    get arn(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _glueVersion?;
    get glueVersion(): string;
    set glueVersion(value: string);
    resetGlueVersion(): void;
    get glueVersionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get labelCount(): number;
    private _maxCapacity?;
    get maxCapacity(): number;
    set maxCapacity(value: number);
    resetMaxCapacity(): void;
    get maxCapacityInput(): number | undefined;
    private _maxRetries?;
    get maxRetries(): number;
    set maxRetries(value: number);
    resetMaxRetries(): void;
    get maxRetriesInput(): number | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _numberOfWorkers?;
    get numberOfWorkers(): number;
    set numberOfWorkers(value: number);
    resetNumberOfWorkers(): void;
    get numberOfWorkersInput(): number | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _roleArn?;
    get roleArn(): string;
    set roleArn(value: string);
    get roleArnInput(): string | undefined;
    private _schema;
    get schema(): TfMlTransform.SchemaPropertyList;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _timeout?;
    get timeout(): number;
    set timeout(value: number);
    resetTimeout(): void;
    get timeoutInput(): number | undefined;
    private _workerType?;
    get workerType(): string;
    set workerType(value: string);
    resetWorkerType(): void;
    get workerTypeInput(): string | undefined;
    private _inputRecordTables;
    get inputRecordTables(): TfMlTransform.InputRecordTablesPropertyList;
    putInputRecordTables(value: TfMlTransform.InputRecordTablesProperty[] | cdktn.IResolvable): void;
    get inputRecordTablesInput(): cdktn.IResolvable | TfMlTransform.InputRecordTablesProperty[] | undefined;
    private _parameters;
    get parameters(): TfMlTransform.ParametersPropertyOutputReference;
    putParameters(value: TfMlTransform.ParametersProperty): void;
    get parametersInput(): TfMlTransform.ParametersProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfMlTransformSchemaPropertyToTerraform(struct?: TfMlTransform.SchemaProperty): any;
export declare function tfMlTransformSchemaPropertyToHclTerraform(struct?: TfMlTransform.SchemaProperty): any;
export declare function tfMlTransformInputRecordTablesPropertyToTerraform(struct?: TfMlTransform.InputRecordTablesProperty | cdktn.IResolvable): any;
export declare function tfMlTransformInputRecordTablesPropertyToHclTerraform(struct?: TfMlTransform.InputRecordTablesProperty | cdktn.IResolvable): any;
export declare function tfMlTransformFindMatchesParametersPropertyToTerraform(struct?: TfMlTransform.FindMatchesParametersPropertyOutputReference | TfMlTransform.FindMatchesParametersProperty): any;
export declare function tfMlTransformFindMatchesParametersPropertyToHclTerraform(struct?: TfMlTransform.FindMatchesParametersPropertyOutputReference | TfMlTransform.FindMatchesParametersProperty): any;
export declare function tfMlTransformParametersPropertyToTerraform(struct?: TfMlTransform.ParametersPropertyOutputReference | TfMlTransform.ParametersProperty): any;
export declare function tfMlTransformParametersPropertyToHclTerraform(struct?: TfMlTransform.ParametersPropertyOutputReference | TfMlTransform.ParametersProperty): any;
export declare namespace TfMlTransform {
    interface SchemaProperty {
    }
    class SchemaPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SchemaProperty | undefined;
        set internalValue(value: SchemaProperty | undefined);
        get dataType(): string;
        get name(): string;
    }
    class SchemaPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SchemaPropertyOutputReference;
    }
    interface InputRecordTablesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_ml_transform#catalog_id TfMlTransform#catalog_id}
        */
        readonly catalogId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_ml_transform#connection_name TfMlTransform#connection_name}
        */
        readonly connectionName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_ml_transform#database_name TfMlTransform#database_name}
        */
        readonly databaseName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_ml_transform#table_name TfMlTransform#table_name}
        */
        readonly tableName: string;
    }
    class InputRecordTablesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): InputRecordTablesProperty | cdktn.IResolvable | undefined;
        set internalValue(value: InputRecordTablesProperty | cdktn.IResolvable | undefined);
        private _catalogId?;
        get catalogId(): string;
        set catalogId(value: string);
        resetCatalogId(): void;
        get catalogIdInput(): string | undefined;
        private _connectionName?;
        get connectionName(): string;
        set connectionName(value: string);
        resetConnectionName(): void;
        get connectionNameInput(): string | undefined;
        private _databaseName?;
        get databaseName(): string;
        set databaseName(value: string);
        get databaseNameInput(): string | undefined;
        private _tableName?;
        get tableName(): string;
        set tableName(value: string);
        get tableNameInput(): string | undefined;
    }
    class InputRecordTablesPropertyList extends cdktn.ComplexList {
        internalValue?: InputRecordTablesProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): InputRecordTablesPropertyOutputReference;
    }
    interface FindMatchesParametersProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_ml_transform#accuracy_cost_trade_off TfMlTransform#accuracy_cost_trade_off}
        */
        readonly accuracyCostTradeOff?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_ml_transform#enforce_provided_labels TfMlTransform#enforce_provided_labels}
        */
        readonly enforceProvidedLabels?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_ml_transform#precision_recall_trade_off TfMlTransform#precision_recall_trade_off}
        */
        readonly precisionRecallTradeOff?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_ml_transform#primary_key_column_name TfMlTransform#primary_key_column_name}
        */
        readonly primaryKeyColumnName?: string;
    }
    class FindMatchesParametersPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): FindMatchesParametersProperty | undefined;
        set internalValue(value: FindMatchesParametersProperty | undefined);
        private _accuracyCostTradeOff?;
        get accuracyCostTradeOff(): number;
        set accuracyCostTradeOff(value: number);
        resetAccuracyCostTradeOff(): void;
        get accuracyCostTradeOffInput(): number | undefined;
        private _enforceProvidedLabels?;
        get enforceProvidedLabels(): boolean | cdktn.IResolvable;
        set enforceProvidedLabels(value: boolean | cdktn.IResolvable);
        resetEnforceProvidedLabels(): void;
        get enforceProvidedLabelsInput(): boolean | cdktn.IResolvable | undefined;
        private _precisionRecallTradeOff?;
        get precisionRecallTradeOff(): number;
        set precisionRecallTradeOff(value: number);
        resetPrecisionRecallTradeOff(): void;
        get precisionRecallTradeOffInput(): number | undefined;
        private _primaryKeyColumnName?;
        get primaryKeyColumnName(): string;
        set primaryKeyColumnName(value: string);
        resetPrimaryKeyColumnName(): void;
        get primaryKeyColumnNameInput(): string | undefined;
    }
    interface ParametersProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_ml_transform#transform_type TfMlTransform#transform_type}
        */
        readonly transformType: string;
        /**
        * find_matches_parameters block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_ml_transform#find_matches_parameters TfMlTransform#find_matches_parameters}
        */
        readonly findMatchesParameters: FindMatchesParametersProperty;
    }
    class ParametersPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ParametersProperty | undefined;
        set internalValue(value: ParametersProperty | undefined);
        private _transformType?;
        get transformType(): string;
        set transformType(value: string);
        get transformTypeInput(): string | undefined;
        private _findMatchesParameters;
        get findMatchesParameters(): FindMatchesParametersPropertyOutputReference;
        putFindMatchesParameters(value: FindMatchesParametersProperty): void;
        get findMatchesParametersInput(): FindMatchesParametersProperty | undefined;
    }
}
