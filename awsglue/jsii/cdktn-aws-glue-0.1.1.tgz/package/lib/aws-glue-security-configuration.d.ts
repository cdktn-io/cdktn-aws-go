import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsGlueSecurityConfigurationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_security_configuration#id AwsGlueSecurityConfiguration#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_security_configuration#name AwsGlueSecurityConfiguration#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_security_configuration#region AwsGlueSecurityConfiguration#region}
    */
    readonly region?: string;
    /**
    * encryption_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_security_configuration#encryption_configuration AwsGlueSecurityConfiguration#encryption_configuration}
    */
    readonly encryptionConfiguration: AwsGlueSecurityConfiguration.EncryptionConfigurationProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_security_configuration aws_glue_security_configuration}
*/
export declare class AwsGlueSecurityConfiguration extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_glue_security_configuration";
    /**
    * Generates CDKTN code for importing a AwsGlueSecurityConfiguration resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsGlueSecurityConfiguration to import
    * @param importFromId The id of the existing AwsGlueSecurityConfiguration that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_security_configuration#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsGlueSecurityConfiguration to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_security_configuration aws_glue_security_configuration} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsGlueSecurityConfigurationConfig
    */
    constructor(scope: Construct, id: string, config: AwsGlueSecurityConfigurationConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _encryptionConfiguration;
    get encryptionConfiguration(): AwsGlueSecurityConfiguration.EncryptionConfigurationPropertyOutputReference;
    putEncryptionConfiguration(value: AwsGlueSecurityConfiguration.EncryptionConfigurationProperty): void;
    get encryptionConfigurationInput(): AwsGlueSecurityConfiguration.EncryptionConfigurationProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsGlueSecurityConfigurationCloudwatchEncryptionPropertyToTerraform(struct?: AwsGlueSecurityConfiguration.CloudwatchEncryptionPropertyOutputReference | AwsGlueSecurityConfiguration.CloudwatchEncryptionProperty): any;
export declare function awsGlueSecurityConfigurationCloudwatchEncryptionPropertyToHclTerraform(struct?: AwsGlueSecurityConfiguration.CloudwatchEncryptionPropertyOutputReference | AwsGlueSecurityConfiguration.CloudwatchEncryptionProperty): any;
export declare function awsGlueSecurityConfigurationJobBookmarksEncryptionPropertyToTerraform(struct?: AwsGlueSecurityConfiguration.JobBookmarksEncryptionPropertyOutputReference | AwsGlueSecurityConfiguration.JobBookmarksEncryptionProperty): any;
export declare function awsGlueSecurityConfigurationJobBookmarksEncryptionPropertyToHclTerraform(struct?: AwsGlueSecurityConfiguration.JobBookmarksEncryptionPropertyOutputReference | AwsGlueSecurityConfiguration.JobBookmarksEncryptionProperty): any;
export declare function awsGlueSecurityConfigurationS3EncryptionPropertyToTerraform(struct?: AwsGlueSecurityConfiguration.S3EncryptionPropertyOutputReference | AwsGlueSecurityConfiguration.S3EncryptionProperty): any;
export declare function awsGlueSecurityConfigurationS3EncryptionPropertyToHclTerraform(struct?: AwsGlueSecurityConfiguration.S3EncryptionPropertyOutputReference | AwsGlueSecurityConfiguration.S3EncryptionProperty): any;
export declare function awsGlueSecurityConfigurationEncryptionConfigurationPropertyToTerraform(struct?: AwsGlueSecurityConfiguration.EncryptionConfigurationPropertyOutputReference | AwsGlueSecurityConfiguration.EncryptionConfigurationProperty): any;
export declare function awsGlueSecurityConfigurationEncryptionConfigurationPropertyToHclTerraform(struct?: AwsGlueSecurityConfiguration.EncryptionConfigurationPropertyOutputReference | AwsGlueSecurityConfiguration.EncryptionConfigurationProperty): any;
export declare namespace AwsGlueSecurityConfiguration {
    interface CloudwatchEncryptionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_security_configuration#cloudwatch_encryption_mode AwsGlueSecurityConfiguration#cloudwatch_encryption_mode}
        */
        readonly cloudwatchEncryptionMode?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_security_configuration#kms_key_arn AwsGlueSecurityConfiguration#kms_key_arn}
        */
        readonly kmsKeyArn?: string;
    }
    class CloudwatchEncryptionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CloudwatchEncryptionProperty | undefined;
        set internalValue(value: CloudwatchEncryptionProperty | undefined);
        private _cloudwatchEncryptionMode?;
        get cloudwatchEncryptionMode(): string;
        set cloudwatchEncryptionMode(value: string);
        resetCloudwatchEncryptionMode(): void;
        get cloudwatchEncryptionModeInput(): string | undefined;
        private _kmsKeyArn?;
        get kmsKeyArn(): string;
        set kmsKeyArn(value: string);
        resetKmsKeyArn(): void;
        get kmsKeyArnInput(): string | undefined;
    }
    interface JobBookmarksEncryptionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_security_configuration#job_bookmarks_encryption_mode AwsGlueSecurityConfiguration#job_bookmarks_encryption_mode}
        */
        readonly jobBookmarksEncryptionMode?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_security_configuration#kms_key_arn AwsGlueSecurityConfiguration#kms_key_arn}
        */
        readonly kmsKeyArn?: string;
    }
    class JobBookmarksEncryptionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): JobBookmarksEncryptionProperty | undefined;
        set internalValue(value: JobBookmarksEncryptionProperty | undefined);
        private _jobBookmarksEncryptionMode?;
        get jobBookmarksEncryptionMode(): string;
        set jobBookmarksEncryptionMode(value: string);
        resetJobBookmarksEncryptionMode(): void;
        get jobBookmarksEncryptionModeInput(): string | undefined;
        private _kmsKeyArn?;
        get kmsKeyArn(): string;
        set kmsKeyArn(value: string);
        resetKmsKeyArn(): void;
        get kmsKeyArnInput(): string | undefined;
    }
    interface S3EncryptionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_security_configuration#kms_key_arn AwsGlueSecurityConfiguration#kms_key_arn}
        */
        readonly kmsKeyArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_security_configuration#s3_encryption_mode AwsGlueSecurityConfiguration#s3_encryption_mode}
        */
        readonly s3EncryptionMode?: string;
    }
    class S3EncryptionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): S3EncryptionProperty | undefined;
        set internalValue(value: S3EncryptionProperty | undefined);
        private _kmsKeyArn?;
        get kmsKeyArn(): string;
        set kmsKeyArn(value: string);
        resetKmsKeyArn(): void;
        get kmsKeyArnInput(): string | undefined;
        private _s3EncryptionMode?;
        get s3EncryptionMode(): string;
        set s3EncryptionMode(value: string);
        resetS3EncryptionMode(): void;
        get s3EncryptionModeInput(): string | undefined;
    }
    interface EncryptionConfigurationProperty {
        /**
        * cloudwatch_encryption block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_security_configuration#cloudwatch_encryption AwsGlueSecurityConfiguration#cloudwatch_encryption}
        */
        readonly cloudwatchEncryption: CloudwatchEncryptionProperty;
        /**
        * job_bookmarks_encryption block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_security_configuration#job_bookmarks_encryption AwsGlueSecurityConfiguration#job_bookmarks_encryption}
        */
        readonly jobBookmarksEncryption: JobBookmarksEncryptionProperty;
        /**
        * s3_encryption block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_security_configuration#s3_encryption AwsGlueSecurityConfiguration#s3_encryption}
        */
        readonly s3Encryption: S3EncryptionProperty;
    }
    class EncryptionConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): EncryptionConfigurationProperty | undefined;
        set internalValue(value: EncryptionConfigurationProperty | undefined);
        private _cloudwatchEncryption;
        get cloudwatchEncryption(): CloudwatchEncryptionPropertyOutputReference;
        putCloudwatchEncryption(value: CloudwatchEncryptionProperty): void;
        get cloudwatchEncryptionInput(): CloudwatchEncryptionProperty | undefined;
        private _jobBookmarksEncryption;
        get jobBookmarksEncryption(): JobBookmarksEncryptionPropertyOutputReference;
        putJobBookmarksEncryption(value: JobBookmarksEncryptionProperty): void;
        get jobBookmarksEncryptionInput(): JobBookmarksEncryptionProperty | undefined;
        private _s3Encryption;
        get s3Encryption(): S3EncryptionPropertyOutputReference;
        putS3Encryption(value: S3EncryptionProperty): void;
        get s3EncryptionInput(): S3EncryptionProperty | undefined;
    }
}
