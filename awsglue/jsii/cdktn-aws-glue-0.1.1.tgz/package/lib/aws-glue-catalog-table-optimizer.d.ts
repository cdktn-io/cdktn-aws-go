import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsGlueCatalogTableOptimizerConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table_optimizer#catalog_id AwsGlueCatalogTableOptimizer#catalog_id}
    */
    readonly catalogId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table_optimizer#database_name AwsGlueCatalogTableOptimizer#database_name}
    */
    readonly databaseName: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table_optimizer#region AwsGlueCatalogTableOptimizer#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table_optimizer#table_name AwsGlueCatalogTableOptimizer#table_name}
    */
    readonly tableName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table_optimizer#type AwsGlueCatalogTableOptimizer#type}
    */
    readonly type: string;
    /**
    * configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table_optimizer#configuration AwsGlueCatalogTableOptimizer#configuration}
    */
    readonly configuration?: AwsGlueCatalogTableOptimizer.ConfigurationProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table_optimizer aws_glue_catalog_table_optimizer}
*/
export declare class AwsGlueCatalogTableOptimizer extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_glue_catalog_table_optimizer";
    /**
    * Generates CDKTN code for importing a AwsGlueCatalogTableOptimizer resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsGlueCatalogTableOptimizer to import
    * @param importFromId The id of the existing AwsGlueCatalogTableOptimizer that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table_optimizer#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsGlueCatalogTableOptimizer to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table_optimizer aws_glue_catalog_table_optimizer} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsGlueCatalogTableOptimizerConfig
    */
    constructor(scope: Construct, id: string, config: AwsGlueCatalogTableOptimizerConfig);
    private _catalogId?;
    get catalogId(): string;
    set catalogId(value: string);
    get catalogIdInput(): string | undefined;
    private _databaseName?;
    get databaseName(): string;
    set databaseName(value: string);
    get databaseNameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tableName?;
    get tableName(): string;
    set tableName(value: string);
    get tableNameInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _configuration;
    get configuration(): AwsGlueCatalogTableOptimizer.ConfigurationPropertyList;
    putConfiguration(value: AwsGlueCatalogTableOptimizer.ConfigurationProperty[] | cdktn.IResolvable): void;
    resetConfiguration(): void;
    get configurationInput(): cdktn.IResolvable | AwsGlueCatalogTableOptimizer.ConfigurationProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsGlueCatalogTableOptimizerConfigurationCompactionConfigurationIcebergConfigurationPropertyToTerraform(struct?: AwsGlueCatalogTableOptimizer.ConfigurationCompactionConfigurationIcebergConfigurationProperty | cdktn.IResolvable): any;
export declare function awsGlueCatalogTableOptimizerConfigurationCompactionConfigurationIcebergConfigurationPropertyToHclTerraform(struct?: AwsGlueCatalogTableOptimizer.ConfigurationCompactionConfigurationIcebergConfigurationProperty | cdktn.IResolvable): any;
export declare function awsGlueCatalogTableOptimizerCompactionConfigurationPropertyToTerraform(struct?: AwsGlueCatalogTableOptimizer.CompactionConfigurationProperty | cdktn.IResolvable): any;
export declare function awsGlueCatalogTableOptimizerCompactionConfigurationPropertyToHclTerraform(struct?: AwsGlueCatalogTableOptimizer.CompactionConfigurationProperty | cdktn.IResolvable): any;
export declare function awsGlueCatalogTableOptimizerConfigurationOrphanFileDeletionConfigurationIcebergConfigurationPropertyToTerraform(struct?: AwsGlueCatalogTableOptimizer.ConfigurationOrphanFileDeletionConfigurationIcebergConfigurationProperty | cdktn.IResolvable): any;
export declare function awsGlueCatalogTableOptimizerConfigurationOrphanFileDeletionConfigurationIcebergConfigurationPropertyToHclTerraform(struct?: AwsGlueCatalogTableOptimizer.ConfigurationOrphanFileDeletionConfigurationIcebergConfigurationProperty | cdktn.IResolvable): any;
export declare function awsGlueCatalogTableOptimizerOrphanFileDeletionConfigurationPropertyToTerraform(struct?: AwsGlueCatalogTableOptimizer.OrphanFileDeletionConfigurationProperty | cdktn.IResolvable): any;
export declare function awsGlueCatalogTableOptimizerOrphanFileDeletionConfigurationPropertyToHclTerraform(struct?: AwsGlueCatalogTableOptimizer.OrphanFileDeletionConfigurationProperty | cdktn.IResolvable): any;
export declare function awsGlueCatalogTableOptimizerConfigurationRetentionConfigurationIcebergConfigurationPropertyToTerraform(struct?: AwsGlueCatalogTableOptimizer.ConfigurationRetentionConfigurationIcebergConfigurationProperty | cdktn.IResolvable): any;
export declare function awsGlueCatalogTableOptimizerConfigurationRetentionConfigurationIcebergConfigurationPropertyToHclTerraform(struct?: AwsGlueCatalogTableOptimizer.ConfigurationRetentionConfigurationIcebergConfigurationProperty | cdktn.IResolvable): any;
export declare function awsGlueCatalogTableOptimizerRetentionConfigurationPropertyToTerraform(struct?: AwsGlueCatalogTableOptimizer.RetentionConfigurationProperty | cdktn.IResolvable): any;
export declare function awsGlueCatalogTableOptimizerRetentionConfigurationPropertyToHclTerraform(struct?: AwsGlueCatalogTableOptimizer.RetentionConfigurationProperty | cdktn.IResolvable): any;
export declare function awsGlueCatalogTableOptimizerConfigurationPropertyToTerraform(struct?: AwsGlueCatalogTableOptimizer.ConfigurationProperty | cdktn.IResolvable): any;
export declare function awsGlueCatalogTableOptimizerConfigurationPropertyToHclTerraform(struct?: AwsGlueCatalogTableOptimizer.ConfigurationProperty | cdktn.IResolvable): any;
export declare namespace AwsGlueCatalogTableOptimizer {
    interface ConfigurationCompactionConfigurationIcebergConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table_optimizer#delete_file_threshold AwsGlueCatalogTableOptimizer#delete_file_threshold}
        */
        readonly deleteFileThreshold?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table_optimizer#min_input_files AwsGlueCatalogTableOptimizer#min_input_files}
        */
        readonly minInputFiles?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table_optimizer#strategy AwsGlueCatalogTableOptimizer#strategy}
        */
        readonly strategy?: string;
    }
    class ConfigurationCompactionConfigurationIcebergConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ConfigurationCompactionConfigurationIcebergConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ConfigurationCompactionConfigurationIcebergConfigurationProperty | cdktn.IResolvable | undefined);
        private _deleteFileThreshold?;
        get deleteFileThreshold(): number;
        set deleteFileThreshold(value: number);
        resetDeleteFileThreshold(): void;
        get deleteFileThresholdInput(): number | undefined;
        private _minInputFiles?;
        get minInputFiles(): number;
        set minInputFiles(value: number);
        resetMinInputFiles(): void;
        get minInputFilesInput(): number | undefined;
        private _strategy?;
        get strategy(): string;
        set strategy(value: string);
        resetStrategy(): void;
        get strategyInput(): string | undefined;
    }
    class ConfigurationCompactionConfigurationIcebergConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: ConfigurationCompactionConfigurationIcebergConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ConfigurationCompactionConfigurationIcebergConfigurationPropertyOutputReference;
    }
    interface CompactionConfigurationProperty {
        /**
        * iceberg_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table_optimizer#iceberg_configuration AwsGlueCatalogTableOptimizer#iceberg_configuration}
        */
        readonly icebergConfiguration?: ConfigurationCompactionConfigurationIcebergConfigurationProperty[] | cdktn.IResolvable;
    }
    class CompactionConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CompactionConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CompactionConfigurationProperty | cdktn.IResolvable | undefined);
        private _icebergConfiguration;
        get icebergConfiguration(): ConfigurationCompactionConfigurationIcebergConfigurationPropertyList;
        putIcebergConfiguration(value: ConfigurationCompactionConfigurationIcebergConfigurationProperty[] | cdktn.IResolvable): void;
        resetIcebergConfiguration(): void;
        get icebergConfigurationInput(): cdktn.IResolvable | ConfigurationCompactionConfigurationIcebergConfigurationProperty[] | undefined;
    }
    class CompactionConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: CompactionConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CompactionConfigurationPropertyOutputReference;
    }
    interface ConfigurationOrphanFileDeletionConfigurationIcebergConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table_optimizer#location AwsGlueCatalogTableOptimizer#location}
        */
        readonly location?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table_optimizer#orphan_file_retention_period_in_days AwsGlueCatalogTableOptimizer#orphan_file_retention_period_in_days}
        */
        readonly orphanFileRetentionPeriodInDays?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table_optimizer#run_rate_in_hours AwsGlueCatalogTableOptimizer#run_rate_in_hours}
        */
        readonly runRateInHours?: number;
    }
    class ConfigurationOrphanFileDeletionConfigurationIcebergConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ConfigurationOrphanFileDeletionConfigurationIcebergConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ConfigurationOrphanFileDeletionConfigurationIcebergConfigurationProperty | cdktn.IResolvable | undefined);
        private _location?;
        get location(): string;
        set location(value: string);
        resetLocation(): void;
        get locationInput(): string | undefined;
        private _orphanFileRetentionPeriodInDays?;
        get orphanFileRetentionPeriodInDays(): number;
        set orphanFileRetentionPeriodInDays(value: number);
        resetOrphanFileRetentionPeriodInDays(): void;
        get orphanFileRetentionPeriodInDaysInput(): number | undefined;
        private _runRateInHours?;
        get runRateInHours(): number;
        set runRateInHours(value: number);
        resetRunRateInHours(): void;
        get runRateInHoursInput(): number | undefined;
    }
    class ConfigurationOrphanFileDeletionConfigurationIcebergConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: ConfigurationOrphanFileDeletionConfigurationIcebergConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ConfigurationOrphanFileDeletionConfigurationIcebergConfigurationPropertyOutputReference;
    }
    interface OrphanFileDeletionConfigurationProperty {
        /**
        * iceberg_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table_optimizer#iceberg_configuration AwsGlueCatalogTableOptimizer#iceberg_configuration}
        */
        readonly icebergConfiguration?: ConfigurationOrphanFileDeletionConfigurationIcebergConfigurationProperty[] | cdktn.IResolvable;
    }
    class OrphanFileDeletionConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): OrphanFileDeletionConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: OrphanFileDeletionConfigurationProperty | cdktn.IResolvable | undefined);
        private _icebergConfiguration;
        get icebergConfiguration(): ConfigurationOrphanFileDeletionConfigurationIcebergConfigurationPropertyList;
        putIcebergConfiguration(value: ConfigurationOrphanFileDeletionConfigurationIcebergConfigurationProperty[] | cdktn.IResolvable): void;
        resetIcebergConfiguration(): void;
        get icebergConfigurationInput(): cdktn.IResolvable | ConfigurationOrphanFileDeletionConfigurationIcebergConfigurationProperty[] | undefined;
    }
    class OrphanFileDeletionConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: OrphanFileDeletionConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): OrphanFileDeletionConfigurationPropertyOutputReference;
    }
    interface ConfigurationRetentionConfigurationIcebergConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table_optimizer#clean_expired_files AwsGlueCatalogTableOptimizer#clean_expired_files}
        */
        readonly cleanExpiredFiles?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table_optimizer#number_of_snapshots_to_retain AwsGlueCatalogTableOptimizer#number_of_snapshots_to_retain}
        */
        readonly numberOfSnapshotsToRetain?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table_optimizer#run_rate_in_hours AwsGlueCatalogTableOptimizer#run_rate_in_hours}
        */
        readonly runRateInHours?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table_optimizer#snapshot_retention_period_in_days AwsGlueCatalogTableOptimizer#snapshot_retention_period_in_days}
        */
        readonly snapshotRetentionPeriodInDays?: number;
    }
    class ConfigurationRetentionConfigurationIcebergConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ConfigurationRetentionConfigurationIcebergConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ConfigurationRetentionConfigurationIcebergConfigurationProperty | cdktn.IResolvable | undefined);
        private _cleanExpiredFiles?;
        get cleanExpiredFiles(): boolean | cdktn.IResolvable;
        set cleanExpiredFiles(value: boolean | cdktn.IResolvable);
        resetCleanExpiredFiles(): void;
        get cleanExpiredFilesInput(): boolean | cdktn.IResolvable | undefined;
        private _numberOfSnapshotsToRetain?;
        get numberOfSnapshotsToRetain(): number;
        set numberOfSnapshotsToRetain(value: number);
        resetNumberOfSnapshotsToRetain(): void;
        get numberOfSnapshotsToRetainInput(): number | undefined;
        private _runRateInHours?;
        get runRateInHours(): number;
        set runRateInHours(value: number);
        resetRunRateInHours(): void;
        get runRateInHoursInput(): number | undefined;
        private _snapshotRetentionPeriodInDays?;
        get snapshotRetentionPeriodInDays(): number;
        set snapshotRetentionPeriodInDays(value: number);
        resetSnapshotRetentionPeriodInDays(): void;
        get snapshotRetentionPeriodInDaysInput(): number | undefined;
    }
    class ConfigurationRetentionConfigurationIcebergConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: ConfigurationRetentionConfigurationIcebergConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ConfigurationRetentionConfigurationIcebergConfigurationPropertyOutputReference;
    }
    interface RetentionConfigurationProperty {
        /**
        * iceberg_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table_optimizer#iceberg_configuration AwsGlueCatalogTableOptimizer#iceberg_configuration}
        */
        readonly icebergConfiguration?: ConfigurationRetentionConfigurationIcebergConfigurationProperty[] | cdktn.IResolvable;
    }
    class RetentionConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RetentionConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RetentionConfigurationProperty | cdktn.IResolvable | undefined);
        private _icebergConfiguration;
        get icebergConfiguration(): ConfigurationRetentionConfigurationIcebergConfigurationPropertyList;
        putIcebergConfiguration(value: ConfigurationRetentionConfigurationIcebergConfigurationProperty[] | cdktn.IResolvable): void;
        resetIcebergConfiguration(): void;
        get icebergConfigurationInput(): cdktn.IResolvable | ConfigurationRetentionConfigurationIcebergConfigurationProperty[] | undefined;
    }
    class RetentionConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: RetentionConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RetentionConfigurationPropertyOutputReference;
    }
    interface ConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table_optimizer#enabled AwsGlueCatalogTableOptimizer#enabled}
        */
        readonly enabled: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table_optimizer#role_arn AwsGlueCatalogTableOptimizer#role_arn}
        */
        readonly roleArn: string;
        /**
        * compaction_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table_optimizer#compaction_configuration AwsGlueCatalogTableOptimizer#compaction_configuration}
        */
        readonly compactionConfiguration?: CompactionConfigurationProperty[] | cdktn.IResolvable;
        /**
        * orphan_file_deletion_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table_optimizer#orphan_file_deletion_configuration AwsGlueCatalogTableOptimizer#orphan_file_deletion_configuration}
        */
        readonly orphanFileDeletionConfiguration?: OrphanFileDeletionConfigurationProperty[] | cdktn.IResolvable;
        /**
        * retention_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table_optimizer#retention_configuration AwsGlueCatalogTableOptimizer#retention_configuration}
        */
        readonly retentionConfiguration?: RetentionConfigurationProperty[] | cdktn.IResolvable;
    }
    class ConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ConfigurationProperty | cdktn.IResolvable | undefined);
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
        private _roleArn?;
        get roleArn(): string;
        set roleArn(value: string);
        get roleArnInput(): string | undefined;
        private _compactionConfiguration;
        get compactionConfiguration(): CompactionConfigurationPropertyList;
        putCompactionConfiguration(value: CompactionConfigurationProperty[] | cdktn.IResolvable): void;
        resetCompactionConfiguration(): void;
        get compactionConfigurationInput(): cdktn.IResolvable | CompactionConfigurationProperty[] | undefined;
        private _orphanFileDeletionConfiguration;
        get orphanFileDeletionConfiguration(): OrphanFileDeletionConfigurationPropertyList;
        putOrphanFileDeletionConfiguration(value: OrphanFileDeletionConfigurationProperty[] | cdktn.IResolvable): void;
        resetOrphanFileDeletionConfiguration(): void;
        get orphanFileDeletionConfigurationInput(): cdktn.IResolvable | OrphanFileDeletionConfigurationProperty[] | undefined;
        private _retentionConfiguration;
        get retentionConfiguration(): RetentionConfigurationPropertyList;
        putRetentionConfiguration(value: RetentionConfigurationProperty[] | cdktn.IResolvable): void;
        resetRetentionConfiguration(): void;
        get retentionConfigurationInput(): cdktn.IResolvable | RetentionConfigurationProperty[] | undefined;
    }
    class ConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: ConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ConfigurationPropertyOutputReference;
    }
}
