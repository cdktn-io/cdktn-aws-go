import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsGlueDataQualityRulesetConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_data_quality_ruleset#description AwsGlueDataQualityRuleset#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_data_quality_ruleset#id AwsGlueDataQualityRuleset#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_data_quality_ruleset#name AwsGlueDataQualityRuleset#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_data_quality_ruleset#region AwsGlueDataQualityRuleset#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_data_quality_ruleset#ruleset AwsGlueDataQualityRuleset#ruleset}
    */
    readonly ruleset: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_data_quality_ruleset#tags AwsGlueDataQualityRuleset#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_data_quality_ruleset#tags_all AwsGlueDataQualityRuleset#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * target_table block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_data_quality_ruleset#target_table AwsGlueDataQualityRuleset#target_table}
    */
    readonly targetTable?: AwsGlueDataQualityRuleset.TargetTableProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_data_quality_ruleset aws_glue_data_quality_ruleset}
*/
export declare class AwsGlueDataQualityRuleset extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_glue_data_quality_ruleset";
    /**
    * Generates CDKTN code for importing a AwsGlueDataQualityRuleset resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsGlueDataQualityRuleset to import
    * @param importFromId The id of the existing AwsGlueDataQualityRuleset that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_data_quality_ruleset#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsGlueDataQualityRuleset to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_data_quality_ruleset aws_glue_data_quality_ruleset} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsGlueDataQualityRulesetConfig
    */
    constructor(scope: Construct, id: string, config: AwsGlueDataQualityRulesetConfig);
    get arn(): string;
    get createdOn(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get lastModifiedOn(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get recommendationRunId(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _ruleset?;
    get ruleset(): string;
    set ruleset(value: string);
    get rulesetInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _targetTable;
    get targetTable(): AwsGlueDataQualityRuleset.TargetTablePropertyOutputReference;
    putTargetTable(value: AwsGlueDataQualityRuleset.TargetTableProperty): void;
    resetTargetTable(): void;
    get targetTableInput(): AwsGlueDataQualityRuleset.TargetTableProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsGlueDataQualityRulesetTargetTablePropertyToTerraform(struct?: AwsGlueDataQualityRuleset.TargetTablePropertyOutputReference | AwsGlueDataQualityRuleset.TargetTableProperty): any;
export declare function awsGlueDataQualityRulesetTargetTablePropertyToHclTerraform(struct?: AwsGlueDataQualityRuleset.TargetTablePropertyOutputReference | AwsGlueDataQualityRuleset.TargetTableProperty): any;
export declare namespace AwsGlueDataQualityRuleset {
    interface TargetTableProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_data_quality_ruleset#catalog_id AwsGlueDataQualityRuleset#catalog_id}
        */
        readonly catalogId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_data_quality_ruleset#database_name AwsGlueDataQualityRuleset#database_name}
        */
        readonly databaseName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_data_quality_ruleset#table_name AwsGlueDataQualityRuleset#table_name}
        */
        readonly tableName: string;
    }
    class TargetTablePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TargetTableProperty | undefined;
        set internalValue(value: TargetTableProperty | undefined);
        private _catalogId?;
        get catalogId(): string;
        set catalogId(value: string);
        resetCatalogId(): void;
        get catalogIdInput(): string | undefined;
        private _databaseName?;
        get databaseName(): string;
        set databaseName(value: string);
        get databaseNameInput(): string | undefined;
        private _tableName?;
        get tableName(): string;
        set tableName(value: string);
        get tableNameInput(): string | undefined;
    }
}
