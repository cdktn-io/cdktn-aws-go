import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsGluePartitionConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_partition#catalog_id AwsGluePartition#catalog_id}
    */
    readonly catalogId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_partition#database_name AwsGluePartition#database_name}
    */
    readonly databaseName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_partition#id AwsGluePartition#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_partition#parameters AwsGluePartition#parameters}
    */
    readonly parameters?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_partition#partition_values AwsGluePartition#partition_values}
    */
    readonly partitionValues: string[];
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_partition#region AwsGluePartition#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_partition#table_name AwsGluePartition#table_name}
    */
    readonly tableName: string;
    /**
    * storage_descriptor block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_partition#storage_descriptor AwsGluePartition#storage_descriptor}
    */
    readonly storageDescriptor?: AwsGluePartition.StorageDescriptorProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_partition aws_glue_partition}
*/
export declare class AwsGluePartition extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_glue_partition";
    /**
    * Generates CDKTN code for importing a AwsGluePartition resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsGluePartition to import
    * @param importFromId The id of the existing AwsGluePartition that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_partition#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsGluePartition to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_partition aws_glue_partition} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsGluePartitionConfig
    */
    constructor(scope: Construct, id: string, config: AwsGluePartitionConfig);
    private _catalogId?;
    get catalogId(): string;
    set catalogId(value: string);
    resetCatalogId(): void;
    get catalogIdInput(): string | undefined;
    get creationTime(): string;
    private _databaseName?;
    get databaseName(): string;
    set databaseName(value: string);
    get databaseNameInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get lastAccessedTime(): string;
    get lastAnalyzedTime(): string;
    private _parameters?;
    get parameters(): {
        [key: string]: string;
    };
    set parameters(value: {
        [key: string]: string;
    });
    resetParameters(): void;
    get parametersInput(): {
        [key: string]: string;
    } | undefined;
    private _partitionValues?;
    get partitionValues(): string[];
    set partitionValues(value: string[]);
    get partitionValuesInput(): string[] | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tableName?;
    get tableName(): string;
    set tableName(value: string);
    get tableNameInput(): string | undefined;
    private _storageDescriptor;
    get storageDescriptor(): AwsGluePartition.StorageDescriptorPropertyOutputReference;
    putStorageDescriptor(value: AwsGluePartition.StorageDescriptorProperty): void;
    resetStorageDescriptor(): void;
    get storageDescriptorInput(): AwsGluePartition.StorageDescriptorProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsGluePartitionColumnsPropertyToTerraform(struct?: AwsGluePartition.ColumnsProperty | cdktn.IResolvable): any;
export declare function awsGluePartitionColumnsPropertyToHclTerraform(struct?: AwsGluePartition.ColumnsProperty | cdktn.IResolvable): any;
export declare function awsGluePartitionSerDeInfoPropertyToTerraform(struct?: AwsGluePartition.SerDeInfoPropertyOutputReference | AwsGluePartition.SerDeInfoProperty): any;
export declare function awsGluePartitionSerDeInfoPropertyToHclTerraform(struct?: AwsGluePartition.SerDeInfoPropertyOutputReference | AwsGluePartition.SerDeInfoProperty): any;
export declare function awsGluePartitionSkewedInfoPropertyToTerraform(struct?: AwsGluePartition.SkewedInfoPropertyOutputReference | AwsGluePartition.SkewedInfoProperty): any;
export declare function awsGluePartitionSkewedInfoPropertyToHclTerraform(struct?: AwsGluePartition.SkewedInfoPropertyOutputReference | AwsGluePartition.SkewedInfoProperty): any;
export declare function awsGluePartitionSortColumnsPropertyToTerraform(struct?: AwsGluePartition.SortColumnsProperty | cdktn.IResolvable): any;
export declare function awsGluePartitionSortColumnsPropertyToHclTerraform(struct?: AwsGluePartition.SortColumnsProperty | cdktn.IResolvable): any;
export declare function awsGluePartitionStorageDescriptorPropertyToTerraform(struct?: AwsGluePartition.StorageDescriptorPropertyOutputReference | AwsGluePartition.StorageDescriptorProperty): any;
export declare function awsGluePartitionStorageDescriptorPropertyToHclTerraform(struct?: AwsGluePartition.StorageDescriptorPropertyOutputReference | AwsGluePartition.StorageDescriptorProperty): any;
export declare namespace AwsGluePartition {
    interface ColumnsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_partition#comment AwsGluePartition#comment}
        */
        readonly comment?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_partition#name AwsGluePartition#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_partition#type AwsGluePartition#type}
        */
        readonly type?: string;
    }
    class ColumnsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ColumnsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ColumnsProperty | cdktn.IResolvable | undefined);
        private _comment?;
        get comment(): string;
        set comment(value: string);
        resetComment(): void;
        get commentInput(): string | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        resetType(): void;
        get typeInput(): string | undefined;
    }
    class ColumnsPropertyList extends cdktn.ComplexList {
        internalValue?: ColumnsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ColumnsPropertyOutputReference;
    }
    interface SerDeInfoProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_partition#name AwsGluePartition#name}
        */
        readonly name?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_partition#parameters AwsGluePartition#parameters}
        */
        readonly parameters?: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_partition#serialization_library AwsGluePartition#serialization_library}
        */
        readonly serializationLibrary?: string;
    }
    class SerDeInfoPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SerDeInfoProperty | undefined;
        set internalValue(value: SerDeInfoProperty | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        resetName(): void;
        get nameInput(): string | undefined;
        private _parameters?;
        get parameters(): {
            [key: string]: string;
        };
        set parameters(value: {
            [key: string]: string;
        });
        resetParameters(): void;
        get parametersInput(): {
            [key: string]: string;
        } | undefined;
        private _serializationLibrary?;
        get serializationLibrary(): string;
        set serializationLibrary(value: string);
        resetSerializationLibrary(): void;
        get serializationLibraryInput(): string | undefined;
    }
    interface SkewedInfoProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_partition#skewed_column_names AwsGluePartition#skewed_column_names}
        */
        readonly skewedColumnNames?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_partition#skewed_column_value_location_maps AwsGluePartition#skewed_column_value_location_maps}
        */
        readonly skewedColumnValueLocationMaps?: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_partition#skewed_column_values AwsGluePartition#skewed_column_values}
        */
        readonly skewedColumnValues?: string[];
    }
    class SkewedInfoPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SkewedInfoProperty | undefined;
        set internalValue(value: SkewedInfoProperty | undefined);
        private _skewedColumnNames?;
        get skewedColumnNames(): string[];
        set skewedColumnNames(value: string[]);
        resetSkewedColumnNames(): void;
        get skewedColumnNamesInput(): string[] | undefined;
        private _skewedColumnValueLocationMaps?;
        get skewedColumnValueLocationMaps(): {
            [key: string]: string;
        };
        set skewedColumnValueLocationMaps(value: {
            [key: string]: string;
        });
        resetSkewedColumnValueLocationMaps(): void;
        get skewedColumnValueLocationMapsInput(): {
            [key: string]: string;
        } | undefined;
        private _skewedColumnValues?;
        get skewedColumnValues(): string[];
        set skewedColumnValues(value: string[]);
        resetSkewedColumnValues(): void;
        get skewedColumnValuesInput(): string[] | undefined;
    }
    interface SortColumnsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_partition#column AwsGluePartition#column}
        */
        readonly column: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_partition#sort_order AwsGluePartition#sort_order}
        */
        readonly sortOrder: number;
    }
    class SortColumnsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SortColumnsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SortColumnsProperty | cdktn.IResolvable | undefined);
        private _column?;
        get column(): string;
        set column(value: string);
        get columnInput(): string | undefined;
        private _sortOrder?;
        get sortOrder(): number;
        set sortOrder(value: number);
        get sortOrderInput(): number | undefined;
    }
    class SortColumnsPropertyList extends cdktn.ComplexList {
        internalValue?: SortColumnsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SortColumnsPropertyOutputReference;
    }
    interface StorageDescriptorProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_partition#additional_locations AwsGluePartition#additional_locations}
        */
        readonly additionalLocations?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_partition#bucket_columns AwsGluePartition#bucket_columns}
        */
        readonly bucketColumns?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_partition#compressed AwsGluePartition#compressed}
        */
        readonly compressed?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_partition#input_format AwsGluePartition#input_format}
        */
        readonly inputFormat?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_partition#location AwsGluePartition#location}
        */
        readonly location?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_partition#number_of_buckets AwsGluePartition#number_of_buckets}
        */
        readonly numberOfBuckets?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_partition#output_format AwsGluePartition#output_format}
        */
        readonly outputFormat?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_partition#parameters AwsGluePartition#parameters}
        */
        readonly parameters?: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_partition#stored_as_sub_directories AwsGluePartition#stored_as_sub_directories}
        */
        readonly storedAsSubDirectories?: boolean | cdktn.IResolvable;
        /**
        * columns block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_partition#columns AwsGluePartition#columns}
        */
        readonly columns?: ColumnsProperty[] | cdktn.IResolvable;
        /**
        * ser_de_info block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_partition#ser_de_info AwsGluePartition#ser_de_info}
        */
        readonly serDeInfo?: SerDeInfoProperty;
        /**
        * skewed_info block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_partition#skewed_info AwsGluePartition#skewed_info}
        */
        readonly skewedInfo?: SkewedInfoProperty;
        /**
        * sort_columns block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_partition#sort_columns AwsGluePartition#sort_columns}
        */
        readonly sortColumns?: SortColumnsProperty[] | cdktn.IResolvable;
    }
    class StorageDescriptorPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): StorageDescriptorProperty | undefined;
        set internalValue(value: StorageDescriptorProperty | undefined);
        private _additionalLocations?;
        get additionalLocations(): string[];
        set additionalLocations(value: string[]);
        resetAdditionalLocations(): void;
        get additionalLocationsInput(): string[] | undefined;
        private _bucketColumns?;
        get bucketColumns(): string[];
        set bucketColumns(value: string[]);
        resetBucketColumns(): void;
        get bucketColumnsInput(): string[] | undefined;
        private _compressed?;
        get compressed(): boolean | cdktn.IResolvable;
        set compressed(value: boolean | cdktn.IResolvable);
        resetCompressed(): void;
        get compressedInput(): boolean | cdktn.IResolvable | undefined;
        private _inputFormat?;
        get inputFormat(): string;
        set inputFormat(value: string);
        resetInputFormat(): void;
        get inputFormatInput(): string | undefined;
        private _location?;
        get location(): string;
        set location(value: string);
        resetLocation(): void;
        get locationInput(): string | undefined;
        private _numberOfBuckets?;
        get numberOfBuckets(): number;
        set numberOfBuckets(value: number);
        resetNumberOfBuckets(): void;
        get numberOfBucketsInput(): number | undefined;
        private _outputFormat?;
        get outputFormat(): string;
        set outputFormat(value: string);
        resetOutputFormat(): void;
        get outputFormatInput(): string | undefined;
        private _parameters?;
        get parameters(): {
            [key: string]: string;
        };
        set parameters(value: {
            [key: string]: string;
        });
        resetParameters(): void;
        get parametersInput(): {
            [key: string]: string;
        } | undefined;
        private _storedAsSubDirectories?;
        get storedAsSubDirectories(): boolean | cdktn.IResolvable;
        set storedAsSubDirectories(value: boolean | cdktn.IResolvable);
        resetStoredAsSubDirectories(): void;
        get storedAsSubDirectoriesInput(): boolean | cdktn.IResolvable | undefined;
        private _columns;
        get columns(): ColumnsPropertyList;
        putColumns(value: ColumnsProperty[] | cdktn.IResolvable): void;
        resetColumns(): void;
        get columnsInput(): cdktn.IResolvable | ColumnsProperty[] | undefined;
        private _serDeInfo;
        get serDeInfo(): SerDeInfoPropertyOutputReference;
        putSerDeInfo(value: SerDeInfoProperty): void;
        resetSerDeInfo(): void;
        get serDeInfoInput(): SerDeInfoProperty | undefined;
        private _skewedInfo;
        get skewedInfo(): SkewedInfoPropertyOutputReference;
        putSkewedInfo(value: SkewedInfoProperty): void;
        resetSkewedInfo(): void;
        get skewedInfoInput(): SkewedInfoProperty | undefined;
        private _sortColumns;
        get sortColumns(): SortColumnsPropertyList;
        putSortColumns(value: SortColumnsProperty[] | cdktn.IResolvable): void;
        resetSortColumns(): void;
        get sortColumnsInput(): cdktn.IResolvable | SortColumnsProperty[] | undefined;
    }
}
