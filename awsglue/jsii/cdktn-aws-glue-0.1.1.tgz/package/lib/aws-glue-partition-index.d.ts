import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsGluePartitionIndexConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_partition_index#catalog_id AwsGluePartitionIndex#catalog_id}
    */
    readonly catalogId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_partition_index#database_name AwsGluePartitionIndex#database_name}
    */
    readonly databaseName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_partition_index#id AwsGluePartitionIndex#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_partition_index#region AwsGluePartitionIndex#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_partition_index#table_name AwsGluePartitionIndex#table_name}
    */
    readonly tableName: string;
    /**
    * partition_index block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_partition_index#partition_index AwsGluePartitionIndex#partition_index}
    */
    readonly partitionIndex: AwsGluePartitionIndex.PartitionIndexProperty;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_partition_index#timeouts AwsGluePartitionIndex#timeouts}
    */
    readonly timeouts?: AwsGluePartitionIndex.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_partition_index aws_glue_partition_index}
*/
export declare class AwsGluePartitionIndex extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_glue_partition_index";
    /**
    * Generates CDKTN code for importing a AwsGluePartitionIndex resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsGluePartitionIndex to import
    * @param importFromId The id of the existing AwsGluePartitionIndex that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_partition_index#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsGluePartitionIndex to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_partition_index aws_glue_partition_index} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsGluePartitionIndexConfig
    */
    constructor(scope: Construct, id: string, config: AwsGluePartitionIndexConfig);
    private _catalogId?;
    get catalogId(): string;
    set catalogId(value: string);
    resetCatalogId(): void;
    get catalogIdInput(): string | undefined;
    private _databaseName?;
    get databaseName(): string;
    set databaseName(value: string);
    get databaseNameInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tableName?;
    get tableName(): string;
    set tableName(value: string);
    get tableNameInput(): string | undefined;
    private _partitionIndex;
    get partitionIndex(): AwsGluePartitionIndex.PartitionIndexPropertyOutputReference;
    putPartitionIndex(value: AwsGluePartitionIndex.PartitionIndexProperty): void;
    get partitionIndexInput(): AwsGluePartitionIndex.PartitionIndexProperty | undefined;
    private _timeouts;
    get timeouts(): AwsGluePartitionIndex.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsGluePartitionIndex.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsGluePartitionIndex.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsGluePartitionIndexPartitionIndexPropertyToTerraform(struct?: AwsGluePartitionIndex.PartitionIndexPropertyOutputReference | AwsGluePartitionIndex.PartitionIndexProperty): any;
export declare function awsGluePartitionIndexPartitionIndexPropertyToHclTerraform(struct?: AwsGluePartitionIndex.PartitionIndexPropertyOutputReference | AwsGluePartitionIndex.PartitionIndexProperty): any;
export declare function awsGluePartitionIndexTimeoutsPropertyToTerraform(struct?: AwsGluePartitionIndex.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsGluePartitionIndexTimeoutsPropertyToHclTerraform(struct?: AwsGluePartitionIndex.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsGluePartitionIndex {
    interface PartitionIndexProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_partition_index#index_name AwsGluePartitionIndex#index_name}
        */
        readonly indexName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_partition_index#keys AwsGluePartitionIndex#keys}
        */
        readonly keys?: string[];
    }
    class PartitionIndexPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): PartitionIndexProperty | undefined;
        set internalValue(value: PartitionIndexProperty | undefined);
        private _indexName?;
        get indexName(): string;
        set indexName(value: string);
        resetIndexName(): void;
        get indexNameInput(): string | undefined;
        get indexStatus(): string;
        private _keys?;
        get keys(): string[];
        set keys(value: string[]);
        resetKeys(): void;
        get keysInput(): string[] | undefined;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_partition_index#create AwsGluePartitionIndex#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_partition_index#delete AwsGluePartitionIndex#delete}
        */
        readonly delete?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
    }
}
