import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsGlueConnectionConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/glue_connection#id DataAwsGlueConnection#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/glue_connection#region DataAwsGlueConnection#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/glue_connection#tags DataAwsGlueConnection#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/glue_connection aws_glue_connection}
*/
export declare class DataAwsGlueConnection extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_glue_connection";
    /**
    * Generates CDKTN code for importing a DataAwsGlueConnection resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsGlueConnection to import
    * @param importFromId The id of the existing DataAwsGlueConnection that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/glue_connection#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsGlueConnection to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/glue_connection aws_glue_connection} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsGlueConnectionConfig
    */
    constructor(scope: Construct, id: string, config: DataAwsGlueConnectionConfig);
    get arn(): string;
    private _athenaProperties;
    get athenaProperties(): cdktn.StringMap;
    private _authenticationConfiguration;
    get authenticationConfiguration(): DataAwsGlueConnection.AuthenticationConfigurationPropertyList;
    get catalogId(): string;
    private _connectionProperties;
    get connectionProperties(): cdktn.StringMap;
    get connectionType(): string;
    get description(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    get matchCriteria(): string[];
    get name(): string;
    private _physicalConnectionRequirements;
    get physicalConnectionRequirements(): DataAwsGlueConnection.PhysicalConnectionRequirementsPropertyList;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataAwsGlueConnectionBasicAuthenticationCredentialsPropertyToTerraform(struct?: DataAwsGlueConnection.BasicAuthenticationCredentialsProperty): any;
export declare function dataAwsGlueConnectionBasicAuthenticationCredentialsPropertyToHclTerraform(struct?: DataAwsGlueConnection.BasicAuthenticationCredentialsProperty): any;
export declare function dataAwsGlueConnectionAuthorizationCodePropertiesPropertyToTerraform(struct?: DataAwsGlueConnection.AuthorizationCodePropertiesProperty): any;
export declare function dataAwsGlueConnectionAuthorizationCodePropertiesPropertyToHclTerraform(struct?: DataAwsGlueConnection.AuthorizationCodePropertiesProperty): any;
export declare function dataAwsGlueConnectionOauth2ClientApplicationPropertyToTerraform(struct?: DataAwsGlueConnection.Oauth2ClientApplicationProperty): any;
export declare function dataAwsGlueConnectionOauth2ClientApplicationPropertyToHclTerraform(struct?: DataAwsGlueConnection.Oauth2ClientApplicationProperty): any;
export declare function dataAwsGlueConnectionOauth2CredentialsPropertyToTerraform(struct?: DataAwsGlueConnection.Oauth2CredentialsProperty): any;
export declare function dataAwsGlueConnectionOauth2CredentialsPropertyToHclTerraform(struct?: DataAwsGlueConnection.Oauth2CredentialsProperty): any;
export declare function dataAwsGlueConnectionOauth2PropertiesPropertyToTerraform(struct?: DataAwsGlueConnection.Oauth2PropertiesProperty): any;
export declare function dataAwsGlueConnectionOauth2PropertiesPropertyToHclTerraform(struct?: DataAwsGlueConnection.Oauth2PropertiesProperty): any;
export declare function dataAwsGlueConnectionAuthenticationConfigurationPropertyToTerraform(struct?: DataAwsGlueConnection.AuthenticationConfigurationProperty): any;
export declare function dataAwsGlueConnectionAuthenticationConfigurationPropertyToHclTerraform(struct?: DataAwsGlueConnection.AuthenticationConfigurationProperty): any;
export declare function dataAwsGlueConnectionPhysicalConnectionRequirementsPropertyToTerraform(struct?: DataAwsGlueConnection.PhysicalConnectionRequirementsProperty): any;
export declare function dataAwsGlueConnectionPhysicalConnectionRequirementsPropertyToHclTerraform(struct?: DataAwsGlueConnection.PhysicalConnectionRequirementsProperty): any;
export declare namespace DataAwsGlueConnection {
    interface BasicAuthenticationCredentialsProperty {
    }
    class BasicAuthenticationCredentialsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): BasicAuthenticationCredentialsProperty | undefined;
        set internalValue(value: BasicAuthenticationCredentialsProperty | undefined);
        get password(): string;
        get username(): string;
    }
    class BasicAuthenticationCredentialsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): BasicAuthenticationCredentialsPropertyOutputReference;
    }
    interface AuthorizationCodePropertiesProperty {
    }
    class AuthorizationCodePropertiesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AuthorizationCodePropertiesProperty | undefined;
        set internalValue(value: AuthorizationCodePropertiesProperty | undefined);
        get authorizationCode(): string;
        get redirectUri(): string;
    }
    class AuthorizationCodePropertiesPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AuthorizationCodePropertiesPropertyOutputReference;
    }
    interface Oauth2ClientApplicationProperty {
    }
    class Oauth2ClientApplicationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): Oauth2ClientApplicationProperty | undefined;
        set internalValue(value: Oauth2ClientApplicationProperty | undefined);
        get awsManagedClientApplicationReference(): string;
        get userManagedClientApplicationClientId(): string;
    }
    class Oauth2ClientApplicationPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): Oauth2ClientApplicationPropertyOutputReference;
    }
    interface Oauth2CredentialsProperty {
    }
    class Oauth2CredentialsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): Oauth2CredentialsProperty | undefined;
        set internalValue(value: Oauth2CredentialsProperty | undefined);
        get accessToken(): string;
        get jwtToken(): string;
        get refreshToken(): string;
        get userManagedClientApplicationClientSecret(): string;
    }
    class Oauth2CredentialsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): Oauth2CredentialsPropertyOutputReference;
    }
    interface Oauth2PropertiesProperty {
    }
    class Oauth2PropertiesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): Oauth2PropertiesProperty | undefined;
        set internalValue(value: Oauth2PropertiesProperty | undefined);
        private _authorizationCodeProperties;
        get authorizationCodeProperties(): AuthorizationCodePropertiesPropertyList;
        private _oauth2ClientApplication;
        get oauth2ClientApplication(): Oauth2ClientApplicationPropertyList;
        private _oauth2Credentials;
        get oauth2Credentials(): Oauth2CredentialsPropertyList;
        get oauth2GrantType(): string;
        get tokenUrl(): string;
        private _tokenUrlParametersMap;
        get tokenUrlParametersMap(): cdktn.StringMap;
    }
    class Oauth2PropertiesPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): Oauth2PropertiesPropertyOutputReference;
    }
    interface AuthenticationConfigurationProperty {
    }
    class AuthenticationConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AuthenticationConfigurationProperty | undefined;
        set internalValue(value: AuthenticationConfigurationProperty | undefined);
        get authenticationType(): string;
        private _basicAuthenticationCredentials;
        get basicAuthenticationCredentials(): BasicAuthenticationCredentialsPropertyList;
        private _customAuthenticationCredentials;
        get customAuthenticationCredentials(): cdktn.StringMap;
        get kmsKeyArn(): string;
        private _oauth2Properties;
        get oauth2Properties(): Oauth2PropertiesPropertyList;
        get secretArn(): string;
    }
    class AuthenticationConfigurationPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AuthenticationConfigurationPropertyOutputReference;
    }
    interface PhysicalConnectionRequirementsProperty {
    }
    class PhysicalConnectionRequirementsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): PhysicalConnectionRequirementsProperty | undefined;
        set internalValue(value: PhysicalConnectionRequirementsProperty | undefined);
        get availabilityZone(): string;
        get securityGroupIdList(): string[];
        get subnetId(): string;
    }
    class PhysicalConnectionRequirementsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): PhysicalConnectionRequirementsPropertyOutputReference;
    }
}
