import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsGlueClassifierConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_classifier#id AwsGlueClassifier#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_classifier#name AwsGlueClassifier#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_classifier#region AwsGlueClassifier#region}
    */
    readonly region?: string;
    /**
    * csv_classifier block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_classifier#csv_classifier AwsGlueClassifier#csv_classifier}
    */
    readonly csvClassifier?: AwsGlueClassifier.CsvClassifierProperty;
    /**
    * grok_classifier block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_classifier#grok_classifier AwsGlueClassifier#grok_classifier}
    */
    readonly grokClassifier?: AwsGlueClassifier.GrokClassifierProperty;
    /**
    * json_classifier block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_classifier#json_classifier AwsGlueClassifier#json_classifier}
    */
    readonly jsonClassifier?: AwsGlueClassifier.JsonClassifierProperty;
    /**
    * xml_classifier block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_classifier#xml_classifier AwsGlueClassifier#xml_classifier}
    */
    readonly xmlClassifier?: AwsGlueClassifier.XmlClassifierProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_classifier aws_glue_classifier}
*/
export declare class AwsGlueClassifier extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_glue_classifier";
    /**
    * Generates CDKTN code for importing a AwsGlueClassifier resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsGlueClassifier to import
    * @param importFromId The id of the existing AwsGlueClassifier that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_classifier#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsGlueClassifier to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_classifier aws_glue_classifier} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsGlueClassifierConfig
    */
    constructor(scope: Construct, id: string, config: AwsGlueClassifierConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _csvClassifier;
    get csvClassifier(): AwsGlueClassifier.CsvClassifierPropertyOutputReference;
    putCsvClassifier(value: AwsGlueClassifier.CsvClassifierProperty): void;
    resetCsvClassifier(): void;
    get csvClassifierInput(): AwsGlueClassifier.CsvClassifierProperty | undefined;
    private _grokClassifier;
    get grokClassifier(): AwsGlueClassifier.GrokClassifierPropertyOutputReference;
    putGrokClassifier(value: AwsGlueClassifier.GrokClassifierProperty): void;
    resetGrokClassifier(): void;
    get grokClassifierInput(): AwsGlueClassifier.GrokClassifierProperty | undefined;
    private _jsonClassifier;
    get jsonClassifier(): AwsGlueClassifier.JsonClassifierPropertyOutputReference;
    putJsonClassifier(value: AwsGlueClassifier.JsonClassifierProperty): void;
    resetJsonClassifier(): void;
    get jsonClassifierInput(): AwsGlueClassifier.JsonClassifierProperty | undefined;
    private _xmlClassifier;
    get xmlClassifier(): AwsGlueClassifier.XmlClassifierPropertyOutputReference;
    putXmlClassifier(value: AwsGlueClassifier.XmlClassifierProperty): void;
    resetXmlClassifier(): void;
    get xmlClassifierInput(): AwsGlueClassifier.XmlClassifierProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsGlueClassifierCsvClassifierPropertyToTerraform(struct?: AwsGlueClassifier.CsvClassifierPropertyOutputReference | AwsGlueClassifier.CsvClassifierProperty): any;
export declare function awsGlueClassifierCsvClassifierPropertyToHclTerraform(struct?: AwsGlueClassifier.CsvClassifierPropertyOutputReference | AwsGlueClassifier.CsvClassifierProperty): any;
export declare function awsGlueClassifierGrokClassifierPropertyToTerraform(struct?: AwsGlueClassifier.GrokClassifierPropertyOutputReference | AwsGlueClassifier.GrokClassifierProperty): any;
export declare function awsGlueClassifierGrokClassifierPropertyToHclTerraform(struct?: AwsGlueClassifier.GrokClassifierPropertyOutputReference | AwsGlueClassifier.GrokClassifierProperty): any;
export declare function awsGlueClassifierJsonClassifierPropertyToTerraform(struct?: AwsGlueClassifier.JsonClassifierPropertyOutputReference | AwsGlueClassifier.JsonClassifierProperty): any;
export declare function awsGlueClassifierJsonClassifierPropertyToHclTerraform(struct?: AwsGlueClassifier.JsonClassifierPropertyOutputReference | AwsGlueClassifier.JsonClassifierProperty): any;
export declare function awsGlueClassifierXmlClassifierPropertyToTerraform(struct?: AwsGlueClassifier.XmlClassifierPropertyOutputReference | AwsGlueClassifier.XmlClassifierProperty): any;
export declare function awsGlueClassifierXmlClassifierPropertyToHclTerraform(struct?: AwsGlueClassifier.XmlClassifierPropertyOutputReference | AwsGlueClassifier.XmlClassifierProperty): any;
export declare namespace AwsGlueClassifier {
    interface CsvClassifierProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_classifier#allow_single_column AwsGlueClassifier#allow_single_column}
        */
        readonly allowSingleColumn?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_classifier#contains_header AwsGlueClassifier#contains_header}
        */
        readonly containsHeader?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_classifier#custom_datatype_configured AwsGlueClassifier#custom_datatype_configured}
        */
        readonly customDatatypeConfigured?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_classifier#custom_datatypes AwsGlueClassifier#custom_datatypes}
        */
        readonly customDatatypes?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_classifier#delimiter AwsGlueClassifier#delimiter}
        */
        readonly delimiter?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_classifier#disable_value_trimming AwsGlueClassifier#disable_value_trimming}
        */
        readonly disableValueTrimming?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_classifier#header AwsGlueClassifier#header}
        */
        readonly header?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_classifier#quote_symbol AwsGlueClassifier#quote_symbol}
        */
        readonly quoteSymbol?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_classifier#serde AwsGlueClassifier#serde}
        */
        readonly serde?: string;
    }
    class CsvClassifierPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CsvClassifierProperty | undefined;
        set internalValue(value: CsvClassifierProperty | undefined);
        private _allowSingleColumn?;
        get allowSingleColumn(): boolean | cdktn.IResolvable;
        set allowSingleColumn(value: boolean | cdktn.IResolvable);
        resetAllowSingleColumn(): void;
        get allowSingleColumnInput(): boolean | cdktn.IResolvable | undefined;
        private _containsHeader?;
        get containsHeader(): string;
        set containsHeader(value: string);
        resetContainsHeader(): void;
        get containsHeaderInput(): string | undefined;
        private _customDatatypeConfigured?;
        get customDatatypeConfigured(): boolean | cdktn.IResolvable;
        set customDatatypeConfigured(value: boolean | cdktn.IResolvable);
        resetCustomDatatypeConfigured(): void;
        get customDatatypeConfiguredInput(): boolean | cdktn.IResolvable | undefined;
        private _customDatatypes?;
        get customDatatypes(): string[];
        set customDatatypes(value: string[]);
        resetCustomDatatypes(): void;
        get customDatatypesInput(): string[] | undefined;
        private _delimiter?;
        get delimiter(): string;
        set delimiter(value: string);
        resetDelimiter(): void;
        get delimiterInput(): string | undefined;
        private _disableValueTrimming?;
        get disableValueTrimming(): boolean | cdktn.IResolvable;
        set disableValueTrimming(value: boolean | cdktn.IResolvable);
        resetDisableValueTrimming(): void;
        get disableValueTrimmingInput(): boolean | cdktn.IResolvable | undefined;
        private _header?;
        get header(): string[];
        set header(value: string[]);
        resetHeader(): void;
        get headerInput(): string[] | undefined;
        private _quoteSymbol?;
        get quoteSymbol(): string;
        set quoteSymbol(value: string);
        resetQuoteSymbol(): void;
        get quoteSymbolInput(): string | undefined;
        private _serde?;
        get serde(): string;
        set serde(value: string);
        resetSerde(): void;
        get serdeInput(): string | undefined;
    }
    interface GrokClassifierProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_classifier#classification AwsGlueClassifier#classification}
        */
        readonly classification: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_classifier#custom_patterns AwsGlueClassifier#custom_patterns}
        */
        readonly customPatterns?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_classifier#grok_pattern AwsGlueClassifier#grok_pattern}
        */
        readonly grokPattern: string;
    }
    class GrokClassifierPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): GrokClassifierProperty | undefined;
        set internalValue(value: GrokClassifierProperty | undefined);
        private _classification?;
        get classification(): string;
        set classification(value: string);
        get classificationInput(): string | undefined;
        private _customPatterns?;
        get customPatterns(): string;
        set customPatterns(value: string);
        resetCustomPatterns(): void;
        get customPatternsInput(): string | undefined;
        private _grokPattern?;
        get grokPattern(): string;
        set grokPattern(value: string);
        get grokPatternInput(): string | undefined;
    }
    interface JsonClassifierProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_classifier#json_path AwsGlueClassifier#json_path}
        */
        readonly jsonPath: string;
    }
    class JsonClassifierPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): JsonClassifierProperty | undefined;
        set internalValue(value: JsonClassifierProperty | undefined);
        private _jsonPath?;
        get jsonPath(): string;
        set jsonPath(value: string);
        get jsonPathInput(): string | undefined;
    }
    interface XmlClassifierProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_classifier#classification AwsGlueClassifier#classification}
        */
        readonly classification: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_classifier#row_tag AwsGlueClassifier#row_tag}
        */
        readonly rowTag: string;
    }
    class XmlClassifierPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): XmlClassifierProperty | undefined;
        set internalValue(value: XmlClassifierProperty | undefined);
        private _classification?;
        get classification(): string;
        set classification(value: string);
        get classificationInput(): string | undefined;
        private _rowTag?;
        get rowTag(): string;
        set rowTag(value: string);
        get rowTagInput(): string | undefined;
    }
}
