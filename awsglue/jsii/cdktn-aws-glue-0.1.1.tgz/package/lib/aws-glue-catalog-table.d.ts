import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsGlueCatalogTableConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#catalog_id AwsGlueCatalogTable#catalog_id}
    */
    readonly catalogId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#database_name AwsGlueCatalogTable#database_name}
    */
    readonly databaseName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#description AwsGlueCatalogTable#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#id AwsGlueCatalogTable#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#name AwsGlueCatalogTable#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#owner AwsGlueCatalogTable#owner}
    */
    readonly owner?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#parameters AwsGlueCatalogTable#parameters}
    */
    readonly parameters?: {
        [key: string]: string;
    };
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#region AwsGlueCatalogTable#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#retention AwsGlueCatalogTable#retention}
    */
    readonly retention?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#table_type AwsGlueCatalogTable#table_type}
    */
    readonly tableType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#view_expanded_text AwsGlueCatalogTable#view_expanded_text}
    */
    readonly viewExpandedText?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#view_original_text AwsGlueCatalogTable#view_original_text}
    */
    readonly viewOriginalText?: string;
    /**
    * open_table_format_input block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#open_table_format_input AwsGlueCatalogTable#open_table_format_input}
    */
    readonly openTableFormatInput?: AwsGlueCatalogTable.OpenTableFormatInputProperty;
    /**
    * partition_index block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#partition_index AwsGlueCatalogTable#partition_index}
    */
    readonly partitionIndex?: AwsGlueCatalogTable.PartitionIndexProperty[] | cdktn.IResolvable;
    /**
    * partition_keys block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#partition_keys AwsGlueCatalogTable#partition_keys}
    */
    readonly partitionKeys?: AwsGlueCatalogTable.PartitionKeysProperty[] | cdktn.IResolvable;
    /**
    * storage_descriptor block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#storage_descriptor AwsGlueCatalogTable#storage_descriptor}
    */
    readonly storageDescriptor?: AwsGlueCatalogTable.StorageDescriptorProperty;
    /**
    * target_table block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#target_table AwsGlueCatalogTable#target_table}
    */
    readonly targetTable?: AwsGlueCatalogTable.TargetTableProperty;
    /**
    * view_definition block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#view_definition AwsGlueCatalogTable#view_definition}
    */
    readonly viewDefinition?: AwsGlueCatalogTable.ViewDefinitionProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table aws_glue_catalog_table}
*/
export declare class AwsGlueCatalogTable extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_glue_catalog_table";
    /**
    * Generates CDKTN code for importing a AwsGlueCatalogTable resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsGlueCatalogTable to import
    * @param importFromId The id of the existing AwsGlueCatalogTable that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsGlueCatalogTable to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table aws_glue_catalog_table} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsGlueCatalogTableConfig
    */
    constructor(scope: Construct, id: string, config: AwsGlueCatalogTableConfig);
    get arn(): string;
    private _catalogId?;
    get catalogId(): string;
    set catalogId(value: string);
    resetCatalogId(): void;
    get catalogIdInput(): string | undefined;
    private _databaseName?;
    get databaseName(): string;
    set databaseName(value: string);
    get databaseNameInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _owner?;
    get owner(): string;
    set owner(value: string);
    resetOwner(): void;
    get ownerInput(): string | undefined;
    private _parameters?;
    get parameters(): {
        [key: string]: string;
    };
    set parameters(value: {
        [key: string]: string;
    });
    resetParameters(): void;
    get parametersInput(): {
        [key: string]: string;
    } | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _retention?;
    get retention(): number;
    set retention(value: number);
    resetRetention(): void;
    get retentionInput(): number | undefined;
    private _tableType?;
    get tableType(): string;
    set tableType(value: string);
    resetTableType(): void;
    get tableTypeInput(): string | undefined;
    private _viewExpandedText?;
    get viewExpandedText(): string;
    set viewExpandedText(value: string);
    resetViewExpandedText(): void;
    get viewExpandedTextInput(): string | undefined;
    private _viewOriginalText?;
    get viewOriginalText(): string;
    set viewOriginalText(value: string);
    resetViewOriginalText(): void;
    get viewOriginalTextInput(): string | undefined;
    private _openTableFormatInput;
    get openTableFormatInput(): AwsGlueCatalogTable.OpenTableFormatInputPropertyOutputReference;
    putOpenTableFormatInput(value: AwsGlueCatalogTable.OpenTableFormatInputProperty): void;
    resetOpenTableFormatInput(): void;
    get openTableFormatInputInput(): AwsGlueCatalogTable.OpenTableFormatInputProperty | undefined;
    private _partitionIndex;
    get partitionIndex(): AwsGlueCatalogTable.PartitionIndexPropertyList;
    putPartitionIndex(value: AwsGlueCatalogTable.PartitionIndexProperty[] | cdktn.IResolvable): void;
    resetPartitionIndex(): void;
    get partitionIndexInput(): cdktn.IResolvable | AwsGlueCatalogTable.PartitionIndexProperty[] | undefined;
    private _partitionKeys;
    get partitionKeys(): AwsGlueCatalogTable.PartitionKeysPropertyList;
    putPartitionKeys(value: AwsGlueCatalogTable.PartitionKeysProperty[] | cdktn.IResolvable): void;
    resetPartitionKeys(): void;
    get partitionKeysInput(): cdktn.IResolvable | AwsGlueCatalogTable.PartitionKeysProperty[] | undefined;
    private _storageDescriptor;
    get storageDescriptor(): AwsGlueCatalogTable.StorageDescriptorPropertyOutputReference;
    putStorageDescriptor(value: AwsGlueCatalogTable.StorageDescriptorProperty): void;
    resetStorageDescriptor(): void;
    get storageDescriptorInput(): AwsGlueCatalogTable.StorageDescriptorProperty | undefined;
    private _targetTable;
    get targetTable(): AwsGlueCatalogTable.TargetTablePropertyOutputReference;
    putTargetTable(value: AwsGlueCatalogTable.TargetTableProperty): void;
    resetTargetTable(): void;
    get targetTableInput(): AwsGlueCatalogTable.TargetTableProperty | undefined;
    private _viewDefinition;
    get viewDefinition(): AwsGlueCatalogTable.ViewDefinitionPropertyOutputReference;
    putViewDefinition(value: AwsGlueCatalogTable.ViewDefinitionProperty): void;
    resetViewDefinition(): void;
    get viewDefinitionInput(): AwsGlueCatalogTable.ViewDefinitionProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsGlueCatalogTableOpenTableFormatInputIcebergInputIcebergTableInputPartitionSpecFieldsPropertyToTerraform(struct?: AwsGlueCatalogTable.OpenTableFormatInputIcebergInputIcebergTableInputPartitionSpecFieldsProperty | cdktn.IResolvable): any;
export declare function awsGlueCatalogTableOpenTableFormatInputIcebergInputIcebergTableInputPartitionSpecFieldsPropertyToHclTerraform(struct?: AwsGlueCatalogTable.OpenTableFormatInputIcebergInputIcebergTableInputPartitionSpecFieldsProperty | cdktn.IResolvable): any;
export declare function awsGlueCatalogTablePartitionSpecPropertyToTerraform(struct?: AwsGlueCatalogTable.PartitionSpecPropertyOutputReference | AwsGlueCatalogTable.PartitionSpecProperty): any;
export declare function awsGlueCatalogTablePartitionSpecPropertyToHclTerraform(struct?: AwsGlueCatalogTable.PartitionSpecPropertyOutputReference | AwsGlueCatalogTable.PartitionSpecProperty): any;
export declare function awsGlueCatalogTableOpenTableFormatInputIcebergInputIcebergTableInputSchemaFieldsPropertyToTerraform(struct?: AwsGlueCatalogTable.OpenTableFormatInputIcebergInputIcebergTableInputSchemaFieldsProperty | cdktn.IResolvable): any;
export declare function awsGlueCatalogTableOpenTableFormatInputIcebergInputIcebergTableInputSchemaFieldsPropertyToHclTerraform(struct?: AwsGlueCatalogTable.OpenTableFormatInputIcebergInputIcebergTableInputSchemaFieldsProperty | cdktn.IResolvable): any;
export declare function awsGlueCatalogTableSchemaPropertyToTerraform(struct?: AwsGlueCatalogTable.SchemaPropertyOutputReference | AwsGlueCatalogTable.SchemaProperty): any;
export declare function awsGlueCatalogTableSchemaPropertyToHclTerraform(struct?: AwsGlueCatalogTable.SchemaPropertyOutputReference | AwsGlueCatalogTable.SchemaProperty): any;
export declare function awsGlueCatalogTableOpenTableFormatInputIcebergInputIcebergTableInputSortOrderFieldsPropertyToTerraform(struct?: AwsGlueCatalogTable.OpenTableFormatInputIcebergInputIcebergTableInputSortOrderFieldsProperty | cdktn.IResolvable): any;
export declare function awsGlueCatalogTableOpenTableFormatInputIcebergInputIcebergTableInputSortOrderFieldsPropertyToHclTerraform(struct?: AwsGlueCatalogTable.OpenTableFormatInputIcebergInputIcebergTableInputSortOrderFieldsProperty | cdktn.IResolvable): any;
export declare function awsGlueCatalogTableSortOrderPropertyToTerraform(struct?: AwsGlueCatalogTable.SortOrderPropertyOutputReference | AwsGlueCatalogTable.SortOrderProperty): any;
export declare function awsGlueCatalogTableSortOrderPropertyToHclTerraform(struct?: AwsGlueCatalogTable.SortOrderPropertyOutputReference | AwsGlueCatalogTable.SortOrderProperty): any;
export declare function awsGlueCatalogTableIcebergTableInputPropertyToTerraform(struct?: AwsGlueCatalogTable.IcebergTableInputPropertyOutputReference | AwsGlueCatalogTable.IcebergTableInputProperty): any;
export declare function awsGlueCatalogTableIcebergTableInputPropertyToHclTerraform(struct?: AwsGlueCatalogTable.IcebergTableInputPropertyOutputReference | AwsGlueCatalogTable.IcebergTableInputProperty): any;
export declare function awsGlueCatalogTableIcebergInputPropertyToTerraform(struct?: AwsGlueCatalogTable.IcebergInputPropertyOutputReference | AwsGlueCatalogTable.IcebergInputProperty): any;
export declare function awsGlueCatalogTableIcebergInputPropertyToHclTerraform(struct?: AwsGlueCatalogTable.IcebergInputPropertyOutputReference | AwsGlueCatalogTable.IcebergInputProperty): any;
export declare function awsGlueCatalogTableOpenTableFormatInputPropertyToTerraform(struct?: AwsGlueCatalogTable.OpenTableFormatInputPropertyOutputReference | AwsGlueCatalogTable.OpenTableFormatInputProperty): any;
export declare function awsGlueCatalogTableOpenTableFormatInputPropertyToHclTerraform(struct?: AwsGlueCatalogTable.OpenTableFormatInputPropertyOutputReference | AwsGlueCatalogTable.OpenTableFormatInputProperty): any;
export declare function awsGlueCatalogTablePartitionIndexPropertyToTerraform(struct?: AwsGlueCatalogTable.PartitionIndexProperty | cdktn.IResolvable): any;
export declare function awsGlueCatalogTablePartitionIndexPropertyToHclTerraform(struct?: AwsGlueCatalogTable.PartitionIndexProperty | cdktn.IResolvable): any;
export declare function awsGlueCatalogTablePartitionKeysPropertyToTerraform(struct?: AwsGlueCatalogTable.PartitionKeysProperty | cdktn.IResolvable): any;
export declare function awsGlueCatalogTablePartitionKeysPropertyToHclTerraform(struct?: AwsGlueCatalogTable.PartitionKeysProperty | cdktn.IResolvable): any;
export declare function awsGlueCatalogTableColumnsPropertyToTerraform(struct?: AwsGlueCatalogTable.ColumnsProperty | cdktn.IResolvable): any;
export declare function awsGlueCatalogTableColumnsPropertyToHclTerraform(struct?: AwsGlueCatalogTable.ColumnsProperty | cdktn.IResolvable): any;
export declare function awsGlueCatalogTableSchemaIdPropertyToTerraform(struct?: AwsGlueCatalogTable.SchemaIdPropertyOutputReference | AwsGlueCatalogTable.SchemaIdProperty): any;
export declare function awsGlueCatalogTableSchemaIdPropertyToHclTerraform(struct?: AwsGlueCatalogTable.SchemaIdPropertyOutputReference | AwsGlueCatalogTable.SchemaIdProperty): any;
export declare function awsGlueCatalogTableSchemaReferencePropertyToTerraform(struct?: AwsGlueCatalogTable.SchemaReferencePropertyOutputReference | AwsGlueCatalogTable.SchemaReferenceProperty): any;
export declare function awsGlueCatalogTableSchemaReferencePropertyToHclTerraform(struct?: AwsGlueCatalogTable.SchemaReferencePropertyOutputReference | AwsGlueCatalogTable.SchemaReferenceProperty): any;
export declare function awsGlueCatalogTableSerDeInfoPropertyToTerraform(struct?: AwsGlueCatalogTable.SerDeInfoPropertyOutputReference | AwsGlueCatalogTable.SerDeInfoProperty): any;
export declare function awsGlueCatalogTableSerDeInfoPropertyToHclTerraform(struct?: AwsGlueCatalogTable.SerDeInfoPropertyOutputReference | AwsGlueCatalogTable.SerDeInfoProperty): any;
export declare function awsGlueCatalogTableSkewedInfoPropertyToTerraform(struct?: AwsGlueCatalogTable.SkewedInfoPropertyOutputReference | AwsGlueCatalogTable.SkewedInfoProperty): any;
export declare function awsGlueCatalogTableSkewedInfoPropertyToHclTerraform(struct?: AwsGlueCatalogTable.SkewedInfoPropertyOutputReference | AwsGlueCatalogTable.SkewedInfoProperty): any;
export declare function awsGlueCatalogTableSortColumnsPropertyToTerraform(struct?: AwsGlueCatalogTable.SortColumnsProperty | cdktn.IResolvable): any;
export declare function awsGlueCatalogTableSortColumnsPropertyToHclTerraform(struct?: AwsGlueCatalogTable.SortColumnsProperty | cdktn.IResolvable): any;
export declare function awsGlueCatalogTableStorageDescriptorPropertyToTerraform(struct?: AwsGlueCatalogTable.StorageDescriptorPropertyOutputReference | AwsGlueCatalogTable.StorageDescriptorProperty): any;
export declare function awsGlueCatalogTableStorageDescriptorPropertyToHclTerraform(struct?: AwsGlueCatalogTable.StorageDescriptorPropertyOutputReference | AwsGlueCatalogTable.StorageDescriptorProperty): any;
export declare function awsGlueCatalogTableTargetTablePropertyToTerraform(struct?: AwsGlueCatalogTable.TargetTablePropertyOutputReference | AwsGlueCatalogTable.TargetTableProperty): any;
export declare function awsGlueCatalogTableTargetTablePropertyToHclTerraform(struct?: AwsGlueCatalogTable.TargetTablePropertyOutputReference | AwsGlueCatalogTable.TargetTableProperty): any;
export declare function awsGlueCatalogTableRepresentationsPropertyToTerraform(struct?: AwsGlueCatalogTable.RepresentationsProperty | cdktn.IResolvable): any;
export declare function awsGlueCatalogTableRepresentationsPropertyToHclTerraform(struct?: AwsGlueCatalogTable.RepresentationsProperty | cdktn.IResolvable): any;
export declare function awsGlueCatalogTableViewDefinitionPropertyToTerraform(struct?: AwsGlueCatalogTable.ViewDefinitionPropertyOutputReference | AwsGlueCatalogTable.ViewDefinitionProperty): any;
export declare function awsGlueCatalogTableViewDefinitionPropertyToHclTerraform(struct?: AwsGlueCatalogTable.ViewDefinitionPropertyOutputReference | AwsGlueCatalogTable.ViewDefinitionProperty): any;
export declare namespace AwsGlueCatalogTable {
    interface OpenTableFormatInputIcebergInputIcebergTableInputPartitionSpecFieldsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#field_id AwsGlueCatalogTable#field_id}
        */
        readonly fieldId?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#name AwsGlueCatalogTable#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#source_id AwsGlueCatalogTable#source_id}
        */
        readonly sourceId: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#transform AwsGlueCatalogTable#transform}
        */
        readonly transform: string;
    }
    class OpenTableFormatInputIcebergInputIcebergTableInputPartitionSpecFieldsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): OpenTableFormatInputIcebergInputIcebergTableInputPartitionSpecFieldsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: OpenTableFormatInputIcebergInputIcebergTableInputPartitionSpecFieldsProperty | cdktn.IResolvable | undefined);
        private _fieldId?;
        get fieldId(): number;
        set fieldId(value: number);
        resetFieldId(): void;
        get fieldIdInput(): number | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _sourceId?;
        get sourceId(): number;
        set sourceId(value: number);
        get sourceIdInput(): number | undefined;
        private _transform?;
        get transform(): string;
        set transform(value: string);
        get transformInput(): string | undefined;
    }
    class OpenTableFormatInputIcebergInputIcebergTableInputPartitionSpecFieldsPropertyList extends cdktn.ComplexList {
        internalValue?: OpenTableFormatInputIcebergInputIcebergTableInputPartitionSpecFieldsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): OpenTableFormatInputIcebergInputIcebergTableInputPartitionSpecFieldsPropertyOutputReference;
    }
    interface PartitionSpecProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#spec_id AwsGlueCatalogTable#spec_id}
        */
        readonly specId?: number;
        /**
        * fields block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#fields AwsGlueCatalogTable#fields}
        */
        readonly fields: OpenTableFormatInputIcebergInputIcebergTableInputPartitionSpecFieldsProperty[] | cdktn.IResolvable;
    }
    class PartitionSpecPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): PartitionSpecProperty | undefined;
        set internalValue(value: PartitionSpecProperty | undefined);
        private _specId?;
        get specId(): number;
        set specId(value: number);
        resetSpecId(): void;
        get specIdInput(): number | undefined;
        private _fields;
        get fields(): OpenTableFormatInputIcebergInputIcebergTableInputPartitionSpecFieldsPropertyList;
        putFields(value: OpenTableFormatInputIcebergInputIcebergTableInputPartitionSpecFieldsProperty[] | cdktn.IResolvable): void;
        get fieldsInput(): cdktn.IResolvable | OpenTableFormatInputIcebergInputIcebergTableInputPartitionSpecFieldsProperty[] | undefined;
    }
    interface OpenTableFormatInputIcebergInputIcebergTableInputSchemaFieldsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#doc AwsGlueCatalogTable#doc}
        */
        readonly doc?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#id AwsGlueCatalogTable#id}
        *
        * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
        * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
        */
        readonly id: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#initial_default AwsGlueCatalogTable#initial_default}
        */
        readonly initialDefault?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#name AwsGlueCatalogTable#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#required AwsGlueCatalogTable#required}
        */
        readonly required: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#type AwsGlueCatalogTable#type}
        */
        readonly type: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#write_default AwsGlueCatalogTable#write_default}
        */
        readonly writeDefault?: string;
    }
    class OpenTableFormatInputIcebergInputIcebergTableInputSchemaFieldsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): OpenTableFormatInputIcebergInputIcebergTableInputSchemaFieldsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: OpenTableFormatInputIcebergInputIcebergTableInputSchemaFieldsProperty | cdktn.IResolvable | undefined);
        private _doc?;
        get doc(): string;
        set doc(value: string);
        resetDoc(): void;
        get docInput(): string | undefined;
        private _id?;
        get id(): number;
        set id(value: number);
        get idInput(): number | undefined;
        private _initialDefault?;
        get initialDefault(): string;
        set initialDefault(value: string);
        resetInitialDefault(): void;
        get initialDefaultInput(): string | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _required?;
        get required(): boolean | cdktn.IResolvable;
        set required(value: boolean | cdktn.IResolvable);
        get requiredInput(): boolean | cdktn.IResolvable | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
        private _writeDefault?;
        get writeDefault(): string;
        set writeDefault(value: string);
        resetWriteDefault(): void;
        get writeDefaultInput(): string | undefined;
    }
    class OpenTableFormatInputIcebergInputIcebergTableInputSchemaFieldsPropertyList extends cdktn.ComplexList {
        internalValue?: OpenTableFormatInputIcebergInputIcebergTableInputSchemaFieldsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): OpenTableFormatInputIcebergInputIcebergTableInputSchemaFieldsPropertyOutputReference;
    }
    interface SchemaProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#identifier_field_ids AwsGlueCatalogTable#identifier_field_ids}
        */
        readonly identifierFieldIds?: number[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#schema_id AwsGlueCatalogTable#schema_id}
        */
        readonly schemaId?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#type AwsGlueCatalogTable#type}
        */
        readonly type?: string;
        /**
        * fields block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#fields AwsGlueCatalogTable#fields}
        */
        readonly fields: OpenTableFormatInputIcebergInputIcebergTableInputSchemaFieldsProperty[] | cdktn.IResolvable;
    }
    class SchemaPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SchemaProperty | undefined;
        set internalValue(value: SchemaProperty | undefined);
        private _identifierFieldIds?;
        get identifierFieldIds(): number[];
        set identifierFieldIds(value: number[]);
        resetIdentifierFieldIds(): void;
        get identifierFieldIdsInput(): number[] | undefined;
        private _schemaId?;
        get schemaId(): number;
        set schemaId(value: number);
        resetSchemaId(): void;
        get schemaIdInput(): number | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        resetType(): void;
        get typeInput(): string | undefined;
        private _fields;
        get fields(): OpenTableFormatInputIcebergInputIcebergTableInputSchemaFieldsPropertyList;
        putFields(value: OpenTableFormatInputIcebergInputIcebergTableInputSchemaFieldsProperty[] | cdktn.IResolvable): void;
        get fieldsInput(): cdktn.IResolvable | OpenTableFormatInputIcebergInputIcebergTableInputSchemaFieldsProperty[] | undefined;
    }
    interface OpenTableFormatInputIcebergInputIcebergTableInputSortOrderFieldsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#direction AwsGlueCatalogTable#direction}
        */
        readonly direction: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#null_order AwsGlueCatalogTable#null_order}
        */
        readonly nullOrder: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#source_id AwsGlueCatalogTable#source_id}
        */
        readonly sourceId: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#transform AwsGlueCatalogTable#transform}
        */
        readonly transform: string;
    }
    class OpenTableFormatInputIcebergInputIcebergTableInputSortOrderFieldsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): OpenTableFormatInputIcebergInputIcebergTableInputSortOrderFieldsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: OpenTableFormatInputIcebergInputIcebergTableInputSortOrderFieldsProperty | cdktn.IResolvable | undefined);
        private _direction?;
        get direction(): string;
        set direction(value: string);
        get directionInput(): string | undefined;
        private _nullOrder?;
        get nullOrder(): string;
        set nullOrder(value: string);
        get nullOrderInput(): string | undefined;
        private _sourceId?;
        get sourceId(): number;
        set sourceId(value: number);
        get sourceIdInput(): number | undefined;
        private _transform?;
        get transform(): string;
        set transform(value: string);
        get transformInput(): string | undefined;
    }
    class OpenTableFormatInputIcebergInputIcebergTableInputSortOrderFieldsPropertyList extends cdktn.ComplexList {
        internalValue?: OpenTableFormatInputIcebergInputIcebergTableInputSortOrderFieldsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): OpenTableFormatInputIcebergInputIcebergTableInputSortOrderFieldsPropertyOutputReference;
    }
    interface SortOrderProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#order_id AwsGlueCatalogTable#order_id}
        */
        readonly orderId: number;
        /**
        * fields block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#fields AwsGlueCatalogTable#fields}
        */
        readonly fields: OpenTableFormatInputIcebergInputIcebergTableInputSortOrderFieldsProperty[] | cdktn.IResolvable;
    }
    class SortOrderPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SortOrderProperty | undefined;
        set internalValue(value: SortOrderProperty | undefined);
        private _orderId?;
        get orderId(): number;
        set orderId(value: number);
        get orderIdInput(): number | undefined;
        private _fields;
        get fields(): OpenTableFormatInputIcebergInputIcebergTableInputSortOrderFieldsPropertyList;
        putFields(value: OpenTableFormatInputIcebergInputIcebergTableInputSortOrderFieldsProperty[] | cdktn.IResolvable): void;
        get fieldsInput(): cdktn.IResolvable | OpenTableFormatInputIcebergInputIcebergTableInputSortOrderFieldsProperty[] | undefined;
    }
    interface IcebergTableInputProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#location AwsGlueCatalogTable#location}
        */
        readonly location: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#properties AwsGlueCatalogTable#properties}
        */
        readonly properties?: {
            [key: string]: string;
        };
        /**
        * partition_spec block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#partition_spec AwsGlueCatalogTable#partition_spec}
        */
        readonly partitionSpec?: PartitionSpecProperty;
        /**
        * schema block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#schema AwsGlueCatalogTable#schema}
        */
        readonly schema: SchemaProperty;
        /**
        * sort_order block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#sort_order AwsGlueCatalogTable#sort_order}
        */
        readonly sortOrder?: SortOrderProperty;
    }
    class IcebergTableInputPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): IcebergTableInputProperty | undefined;
        set internalValue(value: IcebergTableInputProperty | undefined);
        private _location?;
        get location(): string;
        set location(value: string);
        get locationInput(): string | undefined;
        private _properties?;
        get properties(): {
            [key: string]: string;
        };
        set properties(value: {
            [key: string]: string;
        });
        resetProperties(): void;
        get propertiesInput(): {
            [key: string]: string;
        } | undefined;
        private _partitionSpec;
        get partitionSpec(): PartitionSpecPropertyOutputReference;
        putPartitionSpec(value: PartitionSpecProperty): void;
        resetPartitionSpec(): void;
        get partitionSpecInput(): PartitionSpecProperty | undefined;
        private _schema;
        get schema(): SchemaPropertyOutputReference;
        putSchema(value: SchemaProperty): void;
        get schemaInput(): SchemaProperty | undefined;
        private _sortOrder;
        get sortOrder(): SortOrderPropertyOutputReference;
        putSortOrder(value: SortOrderProperty): void;
        resetSortOrder(): void;
        get sortOrderInput(): SortOrderProperty | undefined;
    }
    interface IcebergInputProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#metadata_operation AwsGlueCatalogTable#metadata_operation}
        */
        readonly metadataOperation: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#version AwsGlueCatalogTable#version}
        */
        readonly version?: string;
        /**
        * iceberg_table_input block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#iceberg_table_input AwsGlueCatalogTable#iceberg_table_input}
        */
        readonly icebergTableInput?: IcebergTableInputProperty;
    }
    class IcebergInputPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): IcebergInputProperty | undefined;
        set internalValue(value: IcebergInputProperty | undefined);
        private _metadataOperation?;
        get metadataOperation(): string;
        set metadataOperation(value: string);
        get metadataOperationInput(): string | undefined;
        private _version?;
        get version(): string;
        set version(value: string);
        resetVersion(): void;
        get versionInput(): string | undefined;
        private _icebergTableInput;
        get icebergTableInput(): IcebergTableInputPropertyOutputReference;
        putIcebergTableInput(value: IcebergTableInputProperty): void;
        resetIcebergTableInput(): void;
        get icebergTableInputInput(): IcebergTableInputProperty | undefined;
    }
    interface OpenTableFormatInputProperty {
        /**
        * iceberg_input block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#iceberg_input AwsGlueCatalogTable#iceberg_input}
        */
        readonly icebergInput: IcebergInputProperty;
    }
    class OpenTableFormatInputPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): OpenTableFormatInputProperty | undefined;
        set internalValue(value: OpenTableFormatInputProperty | undefined);
        private _icebergInput;
        get icebergInput(): IcebergInputPropertyOutputReference;
        putIcebergInput(value: IcebergInputProperty): void;
        get icebergInputInput(): IcebergInputProperty | undefined;
    }
    interface PartitionIndexProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#index_name AwsGlueCatalogTable#index_name}
        */
        readonly indexName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#keys AwsGlueCatalogTable#keys}
        */
        readonly keys: string[];
    }
    class PartitionIndexPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): PartitionIndexProperty | cdktn.IResolvable | undefined;
        set internalValue(value: PartitionIndexProperty | cdktn.IResolvable | undefined);
        private _indexName?;
        get indexName(): string;
        set indexName(value: string);
        get indexNameInput(): string | undefined;
        get indexStatus(): string;
        private _keys?;
        get keys(): string[];
        set keys(value: string[]);
        get keysInput(): string[] | undefined;
    }
    class PartitionIndexPropertyList extends cdktn.ComplexList {
        internalValue?: PartitionIndexProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): PartitionIndexPropertyOutputReference;
    }
    interface PartitionKeysProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#comment AwsGlueCatalogTable#comment}
        */
        readonly comment?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#name AwsGlueCatalogTable#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#parameters AwsGlueCatalogTable#parameters}
        */
        readonly parameters?: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#type AwsGlueCatalogTable#type}
        */
        readonly type?: string;
    }
    class PartitionKeysPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): PartitionKeysProperty | cdktn.IResolvable | undefined;
        set internalValue(value: PartitionKeysProperty | cdktn.IResolvable | undefined);
        private _comment?;
        get comment(): string;
        set comment(value: string);
        resetComment(): void;
        get commentInput(): string | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _parameters?;
        get parameters(): {
            [key: string]: string;
        };
        set parameters(value: {
            [key: string]: string;
        });
        resetParameters(): void;
        get parametersInput(): {
            [key: string]: string;
        } | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        resetType(): void;
        get typeInput(): string | undefined;
    }
    class PartitionKeysPropertyList extends cdktn.ComplexList {
        internalValue?: PartitionKeysProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): PartitionKeysPropertyOutputReference;
    }
    interface ColumnsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#comment AwsGlueCatalogTable#comment}
        */
        readonly comment?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#name AwsGlueCatalogTable#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#parameters AwsGlueCatalogTable#parameters}
        */
        readonly parameters?: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#type AwsGlueCatalogTable#type}
        */
        readonly type?: string;
    }
    class ColumnsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ColumnsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ColumnsProperty | cdktn.IResolvable | undefined);
        private _comment?;
        get comment(): string;
        set comment(value: string);
        resetComment(): void;
        get commentInput(): string | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _parameters?;
        get parameters(): {
            [key: string]: string;
        };
        set parameters(value: {
            [key: string]: string;
        });
        resetParameters(): void;
        get parametersInput(): {
            [key: string]: string;
        } | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        resetType(): void;
        get typeInput(): string | undefined;
    }
    class ColumnsPropertyList extends cdktn.ComplexList {
        internalValue?: ColumnsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ColumnsPropertyOutputReference;
    }
    interface SchemaIdProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#registry_name AwsGlueCatalogTable#registry_name}
        */
        readonly registryName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#schema_arn AwsGlueCatalogTable#schema_arn}
        */
        readonly schemaArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#schema_name AwsGlueCatalogTable#schema_name}
        */
        readonly schemaName?: string;
    }
    class SchemaIdPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SchemaIdProperty | undefined;
        set internalValue(value: SchemaIdProperty | undefined);
        private _registryName?;
        get registryName(): string;
        set registryName(value: string);
        resetRegistryName(): void;
        get registryNameInput(): string | undefined;
        private _schemaArn?;
        get schemaArn(): string;
        set schemaArn(value: string);
        resetSchemaArn(): void;
        get schemaArnInput(): string | undefined;
        private _schemaName?;
        get schemaName(): string;
        set schemaName(value: string);
        resetSchemaName(): void;
        get schemaNameInput(): string | undefined;
    }
    interface SchemaReferenceProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#schema_version_id AwsGlueCatalogTable#schema_version_id}
        */
        readonly schemaVersionId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#schema_version_number AwsGlueCatalogTable#schema_version_number}
        */
        readonly schemaVersionNumber: number;
        /**
        * schema_id block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#schema_id AwsGlueCatalogTable#schema_id}
        */
        readonly schemaId?: SchemaIdProperty;
    }
    class SchemaReferencePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SchemaReferenceProperty | undefined;
        set internalValue(value: SchemaReferenceProperty | undefined);
        private _schemaVersionId?;
        get schemaVersionId(): string;
        set schemaVersionId(value: string);
        resetSchemaVersionId(): void;
        get schemaVersionIdInput(): string | undefined;
        private _schemaVersionNumber?;
        get schemaVersionNumber(): number;
        set schemaVersionNumber(value: number);
        get schemaVersionNumberInput(): number | undefined;
        private _schemaId;
        get schemaId(): SchemaIdPropertyOutputReference;
        putSchemaId(value: SchemaIdProperty): void;
        resetSchemaId(): void;
        get schemaIdInput(): SchemaIdProperty | undefined;
    }
    interface SerDeInfoProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#name AwsGlueCatalogTable#name}
        */
        readonly name?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#parameters AwsGlueCatalogTable#parameters}
        */
        readonly parameters?: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#serialization_library AwsGlueCatalogTable#serialization_library}
        */
        readonly serializationLibrary?: string;
    }
    class SerDeInfoPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SerDeInfoProperty | undefined;
        set internalValue(value: SerDeInfoProperty | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        resetName(): void;
        get nameInput(): string | undefined;
        private _parameters?;
        get parameters(): {
            [key: string]: string;
        };
        set parameters(value: {
            [key: string]: string;
        });
        resetParameters(): void;
        get parametersInput(): {
            [key: string]: string;
        } | undefined;
        private _serializationLibrary?;
        get serializationLibrary(): string;
        set serializationLibrary(value: string);
        resetSerializationLibrary(): void;
        get serializationLibraryInput(): string | undefined;
    }
    interface SkewedInfoProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#skewed_column_names AwsGlueCatalogTable#skewed_column_names}
        */
        readonly skewedColumnNames?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#skewed_column_value_location_maps AwsGlueCatalogTable#skewed_column_value_location_maps}
        */
        readonly skewedColumnValueLocationMaps?: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#skewed_column_values AwsGlueCatalogTable#skewed_column_values}
        */
        readonly skewedColumnValues?: string[];
    }
    class SkewedInfoPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SkewedInfoProperty | undefined;
        set internalValue(value: SkewedInfoProperty | undefined);
        private _skewedColumnNames?;
        get skewedColumnNames(): string[];
        set skewedColumnNames(value: string[]);
        resetSkewedColumnNames(): void;
        get skewedColumnNamesInput(): string[] | undefined;
        private _skewedColumnValueLocationMaps?;
        get skewedColumnValueLocationMaps(): {
            [key: string]: string;
        };
        set skewedColumnValueLocationMaps(value: {
            [key: string]: string;
        });
        resetSkewedColumnValueLocationMaps(): void;
        get skewedColumnValueLocationMapsInput(): {
            [key: string]: string;
        } | undefined;
        private _skewedColumnValues?;
        get skewedColumnValues(): string[];
        set skewedColumnValues(value: string[]);
        resetSkewedColumnValues(): void;
        get skewedColumnValuesInput(): string[] | undefined;
    }
    interface SortColumnsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#column AwsGlueCatalogTable#column}
        */
        readonly column: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#sort_order AwsGlueCatalogTable#sort_order}
        */
        readonly sortOrder: number;
    }
    class SortColumnsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SortColumnsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SortColumnsProperty | cdktn.IResolvable | undefined);
        private _column?;
        get column(): string;
        set column(value: string);
        get columnInput(): string | undefined;
        private _sortOrder?;
        get sortOrder(): number;
        set sortOrder(value: number);
        get sortOrderInput(): number | undefined;
    }
    class SortColumnsPropertyList extends cdktn.ComplexList {
        internalValue?: SortColumnsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SortColumnsPropertyOutputReference;
    }
    interface StorageDescriptorProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#additional_locations AwsGlueCatalogTable#additional_locations}
        */
        readonly additionalLocations?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#bucket_columns AwsGlueCatalogTable#bucket_columns}
        */
        readonly bucketColumns?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#compressed AwsGlueCatalogTable#compressed}
        */
        readonly compressed?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#input_format AwsGlueCatalogTable#input_format}
        */
        readonly inputFormat?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#location AwsGlueCatalogTable#location}
        */
        readonly location?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#number_of_buckets AwsGlueCatalogTable#number_of_buckets}
        */
        readonly numberOfBuckets?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#output_format AwsGlueCatalogTable#output_format}
        */
        readonly outputFormat?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#parameters AwsGlueCatalogTable#parameters}
        */
        readonly parameters?: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#stored_as_sub_directories AwsGlueCatalogTable#stored_as_sub_directories}
        */
        readonly storedAsSubDirectories?: boolean | cdktn.IResolvable;
        /**
        * columns block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#columns AwsGlueCatalogTable#columns}
        */
        readonly columns?: ColumnsProperty[] | cdktn.IResolvable;
        /**
        * schema_reference block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#schema_reference AwsGlueCatalogTable#schema_reference}
        */
        readonly schemaReference?: SchemaReferenceProperty;
        /**
        * ser_de_info block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#ser_de_info AwsGlueCatalogTable#ser_de_info}
        */
        readonly serDeInfo?: SerDeInfoProperty;
        /**
        * skewed_info block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#skewed_info AwsGlueCatalogTable#skewed_info}
        */
        readonly skewedInfo?: SkewedInfoProperty;
        /**
        * sort_columns block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#sort_columns AwsGlueCatalogTable#sort_columns}
        */
        readonly sortColumns?: SortColumnsProperty[] | cdktn.IResolvable;
    }
    class StorageDescriptorPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): StorageDescriptorProperty | undefined;
        set internalValue(value: StorageDescriptorProperty | undefined);
        private _additionalLocations?;
        get additionalLocations(): string[];
        set additionalLocations(value: string[]);
        resetAdditionalLocations(): void;
        get additionalLocationsInput(): string[] | undefined;
        private _bucketColumns?;
        get bucketColumns(): string[];
        set bucketColumns(value: string[]);
        resetBucketColumns(): void;
        get bucketColumnsInput(): string[] | undefined;
        private _compressed?;
        get compressed(): boolean | cdktn.IResolvable;
        set compressed(value: boolean | cdktn.IResolvable);
        resetCompressed(): void;
        get compressedInput(): boolean | cdktn.IResolvable | undefined;
        private _inputFormat?;
        get inputFormat(): string;
        set inputFormat(value: string);
        resetInputFormat(): void;
        get inputFormatInput(): string | undefined;
        private _location?;
        get location(): string;
        set location(value: string);
        resetLocation(): void;
        get locationInput(): string | undefined;
        private _numberOfBuckets?;
        get numberOfBuckets(): number;
        set numberOfBuckets(value: number);
        resetNumberOfBuckets(): void;
        get numberOfBucketsInput(): number | undefined;
        private _outputFormat?;
        get outputFormat(): string;
        set outputFormat(value: string);
        resetOutputFormat(): void;
        get outputFormatInput(): string | undefined;
        private _parameters?;
        get parameters(): {
            [key: string]: string;
        };
        set parameters(value: {
            [key: string]: string;
        });
        resetParameters(): void;
        get parametersInput(): {
            [key: string]: string;
        } | undefined;
        private _storedAsSubDirectories?;
        get storedAsSubDirectories(): boolean | cdktn.IResolvable;
        set storedAsSubDirectories(value: boolean | cdktn.IResolvable);
        resetStoredAsSubDirectories(): void;
        get storedAsSubDirectoriesInput(): boolean | cdktn.IResolvable | undefined;
        private _columns;
        get columns(): ColumnsPropertyList;
        putColumns(value: ColumnsProperty[] | cdktn.IResolvable): void;
        resetColumns(): void;
        get columnsInput(): cdktn.IResolvable | ColumnsProperty[] | undefined;
        private _schemaReference;
        get schemaReference(): SchemaReferencePropertyOutputReference;
        putSchemaReference(value: SchemaReferenceProperty): void;
        resetSchemaReference(): void;
        get schemaReferenceInput(): SchemaReferenceProperty | undefined;
        private _serDeInfo;
        get serDeInfo(): SerDeInfoPropertyOutputReference;
        putSerDeInfo(value: SerDeInfoProperty): void;
        resetSerDeInfo(): void;
        get serDeInfoInput(): SerDeInfoProperty | undefined;
        private _skewedInfo;
        get skewedInfo(): SkewedInfoPropertyOutputReference;
        putSkewedInfo(value: SkewedInfoProperty): void;
        resetSkewedInfo(): void;
        get skewedInfoInput(): SkewedInfoProperty | undefined;
        private _sortColumns;
        get sortColumns(): SortColumnsPropertyList;
        putSortColumns(value: SortColumnsProperty[] | cdktn.IResolvable): void;
        resetSortColumns(): void;
        get sortColumnsInput(): cdktn.IResolvable | SortColumnsProperty[] | undefined;
    }
    interface TargetTableProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#catalog_id AwsGlueCatalogTable#catalog_id}
        */
        readonly catalogId: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#database_name AwsGlueCatalogTable#database_name}
        */
        readonly databaseName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#name AwsGlueCatalogTable#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#region AwsGlueCatalogTable#region}
        */
        readonly region?: string;
    }
    class TargetTablePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TargetTableProperty | undefined;
        set internalValue(value: TargetTableProperty | undefined);
        private _catalogId?;
        get catalogId(): string;
        set catalogId(value: string);
        get catalogIdInput(): string | undefined;
        private _databaseName?;
        get databaseName(): string;
        set databaseName(value: string);
        get databaseNameInput(): string | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _region?;
        get region(): string;
        set region(value: string);
        resetRegion(): void;
        get regionInput(): string | undefined;
    }
    interface RepresentationsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#dialect AwsGlueCatalogTable#dialect}
        */
        readonly dialect?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#dialect_version AwsGlueCatalogTable#dialect_version}
        */
        readonly dialectVersion?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#validation_connection AwsGlueCatalogTable#validation_connection}
        */
        readonly validationConnection?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#view_expanded_text AwsGlueCatalogTable#view_expanded_text}
        */
        readonly viewExpandedText?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#view_original_text AwsGlueCatalogTable#view_original_text}
        */
        readonly viewOriginalText?: string;
    }
    class RepresentationsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RepresentationsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RepresentationsProperty | cdktn.IResolvable | undefined);
        private _dialect?;
        get dialect(): string;
        set dialect(value: string);
        resetDialect(): void;
        get dialectInput(): string | undefined;
        private _dialectVersion?;
        get dialectVersion(): string;
        set dialectVersion(value: string);
        resetDialectVersion(): void;
        get dialectVersionInput(): string | undefined;
        private _validationConnection?;
        get validationConnection(): string;
        set validationConnection(value: string);
        resetValidationConnection(): void;
        get validationConnectionInput(): string | undefined;
        private _viewExpandedText?;
        get viewExpandedText(): string;
        set viewExpandedText(value: string);
        resetViewExpandedText(): void;
        get viewExpandedTextInput(): string | undefined;
        private _viewOriginalText?;
        get viewOriginalText(): string;
        set viewOriginalText(value: string);
        resetViewOriginalText(): void;
        get viewOriginalTextInput(): string | undefined;
    }
    class RepresentationsPropertyList extends cdktn.ComplexList {
        internalValue?: RepresentationsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RepresentationsPropertyOutputReference;
    }
    interface ViewDefinitionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#definer AwsGlueCatalogTable#definer}
        */
        readonly definer?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#is_protected AwsGlueCatalogTable#is_protected}
        */
        readonly isProtected?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#last_refresh_type AwsGlueCatalogTable#last_refresh_type}
        */
        readonly lastRefreshType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#refresh_seconds AwsGlueCatalogTable#refresh_seconds}
        */
        readonly refreshSeconds?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#sub_object_version_ids AwsGlueCatalogTable#sub_object_version_ids}
        */
        readonly subObjectVersionIds?: number[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#sub_objects AwsGlueCatalogTable#sub_objects}
        */
        readonly subObjects?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#view_version_id AwsGlueCatalogTable#view_version_id}
        */
        readonly viewVersionId?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#view_version_token AwsGlueCatalogTable#view_version_token}
        */
        readonly viewVersionToken?: string;
        /**
        * representations block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_catalog_table#representations AwsGlueCatalogTable#representations}
        */
        readonly representations?: RepresentationsProperty[] | cdktn.IResolvable;
    }
    class ViewDefinitionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ViewDefinitionProperty | undefined;
        set internalValue(value: ViewDefinitionProperty | undefined);
        private _definer?;
        get definer(): string;
        set definer(value: string);
        resetDefiner(): void;
        get definerInput(): string | undefined;
        private _isProtected?;
        get isProtected(): boolean | cdktn.IResolvable;
        set isProtected(value: boolean | cdktn.IResolvable);
        resetIsProtected(): void;
        get isProtectedInput(): boolean | cdktn.IResolvable | undefined;
        private _lastRefreshType?;
        get lastRefreshType(): string;
        set lastRefreshType(value: string);
        resetLastRefreshType(): void;
        get lastRefreshTypeInput(): string | undefined;
        private _refreshSeconds?;
        get refreshSeconds(): number;
        set refreshSeconds(value: number);
        resetRefreshSeconds(): void;
        get refreshSecondsInput(): number | undefined;
        private _subObjectVersionIds?;
        get subObjectVersionIds(): number[];
        set subObjectVersionIds(value: number[]);
        resetSubObjectVersionIds(): void;
        get subObjectVersionIdsInput(): number[] | undefined;
        private _subObjects?;
        get subObjects(): string[];
        set subObjects(value: string[]);
        resetSubObjects(): void;
        get subObjectsInput(): string[] | undefined;
        private _viewVersionId?;
        get viewVersionId(): number;
        set viewVersionId(value: number);
        resetViewVersionId(): void;
        get viewVersionIdInput(): number | undefined;
        private _viewVersionToken?;
        get viewVersionToken(): string;
        set viewVersionToken(value: string);
        resetViewVersionToken(): void;
        get viewVersionTokenInput(): string | undefined;
        private _representations;
        get representations(): RepresentationsPropertyList;
        putRepresentations(value: RepresentationsProperty[] | cdktn.IResolvable): void;
        resetRepresentations(): void;
        get representationsInput(): cdktn.IResolvable | RepresentationsProperty[] | undefined;
    }
}
