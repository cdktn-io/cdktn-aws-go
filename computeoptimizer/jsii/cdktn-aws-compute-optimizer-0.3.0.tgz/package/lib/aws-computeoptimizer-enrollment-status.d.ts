import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsEnrollmentStatusConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/computeoptimizer_enrollment_status#include_member_accounts AwsEnrollmentStatus#include_member_accounts}
    */
    readonly includeMemberAccounts?: boolean | cdktn.IResolvable;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/computeoptimizer_enrollment_status#region AwsEnrollmentStatus#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/computeoptimizer_enrollment_status#status AwsEnrollmentStatus#status}
    */
    readonly status: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/computeoptimizer_enrollment_status#timeouts AwsEnrollmentStatus#timeouts}
    */
    readonly timeouts?: AwsEnrollmentStatus.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/computeoptimizer_enrollment_status aws_computeoptimizer_enrollment_status}
*/
export declare class AwsEnrollmentStatus extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_computeoptimizer_enrollment_status";
    /**
    * Generates CDKTN code for importing a AwsEnrollmentStatus resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsEnrollmentStatus to import
    * @param importFromId The id of the existing AwsEnrollmentStatus that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/computeoptimizer_enrollment_status#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsEnrollmentStatus to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/computeoptimizer_enrollment_status aws_computeoptimizer_enrollment_status} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsEnrollmentStatusConfig
    */
    constructor(scope: Construct, id: string, config: AwsEnrollmentStatusConfig);
    get id(): string;
    private _includeMemberAccounts?;
    get includeMemberAccounts(): boolean | cdktn.IResolvable;
    set includeMemberAccounts(value: boolean | cdktn.IResolvable);
    resetIncludeMemberAccounts(): void;
    get includeMemberAccountsInput(): boolean | cdktn.IResolvable | undefined;
    get numberOfMemberAccountsOptedIn(): number;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _status?;
    get status(): string;
    set status(value: string);
    get statusInput(): string | undefined;
    private _timeouts;
    get timeouts(): AwsEnrollmentStatus.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsEnrollmentStatus.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsEnrollmentStatus.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsEnrollmentStatusTimeoutsPropertyToTerraform(struct?: AwsEnrollmentStatus.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsEnrollmentStatusTimeoutsPropertyToHclTerraform(struct?: AwsEnrollmentStatus.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsEnrollmentStatus {
    interface TimeoutsProperty {
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/computeoptimizer_enrollment_status#create AwsEnrollmentStatus#create}
        */
        readonly create?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/computeoptimizer_enrollment_status#update AwsEnrollmentStatus#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
