import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfAppAuthorizationConnectionConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appfabric_app_authorization_connection#app_authorization_arn TfAppAuthorizationConnection#app_authorization_arn}
    */
    readonly appAuthorizationArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appfabric_app_authorization_connection#app_bundle_arn TfAppAuthorizationConnection#app_bundle_arn}
    */
    readonly appBundleArn: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appfabric_app_authorization_connection#region TfAppAuthorizationConnection#region}
    */
    readonly region?: string;
    /**
    * auth_request block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appfabric_app_authorization_connection#auth_request TfAppAuthorizationConnection#auth_request}
    */
    readonly authRequest?: TfAppAuthorizationConnection.AuthRequestProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appfabric_app_authorization_connection#timeouts TfAppAuthorizationConnection#timeouts}
    */
    readonly timeouts?: TfAppAuthorizationConnection.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appfabric_app_authorization_connection aws_appfabric_app_authorization_connection}
*/
export declare class TfAppAuthorizationConnection extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_appfabric_app_authorization_connection";
    /**
    * Generates CDKTN code for importing a TfAppAuthorizationConnection resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfAppAuthorizationConnection to import
    * @param importFromId The id of the existing TfAppAuthorizationConnection that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appfabric_app_authorization_connection#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfAppAuthorizationConnection to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appfabric_app_authorization_connection aws_appfabric_app_authorization_connection} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfAppAuthorizationConnectionConfig
    */
    constructor(scope: Construct, id: string, config: TfAppAuthorizationConnectionConfig);
    get app(): string;
    private _appAuthorizationArn?;
    get appAuthorizationArn(): string;
    set appAuthorizationArn(value: string);
    get appAuthorizationArnInput(): string | undefined;
    private _appBundleArn?;
    get appBundleArn(): string;
    set appBundleArn(value: string);
    get appBundleArnInput(): string | undefined;
    get id(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tenant;
    get tenant(): TfAppAuthorizationConnection.TenantPropertyList;
    private _authRequest;
    get authRequest(): TfAppAuthorizationConnection.AuthRequestPropertyList;
    putAuthRequest(value: TfAppAuthorizationConnection.AuthRequestProperty[] | cdktn.IResolvable): void;
    resetAuthRequest(): void;
    get authRequestInput(): cdktn.IResolvable | TfAppAuthorizationConnection.AuthRequestProperty[] | undefined;
    private _timeouts;
    get timeouts(): TfAppAuthorizationConnection.TimeoutsPropertyOutputReference;
    putTimeouts(value: TfAppAuthorizationConnection.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | TfAppAuthorizationConnection.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfAppAuthorizationConnectionTenantPropertyToTerraform(struct?: TfAppAuthorizationConnection.TenantProperty): any;
export declare function tfAppAuthorizationConnectionTenantPropertyToHclTerraform(struct?: TfAppAuthorizationConnection.TenantProperty): any;
export declare function tfAppAuthorizationConnectionAuthRequestPropertyToTerraform(struct?: TfAppAuthorizationConnection.AuthRequestProperty | cdktn.IResolvable): any;
export declare function tfAppAuthorizationConnectionAuthRequestPropertyToHclTerraform(struct?: TfAppAuthorizationConnection.AuthRequestProperty | cdktn.IResolvable): any;
export declare function tfAppAuthorizationConnectionTimeoutsPropertyToTerraform(struct?: TfAppAuthorizationConnection.TimeoutsProperty | cdktn.IResolvable): any;
export declare function tfAppAuthorizationConnectionTimeoutsPropertyToHclTerraform(struct?: TfAppAuthorizationConnection.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace TfAppAuthorizationConnection {
    interface TenantProperty {
    }
    class TenantPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TenantProperty | undefined;
        set internalValue(value: TenantProperty | undefined);
        get tenantDisplayName(): string;
        get tenantIdentifier(): string;
    }
    class TenantPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TenantPropertyOutputReference;
    }
    interface AuthRequestProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appfabric_app_authorization_connection#code TfAppAuthorizationConnection#code}
        */
        readonly code: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appfabric_app_authorization_connection#redirect_uri TfAppAuthorizationConnection#redirect_uri}
        */
        readonly redirectUri: string;
    }
    class AuthRequestPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AuthRequestProperty | cdktn.IResolvable | undefined;
        set internalValue(value: AuthRequestProperty | cdktn.IResolvable | undefined);
        private _code?;
        get code(): string;
        set code(value: string);
        get codeInput(): string | undefined;
        private _redirectUri?;
        get redirectUri(): string;
        set redirectUri(value: string);
        get redirectUriInput(): string | undefined;
    }
    class AuthRequestPropertyList extends cdktn.ComplexList {
        internalValue?: AuthRequestProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AuthRequestPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appfabric_app_authorization_connection#create TfAppAuthorizationConnection#create}
        */
        readonly create?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
    }
}
