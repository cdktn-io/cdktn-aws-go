import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfIngestionConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appfabric_ingestion#app TfIngestion#app}
    */
    readonly app: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appfabric_ingestion#app_bundle_arn TfIngestion#app_bundle_arn}
    */
    readonly appBundleArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appfabric_ingestion#ingestion_type TfIngestion#ingestion_type}
    */
    readonly ingestionType: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appfabric_ingestion#region TfIngestion#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appfabric_ingestion#tags TfIngestion#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appfabric_ingestion#tenant_id TfIngestion#tenant_id}
    */
    readonly tenantId: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appfabric_ingestion aws_appfabric_ingestion}
*/
export declare class TfIngestion extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_appfabric_ingestion";
    /**
    * Generates CDKTN code for importing a TfIngestion resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfIngestion to import
    * @param importFromId The id of the existing TfIngestion that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appfabric_ingestion#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfIngestion to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appfabric_ingestion aws_appfabric_ingestion} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfIngestionConfig
    */
    constructor(scope: Construct, id: string, config: TfIngestionConfig);
    private _app?;
    get app(): string;
    set app(value: string);
    get appInput(): string | undefined;
    private _appBundleArn?;
    get appBundleArn(): string;
    set appBundleArn(value: string);
    get appBundleArnInput(): string | undefined;
    get arn(): string;
    get id(): string;
    private _ingestionType?;
    get ingestionType(): string;
    set ingestionType(value: string);
    get ingestionTypeInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    private _tenantId?;
    get tenantId(): string;
    set tenantId(value: string);
    get tenantIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
