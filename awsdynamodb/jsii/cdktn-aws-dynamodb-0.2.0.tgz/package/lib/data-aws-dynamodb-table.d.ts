import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataTfTableConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/dynamodb_table#id DataTfTable#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/dynamodb_table#name DataTfTable#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/dynamodb_table#region DataTfTable#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/dynamodb_table#tags DataTfTable#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * server_side_encryption block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/dynamodb_table#server_side_encryption DataTfTable#server_side_encryption}
    */
    readonly serverSideEncryption?: DataTfTable.ServerSideEncryptionProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/dynamodb_table aws_dynamodb_table}
*/
export declare class DataTfTable extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_dynamodb_table";
    /**
    * Generates CDKTN code for importing a DataTfTable resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataTfTable to import
    * @param importFromId The id of the existing DataTfTable that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/dynamodb_table#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataTfTable to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/dynamodb_table aws_dynamodb_table} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataTfTableConfig
    */
    constructor(scope: Construct, id: string, config: DataTfTableConfig);
    get arn(): string;
    private _attribute;
    get attribute(): DataTfTable.AttributePropertyList;
    get billingMode(): string;
    get deletionProtectionEnabled(): cdktn.IResolvable;
    private _globalSecondaryIndex;
    get globalSecondaryIndex(): DataTfTable.GlobalSecondaryIndexPropertyList;
    get hashKey(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _localSecondaryIndex;
    get localSecondaryIndex(): DataTfTable.LocalSecondaryIndexPropertyList;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _onDemandThroughput;
    get onDemandThroughput(): DataTfTable.OnDemandThroughputPropertyList;
    private _pointInTimeRecovery;
    get pointInTimeRecovery(): DataTfTable.PointInTimeRecoveryPropertyList;
    get rangeKey(): string;
    get readCapacity(): number;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _replica;
    get replica(): DataTfTable.ReplicaPropertyList;
    get streamArn(): string;
    get streamEnabled(): cdktn.IResolvable;
    get streamLabel(): string;
    get streamViewType(): string;
    get tableClass(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _ttl;
    get ttl(): DataTfTable.TtlPropertyList;
    private _warmThroughput;
    get warmThroughput(): DataTfTable.WarmThroughputPropertyList;
    get writeCapacity(): number;
    private _serverSideEncryption;
    get serverSideEncryption(): DataTfTable.ServerSideEncryptionPropertyOutputReference;
    putServerSideEncryption(value: DataTfTable.ServerSideEncryptionProperty): void;
    resetServerSideEncryption(): void;
    get serverSideEncryptionInput(): DataTfTable.ServerSideEncryptionProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataTfTableAttributePropertyToTerraform(struct?: DataTfTable.AttributeProperty): any;
export declare function dataTfTableAttributePropertyToHclTerraform(struct?: DataTfTable.AttributeProperty): any;
export declare function dataTfTableKeySchemaPropertyToTerraform(struct?: DataTfTable.KeySchemaProperty): any;
export declare function dataTfTableKeySchemaPropertyToHclTerraform(struct?: DataTfTable.KeySchemaProperty): any;
export declare function dataTfTableGlobalSecondaryIndexOnDemandThroughputPropertyToTerraform(struct?: DataTfTable.GlobalSecondaryIndexOnDemandThroughputProperty): any;
export declare function dataTfTableGlobalSecondaryIndexOnDemandThroughputPropertyToHclTerraform(struct?: DataTfTable.GlobalSecondaryIndexOnDemandThroughputProperty): any;
export declare function dataTfTableGlobalSecondaryIndexWarmThroughputPropertyToTerraform(struct?: DataTfTable.GlobalSecondaryIndexWarmThroughputProperty): any;
export declare function dataTfTableGlobalSecondaryIndexWarmThroughputPropertyToHclTerraform(struct?: DataTfTable.GlobalSecondaryIndexWarmThroughputProperty): any;
export declare function dataTfTableGlobalSecondaryIndexPropertyToTerraform(struct?: DataTfTable.GlobalSecondaryIndexProperty): any;
export declare function dataTfTableGlobalSecondaryIndexPropertyToHclTerraform(struct?: DataTfTable.GlobalSecondaryIndexProperty): any;
export declare function dataTfTableLocalSecondaryIndexPropertyToTerraform(struct?: DataTfTable.LocalSecondaryIndexProperty): any;
export declare function dataTfTableLocalSecondaryIndexPropertyToHclTerraform(struct?: DataTfTable.LocalSecondaryIndexProperty): any;
export declare function dataTfTableOnDemandThroughputPropertyToTerraform(struct?: DataTfTable.OnDemandThroughputProperty): any;
export declare function dataTfTableOnDemandThroughputPropertyToHclTerraform(struct?: DataTfTable.OnDemandThroughputProperty): any;
export declare function dataTfTablePointInTimeRecoveryPropertyToTerraform(struct?: DataTfTable.PointInTimeRecoveryProperty): any;
export declare function dataTfTablePointInTimeRecoveryPropertyToHclTerraform(struct?: DataTfTable.PointInTimeRecoveryProperty): any;
export declare function dataTfTableReplicaPropertyToTerraform(struct?: DataTfTable.ReplicaProperty): any;
export declare function dataTfTableReplicaPropertyToHclTerraform(struct?: DataTfTable.ReplicaProperty): any;
export declare function dataTfTableTtlPropertyToTerraform(struct?: DataTfTable.TtlProperty): any;
export declare function dataTfTableTtlPropertyToHclTerraform(struct?: DataTfTable.TtlProperty): any;
export declare function dataTfTableWarmThroughputPropertyToTerraform(struct?: DataTfTable.WarmThroughputProperty): any;
export declare function dataTfTableWarmThroughputPropertyToHclTerraform(struct?: DataTfTable.WarmThroughputProperty): any;
export declare function dataTfTableServerSideEncryptionPropertyToTerraform(struct?: DataTfTable.ServerSideEncryptionPropertyOutputReference | DataTfTable.ServerSideEncryptionProperty): any;
export declare function dataTfTableServerSideEncryptionPropertyToHclTerraform(struct?: DataTfTable.ServerSideEncryptionPropertyOutputReference | DataTfTable.ServerSideEncryptionProperty): any;
export declare namespace DataTfTable {
    interface AttributeProperty {
    }
    class AttributePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AttributeProperty | undefined;
        set internalValue(value: AttributeProperty | undefined);
        get name(): string;
        get type(): string;
    }
    class AttributePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AttributePropertyOutputReference;
    }
    interface KeySchemaProperty {
    }
    class KeySchemaPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): KeySchemaProperty | undefined;
        set internalValue(value: KeySchemaProperty | undefined);
        get attributeName(): string;
        get keyType(): string;
    }
    class KeySchemaPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): KeySchemaPropertyOutputReference;
    }
    interface GlobalSecondaryIndexOnDemandThroughputProperty {
    }
    class GlobalSecondaryIndexOnDemandThroughputPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): GlobalSecondaryIndexOnDemandThroughputProperty | undefined;
        set internalValue(value: GlobalSecondaryIndexOnDemandThroughputProperty | undefined);
        get maxReadRequestUnits(): number;
        get maxWriteRequestUnits(): number;
    }
    class GlobalSecondaryIndexOnDemandThroughputPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): GlobalSecondaryIndexOnDemandThroughputPropertyOutputReference;
    }
    interface GlobalSecondaryIndexWarmThroughputProperty {
    }
    class GlobalSecondaryIndexWarmThroughputPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): GlobalSecondaryIndexWarmThroughputProperty | undefined;
        set internalValue(value: GlobalSecondaryIndexWarmThroughputProperty | undefined);
        get readUnitsPerSecond(): number;
        get writeUnitsPerSecond(): number;
    }
    class GlobalSecondaryIndexWarmThroughputPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): GlobalSecondaryIndexWarmThroughputPropertyOutputReference;
    }
    interface GlobalSecondaryIndexProperty {
    }
    class GlobalSecondaryIndexPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): GlobalSecondaryIndexProperty | undefined;
        set internalValue(value: GlobalSecondaryIndexProperty | undefined);
        get hashKey(): string;
        private _keySchema;
        get keySchema(): KeySchemaPropertyList;
        get name(): string;
        get nonKeyAttributes(): string[];
        private _onDemandThroughput;
        get onDemandThroughput(): GlobalSecondaryIndexOnDemandThroughputPropertyList;
        get projectionType(): string;
        get rangeKey(): string;
        get readCapacity(): number;
        private _warmThroughput;
        get warmThroughput(): GlobalSecondaryIndexWarmThroughputPropertyList;
        get writeCapacity(): number;
    }
    class GlobalSecondaryIndexPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): GlobalSecondaryIndexPropertyOutputReference;
    }
    interface LocalSecondaryIndexProperty {
    }
    class LocalSecondaryIndexPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): LocalSecondaryIndexProperty | undefined;
        set internalValue(value: LocalSecondaryIndexProperty | undefined);
        get name(): string;
        get nonKeyAttributes(): string[];
        get projectionType(): string;
        get rangeKey(): string;
    }
    class LocalSecondaryIndexPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): LocalSecondaryIndexPropertyOutputReference;
    }
    interface OnDemandThroughputProperty {
    }
    class OnDemandThroughputPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): OnDemandThroughputProperty | undefined;
        set internalValue(value: OnDemandThroughputProperty | undefined);
        get maxReadRequestUnits(): number;
        get maxWriteRequestUnits(): number;
    }
    class OnDemandThroughputPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): OnDemandThroughputPropertyOutputReference;
    }
    interface PointInTimeRecoveryProperty {
    }
    class PointInTimeRecoveryPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): PointInTimeRecoveryProperty | undefined;
        set internalValue(value: PointInTimeRecoveryProperty | undefined);
        get enabled(): cdktn.IResolvable;
        get recoveryPeriodInDays(): number;
    }
    class PointInTimeRecoveryPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): PointInTimeRecoveryPropertyOutputReference;
    }
    interface ReplicaProperty {
    }
    class ReplicaPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ReplicaProperty | undefined;
        set internalValue(value: ReplicaProperty | undefined);
        get kmsKeyArn(): string;
        get regionName(): string;
    }
    class ReplicaPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ReplicaPropertyOutputReference;
    }
    interface TtlProperty {
    }
    class TtlPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TtlProperty | undefined;
        set internalValue(value: TtlProperty | undefined);
        get attributeName(): string;
        get enabled(): cdktn.IResolvable;
    }
    class TtlPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TtlPropertyOutputReference;
    }
    interface WarmThroughputProperty {
    }
    class WarmThroughputPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WarmThroughputProperty | undefined;
        set internalValue(value: WarmThroughputProperty | undefined);
        get readUnitsPerSecond(): number;
        get writeUnitsPerSecond(): number;
    }
    class WarmThroughputPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WarmThroughputPropertyOutputReference;
    }
    interface ServerSideEncryptionProperty {
    }
    class ServerSideEncryptionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ServerSideEncryptionProperty | undefined;
        set internalValue(value: ServerSideEncryptionProperty | undefined);
        get enabled(): cdktn.IResolvable;
        get kmsKeyArn(): string;
    }
}
