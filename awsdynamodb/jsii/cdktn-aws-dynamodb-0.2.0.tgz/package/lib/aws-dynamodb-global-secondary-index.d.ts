import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfGlobalSecondaryIndexConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_global_secondary_index#index_name TfGlobalSecondaryIndex#index_name}
    */
    readonly indexName: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_global_secondary_index#region TfGlobalSecondaryIndex#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_global_secondary_index#table_name TfGlobalSecondaryIndex#table_name}
    */
    readonly tableName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_global_secondary_index#warm_throughput TfGlobalSecondaryIndex#warm_throughput}
    */
    readonly warmThroughput?: TfGlobalSecondaryIndex.WarmThroughputProperty;
    /**
    * key_schema block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_global_secondary_index#key_schema TfGlobalSecondaryIndex#key_schema}
    */
    readonly keySchema?: TfGlobalSecondaryIndex.KeySchemaProperty[] | cdktn.IResolvable;
    /**
    * on_demand_throughput block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_global_secondary_index#on_demand_throughput TfGlobalSecondaryIndex#on_demand_throughput}
    */
    readonly onDemandThroughput?: TfGlobalSecondaryIndex.OnDemandThroughputProperty[] | cdktn.IResolvable;
    /**
    * projection block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_global_secondary_index#projection TfGlobalSecondaryIndex#projection}
    */
    readonly projection?: TfGlobalSecondaryIndex.ProjectionProperty[] | cdktn.IResolvable;
    /**
    * provisioned_throughput block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_global_secondary_index#provisioned_throughput TfGlobalSecondaryIndex#provisioned_throughput}
    */
    readonly provisionedThroughput?: TfGlobalSecondaryIndex.ProvisionedThroughputProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_global_secondary_index#timeouts TfGlobalSecondaryIndex#timeouts}
    */
    readonly timeouts?: TfGlobalSecondaryIndex.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_global_secondary_index aws_dynamodb_global_secondary_index}
*/
export declare class TfGlobalSecondaryIndex extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_dynamodb_global_secondary_index";
    /**
    * Generates CDKTN code for importing a TfGlobalSecondaryIndex resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfGlobalSecondaryIndex to import
    * @param importFromId The id of the existing TfGlobalSecondaryIndex that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_global_secondary_index#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfGlobalSecondaryIndex to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_global_secondary_index aws_dynamodb_global_secondary_index} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfGlobalSecondaryIndexConfig
    */
    constructor(scope: Construct, id: string, config: TfGlobalSecondaryIndexConfig);
    get arn(): string;
    private _indexName?;
    get indexName(): string;
    set indexName(value: string);
    get indexNameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tableName?;
    get tableName(): string;
    set tableName(value: string);
    get tableNameInput(): string | undefined;
    private _warmThroughput;
    get warmThroughput(): TfGlobalSecondaryIndex.WarmThroughputPropertyOutputReference;
    putWarmThroughput(value: TfGlobalSecondaryIndex.WarmThroughputProperty): void;
    resetWarmThroughput(): void;
    get warmThroughputInput(): cdktn.IResolvable | TfGlobalSecondaryIndex.WarmThroughputProperty | undefined;
    private _keySchema;
    get keySchema(): TfGlobalSecondaryIndex.KeySchemaPropertyList;
    putKeySchema(value: TfGlobalSecondaryIndex.KeySchemaProperty[] | cdktn.IResolvable): void;
    resetKeySchema(): void;
    get keySchemaInput(): cdktn.IResolvable | TfGlobalSecondaryIndex.KeySchemaProperty[] | undefined;
    private _onDemandThroughput;
    get onDemandThroughput(): TfGlobalSecondaryIndex.OnDemandThroughputPropertyList;
    putOnDemandThroughput(value: TfGlobalSecondaryIndex.OnDemandThroughputProperty[] | cdktn.IResolvable): void;
    resetOnDemandThroughput(): void;
    get onDemandThroughputInput(): cdktn.IResolvable | TfGlobalSecondaryIndex.OnDemandThroughputProperty[] | undefined;
    private _projection;
    get projection(): TfGlobalSecondaryIndex.ProjectionPropertyList;
    putProjection(value: TfGlobalSecondaryIndex.ProjectionProperty[] | cdktn.IResolvable): void;
    resetProjection(): void;
    get projectionInput(): cdktn.IResolvable | TfGlobalSecondaryIndex.ProjectionProperty[] | undefined;
    private _provisionedThroughput;
    get provisionedThroughput(): TfGlobalSecondaryIndex.ProvisionedThroughputPropertyList;
    putProvisionedThroughput(value: TfGlobalSecondaryIndex.ProvisionedThroughputProperty[] | cdktn.IResolvable): void;
    resetProvisionedThroughput(): void;
    get provisionedThroughputInput(): cdktn.IResolvable | TfGlobalSecondaryIndex.ProvisionedThroughputProperty[] | undefined;
    private _timeouts;
    get timeouts(): TfGlobalSecondaryIndex.TimeoutsPropertyOutputReference;
    putTimeouts(value: TfGlobalSecondaryIndex.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | TfGlobalSecondaryIndex.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfGlobalSecondaryIndexWarmThroughputPropertyToTerraform(struct?: TfGlobalSecondaryIndex.WarmThroughputProperty | cdktn.IResolvable): any;
export declare function tfGlobalSecondaryIndexWarmThroughputPropertyToHclTerraform(struct?: TfGlobalSecondaryIndex.WarmThroughputProperty | cdktn.IResolvable): any;
export declare function tfGlobalSecondaryIndexKeySchemaPropertyToTerraform(struct?: TfGlobalSecondaryIndex.KeySchemaProperty | cdktn.IResolvable): any;
export declare function tfGlobalSecondaryIndexKeySchemaPropertyToHclTerraform(struct?: TfGlobalSecondaryIndex.KeySchemaProperty | cdktn.IResolvable): any;
export declare function tfGlobalSecondaryIndexOnDemandThroughputPropertyToTerraform(struct?: TfGlobalSecondaryIndex.OnDemandThroughputProperty | cdktn.IResolvable): any;
export declare function tfGlobalSecondaryIndexOnDemandThroughputPropertyToHclTerraform(struct?: TfGlobalSecondaryIndex.OnDemandThroughputProperty | cdktn.IResolvable): any;
export declare function tfGlobalSecondaryIndexProjectionPropertyToTerraform(struct?: TfGlobalSecondaryIndex.ProjectionProperty | cdktn.IResolvable): any;
export declare function tfGlobalSecondaryIndexProjectionPropertyToHclTerraform(struct?: TfGlobalSecondaryIndex.ProjectionProperty | cdktn.IResolvable): any;
export declare function tfGlobalSecondaryIndexProvisionedThroughputPropertyToTerraform(struct?: TfGlobalSecondaryIndex.ProvisionedThroughputProperty | cdktn.IResolvable): any;
export declare function tfGlobalSecondaryIndexProvisionedThroughputPropertyToHclTerraform(struct?: TfGlobalSecondaryIndex.ProvisionedThroughputProperty | cdktn.IResolvable): any;
export declare function tfGlobalSecondaryIndexTimeoutsPropertyToTerraform(struct?: TfGlobalSecondaryIndex.TimeoutsProperty | cdktn.IResolvable): any;
export declare function tfGlobalSecondaryIndexTimeoutsPropertyToHclTerraform(struct?: TfGlobalSecondaryIndex.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace TfGlobalSecondaryIndex {
    interface WarmThroughputProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_global_secondary_index#read_units_per_second TfGlobalSecondaryIndex#read_units_per_second}
        */
        readonly readUnitsPerSecond?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_global_secondary_index#write_units_per_second TfGlobalSecondaryIndex#write_units_per_second}
        */
        readonly writeUnitsPerSecond?: number;
    }
    class WarmThroughputPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): WarmThroughputProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WarmThroughputProperty | cdktn.IResolvable | undefined);
        private _readUnitsPerSecond?;
        get readUnitsPerSecond(): number;
        set readUnitsPerSecond(value: number);
        resetReadUnitsPerSecond(): void;
        get readUnitsPerSecondInput(): number | undefined;
        private _writeUnitsPerSecond?;
        get writeUnitsPerSecond(): number;
        set writeUnitsPerSecond(value: number);
        resetWriteUnitsPerSecond(): void;
        get writeUnitsPerSecondInput(): number | undefined;
    }
    interface KeySchemaProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_global_secondary_index#attribute_name TfGlobalSecondaryIndex#attribute_name}
        */
        readonly attributeName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_global_secondary_index#attribute_type TfGlobalSecondaryIndex#attribute_type}
        */
        readonly attributeType: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_global_secondary_index#key_type TfGlobalSecondaryIndex#key_type}
        */
        readonly keyType: string;
    }
    class KeySchemaPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): KeySchemaProperty | cdktn.IResolvable | undefined;
        set internalValue(value: KeySchemaProperty | cdktn.IResolvable | undefined);
        private _attributeName?;
        get attributeName(): string;
        set attributeName(value: string);
        get attributeNameInput(): string | undefined;
        private _attributeType?;
        get attributeType(): string;
        set attributeType(value: string);
        get attributeTypeInput(): string | undefined;
        private _keyType?;
        get keyType(): string;
        set keyType(value: string);
        get keyTypeInput(): string | undefined;
    }
    class KeySchemaPropertyList extends cdktn.ComplexList {
        internalValue?: KeySchemaProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): KeySchemaPropertyOutputReference;
    }
    interface OnDemandThroughputProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_global_secondary_index#max_read_request_units TfGlobalSecondaryIndex#max_read_request_units}
        */
        readonly maxReadRequestUnits?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_global_secondary_index#max_write_request_units TfGlobalSecondaryIndex#max_write_request_units}
        */
        readonly maxWriteRequestUnits?: number;
    }
    class OnDemandThroughputPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): OnDemandThroughputProperty | cdktn.IResolvable | undefined;
        set internalValue(value: OnDemandThroughputProperty | cdktn.IResolvable | undefined);
        private _maxReadRequestUnits?;
        get maxReadRequestUnits(): number;
        set maxReadRequestUnits(value: number);
        resetMaxReadRequestUnits(): void;
        get maxReadRequestUnitsInput(): number | undefined;
        private _maxWriteRequestUnits?;
        get maxWriteRequestUnits(): number;
        set maxWriteRequestUnits(value: number);
        resetMaxWriteRequestUnits(): void;
        get maxWriteRequestUnitsInput(): number | undefined;
    }
    class OnDemandThroughputPropertyList extends cdktn.ComplexList {
        internalValue?: OnDemandThroughputProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): OnDemandThroughputPropertyOutputReference;
    }
    interface ProjectionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_global_secondary_index#non_key_attributes TfGlobalSecondaryIndex#non_key_attributes}
        */
        readonly nonKeyAttributes?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_global_secondary_index#projection_type TfGlobalSecondaryIndex#projection_type}
        */
        readonly projectionType: string;
    }
    class ProjectionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ProjectionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ProjectionProperty | cdktn.IResolvable | undefined);
        private _nonKeyAttributes?;
        get nonKeyAttributes(): string[];
        set nonKeyAttributes(value: string[]);
        resetNonKeyAttributes(): void;
        get nonKeyAttributesInput(): string[] | undefined;
        private _projectionType?;
        get projectionType(): string;
        set projectionType(value: string);
        get projectionTypeInput(): string | undefined;
    }
    class ProjectionPropertyList extends cdktn.ComplexList {
        internalValue?: ProjectionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ProjectionPropertyOutputReference;
    }
    interface ProvisionedThroughputProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_global_secondary_index#read_capacity_units TfGlobalSecondaryIndex#read_capacity_units}
        */
        readonly readCapacityUnits?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_global_secondary_index#write_capacity_units TfGlobalSecondaryIndex#write_capacity_units}
        */
        readonly writeCapacityUnits?: number;
    }
    class ProvisionedThroughputPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ProvisionedThroughputProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ProvisionedThroughputProperty | cdktn.IResolvable | undefined);
        private _readCapacityUnits?;
        get readCapacityUnits(): number;
        set readCapacityUnits(value: number);
        resetReadCapacityUnits(): void;
        get readCapacityUnitsInput(): number | undefined;
        private _writeCapacityUnits?;
        get writeCapacityUnits(): number;
        set writeCapacityUnits(value: number);
        resetWriteCapacityUnits(): void;
        get writeCapacityUnitsInput(): number | undefined;
    }
    class ProvisionedThroughputPropertyList extends cdktn.ComplexList {
        internalValue?: ProvisionedThroughputProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ProvisionedThroughputPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_global_secondary_index#create TfGlobalSecondaryIndex#create}
        */
        readonly create?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Setting a timeout for a Delete operation is only applicable if changes are saved into state before the destroy operation occurs.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_global_secondary_index#delete TfGlobalSecondaryIndex#delete}
        */
        readonly delete?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_global_secondary_index#update TfGlobalSecondaryIndex#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
