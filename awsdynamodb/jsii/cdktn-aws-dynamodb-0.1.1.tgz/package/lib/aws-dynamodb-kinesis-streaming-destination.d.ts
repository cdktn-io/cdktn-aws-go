import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsDynamodbKinesisStreamingDestinationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_kinesis_streaming_destination#approximate_creation_date_time_precision AwsDynamodbKinesisStreamingDestination#approximate_creation_date_time_precision}
    */
    readonly approximateCreationDateTimePrecision?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_kinesis_streaming_destination#id AwsDynamodbKinesisStreamingDestination#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_kinesis_streaming_destination#region AwsDynamodbKinesisStreamingDestination#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_kinesis_streaming_destination#stream_arn AwsDynamodbKinesisStreamingDestination#stream_arn}
    */
    readonly streamArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_kinesis_streaming_destination#table_name AwsDynamodbKinesisStreamingDestination#table_name}
    */
    readonly tableName: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_kinesis_streaming_destination aws_dynamodb_kinesis_streaming_destination}
*/
export declare class AwsDynamodbKinesisStreamingDestination extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_dynamodb_kinesis_streaming_destination";
    /**
    * Generates CDKTN code for importing a AwsDynamodbKinesisStreamingDestination resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsDynamodbKinesisStreamingDestination to import
    * @param importFromId The id of the existing AwsDynamodbKinesisStreamingDestination that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_kinesis_streaming_destination#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsDynamodbKinesisStreamingDestination to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_kinesis_streaming_destination aws_dynamodb_kinesis_streaming_destination} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsDynamodbKinesisStreamingDestinationConfig
    */
    constructor(scope: Construct, id: string, config: AwsDynamodbKinesisStreamingDestinationConfig);
    private _approximateCreationDateTimePrecision?;
    get approximateCreationDateTimePrecision(): string;
    set approximateCreationDateTimePrecision(value: string);
    resetApproximateCreationDateTimePrecision(): void;
    get approximateCreationDateTimePrecisionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _streamArn?;
    get streamArn(): string;
    set streamArn(value: string);
    get streamArnInput(): string | undefined;
    private _tableName?;
    get tableName(): string;
    set tableName(value: string);
    get tableNameInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
