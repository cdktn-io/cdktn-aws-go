import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsDynamodbGlobalTableConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_global_table#id AwsDynamodbGlobalTable#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_global_table#name AwsDynamodbGlobalTable#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_global_table#region AwsDynamodbGlobalTable#region}
    */
    readonly region?: string;
    /**
    * replica block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_global_table#replica AwsDynamodbGlobalTable#replica}
    */
    readonly replica: AwsDynamodbGlobalTable.ReplicaProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_global_table#timeouts AwsDynamodbGlobalTable#timeouts}
    */
    readonly timeouts?: AwsDynamodbGlobalTable.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_global_table aws_dynamodb_global_table}
*/
export declare class AwsDynamodbGlobalTable extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_dynamodb_global_table";
    /**
    * Generates CDKTN code for importing a AwsDynamodbGlobalTable resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsDynamodbGlobalTable to import
    * @param importFromId The id of the existing AwsDynamodbGlobalTable that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_global_table#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsDynamodbGlobalTable to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_global_table aws_dynamodb_global_table} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsDynamodbGlobalTableConfig
    */
    constructor(scope: Construct, id: string, config: AwsDynamodbGlobalTableConfig);
    get arn(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _replica;
    get replica(): AwsDynamodbGlobalTable.ReplicaPropertyList;
    putReplica(value: AwsDynamodbGlobalTable.ReplicaProperty[] | cdktn.IResolvable): void;
    get replicaInput(): cdktn.IResolvable | AwsDynamodbGlobalTable.ReplicaProperty[] | undefined;
    private _timeouts;
    get timeouts(): AwsDynamodbGlobalTable.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsDynamodbGlobalTable.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsDynamodbGlobalTable.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsDynamodbGlobalTableReplicaPropertyToTerraform(struct?: AwsDynamodbGlobalTable.ReplicaProperty | cdktn.IResolvable): any;
export declare function awsDynamodbGlobalTableReplicaPropertyToHclTerraform(struct?: AwsDynamodbGlobalTable.ReplicaProperty | cdktn.IResolvable): any;
export declare function awsDynamodbGlobalTableTimeoutsPropertyToTerraform(struct?: AwsDynamodbGlobalTable.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsDynamodbGlobalTableTimeoutsPropertyToHclTerraform(struct?: AwsDynamodbGlobalTable.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsDynamodbGlobalTable {
    interface ReplicaProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_global_table#region_name AwsDynamodbGlobalTable#region_name}
        */
        readonly regionName: string;
    }
    class ReplicaPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ReplicaProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ReplicaProperty | cdktn.IResolvable | undefined);
        private _regionName?;
        get regionName(): string;
        set regionName(value: string);
        get regionNameInput(): string | undefined;
    }
    class ReplicaPropertyList extends cdktn.ComplexList {
        internalValue?: ReplicaProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ReplicaPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_global_table#create AwsDynamodbGlobalTable#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_global_table#delete AwsDynamodbGlobalTable#delete}
        */
        readonly delete?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_global_table#update AwsDynamodbGlobalTable#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
