import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsDynamodbContributorInsightsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_contributor_insights#id AwsDynamodbContributorInsights#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_contributor_insights#index_name AwsDynamodbContributorInsights#index_name}
    */
    readonly indexName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_contributor_insights#mode AwsDynamodbContributorInsights#mode}
    */
    readonly mode?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_contributor_insights#region AwsDynamodbContributorInsights#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_contributor_insights#table_name AwsDynamodbContributorInsights#table_name}
    */
    readonly tableName: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_contributor_insights#timeouts AwsDynamodbContributorInsights#timeouts}
    */
    readonly timeouts?: AwsDynamodbContributorInsights.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_contributor_insights aws_dynamodb_contributor_insights}
*/
export declare class AwsDynamodbContributorInsights extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_dynamodb_contributor_insights";
    /**
    * Generates CDKTN code for importing a AwsDynamodbContributorInsights resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsDynamodbContributorInsights to import
    * @param importFromId The id of the existing AwsDynamodbContributorInsights that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_contributor_insights#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsDynamodbContributorInsights to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_contributor_insights aws_dynamodb_contributor_insights} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsDynamodbContributorInsightsConfig
    */
    constructor(scope: Construct, id: string, config: AwsDynamodbContributorInsightsConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _indexName?;
    get indexName(): string;
    set indexName(value: string);
    resetIndexName(): void;
    get indexNameInput(): string | undefined;
    private _mode?;
    get mode(): string;
    set mode(value: string);
    resetMode(): void;
    get modeInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tableName?;
    get tableName(): string;
    set tableName(value: string);
    get tableNameInput(): string | undefined;
    private _timeouts;
    get timeouts(): AwsDynamodbContributorInsights.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsDynamodbContributorInsights.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): AwsDynamodbContributorInsights.TimeoutsProperty | cdktn.IResolvable | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsDynamodbContributorInsightsTimeoutsPropertyToTerraform(struct?: AwsDynamodbContributorInsights.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsDynamodbContributorInsightsTimeoutsPropertyToHclTerraform(struct?: AwsDynamodbContributorInsights.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsDynamodbContributorInsights {
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_contributor_insights#create AwsDynamodbContributorInsights#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_contributor_insights#delete AwsDynamodbContributorInsights#delete}
        */
        readonly delete?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
    }
}
