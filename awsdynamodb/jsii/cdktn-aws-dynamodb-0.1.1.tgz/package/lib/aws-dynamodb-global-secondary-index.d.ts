import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsDynamodbGlobalSecondaryIndexConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_global_secondary_index#index_name AwsDynamodbGlobalSecondaryIndex#index_name}
    */
    readonly indexName: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_global_secondary_index#region AwsDynamodbGlobalSecondaryIndex#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_global_secondary_index#table_name AwsDynamodbGlobalSecondaryIndex#table_name}
    */
    readonly tableName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_global_secondary_index#warm_throughput AwsDynamodbGlobalSecondaryIndex#warm_throughput}
    */
    readonly warmThroughput?: AwsDynamodbGlobalSecondaryIndex.WarmThroughputProperty;
    /**
    * key_schema block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_global_secondary_index#key_schema AwsDynamodbGlobalSecondaryIndex#key_schema}
    */
    readonly keySchema?: AwsDynamodbGlobalSecondaryIndex.KeySchemaProperty[] | cdktn.IResolvable;
    /**
    * on_demand_throughput block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_global_secondary_index#on_demand_throughput AwsDynamodbGlobalSecondaryIndex#on_demand_throughput}
    */
    readonly onDemandThroughput?: AwsDynamodbGlobalSecondaryIndex.OnDemandThroughputProperty[] | cdktn.IResolvable;
    /**
    * projection block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_global_secondary_index#projection AwsDynamodbGlobalSecondaryIndex#projection}
    */
    readonly projection?: AwsDynamodbGlobalSecondaryIndex.ProjectionProperty[] | cdktn.IResolvable;
    /**
    * provisioned_throughput block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_global_secondary_index#provisioned_throughput AwsDynamodbGlobalSecondaryIndex#provisioned_throughput}
    */
    readonly provisionedThroughput?: AwsDynamodbGlobalSecondaryIndex.ProvisionedThroughputProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_global_secondary_index#timeouts AwsDynamodbGlobalSecondaryIndex#timeouts}
    */
    readonly timeouts?: AwsDynamodbGlobalSecondaryIndex.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_global_secondary_index aws_dynamodb_global_secondary_index}
*/
export declare class AwsDynamodbGlobalSecondaryIndex extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_dynamodb_global_secondary_index";
    /**
    * Generates CDKTN code for importing a AwsDynamodbGlobalSecondaryIndex resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsDynamodbGlobalSecondaryIndex to import
    * @param importFromId The id of the existing AwsDynamodbGlobalSecondaryIndex that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_global_secondary_index#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsDynamodbGlobalSecondaryIndex to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_global_secondary_index aws_dynamodb_global_secondary_index} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsDynamodbGlobalSecondaryIndexConfig
    */
    constructor(scope: Construct, id: string, config: AwsDynamodbGlobalSecondaryIndexConfig);
    get arn(): string;
    private _indexName?;
    get indexName(): string;
    set indexName(value: string);
    get indexNameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tableName?;
    get tableName(): string;
    set tableName(value: string);
    get tableNameInput(): string | undefined;
    private _warmThroughput;
    get warmThroughput(): AwsDynamodbGlobalSecondaryIndex.WarmThroughputPropertyOutputReference;
    putWarmThroughput(value: AwsDynamodbGlobalSecondaryIndex.WarmThroughputProperty): void;
    resetWarmThroughput(): void;
    get warmThroughputInput(): cdktn.IResolvable | AwsDynamodbGlobalSecondaryIndex.WarmThroughputProperty | undefined;
    private _keySchema;
    get keySchema(): AwsDynamodbGlobalSecondaryIndex.KeySchemaPropertyList;
    putKeySchema(value: AwsDynamodbGlobalSecondaryIndex.KeySchemaProperty[] | cdktn.IResolvable): void;
    resetKeySchema(): void;
    get keySchemaInput(): cdktn.IResolvable | AwsDynamodbGlobalSecondaryIndex.KeySchemaProperty[] | undefined;
    private _onDemandThroughput;
    get onDemandThroughput(): AwsDynamodbGlobalSecondaryIndex.OnDemandThroughputPropertyList;
    putOnDemandThroughput(value: AwsDynamodbGlobalSecondaryIndex.OnDemandThroughputProperty[] | cdktn.IResolvable): void;
    resetOnDemandThroughput(): void;
    get onDemandThroughputInput(): cdktn.IResolvable | AwsDynamodbGlobalSecondaryIndex.OnDemandThroughputProperty[] | undefined;
    private _projection;
    get projection(): AwsDynamodbGlobalSecondaryIndex.ProjectionPropertyList;
    putProjection(value: AwsDynamodbGlobalSecondaryIndex.ProjectionProperty[] | cdktn.IResolvable): void;
    resetProjection(): void;
    get projectionInput(): cdktn.IResolvable | AwsDynamodbGlobalSecondaryIndex.ProjectionProperty[] | undefined;
    private _provisionedThroughput;
    get provisionedThroughput(): AwsDynamodbGlobalSecondaryIndex.ProvisionedThroughputPropertyList;
    putProvisionedThroughput(value: AwsDynamodbGlobalSecondaryIndex.ProvisionedThroughputProperty[] | cdktn.IResolvable): void;
    resetProvisionedThroughput(): void;
    get provisionedThroughputInput(): cdktn.IResolvable | AwsDynamodbGlobalSecondaryIndex.ProvisionedThroughputProperty[] | undefined;
    private _timeouts;
    get timeouts(): AwsDynamodbGlobalSecondaryIndex.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsDynamodbGlobalSecondaryIndex.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsDynamodbGlobalSecondaryIndex.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsDynamodbGlobalSecondaryIndexWarmThroughputPropertyToTerraform(struct?: AwsDynamodbGlobalSecondaryIndex.WarmThroughputProperty | cdktn.IResolvable): any;
export declare function awsDynamodbGlobalSecondaryIndexWarmThroughputPropertyToHclTerraform(struct?: AwsDynamodbGlobalSecondaryIndex.WarmThroughputProperty | cdktn.IResolvable): any;
export declare function awsDynamodbGlobalSecondaryIndexKeySchemaPropertyToTerraform(struct?: AwsDynamodbGlobalSecondaryIndex.KeySchemaProperty | cdktn.IResolvable): any;
export declare function awsDynamodbGlobalSecondaryIndexKeySchemaPropertyToHclTerraform(struct?: AwsDynamodbGlobalSecondaryIndex.KeySchemaProperty | cdktn.IResolvable): any;
export declare function awsDynamodbGlobalSecondaryIndexOnDemandThroughputPropertyToTerraform(struct?: AwsDynamodbGlobalSecondaryIndex.OnDemandThroughputProperty | cdktn.IResolvable): any;
export declare function awsDynamodbGlobalSecondaryIndexOnDemandThroughputPropertyToHclTerraform(struct?: AwsDynamodbGlobalSecondaryIndex.OnDemandThroughputProperty | cdktn.IResolvable): any;
export declare function awsDynamodbGlobalSecondaryIndexProjectionPropertyToTerraform(struct?: AwsDynamodbGlobalSecondaryIndex.ProjectionProperty | cdktn.IResolvable): any;
export declare function awsDynamodbGlobalSecondaryIndexProjectionPropertyToHclTerraform(struct?: AwsDynamodbGlobalSecondaryIndex.ProjectionProperty | cdktn.IResolvable): any;
export declare function awsDynamodbGlobalSecondaryIndexProvisionedThroughputPropertyToTerraform(struct?: AwsDynamodbGlobalSecondaryIndex.ProvisionedThroughputProperty | cdktn.IResolvable): any;
export declare function awsDynamodbGlobalSecondaryIndexProvisionedThroughputPropertyToHclTerraform(struct?: AwsDynamodbGlobalSecondaryIndex.ProvisionedThroughputProperty | cdktn.IResolvable): any;
export declare function awsDynamodbGlobalSecondaryIndexTimeoutsPropertyToTerraform(struct?: AwsDynamodbGlobalSecondaryIndex.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsDynamodbGlobalSecondaryIndexTimeoutsPropertyToHclTerraform(struct?: AwsDynamodbGlobalSecondaryIndex.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsDynamodbGlobalSecondaryIndex {
    interface WarmThroughputProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_global_secondary_index#read_units_per_second AwsDynamodbGlobalSecondaryIndex#read_units_per_second}
        */
        readonly readUnitsPerSecond?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_global_secondary_index#write_units_per_second AwsDynamodbGlobalSecondaryIndex#write_units_per_second}
        */
        readonly writeUnitsPerSecond?: number;
    }
    class WarmThroughputPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): WarmThroughputProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WarmThroughputProperty | cdktn.IResolvable | undefined);
        private _readUnitsPerSecond?;
        get readUnitsPerSecond(): number;
        set readUnitsPerSecond(value: number);
        resetReadUnitsPerSecond(): void;
        get readUnitsPerSecondInput(): number | undefined;
        private _writeUnitsPerSecond?;
        get writeUnitsPerSecond(): number;
        set writeUnitsPerSecond(value: number);
        resetWriteUnitsPerSecond(): void;
        get writeUnitsPerSecondInput(): number | undefined;
    }
    interface KeySchemaProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_global_secondary_index#attribute_name AwsDynamodbGlobalSecondaryIndex#attribute_name}
        */
        readonly attributeName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_global_secondary_index#attribute_type AwsDynamodbGlobalSecondaryIndex#attribute_type}
        */
        readonly attributeType: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_global_secondary_index#key_type AwsDynamodbGlobalSecondaryIndex#key_type}
        */
        readonly keyType: string;
    }
    class KeySchemaPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): KeySchemaProperty | cdktn.IResolvable | undefined;
        set internalValue(value: KeySchemaProperty | cdktn.IResolvable | undefined);
        private _attributeName?;
        get attributeName(): string;
        set attributeName(value: string);
        get attributeNameInput(): string | undefined;
        private _attributeType?;
        get attributeType(): string;
        set attributeType(value: string);
        get attributeTypeInput(): string | undefined;
        private _keyType?;
        get keyType(): string;
        set keyType(value: string);
        get keyTypeInput(): string | undefined;
    }
    class KeySchemaPropertyList extends cdktn.ComplexList {
        internalValue?: KeySchemaProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): KeySchemaPropertyOutputReference;
    }
    interface OnDemandThroughputProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_global_secondary_index#max_read_request_units AwsDynamodbGlobalSecondaryIndex#max_read_request_units}
        */
        readonly maxReadRequestUnits?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_global_secondary_index#max_write_request_units AwsDynamodbGlobalSecondaryIndex#max_write_request_units}
        */
        readonly maxWriteRequestUnits?: number;
    }
    class OnDemandThroughputPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): OnDemandThroughputProperty | cdktn.IResolvable | undefined;
        set internalValue(value: OnDemandThroughputProperty | cdktn.IResolvable | undefined);
        private _maxReadRequestUnits?;
        get maxReadRequestUnits(): number;
        set maxReadRequestUnits(value: number);
        resetMaxReadRequestUnits(): void;
        get maxReadRequestUnitsInput(): number | undefined;
        private _maxWriteRequestUnits?;
        get maxWriteRequestUnits(): number;
        set maxWriteRequestUnits(value: number);
        resetMaxWriteRequestUnits(): void;
        get maxWriteRequestUnitsInput(): number | undefined;
    }
    class OnDemandThroughputPropertyList extends cdktn.ComplexList {
        internalValue?: OnDemandThroughputProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): OnDemandThroughputPropertyOutputReference;
    }
    interface ProjectionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_global_secondary_index#non_key_attributes AwsDynamodbGlobalSecondaryIndex#non_key_attributes}
        */
        readonly nonKeyAttributes?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_global_secondary_index#projection_type AwsDynamodbGlobalSecondaryIndex#projection_type}
        */
        readonly projectionType: string;
    }
    class ProjectionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ProjectionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ProjectionProperty | cdktn.IResolvable | undefined);
        private _nonKeyAttributes?;
        get nonKeyAttributes(): string[];
        set nonKeyAttributes(value: string[]);
        resetNonKeyAttributes(): void;
        get nonKeyAttributesInput(): string[] | undefined;
        private _projectionType?;
        get projectionType(): string;
        set projectionType(value: string);
        get projectionTypeInput(): string | undefined;
    }
    class ProjectionPropertyList extends cdktn.ComplexList {
        internalValue?: ProjectionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ProjectionPropertyOutputReference;
    }
    interface ProvisionedThroughputProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_global_secondary_index#read_capacity_units AwsDynamodbGlobalSecondaryIndex#read_capacity_units}
        */
        readonly readCapacityUnits?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_global_secondary_index#write_capacity_units AwsDynamodbGlobalSecondaryIndex#write_capacity_units}
        */
        readonly writeCapacityUnits?: number;
    }
    class ProvisionedThroughputPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ProvisionedThroughputProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ProvisionedThroughputProperty | cdktn.IResolvable | undefined);
        private _readCapacityUnits?;
        get readCapacityUnits(): number;
        set readCapacityUnits(value: number);
        resetReadCapacityUnits(): void;
        get readCapacityUnitsInput(): number | undefined;
        private _writeCapacityUnits?;
        get writeCapacityUnits(): number;
        set writeCapacityUnits(value: number);
        resetWriteCapacityUnits(): void;
        get writeCapacityUnitsInput(): number | undefined;
    }
    class ProvisionedThroughputPropertyList extends cdktn.ComplexList {
        internalValue?: ProvisionedThroughputProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ProvisionedThroughputPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_global_secondary_index#create AwsDynamodbGlobalSecondaryIndex#create}
        */
        readonly create?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Setting a timeout for a Delete operation is only applicable if changes are saved into state before the destroy operation occurs.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_global_secondary_index#delete AwsDynamodbGlobalSecondaryIndex#delete}
        */
        readonly delete?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_global_secondary_index#update AwsDynamodbGlobalSecondaryIndex#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
