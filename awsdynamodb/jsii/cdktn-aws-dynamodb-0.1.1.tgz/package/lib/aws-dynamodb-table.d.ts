import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsDynamodbTableConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_table#billing_mode AwsDynamodbTable#billing_mode}
    */
    readonly billingMode?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_table#deletion_protection_enabled AwsDynamodbTable#deletion_protection_enabled}
    */
    readonly deletionProtectionEnabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_table#hash_key AwsDynamodbTable#hash_key}
    */
    readonly hashKey?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_table#id AwsDynamodbTable#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_table#name AwsDynamodbTable#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_table#range_key AwsDynamodbTable#range_key}
    */
    readonly rangeKey?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_table#read_capacity AwsDynamodbTable#read_capacity}
    */
    readonly readCapacity?: number;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_table#region AwsDynamodbTable#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_table#restore_backup_arn AwsDynamodbTable#restore_backup_arn}
    */
    readonly restoreBackupArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_table#restore_date_time AwsDynamodbTable#restore_date_time}
    */
    readonly restoreDateTime?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_table#restore_source_name AwsDynamodbTable#restore_source_name}
    */
    readonly restoreSourceName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_table#restore_source_table_arn AwsDynamodbTable#restore_source_table_arn}
    */
    readonly restoreSourceTableArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_table#restore_to_latest_time AwsDynamodbTable#restore_to_latest_time}
    */
    readonly restoreToLatestTime?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_table#stream_enabled AwsDynamodbTable#stream_enabled}
    */
    readonly streamEnabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_table#stream_view_type AwsDynamodbTable#stream_view_type}
    */
    readonly streamViewType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_table#table_class AwsDynamodbTable#table_class}
    */
    readonly tableClass?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_table#tags AwsDynamodbTable#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_table#tags_all AwsDynamodbTable#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_table#write_capacity AwsDynamodbTable#write_capacity}
    */
    readonly writeCapacity?: number;
    /**
    * attribute block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_table#attribute AwsDynamodbTable#attribute}
    */
    readonly attribute?: AwsDynamodbTable.AttributeProperty[] | cdktn.IResolvable;
    /**
    * global_secondary_index block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_table#global_secondary_index AwsDynamodbTable#global_secondary_index}
    */
    readonly globalSecondaryIndex?: AwsDynamodbTable.GlobalSecondaryIndexProperty[] | cdktn.IResolvable;
    /**
    * global_table_witness block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_table#global_table_witness AwsDynamodbTable#global_table_witness}
    */
    readonly globalTableWitness?: AwsDynamodbTable.GlobalTableWitnessProperty;
    /**
    * import_table block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_table#import_table AwsDynamodbTable#import_table}
    */
    readonly importTable?: AwsDynamodbTable.ImportTableProperty;
    /**
    * local_secondary_index block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_table#local_secondary_index AwsDynamodbTable#local_secondary_index}
    */
    readonly localSecondaryIndex?: AwsDynamodbTable.LocalSecondaryIndexProperty[] | cdktn.IResolvable;
    /**
    * on_demand_throughput block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_table#on_demand_throughput AwsDynamodbTable#on_demand_throughput}
    */
    readonly onDemandThroughput?: AwsDynamodbTable.OnDemandThroughputProperty;
    /**
    * point_in_time_recovery block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_table#point_in_time_recovery AwsDynamodbTable#point_in_time_recovery}
    */
    readonly pointInTimeRecovery?: AwsDynamodbTable.PointInTimeRecoveryProperty;
    /**
    * replica block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_table#replica AwsDynamodbTable#replica}
    */
    readonly replica?: AwsDynamodbTable.ReplicaProperty[] | cdktn.IResolvable;
    /**
    * server_side_encryption block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_table#server_side_encryption AwsDynamodbTable#server_side_encryption}
    */
    readonly serverSideEncryption?: AwsDynamodbTable.ServerSideEncryptionProperty;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_table#timeouts AwsDynamodbTable#timeouts}
    */
    readonly timeouts?: AwsDynamodbTable.TimeoutsProperty;
    /**
    * ttl block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_table#ttl AwsDynamodbTable#ttl}
    */
    readonly ttl?: AwsDynamodbTable.TtlProperty;
    /**
    * warm_throughput block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_table#warm_throughput AwsDynamodbTable#warm_throughput}
    */
    readonly warmThroughput?: AwsDynamodbTable.WarmThroughputProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_table aws_dynamodb_table}
*/
export declare class AwsDynamodbTable extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_dynamodb_table";
    /**
    * Generates CDKTN code for importing a AwsDynamodbTable resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsDynamodbTable to import
    * @param importFromId The id of the existing AwsDynamodbTable that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_table#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsDynamodbTable to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_table aws_dynamodb_table} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsDynamodbTableConfig
    */
    constructor(scope: Construct, id: string, config: AwsDynamodbTableConfig);
    get arn(): string;
    private _billingMode?;
    get billingMode(): string;
    set billingMode(value: string);
    resetBillingMode(): void;
    get billingModeInput(): string | undefined;
    private _deletionProtectionEnabled?;
    get deletionProtectionEnabled(): boolean | cdktn.IResolvable;
    set deletionProtectionEnabled(value: boolean | cdktn.IResolvable);
    resetDeletionProtectionEnabled(): void;
    get deletionProtectionEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _hashKey?;
    get hashKey(): string;
    set hashKey(value: string);
    resetHashKey(): void;
    get hashKeyInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _rangeKey?;
    get rangeKey(): string;
    set rangeKey(value: string);
    resetRangeKey(): void;
    get rangeKeyInput(): string | undefined;
    private _readCapacity?;
    get readCapacity(): number;
    set readCapacity(value: number);
    resetReadCapacity(): void;
    get readCapacityInput(): number | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _restoreBackupArn?;
    get restoreBackupArn(): string;
    set restoreBackupArn(value: string);
    resetRestoreBackupArn(): void;
    get restoreBackupArnInput(): string | undefined;
    private _restoreDateTime?;
    get restoreDateTime(): string;
    set restoreDateTime(value: string);
    resetRestoreDateTime(): void;
    get restoreDateTimeInput(): string | undefined;
    private _restoreSourceName?;
    get restoreSourceName(): string;
    set restoreSourceName(value: string);
    resetRestoreSourceName(): void;
    get restoreSourceNameInput(): string | undefined;
    private _restoreSourceTableArn?;
    get restoreSourceTableArn(): string;
    set restoreSourceTableArn(value: string);
    resetRestoreSourceTableArn(): void;
    get restoreSourceTableArnInput(): string | undefined;
    private _restoreToLatestTime?;
    get restoreToLatestTime(): boolean | cdktn.IResolvable;
    set restoreToLatestTime(value: boolean | cdktn.IResolvable);
    resetRestoreToLatestTime(): void;
    get restoreToLatestTimeInput(): boolean | cdktn.IResolvable | undefined;
    get streamArn(): string;
    private _streamEnabled?;
    get streamEnabled(): boolean | cdktn.IResolvable;
    set streamEnabled(value: boolean | cdktn.IResolvable);
    resetStreamEnabled(): void;
    get streamEnabledInput(): boolean | cdktn.IResolvable | undefined;
    get streamLabel(): string;
    private _streamViewType?;
    get streamViewType(): string;
    set streamViewType(value: string);
    resetStreamViewType(): void;
    get streamViewTypeInput(): string | undefined;
    private _tableClass?;
    get tableClass(): string;
    set tableClass(value: string);
    resetTableClass(): void;
    get tableClassInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _writeCapacity?;
    get writeCapacity(): number;
    set writeCapacity(value: number);
    resetWriteCapacity(): void;
    get writeCapacityInput(): number | undefined;
    private _attribute;
    get attribute(): AwsDynamodbTable.AttributePropertyList;
    putAttribute(value: AwsDynamodbTable.AttributeProperty[] | cdktn.IResolvable): void;
    resetAttribute(): void;
    get attributeInput(): cdktn.IResolvable | AwsDynamodbTable.AttributeProperty[] | undefined;
    private _globalSecondaryIndex;
    get globalSecondaryIndex(): AwsDynamodbTable.GlobalSecondaryIndexPropertyList;
    putGlobalSecondaryIndex(value: AwsDynamodbTable.GlobalSecondaryIndexProperty[] | cdktn.IResolvable): void;
    resetGlobalSecondaryIndex(): void;
    get globalSecondaryIndexInput(): cdktn.IResolvable | AwsDynamodbTable.GlobalSecondaryIndexProperty[] | undefined;
    private _globalTableWitness;
    get globalTableWitness(): AwsDynamodbTable.GlobalTableWitnessPropertyOutputReference;
    putGlobalTableWitness(value: AwsDynamodbTable.GlobalTableWitnessProperty): void;
    resetGlobalTableWitness(): void;
    get globalTableWitnessInput(): AwsDynamodbTable.GlobalTableWitnessProperty | undefined;
    private _importTable;
    get importTable(): AwsDynamodbTable.ImportTablePropertyOutputReference;
    putImportTable(value: AwsDynamodbTable.ImportTableProperty): void;
    resetImportTable(): void;
    get importTableInput(): AwsDynamodbTable.ImportTableProperty | undefined;
    private _localSecondaryIndex;
    get localSecondaryIndex(): AwsDynamodbTable.LocalSecondaryIndexPropertyList;
    putLocalSecondaryIndex(value: AwsDynamodbTable.LocalSecondaryIndexProperty[] | cdktn.IResolvable): void;
    resetLocalSecondaryIndex(): void;
    get localSecondaryIndexInput(): cdktn.IResolvable | AwsDynamodbTable.LocalSecondaryIndexProperty[] | undefined;
    private _onDemandThroughput;
    get onDemandThroughput(): AwsDynamodbTable.OnDemandThroughputPropertyOutputReference;
    putOnDemandThroughput(value: AwsDynamodbTable.OnDemandThroughputProperty): void;
    resetOnDemandThroughput(): void;
    get onDemandThroughputInput(): AwsDynamodbTable.OnDemandThroughputProperty | undefined;
    private _pointInTimeRecovery;
    get pointInTimeRecovery(): AwsDynamodbTable.PointInTimeRecoveryPropertyOutputReference;
    putPointInTimeRecovery(value: AwsDynamodbTable.PointInTimeRecoveryProperty): void;
    resetPointInTimeRecovery(): void;
    get pointInTimeRecoveryInput(): AwsDynamodbTable.PointInTimeRecoveryProperty | undefined;
    private _replica;
    get replica(): AwsDynamodbTable.ReplicaPropertyList;
    putReplica(value: AwsDynamodbTable.ReplicaProperty[] | cdktn.IResolvable): void;
    resetReplica(): void;
    get replicaInput(): cdktn.IResolvable | AwsDynamodbTable.ReplicaProperty[] | undefined;
    private _serverSideEncryption;
    get serverSideEncryption(): AwsDynamodbTable.ServerSideEncryptionPropertyOutputReference;
    putServerSideEncryption(value: AwsDynamodbTable.ServerSideEncryptionProperty): void;
    resetServerSideEncryption(): void;
    get serverSideEncryptionInput(): AwsDynamodbTable.ServerSideEncryptionProperty | undefined;
    private _timeouts;
    get timeouts(): AwsDynamodbTable.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsDynamodbTable.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsDynamodbTable.TimeoutsProperty | undefined;
    private _ttl;
    get ttl(): AwsDynamodbTable.TtlPropertyOutputReference;
    putTtl(value: AwsDynamodbTable.TtlProperty): void;
    resetTtl(): void;
    get ttlInput(): AwsDynamodbTable.TtlProperty | undefined;
    private _warmThroughput;
    get warmThroughput(): AwsDynamodbTable.WarmThroughputPropertyOutputReference;
    putWarmThroughput(value: AwsDynamodbTable.WarmThroughputProperty): void;
    resetWarmThroughput(): void;
    get warmThroughputInput(): AwsDynamodbTable.WarmThroughputProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsDynamodbTableAttributePropertyToTerraform(struct?: AwsDynamodbTable.AttributeProperty | cdktn.IResolvable): any;
export declare function awsDynamodbTableAttributePropertyToHclTerraform(struct?: AwsDynamodbTable.AttributeProperty | cdktn.IResolvable): any;
export declare function awsDynamodbTableKeySchemaPropertyToTerraform(struct?: AwsDynamodbTable.KeySchemaProperty | cdktn.IResolvable): any;
export declare function awsDynamodbTableKeySchemaPropertyToHclTerraform(struct?: AwsDynamodbTable.KeySchemaProperty | cdktn.IResolvable): any;
export declare function awsDynamodbTableGlobalSecondaryIndexOnDemandThroughputPropertyToTerraform(struct?: AwsDynamodbTable.GlobalSecondaryIndexOnDemandThroughputPropertyOutputReference | AwsDynamodbTable.GlobalSecondaryIndexOnDemandThroughputProperty): any;
export declare function awsDynamodbTableGlobalSecondaryIndexOnDemandThroughputPropertyToHclTerraform(struct?: AwsDynamodbTable.GlobalSecondaryIndexOnDemandThroughputPropertyOutputReference | AwsDynamodbTable.GlobalSecondaryIndexOnDemandThroughputProperty): any;
export declare function awsDynamodbTableGlobalSecondaryIndexWarmThroughputPropertyToTerraform(struct?: AwsDynamodbTable.GlobalSecondaryIndexWarmThroughputPropertyOutputReference | AwsDynamodbTable.GlobalSecondaryIndexWarmThroughputProperty): any;
export declare function awsDynamodbTableGlobalSecondaryIndexWarmThroughputPropertyToHclTerraform(struct?: AwsDynamodbTable.GlobalSecondaryIndexWarmThroughputPropertyOutputReference | AwsDynamodbTable.GlobalSecondaryIndexWarmThroughputProperty): any;
export declare function awsDynamodbTableGlobalSecondaryIndexPropertyToTerraform(struct?: AwsDynamodbTable.GlobalSecondaryIndexProperty | cdktn.IResolvable): any;
export declare function awsDynamodbTableGlobalSecondaryIndexPropertyToHclTerraform(struct?: AwsDynamodbTable.GlobalSecondaryIndexProperty | cdktn.IResolvable): any;
export declare function awsDynamodbTableGlobalTableWitnessPropertyToTerraform(struct?: AwsDynamodbTable.GlobalTableWitnessPropertyOutputReference | AwsDynamodbTable.GlobalTableWitnessProperty): any;
export declare function awsDynamodbTableGlobalTableWitnessPropertyToHclTerraform(struct?: AwsDynamodbTable.GlobalTableWitnessPropertyOutputReference | AwsDynamodbTable.GlobalTableWitnessProperty): any;
export declare function awsDynamodbTableCsvPropertyToTerraform(struct?: AwsDynamodbTable.CsvPropertyOutputReference | AwsDynamodbTable.CsvProperty): any;
export declare function awsDynamodbTableCsvPropertyToHclTerraform(struct?: AwsDynamodbTable.CsvPropertyOutputReference | AwsDynamodbTable.CsvProperty): any;
export declare function awsDynamodbTableInputFormatOptionsPropertyToTerraform(struct?: AwsDynamodbTable.InputFormatOptionsPropertyOutputReference | AwsDynamodbTable.InputFormatOptionsProperty): any;
export declare function awsDynamodbTableInputFormatOptionsPropertyToHclTerraform(struct?: AwsDynamodbTable.InputFormatOptionsPropertyOutputReference | AwsDynamodbTable.InputFormatOptionsProperty): any;
export declare function awsDynamodbTableS3BucketSourcePropertyToTerraform(struct?: AwsDynamodbTable.S3BucketSourcePropertyOutputReference | AwsDynamodbTable.S3BucketSourceProperty): any;
export declare function awsDynamodbTableS3BucketSourcePropertyToHclTerraform(struct?: AwsDynamodbTable.S3BucketSourcePropertyOutputReference | AwsDynamodbTable.S3BucketSourceProperty): any;
export declare function awsDynamodbTableImportTablePropertyToTerraform(struct?: AwsDynamodbTable.ImportTablePropertyOutputReference | AwsDynamodbTable.ImportTableProperty): any;
export declare function awsDynamodbTableImportTablePropertyToHclTerraform(struct?: AwsDynamodbTable.ImportTablePropertyOutputReference | AwsDynamodbTable.ImportTableProperty): any;
export declare function awsDynamodbTableLocalSecondaryIndexPropertyToTerraform(struct?: AwsDynamodbTable.LocalSecondaryIndexProperty | cdktn.IResolvable): any;
export declare function awsDynamodbTableLocalSecondaryIndexPropertyToHclTerraform(struct?: AwsDynamodbTable.LocalSecondaryIndexProperty | cdktn.IResolvable): any;
export declare function awsDynamodbTableOnDemandThroughputPropertyToTerraform(struct?: AwsDynamodbTable.OnDemandThroughputPropertyOutputReference | AwsDynamodbTable.OnDemandThroughputProperty): any;
export declare function awsDynamodbTableOnDemandThroughputPropertyToHclTerraform(struct?: AwsDynamodbTable.OnDemandThroughputPropertyOutputReference | AwsDynamodbTable.OnDemandThroughputProperty): any;
export declare function awsDynamodbTablePointInTimeRecoveryPropertyToTerraform(struct?: AwsDynamodbTable.PointInTimeRecoveryPropertyOutputReference | AwsDynamodbTable.PointInTimeRecoveryProperty): any;
export declare function awsDynamodbTablePointInTimeRecoveryPropertyToHclTerraform(struct?: AwsDynamodbTable.PointInTimeRecoveryPropertyOutputReference | AwsDynamodbTable.PointInTimeRecoveryProperty): any;
export declare function awsDynamodbTableReplicaPropertyToTerraform(struct?: AwsDynamodbTable.ReplicaProperty | cdktn.IResolvable): any;
export declare function awsDynamodbTableReplicaPropertyToHclTerraform(struct?: AwsDynamodbTable.ReplicaProperty | cdktn.IResolvable): any;
export declare function awsDynamodbTableServerSideEncryptionPropertyToTerraform(struct?: AwsDynamodbTable.ServerSideEncryptionPropertyOutputReference | AwsDynamodbTable.ServerSideEncryptionProperty): any;
export declare function awsDynamodbTableServerSideEncryptionPropertyToHclTerraform(struct?: AwsDynamodbTable.ServerSideEncryptionPropertyOutputReference | AwsDynamodbTable.ServerSideEncryptionProperty): any;
export declare function awsDynamodbTableTimeoutsPropertyToTerraform(struct?: AwsDynamodbTable.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsDynamodbTableTimeoutsPropertyToHclTerraform(struct?: AwsDynamodbTable.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsDynamodbTableTtlPropertyToTerraform(struct?: AwsDynamodbTable.TtlPropertyOutputReference | AwsDynamodbTable.TtlProperty): any;
export declare function awsDynamodbTableTtlPropertyToHclTerraform(struct?: AwsDynamodbTable.TtlPropertyOutputReference | AwsDynamodbTable.TtlProperty): any;
export declare function awsDynamodbTableWarmThroughputPropertyToTerraform(struct?: AwsDynamodbTable.WarmThroughputPropertyOutputReference | AwsDynamodbTable.WarmThroughputProperty): any;
export declare function awsDynamodbTableWarmThroughputPropertyToHclTerraform(struct?: AwsDynamodbTable.WarmThroughputPropertyOutputReference | AwsDynamodbTable.WarmThroughputProperty): any;
export declare namespace AwsDynamodbTable {
    interface AttributeProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_table#name AwsDynamodbTable#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_table#type AwsDynamodbTable#type}
        */
        readonly type: string;
    }
    class AttributePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AttributeProperty | cdktn.IResolvable | undefined;
        set internalValue(value: AttributeProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
    }
    class AttributePropertyList extends cdktn.ComplexList {
        internalValue?: AttributeProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AttributePropertyOutputReference;
    }
    interface KeySchemaProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_table#attribute_name AwsDynamodbTable#attribute_name}
        */
        readonly attributeName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_table#key_type AwsDynamodbTable#key_type}
        */
        readonly keyType: string;
    }
    class KeySchemaPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): KeySchemaProperty | cdktn.IResolvable | undefined;
        set internalValue(value: KeySchemaProperty | cdktn.IResolvable | undefined);
        private _attributeName?;
        get attributeName(): string;
        set attributeName(value: string);
        get attributeNameInput(): string | undefined;
        private _keyType?;
        get keyType(): string;
        set keyType(value: string);
        get keyTypeInput(): string | undefined;
    }
    class KeySchemaPropertyList extends cdktn.ComplexList {
        internalValue?: KeySchemaProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): KeySchemaPropertyOutputReference;
    }
    interface GlobalSecondaryIndexOnDemandThroughputProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_table#max_read_request_units AwsDynamodbTable#max_read_request_units}
        */
        readonly maxReadRequestUnits?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_table#max_write_request_units AwsDynamodbTable#max_write_request_units}
        */
        readonly maxWriteRequestUnits?: number;
    }
    class GlobalSecondaryIndexOnDemandThroughputPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): GlobalSecondaryIndexOnDemandThroughputProperty | undefined;
        set internalValue(value: GlobalSecondaryIndexOnDemandThroughputProperty | undefined);
        private _maxReadRequestUnits?;
        get maxReadRequestUnits(): number;
        set maxReadRequestUnits(value: number);
        resetMaxReadRequestUnits(): void;
        get maxReadRequestUnitsInput(): number | undefined;
        private _maxWriteRequestUnits?;
        get maxWriteRequestUnits(): number;
        set maxWriteRequestUnits(value: number);
        resetMaxWriteRequestUnits(): void;
        get maxWriteRequestUnitsInput(): number | undefined;
    }
    interface GlobalSecondaryIndexWarmThroughputProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_table#read_units_per_second AwsDynamodbTable#read_units_per_second}
        */
        readonly readUnitsPerSecond?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_table#write_units_per_second AwsDynamodbTable#write_units_per_second}
        */
        readonly writeUnitsPerSecond?: number;
    }
    class GlobalSecondaryIndexWarmThroughputPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): GlobalSecondaryIndexWarmThroughputProperty | undefined;
        set internalValue(value: GlobalSecondaryIndexWarmThroughputProperty | undefined);
        private _readUnitsPerSecond?;
        get readUnitsPerSecond(): number;
        set readUnitsPerSecond(value: number);
        resetReadUnitsPerSecond(): void;
        get readUnitsPerSecondInput(): number | undefined;
        private _writeUnitsPerSecond?;
        get writeUnitsPerSecond(): number;
        set writeUnitsPerSecond(value: number);
        resetWriteUnitsPerSecond(): void;
        get writeUnitsPerSecondInput(): number | undefined;
    }
    interface GlobalSecondaryIndexProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_table#hash_key AwsDynamodbTable#hash_key}
        */
        readonly hashKey?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_table#name AwsDynamodbTable#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_table#non_key_attributes AwsDynamodbTable#non_key_attributes}
        */
        readonly nonKeyAttributes?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_table#projection_type AwsDynamodbTable#projection_type}
        */
        readonly projectionType: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_table#range_key AwsDynamodbTable#range_key}
        */
        readonly rangeKey?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_table#read_capacity AwsDynamodbTable#read_capacity}
        */
        readonly readCapacity?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_table#write_capacity AwsDynamodbTable#write_capacity}
        */
        readonly writeCapacity?: number;
        /**
        * key_schema block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_table#key_schema AwsDynamodbTable#key_schema}
        */
        readonly keySchema?: KeySchemaProperty[] | cdktn.IResolvable;
        /**
        * on_demand_throughput block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_table#on_demand_throughput AwsDynamodbTable#on_demand_throughput}
        */
        readonly onDemandThroughput?: GlobalSecondaryIndexOnDemandThroughputProperty;
        /**
        * warm_throughput block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_table#warm_throughput AwsDynamodbTable#warm_throughput}
        */
        readonly warmThroughput?: GlobalSecondaryIndexWarmThroughputProperty;
    }
    class GlobalSecondaryIndexPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): GlobalSecondaryIndexProperty | cdktn.IResolvable | undefined;
        set internalValue(value: GlobalSecondaryIndexProperty | cdktn.IResolvable | undefined);
        private _hashKey?;
        get hashKey(): string;
        set hashKey(value: string);
        resetHashKey(): void;
        get hashKeyInput(): string | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _nonKeyAttributes?;
        get nonKeyAttributes(): string[];
        set nonKeyAttributes(value: string[]);
        resetNonKeyAttributes(): void;
        get nonKeyAttributesInput(): string[] | undefined;
        private _projectionType?;
        get projectionType(): string;
        set projectionType(value: string);
        get projectionTypeInput(): string | undefined;
        private _rangeKey?;
        get rangeKey(): string;
        set rangeKey(value: string);
        resetRangeKey(): void;
        get rangeKeyInput(): string | undefined;
        private _readCapacity?;
        get readCapacity(): number;
        set readCapacity(value: number);
        resetReadCapacity(): void;
        get readCapacityInput(): number | undefined;
        private _writeCapacity?;
        get writeCapacity(): number;
        set writeCapacity(value: number);
        resetWriteCapacity(): void;
        get writeCapacityInput(): number | undefined;
        private _keySchema;
        get keySchema(): KeySchemaPropertyList;
        putKeySchema(value: KeySchemaProperty[] | cdktn.IResolvable): void;
        resetKeySchema(): void;
        get keySchemaInput(): cdktn.IResolvable | KeySchemaProperty[] | undefined;
        private _onDemandThroughput;
        get onDemandThroughput(): GlobalSecondaryIndexOnDemandThroughputPropertyOutputReference;
        putOnDemandThroughput(value: GlobalSecondaryIndexOnDemandThroughputProperty): void;
        resetOnDemandThroughput(): void;
        get onDemandThroughputInput(): GlobalSecondaryIndexOnDemandThroughputProperty | undefined;
        private _warmThroughput;
        get warmThroughput(): GlobalSecondaryIndexWarmThroughputPropertyOutputReference;
        putWarmThroughput(value: GlobalSecondaryIndexWarmThroughputProperty): void;
        resetWarmThroughput(): void;
        get warmThroughputInput(): GlobalSecondaryIndexWarmThroughputProperty | undefined;
    }
    class GlobalSecondaryIndexPropertyList extends cdktn.ComplexList {
        internalValue?: GlobalSecondaryIndexProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): GlobalSecondaryIndexPropertyOutputReference;
    }
    interface GlobalTableWitnessProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_table#region_name AwsDynamodbTable#region_name}
        */
        readonly regionName?: string;
    }
    class GlobalTableWitnessPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): GlobalTableWitnessProperty | undefined;
        set internalValue(value: GlobalTableWitnessProperty | undefined);
        private _regionName?;
        get regionName(): string;
        set regionName(value: string);
        resetRegionName(): void;
        get regionNameInput(): string | undefined;
    }
    interface CsvProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_table#delimiter AwsDynamodbTable#delimiter}
        */
        readonly delimiter?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_table#header_list AwsDynamodbTable#header_list}
        */
        readonly headerList?: string[];
    }
    class CsvPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CsvProperty | undefined;
        set internalValue(value: CsvProperty | undefined);
        private _delimiter?;
        get delimiter(): string;
        set delimiter(value: string);
        resetDelimiter(): void;
        get delimiterInput(): string | undefined;
        private _headerList?;
        get headerList(): string[];
        set headerList(value: string[]);
        resetHeaderList(): void;
        get headerListInput(): string[] | undefined;
    }
    interface InputFormatOptionsProperty {
        /**
        * csv block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_table#csv AwsDynamodbTable#csv}
        */
        readonly csv?: CsvProperty;
    }
    class InputFormatOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): InputFormatOptionsProperty | undefined;
        set internalValue(value: InputFormatOptionsProperty | undefined);
        private _csv;
        get csv(): CsvPropertyOutputReference;
        putCsv(value: CsvProperty): void;
        resetCsv(): void;
        get csvInput(): CsvProperty | undefined;
    }
    interface S3BucketSourceProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_table#bucket AwsDynamodbTable#bucket}
        */
        readonly bucket: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_table#bucket_owner AwsDynamodbTable#bucket_owner}
        */
        readonly bucketOwner?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_table#key_prefix AwsDynamodbTable#key_prefix}
        */
        readonly keyPrefix?: string;
    }
    class S3BucketSourcePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): S3BucketSourceProperty | undefined;
        set internalValue(value: S3BucketSourceProperty | undefined);
        private _bucket?;
        get bucket(): string;
        set bucket(value: string);
        get bucketInput(): string | undefined;
        private _bucketOwner?;
        get bucketOwner(): string;
        set bucketOwner(value: string);
        resetBucketOwner(): void;
        get bucketOwnerInput(): string | undefined;
        private _keyPrefix?;
        get keyPrefix(): string;
        set keyPrefix(value: string);
        resetKeyPrefix(): void;
        get keyPrefixInput(): string | undefined;
    }
    interface ImportTableProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_table#input_compression_type AwsDynamodbTable#input_compression_type}
        */
        readonly inputCompressionType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_table#input_format AwsDynamodbTable#input_format}
        */
        readonly inputFormat: string;
        /**
        * input_format_options block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_table#input_format_options AwsDynamodbTable#input_format_options}
        */
        readonly inputFormatOptions?: InputFormatOptionsProperty;
        /**
        * s3_bucket_source block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_table#s3_bucket_source AwsDynamodbTable#s3_bucket_source}
        */
        readonly s3BucketSource: S3BucketSourceProperty;
    }
    class ImportTablePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ImportTableProperty | undefined;
        set internalValue(value: ImportTableProperty | undefined);
        private _inputCompressionType?;
        get inputCompressionType(): string;
        set inputCompressionType(value: string);
        resetInputCompressionType(): void;
        get inputCompressionTypeInput(): string | undefined;
        private _inputFormat?;
        get inputFormat(): string;
        set inputFormat(value: string);
        get inputFormatInput(): string | undefined;
        private _inputFormatOptions;
        get inputFormatOptions(): InputFormatOptionsPropertyOutputReference;
        putInputFormatOptions(value: InputFormatOptionsProperty): void;
        resetInputFormatOptions(): void;
        get inputFormatOptionsInput(): InputFormatOptionsProperty | undefined;
        private _s3BucketSource;
        get s3BucketSource(): S3BucketSourcePropertyOutputReference;
        putS3BucketSource(value: S3BucketSourceProperty): void;
        get s3BucketSourceInput(): S3BucketSourceProperty | undefined;
    }
    interface LocalSecondaryIndexProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_table#name AwsDynamodbTable#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_table#non_key_attributes AwsDynamodbTable#non_key_attributes}
        */
        readonly nonKeyAttributes?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_table#projection_type AwsDynamodbTable#projection_type}
        */
        readonly projectionType: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_table#range_key AwsDynamodbTable#range_key}
        */
        readonly rangeKey: string;
    }
    class LocalSecondaryIndexPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): LocalSecondaryIndexProperty | cdktn.IResolvable | undefined;
        set internalValue(value: LocalSecondaryIndexProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _nonKeyAttributes?;
        get nonKeyAttributes(): string[];
        set nonKeyAttributes(value: string[]);
        resetNonKeyAttributes(): void;
        get nonKeyAttributesInput(): string[] | undefined;
        private _projectionType?;
        get projectionType(): string;
        set projectionType(value: string);
        get projectionTypeInput(): string | undefined;
        private _rangeKey?;
        get rangeKey(): string;
        set rangeKey(value: string);
        get rangeKeyInput(): string | undefined;
    }
    class LocalSecondaryIndexPropertyList extends cdktn.ComplexList {
        internalValue?: LocalSecondaryIndexProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): LocalSecondaryIndexPropertyOutputReference;
    }
    interface OnDemandThroughputProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_table#max_read_request_units AwsDynamodbTable#max_read_request_units}
        */
        readonly maxReadRequestUnits?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_table#max_write_request_units AwsDynamodbTable#max_write_request_units}
        */
        readonly maxWriteRequestUnits?: number;
    }
    class OnDemandThroughputPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): OnDemandThroughputProperty | undefined;
        set internalValue(value: OnDemandThroughputProperty | undefined);
        private _maxReadRequestUnits?;
        get maxReadRequestUnits(): number;
        set maxReadRequestUnits(value: number);
        resetMaxReadRequestUnits(): void;
        get maxReadRequestUnitsInput(): number | undefined;
        private _maxWriteRequestUnits?;
        get maxWriteRequestUnits(): number;
        set maxWriteRequestUnits(value: number);
        resetMaxWriteRequestUnits(): void;
        get maxWriteRequestUnitsInput(): number | undefined;
    }
    interface PointInTimeRecoveryProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_table#enabled AwsDynamodbTable#enabled}
        */
        readonly enabled: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_table#recovery_period_in_days AwsDynamodbTable#recovery_period_in_days}
        */
        readonly recoveryPeriodInDays?: number;
    }
    class PointInTimeRecoveryPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): PointInTimeRecoveryProperty | undefined;
        set internalValue(value: PointInTimeRecoveryProperty | undefined);
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
        private _recoveryPeriodInDays?;
        get recoveryPeriodInDays(): number;
        set recoveryPeriodInDays(value: number);
        resetRecoveryPeriodInDays(): void;
        get recoveryPeriodInDaysInput(): number | undefined;
    }
    interface ReplicaProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_table#consistency_mode AwsDynamodbTable#consistency_mode}
        */
        readonly consistencyMode?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_table#deletion_protection_enabled AwsDynamodbTable#deletion_protection_enabled}
        */
        readonly deletionProtectionEnabled?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_table#kms_key_arn AwsDynamodbTable#kms_key_arn}
        */
        readonly kmsKeyArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_table#point_in_time_recovery AwsDynamodbTable#point_in_time_recovery}
        */
        readonly pointInTimeRecovery?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_table#propagate_tags AwsDynamodbTable#propagate_tags}
        */
        readonly propagateTags?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_table#region_name AwsDynamodbTable#region_name}
        */
        readonly regionName: string;
    }
    class ReplicaPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ReplicaProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ReplicaProperty | cdktn.IResolvable | undefined);
        get arn(): string;
        private _consistencyMode?;
        get consistencyMode(): string;
        set consistencyMode(value: string);
        resetConsistencyMode(): void;
        get consistencyModeInput(): string | undefined;
        private _deletionProtectionEnabled?;
        get deletionProtectionEnabled(): boolean | cdktn.IResolvable;
        set deletionProtectionEnabled(value: boolean | cdktn.IResolvable);
        resetDeletionProtectionEnabled(): void;
        get deletionProtectionEnabledInput(): boolean | cdktn.IResolvable | undefined;
        private _kmsKeyArn?;
        get kmsKeyArn(): string;
        set kmsKeyArn(value: string);
        resetKmsKeyArn(): void;
        get kmsKeyArnInput(): string | undefined;
        private _pointInTimeRecovery?;
        get pointInTimeRecovery(): boolean | cdktn.IResolvable;
        set pointInTimeRecovery(value: boolean | cdktn.IResolvable);
        resetPointInTimeRecovery(): void;
        get pointInTimeRecoveryInput(): boolean | cdktn.IResolvable | undefined;
        private _propagateTags?;
        get propagateTags(): boolean | cdktn.IResolvable;
        set propagateTags(value: boolean | cdktn.IResolvable);
        resetPropagateTags(): void;
        get propagateTagsInput(): boolean | cdktn.IResolvable | undefined;
        private _regionName?;
        get regionName(): string;
        set regionName(value: string);
        get regionNameInput(): string | undefined;
        get streamArn(): string;
        get streamLabel(): string;
    }
    class ReplicaPropertyList extends cdktn.ComplexList {
        internalValue?: ReplicaProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ReplicaPropertyOutputReference;
    }
    interface ServerSideEncryptionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_table#enabled AwsDynamodbTable#enabled}
        */
        readonly enabled: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_table#kms_key_arn AwsDynamodbTable#kms_key_arn}
        */
        readonly kmsKeyArn?: string;
    }
    class ServerSideEncryptionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ServerSideEncryptionProperty | undefined;
        set internalValue(value: ServerSideEncryptionProperty | undefined);
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
        private _kmsKeyArn?;
        get kmsKeyArn(): string;
        set kmsKeyArn(value: string);
        resetKmsKeyArn(): void;
        get kmsKeyArnInput(): string | undefined;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_table#create AwsDynamodbTable#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_table#delete AwsDynamodbTable#delete}
        */
        readonly delete?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_table#update AwsDynamodbTable#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
    interface TtlProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_table#attribute_name AwsDynamodbTable#attribute_name}
        */
        readonly attributeName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_table#enabled AwsDynamodbTable#enabled}
        */
        readonly enabled?: boolean | cdktn.IResolvable;
    }
    class TtlPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TtlProperty | undefined;
        set internalValue(value: TtlProperty | undefined);
        private _attributeName?;
        get attributeName(): string;
        set attributeName(value: string);
        resetAttributeName(): void;
        get attributeNameInput(): string | undefined;
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        resetEnabled(): void;
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface WarmThroughputProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_table#read_units_per_second AwsDynamodbTable#read_units_per_second}
        */
        readonly readUnitsPerSecond?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_table#write_units_per_second AwsDynamodbTable#write_units_per_second}
        */
        readonly writeUnitsPerSecond?: number;
    }
    class WarmThroughputPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): WarmThroughputProperty | undefined;
        set internalValue(value: WarmThroughputProperty | undefined);
        private _readUnitsPerSecond?;
        get readUnitsPerSecond(): number;
        set readUnitsPerSecond(value: number);
        resetReadUnitsPerSecond(): void;
        get readUnitsPerSecondInput(): number | undefined;
        private _writeUnitsPerSecond?;
        get writeUnitsPerSecond(): number;
        set writeUnitsPerSecond(value: number);
        resetWriteUnitsPerSecond(): void;
        get writeUnitsPerSecondInput(): number | undefined;
    }
}
