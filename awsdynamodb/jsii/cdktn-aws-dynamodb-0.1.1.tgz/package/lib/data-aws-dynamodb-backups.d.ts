import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsDynamodbBackupsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/dynamodb_backups#backup_type DataAwsDynamodbBackups#backup_type}
    */
    readonly backupType?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/dynamodb_backups#region DataAwsDynamodbBackups#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/dynamodb_backups#table_name DataAwsDynamodbBackups#table_name}
    */
    readonly tableName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/dynamodb_backups#time_range_lower_bound DataAwsDynamodbBackups#time_range_lower_bound}
    */
    readonly timeRangeLowerBound?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/dynamodb_backups#time_range_upper_bound DataAwsDynamodbBackups#time_range_upper_bound}
    */
    readonly timeRangeUpperBound?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/dynamodb_backups aws_dynamodb_backups}
*/
export declare class DataAwsDynamodbBackups extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_dynamodb_backups";
    /**
    * Generates CDKTN code for importing a DataAwsDynamodbBackups resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsDynamodbBackups to import
    * @param importFromId The id of the existing DataAwsDynamodbBackups that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/dynamodb_backups#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsDynamodbBackups to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/dynamodb_backups aws_dynamodb_backups} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsDynamodbBackupsConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataAwsDynamodbBackupsConfig);
    private _backupSummaries;
    get backupSummaries(): DataAwsDynamodbBackups.BackupSummariesPropertyList;
    private _backupType?;
    get backupType(): string;
    set backupType(value: string);
    resetBackupType(): void;
    get backupTypeInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tableName?;
    get tableName(): string;
    set tableName(value: string);
    resetTableName(): void;
    get tableNameInput(): string | undefined;
    private _timeRangeLowerBound?;
    get timeRangeLowerBound(): string;
    set timeRangeLowerBound(value: string);
    resetTimeRangeLowerBound(): void;
    get timeRangeLowerBoundInput(): string | undefined;
    private _timeRangeUpperBound?;
    get timeRangeUpperBound(): string;
    set timeRangeUpperBound(value: string);
    resetTimeRangeUpperBound(): void;
    get timeRangeUpperBoundInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataAwsDynamodbBackupsBackupSummariesPropertyToTerraform(struct?: DataAwsDynamodbBackups.BackupSummariesProperty): any;
export declare function dataAwsDynamodbBackupsBackupSummariesPropertyToHclTerraform(struct?: DataAwsDynamodbBackups.BackupSummariesProperty): any;
export declare namespace DataAwsDynamodbBackups {
    interface BackupSummariesProperty {
    }
    class BackupSummariesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): BackupSummariesProperty | undefined;
        set internalValue(value: BackupSummariesProperty | undefined);
        get backupArn(): string;
        get backupCreationDateTime(): string;
        get backupExpiryDateTime(): string;
        get backupName(): string;
        get backupSizeBytes(): number;
        get backupStatus(): string;
        get backupType(): string;
        get tableArn(): string;
        get tableId(): string;
        get tableName(): string;
    }
    class BackupSummariesPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): BackupSummariesPropertyOutputReference;
    }
}
