import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsCostoptimizationhubPreferencesConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/costoptimizationhub_preferences#member_account_discount_visibility AwsCostoptimizationhubPreferences#member_account_discount_visibility}
    */
    readonly memberAccountDiscountVisibility?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/costoptimizationhub_preferences#savings_estimation_mode AwsCostoptimizationhubPreferences#savings_estimation_mode}
    */
    readonly savingsEstimationMode?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/costoptimizationhub_preferences aws_costoptimizationhub_preferences}
*/
export declare class AwsCostoptimizationhubPreferences extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_costoptimizationhub_preferences";
    /**
    * Generates CDKTN code for importing a AwsCostoptimizationhubPreferences resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsCostoptimizationhubPreferences to import
    * @param importFromId The id of the existing AwsCostoptimizationhubPreferences that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/costoptimizationhub_preferences#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsCostoptimizationhubPreferences to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/costoptimizationhub_preferences aws_costoptimizationhub_preferences} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsCostoptimizationhubPreferencesConfig = {}
    */
    constructor(scope: Construct, id: string, config?: AwsCostoptimizationhubPreferencesConfig);
    get id(): string;
    private _memberAccountDiscountVisibility?;
    get memberAccountDiscountVisibility(): string;
    set memberAccountDiscountVisibility(value: string);
    resetMemberAccountDiscountVisibility(): void;
    get memberAccountDiscountVisibilityInput(): string | undefined;
    private _savingsEstimationMode?;
    get savingsEstimationMode(): string;
    set savingsEstimationMode(value: string);
    resetSavingsEstimationMode(): void;
    get savingsEstimationModeInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
