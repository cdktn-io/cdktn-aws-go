import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsCostoptimizationhubEnrollmentStatusConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/costoptimizationhub_enrollment_status#include_member_accounts AwsCostoptimizationhubEnrollmentStatus#include_member_accounts}
    */
    readonly includeMemberAccounts?: boolean | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/costoptimizationhub_enrollment_status aws_costoptimizationhub_enrollment_status}
*/
export declare class AwsCostoptimizationhubEnrollmentStatus extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_costoptimizationhub_enrollment_status";
    /**
    * Generates CDKTN code for importing a AwsCostoptimizationhubEnrollmentStatus resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsCostoptimizationhubEnrollmentStatus to import
    * @param importFromId The id of the existing AwsCostoptimizationhubEnrollmentStatus that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/costoptimizationhub_enrollment_status#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsCostoptimizationhubEnrollmentStatus to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/costoptimizationhub_enrollment_status aws_costoptimizationhub_enrollment_status} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsCostoptimizationhubEnrollmentStatusConfig = {}
    */
    constructor(scope: Construct, id: string, config?: AwsCostoptimizationhubEnrollmentStatusConfig);
    get id(): string;
    private _includeMemberAccounts?;
    get includeMemberAccounts(): boolean | cdktn.IResolvable;
    set includeMemberAccounts(value: boolean | cdktn.IResolvable);
    resetIncludeMemberAccounts(): void;
    get includeMemberAccountsInput(): boolean | cdktn.IResolvable | undefined;
    get status(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
