import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsTimestreaminfluxdbDbInstanceConfig extends cdktn.TerraformMetaArguments {
    /**
    * The amount of storage to allocate for your DB storage type in GiB (gibibytes).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreaminfluxdb_db_instance#allocated_storage AwsTimestreaminfluxdbDbInstance#allocated_storage}
    */
    readonly allocatedStorage: number;
    /**
    * The name of the initial InfluxDB bucket. All InfluxDB data is stored in a bucket.
    * 					A bucket combines the concept of a database and a retention period (the duration of time
    * 					that each data point persists). A bucket belongs to an organization.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreaminfluxdb_db_instance#bucket AwsTimestreaminfluxdbDbInstance#bucket}
    */
    readonly bucket: string;
    /**
    * The Timestream for InfluxDB DB instance type to run InfluxDB on.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreaminfluxdb_db_instance#db_instance_type AwsTimestreaminfluxdbDbInstance#db_instance_type}
    */
    readonly dbInstanceType: string;
    /**
    * The id of the DB parameter group assigned to your DB instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreaminfluxdb_db_instance#db_parameter_group_identifier AwsTimestreaminfluxdbDbInstance#db_parameter_group_identifier}
    */
    readonly dbParameterGroupIdentifier?: string;
    /**
    * The Timestream for InfluxDB DB storage type to read and write InfluxDB data.
    * 					You can choose between 3 different types of provisioned Influx IOPS included storage according
    * 					to your workloads requirements: Influx IO Included 3000 IOPS, Influx IO Included 12000 IOPS,
    * 					Influx IO Included 16000 IOPS.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreaminfluxdb_db_instance#db_storage_type AwsTimestreaminfluxdbDbInstance#db_storage_type}
    */
    readonly dbStorageType?: string;
    /**
    * Specifies whether the DB instance will be deployed as a standalone instance or
    * 					with a Multi-AZ standby for high availability.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreaminfluxdb_db_instance#deployment_type AwsTimestreaminfluxdbDbInstance#deployment_type}
    */
    readonly deploymentType?: string;
    /**
    * The name that uniquely identifies the DB instance when interacting with the
    * 					Amazon Timestream for InfluxDB API and CLI commands. This name will also be a
    * 					prefix included in the endpoint. DB instance names must be unique per customer
    * 					and per region.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreaminfluxdb_db_instance#name AwsTimestreaminfluxdbDbInstance#name}
    */
    readonly name: string;
    /**
    * Specifies whether the networkType of the Timestream for InfluxDB instance is
    * 					IPV4, which can communicate over IPv4 protocol only, or DUAL, which can communicate
    * 					over both IPv4 and IPv6 protocols.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreaminfluxdb_db_instance#network_type AwsTimestreaminfluxdbDbInstance#network_type}
    */
    readonly networkType?: string;
    /**
    * The name of the initial organization for the initial admin user in InfluxDB. An
    * 					InfluxDB organization is a workspace for a group of users.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreaminfluxdb_db_instance#organization AwsTimestreaminfluxdbDbInstance#organization}
    */
    readonly organization: string;
    /**
    * The password of the initial admin user created in InfluxDB. This password will
    * 					allow you to access the InfluxDB UI to perform various administrative tasks and
    * 					also use the InfluxDB CLI to create an operator token. These attributes will be
    * 					stored in a Secret created in AWS SecretManager in your account.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreaminfluxdb_db_instance#password AwsTimestreaminfluxdbDbInstance#password}
    */
    readonly password: string;
    /**
    * The port number on which InfluxDB accepts connections.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreaminfluxdb_db_instance#port AwsTimestreaminfluxdbDbInstance#port}
    */
    readonly port?: number;
    /**
    * Configures the DB instance with a public IP to facilitate access.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreaminfluxdb_db_instance#publicly_accessible AwsTimestreaminfluxdbDbInstance#publicly_accessible}
    */
    readonly publiclyAccessible?: boolean | cdktn.IResolvable;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreaminfluxdb_db_instance#region AwsTimestreaminfluxdbDbInstance#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreaminfluxdb_db_instance#tags AwsTimestreaminfluxdbDbInstance#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * The username of the initial admin user created in InfluxDB.
    * 					Must start with a letter and can't end with a hyphen or contain two
    * 					consecutive hyphens. For example, my-user1. This username will allow
    * 					you to access the InfluxDB UI to perform various administrative tasks
    * 					and also use the InfluxDB CLI to create an operator token. These
    * 					attributes will be stored in a Secret created in Amazon Secrets
    * 					Manager in your account
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreaminfluxdb_db_instance#username AwsTimestreaminfluxdbDbInstance#username}
    */
    readonly username: string;
    /**
    * A list of VPC security group IDs to associate with the DB instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreaminfluxdb_db_instance#vpc_security_group_ids AwsTimestreaminfluxdbDbInstance#vpc_security_group_ids}
    */
    readonly vpcSecurityGroupIds: string[];
    /**
    * A list of VPC subnet IDs to associate with the DB instance. Provide at least
    * 					two VPC subnet IDs in different availability zones when deploying with a Multi-AZ standby.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreaminfluxdb_db_instance#vpc_subnet_ids AwsTimestreaminfluxdbDbInstance#vpc_subnet_ids}
    */
    readonly vpcSubnetIds: string[];
    /**
    * log_delivery_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreaminfluxdb_db_instance#log_delivery_configuration AwsTimestreaminfluxdbDbInstance#log_delivery_configuration}
    */
    readonly logDeliveryConfiguration?: AwsTimestreaminfluxdbDbInstance.LogDeliveryConfigurationProperty[] | cdktn.IResolvable;
    /**
    * maintenance_schedule block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreaminfluxdb_db_instance#maintenance_schedule AwsTimestreaminfluxdbDbInstance#maintenance_schedule}
    */
    readonly maintenanceSchedule?: AwsTimestreaminfluxdbDbInstance.MaintenanceScheduleProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreaminfluxdb_db_instance#timeouts AwsTimestreaminfluxdbDbInstance#timeouts}
    */
    readonly timeouts?: AwsTimestreaminfluxdbDbInstance.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreaminfluxdb_db_instance aws_timestreaminfluxdb_db_instance}
*/
export declare class AwsTimestreaminfluxdbDbInstance extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_timestreaminfluxdb_db_instance";
    /**
    * Generates CDKTN code for importing a AwsTimestreaminfluxdbDbInstance resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsTimestreaminfluxdbDbInstance to import
    * @param importFromId The id of the existing AwsTimestreaminfluxdbDbInstance that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreaminfluxdb_db_instance#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsTimestreaminfluxdbDbInstance to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreaminfluxdb_db_instance aws_timestreaminfluxdb_db_instance} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsTimestreaminfluxdbDbInstanceConfig
    */
    constructor(scope: Construct, id: string, config: AwsTimestreaminfluxdbDbInstanceConfig);
    private _allocatedStorage?;
    get allocatedStorage(): number;
    set allocatedStorage(value: number);
    get allocatedStorageInput(): number | undefined;
    get arn(): string;
    get availabilityZone(): string;
    private _bucket?;
    get bucket(): string;
    set bucket(value: string);
    get bucketInput(): string | undefined;
    private _dbInstanceType?;
    get dbInstanceType(): string;
    set dbInstanceType(value: string);
    get dbInstanceTypeInput(): string | undefined;
    private _dbParameterGroupIdentifier?;
    get dbParameterGroupIdentifier(): string;
    set dbParameterGroupIdentifier(value: string);
    resetDbParameterGroupIdentifier(): void;
    get dbParameterGroupIdentifierInput(): string | undefined;
    private _dbStorageType?;
    get dbStorageType(): string;
    set dbStorageType(value: string);
    resetDbStorageType(): void;
    get dbStorageTypeInput(): string | undefined;
    private _deploymentType?;
    get deploymentType(): string;
    set deploymentType(value: string);
    resetDeploymentType(): void;
    get deploymentTypeInput(): string | undefined;
    get endpoint(): string;
    get id(): string;
    get influxAuthParametersSecretArn(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _networkType?;
    get networkType(): string;
    set networkType(value: string);
    resetNetworkType(): void;
    get networkTypeInput(): string | undefined;
    private _organization?;
    get organization(): string;
    set organization(value: string);
    get organizationInput(): string | undefined;
    private _password?;
    get password(): string;
    set password(value: string);
    get passwordInput(): string | undefined;
    private _port?;
    get port(): number;
    set port(value: number);
    resetPort(): void;
    get portInput(): number | undefined;
    private _publiclyAccessible?;
    get publiclyAccessible(): boolean | cdktn.IResolvable;
    set publiclyAccessible(value: boolean | cdktn.IResolvable);
    resetPubliclyAccessible(): void;
    get publiclyAccessibleInput(): boolean | cdktn.IResolvable | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get secondaryAvailabilityZone(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    private _username?;
    get username(): string;
    set username(value: string);
    get usernameInput(): string | undefined;
    private _vpcSecurityGroupIds?;
    get vpcSecurityGroupIds(): string[];
    set vpcSecurityGroupIds(value: string[]);
    get vpcSecurityGroupIdsInput(): string[] | undefined;
    private _vpcSubnetIds?;
    get vpcSubnetIds(): string[];
    set vpcSubnetIds(value: string[]);
    get vpcSubnetIdsInput(): string[] | undefined;
    private _logDeliveryConfiguration;
    get logDeliveryConfiguration(): AwsTimestreaminfluxdbDbInstance.LogDeliveryConfigurationPropertyList;
    putLogDeliveryConfiguration(value: AwsTimestreaminfluxdbDbInstance.LogDeliveryConfigurationProperty[] | cdktn.IResolvable): void;
    resetLogDeliveryConfiguration(): void;
    get logDeliveryConfigurationInput(): cdktn.IResolvable | AwsTimestreaminfluxdbDbInstance.LogDeliveryConfigurationProperty[] | undefined;
    private _maintenanceSchedule;
    get maintenanceSchedule(): AwsTimestreaminfluxdbDbInstance.MaintenanceSchedulePropertyList;
    putMaintenanceSchedule(value: AwsTimestreaminfluxdbDbInstance.MaintenanceScheduleProperty[] | cdktn.IResolvable): void;
    resetMaintenanceSchedule(): void;
    get maintenanceScheduleInput(): cdktn.IResolvable | AwsTimestreaminfluxdbDbInstance.MaintenanceScheduleProperty[] | undefined;
    private _timeouts;
    get timeouts(): AwsTimestreaminfluxdbDbInstance.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsTimestreaminfluxdbDbInstance.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsTimestreaminfluxdbDbInstance.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsTimestreaminfluxdbDbInstanceS3ConfigurationPropertyToTerraform(struct?: AwsTimestreaminfluxdbDbInstance.S3ConfigurationProperty | cdktn.IResolvable): any;
export declare function awsTimestreaminfluxdbDbInstanceS3ConfigurationPropertyToHclTerraform(struct?: AwsTimestreaminfluxdbDbInstance.S3ConfigurationProperty | cdktn.IResolvable): any;
export declare function awsTimestreaminfluxdbDbInstanceLogDeliveryConfigurationPropertyToTerraform(struct?: AwsTimestreaminfluxdbDbInstance.LogDeliveryConfigurationProperty | cdktn.IResolvable): any;
export declare function awsTimestreaminfluxdbDbInstanceLogDeliveryConfigurationPropertyToHclTerraform(struct?: AwsTimestreaminfluxdbDbInstance.LogDeliveryConfigurationProperty | cdktn.IResolvable): any;
export declare function awsTimestreaminfluxdbDbInstanceMaintenanceSchedulePropertyToTerraform(struct?: AwsTimestreaminfluxdbDbInstance.MaintenanceScheduleProperty | cdktn.IResolvable): any;
export declare function awsTimestreaminfluxdbDbInstanceMaintenanceSchedulePropertyToHclTerraform(struct?: AwsTimestreaminfluxdbDbInstance.MaintenanceScheduleProperty | cdktn.IResolvable): any;
export declare function awsTimestreaminfluxdbDbInstanceTimeoutsPropertyToTerraform(struct?: AwsTimestreaminfluxdbDbInstance.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsTimestreaminfluxdbDbInstanceTimeoutsPropertyToHclTerraform(struct?: AwsTimestreaminfluxdbDbInstance.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsTimestreaminfluxdbDbInstance {
    interface S3ConfigurationProperty {
        /**
        * The name of the S3 bucket to deliver logs to.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreaminfluxdb_db_instance#bucket_name AwsTimestreaminfluxdbDbInstance#bucket_name}
        */
        readonly bucketName: string;
        /**
        * Indicates whether log delivery to the S3 bucket is enabled.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreaminfluxdb_db_instance#enabled AwsTimestreaminfluxdbDbInstance#enabled}
        */
        readonly enabled: boolean | cdktn.IResolvable;
    }
    class S3ConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): S3ConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: S3ConfigurationProperty | cdktn.IResolvable | undefined);
        private _bucketName?;
        get bucketName(): string;
        set bucketName(value: string);
        get bucketNameInput(): string | undefined;
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
    }
    class S3ConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: S3ConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): S3ConfigurationPropertyOutputReference;
    }
    interface LogDeliveryConfigurationProperty {
        /**
        * s3_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreaminfluxdb_db_instance#s3_configuration AwsTimestreaminfluxdbDbInstance#s3_configuration}
        */
        readonly s3Configuration?: S3ConfigurationProperty[] | cdktn.IResolvable;
    }
    class LogDeliveryConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): LogDeliveryConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: LogDeliveryConfigurationProperty | cdktn.IResolvable | undefined);
        private _s3Configuration;
        get s3Configuration(): S3ConfigurationPropertyList;
        putS3Configuration(value: S3ConfigurationProperty[] | cdktn.IResolvable): void;
        resetS3Configuration(): void;
        get s3ConfigurationInput(): cdktn.IResolvable | S3ConfigurationProperty[] | undefined;
    }
    class LogDeliveryConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: LogDeliveryConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): LogDeliveryConfigurationPropertyOutputReference;
    }
    interface MaintenanceScheduleProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreaminfluxdb_db_instance#preferred_maintenance_window AwsTimestreaminfluxdbDbInstance#preferred_maintenance_window}
        */
        readonly preferredMaintenanceWindow: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreaminfluxdb_db_instance#timezone AwsTimestreaminfluxdbDbInstance#timezone}
        */
        readonly timezone: string;
    }
    class MaintenanceSchedulePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): MaintenanceScheduleProperty | cdktn.IResolvable | undefined;
        set internalValue(value: MaintenanceScheduleProperty | cdktn.IResolvable | undefined);
        private _preferredMaintenanceWindow?;
        get preferredMaintenanceWindow(): string;
        set preferredMaintenanceWindow(value: string);
        get preferredMaintenanceWindowInput(): string | undefined;
        private _timezone?;
        get timezone(): string;
        set timezone(value: string);
        get timezoneInput(): string | undefined;
    }
    class MaintenanceSchedulePropertyList extends cdktn.ComplexList {
        internalValue?: MaintenanceScheduleProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): MaintenanceSchedulePropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreaminfluxdb_db_instance#create AwsTimestreaminfluxdbDbInstance#create}
        */
        readonly create?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Setting a timeout for a Delete operation is only applicable if changes are saved into state before the destroy operation occurs.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreaminfluxdb_db_instance#delete AwsTimestreaminfluxdbDbInstance#delete}
        */
        readonly delete?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreaminfluxdb_db_instance#update AwsTimestreaminfluxdbDbInstance#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
