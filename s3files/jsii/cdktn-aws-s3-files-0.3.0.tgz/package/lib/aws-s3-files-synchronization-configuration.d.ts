import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsSynchronizationConfigurationConfig extends cdktn.TerraformMetaArguments {
    /**
    * File system ID
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3files_synchronization_configuration#file_system_id AwsSynchronizationConfiguration#file_system_id}
    */
    readonly fileSystemId: string;
    /**
    * Latest version number for optimistic locking
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3files_synchronization_configuration#latest_version_number AwsSynchronizationConfiguration#latest_version_number}
    */
    readonly latestVersionNumber?: number;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3files_synchronization_configuration#region AwsSynchronizationConfiguration#region}
    */
    readonly region?: string;
    /**
    * expiration_data_rule block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3files_synchronization_configuration#expiration_data_rule AwsSynchronizationConfiguration#expiration_data_rule}
    */
    readonly expirationDataRule?: AwsSynchronizationConfiguration.ExpirationDataRuleProperty[] | cdktn.IResolvable;
    /**
    * import_data_rule block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3files_synchronization_configuration#import_data_rule AwsSynchronizationConfiguration#import_data_rule}
    */
    readonly importDataRule?: AwsSynchronizationConfiguration.ImportDataRuleProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3files_synchronization_configuration aws_s3files_synchronization_configuration}
*/
export declare class AwsSynchronizationConfiguration extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_s3files_synchronization_configuration";
    /**
    * Generates CDKTN code for importing a AwsSynchronizationConfiguration resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsSynchronizationConfiguration to import
    * @param importFromId The id of the existing AwsSynchronizationConfiguration that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3files_synchronization_configuration#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsSynchronizationConfiguration to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3files_synchronization_configuration aws_s3files_synchronization_configuration} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsSynchronizationConfigurationConfig
    */
    constructor(scope: Construct, id: string, config: AwsSynchronizationConfigurationConfig);
    private _fileSystemId?;
    get fileSystemId(): string;
    set fileSystemId(value: string);
    get fileSystemIdInput(): string | undefined;
    private _latestVersionNumber?;
    get latestVersionNumber(): number;
    set latestVersionNumber(value: number);
    resetLatestVersionNumber(): void;
    get latestVersionNumberInput(): number | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _expirationDataRule;
    get expirationDataRule(): AwsSynchronizationConfiguration.ExpirationDataRulePropertyList;
    putExpirationDataRule(value: AwsSynchronizationConfiguration.ExpirationDataRuleProperty[] | cdktn.IResolvable): void;
    resetExpirationDataRule(): void;
    get expirationDataRuleInput(): cdktn.IResolvable | AwsSynchronizationConfiguration.ExpirationDataRuleProperty[] | undefined;
    private _importDataRule;
    get importDataRule(): AwsSynchronizationConfiguration.ImportDataRulePropertyList;
    putImportDataRule(value: AwsSynchronizationConfiguration.ImportDataRuleProperty[] | cdktn.IResolvable): void;
    resetImportDataRule(): void;
    get importDataRuleInput(): cdktn.IResolvable | AwsSynchronizationConfiguration.ImportDataRuleProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsSynchronizationConfigurationExpirationDataRulePropertyToTerraform(struct?: AwsSynchronizationConfiguration.ExpirationDataRuleProperty | cdktn.IResolvable): any;
export declare function awsSynchronizationConfigurationExpirationDataRulePropertyToHclTerraform(struct?: AwsSynchronizationConfiguration.ExpirationDataRuleProperty | cdktn.IResolvable): any;
export declare function awsSynchronizationConfigurationImportDataRulePropertyToTerraform(struct?: AwsSynchronizationConfiguration.ImportDataRuleProperty | cdktn.IResolvable): any;
export declare function awsSynchronizationConfigurationImportDataRulePropertyToHclTerraform(struct?: AwsSynchronizationConfiguration.ImportDataRuleProperty | cdktn.IResolvable): any;
export declare namespace AwsSynchronizationConfiguration {
    interface ExpirationDataRuleProperty {
        /**
        * Days after last access before data expires
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3files_synchronization_configuration#days_after_last_access AwsSynchronizationConfiguration#days_after_last_access}
        */
        readonly daysAfterLastAccess: number;
    }
    class ExpirationDataRulePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ExpirationDataRuleProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ExpirationDataRuleProperty | cdktn.IResolvable | undefined);
        private _daysAfterLastAccess?;
        get daysAfterLastAccess(): number;
        set daysAfterLastAccess(value: number);
        get daysAfterLastAccessInput(): number | undefined;
    }
    class ExpirationDataRulePropertyList extends cdktn.ComplexList {
        internalValue?: ExpirationDataRuleProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ExpirationDataRulePropertyOutputReference;
    }
    interface ImportDataRuleProperty {
        /**
        * S3 prefix for import
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3files_synchronization_configuration#prefix AwsSynchronizationConfiguration#prefix}
        */
        readonly prefix: string;
        /**
        * Maximum file size to import
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3files_synchronization_configuration#size_less_than AwsSynchronizationConfiguration#size_less_than}
        */
        readonly sizeLessThan: number;
        /**
        * Import trigger type
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3files_synchronization_configuration#trigger AwsSynchronizationConfiguration#trigger}
        */
        readonly trigger: string;
    }
    class ImportDataRulePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ImportDataRuleProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ImportDataRuleProperty | cdktn.IResolvable | undefined);
        private _prefix?;
        get prefix(): string;
        set prefix(value: string);
        get prefixInput(): string | undefined;
        private _sizeLessThan?;
        get sizeLessThan(): number;
        set sizeLessThan(value: number);
        get sizeLessThanInput(): number | undefined;
        private _trigger?;
        get trigger(): string;
        set trigger(value: string);
        get triggerInput(): string | undefined;
    }
    class ImportDataRulePropertyList extends cdktn.ComplexList {
        internalValue?: ImportDataRuleProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ImportDataRulePropertyOutputReference;
    }
}
