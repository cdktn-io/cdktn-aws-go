import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsAccessPointConfig extends cdktn.TerraformMetaArguments {
    /**
    * File system ID
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3files_access_point#file_system_id AwsAccessPoint#file_system_id}
    */
    readonly fileSystemId: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3files_access_point#region AwsAccessPoint#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3files_access_point#tags AwsAccessPoint#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * posix_user block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3files_access_point#posix_user AwsAccessPoint#posix_user}
    */
    readonly posixUser?: AwsAccessPoint.PosixUserProperty[] | cdktn.IResolvable;
    /**
    * root_directory block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3files_access_point#root_directory AwsAccessPoint#root_directory}
    */
    readonly rootDirectory?: AwsAccessPoint.RootDirectoryProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3files_access_point#timeouts AwsAccessPoint#timeouts}
    */
    readonly timeouts?: AwsAccessPoint.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3files_access_point aws_s3files_access_point}
*/
export declare class AwsAccessPoint extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_s3files_access_point";
    /**
    * Generates CDKTN code for importing a AwsAccessPoint resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsAccessPoint to import
    * @param importFromId The id of the existing AwsAccessPoint that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3files_access_point#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsAccessPoint to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3files_access_point aws_s3files_access_point} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsAccessPointConfig
    */
    constructor(scope: Construct, id: string, config: AwsAccessPointConfig);
    get arn(): string;
    private _fileSystemId?;
    get fileSystemId(): string;
    set fileSystemId(value: string);
    get fileSystemIdInput(): string | undefined;
    get id(): string;
    get name(): string;
    get ownerId(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get status(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    private _posixUser;
    get posixUser(): AwsAccessPoint.PosixUserPropertyList;
    putPosixUser(value: AwsAccessPoint.PosixUserProperty[] | cdktn.IResolvable): void;
    resetPosixUser(): void;
    get posixUserInput(): cdktn.IResolvable | AwsAccessPoint.PosixUserProperty[] | undefined;
    private _rootDirectory;
    get rootDirectory(): AwsAccessPoint.RootDirectoryPropertyList;
    putRootDirectory(value: AwsAccessPoint.RootDirectoryProperty[] | cdktn.IResolvable): void;
    resetRootDirectory(): void;
    get rootDirectoryInput(): cdktn.IResolvable | AwsAccessPoint.RootDirectoryProperty[] | undefined;
    private _timeouts;
    get timeouts(): AwsAccessPoint.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsAccessPoint.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsAccessPoint.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsAccessPointPosixUserPropertyToTerraform(struct?: AwsAccessPoint.PosixUserProperty | cdktn.IResolvable): any;
export declare function awsAccessPointPosixUserPropertyToHclTerraform(struct?: AwsAccessPoint.PosixUserProperty | cdktn.IResolvable): any;
export declare function awsAccessPointCreationPermissionsPropertyToTerraform(struct?: AwsAccessPoint.CreationPermissionsProperty | cdktn.IResolvable): any;
export declare function awsAccessPointCreationPermissionsPropertyToHclTerraform(struct?: AwsAccessPoint.CreationPermissionsProperty | cdktn.IResolvable): any;
export declare function awsAccessPointRootDirectoryPropertyToTerraform(struct?: AwsAccessPoint.RootDirectoryProperty | cdktn.IResolvable): any;
export declare function awsAccessPointRootDirectoryPropertyToHclTerraform(struct?: AwsAccessPoint.RootDirectoryProperty | cdktn.IResolvable): any;
export declare function awsAccessPointTimeoutsPropertyToTerraform(struct?: AwsAccessPoint.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsAccessPointTimeoutsPropertyToHclTerraform(struct?: AwsAccessPoint.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsAccessPoint {
    interface PosixUserProperty {
        /**
        * POSIX group ID
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3files_access_point#gid AwsAccessPoint#gid}
        */
        readonly gid: number;
        /**
        * Secondary POSIX group IDs
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3files_access_point#secondary_gids AwsAccessPoint#secondary_gids}
        */
        readonly secondaryGids?: number[];
        /**
        * POSIX user ID
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3files_access_point#uid AwsAccessPoint#uid}
        */
        readonly uid: number;
    }
    class PosixUserPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): PosixUserProperty | cdktn.IResolvable | undefined;
        set internalValue(value: PosixUserProperty | cdktn.IResolvable | undefined);
        private _gid?;
        get gid(): number;
        set gid(value: number);
        get gidInput(): number | undefined;
        private _secondaryGids?;
        get secondaryGids(): number[];
        set secondaryGids(value: number[]);
        resetSecondaryGids(): void;
        get secondaryGidsInput(): number[] | undefined;
        private _uid?;
        get uid(): number;
        set uid(value: number);
        get uidInput(): number | undefined;
    }
    class PosixUserPropertyList extends cdktn.ComplexList {
        internalValue?: PosixUserProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): PosixUserPropertyOutputReference;
    }
    interface CreationPermissionsProperty {
        /**
        * Owner group ID
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3files_access_point#owner_gid AwsAccessPoint#owner_gid}
        */
        readonly ownerGid: number;
        /**
        * Owner user ID
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3files_access_point#owner_uid AwsAccessPoint#owner_uid}
        */
        readonly ownerUid: number;
        /**
        * POSIX permissions
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3files_access_point#permissions AwsAccessPoint#permissions}
        */
        readonly permissions: string;
    }
    class CreationPermissionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CreationPermissionsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CreationPermissionsProperty | cdktn.IResolvable | undefined);
        private _ownerGid?;
        get ownerGid(): number;
        set ownerGid(value: number);
        get ownerGidInput(): number | undefined;
        private _ownerUid?;
        get ownerUid(): number;
        set ownerUid(value: number);
        get ownerUidInput(): number | undefined;
        private _permissions?;
        get permissions(): string;
        set permissions(value: string);
        get permissionsInput(): string | undefined;
    }
    class CreationPermissionsPropertyList extends cdktn.ComplexList {
        internalValue?: CreationPermissionsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CreationPermissionsPropertyOutputReference;
    }
    interface RootDirectoryProperty {
        /**
        * Root directory path
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3files_access_point#path AwsAccessPoint#path}
        */
        readonly path?: string;
        /**
        * creation_permissions block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3files_access_point#creation_permissions AwsAccessPoint#creation_permissions}
        */
        readonly creationPermissions?: CreationPermissionsProperty[] | cdktn.IResolvable;
    }
    class RootDirectoryPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RootDirectoryProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RootDirectoryProperty | cdktn.IResolvable | undefined);
        private _path?;
        get path(): string;
        set path(value: string);
        resetPath(): void;
        get pathInput(): string | undefined;
        private _creationPermissions;
        get creationPermissions(): CreationPermissionsPropertyList;
        putCreationPermissions(value: CreationPermissionsProperty[] | cdktn.IResolvable): void;
        resetCreationPermissions(): void;
        get creationPermissionsInput(): cdktn.IResolvable | CreationPermissionsProperty[] | undefined;
    }
    class RootDirectoryPropertyList extends cdktn.ComplexList {
        internalValue?: RootDirectoryProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RootDirectoryPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3files_access_point#create AwsAccessPoint#create}
        */
        readonly create?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Setting a timeout for a Delete operation is only applicable if changes are saved into state before the destroy operation occurs.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3files_access_point#delete AwsAccessPoint#delete}
        */
        readonly delete?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
    }
}
