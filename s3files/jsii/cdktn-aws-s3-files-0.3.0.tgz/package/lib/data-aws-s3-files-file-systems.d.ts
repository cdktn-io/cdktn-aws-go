import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsFileSystemsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/s3files_file_systems#region DataAwsFileSystems#region}
    */
    readonly region?: string;
    /**
    * file_systems block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/s3files_file_systems#file_systems DataAwsFileSystems#file_systems}
    */
    readonly fileSystems?: DataAwsFileSystems.FileSystemsProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/s3files_file_systems aws_s3files_file_systems}
*/
export declare class DataAwsFileSystems extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_s3files_file_systems";
    /**
    * Generates CDKTN code for importing a DataAwsFileSystems resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsFileSystems to import
    * @param importFromId The id of the existing DataAwsFileSystems that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/s3files_file_systems#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsFileSystems to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/s3files_file_systems aws_s3files_file_systems} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsFileSystemsConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataAwsFileSystemsConfig);
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _fileSystems;
    get fileSystems(): DataAwsFileSystems.FileSystemsPropertyList;
    putFileSystems(value: DataAwsFileSystems.FileSystemsProperty[] | cdktn.IResolvable): void;
    resetFileSystems(): void;
    get fileSystemsInput(): cdktn.IResolvable | DataAwsFileSystems.FileSystemsProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataAwsFileSystemsFileSystemsPropertyToTerraform(struct?: DataAwsFileSystems.FileSystemsProperty | cdktn.IResolvable): any;
export declare function dataAwsFileSystemsFileSystemsPropertyToHclTerraform(struct?: DataAwsFileSystems.FileSystemsProperty | cdktn.IResolvable): any;
export declare namespace DataAwsFileSystems {
    interface FileSystemsProperty {
    }
    class FileSystemsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): FileSystemsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: FileSystemsProperty | cdktn.IResolvable | undefined);
        get arn(): string;
        get bucket(): string;
        get creationTime(): string;
        get id(): string;
        get kmsKeyId(): string;
        get name(): string;
        get ownerId(): string;
        get roleArn(): string;
        get status(): string;
        get statusMessage(): string;
    }
    class FileSystemsPropertyList extends cdktn.ComplexList {
        internalValue?: FileSystemsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): FileSystemsPropertyOutputReference;
    }
}
