import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsAccessPointConfig extends cdktn.TerraformMetaArguments {
    /**
    * Access point ID
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/s3files_access_point#id DataAwsAccessPoint#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/s3files_access_point#region DataAwsAccessPoint#region}
    */
    readonly region?: string;
    /**
    * posix_user block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/s3files_access_point#posix_user DataAwsAccessPoint#posix_user}
    */
    readonly posixUser?: DataAwsAccessPoint.PosixUserProperty[] | cdktn.IResolvable;
    /**
    * root_directory block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/s3files_access_point#root_directory DataAwsAccessPoint#root_directory}
    */
    readonly rootDirectory?: DataAwsAccessPoint.RootDirectoryProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/s3files_access_point aws_s3files_access_point}
*/
export declare class DataAwsAccessPoint extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_s3files_access_point";
    /**
    * Generates CDKTN code for importing a DataAwsAccessPoint resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsAccessPoint to import
    * @param importFromId The id of the existing DataAwsAccessPoint that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/s3files_access_point#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsAccessPoint to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/s3files_access_point aws_s3files_access_point} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsAccessPointConfig
    */
    constructor(scope: Construct, id: string, config: DataAwsAccessPointConfig);
    get arn(): string;
    get fileSystemId(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    get name(): string;
    get ownerId(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get status(): string;
    private _tags;
    get tags(): cdktn.StringMap;
    private _posixUser;
    get posixUser(): DataAwsAccessPoint.PosixUserPropertyList;
    putPosixUser(value: DataAwsAccessPoint.PosixUserProperty[] | cdktn.IResolvable): void;
    resetPosixUser(): void;
    get posixUserInput(): cdktn.IResolvable | DataAwsAccessPoint.PosixUserProperty[] | undefined;
    private _rootDirectory;
    get rootDirectory(): DataAwsAccessPoint.RootDirectoryPropertyList;
    putRootDirectory(value: DataAwsAccessPoint.RootDirectoryProperty[] | cdktn.IResolvable): void;
    resetRootDirectory(): void;
    get rootDirectoryInput(): cdktn.IResolvable | DataAwsAccessPoint.RootDirectoryProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataAwsAccessPointPosixUserPropertyToTerraform(struct?: DataAwsAccessPoint.PosixUserProperty | cdktn.IResolvable): any;
export declare function dataAwsAccessPointPosixUserPropertyToHclTerraform(struct?: DataAwsAccessPoint.PosixUserProperty | cdktn.IResolvable): any;
export declare function dataAwsAccessPointCreationPermissionsPropertyToTerraform(struct?: DataAwsAccessPoint.CreationPermissionsProperty | cdktn.IResolvable): any;
export declare function dataAwsAccessPointCreationPermissionsPropertyToHclTerraform(struct?: DataAwsAccessPoint.CreationPermissionsProperty | cdktn.IResolvable): any;
export declare function dataAwsAccessPointRootDirectoryPropertyToTerraform(struct?: DataAwsAccessPoint.RootDirectoryProperty | cdktn.IResolvable): any;
export declare function dataAwsAccessPointRootDirectoryPropertyToHclTerraform(struct?: DataAwsAccessPoint.RootDirectoryProperty | cdktn.IResolvable): any;
export declare namespace DataAwsAccessPoint {
    interface PosixUserProperty {
    }
    class PosixUserPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): PosixUserProperty | cdktn.IResolvable | undefined;
        set internalValue(value: PosixUserProperty | cdktn.IResolvable | undefined);
        get gid(): number;
        get secondaryGids(): number[];
        get uid(): number;
    }
    class PosixUserPropertyList extends cdktn.ComplexList {
        internalValue?: PosixUserProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): PosixUserPropertyOutputReference;
    }
    interface CreationPermissionsProperty {
    }
    class CreationPermissionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CreationPermissionsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CreationPermissionsProperty | cdktn.IResolvable | undefined);
        get ownerGid(): number;
        get ownerUid(): number;
        get permissions(): string;
    }
    class CreationPermissionsPropertyList extends cdktn.ComplexList {
        internalValue?: CreationPermissionsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CreationPermissionsPropertyOutputReference;
    }
    interface RootDirectoryProperty {
        /**
        * creation_permissions block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/s3files_access_point#creation_permissions DataAwsAccessPoint#creation_permissions}
        */
        readonly creationPermissions?: CreationPermissionsProperty[] | cdktn.IResolvable;
    }
    class RootDirectoryPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RootDirectoryProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RootDirectoryProperty | cdktn.IResolvable | undefined);
        get path(): string;
        private _creationPermissions;
        get creationPermissions(): CreationPermissionsPropertyList;
        putCreationPermissions(value: CreationPermissionsProperty[] | cdktn.IResolvable): void;
        resetCreationPermissions(): void;
        get creationPermissionsInput(): cdktn.IResolvable | CreationPermissionsProperty[] | undefined;
    }
    class RootDirectoryPropertyList extends cdktn.ComplexList {
        internalValue?: RootDirectoryProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RootDirectoryPropertyOutputReference;
    }
}
