import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsWorkgroupConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/athena_workgroup#description AwsWorkgroup#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/athena_workgroup#force_destroy AwsWorkgroup#force_destroy}
    */
    readonly forceDestroy?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/athena_workgroup#id AwsWorkgroup#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/athena_workgroup#name AwsWorkgroup#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/athena_workgroup#region AwsWorkgroup#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/athena_workgroup#state AwsWorkgroup#state}
    */
    readonly state?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/athena_workgroup#tags AwsWorkgroup#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/athena_workgroup#tags_all AwsWorkgroup#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/athena_workgroup#configuration AwsWorkgroup#configuration}
    */
    readonly configuration?: AwsWorkgroup.ConfigurationProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/athena_workgroup aws_athena_workgroup}
*/
export declare class AwsWorkgroup extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_athena_workgroup";
    /**
    * Generates CDKTN code for importing a AwsWorkgroup resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsWorkgroup to import
    * @param importFromId The id of the existing AwsWorkgroup that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/athena_workgroup#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsWorkgroup to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/athena_workgroup aws_athena_workgroup} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsWorkgroupConfig
    */
    constructor(scope: Construct, id: string, config: AwsWorkgroupConfig);
    get arn(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _forceDestroy?;
    get forceDestroy(): boolean | cdktn.IResolvable;
    set forceDestroy(value: boolean | cdktn.IResolvable);
    resetForceDestroy(): void;
    get forceDestroyInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _state?;
    get state(): string;
    set state(value: string);
    resetState(): void;
    get stateInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _configuration;
    get configuration(): AwsWorkgroup.ConfigurationPropertyOutputReference;
    putConfiguration(value: AwsWorkgroup.ConfigurationProperty): void;
    resetConfiguration(): void;
    get configurationInput(): AwsWorkgroup.ConfigurationProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsWorkgroupCustomerContentEncryptionConfigurationPropertyToTerraform(struct?: AwsWorkgroup.CustomerContentEncryptionConfigurationPropertyOutputReference | AwsWorkgroup.CustomerContentEncryptionConfigurationProperty): any;
export declare function awsWorkgroupCustomerContentEncryptionConfigurationPropertyToHclTerraform(struct?: AwsWorkgroup.CustomerContentEncryptionConfigurationPropertyOutputReference | AwsWorkgroup.CustomerContentEncryptionConfigurationProperty): any;
export declare function awsWorkgroupEngineVersionPropertyToTerraform(struct?: AwsWorkgroup.EngineVersionPropertyOutputReference | AwsWorkgroup.EngineVersionProperty): any;
export declare function awsWorkgroupEngineVersionPropertyToHclTerraform(struct?: AwsWorkgroup.EngineVersionPropertyOutputReference | AwsWorkgroup.EngineVersionProperty): any;
export declare function awsWorkgroupIdentityCenterConfigurationPropertyToTerraform(struct?: AwsWorkgroup.IdentityCenterConfigurationPropertyOutputReference | AwsWorkgroup.IdentityCenterConfigurationProperty): any;
export declare function awsWorkgroupIdentityCenterConfigurationPropertyToHclTerraform(struct?: AwsWorkgroup.IdentityCenterConfigurationPropertyOutputReference | AwsWorkgroup.IdentityCenterConfigurationProperty): any;
export declare function awsWorkgroupConfigurationManagedQueryResultsConfigurationEncryptionConfigurationPropertyToTerraform(struct?: AwsWorkgroup.ConfigurationManagedQueryResultsConfigurationEncryptionConfigurationPropertyOutputReference | AwsWorkgroup.ConfigurationManagedQueryResultsConfigurationEncryptionConfigurationProperty): any;
export declare function awsWorkgroupConfigurationManagedQueryResultsConfigurationEncryptionConfigurationPropertyToHclTerraform(struct?: AwsWorkgroup.ConfigurationManagedQueryResultsConfigurationEncryptionConfigurationPropertyOutputReference | AwsWorkgroup.ConfigurationManagedQueryResultsConfigurationEncryptionConfigurationProperty): any;
export declare function awsWorkgroupManagedQueryResultsConfigurationPropertyToTerraform(struct?: AwsWorkgroup.ManagedQueryResultsConfigurationPropertyOutputReference | AwsWorkgroup.ManagedQueryResultsConfigurationProperty): any;
export declare function awsWorkgroupManagedQueryResultsConfigurationPropertyToHclTerraform(struct?: AwsWorkgroup.ManagedQueryResultsConfigurationPropertyOutputReference | AwsWorkgroup.ManagedQueryResultsConfigurationProperty): any;
export declare function awsWorkgroupLogTypePropertyToTerraform(struct?: AwsWorkgroup.LogTypeProperty | cdktn.IResolvable): any;
export declare function awsWorkgroupLogTypePropertyToHclTerraform(struct?: AwsWorkgroup.LogTypeProperty | cdktn.IResolvable): any;
export declare function awsWorkgroupCloudWatchLoggingConfigurationPropertyToTerraform(struct?: AwsWorkgroup.CloudWatchLoggingConfigurationPropertyOutputReference | AwsWorkgroup.CloudWatchLoggingConfigurationProperty): any;
export declare function awsWorkgroupCloudWatchLoggingConfigurationPropertyToHclTerraform(struct?: AwsWorkgroup.CloudWatchLoggingConfigurationPropertyOutputReference | AwsWorkgroup.CloudWatchLoggingConfigurationProperty): any;
export declare function awsWorkgroupManagedLoggingConfigurationPropertyToTerraform(struct?: AwsWorkgroup.ManagedLoggingConfigurationPropertyOutputReference | AwsWorkgroup.ManagedLoggingConfigurationProperty): any;
export declare function awsWorkgroupManagedLoggingConfigurationPropertyToHclTerraform(struct?: AwsWorkgroup.ManagedLoggingConfigurationPropertyOutputReference | AwsWorkgroup.ManagedLoggingConfigurationProperty): any;
export declare function awsWorkgroupS3LoggingConfigurationPropertyToTerraform(struct?: AwsWorkgroup.S3LoggingConfigurationPropertyOutputReference | AwsWorkgroup.S3LoggingConfigurationProperty): any;
export declare function awsWorkgroupS3LoggingConfigurationPropertyToHclTerraform(struct?: AwsWorkgroup.S3LoggingConfigurationPropertyOutputReference | AwsWorkgroup.S3LoggingConfigurationProperty): any;
export declare function awsWorkgroupMonitoringConfigurationPropertyToTerraform(struct?: AwsWorkgroup.MonitoringConfigurationPropertyOutputReference | AwsWorkgroup.MonitoringConfigurationProperty): any;
export declare function awsWorkgroupMonitoringConfigurationPropertyToHclTerraform(struct?: AwsWorkgroup.MonitoringConfigurationPropertyOutputReference | AwsWorkgroup.MonitoringConfigurationProperty): any;
export declare function awsWorkgroupQueryResultsS3AccessGrantsConfigurationPropertyToTerraform(struct?: AwsWorkgroup.QueryResultsS3AccessGrantsConfigurationPropertyOutputReference | AwsWorkgroup.QueryResultsS3AccessGrantsConfigurationProperty): any;
export declare function awsWorkgroupQueryResultsS3AccessGrantsConfigurationPropertyToHclTerraform(struct?: AwsWorkgroup.QueryResultsS3AccessGrantsConfigurationPropertyOutputReference | AwsWorkgroup.QueryResultsS3AccessGrantsConfigurationProperty): any;
export declare function awsWorkgroupAclConfigurationPropertyToTerraform(struct?: AwsWorkgroup.AclConfigurationPropertyOutputReference | AwsWorkgroup.AclConfigurationProperty): any;
export declare function awsWorkgroupAclConfigurationPropertyToHclTerraform(struct?: AwsWorkgroup.AclConfigurationPropertyOutputReference | AwsWorkgroup.AclConfigurationProperty): any;
export declare function awsWorkgroupConfigurationResultConfigurationEncryptionConfigurationPropertyToTerraform(struct?: AwsWorkgroup.ConfigurationResultConfigurationEncryptionConfigurationPropertyOutputReference | AwsWorkgroup.ConfigurationResultConfigurationEncryptionConfigurationProperty): any;
export declare function awsWorkgroupConfigurationResultConfigurationEncryptionConfigurationPropertyToHclTerraform(struct?: AwsWorkgroup.ConfigurationResultConfigurationEncryptionConfigurationPropertyOutputReference | AwsWorkgroup.ConfigurationResultConfigurationEncryptionConfigurationProperty): any;
export declare function awsWorkgroupResultConfigurationPropertyToTerraform(struct?: AwsWorkgroup.ResultConfigurationPropertyOutputReference | AwsWorkgroup.ResultConfigurationProperty): any;
export declare function awsWorkgroupResultConfigurationPropertyToHclTerraform(struct?: AwsWorkgroup.ResultConfigurationPropertyOutputReference | AwsWorkgroup.ResultConfigurationProperty): any;
export declare function awsWorkgroupConfigurationPropertyToTerraform(struct?: AwsWorkgroup.ConfigurationPropertyOutputReference | AwsWorkgroup.ConfigurationProperty): any;
export declare function awsWorkgroupConfigurationPropertyToHclTerraform(struct?: AwsWorkgroup.ConfigurationPropertyOutputReference | AwsWorkgroup.ConfigurationProperty): any;
export declare namespace AwsWorkgroup {
    interface CustomerContentEncryptionConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/athena_workgroup#kms_key AwsWorkgroup#kms_key}
        */
        readonly kmsKey?: string;
    }
    class CustomerContentEncryptionConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CustomerContentEncryptionConfigurationProperty | undefined;
        set internalValue(value: CustomerContentEncryptionConfigurationProperty | undefined);
        private _kmsKey?;
        get kmsKey(): string;
        set kmsKey(value: string);
        resetKmsKey(): void;
        get kmsKeyInput(): string | undefined;
    }
    interface EngineVersionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/athena_workgroup#selected_engine_version AwsWorkgroup#selected_engine_version}
        */
        readonly selectedEngineVersion?: string;
    }
    class EngineVersionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): EngineVersionProperty | undefined;
        set internalValue(value: EngineVersionProperty | undefined);
        get effectiveEngineVersion(): string;
        private _selectedEngineVersion?;
        get selectedEngineVersion(): string;
        set selectedEngineVersion(value: string);
        resetSelectedEngineVersion(): void;
        get selectedEngineVersionInput(): string | undefined;
    }
    interface IdentityCenterConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/athena_workgroup#enable_identity_center AwsWorkgroup#enable_identity_center}
        */
        readonly enableIdentityCenter?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/athena_workgroup#identity_center_instance_arn AwsWorkgroup#identity_center_instance_arn}
        */
        readonly identityCenterInstanceArn?: string;
    }
    class IdentityCenterConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): IdentityCenterConfigurationProperty | undefined;
        set internalValue(value: IdentityCenterConfigurationProperty | undefined);
        private _enableIdentityCenter?;
        get enableIdentityCenter(): boolean | cdktn.IResolvable;
        set enableIdentityCenter(value: boolean | cdktn.IResolvable);
        resetEnableIdentityCenter(): void;
        get enableIdentityCenterInput(): boolean | cdktn.IResolvable | undefined;
        private _identityCenterInstanceArn?;
        get identityCenterInstanceArn(): string;
        set identityCenterInstanceArn(value: string);
        resetIdentityCenterInstanceArn(): void;
        get identityCenterInstanceArnInput(): string | undefined;
    }
    interface ConfigurationManagedQueryResultsConfigurationEncryptionConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/athena_workgroup#kms_key AwsWorkgroup#kms_key}
        */
        readonly kmsKey?: string;
    }
    class ConfigurationManagedQueryResultsConfigurationEncryptionConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ConfigurationManagedQueryResultsConfigurationEncryptionConfigurationProperty | undefined;
        set internalValue(value: ConfigurationManagedQueryResultsConfigurationEncryptionConfigurationProperty | undefined);
        private _kmsKey?;
        get kmsKey(): string;
        set kmsKey(value: string);
        resetKmsKey(): void;
        get kmsKeyInput(): string | undefined;
    }
    interface ManagedQueryResultsConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/athena_workgroup#enabled AwsWorkgroup#enabled}
        */
        readonly enabled?: boolean | cdktn.IResolvable;
        /**
        * encryption_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/athena_workgroup#encryption_configuration AwsWorkgroup#encryption_configuration}
        */
        readonly encryptionConfiguration?: ConfigurationManagedQueryResultsConfigurationEncryptionConfigurationProperty;
    }
    class ManagedQueryResultsConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ManagedQueryResultsConfigurationProperty | undefined;
        set internalValue(value: ManagedQueryResultsConfigurationProperty | undefined);
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        resetEnabled(): void;
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
        private _encryptionConfiguration;
        get encryptionConfiguration(): ConfigurationManagedQueryResultsConfigurationEncryptionConfigurationPropertyOutputReference;
        putEncryptionConfiguration(value: ConfigurationManagedQueryResultsConfigurationEncryptionConfigurationProperty): void;
        resetEncryptionConfiguration(): void;
        get encryptionConfigurationInput(): ConfigurationManagedQueryResultsConfigurationEncryptionConfigurationProperty | undefined;
    }
    interface LogTypeProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/athena_workgroup#key AwsWorkgroup#key}
        */
        readonly key: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/athena_workgroup#values AwsWorkgroup#values}
        */
        readonly values: string[];
    }
    class LogTypePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): LogTypeProperty | cdktn.IResolvable | undefined;
        set internalValue(value: LogTypeProperty | cdktn.IResolvable | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        get keyInput(): string | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        get valuesInput(): string[] | undefined;
    }
    class LogTypePropertyList extends cdktn.ComplexList {
        internalValue?: LogTypeProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): LogTypePropertyOutputReference;
    }
    interface CloudWatchLoggingConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/athena_workgroup#enabled AwsWorkgroup#enabled}
        */
        readonly enabled: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/athena_workgroup#log_group AwsWorkgroup#log_group}
        */
        readonly logGroup?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/athena_workgroup#log_stream_name_prefix AwsWorkgroup#log_stream_name_prefix}
        */
        readonly logStreamNamePrefix?: string;
        /**
        * log_type block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/athena_workgroup#log_type AwsWorkgroup#log_type}
        */
        readonly logType?: LogTypeProperty[] | cdktn.IResolvable;
    }
    class CloudWatchLoggingConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CloudWatchLoggingConfigurationProperty | undefined;
        set internalValue(value: CloudWatchLoggingConfigurationProperty | undefined);
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
        private _logGroup?;
        get logGroup(): string;
        set logGroup(value: string);
        resetLogGroup(): void;
        get logGroupInput(): string | undefined;
        private _logStreamNamePrefix?;
        get logStreamNamePrefix(): string;
        set logStreamNamePrefix(value: string);
        resetLogStreamNamePrefix(): void;
        get logStreamNamePrefixInput(): string | undefined;
        private _logType;
        get logType(): LogTypePropertyList;
        putLogType(value: LogTypeProperty[] | cdktn.IResolvable): void;
        resetLogType(): void;
        get logTypeInput(): cdktn.IResolvable | LogTypeProperty[] | undefined;
    }
    interface ManagedLoggingConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/athena_workgroup#enabled AwsWorkgroup#enabled}
        */
        readonly enabled: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/athena_workgroup#kms_key AwsWorkgroup#kms_key}
        */
        readonly kmsKey?: string;
    }
    class ManagedLoggingConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ManagedLoggingConfigurationProperty | undefined;
        set internalValue(value: ManagedLoggingConfigurationProperty | undefined);
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
        private _kmsKey?;
        get kmsKey(): string;
        set kmsKey(value: string);
        resetKmsKey(): void;
        get kmsKeyInput(): string | undefined;
    }
    interface S3LoggingConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/athena_workgroup#enabled AwsWorkgroup#enabled}
        */
        readonly enabled: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/athena_workgroup#kms_key AwsWorkgroup#kms_key}
        */
        readonly kmsKey?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/athena_workgroup#log_location AwsWorkgroup#log_location}
        */
        readonly logLocation?: string;
    }
    class S3LoggingConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): S3LoggingConfigurationProperty | undefined;
        set internalValue(value: S3LoggingConfigurationProperty | undefined);
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
        private _kmsKey?;
        get kmsKey(): string;
        set kmsKey(value: string);
        resetKmsKey(): void;
        get kmsKeyInput(): string | undefined;
        private _logLocation?;
        get logLocation(): string;
        set logLocation(value: string);
        resetLogLocation(): void;
        get logLocationInput(): string | undefined;
    }
    interface MonitoringConfigurationProperty {
        /**
        * cloud_watch_logging_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/athena_workgroup#cloud_watch_logging_configuration AwsWorkgroup#cloud_watch_logging_configuration}
        */
        readonly cloudWatchLoggingConfiguration?: CloudWatchLoggingConfigurationProperty;
        /**
        * managed_logging_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/athena_workgroup#managed_logging_configuration AwsWorkgroup#managed_logging_configuration}
        */
        readonly managedLoggingConfiguration?: ManagedLoggingConfigurationProperty;
        /**
        * s3_logging_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/athena_workgroup#s3_logging_configuration AwsWorkgroup#s3_logging_configuration}
        */
        readonly s3LoggingConfiguration?: S3LoggingConfigurationProperty;
    }
    class MonitoringConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): MonitoringConfigurationProperty | undefined;
        set internalValue(value: MonitoringConfigurationProperty | undefined);
        private _cloudWatchLoggingConfiguration;
        get cloudWatchLoggingConfiguration(): CloudWatchLoggingConfigurationPropertyOutputReference;
        putCloudWatchLoggingConfiguration(value: CloudWatchLoggingConfigurationProperty): void;
        resetCloudWatchLoggingConfiguration(): void;
        get cloudWatchLoggingConfigurationInput(): CloudWatchLoggingConfigurationProperty | undefined;
        private _managedLoggingConfiguration;
        get managedLoggingConfiguration(): ManagedLoggingConfigurationPropertyOutputReference;
        putManagedLoggingConfiguration(value: ManagedLoggingConfigurationProperty): void;
        resetManagedLoggingConfiguration(): void;
        get managedLoggingConfigurationInput(): ManagedLoggingConfigurationProperty | undefined;
        private _s3LoggingConfiguration;
        get s3LoggingConfiguration(): S3LoggingConfigurationPropertyOutputReference;
        putS3LoggingConfiguration(value: S3LoggingConfigurationProperty): void;
        resetS3LoggingConfiguration(): void;
        get s3LoggingConfigurationInput(): S3LoggingConfigurationProperty | undefined;
    }
    interface QueryResultsS3AccessGrantsConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/athena_workgroup#authentication_type AwsWorkgroup#authentication_type}
        */
        readonly authenticationType: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/athena_workgroup#create_user_level_prefix AwsWorkgroup#create_user_level_prefix}
        */
        readonly createUserLevelPrefix?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/athena_workgroup#enable_s3_access_grants AwsWorkgroup#enable_s3_access_grants}
        */
        readonly enableS3AccessGrants: boolean | cdktn.IResolvable;
    }
    class QueryResultsS3AccessGrantsConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): QueryResultsS3AccessGrantsConfigurationProperty | undefined;
        set internalValue(value: QueryResultsS3AccessGrantsConfigurationProperty | undefined);
        private _authenticationType?;
        get authenticationType(): string;
        set authenticationType(value: string);
        get authenticationTypeInput(): string | undefined;
        private _createUserLevelPrefix?;
        get createUserLevelPrefix(): boolean | cdktn.IResolvable;
        set createUserLevelPrefix(value: boolean | cdktn.IResolvable);
        resetCreateUserLevelPrefix(): void;
        get createUserLevelPrefixInput(): boolean | cdktn.IResolvable | undefined;
        private _enableS3AccessGrants?;
        get enableS3AccessGrants(): boolean | cdktn.IResolvable;
        set enableS3AccessGrants(value: boolean | cdktn.IResolvable);
        get enableS3AccessGrantsInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface AclConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/athena_workgroup#s3_acl_option AwsWorkgroup#s3_acl_option}
        */
        readonly s3AclOption: string;
    }
    class AclConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AclConfigurationProperty | undefined;
        set internalValue(value: AclConfigurationProperty | undefined);
        private _s3AclOption?;
        get s3AclOption(): string;
        set s3AclOption(value: string);
        get s3AclOptionInput(): string | undefined;
    }
    interface ConfigurationResultConfigurationEncryptionConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/athena_workgroup#encryption_option AwsWorkgroup#encryption_option}
        */
        readonly encryptionOption?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/athena_workgroup#kms_key_arn AwsWorkgroup#kms_key_arn}
        */
        readonly kmsKeyArn?: string;
    }
    class ConfigurationResultConfigurationEncryptionConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ConfigurationResultConfigurationEncryptionConfigurationProperty | undefined;
        set internalValue(value: ConfigurationResultConfigurationEncryptionConfigurationProperty | undefined);
        private _encryptionOption?;
        get encryptionOption(): string;
        set encryptionOption(value: string);
        resetEncryptionOption(): void;
        get encryptionOptionInput(): string | undefined;
        private _kmsKeyArn?;
        get kmsKeyArn(): string;
        set kmsKeyArn(value: string);
        resetKmsKeyArn(): void;
        get kmsKeyArnInput(): string | undefined;
    }
    interface ResultConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/athena_workgroup#expected_bucket_owner AwsWorkgroup#expected_bucket_owner}
        */
        readonly expectedBucketOwner?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/athena_workgroup#output_location AwsWorkgroup#output_location}
        */
        readonly outputLocation?: string;
        /**
        * acl_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/athena_workgroup#acl_configuration AwsWorkgroup#acl_configuration}
        */
        readonly aclConfiguration?: AclConfigurationProperty;
        /**
        * encryption_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/athena_workgroup#encryption_configuration AwsWorkgroup#encryption_configuration}
        */
        readonly encryptionConfiguration?: ConfigurationResultConfigurationEncryptionConfigurationProperty;
    }
    class ResultConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ResultConfigurationProperty | undefined;
        set internalValue(value: ResultConfigurationProperty | undefined);
        private _expectedBucketOwner?;
        get expectedBucketOwner(): string;
        set expectedBucketOwner(value: string);
        resetExpectedBucketOwner(): void;
        get expectedBucketOwnerInput(): string | undefined;
        private _outputLocation?;
        get outputLocation(): string;
        set outputLocation(value: string);
        resetOutputLocation(): void;
        get outputLocationInput(): string | undefined;
        private _aclConfiguration;
        get aclConfiguration(): AclConfigurationPropertyOutputReference;
        putAclConfiguration(value: AclConfigurationProperty): void;
        resetAclConfiguration(): void;
        get aclConfigurationInput(): AclConfigurationProperty | undefined;
        private _encryptionConfiguration;
        get encryptionConfiguration(): ConfigurationResultConfigurationEncryptionConfigurationPropertyOutputReference;
        putEncryptionConfiguration(value: ConfigurationResultConfigurationEncryptionConfigurationProperty): void;
        resetEncryptionConfiguration(): void;
        get encryptionConfigurationInput(): ConfigurationResultConfigurationEncryptionConfigurationProperty | undefined;
    }
    interface ConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/athena_workgroup#bytes_scanned_cutoff_per_query AwsWorkgroup#bytes_scanned_cutoff_per_query}
        */
        readonly bytesScannedCutoffPerQuery?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/athena_workgroup#enable_minimum_encryption_configuration AwsWorkgroup#enable_minimum_encryption_configuration}
        */
        readonly enableMinimumEncryptionConfiguration?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/athena_workgroup#enforce_workgroup_configuration AwsWorkgroup#enforce_workgroup_configuration}
        */
        readonly enforceWorkgroupConfiguration?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/athena_workgroup#execution_role AwsWorkgroup#execution_role}
        */
        readonly executionRole?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/athena_workgroup#publish_cloudwatch_metrics_enabled AwsWorkgroup#publish_cloudwatch_metrics_enabled}
        */
        readonly publishCloudwatchMetricsEnabled?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/athena_workgroup#requester_pays_enabled AwsWorkgroup#requester_pays_enabled}
        */
        readonly requesterPaysEnabled?: boolean | cdktn.IResolvable;
        /**
        * customer_content_encryption_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/athena_workgroup#customer_content_encryption_configuration AwsWorkgroup#customer_content_encryption_configuration}
        */
        readonly customerContentEncryptionConfiguration?: CustomerContentEncryptionConfigurationProperty;
        /**
        * engine_version block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/athena_workgroup#engine_version AwsWorkgroup#engine_version}
        */
        readonly engineVersion?: EngineVersionProperty;
        /**
        * identity_center_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/athena_workgroup#identity_center_configuration AwsWorkgroup#identity_center_configuration}
        */
        readonly identityCenterConfiguration?: IdentityCenterConfigurationProperty;
        /**
        * managed_query_results_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/athena_workgroup#managed_query_results_configuration AwsWorkgroup#managed_query_results_configuration}
        */
        readonly managedQueryResultsConfiguration?: ManagedQueryResultsConfigurationProperty;
        /**
        * monitoring_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/athena_workgroup#monitoring_configuration AwsWorkgroup#monitoring_configuration}
        */
        readonly monitoringConfiguration?: MonitoringConfigurationProperty;
        /**
        * query_results_s3_access_grants_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/athena_workgroup#query_results_s3_access_grants_configuration AwsWorkgroup#query_results_s3_access_grants_configuration}
        */
        readonly queryResultsS3AccessGrantsConfiguration?: QueryResultsS3AccessGrantsConfigurationProperty;
        /**
        * result_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/athena_workgroup#result_configuration AwsWorkgroup#result_configuration}
        */
        readonly resultConfiguration?: ResultConfigurationProperty;
    }
    class ConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ConfigurationProperty | undefined;
        set internalValue(value: ConfigurationProperty | undefined);
        private _bytesScannedCutoffPerQuery?;
        get bytesScannedCutoffPerQuery(): number;
        set bytesScannedCutoffPerQuery(value: number);
        resetBytesScannedCutoffPerQuery(): void;
        get bytesScannedCutoffPerQueryInput(): number | undefined;
        private _enableMinimumEncryptionConfiguration?;
        get enableMinimumEncryptionConfiguration(): boolean | cdktn.IResolvable;
        set enableMinimumEncryptionConfiguration(value: boolean | cdktn.IResolvable);
        resetEnableMinimumEncryptionConfiguration(): void;
        get enableMinimumEncryptionConfigurationInput(): boolean | cdktn.IResolvable | undefined;
        private _enforceWorkgroupConfiguration?;
        get enforceWorkgroupConfiguration(): boolean | cdktn.IResolvable;
        set enforceWorkgroupConfiguration(value: boolean | cdktn.IResolvable);
        resetEnforceWorkgroupConfiguration(): void;
        get enforceWorkgroupConfigurationInput(): boolean | cdktn.IResolvable | undefined;
        private _executionRole?;
        get executionRole(): string;
        set executionRole(value: string);
        resetExecutionRole(): void;
        get executionRoleInput(): string | undefined;
        private _publishCloudwatchMetricsEnabled?;
        get publishCloudwatchMetricsEnabled(): boolean | cdktn.IResolvable;
        set publishCloudwatchMetricsEnabled(value: boolean | cdktn.IResolvable);
        resetPublishCloudwatchMetricsEnabled(): void;
        get publishCloudwatchMetricsEnabledInput(): boolean | cdktn.IResolvable | undefined;
        private _requesterPaysEnabled?;
        get requesterPaysEnabled(): boolean | cdktn.IResolvable;
        set requesterPaysEnabled(value: boolean | cdktn.IResolvable);
        resetRequesterPaysEnabled(): void;
        get requesterPaysEnabledInput(): boolean | cdktn.IResolvable | undefined;
        private _customerContentEncryptionConfiguration;
        get customerContentEncryptionConfiguration(): CustomerContentEncryptionConfigurationPropertyOutputReference;
        putCustomerContentEncryptionConfiguration(value: CustomerContentEncryptionConfigurationProperty): void;
        resetCustomerContentEncryptionConfiguration(): void;
        get customerContentEncryptionConfigurationInput(): CustomerContentEncryptionConfigurationProperty | undefined;
        private _engineVersion;
        get engineVersion(): EngineVersionPropertyOutputReference;
        putEngineVersion(value: EngineVersionProperty): void;
        resetEngineVersion(): void;
        get engineVersionInput(): EngineVersionProperty | undefined;
        private _identityCenterConfiguration;
        get identityCenterConfiguration(): IdentityCenterConfigurationPropertyOutputReference;
        putIdentityCenterConfiguration(value: IdentityCenterConfigurationProperty): void;
        resetIdentityCenterConfiguration(): void;
        get identityCenterConfigurationInput(): IdentityCenterConfigurationProperty | undefined;
        private _managedQueryResultsConfiguration;
        get managedQueryResultsConfiguration(): ManagedQueryResultsConfigurationPropertyOutputReference;
        putManagedQueryResultsConfiguration(value: ManagedQueryResultsConfigurationProperty): void;
        resetManagedQueryResultsConfiguration(): void;
        get managedQueryResultsConfigurationInput(): ManagedQueryResultsConfigurationProperty | undefined;
        private _monitoringConfiguration;
        get monitoringConfiguration(): MonitoringConfigurationPropertyOutputReference;
        putMonitoringConfiguration(value: MonitoringConfigurationProperty): void;
        resetMonitoringConfiguration(): void;
        get monitoringConfigurationInput(): MonitoringConfigurationProperty | undefined;
        private _queryResultsS3AccessGrantsConfiguration;
        get queryResultsS3AccessGrantsConfiguration(): QueryResultsS3AccessGrantsConfigurationPropertyOutputReference;
        putQueryResultsS3AccessGrantsConfiguration(value: QueryResultsS3AccessGrantsConfigurationProperty): void;
        resetQueryResultsS3AccessGrantsConfiguration(): void;
        get queryResultsS3AccessGrantsConfigurationInput(): QueryResultsS3AccessGrantsConfigurationProperty | undefined;
        private _resultConfiguration;
        get resultConfiguration(): ResultConfigurationPropertyOutputReference;
        putResultConfiguration(value: ResultConfigurationProperty): void;
        resetResultConfiguration(): void;
        get resultConfigurationInput(): ResultConfigurationProperty | undefined;
    }
}
