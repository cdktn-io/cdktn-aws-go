import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsCloudwatchLogMetricFilterConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_log_metric_filter#apply_on_transformed_logs AwsCloudwatchLogMetricFilter#apply_on_transformed_logs}
    */
    readonly applyOnTransformedLogs?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_log_metric_filter#id AwsCloudwatchLogMetricFilter#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_log_metric_filter#log_group_name AwsCloudwatchLogMetricFilter#log_group_name}
    */
    readonly logGroupName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_log_metric_filter#name AwsCloudwatchLogMetricFilter#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_log_metric_filter#pattern AwsCloudwatchLogMetricFilter#pattern}
    */
    readonly pattern: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_log_metric_filter#region AwsCloudwatchLogMetricFilter#region}
    */
    readonly region?: string;
    /**
    * metric_transformation block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_log_metric_filter#metric_transformation AwsCloudwatchLogMetricFilter#metric_transformation}
    */
    readonly metricTransformation: AwsCloudwatchLogMetricFilter.MetricTransformationProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_log_metric_filter aws_cloudwatch_log_metric_filter}
*/
export declare class AwsCloudwatchLogMetricFilter extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_cloudwatch_log_metric_filter";
    /**
    * Generates CDKTN code for importing a AwsCloudwatchLogMetricFilter resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsCloudwatchLogMetricFilter to import
    * @param importFromId The id of the existing AwsCloudwatchLogMetricFilter that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_log_metric_filter#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsCloudwatchLogMetricFilter to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_log_metric_filter aws_cloudwatch_log_metric_filter} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsCloudwatchLogMetricFilterConfig
    */
    constructor(scope: Construct, id: string, config: AwsCloudwatchLogMetricFilterConfig);
    private _applyOnTransformedLogs?;
    get applyOnTransformedLogs(): boolean | cdktn.IResolvable;
    set applyOnTransformedLogs(value: boolean | cdktn.IResolvable);
    resetApplyOnTransformedLogs(): void;
    get applyOnTransformedLogsInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _logGroupName?;
    get logGroupName(): string;
    set logGroupName(value: string);
    get logGroupNameInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _pattern?;
    get pattern(): string;
    set pattern(value: string);
    get patternInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _metricTransformation;
    get metricTransformation(): AwsCloudwatchLogMetricFilter.MetricTransformationPropertyOutputReference;
    putMetricTransformation(value: AwsCloudwatchLogMetricFilter.MetricTransformationProperty): void;
    get metricTransformationInput(): AwsCloudwatchLogMetricFilter.MetricTransformationProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsCloudwatchLogMetricFilterMetricTransformationPropertyToTerraform(struct?: AwsCloudwatchLogMetricFilter.MetricTransformationPropertyOutputReference | AwsCloudwatchLogMetricFilter.MetricTransformationProperty): any;
export declare function awsCloudwatchLogMetricFilterMetricTransformationPropertyToHclTerraform(struct?: AwsCloudwatchLogMetricFilter.MetricTransformationPropertyOutputReference | AwsCloudwatchLogMetricFilter.MetricTransformationProperty): any;
export declare namespace AwsCloudwatchLogMetricFilter {
    interface MetricTransformationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_log_metric_filter#default_value AwsCloudwatchLogMetricFilter#default_value}
        */
        readonly defaultValue?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_log_metric_filter#dimensions AwsCloudwatchLogMetricFilter#dimensions}
        */
        readonly dimensions?: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_log_metric_filter#name AwsCloudwatchLogMetricFilter#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_log_metric_filter#namespace AwsCloudwatchLogMetricFilter#namespace}
        */
        readonly namespace: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_log_metric_filter#unit AwsCloudwatchLogMetricFilter#unit}
        */
        readonly unit?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_log_metric_filter#value AwsCloudwatchLogMetricFilter#value}
        */
        readonly value: string;
    }
    class MetricTransformationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): MetricTransformationProperty | undefined;
        set internalValue(value: MetricTransformationProperty | undefined);
        private _defaultValue?;
        get defaultValue(): string;
        set defaultValue(value: string);
        resetDefaultValue(): void;
        get defaultValueInput(): string | undefined;
        private _dimensions?;
        get dimensions(): {
            [key: string]: string;
        };
        set dimensions(value: {
            [key: string]: string;
        });
        resetDimensions(): void;
        get dimensionsInput(): {
            [key: string]: string;
        } | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _namespace?;
        get namespace(): string;
        set namespace(value: string);
        get namespaceInput(): string | undefined;
        private _unit?;
        get unit(): string;
        set unit(value: string);
        resetUnit(): void;
        get unitInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
}
