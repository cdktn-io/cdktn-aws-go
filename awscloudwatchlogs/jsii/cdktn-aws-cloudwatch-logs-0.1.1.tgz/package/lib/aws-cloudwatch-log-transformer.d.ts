import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsCloudwatchLogTransformerConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_log_transformer#log_group_arn AwsCloudwatchLogTransformer#log_group_arn}
    */
    readonly logGroupArn: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_log_transformer#region AwsCloudwatchLogTransformer#region}
    */
    readonly region?: string;
    /**
    * transformer_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_log_transformer#transformer_config AwsCloudwatchLogTransformer#transformer_config}
    */
    readonly transformerConfig?: AwsCloudwatchLogTransformer.TransformerConfigProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_log_transformer aws_cloudwatch_log_transformer}
*/
export declare class AwsCloudwatchLogTransformer extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_cloudwatch_log_transformer";
    /**
    * Generates CDKTN code for importing a AwsCloudwatchLogTransformer resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsCloudwatchLogTransformer to import
    * @param importFromId The id of the existing AwsCloudwatchLogTransformer that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_log_transformer#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsCloudwatchLogTransformer to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_log_transformer aws_cloudwatch_log_transformer} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsCloudwatchLogTransformerConfig
    */
    constructor(scope: Construct, id: string, config: AwsCloudwatchLogTransformerConfig);
    private _logGroupArn?;
    get logGroupArn(): string;
    set logGroupArn(value: string);
    get logGroupArnInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _transformerConfig;
    get transformerConfig(): AwsCloudwatchLogTransformer.TransformerConfigPropertyList;
    putTransformerConfig(value: AwsCloudwatchLogTransformer.TransformerConfigProperty[] | cdktn.IResolvable): void;
    resetTransformerConfig(): void;
    get transformerConfigInput(): cdktn.IResolvable | AwsCloudwatchLogTransformer.TransformerConfigProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsCloudwatchLogTransformerTransformerConfigAddKeysEntryPropertyToTerraform(struct?: AwsCloudwatchLogTransformer.TransformerConfigAddKeysEntryProperty | cdktn.IResolvable): any;
export declare function awsCloudwatchLogTransformerTransformerConfigAddKeysEntryPropertyToHclTerraform(struct?: AwsCloudwatchLogTransformer.TransformerConfigAddKeysEntryProperty | cdktn.IResolvable): any;
export declare function awsCloudwatchLogTransformerAddKeysPropertyToTerraform(struct?: AwsCloudwatchLogTransformer.AddKeysProperty | cdktn.IResolvable): any;
export declare function awsCloudwatchLogTransformerAddKeysPropertyToHclTerraform(struct?: AwsCloudwatchLogTransformer.AddKeysProperty | cdktn.IResolvable): any;
export declare function awsCloudwatchLogTransformerTransformerConfigCopyValueEntryPropertyToTerraform(struct?: AwsCloudwatchLogTransformer.TransformerConfigCopyValueEntryProperty | cdktn.IResolvable): any;
export declare function awsCloudwatchLogTransformerTransformerConfigCopyValueEntryPropertyToHclTerraform(struct?: AwsCloudwatchLogTransformer.TransformerConfigCopyValueEntryProperty | cdktn.IResolvable): any;
export declare function awsCloudwatchLogTransformerCopyValuePropertyToTerraform(struct?: AwsCloudwatchLogTransformer.CopyValueProperty | cdktn.IResolvable): any;
export declare function awsCloudwatchLogTransformerCopyValuePropertyToHclTerraform(struct?: AwsCloudwatchLogTransformer.CopyValueProperty | cdktn.IResolvable): any;
export declare function awsCloudwatchLogTransformerCsvPropertyToTerraform(struct?: AwsCloudwatchLogTransformer.CsvProperty | cdktn.IResolvable): any;
export declare function awsCloudwatchLogTransformerCsvPropertyToHclTerraform(struct?: AwsCloudwatchLogTransformer.CsvProperty | cdktn.IResolvable): any;
export declare function awsCloudwatchLogTransformerDateTimeConverterPropertyToTerraform(struct?: AwsCloudwatchLogTransformer.DateTimeConverterProperty | cdktn.IResolvable): any;
export declare function awsCloudwatchLogTransformerDateTimeConverterPropertyToHclTerraform(struct?: AwsCloudwatchLogTransformer.DateTimeConverterProperty | cdktn.IResolvable): any;
export declare function awsCloudwatchLogTransformerDeleteKeysPropertyToTerraform(struct?: AwsCloudwatchLogTransformer.DeleteKeysProperty | cdktn.IResolvable): any;
export declare function awsCloudwatchLogTransformerDeleteKeysPropertyToHclTerraform(struct?: AwsCloudwatchLogTransformer.DeleteKeysProperty | cdktn.IResolvable): any;
export declare function awsCloudwatchLogTransformerGrokPropertyToTerraform(struct?: AwsCloudwatchLogTransformer.GrokProperty | cdktn.IResolvable): any;
export declare function awsCloudwatchLogTransformerGrokPropertyToHclTerraform(struct?: AwsCloudwatchLogTransformer.GrokProperty | cdktn.IResolvable): any;
export declare function awsCloudwatchLogTransformerListToMapPropertyToTerraform(struct?: AwsCloudwatchLogTransformer.ListToMapProperty | cdktn.IResolvable): any;
export declare function awsCloudwatchLogTransformerListToMapPropertyToHclTerraform(struct?: AwsCloudwatchLogTransformer.ListToMapProperty | cdktn.IResolvable): any;
export declare function awsCloudwatchLogTransformerLowerCaseStringPropertyToTerraform(struct?: AwsCloudwatchLogTransformer.LowerCaseStringProperty | cdktn.IResolvable): any;
export declare function awsCloudwatchLogTransformerLowerCaseStringPropertyToHclTerraform(struct?: AwsCloudwatchLogTransformer.LowerCaseStringProperty | cdktn.IResolvable): any;
export declare function awsCloudwatchLogTransformerTransformerConfigMoveKeysEntryPropertyToTerraform(struct?: AwsCloudwatchLogTransformer.TransformerConfigMoveKeysEntryProperty | cdktn.IResolvable): any;
export declare function awsCloudwatchLogTransformerTransformerConfigMoveKeysEntryPropertyToHclTerraform(struct?: AwsCloudwatchLogTransformer.TransformerConfigMoveKeysEntryProperty | cdktn.IResolvable): any;
export declare function awsCloudwatchLogTransformerMoveKeysPropertyToTerraform(struct?: AwsCloudwatchLogTransformer.MoveKeysProperty | cdktn.IResolvable): any;
export declare function awsCloudwatchLogTransformerMoveKeysPropertyToHclTerraform(struct?: AwsCloudwatchLogTransformer.MoveKeysProperty | cdktn.IResolvable): any;
export declare function awsCloudwatchLogTransformerParseCloudfrontPropertyToTerraform(struct?: AwsCloudwatchLogTransformer.ParseCloudfrontProperty | cdktn.IResolvable): any;
export declare function awsCloudwatchLogTransformerParseCloudfrontPropertyToHclTerraform(struct?: AwsCloudwatchLogTransformer.ParseCloudfrontProperty | cdktn.IResolvable): any;
export declare function awsCloudwatchLogTransformerParseJsonPropertyToTerraform(struct?: AwsCloudwatchLogTransformer.ParseJsonProperty | cdktn.IResolvable): any;
export declare function awsCloudwatchLogTransformerParseJsonPropertyToHclTerraform(struct?: AwsCloudwatchLogTransformer.ParseJsonProperty | cdktn.IResolvable): any;
export declare function awsCloudwatchLogTransformerParseKeyValuePropertyToTerraform(struct?: AwsCloudwatchLogTransformer.ParseKeyValueProperty | cdktn.IResolvable): any;
export declare function awsCloudwatchLogTransformerParseKeyValuePropertyToHclTerraform(struct?: AwsCloudwatchLogTransformer.ParseKeyValueProperty | cdktn.IResolvable): any;
export declare function awsCloudwatchLogTransformerParsePostgresPropertyToTerraform(struct?: AwsCloudwatchLogTransformer.ParsePostgresProperty | cdktn.IResolvable): any;
export declare function awsCloudwatchLogTransformerParsePostgresPropertyToHclTerraform(struct?: AwsCloudwatchLogTransformer.ParsePostgresProperty | cdktn.IResolvable): any;
export declare function awsCloudwatchLogTransformerParseRoute53PropertyToTerraform(struct?: AwsCloudwatchLogTransformer.ParseRoute53Property | cdktn.IResolvable): any;
export declare function awsCloudwatchLogTransformerParseRoute53PropertyToHclTerraform(struct?: AwsCloudwatchLogTransformer.ParseRoute53Property | cdktn.IResolvable): any;
export declare function awsCloudwatchLogTransformerParseToOcsfPropertyToTerraform(struct?: AwsCloudwatchLogTransformer.ParseToOcsfProperty | cdktn.IResolvable): any;
export declare function awsCloudwatchLogTransformerParseToOcsfPropertyToHclTerraform(struct?: AwsCloudwatchLogTransformer.ParseToOcsfProperty | cdktn.IResolvable): any;
export declare function awsCloudwatchLogTransformerParseVpcPropertyToTerraform(struct?: AwsCloudwatchLogTransformer.ParseVpcProperty | cdktn.IResolvable): any;
export declare function awsCloudwatchLogTransformerParseVpcPropertyToHclTerraform(struct?: AwsCloudwatchLogTransformer.ParseVpcProperty | cdktn.IResolvable): any;
export declare function awsCloudwatchLogTransformerParseWafPropertyToTerraform(struct?: AwsCloudwatchLogTransformer.ParseWafProperty | cdktn.IResolvable): any;
export declare function awsCloudwatchLogTransformerParseWafPropertyToHclTerraform(struct?: AwsCloudwatchLogTransformer.ParseWafProperty | cdktn.IResolvable): any;
export declare function awsCloudwatchLogTransformerTransformerConfigRenameKeysEntryPropertyToTerraform(struct?: AwsCloudwatchLogTransformer.TransformerConfigRenameKeysEntryProperty | cdktn.IResolvable): any;
export declare function awsCloudwatchLogTransformerTransformerConfigRenameKeysEntryPropertyToHclTerraform(struct?: AwsCloudwatchLogTransformer.TransformerConfigRenameKeysEntryProperty | cdktn.IResolvable): any;
export declare function awsCloudwatchLogTransformerRenameKeysPropertyToTerraform(struct?: AwsCloudwatchLogTransformer.RenameKeysProperty | cdktn.IResolvable): any;
export declare function awsCloudwatchLogTransformerRenameKeysPropertyToHclTerraform(struct?: AwsCloudwatchLogTransformer.RenameKeysProperty | cdktn.IResolvable): any;
export declare function awsCloudwatchLogTransformerTransformerConfigSplitStringEntryPropertyToTerraform(struct?: AwsCloudwatchLogTransformer.TransformerConfigSplitStringEntryProperty | cdktn.IResolvable): any;
export declare function awsCloudwatchLogTransformerTransformerConfigSplitStringEntryPropertyToHclTerraform(struct?: AwsCloudwatchLogTransformer.TransformerConfigSplitStringEntryProperty | cdktn.IResolvable): any;
export declare function awsCloudwatchLogTransformerSplitStringPropertyToTerraform(struct?: AwsCloudwatchLogTransformer.SplitStringProperty | cdktn.IResolvable): any;
export declare function awsCloudwatchLogTransformerSplitStringPropertyToHclTerraform(struct?: AwsCloudwatchLogTransformer.SplitStringProperty | cdktn.IResolvable): any;
export declare function awsCloudwatchLogTransformerTransformerConfigSubstituteStringEntryPropertyToTerraform(struct?: AwsCloudwatchLogTransformer.TransformerConfigSubstituteStringEntryProperty | cdktn.IResolvable): any;
export declare function awsCloudwatchLogTransformerTransformerConfigSubstituteStringEntryPropertyToHclTerraform(struct?: AwsCloudwatchLogTransformer.TransformerConfigSubstituteStringEntryProperty | cdktn.IResolvable): any;
export declare function awsCloudwatchLogTransformerSubstituteStringPropertyToTerraform(struct?: AwsCloudwatchLogTransformer.SubstituteStringProperty | cdktn.IResolvable): any;
export declare function awsCloudwatchLogTransformerSubstituteStringPropertyToHclTerraform(struct?: AwsCloudwatchLogTransformer.SubstituteStringProperty | cdktn.IResolvable): any;
export declare function awsCloudwatchLogTransformerTrimStringPropertyToTerraform(struct?: AwsCloudwatchLogTransformer.TrimStringProperty | cdktn.IResolvable): any;
export declare function awsCloudwatchLogTransformerTrimStringPropertyToHclTerraform(struct?: AwsCloudwatchLogTransformer.TrimStringProperty | cdktn.IResolvable): any;
export declare function awsCloudwatchLogTransformerTransformerConfigTypeConverterEntryPropertyToTerraform(struct?: AwsCloudwatchLogTransformer.TransformerConfigTypeConverterEntryProperty | cdktn.IResolvable): any;
export declare function awsCloudwatchLogTransformerTransformerConfigTypeConverterEntryPropertyToHclTerraform(struct?: AwsCloudwatchLogTransformer.TransformerConfigTypeConverterEntryProperty | cdktn.IResolvable): any;
export declare function awsCloudwatchLogTransformerTypeConverterPropertyToTerraform(struct?: AwsCloudwatchLogTransformer.TypeConverterProperty | cdktn.IResolvable): any;
export declare function awsCloudwatchLogTransformerTypeConverterPropertyToHclTerraform(struct?: AwsCloudwatchLogTransformer.TypeConverterProperty | cdktn.IResolvable): any;
export declare function awsCloudwatchLogTransformerUpperCaseStringPropertyToTerraform(struct?: AwsCloudwatchLogTransformer.UpperCaseStringProperty | cdktn.IResolvable): any;
export declare function awsCloudwatchLogTransformerUpperCaseStringPropertyToHclTerraform(struct?: AwsCloudwatchLogTransformer.UpperCaseStringProperty | cdktn.IResolvable): any;
export declare function awsCloudwatchLogTransformerTransformerConfigPropertyToTerraform(struct?: AwsCloudwatchLogTransformer.TransformerConfigProperty | cdktn.IResolvable): any;
export declare function awsCloudwatchLogTransformerTransformerConfigPropertyToHclTerraform(struct?: AwsCloudwatchLogTransformer.TransformerConfigProperty | cdktn.IResolvable): any;
export declare namespace AwsCloudwatchLogTransformer {
    interface TransformerConfigAddKeysEntryProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_log_transformer#key AwsCloudwatchLogTransformer#key}
        */
        readonly key: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_log_transformer#overwrite_if_exists AwsCloudwatchLogTransformer#overwrite_if_exists}
        */
        readonly overwriteIfExists?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_log_transformer#value AwsCloudwatchLogTransformer#value}
        */
        readonly value: string;
    }
    class TransformerConfigAddKeysEntryPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TransformerConfigAddKeysEntryProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TransformerConfigAddKeysEntryProperty | cdktn.IResolvable | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        get keyInput(): string | undefined;
        private _overwriteIfExists?;
        get overwriteIfExists(): boolean | cdktn.IResolvable;
        set overwriteIfExists(value: boolean | cdktn.IResolvable);
        resetOverwriteIfExists(): void;
        get overwriteIfExistsInput(): boolean | cdktn.IResolvable | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class TransformerConfigAddKeysEntryPropertyList extends cdktn.ComplexList {
        internalValue?: TransformerConfigAddKeysEntryProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TransformerConfigAddKeysEntryPropertyOutputReference;
    }
    interface AddKeysProperty {
        /**
        * entry block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_log_transformer#entry AwsCloudwatchLogTransformer#entry}
        */
        readonly entry?: TransformerConfigAddKeysEntryProperty[] | cdktn.IResolvable;
    }
    class AddKeysPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AddKeysProperty | cdktn.IResolvable | undefined;
        set internalValue(value: AddKeysProperty | cdktn.IResolvable | undefined);
        private _entry;
        get entry(): TransformerConfigAddKeysEntryPropertyList;
        putEntry(value: TransformerConfigAddKeysEntryProperty[] | cdktn.IResolvable): void;
        resetEntry(): void;
        get entryInput(): cdktn.IResolvable | TransformerConfigAddKeysEntryProperty[] | undefined;
    }
    class AddKeysPropertyList extends cdktn.ComplexList {
        internalValue?: AddKeysProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AddKeysPropertyOutputReference;
    }
    interface TransformerConfigCopyValueEntryProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_log_transformer#overwrite_if_exists AwsCloudwatchLogTransformer#overwrite_if_exists}
        */
        readonly overwriteIfExists?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_log_transformer#source AwsCloudwatchLogTransformer#source}
        */
        readonly source: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_log_transformer#target AwsCloudwatchLogTransformer#target}
        */
        readonly target: string;
    }
    class TransformerConfigCopyValueEntryPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TransformerConfigCopyValueEntryProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TransformerConfigCopyValueEntryProperty | cdktn.IResolvable | undefined);
        private _overwriteIfExists?;
        get overwriteIfExists(): boolean | cdktn.IResolvable;
        set overwriteIfExists(value: boolean | cdktn.IResolvable);
        resetOverwriteIfExists(): void;
        get overwriteIfExistsInput(): boolean | cdktn.IResolvable | undefined;
        private _source?;
        get source(): string;
        set source(value: string);
        get sourceInput(): string | undefined;
        private _target?;
        get target(): string;
        set target(value: string);
        get targetInput(): string | undefined;
    }
    class TransformerConfigCopyValueEntryPropertyList extends cdktn.ComplexList {
        internalValue?: TransformerConfigCopyValueEntryProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TransformerConfigCopyValueEntryPropertyOutputReference;
    }
    interface CopyValueProperty {
        /**
        * entry block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_log_transformer#entry AwsCloudwatchLogTransformer#entry}
        */
        readonly entry?: TransformerConfigCopyValueEntryProperty[] | cdktn.IResolvable;
    }
    class CopyValuePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CopyValueProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CopyValueProperty | cdktn.IResolvable | undefined);
        private _entry;
        get entry(): TransformerConfigCopyValueEntryPropertyList;
        putEntry(value: TransformerConfigCopyValueEntryProperty[] | cdktn.IResolvable): void;
        resetEntry(): void;
        get entryInput(): cdktn.IResolvable | TransformerConfigCopyValueEntryProperty[] | undefined;
    }
    class CopyValuePropertyList extends cdktn.ComplexList {
        internalValue?: CopyValueProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CopyValuePropertyOutputReference;
    }
    interface CsvProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_log_transformer#columns AwsCloudwatchLogTransformer#columns}
        */
        readonly columns?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_log_transformer#delimiter AwsCloudwatchLogTransformer#delimiter}
        */
        readonly delimiter?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_log_transformer#quote_character AwsCloudwatchLogTransformer#quote_character}
        */
        readonly quoteCharacter?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_log_transformer#source AwsCloudwatchLogTransformer#source}
        */
        readonly source?: string;
    }
    class CsvPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CsvProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CsvProperty | cdktn.IResolvable | undefined);
        private _columns?;
        get columns(): string[];
        set columns(value: string[]);
        resetColumns(): void;
        get columnsInput(): string[] | undefined;
        private _delimiter?;
        get delimiter(): string;
        set delimiter(value: string);
        resetDelimiter(): void;
        get delimiterInput(): string | undefined;
        private _quoteCharacter?;
        get quoteCharacter(): string;
        set quoteCharacter(value: string);
        resetQuoteCharacter(): void;
        get quoteCharacterInput(): string | undefined;
        private _source?;
        get source(): string;
        set source(value: string);
        resetSource(): void;
        get sourceInput(): string | undefined;
    }
    class CsvPropertyList extends cdktn.ComplexList {
        internalValue?: CsvProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CsvPropertyOutputReference;
    }
    interface DateTimeConverterProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_log_transformer#locale AwsCloudwatchLogTransformer#locale}
        */
        readonly locale?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_log_transformer#match_patterns AwsCloudwatchLogTransformer#match_patterns}
        */
        readonly matchPatterns: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_log_transformer#source AwsCloudwatchLogTransformer#source}
        */
        readonly source: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_log_transformer#source_timezone AwsCloudwatchLogTransformer#source_timezone}
        */
        readonly sourceTimezone?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_log_transformer#target AwsCloudwatchLogTransformer#target}
        */
        readonly target: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_log_transformer#target_format AwsCloudwatchLogTransformer#target_format}
        */
        readonly targetFormat?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_log_transformer#target_timezone AwsCloudwatchLogTransformer#target_timezone}
        */
        readonly targetTimezone?: string;
    }
    class DateTimeConverterPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DateTimeConverterProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DateTimeConverterProperty | cdktn.IResolvable | undefined);
        private _locale?;
        get locale(): string;
        set locale(value: string);
        resetLocale(): void;
        get localeInput(): string | undefined;
        private _matchPatterns?;
        get matchPatterns(): string[];
        set matchPatterns(value: string[]);
        get matchPatternsInput(): string[] | undefined;
        private _source?;
        get source(): string;
        set source(value: string);
        get sourceInput(): string | undefined;
        private _sourceTimezone?;
        get sourceTimezone(): string;
        set sourceTimezone(value: string);
        resetSourceTimezone(): void;
        get sourceTimezoneInput(): string | undefined;
        private _target?;
        get target(): string;
        set target(value: string);
        get targetInput(): string | undefined;
        private _targetFormat?;
        get targetFormat(): string;
        set targetFormat(value: string);
        resetTargetFormat(): void;
        get targetFormatInput(): string | undefined;
        private _targetTimezone?;
        get targetTimezone(): string;
        set targetTimezone(value: string);
        resetTargetTimezone(): void;
        get targetTimezoneInput(): string | undefined;
    }
    class DateTimeConverterPropertyList extends cdktn.ComplexList {
        internalValue?: DateTimeConverterProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DateTimeConverterPropertyOutputReference;
    }
    interface DeleteKeysProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_log_transformer#with_keys AwsCloudwatchLogTransformer#with_keys}
        */
        readonly withKeys: string[];
    }
    class DeleteKeysPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DeleteKeysProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DeleteKeysProperty | cdktn.IResolvable | undefined);
        private _withKeys?;
        get withKeys(): string[];
        set withKeys(value: string[]);
        get withKeysInput(): string[] | undefined;
    }
    class DeleteKeysPropertyList extends cdktn.ComplexList {
        internalValue?: DeleteKeysProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DeleteKeysPropertyOutputReference;
    }
    interface GrokProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_log_transformer#match AwsCloudwatchLogTransformer#match}
        */
        readonly match: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_log_transformer#source AwsCloudwatchLogTransformer#source}
        */
        readonly source?: string;
    }
    class GrokPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): GrokProperty | cdktn.IResolvable | undefined;
        set internalValue(value: GrokProperty | cdktn.IResolvable | undefined);
        private _match?;
        get match(): string;
        set match(value: string);
        get matchInput(): string | undefined;
        private _source?;
        get source(): string;
        set source(value: string);
        resetSource(): void;
        get sourceInput(): string | undefined;
    }
    class GrokPropertyList extends cdktn.ComplexList {
        internalValue?: GrokProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): GrokPropertyOutputReference;
    }
    interface ListToMapProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_log_transformer#flatten AwsCloudwatchLogTransformer#flatten}
        */
        readonly flatten?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_log_transformer#flattened_element AwsCloudwatchLogTransformer#flattened_element}
        */
        readonly flattenedElement?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_log_transformer#key AwsCloudwatchLogTransformer#key}
        */
        readonly key: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_log_transformer#source AwsCloudwatchLogTransformer#source}
        */
        readonly source: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_log_transformer#target AwsCloudwatchLogTransformer#target}
        */
        readonly target?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_log_transformer#value_key AwsCloudwatchLogTransformer#value_key}
        */
        readonly valueKey?: string;
    }
    class ListToMapPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ListToMapProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ListToMapProperty | cdktn.IResolvable | undefined);
        private _flatten?;
        get flatten(): boolean | cdktn.IResolvable;
        set flatten(value: boolean | cdktn.IResolvable);
        resetFlatten(): void;
        get flattenInput(): boolean | cdktn.IResolvable | undefined;
        private _flattenedElement?;
        get flattenedElement(): string;
        set flattenedElement(value: string);
        resetFlattenedElement(): void;
        get flattenedElementInput(): string | undefined;
        private _key?;
        get key(): string;
        set key(value: string);
        get keyInput(): string | undefined;
        private _source?;
        get source(): string;
        set source(value: string);
        get sourceInput(): string | undefined;
        private _target?;
        get target(): string;
        set target(value: string);
        resetTarget(): void;
        get targetInput(): string | undefined;
        private _valueKey?;
        get valueKey(): string;
        set valueKey(value: string);
        resetValueKey(): void;
        get valueKeyInput(): string | undefined;
    }
    class ListToMapPropertyList extends cdktn.ComplexList {
        internalValue?: ListToMapProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ListToMapPropertyOutputReference;
    }
    interface LowerCaseStringProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_log_transformer#with_keys AwsCloudwatchLogTransformer#with_keys}
        */
        readonly withKeys: string[];
    }
    class LowerCaseStringPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): LowerCaseStringProperty | cdktn.IResolvable | undefined;
        set internalValue(value: LowerCaseStringProperty | cdktn.IResolvable | undefined);
        private _withKeys?;
        get withKeys(): string[];
        set withKeys(value: string[]);
        get withKeysInput(): string[] | undefined;
    }
    class LowerCaseStringPropertyList extends cdktn.ComplexList {
        internalValue?: LowerCaseStringProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): LowerCaseStringPropertyOutputReference;
    }
    interface TransformerConfigMoveKeysEntryProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_log_transformer#overwrite_if_exists AwsCloudwatchLogTransformer#overwrite_if_exists}
        */
        readonly overwriteIfExists?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_log_transformer#source AwsCloudwatchLogTransformer#source}
        */
        readonly source: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_log_transformer#target AwsCloudwatchLogTransformer#target}
        */
        readonly target: string;
    }
    class TransformerConfigMoveKeysEntryPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TransformerConfigMoveKeysEntryProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TransformerConfigMoveKeysEntryProperty | cdktn.IResolvable | undefined);
        private _overwriteIfExists?;
        get overwriteIfExists(): boolean | cdktn.IResolvable;
        set overwriteIfExists(value: boolean | cdktn.IResolvable);
        resetOverwriteIfExists(): void;
        get overwriteIfExistsInput(): boolean | cdktn.IResolvable | undefined;
        private _source?;
        get source(): string;
        set source(value: string);
        get sourceInput(): string | undefined;
        private _target?;
        get target(): string;
        set target(value: string);
        get targetInput(): string | undefined;
    }
    class TransformerConfigMoveKeysEntryPropertyList extends cdktn.ComplexList {
        internalValue?: TransformerConfigMoveKeysEntryProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TransformerConfigMoveKeysEntryPropertyOutputReference;
    }
    interface MoveKeysProperty {
        /**
        * entry block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_log_transformer#entry AwsCloudwatchLogTransformer#entry}
        */
        readonly entry?: TransformerConfigMoveKeysEntryProperty[] | cdktn.IResolvable;
    }
    class MoveKeysPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): MoveKeysProperty | cdktn.IResolvable | undefined;
        set internalValue(value: MoveKeysProperty | cdktn.IResolvable | undefined);
        private _entry;
        get entry(): TransformerConfigMoveKeysEntryPropertyList;
        putEntry(value: TransformerConfigMoveKeysEntryProperty[] | cdktn.IResolvable): void;
        resetEntry(): void;
        get entryInput(): cdktn.IResolvable | TransformerConfigMoveKeysEntryProperty[] | undefined;
    }
    class MoveKeysPropertyList extends cdktn.ComplexList {
        internalValue?: MoveKeysProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): MoveKeysPropertyOutputReference;
    }
    interface ParseCloudfrontProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_log_transformer#source AwsCloudwatchLogTransformer#source}
        */
        readonly source?: string;
    }
    class ParseCloudfrontPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ParseCloudfrontProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ParseCloudfrontProperty | cdktn.IResolvable | undefined);
        private _source?;
        get source(): string;
        set source(value: string);
        resetSource(): void;
        get sourceInput(): string | undefined;
    }
    class ParseCloudfrontPropertyList extends cdktn.ComplexList {
        internalValue?: ParseCloudfrontProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ParseCloudfrontPropertyOutputReference;
    }
    interface ParseJsonProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_log_transformer#destination AwsCloudwatchLogTransformer#destination}
        */
        readonly destination?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_log_transformer#source AwsCloudwatchLogTransformer#source}
        */
        readonly source?: string;
    }
    class ParseJsonPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ParseJsonProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ParseJsonProperty | cdktn.IResolvable | undefined);
        private _destination?;
        get destination(): string;
        set destination(value: string);
        resetDestination(): void;
        get destinationInput(): string | undefined;
        private _source?;
        get source(): string;
        set source(value: string);
        resetSource(): void;
        get sourceInput(): string | undefined;
    }
    class ParseJsonPropertyList extends cdktn.ComplexList {
        internalValue?: ParseJsonProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ParseJsonPropertyOutputReference;
    }
    interface ParseKeyValueProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_log_transformer#destination AwsCloudwatchLogTransformer#destination}
        */
        readonly destination?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_log_transformer#field_delimiter AwsCloudwatchLogTransformer#field_delimiter}
        */
        readonly fieldDelimiter?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_log_transformer#key_prefix AwsCloudwatchLogTransformer#key_prefix}
        */
        readonly keyPrefix?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_log_transformer#key_value_delimiter AwsCloudwatchLogTransformer#key_value_delimiter}
        */
        readonly keyValueDelimiter?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_log_transformer#non_match_value AwsCloudwatchLogTransformer#non_match_value}
        */
        readonly nonMatchValue?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_log_transformer#overwrite_if_exists AwsCloudwatchLogTransformer#overwrite_if_exists}
        */
        readonly overwriteIfExists?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_log_transformer#source AwsCloudwatchLogTransformer#source}
        */
        readonly source?: string;
    }
    class ParseKeyValuePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ParseKeyValueProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ParseKeyValueProperty | cdktn.IResolvable | undefined);
        private _destination?;
        get destination(): string;
        set destination(value: string);
        resetDestination(): void;
        get destinationInput(): string | undefined;
        private _fieldDelimiter?;
        get fieldDelimiter(): string;
        set fieldDelimiter(value: string);
        resetFieldDelimiter(): void;
        get fieldDelimiterInput(): string | undefined;
        private _keyPrefix?;
        get keyPrefix(): string;
        set keyPrefix(value: string);
        resetKeyPrefix(): void;
        get keyPrefixInput(): string | undefined;
        private _keyValueDelimiter?;
        get keyValueDelimiter(): string;
        set keyValueDelimiter(value: string);
        resetKeyValueDelimiter(): void;
        get keyValueDelimiterInput(): string | undefined;
        private _nonMatchValue?;
        get nonMatchValue(): string;
        set nonMatchValue(value: string);
        resetNonMatchValue(): void;
        get nonMatchValueInput(): string | undefined;
        private _overwriteIfExists?;
        get overwriteIfExists(): boolean | cdktn.IResolvable;
        set overwriteIfExists(value: boolean | cdktn.IResolvable);
        resetOverwriteIfExists(): void;
        get overwriteIfExistsInput(): boolean | cdktn.IResolvable | undefined;
        private _source?;
        get source(): string;
        set source(value: string);
        resetSource(): void;
        get sourceInput(): string | undefined;
    }
    class ParseKeyValuePropertyList extends cdktn.ComplexList {
        internalValue?: ParseKeyValueProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ParseKeyValuePropertyOutputReference;
    }
    interface ParsePostgresProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_log_transformer#source AwsCloudwatchLogTransformer#source}
        */
        readonly source?: string;
    }
    class ParsePostgresPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ParsePostgresProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ParsePostgresProperty | cdktn.IResolvable | undefined);
        private _source?;
        get source(): string;
        set source(value: string);
        resetSource(): void;
        get sourceInput(): string | undefined;
    }
    class ParsePostgresPropertyList extends cdktn.ComplexList {
        internalValue?: ParsePostgresProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ParsePostgresPropertyOutputReference;
    }
    interface ParseRoute53Property {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_log_transformer#source AwsCloudwatchLogTransformer#source}
        */
        readonly source?: string;
    }
    class ParseRoute53PropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ParseRoute53Property | cdktn.IResolvable | undefined;
        set internalValue(value: ParseRoute53Property | cdktn.IResolvable | undefined);
        private _source?;
        get source(): string;
        set source(value: string);
        resetSource(): void;
        get sourceInput(): string | undefined;
    }
    class ParseRoute53PropertyList extends cdktn.ComplexList {
        internalValue?: ParseRoute53Property[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ParseRoute53PropertyOutputReference;
    }
    interface ParseToOcsfProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_log_transformer#event_source AwsCloudwatchLogTransformer#event_source}
        */
        readonly eventSource: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_log_transformer#ocsf_version AwsCloudwatchLogTransformer#ocsf_version}
        */
        readonly ocsfVersion: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_log_transformer#source AwsCloudwatchLogTransformer#source}
        */
        readonly source?: string;
    }
    class ParseToOcsfPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ParseToOcsfProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ParseToOcsfProperty | cdktn.IResolvable | undefined);
        private _eventSource?;
        get eventSource(): string;
        set eventSource(value: string);
        get eventSourceInput(): string | undefined;
        private _ocsfVersion?;
        get ocsfVersion(): string;
        set ocsfVersion(value: string);
        get ocsfVersionInput(): string | undefined;
        private _source?;
        get source(): string;
        set source(value: string);
        resetSource(): void;
        get sourceInput(): string | undefined;
    }
    class ParseToOcsfPropertyList extends cdktn.ComplexList {
        internalValue?: ParseToOcsfProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ParseToOcsfPropertyOutputReference;
    }
    interface ParseVpcProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_log_transformer#source AwsCloudwatchLogTransformer#source}
        */
        readonly source?: string;
    }
    class ParseVpcPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ParseVpcProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ParseVpcProperty | cdktn.IResolvable | undefined);
        private _source?;
        get source(): string;
        set source(value: string);
        resetSource(): void;
        get sourceInput(): string | undefined;
    }
    class ParseVpcPropertyList extends cdktn.ComplexList {
        internalValue?: ParseVpcProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ParseVpcPropertyOutputReference;
    }
    interface ParseWafProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_log_transformer#source AwsCloudwatchLogTransformer#source}
        */
        readonly source?: string;
    }
    class ParseWafPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ParseWafProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ParseWafProperty | cdktn.IResolvable | undefined);
        private _source?;
        get source(): string;
        set source(value: string);
        resetSource(): void;
        get sourceInput(): string | undefined;
    }
    class ParseWafPropertyList extends cdktn.ComplexList {
        internalValue?: ParseWafProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ParseWafPropertyOutputReference;
    }
    interface TransformerConfigRenameKeysEntryProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_log_transformer#key AwsCloudwatchLogTransformer#key}
        */
        readonly key: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_log_transformer#overwrite_if_exists AwsCloudwatchLogTransformer#overwrite_if_exists}
        */
        readonly overwriteIfExists?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_log_transformer#rename_to AwsCloudwatchLogTransformer#rename_to}
        */
        readonly renameTo: string;
    }
    class TransformerConfigRenameKeysEntryPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TransformerConfigRenameKeysEntryProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TransformerConfigRenameKeysEntryProperty | cdktn.IResolvable | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        get keyInput(): string | undefined;
        private _overwriteIfExists?;
        get overwriteIfExists(): boolean | cdktn.IResolvable;
        set overwriteIfExists(value: boolean | cdktn.IResolvable);
        resetOverwriteIfExists(): void;
        get overwriteIfExistsInput(): boolean | cdktn.IResolvable | undefined;
        private _renameTo?;
        get renameTo(): string;
        set renameTo(value: string);
        get renameToInput(): string | undefined;
    }
    class TransformerConfigRenameKeysEntryPropertyList extends cdktn.ComplexList {
        internalValue?: TransformerConfigRenameKeysEntryProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TransformerConfigRenameKeysEntryPropertyOutputReference;
    }
    interface RenameKeysProperty {
        /**
        * entry block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_log_transformer#entry AwsCloudwatchLogTransformer#entry}
        */
        readonly entry?: TransformerConfigRenameKeysEntryProperty[] | cdktn.IResolvable;
    }
    class RenameKeysPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RenameKeysProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RenameKeysProperty | cdktn.IResolvable | undefined);
        private _entry;
        get entry(): TransformerConfigRenameKeysEntryPropertyList;
        putEntry(value: TransformerConfigRenameKeysEntryProperty[] | cdktn.IResolvable): void;
        resetEntry(): void;
        get entryInput(): cdktn.IResolvable | TransformerConfigRenameKeysEntryProperty[] | undefined;
    }
    class RenameKeysPropertyList extends cdktn.ComplexList {
        internalValue?: RenameKeysProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RenameKeysPropertyOutputReference;
    }
    interface TransformerConfigSplitStringEntryProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_log_transformer#delimiter AwsCloudwatchLogTransformer#delimiter}
        */
        readonly delimiter: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_log_transformer#source AwsCloudwatchLogTransformer#source}
        */
        readonly source: string;
    }
    class TransformerConfigSplitStringEntryPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TransformerConfigSplitStringEntryProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TransformerConfigSplitStringEntryProperty | cdktn.IResolvable | undefined);
        private _delimiter?;
        get delimiter(): string;
        set delimiter(value: string);
        get delimiterInput(): string | undefined;
        private _source?;
        get source(): string;
        set source(value: string);
        get sourceInput(): string | undefined;
    }
    class TransformerConfigSplitStringEntryPropertyList extends cdktn.ComplexList {
        internalValue?: TransformerConfigSplitStringEntryProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TransformerConfigSplitStringEntryPropertyOutputReference;
    }
    interface SplitStringProperty {
        /**
        * entry block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_log_transformer#entry AwsCloudwatchLogTransformer#entry}
        */
        readonly entry?: TransformerConfigSplitStringEntryProperty[] | cdktn.IResolvable;
    }
    class SplitStringPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SplitStringProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SplitStringProperty | cdktn.IResolvable | undefined);
        private _entry;
        get entry(): TransformerConfigSplitStringEntryPropertyList;
        putEntry(value: TransformerConfigSplitStringEntryProperty[] | cdktn.IResolvable): void;
        resetEntry(): void;
        get entryInput(): cdktn.IResolvable | TransformerConfigSplitStringEntryProperty[] | undefined;
    }
    class SplitStringPropertyList extends cdktn.ComplexList {
        internalValue?: SplitStringProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SplitStringPropertyOutputReference;
    }
    interface TransformerConfigSubstituteStringEntryProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_log_transformer#from AwsCloudwatchLogTransformer#from}
        */
        readonly from: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_log_transformer#source AwsCloudwatchLogTransformer#source}
        */
        readonly source: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_log_transformer#to AwsCloudwatchLogTransformer#to}
        */
        readonly to: string;
    }
    class TransformerConfigSubstituteStringEntryPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TransformerConfigSubstituteStringEntryProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TransformerConfigSubstituteStringEntryProperty | cdktn.IResolvable | undefined);
        private _from?;
        get from(): string;
        set from(value: string);
        get fromInput(): string | undefined;
        private _source?;
        get source(): string;
        set source(value: string);
        get sourceInput(): string | undefined;
        private _to?;
        get to(): string;
        set to(value: string);
        get toInput(): string | undefined;
    }
    class TransformerConfigSubstituteStringEntryPropertyList extends cdktn.ComplexList {
        internalValue?: TransformerConfigSubstituteStringEntryProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TransformerConfigSubstituteStringEntryPropertyOutputReference;
    }
    interface SubstituteStringProperty {
        /**
        * entry block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_log_transformer#entry AwsCloudwatchLogTransformer#entry}
        */
        readonly entry?: TransformerConfigSubstituteStringEntryProperty[] | cdktn.IResolvable;
    }
    class SubstituteStringPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SubstituteStringProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SubstituteStringProperty | cdktn.IResolvable | undefined);
        private _entry;
        get entry(): TransformerConfigSubstituteStringEntryPropertyList;
        putEntry(value: TransformerConfigSubstituteStringEntryProperty[] | cdktn.IResolvable): void;
        resetEntry(): void;
        get entryInput(): cdktn.IResolvable | TransformerConfigSubstituteStringEntryProperty[] | undefined;
    }
    class SubstituteStringPropertyList extends cdktn.ComplexList {
        internalValue?: SubstituteStringProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SubstituteStringPropertyOutputReference;
    }
    interface TrimStringProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_log_transformer#with_keys AwsCloudwatchLogTransformer#with_keys}
        */
        readonly withKeys: string[];
    }
    class TrimStringPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TrimStringProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TrimStringProperty | cdktn.IResolvable | undefined);
        private _withKeys?;
        get withKeys(): string[];
        set withKeys(value: string[]);
        get withKeysInput(): string[] | undefined;
    }
    class TrimStringPropertyList extends cdktn.ComplexList {
        internalValue?: TrimStringProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TrimStringPropertyOutputReference;
    }
    interface TransformerConfigTypeConverterEntryProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_log_transformer#key AwsCloudwatchLogTransformer#key}
        */
        readonly key: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_log_transformer#type AwsCloudwatchLogTransformer#type}
        */
        readonly type: string;
    }
    class TransformerConfigTypeConverterEntryPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TransformerConfigTypeConverterEntryProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TransformerConfigTypeConverterEntryProperty | cdktn.IResolvable | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        get keyInput(): string | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
    }
    class TransformerConfigTypeConverterEntryPropertyList extends cdktn.ComplexList {
        internalValue?: TransformerConfigTypeConverterEntryProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TransformerConfigTypeConverterEntryPropertyOutputReference;
    }
    interface TypeConverterProperty {
        /**
        * entry block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_log_transformer#entry AwsCloudwatchLogTransformer#entry}
        */
        readonly entry?: TransformerConfigTypeConverterEntryProperty[] | cdktn.IResolvable;
    }
    class TypeConverterPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TypeConverterProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TypeConverterProperty | cdktn.IResolvable | undefined);
        private _entry;
        get entry(): TransformerConfigTypeConverterEntryPropertyList;
        putEntry(value: TransformerConfigTypeConverterEntryProperty[] | cdktn.IResolvable): void;
        resetEntry(): void;
        get entryInput(): cdktn.IResolvable | TransformerConfigTypeConverterEntryProperty[] | undefined;
    }
    class TypeConverterPropertyList extends cdktn.ComplexList {
        internalValue?: TypeConverterProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TypeConverterPropertyOutputReference;
    }
    interface UpperCaseStringProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_log_transformer#with_keys AwsCloudwatchLogTransformer#with_keys}
        */
        readonly withKeys: string[];
    }
    class UpperCaseStringPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): UpperCaseStringProperty | cdktn.IResolvable | undefined;
        set internalValue(value: UpperCaseStringProperty | cdktn.IResolvable | undefined);
        private _withKeys?;
        get withKeys(): string[];
        set withKeys(value: string[]);
        get withKeysInput(): string[] | undefined;
    }
    class UpperCaseStringPropertyList extends cdktn.ComplexList {
        internalValue?: UpperCaseStringProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): UpperCaseStringPropertyOutputReference;
    }
    interface TransformerConfigProperty {
        /**
        * add_keys block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_log_transformer#add_keys AwsCloudwatchLogTransformer#add_keys}
        */
        readonly addKeys?: AddKeysProperty[] | cdktn.IResolvable;
        /**
        * copy_value block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_log_transformer#copy_value AwsCloudwatchLogTransformer#copy_value}
        */
        readonly copyValue?: CopyValueProperty[] | cdktn.IResolvable;
        /**
        * csv block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_log_transformer#csv AwsCloudwatchLogTransformer#csv}
        */
        readonly csv?: CsvProperty[] | cdktn.IResolvable;
        /**
        * date_time_converter block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_log_transformer#date_time_converter AwsCloudwatchLogTransformer#date_time_converter}
        */
        readonly dateTimeConverter?: DateTimeConverterProperty[] | cdktn.IResolvable;
        /**
        * delete_keys block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_log_transformer#delete_keys AwsCloudwatchLogTransformer#delete_keys}
        */
        readonly deleteKeys?: DeleteKeysProperty[] | cdktn.IResolvable;
        /**
        * grok block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_log_transformer#grok AwsCloudwatchLogTransformer#grok}
        */
        readonly grok?: GrokProperty[] | cdktn.IResolvable;
        /**
        * list_to_map block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_log_transformer#list_to_map AwsCloudwatchLogTransformer#list_to_map}
        */
        readonly listToMap?: ListToMapProperty[] | cdktn.IResolvable;
        /**
        * lower_case_string block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_log_transformer#lower_case_string AwsCloudwatchLogTransformer#lower_case_string}
        */
        readonly lowerCaseString?: LowerCaseStringProperty[] | cdktn.IResolvable;
        /**
        * move_keys block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_log_transformer#move_keys AwsCloudwatchLogTransformer#move_keys}
        */
        readonly moveKeys?: MoveKeysProperty[] | cdktn.IResolvable;
        /**
        * parse_cloudfront block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_log_transformer#parse_cloudfront AwsCloudwatchLogTransformer#parse_cloudfront}
        */
        readonly parseCloudfront?: ParseCloudfrontProperty[] | cdktn.IResolvable;
        /**
        * parse_json block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_log_transformer#parse_json AwsCloudwatchLogTransformer#parse_json}
        */
        readonly parseJson?: ParseJsonProperty[] | cdktn.IResolvable;
        /**
        * parse_key_value block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_log_transformer#parse_key_value AwsCloudwatchLogTransformer#parse_key_value}
        */
        readonly parseKeyValue?: ParseKeyValueProperty[] | cdktn.IResolvable;
        /**
        * parse_postgres block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_log_transformer#parse_postgres AwsCloudwatchLogTransformer#parse_postgres}
        */
        readonly parsePostgres?: ParsePostgresProperty[] | cdktn.IResolvable;
        /**
        * parse_route53 block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_log_transformer#parse_route53 AwsCloudwatchLogTransformer#parse_route53}
        */
        readonly parseRoute53?: ParseRoute53Property[] | cdktn.IResolvable;
        /**
        * parse_to_ocsf block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_log_transformer#parse_to_ocsf AwsCloudwatchLogTransformer#parse_to_ocsf}
        */
        readonly parseToOcsf?: ParseToOcsfProperty[] | cdktn.IResolvable;
        /**
        * parse_vpc block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_log_transformer#parse_vpc AwsCloudwatchLogTransformer#parse_vpc}
        */
        readonly parseVpc?: ParseVpcProperty[] | cdktn.IResolvable;
        /**
        * parse_waf block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_log_transformer#parse_waf AwsCloudwatchLogTransformer#parse_waf}
        */
        readonly parseWaf?: ParseWafProperty[] | cdktn.IResolvable;
        /**
        * rename_keys block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_log_transformer#rename_keys AwsCloudwatchLogTransformer#rename_keys}
        */
        readonly renameKeys?: RenameKeysProperty[] | cdktn.IResolvable;
        /**
        * split_string block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_log_transformer#split_string AwsCloudwatchLogTransformer#split_string}
        */
        readonly splitString?: SplitStringProperty[] | cdktn.IResolvable;
        /**
        * substitute_string block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_log_transformer#substitute_string AwsCloudwatchLogTransformer#substitute_string}
        */
        readonly substituteString?: SubstituteStringProperty[] | cdktn.IResolvable;
        /**
        * trim_string block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_log_transformer#trim_string AwsCloudwatchLogTransformer#trim_string}
        */
        readonly trimString?: TrimStringProperty[] | cdktn.IResolvable;
        /**
        * type_converter block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_log_transformer#type_converter AwsCloudwatchLogTransformer#type_converter}
        */
        readonly typeConverter?: TypeConverterProperty[] | cdktn.IResolvable;
        /**
        * upper_case_string block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_log_transformer#upper_case_string AwsCloudwatchLogTransformer#upper_case_string}
        */
        readonly upperCaseString?: UpperCaseStringProperty[] | cdktn.IResolvable;
    }
    class TransformerConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TransformerConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TransformerConfigProperty | cdktn.IResolvable | undefined);
        private _addKeys;
        get addKeys(): AddKeysPropertyList;
        putAddKeys(value: AddKeysProperty[] | cdktn.IResolvable): void;
        resetAddKeys(): void;
        get addKeysInput(): cdktn.IResolvable | AddKeysProperty[] | undefined;
        private _copyValue;
        get copyValue(): CopyValuePropertyList;
        putCopyValue(value: CopyValueProperty[] | cdktn.IResolvable): void;
        resetCopyValue(): void;
        get copyValueInput(): cdktn.IResolvable | CopyValueProperty[] | undefined;
        private _csv;
        get csv(): CsvPropertyList;
        putCsv(value: CsvProperty[] | cdktn.IResolvable): void;
        resetCsv(): void;
        get csvInput(): cdktn.IResolvable | CsvProperty[] | undefined;
        private _dateTimeConverter;
        get dateTimeConverter(): DateTimeConverterPropertyList;
        putDateTimeConverter(value: DateTimeConverterProperty[] | cdktn.IResolvable): void;
        resetDateTimeConverter(): void;
        get dateTimeConverterInput(): cdktn.IResolvable | DateTimeConverterProperty[] | undefined;
        private _deleteKeys;
        get deleteKeys(): DeleteKeysPropertyList;
        putDeleteKeys(value: DeleteKeysProperty[] | cdktn.IResolvable): void;
        resetDeleteKeys(): void;
        get deleteKeysInput(): cdktn.IResolvable | DeleteKeysProperty[] | undefined;
        private _grok;
        get grok(): GrokPropertyList;
        putGrok(value: GrokProperty[] | cdktn.IResolvable): void;
        resetGrok(): void;
        get grokInput(): cdktn.IResolvable | GrokProperty[] | undefined;
        private _listToMap;
        get listToMap(): ListToMapPropertyList;
        putListToMap(value: ListToMapProperty[] | cdktn.IResolvable): void;
        resetListToMap(): void;
        get listToMapInput(): cdktn.IResolvable | ListToMapProperty[] | undefined;
        private _lowerCaseString;
        get lowerCaseString(): LowerCaseStringPropertyList;
        putLowerCaseString(value: LowerCaseStringProperty[] | cdktn.IResolvable): void;
        resetLowerCaseString(): void;
        get lowerCaseStringInput(): cdktn.IResolvable | LowerCaseStringProperty[] | undefined;
        private _moveKeys;
        get moveKeys(): MoveKeysPropertyList;
        putMoveKeys(value: MoveKeysProperty[] | cdktn.IResolvable): void;
        resetMoveKeys(): void;
        get moveKeysInput(): cdktn.IResolvable | MoveKeysProperty[] | undefined;
        private _parseCloudfront;
        get parseCloudfront(): ParseCloudfrontPropertyList;
        putParseCloudfront(value: ParseCloudfrontProperty[] | cdktn.IResolvable): void;
        resetParseCloudfront(): void;
        get parseCloudfrontInput(): cdktn.IResolvable | ParseCloudfrontProperty[] | undefined;
        private _parseJson;
        get parseJson(): ParseJsonPropertyList;
        putParseJson(value: ParseJsonProperty[] | cdktn.IResolvable): void;
        resetParseJson(): void;
        get parseJsonInput(): cdktn.IResolvable | ParseJsonProperty[] | undefined;
        private _parseKeyValue;
        get parseKeyValue(): ParseKeyValuePropertyList;
        putParseKeyValue(value: ParseKeyValueProperty[] | cdktn.IResolvable): void;
        resetParseKeyValue(): void;
        get parseKeyValueInput(): cdktn.IResolvable | ParseKeyValueProperty[] | undefined;
        private _parsePostgres;
        get parsePostgres(): ParsePostgresPropertyList;
        putParsePostgres(value: ParsePostgresProperty[] | cdktn.IResolvable): void;
        resetParsePostgres(): void;
        get parsePostgresInput(): cdktn.IResolvable | ParsePostgresProperty[] | undefined;
        private _parseRoute53;
        get parseRoute53(): ParseRoute53PropertyList;
        putParseRoute53(value: ParseRoute53Property[] | cdktn.IResolvable): void;
        resetParseRoute53(): void;
        get parseRoute53Input(): cdktn.IResolvable | ParseRoute53Property[] | undefined;
        private _parseToOcsf;
        get parseToOcsf(): ParseToOcsfPropertyList;
        putParseToOcsf(value: ParseToOcsfProperty[] | cdktn.IResolvable): void;
        resetParseToOcsf(): void;
        get parseToOcsfInput(): cdktn.IResolvable | ParseToOcsfProperty[] | undefined;
        private _parseVpc;
        get parseVpc(): ParseVpcPropertyList;
        putParseVpc(value: ParseVpcProperty[] | cdktn.IResolvable): void;
        resetParseVpc(): void;
        get parseVpcInput(): cdktn.IResolvable | ParseVpcProperty[] | undefined;
        private _parseWaf;
        get parseWaf(): ParseWafPropertyList;
        putParseWaf(value: ParseWafProperty[] | cdktn.IResolvable): void;
        resetParseWaf(): void;
        get parseWafInput(): cdktn.IResolvable | ParseWafProperty[] | undefined;
        private _renameKeys;
        get renameKeys(): RenameKeysPropertyList;
        putRenameKeys(value: RenameKeysProperty[] | cdktn.IResolvable): void;
        resetRenameKeys(): void;
        get renameKeysInput(): cdktn.IResolvable | RenameKeysProperty[] | undefined;
        private _splitString;
        get splitString(): SplitStringPropertyList;
        putSplitString(value: SplitStringProperty[] | cdktn.IResolvable): void;
        resetSplitString(): void;
        get splitStringInput(): cdktn.IResolvable | SplitStringProperty[] | undefined;
        private _substituteString;
        get substituteString(): SubstituteStringPropertyList;
        putSubstituteString(value: SubstituteStringProperty[] | cdktn.IResolvable): void;
        resetSubstituteString(): void;
        get substituteStringInput(): cdktn.IResolvable | SubstituteStringProperty[] | undefined;
        private _trimString;
        get trimString(): TrimStringPropertyList;
        putTrimString(value: TrimStringProperty[] | cdktn.IResolvable): void;
        resetTrimString(): void;
        get trimStringInput(): cdktn.IResolvable | TrimStringProperty[] | undefined;
        private _typeConverter;
        get typeConverter(): TypeConverterPropertyList;
        putTypeConverter(value: TypeConverterProperty[] | cdktn.IResolvable): void;
        resetTypeConverter(): void;
        get typeConverterInput(): cdktn.IResolvable | TypeConverterProperty[] | undefined;
        private _upperCaseString;
        get upperCaseString(): UpperCaseStringPropertyList;
        putUpperCaseString(value: UpperCaseStringProperty[] | cdktn.IResolvable): void;
        resetUpperCaseString(): void;
        get upperCaseStringInput(): cdktn.IResolvable | UpperCaseStringProperty[] | undefined;
    }
    class TransformerConfigPropertyList extends cdktn.ComplexList {
        internalValue?: TransformerConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TransformerConfigPropertyOutputReference;
    }
}
