import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsCloudwatchLogStorageTierPolicyConfig extends cdktn.TerraformMetaArguments {
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_log_storage_tier_policy#region AwsCloudwatchLogStorageTierPolicy#region}
    */
    readonly region?: string;
    /**
    * The storage tier to set for the account. Valid values are `STANDARD` or `INTELLIGENT_TIERING`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_log_storage_tier_policy#storage_tier AwsCloudwatchLogStorageTierPolicy#storage_tier}
    */
    readonly storageTier: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_log_storage_tier_policy aws_cloudwatch_log_storage_tier_policy}
*/
export declare class AwsCloudwatchLogStorageTierPolicy extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_cloudwatch_log_storage_tier_policy";
    /**
    * Generates CDKTN code for importing a AwsCloudwatchLogStorageTierPolicy resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsCloudwatchLogStorageTierPolicy to import
    * @param importFromId The id of the existing AwsCloudwatchLogStorageTierPolicy that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_log_storage_tier_policy#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsCloudwatchLogStorageTierPolicy to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_log_storage_tier_policy aws_cloudwatch_log_storage_tier_policy} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsCloudwatchLogStorageTierPolicyConfig
    */
    constructor(scope: Construct, id: string, config: AwsCloudwatchLogStorageTierPolicyConfig);
    get id(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _storageTier?;
    get storageTier(): string;
    set storageTier(value: string);
    get storageTierInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
