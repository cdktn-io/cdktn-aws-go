import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsCloudwatchLogSubscriptionFilterConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_log_subscription_filter#apply_on_transformed_logs AwsCloudwatchLogSubscriptionFilter#apply_on_transformed_logs}
    */
    readonly applyOnTransformedLogs?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_log_subscription_filter#destination_arn AwsCloudwatchLogSubscriptionFilter#destination_arn}
    */
    readonly destinationArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_log_subscription_filter#distribution AwsCloudwatchLogSubscriptionFilter#distribution}
    */
    readonly distribution?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_log_subscription_filter#emit_system_fields AwsCloudwatchLogSubscriptionFilter#emit_system_fields}
    */
    readonly emitSystemFields?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_log_subscription_filter#filter_pattern AwsCloudwatchLogSubscriptionFilter#filter_pattern}
    */
    readonly filterPattern: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_log_subscription_filter#id AwsCloudwatchLogSubscriptionFilter#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_log_subscription_filter#log_group_name AwsCloudwatchLogSubscriptionFilter#log_group_name}
    */
    readonly logGroupName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_log_subscription_filter#name AwsCloudwatchLogSubscriptionFilter#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_log_subscription_filter#region AwsCloudwatchLogSubscriptionFilter#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_log_subscription_filter#role_arn AwsCloudwatchLogSubscriptionFilter#role_arn}
    */
    readonly roleArn?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_log_subscription_filter aws_cloudwatch_log_subscription_filter}
*/
export declare class AwsCloudwatchLogSubscriptionFilter extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_cloudwatch_log_subscription_filter";
    /**
    * Generates CDKTN code for importing a AwsCloudwatchLogSubscriptionFilter resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsCloudwatchLogSubscriptionFilter to import
    * @param importFromId The id of the existing AwsCloudwatchLogSubscriptionFilter that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_log_subscription_filter#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsCloudwatchLogSubscriptionFilter to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_log_subscription_filter aws_cloudwatch_log_subscription_filter} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsCloudwatchLogSubscriptionFilterConfig
    */
    constructor(scope: Construct, id: string, config: AwsCloudwatchLogSubscriptionFilterConfig);
    private _applyOnTransformedLogs?;
    get applyOnTransformedLogs(): boolean | cdktn.IResolvable;
    set applyOnTransformedLogs(value: boolean | cdktn.IResolvable);
    resetApplyOnTransformedLogs(): void;
    get applyOnTransformedLogsInput(): boolean | cdktn.IResolvable | undefined;
    private _destinationArn?;
    get destinationArn(): string;
    set destinationArn(value: string);
    get destinationArnInput(): string | undefined;
    private _distribution?;
    get distribution(): string;
    set distribution(value: string);
    resetDistribution(): void;
    get distributionInput(): string | undefined;
    private _emitSystemFields?;
    get emitSystemFields(): string[];
    set emitSystemFields(value: string[]);
    resetEmitSystemFields(): void;
    get emitSystemFieldsInput(): string[] | undefined;
    private _filterPattern?;
    get filterPattern(): string;
    set filterPattern(value: string);
    get filterPatternInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _logGroupName?;
    get logGroupName(): string;
    set logGroupName(value: string);
    get logGroupNameInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _roleArn?;
    get roleArn(): string;
    set roleArn(value: string);
    resetRoleArn(): void;
    get roleArnInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
