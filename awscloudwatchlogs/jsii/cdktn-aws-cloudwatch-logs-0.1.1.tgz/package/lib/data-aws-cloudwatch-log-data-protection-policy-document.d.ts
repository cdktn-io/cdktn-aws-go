import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsCloudwatchLogDataProtectionPolicyDocumentConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/cloudwatch_log_data_protection_policy_document#description DataAwsCloudwatchLogDataProtectionPolicyDocument#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/cloudwatch_log_data_protection_policy_document#id DataAwsCloudwatchLogDataProtectionPolicyDocument#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/cloudwatch_log_data_protection_policy_document#name DataAwsCloudwatchLogDataProtectionPolicyDocument#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/cloudwatch_log_data_protection_policy_document#version DataAwsCloudwatchLogDataProtectionPolicyDocument#version}
    */
    readonly version?: string;
    /**
    * configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/cloudwatch_log_data_protection_policy_document#configuration DataAwsCloudwatchLogDataProtectionPolicyDocument#configuration}
    */
    readonly configuration?: DataAwsCloudwatchLogDataProtectionPolicyDocument.ConfigurationProperty;
    /**
    * statement block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/cloudwatch_log_data_protection_policy_document#statement DataAwsCloudwatchLogDataProtectionPolicyDocument#statement}
    */
    readonly statement: DataAwsCloudwatchLogDataProtectionPolicyDocument.StatementProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/cloudwatch_log_data_protection_policy_document aws_cloudwatch_log_data_protection_policy_document}
*/
export declare class DataAwsCloudwatchLogDataProtectionPolicyDocument extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_cloudwatch_log_data_protection_policy_document";
    /**
    * Generates CDKTN code for importing a DataAwsCloudwatchLogDataProtectionPolicyDocument resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsCloudwatchLogDataProtectionPolicyDocument to import
    * @param importFromId The id of the existing DataAwsCloudwatchLogDataProtectionPolicyDocument that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/cloudwatch_log_data_protection_policy_document#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsCloudwatchLogDataProtectionPolicyDocument to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/cloudwatch_log_data_protection_policy_document aws_cloudwatch_log_data_protection_policy_document} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsCloudwatchLogDataProtectionPolicyDocumentConfig
    */
    constructor(scope: Construct, id: string, config: DataAwsCloudwatchLogDataProtectionPolicyDocumentConfig);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get json(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _version?;
    get version(): string;
    set version(value: string);
    resetVersion(): void;
    get versionInput(): string | undefined;
    private _configuration;
    get configuration(): DataAwsCloudwatchLogDataProtectionPolicyDocument.ConfigurationPropertyOutputReference;
    putConfiguration(value: DataAwsCloudwatchLogDataProtectionPolicyDocument.ConfigurationProperty): void;
    resetConfiguration(): void;
    get configurationInput(): DataAwsCloudwatchLogDataProtectionPolicyDocument.ConfigurationProperty | undefined;
    private _statement;
    get statement(): DataAwsCloudwatchLogDataProtectionPolicyDocument.StatementPropertyList;
    putStatement(value: DataAwsCloudwatchLogDataProtectionPolicyDocument.StatementProperty[] | cdktn.IResolvable): void;
    get statementInput(): cdktn.IResolvable | DataAwsCloudwatchLogDataProtectionPolicyDocument.StatementProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataAwsCloudwatchLogDataProtectionPolicyDocumentCustomDataIdentifierPropertyToTerraform(struct?: DataAwsCloudwatchLogDataProtectionPolicyDocument.CustomDataIdentifierProperty | cdktn.IResolvable): any;
export declare function dataAwsCloudwatchLogDataProtectionPolicyDocumentCustomDataIdentifierPropertyToHclTerraform(struct?: DataAwsCloudwatchLogDataProtectionPolicyDocument.CustomDataIdentifierProperty | cdktn.IResolvable): any;
export declare function dataAwsCloudwatchLogDataProtectionPolicyDocumentConfigurationPropertyToTerraform(struct?: DataAwsCloudwatchLogDataProtectionPolicyDocument.ConfigurationPropertyOutputReference | DataAwsCloudwatchLogDataProtectionPolicyDocument.ConfigurationProperty): any;
export declare function dataAwsCloudwatchLogDataProtectionPolicyDocumentConfigurationPropertyToHclTerraform(struct?: DataAwsCloudwatchLogDataProtectionPolicyDocument.ConfigurationPropertyOutputReference | DataAwsCloudwatchLogDataProtectionPolicyDocument.ConfigurationProperty): any;
export declare function dataAwsCloudwatchLogDataProtectionPolicyDocumentCloudwatchLogsPropertyToTerraform(struct?: DataAwsCloudwatchLogDataProtectionPolicyDocument.CloudwatchLogsPropertyOutputReference | DataAwsCloudwatchLogDataProtectionPolicyDocument.CloudwatchLogsProperty): any;
export declare function dataAwsCloudwatchLogDataProtectionPolicyDocumentCloudwatchLogsPropertyToHclTerraform(struct?: DataAwsCloudwatchLogDataProtectionPolicyDocument.CloudwatchLogsPropertyOutputReference | DataAwsCloudwatchLogDataProtectionPolicyDocument.CloudwatchLogsProperty): any;
export declare function dataAwsCloudwatchLogDataProtectionPolicyDocumentFirehosePropertyToTerraform(struct?: DataAwsCloudwatchLogDataProtectionPolicyDocument.FirehosePropertyOutputReference | DataAwsCloudwatchLogDataProtectionPolicyDocument.FirehoseProperty): any;
export declare function dataAwsCloudwatchLogDataProtectionPolicyDocumentFirehosePropertyToHclTerraform(struct?: DataAwsCloudwatchLogDataProtectionPolicyDocument.FirehosePropertyOutputReference | DataAwsCloudwatchLogDataProtectionPolicyDocument.FirehoseProperty): any;
export declare function dataAwsCloudwatchLogDataProtectionPolicyDocumentS3PropertyToTerraform(struct?: DataAwsCloudwatchLogDataProtectionPolicyDocument.S3PropertyOutputReference | DataAwsCloudwatchLogDataProtectionPolicyDocument.S3Property): any;
export declare function dataAwsCloudwatchLogDataProtectionPolicyDocumentS3PropertyToHclTerraform(struct?: DataAwsCloudwatchLogDataProtectionPolicyDocument.S3PropertyOutputReference | DataAwsCloudwatchLogDataProtectionPolicyDocument.S3Property): any;
export declare function dataAwsCloudwatchLogDataProtectionPolicyDocumentFindingsDestinationPropertyToTerraform(struct?: DataAwsCloudwatchLogDataProtectionPolicyDocument.FindingsDestinationPropertyOutputReference | DataAwsCloudwatchLogDataProtectionPolicyDocument.FindingsDestinationProperty): any;
export declare function dataAwsCloudwatchLogDataProtectionPolicyDocumentFindingsDestinationPropertyToHclTerraform(struct?: DataAwsCloudwatchLogDataProtectionPolicyDocument.FindingsDestinationPropertyOutputReference | DataAwsCloudwatchLogDataProtectionPolicyDocument.FindingsDestinationProperty): any;
export declare function dataAwsCloudwatchLogDataProtectionPolicyDocumentAuditPropertyToTerraform(struct?: DataAwsCloudwatchLogDataProtectionPolicyDocument.AuditPropertyOutputReference | DataAwsCloudwatchLogDataProtectionPolicyDocument.AuditProperty): any;
export declare function dataAwsCloudwatchLogDataProtectionPolicyDocumentAuditPropertyToHclTerraform(struct?: DataAwsCloudwatchLogDataProtectionPolicyDocument.AuditPropertyOutputReference | DataAwsCloudwatchLogDataProtectionPolicyDocument.AuditProperty): any;
export declare function dataAwsCloudwatchLogDataProtectionPolicyDocumentMaskConfigPropertyToTerraform(struct?: DataAwsCloudwatchLogDataProtectionPolicyDocument.MaskConfigPropertyOutputReference | DataAwsCloudwatchLogDataProtectionPolicyDocument.MaskConfigProperty): any;
export declare function dataAwsCloudwatchLogDataProtectionPolicyDocumentMaskConfigPropertyToHclTerraform(struct?: DataAwsCloudwatchLogDataProtectionPolicyDocument.MaskConfigPropertyOutputReference | DataAwsCloudwatchLogDataProtectionPolicyDocument.MaskConfigProperty): any;
export declare function dataAwsCloudwatchLogDataProtectionPolicyDocumentDeidentifyPropertyToTerraform(struct?: DataAwsCloudwatchLogDataProtectionPolicyDocument.DeidentifyPropertyOutputReference | DataAwsCloudwatchLogDataProtectionPolicyDocument.DeidentifyProperty): any;
export declare function dataAwsCloudwatchLogDataProtectionPolicyDocumentDeidentifyPropertyToHclTerraform(struct?: DataAwsCloudwatchLogDataProtectionPolicyDocument.DeidentifyPropertyOutputReference | DataAwsCloudwatchLogDataProtectionPolicyDocument.DeidentifyProperty): any;
export declare function dataAwsCloudwatchLogDataProtectionPolicyDocumentOperationPropertyToTerraform(struct?: DataAwsCloudwatchLogDataProtectionPolicyDocument.OperationPropertyOutputReference | DataAwsCloudwatchLogDataProtectionPolicyDocument.OperationProperty): any;
export declare function dataAwsCloudwatchLogDataProtectionPolicyDocumentOperationPropertyToHclTerraform(struct?: DataAwsCloudwatchLogDataProtectionPolicyDocument.OperationPropertyOutputReference | DataAwsCloudwatchLogDataProtectionPolicyDocument.OperationProperty): any;
export declare function dataAwsCloudwatchLogDataProtectionPolicyDocumentStatementPropertyToTerraform(struct?: DataAwsCloudwatchLogDataProtectionPolicyDocument.StatementProperty | cdktn.IResolvable): any;
export declare function dataAwsCloudwatchLogDataProtectionPolicyDocumentStatementPropertyToHclTerraform(struct?: DataAwsCloudwatchLogDataProtectionPolicyDocument.StatementProperty | cdktn.IResolvable): any;
export declare namespace DataAwsCloudwatchLogDataProtectionPolicyDocument {
    interface CustomDataIdentifierProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/cloudwatch_log_data_protection_policy_document#name DataAwsCloudwatchLogDataProtectionPolicyDocument#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/cloudwatch_log_data_protection_policy_document#regex DataAwsCloudwatchLogDataProtectionPolicyDocument#regex}
        */
        readonly regex: string;
    }
    class CustomDataIdentifierPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CustomDataIdentifierProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CustomDataIdentifierProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _regex?;
        get regex(): string;
        set regex(value: string);
        get regexInput(): string | undefined;
    }
    class CustomDataIdentifierPropertyList extends cdktn.ComplexList {
        internalValue?: CustomDataIdentifierProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CustomDataIdentifierPropertyOutputReference;
    }
    interface ConfigurationProperty {
        /**
        * custom_data_identifier block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/cloudwatch_log_data_protection_policy_document#custom_data_identifier DataAwsCloudwatchLogDataProtectionPolicyDocument#custom_data_identifier}
        */
        readonly customDataIdentifier?: CustomDataIdentifierProperty[] | cdktn.IResolvable;
    }
    class ConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ConfigurationProperty | undefined;
        set internalValue(value: ConfigurationProperty | undefined);
        private _customDataIdentifier;
        get customDataIdentifier(): CustomDataIdentifierPropertyList;
        putCustomDataIdentifier(value: CustomDataIdentifierProperty[] | cdktn.IResolvable): void;
        resetCustomDataIdentifier(): void;
        get customDataIdentifierInput(): cdktn.IResolvable | CustomDataIdentifierProperty[] | undefined;
    }
    interface CloudwatchLogsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/cloudwatch_log_data_protection_policy_document#log_group DataAwsCloudwatchLogDataProtectionPolicyDocument#log_group}
        */
        readonly logGroup: string;
    }
    class CloudwatchLogsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CloudwatchLogsProperty | undefined;
        set internalValue(value: CloudwatchLogsProperty | undefined);
        private _logGroup?;
        get logGroup(): string;
        set logGroup(value: string);
        get logGroupInput(): string | undefined;
    }
    interface FirehoseProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/cloudwatch_log_data_protection_policy_document#delivery_stream DataAwsCloudwatchLogDataProtectionPolicyDocument#delivery_stream}
        */
        readonly deliveryStream: string;
    }
    class FirehosePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): FirehoseProperty | undefined;
        set internalValue(value: FirehoseProperty | undefined);
        private _deliveryStream?;
        get deliveryStream(): string;
        set deliveryStream(value: string);
        get deliveryStreamInput(): string | undefined;
    }
    interface S3Property {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/cloudwatch_log_data_protection_policy_document#bucket DataAwsCloudwatchLogDataProtectionPolicyDocument#bucket}
        */
        readonly bucket: string;
    }
    class S3PropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): S3Property | undefined;
        set internalValue(value: S3Property | undefined);
        private _bucket?;
        get bucket(): string;
        set bucket(value: string);
        get bucketInput(): string | undefined;
    }
    interface FindingsDestinationProperty {
        /**
        * cloudwatch_logs block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/cloudwatch_log_data_protection_policy_document#cloudwatch_logs DataAwsCloudwatchLogDataProtectionPolicyDocument#cloudwatch_logs}
        */
        readonly cloudwatchLogs?: CloudwatchLogsProperty;
        /**
        * firehose block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/cloudwatch_log_data_protection_policy_document#firehose DataAwsCloudwatchLogDataProtectionPolicyDocument#firehose}
        */
        readonly firehose?: FirehoseProperty;
        /**
        * s3 block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/cloudwatch_log_data_protection_policy_document#s3 DataAwsCloudwatchLogDataProtectionPolicyDocument#s3}
        */
        readonly s3?: S3Property;
    }
    class FindingsDestinationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): FindingsDestinationProperty | undefined;
        set internalValue(value: FindingsDestinationProperty | undefined);
        private _cloudwatchLogs;
        get cloudwatchLogs(): CloudwatchLogsPropertyOutputReference;
        putCloudwatchLogs(value: CloudwatchLogsProperty): void;
        resetCloudwatchLogs(): void;
        get cloudwatchLogsInput(): CloudwatchLogsProperty | undefined;
        private _firehose;
        get firehose(): FirehosePropertyOutputReference;
        putFirehose(value: FirehoseProperty): void;
        resetFirehose(): void;
        get firehoseInput(): FirehoseProperty | undefined;
        private _s3;
        get s3(): S3PropertyOutputReference;
        putS3(value: S3Property): void;
        resetS3(): void;
        get s3Input(): S3Property | undefined;
    }
    interface AuditProperty {
        /**
        * findings_destination block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/cloudwatch_log_data_protection_policy_document#findings_destination DataAwsCloudwatchLogDataProtectionPolicyDocument#findings_destination}
        */
        readonly findingsDestination: FindingsDestinationProperty;
    }
    class AuditPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AuditProperty | undefined;
        set internalValue(value: AuditProperty | undefined);
        private _findingsDestination;
        get findingsDestination(): FindingsDestinationPropertyOutputReference;
        putFindingsDestination(value: FindingsDestinationProperty): void;
        get findingsDestinationInput(): FindingsDestinationProperty | undefined;
    }
    interface MaskConfigProperty {
    }
    class MaskConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): MaskConfigProperty | undefined;
        set internalValue(value: MaskConfigProperty | undefined);
    }
    interface DeidentifyProperty {
        /**
        * mask_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/cloudwatch_log_data_protection_policy_document#mask_config DataAwsCloudwatchLogDataProtectionPolicyDocument#mask_config}
        */
        readonly maskConfig: MaskConfigProperty;
    }
    class DeidentifyPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DeidentifyProperty | undefined;
        set internalValue(value: DeidentifyProperty | undefined);
        private _maskConfig;
        get maskConfig(): MaskConfigPropertyOutputReference;
        putMaskConfig(value: MaskConfigProperty): void;
        get maskConfigInput(): MaskConfigProperty | undefined;
    }
    interface OperationProperty {
        /**
        * audit block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/cloudwatch_log_data_protection_policy_document#audit DataAwsCloudwatchLogDataProtectionPolicyDocument#audit}
        */
        readonly audit?: AuditProperty;
        /**
        * deidentify block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/cloudwatch_log_data_protection_policy_document#deidentify DataAwsCloudwatchLogDataProtectionPolicyDocument#deidentify}
        */
        readonly deidentify?: DeidentifyProperty;
    }
    class OperationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): OperationProperty | undefined;
        set internalValue(value: OperationProperty | undefined);
        private _audit;
        get audit(): AuditPropertyOutputReference;
        putAudit(value: AuditProperty): void;
        resetAudit(): void;
        get auditInput(): AuditProperty | undefined;
        private _deidentify;
        get deidentify(): DeidentifyPropertyOutputReference;
        putDeidentify(value: DeidentifyProperty): void;
        resetDeidentify(): void;
        get deidentifyInput(): DeidentifyProperty | undefined;
    }
    interface StatementProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/cloudwatch_log_data_protection_policy_document#data_identifiers DataAwsCloudwatchLogDataProtectionPolicyDocument#data_identifiers}
        */
        readonly dataIdentifiers: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/cloudwatch_log_data_protection_policy_document#sid DataAwsCloudwatchLogDataProtectionPolicyDocument#sid}
        */
        readonly sid?: string;
        /**
        * operation block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/cloudwatch_log_data_protection_policy_document#operation DataAwsCloudwatchLogDataProtectionPolicyDocument#operation}
        */
        readonly operation: OperationProperty;
    }
    class StatementPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): StatementProperty | cdktn.IResolvable | undefined;
        set internalValue(value: StatementProperty | cdktn.IResolvable | undefined);
        private _dataIdentifiers?;
        get dataIdentifiers(): string[];
        set dataIdentifiers(value: string[]);
        get dataIdentifiersInput(): string[] | undefined;
        private _sid?;
        get sid(): string;
        set sid(value: string);
        resetSid(): void;
        get sidInput(): string | undefined;
        private _operation;
        get operation(): OperationPropertyOutputReference;
        putOperation(value: OperationProperty): void;
        get operationInput(): OperationProperty | undefined;
    }
    class StatementPropertyList extends cdktn.ComplexList {
        internalValue?: StatementProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): StatementPropertyOutputReference;
    }
}
