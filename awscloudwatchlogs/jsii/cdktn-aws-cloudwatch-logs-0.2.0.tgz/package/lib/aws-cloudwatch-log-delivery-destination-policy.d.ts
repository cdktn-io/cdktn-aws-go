import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfDeliveryDestinationPolicyConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_log_delivery_destination_policy#delivery_destination_name TfDeliveryDestinationPolicy#delivery_destination_name}
    */
    readonly deliveryDestinationName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_log_delivery_destination_policy#delivery_destination_policy TfDeliveryDestinationPolicy#delivery_destination_policy}
    */
    readonly deliveryDestinationPolicy: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_log_delivery_destination_policy#region TfDeliveryDestinationPolicy#region}
    */
    readonly region?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_log_delivery_destination_policy aws_cloudwatch_log_delivery_destination_policy}
*/
export declare class TfDeliveryDestinationPolicy extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_cloudwatch_log_delivery_destination_policy";
    /**
    * Generates CDKTN code for importing a TfDeliveryDestinationPolicy resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfDeliveryDestinationPolicy to import
    * @param importFromId The id of the existing TfDeliveryDestinationPolicy that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_log_delivery_destination_policy#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfDeliveryDestinationPolicy to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_log_delivery_destination_policy aws_cloudwatch_log_delivery_destination_policy} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfDeliveryDestinationPolicyConfig
    */
    constructor(scope: Construct, id: string, config: TfDeliveryDestinationPolicyConfig);
    private _deliveryDestinationName?;
    get deliveryDestinationName(): string;
    set deliveryDestinationName(value: string);
    get deliveryDestinationNameInput(): string | undefined;
    private _deliveryDestinationPolicy?;
    get deliveryDestinationPolicy(): string;
    set deliveryDestinationPolicy(value: string);
    get deliveryDestinationPolicyInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
