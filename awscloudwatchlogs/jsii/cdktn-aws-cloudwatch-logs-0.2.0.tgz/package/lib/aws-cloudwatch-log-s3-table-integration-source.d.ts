import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfS3TableIntegrationSourceConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_log_s3_table_integration_source#integration_arn TfS3TableIntegrationSource#integration_arn}
    */
    readonly integrationArn: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_log_s3_table_integration_source#region TfS3TableIntegrationSource#region}
    */
    readonly region?: string;
    /**
    * data_source block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_log_s3_table_integration_source#data_source TfS3TableIntegrationSource#data_source}
    */
    readonly dataSource?: TfS3TableIntegrationSource.DataSourceProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_log_s3_table_integration_source#timeouts TfS3TableIntegrationSource#timeouts}
    */
    readonly timeouts?: TfS3TableIntegrationSource.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_log_s3_table_integration_source aws_cloudwatch_log_s3_table_integration_source}
*/
export declare class TfS3TableIntegrationSource extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_cloudwatch_log_s3_table_integration_source";
    /**
    * Generates CDKTN code for importing a TfS3TableIntegrationSource resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfS3TableIntegrationSource to import
    * @param importFromId The id of the existing TfS3TableIntegrationSource that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_log_s3_table_integration_source#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfS3TableIntegrationSource to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_log_s3_table_integration_source aws_cloudwatch_log_s3_table_integration_source} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfS3TableIntegrationSourceConfig
    */
    constructor(scope: Construct, id: string, config: TfS3TableIntegrationSourceConfig);
    get id(): string;
    private _integrationArn?;
    get integrationArn(): string;
    set integrationArn(value: string);
    get integrationArnInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _dataSource;
    get dataSource(): TfS3TableIntegrationSource.DataSourcePropertyList;
    putDataSource(value: TfS3TableIntegrationSource.DataSourceProperty[] | cdktn.IResolvable): void;
    resetDataSource(): void;
    get dataSourceInput(): cdktn.IResolvable | TfS3TableIntegrationSource.DataSourceProperty[] | undefined;
    private _timeouts;
    get timeouts(): TfS3TableIntegrationSource.TimeoutsPropertyOutputReference;
    putTimeouts(value: TfS3TableIntegrationSource.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | TfS3TableIntegrationSource.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfS3TableIntegrationSourceDataSourcePropertyToTerraform(struct?: TfS3TableIntegrationSource.DataSourceProperty | cdktn.IResolvable): any;
export declare function tfS3TableIntegrationSourceDataSourcePropertyToHclTerraform(struct?: TfS3TableIntegrationSource.DataSourceProperty | cdktn.IResolvable): any;
export declare function tfS3TableIntegrationSourceTimeoutsPropertyToTerraform(struct?: TfS3TableIntegrationSource.TimeoutsProperty | cdktn.IResolvable): any;
export declare function tfS3TableIntegrationSourceTimeoutsPropertyToHclTerraform(struct?: TfS3TableIntegrationSource.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace TfS3TableIntegrationSource {
    interface DataSourceProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_log_s3_table_integration_source#name TfS3TableIntegrationSource#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_log_s3_table_integration_source#type TfS3TableIntegrationSource#type}
        */
        readonly type: string;
    }
    class DataSourcePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DataSourceProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DataSourceProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
    }
    class DataSourcePropertyList extends cdktn.ComplexList {
        internalValue?: DataSourceProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DataSourcePropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Setting a timeout for a Delete operation is only applicable if changes are saved into state before the destroy operation occurs.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_log_s3_table_integration_source#delete TfS3TableIntegrationSource#delete}
        */
        readonly delete?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
    }
}
