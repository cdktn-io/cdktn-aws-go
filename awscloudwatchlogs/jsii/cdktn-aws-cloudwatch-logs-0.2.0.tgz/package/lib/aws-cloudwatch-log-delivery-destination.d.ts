import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfDeliveryDestinationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_log_delivery_destination#delivery_destination_type TfDeliveryDestination#delivery_destination_type}
    */
    readonly deliveryDestinationType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_log_delivery_destination#name TfDeliveryDestination#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_log_delivery_destination#output_format TfDeliveryDestination#output_format}
    */
    readonly outputFormat?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_log_delivery_destination#region TfDeliveryDestination#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_log_delivery_destination#tags TfDeliveryDestination#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * delivery_destination_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_log_delivery_destination#delivery_destination_configuration TfDeliveryDestination#delivery_destination_configuration}
    */
    readonly deliveryDestinationConfiguration?: TfDeliveryDestination.DeliveryDestinationConfigurationProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_log_delivery_destination aws_cloudwatch_log_delivery_destination}
*/
export declare class TfDeliveryDestination extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_cloudwatch_log_delivery_destination";
    /**
    * Generates CDKTN code for importing a TfDeliveryDestination resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfDeliveryDestination to import
    * @param importFromId The id of the existing TfDeliveryDestination that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_log_delivery_destination#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfDeliveryDestination to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_log_delivery_destination aws_cloudwatch_log_delivery_destination} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfDeliveryDestinationConfig
    */
    constructor(scope: Construct, id: string, config: TfDeliveryDestinationConfig);
    get arn(): string;
    private _deliveryDestinationType?;
    get deliveryDestinationType(): string;
    set deliveryDestinationType(value: string);
    resetDeliveryDestinationType(): void;
    get deliveryDestinationTypeInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _outputFormat?;
    get outputFormat(): string;
    set outputFormat(value: string);
    resetOutputFormat(): void;
    get outputFormatInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    private _deliveryDestinationConfiguration;
    get deliveryDestinationConfiguration(): TfDeliveryDestination.DeliveryDestinationConfigurationPropertyList;
    putDeliveryDestinationConfiguration(value: TfDeliveryDestination.DeliveryDestinationConfigurationProperty[] | cdktn.IResolvable): void;
    resetDeliveryDestinationConfiguration(): void;
    get deliveryDestinationConfigurationInput(): cdktn.IResolvable | TfDeliveryDestination.DeliveryDestinationConfigurationProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfDeliveryDestinationDeliveryDestinationConfigurationPropertyToTerraform(struct?: TfDeliveryDestination.DeliveryDestinationConfigurationProperty | cdktn.IResolvable): any;
export declare function tfDeliveryDestinationDeliveryDestinationConfigurationPropertyToHclTerraform(struct?: TfDeliveryDestination.DeliveryDestinationConfigurationProperty | cdktn.IResolvable): any;
export declare namespace TfDeliveryDestination {
    interface DeliveryDestinationConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_log_delivery_destination#destination_resource_arn TfDeliveryDestination#destination_resource_arn}
        */
        readonly destinationResourceArn?: string;
    }
    class DeliveryDestinationConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DeliveryDestinationConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DeliveryDestinationConfigurationProperty | cdktn.IResolvable | undefined);
        private _destinationResourceArn?;
        get destinationResourceArn(): string;
        set destinationResourceArn(value: string);
        resetDestinationResourceArn(): void;
        get destinationResourceArnInput(): string | undefined;
    }
    class DeliveryDestinationConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: DeliveryDestinationConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DeliveryDestinationConfigurationPropertyOutputReference;
    }
}
