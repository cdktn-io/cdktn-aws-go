import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsCeTagsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#id DataAwsCeTags#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#search_string DataAwsCeTags#search_string}
    */
    readonly searchString?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#tag_key DataAwsCeTags#tag_key}
    */
    readonly tagKey?: string;
    /**
    * filter block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#filter DataAwsCeTags#filter}
    */
    readonly filter?: DataAwsCeTags.FilterProperty;
    /**
    * sort_by block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#sort_by DataAwsCeTags#sort_by}
    */
    readonly sortBy?: DataAwsCeTags.SortByProperty[] | cdktn.IResolvable;
    /**
    * time_period block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#time_period DataAwsCeTags#time_period}
    */
    readonly timePeriod: DataAwsCeTags.TimePeriodProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags aws_ce_tags}
*/
export declare class DataAwsCeTags extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_ce_tags";
    /**
    * Generates CDKTN code for importing a DataAwsCeTags resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsCeTags to import
    * @param importFromId The id of the existing DataAwsCeTags that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsCeTags to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags aws_ce_tags} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsCeTagsConfig
    */
    constructor(scope: Construct, id: string, config: DataAwsCeTagsConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _searchString?;
    get searchString(): string;
    set searchString(value: string);
    resetSearchString(): void;
    get searchStringInput(): string | undefined;
    private _tagKey?;
    get tagKey(): string;
    set tagKey(value: string);
    resetTagKey(): void;
    get tagKeyInput(): string | undefined;
    get tags(): string[];
    private _filter;
    get filter(): DataAwsCeTags.FilterPropertyOutputReference;
    putFilter(value: DataAwsCeTags.FilterProperty): void;
    resetFilter(): void;
    get filterInput(): DataAwsCeTags.FilterProperty | undefined;
    private _sortBy;
    get sortBy(): DataAwsCeTags.SortByPropertyList;
    putSortBy(value: DataAwsCeTags.SortByProperty[] | cdktn.IResolvable): void;
    resetSortBy(): void;
    get sortByInput(): cdktn.IResolvable | DataAwsCeTags.SortByProperty[] | undefined;
    private _timePeriod;
    get timePeriod(): DataAwsCeTags.TimePeriodPropertyOutputReference;
    putTimePeriod(value: DataAwsCeTags.TimePeriodProperty): void;
    get timePeriodInput(): DataAwsCeTags.TimePeriodProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataAwsCeTagsFilterAndCostCategoryPropertyToTerraform(struct?: DataAwsCeTags.FilterAndCostCategoryPropertyOutputReference | DataAwsCeTags.FilterAndCostCategoryProperty): any;
export declare function dataAwsCeTagsFilterAndCostCategoryPropertyToHclTerraform(struct?: DataAwsCeTags.FilterAndCostCategoryPropertyOutputReference | DataAwsCeTags.FilterAndCostCategoryProperty): any;
export declare function dataAwsCeTagsFilterAndDimensionPropertyToTerraform(struct?: DataAwsCeTags.FilterAndDimensionPropertyOutputReference | DataAwsCeTags.FilterAndDimensionProperty): any;
export declare function dataAwsCeTagsFilterAndDimensionPropertyToHclTerraform(struct?: DataAwsCeTags.FilterAndDimensionPropertyOutputReference | DataAwsCeTags.FilterAndDimensionProperty): any;
export declare function dataAwsCeTagsFilterAndTagsPropertyToTerraform(struct?: DataAwsCeTags.FilterAndTagsPropertyOutputReference | DataAwsCeTags.FilterAndTagsProperty): any;
export declare function dataAwsCeTagsFilterAndTagsPropertyToHclTerraform(struct?: DataAwsCeTags.FilterAndTagsPropertyOutputReference | DataAwsCeTags.FilterAndTagsProperty): any;
export declare function dataAwsCeTagsAndPropertyToTerraform(struct?: DataAwsCeTags.AndProperty | cdktn.IResolvable): any;
export declare function dataAwsCeTagsAndPropertyToHclTerraform(struct?: DataAwsCeTags.AndProperty | cdktn.IResolvable): any;
export declare function dataAwsCeTagsFilterCostCategoryPropertyToTerraform(struct?: DataAwsCeTags.FilterCostCategoryPropertyOutputReference | DataAwsCeTags.FilterCostCategoryProperty): any;
export declare function dataAwsCeTagsFilterCostCategoryPropertyToHclTerraform(struct?: DataAwsCeTags.FilterCostCategoryPropertyOutputReference | DataAwsCeTags.FilterCostCategoryProperty): any;
export declare function dataAwsCeTagsFilterDimensionPropertyToTerraform(struct?: DataAwsCeTags.FilterDimensionPropertyOutputReference | DataAwsCeTags.FilterDimensionProperty): any;
export declare function dataAwsCeTagsFilterDimensionPropertyToHclTerraform(struct?: DataAwsCeTags.FilterDimensionPropertyOutputReference | DataAwsCeTags.FilterDimensionProperty): any;
export declare function dataAwsCeTagsFilterNotCostCategoryPropertyToTerraform(struct?: DataAwsCeTags.FilterNotCostCategoryPropertyOutputReference | DataAwsCeTags.FilterNotCostCategoryProperty): any;
export declare function dataAwsCeTagsFilterNotCostCategoryPropertyToHclTerraform(struct?: DataAwsCeTags.FilterNotCostCategoryPropertyOutputReference | DataAwsCeTags.FilterNotCostCategoryProperty): any;
export declare function dataAwsCeTagsFilterNotDimensionPropertyToTerraform(struct?: DataAwsCeTags.FilterNotDimensionPropertyOutputReference | DataAwsCeTags.FilterNotDimensionProperty): any;
export declare function dataAwsCeTagsFilterNotDimensionPropertyToHclTerraform(struct?: DataAwsCeTags.FilterNotDimensionPropertyOutputReference | DataAwsCeTags.FilterNotDimensionProperty): any;
export declare function dataAwsCeTagsFilterNotTagsPropertyToTerraform(struct?: DataAwsCeTags.FilterNotTagsPropertyOutputReference | DataAwsCeTags.FilterNotTagsProperty): any;
export declare function dataAwsCeTagsFilterNotTagsPropertyToHclTerraform(struct?: DataAwsCeTags.FilterNotTagsPropertyOutputReference | DataAwsCeTags.FilterNotTagsProperty): any;
export declare function dataAwsCeTagsNotPropertyToTerraform(struct?: DataAwsCeTags.NotPropertyOutputReference | DataAwsCeTags.NotProperty): any;
export declare function dataAwsCeTagsNotPropertyToHclTerraform(struct?: DataAwsCeTags.NotPropertyOutputReference | DataAwsCeTags.NotProperty): any;
export declare function dataAwsCeTagsFilterOrCostCategoryPropertyToTerraform(struct?: DataAwsCeTags.FilterOrCostCategoryPropertyOutputReference | DataAwsCeTags.FilterOrCostCategoryProperty): any;
export declare function dataAwsCeTagsFilterOrCostCategoryPropertyToHclTerraform(struct?: DataAwsCeTags.FilterOrCostCategoryPropertyOutputReference | DataAwsCeTags.FilterOrCostCategoryProperty): any;
export declare function dataAwsCeTagsFilterOrDimensionPropertyToTerraform(struct?: DataAwsCeTags.FilterOrDimensionPropertyOutputReference | DataAwsCeTags.FilterOrDimensionProperty): any;
export declare function dataAwsCeTagsFilterOrDimensionPropertyToHclTerraform(struct?: DataAwsCeTags.FilterOrDimensionPropertyOutputReference | DataAwsCeTags.FilterOrDimensionProperty): any;
export declare function dataAwsCeTagsFilterOrTagsPropertyToTerraform(struct?: DataAwsCeTags.FilterOrTagsPropertyOutputReference | DataAwsCeTags.FilterOrTagsProperty): any;
export declare function dataAwsCeTagsFilterOrTagsPropertyToHclTerraform(struct?: DataAwsCeTags.FilterOrTagsPropertyOutputReference | DataAwsCeTags.FilterOrTagsProperty): any;
export declare function dataAwsCeTagsOrPropertyToTerraform(struct?: DataAwsCeTags.OrProperty | cdktn.IResolvable): any;
export declare function dataAwsCeTagsOrPropertyToHclTerraform(struct?: DataAwsCeTags.OrProperty | cdktn.IResolvable): any;
export declare function dataAwsCeTagsFilterTagsPropertyToTerraform(struct?: DataAwsCeTags.FilterTagsPropertyOutputReference | DataAwsCeTags.FilterTagsProperty): any;
export declare function dataAwsCeTagsFilterTagsPropertyToHclTerraform(struct?: DataAwsCeTags.FilterTagsPropertyOutputReference | DataAwsCeTags.FilterTagsProperty): any;
export declare function dataAwsCeTagsFilterPropertyToTerraform(struct?: DataAwsCeTags.FilterPropertyOutputReference | DataAwsCeTags.FilterProperty): any;
export declare function dataAwsCeTagsFilterPropertyToHclTerraform(struct?: DataAwsCeTags.FilterPropertyOutputReference | DataAwsCeTags.FilterProperty): any;
export declare function dataAwsCeTagsSortByPropertyToTerraform(struct?: DataAwsCeTags.SortByProperty | cdktn.IResolvable): any;
export declare function dataAwsCeTagsSortByPropertyToHclTerraform(struct?: DataAwsCeTags.SortByProperty | cdktn.IResolvable): any;
export declare function dataAwsCeTagsTimePeriodPropertyToTerraform(struct?: DataAwsCeTags.TimePeriodPropertyOutputReference | DataAwsCeTags.TimePeriodProperty): any;
export declare function dataAwsCeTagsTimePeriodPropertyToHclTerraform(struct?: DataAwsCeTags.TimePeriodPropertyOutputReference | DataAwsCeTags.TimePeriodProperty): any;
export declare namespace DataAwsCeTags {
    interface FilterAndCostCategoryProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#key DataAwsCeTags#key}
        */
        readonly key?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#match_options DataAwsCeTags#match_options}
        */
        readonly matchOptions?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#values DataAwsCeTags#values}
        */
        readonly values?: string[];
    }
    class FilterAndCostCategoryPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): FilterAndCostCategoryProperty | undefined;
        set internalValue(value: FilterAndCostCategoryProperty | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        resetKey(): void;
        get keyInput(): string | undefined;
        private _matchOptions?;
        get matchOptions(): string[];
        set matchOptions(value: string[]);
        resetMatchOptions(): void;
        get matchOptionsInput(): string[] | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        resetValues(): void;
        get valuesInput(): string[] | undefined;
    }
    interface FilterAndDimensionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#key DataAwsCeTags#key}
        */
        readonly key?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#match_options DataAwsCeTags#match_options}
        */
        readonly matchOptions?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#values DataAwsCeTags#values}
        */
        readonly values?: string[];
    }
    class FilterAndDimensionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): FilterAndDimensionProperty | undefined;
        set internalValue(value: FilterAndDimensionProperty | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        resetKey(): void;
        get keyInput(): string | undefined;
        private _matchOptions?;
        get matchOptions(): string[];
        set matchOptions(value: string[]);
        resetMatchOptions(): void;
        get matchOptionsInput(): string[] | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        resetValues(): void;
        get valuesInput(): string[] | undefined;
    }
    interface FilterAndTagsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#key DataAwsCeTags#key}
        */
        readonly key?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#match_options DataAwsCeTags#match_options}
        */
        readonly matchOptions?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#values DataAwsCeTags#values}
        */
        readonly values?: string[];
    }
    class FilterAndTagsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): FilterAndTagsProperty | undefined;
        set internalValue(value: FilterAndTagsProperty | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        resetKey(): void;
        get keyInput(): string | undefined;
        private _matchOptions?;
        get matchOptions(): string[];
        set matchOptions(value: string[]);
        resetMatchOptions(): void;
        get matchOptionsInput(): string[] | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        resetValues(): void;
        get valuesInput(): string[] | undefined;
    }
    interface AndProperty {
        /**
        * cost_category block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#cost_category DataAwsCeTags#cost_category}
        */
        readonly costCategory?: FilterAndCostCategoryProperty;
        /**
        * dimension block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#dimension DataAwsCeTags#dimension}
        */
        readonly dimension?: FilterAndDimensionProperty;
        /**
        * tags block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#tags DataAwsCeTags#tags}
        */
        readonly tags?: FilterAndTagsProperty;
    }
    class AndPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AndProperty | cdktn.IResolvable | undefined;
        set internalValue(value: AndProperty | cdktn.IResolvable | undefined);
        private _costCategory;
        get costCategory(): FilterAndCostCategoryPropertyOutputReference;
        putCostCategory(value: FilterAndCostCategoryProperty): void;
        resetCostCategory(): void;
        get costCategoryInput(): FilterAndCostCategoryProperty | undefined;
        private _dimension;
        get dimension(): FilterAndDimensionPropertyOutputReference;
        putDimension(value: FilterAndDimensionProperty): void;
        resetDimension(): void;
        get dimensionInput(): FilterAndDimensionProperty | undefined;
        private _tags;
        get tags(): FilterAndTagsPropertyOutputReference;
        putTags(value: FilterAndTagsProperty): void;
        resetTags(): void;
        get tagsInput(): FilterAndTagsProperty | undefined;
    }
    class AndPropertyList extends cdktn.ComplexList {
        internalValue?: AndProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AndPropertyOutputReference;
    }
    interface FilterCostCategoryProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#key DataAwsCeTags#key}
        */
        readonly key?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#match_options DataAwsCeTags#match_options}
        */
        readonly matchOptions?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#values DataAwsCeTags#values}
        */
        readonly values?: string[];
    }
    class FilterCostCategoryPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): FilterCostCategoryProperty | undefined;
        set internalValue(value: FilterCostCategoryProperty | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        resetKey(): void;
        get keyInput(): string | undefined;
        private _matchOptions?;
        get matchOptions(): string[];
        set matchOptions(value: string[]);
        resetMatchOptions(): void;
        get matchOptionsInput(): string[] | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        resetValues(): void;
        get valuesInput(): string[] | undefined;
    }
    interface FilterDimensionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#key DataAwsCeTags#key}
        */
        readonly key?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#match_options DataAwsCeTags#match_options}
        */
        readonly matchOptions?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#values DataAwsCeTags#values}
        */
        readonly values?: string[];
    }
    class FilterDimensionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): FilterDimensionProperty | undefined;
        set internalValue(value: FilterDimensionProperty | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        resetKey(): void;
        get keyInput(): string | undefined;
        private _matchOptions?;
        get matchOptions(): string[];
        set matchOptions(value: string[]);
        resetMatchOptions(): void;
        get matchOptionsInput(): string[] | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        resetValues(): void;
        get valuesInput(): string[] | undefined;
    }
    interface FilterNotCostCategoryProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#key DataAwsCeTags#key}
        */
        readonly key?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#match_options DataAwsCeTags#match_options}
        */
        readonly matchOptions?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#values DataAwsCeTags#values}
        */
        readonly values?: string[];
    }
    class FilterNotCostCategoryPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): FilterNotCostCategoryProperty | undefined;
        set internalValue(value: FilterNotCostCategoryProperty | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        resetKey(): void;
        get keyInput(): string | undefined;
        private _matchOptions?;
        get matchOptions(): string[];
        set matchOptions(value: string[]);
        resetMatchOptions(): void;
        get matchOptionsInput(): string[] | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        resetValues(): void;
        get valuesInput(): string[] | undefined;
    }
    interface FilterNotDimensionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#key DataAwsCeTags#key}
        */
        readonly key?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#match_options DataAwsCeTags#match_options}
        */
        readonly matchOptions?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#values DataAwsCeTags#values}
        */
        readonly values?: string[];
    }
    class FilterNotDimensionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): FilterNotDimensionProperty | undefined;
        set internalValue(value: FilterNotDimensionProperty | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        resetKey(): void;
        get keyInput(): string | undefined;
        private _matchOptions?;
        get matchOptions(): string[];
        set matchOptions(value: string[]);
        resetMatchOptions(): void;
        get matchOptionsInput(): string[] | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        resetValues(): void;
        get valuesInput(): string[] | undefined;
    }
    interface FilterNotTagsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#key DataAwsCeTags#key}
        */
        readonly key?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#match_options DataAwsCeTags#match_options}
        */
        readonly matchOptions?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#values DataAwsCeTags#values}
        */
        readonly values?: string[];
    }
    class FilterNotTagsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): FilterNotTagsProperty | undefined;
        set internalValue(value: FilterNotTagsProperty | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        resetKey(): void;
        get keyInput(): string | undefined;
        private _matchOptions?;
        get matchOptions(): string[];
        set matchOptions(value: string[]);
        resetMatchOptions(): void;
        get matchOptionsInput(): string[] | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        resetValues(): void;
        get valuesInput(): string[] | undefined;
    }
    interface NotProperty {
        /**
        * cost_category block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#cost_category DataAwsCeTags#cost_category}
        */
        readonly costCategory?: FilterNotCostCategoryProperty;
        /**
        * dimension block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#dimension DataAwsCeTags#dimension}
        */
        readonly dimension?: FilterNotDimensionProperty;
        /**
        * tags block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#tags DataAwsCeTags#tags}
        */
        readonly tags?: FilterNotTagsProperty;
    }
    class NotPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): NotProperty | undefined;
        set internalValue(value: NotProperty | undefined);
        private _costCategory;
        get costCategory(): FilterNotCostCategoryPropertyOutputReference;
        putCostCategory(value: FilterNotCostCategoryProperty): void;
        resetCostCategory(): void;
        get costCategoryInput(): FilterNotCostCategoryProperty | undefined;
        private _dimension;
        get dimension(): FilterNotDimensionPropertyOutputReference;
        putDimension(value: FilterNotDimensionProperty): void;
        resetDimension(): void;
        get dimensionInput(): FilterNotDimensionProperty | undefined;
        private _tags;
        get tags(): FilterNotTagsPropertyOutputReference;
        putTags(value: FilterNotTagsProperty): void;
        resetTags(): void;
        get tagsInput(): FilterNotTagsProperty | undefined;
    }
    interface FilterOrCostCategoryProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#key DataAwsCeTags#key}
        */
        readonly key?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#match_options DataAwsCeTags#match_options}
        */
        readonly matchOptions?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#values DataAwsCeTags#values}
        */
        readonly values?: string[];
    }
    class FilterOrCostCategoryPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): FilterOrCostCategoryProperty | undefined;
        set internalValue(value: FilterOrCostCategoryProperty | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        resetKey(): void;
        get keyInput(): string | undefined;
        private _matchOptions?;
        get matchOptions(): string[];
        set matchOptions(value: string[]);
        resetMatchOptions(): void;
        get matchOptionsInput(): string[] | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        resetValues(): void;
        get valuesInput(): string[] | undefined;
    }
    interface FilterOrDimensionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#key DataAwsCeTags#key}
        */
        readonly key?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#match_options DataAwsCeTags#match_options}
        */
        readonly matchOptions?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#values DataAwsCeTags#values}
        */
        readonly values?: string[];
    }
    class FilterOrDimensionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): FilterOrDimensionProperty | undefined;
        set internalValue(value: FilterOrDimensionProperty | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        resetKey(): void;
        get keyInput(): string | undefined;
        private _matchOptions?;
        get matchOptions(): string[];
        set matchOptions(value: string[]);
        resetMatchOptions(): void;
        get matchOptionsInput(): string[] | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        resetValues(): void;
        get valuesInput(): string[] | undefined;
    }
    interface FilterOrTagsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#key DataAwsCeTags#key}
        */
        readonly key?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#match_options DataAwsCeTags#match_options}
        */
        readonly matchOptions?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#values DataAwsCeTags#values}
        */
        readonly values?: string[];
    }
    class FilterOrTagsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): FilterOrTagsProperty | undefined;
        set internalValue(value: FilterOrTagsProperty | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        resetKey(): void;
        get keyInput(): string | undefined;
        private _matchOptions?;
        get matchOptions(): string[];
        set matchOptions(value: string[]);
        resetMatchOptions(): void;
        get matchOptionsInput(): string[] | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        resetValues(): void;
        get valuesInput(): string[] | undefined;
    }
    interface OrProperty {
        /**
        * cost_category block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#cost_category DataAwsCeTags#cost_category}
        */
        readonly costCategory?: FilterOrCostCategoryProperty;
        /**
        * dimension block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#dimension DataAwsCeTags#dimension}
        */
        readonly dimension?: FilterOrDimensionProperty;
        /**
        * tags block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#tags DataAwsCeTags#tags}
        */
        readonly tags?: FilterOrTagsProperty;
    }
    class OrPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): OrProperty | cdktn.IResolvable | undefined;
        set internalValue(value: OrProperty | cdktn.IResolvable | undefined);
        private _costCategory;
        get costCategory(): FilterOrCostCategoryPropertyOutputReference;
        putCostCategory(value: FilterOrCostCategoryProperty): void;
        resetCostCategory(): void;
        get costCategoryInput(): FilterOrCostCategoryProperty | undefined;
        private _dimension;
        get dimension(): FilterOrDimensionPropertyOutputReference;
        putDimension(value: FilterOrDimensionProperty): void;
        resetDimension(): void;
        get dimensionInput(): FilterOrDimensionProperty | undefined;
        private _tags;
        get tags(): FilterOrTagsPropertyOutputReference;
        putTags(value: FilterOrTagsProperty): void;
        resetTags(): void;
        get tagsInput(): FilterOrTagsProperty | undefined;
    }
    class OrPropertyList extends cdktn.ComplexList {
        internalValue?: OrProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): OrPropertyOutputReference;
    }
    interface FilterTagsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#key DataAwsCeTags#key}
        */
        readonly key?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#match_options DataAwsCeTags#match_options}
        */
        readonly matchOptions?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#values DataAwsCeTags#values}
        */
        readonly values?: string[];
    }
    class FilterTagsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): FilterTagsProperty | undefined;
        set internalValue(value: FilterTagsProperty | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        resetKey(): void;
        get keyInput(): string | undefined;
        private _matchOptions?;
        get matchOptions(): string[];
        set matchOptions(value: string[]);
        resetMatchOptions(): void;
        get matchOptionsInput(): string[] | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        resetValues(): void;
        get valuesInput(): string[] | undefined;
    }
    interface FilterProperty {
        /**
        * and block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#and DataAwsCeTags#and}
        */
        readonly and?: AndProperty[] | cdktn.IResolvable;
        /**
        * cost_category block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#cost_category DataAwsCeTags#cost_category}
        */
        readonly costCategory?: FilterCostCategoryProperty;
        /**
        * dimension block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#dimension DataAwsCeTags#dimension}
        */
        readonly dimension?: FilterDimensionProperty;
        /**
        * not block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#not DataAwsCeTags#not}
        */
        readonly not?: NotProperty;
        /**
        * or block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#or DataAwsCeTags#or}
        */
        readonly or?: OrProperty[] | cdktn.IResolvable;
        /**
        * tags block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#tags DataAwsCeTags#tags}
        */
        readonly tags?: FilterTagsProperty;
    }
    class FilterPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): FilterProperty | undefined;
        set internalValue(value: FilterProperty | undefined);
        private _and;
        get and(): AndPropertyList;
        putAnd(value: AndProperty[] | cdktn.IResolvable): void;
        resetAnd(): void;
        get andInput(): cdktn.IResolvable | AndProperty[] | undefined;
        private _costCategory;
        get costCategory(): FilterCostCategoryPropertyOutputReference;
        putCostCategory(value: FilterCostCategoryProperty): void;
        resetCostCategory(): void;
        get costCategoryInput(): FilterCostCategoryProperty | undefined;
        private _dimension;
        get dimension(): FilterDimensionPropertyOutputReference;
        putDimension(value: FilterDimensionProperty): void;
        resetDimension(): void;
        get dimensionInput(): FilterDimensionProperty | undefined;
        private _not;
        get not(): NotPropertyOutputReference;
        putNot(value: NotProperty): void;
        resetNot(): void;
        get notInput(): NotProperty | undefined;
        private _or;
        get or(): OrPropertyList;
        putOr(value: OrProperty[] | cdktn.IResolvable): void;
        resetOr(): void;
        get orInput(): cdktn.IResolvable | OrProperty[] | undefined;
        private _tags;
        get tags(): FilterTagsPropertyOutputReference;
        putTags(value: FilterTagsProperty): void;
        resetTags(): void;
        get tagsInput(): FilterTagsProperty | undefined;
    }
    interface SortByProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#key DataAwsCeTags#key}
        */
        readonly key?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#sort_order DataAwsCeTags#sort_order}
        */
        readonly sortOrder?: string;
    }
    class SortByPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SortByProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SortByProperty | cdktn.IResolvable | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        resetKey(): void;
        get keyInput(): string | undefined;
        private _sortOrder?;
        get sortOrder(): string;
        set sortOrder(value: string);
        resetSortOrder(): void;
        get sortOrderInput(): string | undefined;
    }
    class SortByPropertyList extends cdktn.ComplexList {
        internalValue?: SortByProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SortByPropertyOutputReference;
    }
    interface TimePeriodProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#end DataAwsCeTags#end}
        */
        readonly end: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#start DataAwsCeTags#start}
        */
        readonly start: string;
    }
    class TimePeriodPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimePeriodProperty | undefined;
        set internalValue(value: TimePeriodProperty | undefined);
        private _end?;
        get end(): string;
        set end(value: string);
        get endInput(): string | undefined;
        private _start?;
        get start(): string;
        set start(value: string);
        get startInput(): string | undefined;
    }
}
