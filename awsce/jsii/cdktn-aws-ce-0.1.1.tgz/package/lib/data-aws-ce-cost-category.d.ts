import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsCeCostCategoryConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_cost_category#cost_category_arn DataAwsCeCostCategory#cost_category_arn}
    */
    readonly costCategoryArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_cost_category#id DataAwsCeCostCategory#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_cost_category#tags DataAwsCeCostCategory#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_cost_category aws_ce_cost_category}
*/
export declare class DataAwsCeCostCategory extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_ce_cost_category";
    /**
    * Generates CDKTN code for importing a DataAwsCeCostCategory resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsCeCostCategory to import
    * @param importFromId The id of the existing DataAwsCeCostCategory that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_cost_category#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsCeCostCategory to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_cost_category aws_ce_cost_category} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsCeCostCategoryConfig
    */
    constructor(scope: Construct, id: string, config: DataAwsCeCostCategoryConfig);
    private _costCategoryArn?;
    get costCategoryArn(): string;
    set costCategoryArn(value: string);
    get costCategoryArnInput(): string | undefined;
    get defaultValue(): string;
    get effectiveEnd(): string;
    get effectiveStart(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get name(): string;
    private _rule;
    get rule(): DataAwsCeCostCategory.RulePropertyList;
    get ruleVersion(): string;
    private _splitChargeRule;
    get splitChargeRule(): DataAwsCeCostCategory.SplitChargeRulePropertyList;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataAwsCeCostCategoryInheritedValuePropertyToTerraform(struct?: DataAwsCeCostCategory.InheritedValueProperty): any;
export declare function dataAwsCeCostCategoryInheritedValuePropertyToHclTerraform(struct?: DataAwsCeCostCategory.InheritedValueProperty): any;
export declare function dataAwsCeCostCategoryRuleRuleAndAndCostCategoryPropertyToTerraform(struct?: DataAwsCeCostCategory.RuleRuleAndAndCostCategoryProperty): any;
export declare function dataAwsCeCostCategoryRuleRuleAndAndCostCategoryPropertyToHclTerraform(struct?: DataAwsCeCostCategory.RuleRuleAndAndCostCategoryProperty): any;
export declare function dataAwsCeCostCategoryRuleRuleAndAndDimensionPropertyToTerraform(struct?: DataAwsCeCostCategory.RuleRuleAndAndDimensionProperty): any;
export declare function dataAwsCeCostCategoryRuleRuleAndAndDimensionPropertyToHclTerraform(struct?: DataAwsCeCostCategory.RuleRuleAndAndDimensionProperty): any;
export declare function dataAwsCeCostCategoryRuleRuleAndAndTagsPropertyToTerraform(struct?: DataAwsCeCostCategory.RuleRuleAndAndTagsProperty): any;
export declare function dataAwsCeCostCategoryRuleRuleAndAndTagsPropertyToHclTerraform(struct?: DataAwsCeCostCategory.RuleRuleAndAndTagsProperty): any;
export declare function dataAwsCeCostCategoryRuleRuleAndAndPropertyToTerraform(struct?: DataAwsCeCostCategory.RuleRuleAndAndProperty): any;
export declare function dataAwsCeCostCategoryRuleRuleAndAndPropertyToHclTerraform(struct?: DataAwsCeCostCategory.RuleRuleAndAndProperty): any;
export declare function dataAwsCeCostCategoryRuleRuleAndCostCategoryPropertyToTerraform(struct?: DataAwsCeCostCategory.RuleRuleAndCostCategoryProperty): any;
export declare function dataAwsCeCostCategoryRuleRuleAndCostCategoryPropertyToHclTerraform(struct?: DataAwsCeCostCategory.RuleRuleAndCostCategoryProperty): any;
export declare function dataAwsCeCostCategoryRuleRuleAndDimensionPropertyToTerraform(struct?: DataAwsCeCostCategory.RuleRuleAndDimensionProperty): any;
export declare function dataAwsCeCostCategoryRuleRuleAndDimensionPropertyToHclTerraform(struct?: DataAwsCeCostCategory.RuleRuleAndDimensionProperty): any;
export declare function dataAwsCeCostCategoryRuleRuleAndNotCostCategoryPropertyToTerraform(struct?: DataAwsCeCostCategory.RuleRuleAndNotCostCategoryProperty): any;
export declare function dataAwsCeCostCategoryRuleRuleAndNotCostCategoryPropertyToHclTerraform(struct?: DataAwsCeCostCategory.RuleRuleAndNotCostCategoryProperty): any;
export declare function dataAwsCeCostCategoryRuleRuleAndNotDimensionPropertyToTerraform(struct?: DataAwsCeCostCategory.RuleRuleAndNotDimensionProperty): any;
export declare function dataAwsCeCostCategoryRuleRuleAndNotDimensionPropertyToHclTerraform(struct?: DataAwsCeCostCategory.RuleRuleAndNotDimensionProperty): any;
export declare function dataAwsCeCostCategoryRuleRuleAndNotTagsPropertyToTerraform(struct?: DataAwsCeCostCategory.RuleRuleAndNotTagsProperty): any;
export declare function dataAwsCeCostCategoryRuleRuleAndNotTagsPropertyToHclTerraform(struct?: DataAwsCeCostCategory.RuleRuleAndNotTagsProperty): any;
export declare function dataAwsCeCostCategoryRuleRuleAndNotPropertyToTerraform(struct?: DataAwsCeCostCategory.RuleRuleAndNotProperty): any;
export declare function dataAwsCeCostCategoryRuleRuleAndNotPropertyToHclTerraform(struct?: DataAwsCeCostCategory.RuleRuleAndNotProperty): any;
export declare function dataAwsCeCostCategoryRuleRuleAndOrCostCategoryPropertyToTerraform(struct?: DataAwsCeCostCategory.RuleRuleAndOrCostCategoryProperty): any;
export declare function dataAwsCeCostCategoryRuleRuleAndOrCostCategoryPropertyToHclTerraform(struct?: DataAwsCeCostCategory.RuleRuleAndOrCostCategoryProperty): any;
export declare function dataAwsCeCostCategoryRuleRuleAndOrDimensionPropertyToTerraform(struct?: DataAwsCeCostCategory.RuleRuleAndOrDimensionProperty): any;
export declare function dataAwsCeCostCategoryRuleRuleAndOrDimensionPropertyToHclTerraform(struct?: DataAwsCeCostCategory.RuleRuleAndOrDimensionProperty): any;
export declare function dataAwsCeCostCategoryRuleRuleAndOrTagsPropertyToTerraform(struct?: DataAwsCeCostCategory.RuleRuleAndOrTagsProperty): any;
export declare function dataAwsCeCostCategoryRuleRuleAndOrTagsPropertyToHclTerraform(struct?: DataAwsCeCostCategory.RuleRuleAndOrTagsProperty): any;
export declare function dataAwsCeCostCategoryRuleRuleAndOrPropertyToTerraform(struct?: DataAwsCeCostCategory.RuleRuleAndOrProperty): any;
export declare function dataAwsCeCostCategoryRuleRuleAndOrPropertyToHclTerraform(struct?: DataAwsCeCostCategory.RuleRuleAndOrProperty): any;
export declare function dataAwsCeCostCategoryRuleRuleAndTagsPropertyToTerraform(struct?: DataAwsCeCostCategory.RuleRuleAndTagsProperty): any;
export declare function dataAwsCeCostCategoryRuleRuleAndTagsPropertyToHclTerraform(struct?: DataAwsCeCostCategory.RuleRuleAndTagsProperty): any;
export declare function dataAwsCeCostCategoryRuleRuleAndPropertyToTerraform(struct?: DataAwsCeCostCategory.RuleRuleAndProperty): any;
export declare function dataAwsCeCostCategoryRuleRuleAndPropertyToHclTerraform(struct?: DataAwsCeCostCategory.RuleRuleAndProperty): any;
export declare function dataAwsCeCostCategoryRuleRuleCostCategoryPropertyToTerraform(struct?: DataAwsCeCostCategory.RuleRuleCostCategoryProperty): any;
export declare function dataAwsCeCostCategoryRuleRuleCostCategoryPropertyToHclTerraform(struct?: DataAwsCeCostCategory.RuleRuleCostCategoryProperty): any;
export declare function dataAwsCeCostCategoryRuleRuleDimensionPropertyToTerraform(struct?: DataAwsCeCostCategory.RuleRuleDimensionProperty): any;
export declare function dataAwsCeCostCategoryRuleRuleDimensionPropertyToHclTerraform(struct?: DataAwsCeCostCategory.RuleRuleDimensionProperty): any;
export declare function dataAwsCeCostCategoryRuleRuleNotAndCostCategoryPropertyToTerraform(struct?: DataAwsCeCostCategory.RuleRuleNotAndCostCategoryProperty): any;
export declare function dataAwsCeCostCategoryRuleRuleNotAndCostCategoryPropertyToHclTerraform(struct?: DataAwsCeCostCategory.RuleRuleNotAndCostCategoryProperty): any;
export declare function dataAwsCeCostCategoryRuleRuleNotAndDimensionPropertyToTerraform(struct?: DataAwsCeCostCategory.RuleRuleNotAndDimensionProperty): any;
export declare function dataAwsCeCostCategoryRuleRuleNotAndDimensionPropertyToHclTerraform(struct?: DataAwsCeCostCategory.RuleRuleNotAndDimensionProperty): any;
export declare function dataAwsCeCostCategoryRuleRuleNotAndTagsPropertyToTerraform(struct?: DataAwsCeCostCategory.RuleRuleNotAndTagsProperty): any;
export declare function dataAwsCeCostCategoryRuleRuleNotAndTagsPropertyToHclTerraform(struct?: DataAwsCeCostCategory.RuleRuleNotAndTagsProperty): any;
export declare function dataAwsCeCostCategoryRuleRuleNotAndPropertyToTerraform(struct?: DataAwsCeCostCategory.RuleRuleNotAndProperty): any;
export declare function dataAwsCeCostCategoryRuleRuleNotAndPropertyToHclTerraform(struct?: DataAwsCeCostCategory.RuleRuleNotAndProperty): any;
export declare function dataAwsCeCostCategoryRuleRuleNotCostCategoryPropertyToTerraform(struct?: DataAwsCeCostCategory.RuleRuleNotCostCategoryProperty): any;
export declare function dataAwsCeCostCategoryRuleRuleNotCostCategoryPropertyToHclTerraform(struct?: DataAwsCeCostCategory.RuleRuleNotCostCategoryProperty): any;
export declare function dataAwsCeCostCategoryRuleRuleNotDimensionPropertyToTerraform(struct?: DataAwsCeCostCategory.RuleRuleNotDimensionProperty): any;
export declare function dataAwsCeCostCategoryRuleRuleNotDimensionPropertyToHclTerraform(struct?: DataAwsCeCostCategory.RuleRuleNotDimensionProperty): any;
export declare function dataAwsCeCostCategoryRuleRuleNotNotCostCategoryPropertyToTerraform(struct?: DataAwsCeCostCategory.RuleRuleNotNotCostCategoryProperty): any;
export declare function dataAwsCeCostCategoryRuleRuleNotNotCostCategoryPropertyToHclTerraform(struct?: DataAwsCeCostCategory.RuleRuleNotNotCostCategoryProperty): any;
export declare function dataAwsCeCostCategoryRuleRuleNotNotDimensionPropertyToTerraform(struct?: DataAwsCeCostCategory.RuleRuleNotNotDimensionProperty): any;
export declare function dataAwsCeCostCategoryRuleRuleNotNotDimensionPropertyToHclTerraform(struct?: DataAwsCeCostCategory.RuleRuleNotNotDimensionProperty): any;
export declare function dataAwsCeCostCategoryRuleRuleNotNotTagsPropertyToTerraform(struct?: DataAwsCeCostCategory.RuleRuleNotNotTagsProperty): any;
export declare function dataAwsCeCostCategoryRuleRuleNotNotTagsPropertyToHclTerraform(struct?: DataAwsCeCostCategory.RuleRuleNotNotTagsProperty): any;
export declare function dataAwsCeCostCategoryRuleRuleNotNotPropertyToTerraform(struct?: DataAwsCeCostCategory.RuleRuleNotNotProperty): any;
export declare function dataAwsCeCostCategoryRuleRuleNotNotPropertyToHclTerraform(struct?: DataAwsCeCostCategory.RuleRuleNotNotProperty): any;
export declare function dataAwsCeCostCategoryRuleRuleNotOrCostCategoryPropertyToTerraform(struct?: DataAwsCeCostCategory.RuleRuleNotOrCostCategoryProperty): any;
export declare function dataAwsCeCostCategoryRuleRuleNotOrCostCategoryPropertyToHclTerraform(struct?: DataAwsCeCostCategory.RuleRuleNotOrCostCategoryProperty): any;
export declare function dataAwsCeCostCategoryRuleRuleNotOrDimensionPropertyToTerraform(struct?: DataAwsCeCostCategory.RuleRuleNotOrDimensionProperty): any;
export declare function dataAwsCeCostCategoryRuleRuleNotOrDimensionPropertyToHclTerraform(struct?: DataAwsCeCostCategory.RuleRuleNotOrDimensionProperty): any;
export declare function dataAwsCeCostCategoryRuleRuleNotOrTagsPropertyToTerraform(struct?: DataAwsCeCostCategory.RuleRuleNotOrTagsProperty): any;
export declare function dataAwsCeCostCategoryRuleRuleNotOrTagsPropertyToHclTerraform(struct?: DataAwsCeCostCategory.RuleRuleNotOrTagsProperty): any;
export declare function dataAwsCeCostCategoryRuleRuleNotOrPropertyToTerraform(struct?: DataAwsCeCostCategory.RuleRuleNotOrProperty): any;
export declare function dataAwsCeCostCategoryRuleRuleNotOrPropertyToHclTerraform(struct?: DataAwsCeCostCategory.RuleRuleNotOrProperty): any;
export declare function dataAwsCeCostCategoryRuleRuleNotTagsPropertyToTerraform(struct?: DataAwsCeCostCategory.RuleRuleNotTagsProperty): any;
export declare function dataAwsCeCostCategoryRuleRuleNotTagsPropertyToHclTerraform(struct?: DataAwsCeCostCategory.RuleRuleNotTagsProperty): any;
export declare function dataAwsCeCostCategoryRuleRuleNotPropertyToTerraform(struct?: DataAwsCeCostCategory.RuleRuleNotProperty): any;
export declare function dataAwsCeCostCategoryRuleRuleNotPropertyToHclTerraform(struct?: DataAwsCeCostCategory.RuleRuleNotProperty): any;
export declare function dataAwsCeCostCategoryRuleRuleOrAndCostCategoryPropertyToTerraform(struct?: DataAwsCeCostCategory.RuleRuleOrAndCostCategoryProperty): any;
export declare function dataAwsCeCostCategoryRuleRuleOrAndCostCategoryPropertyToHclTerraform(struct?: DataAwsCeCostCategory.RuleRuleOrAndCostCategoryProperty): any;
export declare function dataAwsCeCostCategoryRuleRuleOrAndDimensionPropertyToTerraform(struct?: DataAwsCeCostCategory.RuleRuleOrAndDimensionProperty): any;
export declare function dataAwsCeCostCategoryRuleRuleOrAndDimensionPropertyToHclTerraform(struct?: DataAwsCeCostCategory.RuleRuleOrAndDimensionProperty): any;
export declare function dataAwsCeCostCategoryRuleRuleOrAndTagsPropertyToTerraform(struct?: DataAwsCeCostCategory.RuleRuleOrAndTagsProperty): any;
export declare function dataAwsCeCostCategoryRuleRuleOrAndTagsPropertyToHclTerraform(struct?: DataAwsCeCostCategory.RuleRuleOrAndTagsProperty): any;
export declare function dataAwsCeCostCategoryRuleRuleOrAndPropertyToTerraform(struct?: DataAwsCeCostCategory.RuleRuleOrAndProperty): any;
export declare function dataAwsCeCostCategoryRuleRuleOrAndPropertyToHclTerraform(struct?: DataAwsCeCostCategory.RuleRuleOrAndProperty): any;
export declare function dataAwsCeCostCategoryRuleRuleOrCostCategoryPropertyToTerraform(struct?: DataAwsCeCostCategory.RuleRuleOrCostCategoryProperty): any;
export declare function dataAwsCeCostCategoryRuleRuleOrCostCategoryPropertyToHclTerraform(struct?: DataAwsCeCostCategory.RuleRuleOrCostCategoryProperty): any;
export declare function dataAwsCeCostCategoryRuleRuleOrDimensionPropertyToTerraform(struct?: DataAwsCeCostCategory.RuleRuleOrDimensionProperty): any;
export declare function dataAwsCeCostCategoryRuleRuleOrDimensionPropertyToHclTerraform(struct?: DataAwsCeCostCategory.RuleRuleOrDimensionProperty): any;
export declare function dataAwsCeCostCategoryRuleRuleOrNotCostCategoryPropertyToTerraform(struct?: DataAwsCeCostCategory.RuleRuleOrNotCostCategoryProperty): any;
export declare function dataAwsCeCostCategoryRuleRuleOrNotCostCategoryPropertyToHclTerraform(struct?: DataAwsCeCostCategory.RuleRuleOrNotCostCategoryProperty): any;
export declare function dataAwsCeCostCategoryRuleRuleOrNotDimensionPropertyToTerraform(struct?: DataAwsCeCostCategory.RuleRuleOrNotDimensionProperty): any;
export declare function dataAwsCeCostCategoryRuleRuleOrNotDimensionPropertyToHclTerraform(struct?: DataAwsCeCostCategory.RuleRuleOrNotDimensionProperty): any;
export declare function dataAwsCeCostCategoryRuleRuleOrNotTagsPropertyToTerraform(struct?: DataAwsCeCostCategory.RuleRuleOrNotTagsProperty): any;
export declare function dataAwsCeCostCategoryRuleRuleOrNotTagsPropertyToHclTerraform(struct?: DataAwsCeCostCategory.RuleRuleOrNotTagsProperty): any;
export declare function dataAwsCeCostCategoryRuleRuleOrNotPropertyToTerraform(struct?: DataAwsCeCostCategory.RuleRuleOrNotProperty): any;
export declare function dataAwsCeCostCategoryRuleRuleOrNotPropertyToHclTerraform(struct?: DataAwsCeCostCategory.RuleRuleOrNotProperty): any;
export declare function dataAwsCeCostCategoryRuleRuleOrOrCostCategoryPropertyToTerraform(struct?: DataAwsCeCostCategory.RuleRuleOrOrCostCategoryProperty): any;
export declare function dataAwsCeCostCategoryRuleRuleOrOrCostCategoryPropertyToHclTerraform(struct?: DataAwsCeCostCategory.RuleRuleOrOrCostCategoryProperty): any;
export declare function dataAwsCeCostCategoryRuleRuleOrOrDimensionPropertyToTerraform(struct?: DataAwsCeCostCategory.RuleRuleOrOrDimensionProperty): any;
export declare function dataAwsCeCostCategoryRuleRuleOrOrDimensionPropertyToHclTerraform(struct?: DataAwsCeCostCategory.RuleRuleOrOrDimensionProperty): any;
export declare function dataAwsCeCostCategoryRuleRuleOrOrTagsPropertyToTerraform(struct?: DataAwsCeCostCategory.RuleRuleOrOrTagsProperty): any;
export declare function dataAwsCeCostCategoryRuleRuleOrOrTagsPropertyToHclTerraform(struct?: DataAwsCeCostCategory.RuleRuleOrOrTagsProperty): any;
export declare function dataAwsCeCostCategoryRuleRuleOrOrPropertyToTerraform(struct?: DataAwsCeCostCategory.RuleRuleOrOrProperty): any;
export declare function dataAwsCeCostCategoryRuleRuleOrOrPropertyToHclTerraform(struct?: DataAwsCeCostCategory.RuleRuleOrOrProperty): any;
export declare function dataAwsCeCostCategoryRuleRuleOrTagsPropertyToTerraform(struct?: DataAwsCeCostCategory.RuleRuleOrTagsProperty): any;
export declare function dataAwsCeCostCategoryRuleRuleOrTagsPropertyToHclTerraform(struct?: DataAwsCeCostCategory.RuleRuleOrTagsProperty): any;
export declare function dataAwsCeCostCategoryRuleRuleOrPropertyToTerraform(struct?: DataAwsCeCostCategory.RuleRuleOrProperty): any;
export declare function dataAwsCeCostCategoryRuleRuleOrPropertyToHclTerraform(struct?: DataAwsCeCostCategory.RuleRuleOrProperty): any;
export declare function dataAwsCeCostCategoryRuleRuleTagsPropertyToTerraform(struct?: DataAwsCeCostCategory.RuleRuleTagsProperty): any;
export declare function dataAwsCeCostCategoryRuleRuleTagsPropertyToHclTerraform(struct?: DataAwsCeCostCategory.RuleRuleTagsProperty): any;
export declare function dataAwsCeCostCategoryRuleRulePropertyToTerraform(struct?: DataAwsCeCostCategory.RuleRuleProperty): any;
export declare function dataAwsCeCostCategoryRuleRulePropertyToHclTerraform(struct?: DataAwsCeCostCategory.RuleRuleProperty): any;
export declare function dataAwsCeCostCategoryRulePropertyToTerraform(struct?: DataAwsCeCostCategory.RuleProperty): any;
export declare function dataAwsCeCostCategoryRulePropertyToHclTerraform(struct?: DataAwsCeCostCategory.RuleProperty): any;
export declare function dataAwsCeCostCategoryParameterPropertyToTerraform(struct?: DataAwsCeCostCategory.ParameterProperty): any;
export declare function dataAwsCeCostCategoryParameterPropertyToHclTerraform(struct?: DataAwsCeCostCategory.ParameterProperty): any;
export declare function dataAwsCeCostCategorySplitChargeRulePropertyToTerraform(struct?: DataAwsCeCostCategory.SplitChargeRuleProperty): any;
export declare function dataAwsCeCostCategorySplitChargeRulePropertyToHclTerraform(struct?: DataAwsCeCostCategory.SplitChargeRuleProperty): any;
export declare namespace DataAwsCeCostCategory {
    interface InheritedValueProperty {
    }
    class InheritedValuePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): InheritedValueProperty | undefined;
        set internalValue(value: InheritedValueProperty | undefined);
        get dimensionKey(): string;
        get dimensionName(): string;
    }
    class InheritedValuePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): InheritedValuePropertyOutputReference;
    }
    interface RuleRuleAndAndCostCategoryProperty {
    }
    class RuleRuleAndAndCostCategoryPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleRuleAndAndCostCategoryProperty | undefined;
        set internalValue(value: RuleRuleAndAndCostCategoryProperty | undefined);
        get key(): string;
        get matchOptions(): string[];
        get values(): string[];
    }
    class RuleRuleAndAndCostCategoryPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleRuleAndAndCostCategoryPropertyOutputReference;
    }
    interface RuleRuleAndAndDimensionProperty {
    }
    class RuleRuleAndAndDimensionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleRuleAndAndDimensionProperty | undefined;
        set internalValue(value: RuleRuleAndAndDimensionProperty | undefined);
        get key(): string;
        get matchOptions(): string[];
        get values(): string[];
    }
    class RuleRuleAndAndDimensionPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleRuleAndAndDimensionPropertyOutputReference;
    }
    interface RuleRuleAndAndTagsProperty {
    }
    class RuleRuleAndAndTagsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleRuleAndAndTagsProperty | undefined;
        set internalValue(value: RuleRuleAndAndTagsProperty | undefined);
        get key(): string;
        get matchOptions(): string[];
        get values(): string[];
    }
    class RuleRuleAndAndTagsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleRuleAndAndTagsPropertyOutputReference;
    }
    interface RuleRuleAndAndProperty {
    }
    class RuleRuleAndAndPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleRuleAndAndProperty | undefined;
        set internalValue(value: RuleRuleAndAndProperty | undefined);
        private _costCategory;
        get costCategory(): RuleRuleAndAndCostCategoryPropertyList;
        private _dimension;
        get dimension(): RuleRuleAndAndDimensionPropertyList;
        private _tags;
        get tags(): RuleRuleAndAndTagsPropertyList;
    }
    class RuleRuleAndAndPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleRuleAndAndPropertyOutputReference;
    }
    interface RuleRuleAndCostCategoryProperty {
    }
    class RuleRuleAndCostCategoryPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleRuleAndCostCategoryProperty | undefined;
        set internalValue(value: RuleRuleAndCostCategoryProperty | undefined);
        get key(): string;
        get matchOptions(): string[];
        get values(): string[];
    }
    class RuleRuleAndCostCategoryPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleRuleAndCostCategoryPropertyOutputReference;
    }
    interface RuleRuleAndDimensionProperty {
    }
    class RuleRuleAndDimensionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleRuleAndDimensionProperty | undefined;
        set internalValue(value: RuleRuleAndDimensionProperty | undefined);
        get key(): string;
        get matchOptions(): string[];
        get values(): string[];
    }
    class RuleRuleAndDimensionPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleRuleAndDimensionPropertyOutputReference;
    }
    interface RuleRuleAndNotCostCategoryProperty {
    }
    class RuleRuleAndNotCostCategoryPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleRuleAndNotCostCategoryProperty | undefined;
        set internalValue(value: RuleRuleAndNotCostCategoryProperty | undefined);
        get key(): string;
        get matchOptions(): string[];
        get values(): string[];
    }
    class RuleRuleAndNotCostCategoryPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleRuleAndNotCostCategoryPropertyOutputReference;
    }
    interface RuleRuleAndNotDimensionProperty {
    }
    class RuleRuleAndNotDimensionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleRuleAndNotDimensionProperty | undefined;
        set internalValue(value: RuleRuleAndNotDimensionProperty | undefined);
        get key(): string;
        get matchOptions(): string[];
        get values(): string[];
    }
    class RuleRuleAndNotDimensionPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleRuleAndNotDimensionPropertyOutputReference;
    }
    interface RuleRuleAndNotTagsProperty {
    }
    class RuleRuleAndNotTagsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleRuleAndNotTagsProperty | undefined;
        set internalValue(value: RuleRuleAndNotTagsProperty | undefined);
        get key(): string;
        get matchOptions(): string[];
        get values(): string[];
    }
    class RuleRuleAndNotTagsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleRuleAndNotTagsPropertyOutputReference;
    }
    interface RuleRuleAndNotProperty {
    }
    class RuleRuleAndNotPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleRuleAndNotProperty | undefined;
        set internalValue(value: RuleRuleAndNotProperty | undefined);
        private _costCategory;
        get costCategory(): RuleRuleAndNotCostCategoryPropertyList;
        private _dimension;
        get dimension(): RuleRuleAndNotDimensionPropertyList;
        private _tags;
        get tags(): RuleRuleAndNotTagsPropertyList;
    }
    class RuleRuleAndNotPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleRuleAndNotPropertyOutputReference;
    }
    interface RuleRuleAndOrCostCategoryProperty {
    }
    class RuleRuleAndOrCostCategoryPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleRuleAndOrCostCategoryProperty | undefined;
        set internalValue(value: RuleRuleAndOrCostCategoryProperty | undefined);
        get key(): string;
        get matchOptions(): string[];
        get values(): string[];
    }
    class RuleRuleAndOrCostCategoryPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleRuleAndOrCostCategoryPropertyOutputReference;
    }
    interface RuleRuleAndOrDimensionProperty {
    }
    class RuleRuleAndOrDimensionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleRuleAndOrDimensionProperty | undefined;
        set internalValue(value: RuleRuleAndOrDimensionProperty | undefined);
        get key(): string;
        get matchOptions(): string[];
        get values(): string[];
    }
    class RuleRuleAndOrDimensionPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleRuleAndOrDimensionPropertyOutputReference;
    }
    interface RuleRuleAndOrTagsProperty {
    }
    class RuleRuleAndOrTagsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleRuleAndOrTagsProperty | undefined;
        set internalValue(value: RuleRuleAndOrTagsProperty | undefined);
        get key(): string;
        get matchOptions(): string[];
        get values(): string[];
    }
    class RuleRuleAndOrTagsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleRuleAndOrTagsPropertyOutputReference;
    }
    interface RuleRuleAndOrProperty {
    }
    class RuleRuleAndOrPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleRuleAndOrProperty | undefined;
        set internalValue(value: RuleRuleAndOrProperty | undefined);
        private _costCategory;
        get costCategory(): RuleRuleAndOrCostCategoryPropertyList;
        private _dimension;
        get dimension(): RuleRuleAndOrDimensionPropertyList;
        private _tags;
        get tags(): RuleRuleAndOrTagsPropertyList;
    }
    class RuleRuleAndOrPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleRuleAndOrPropertyOutputReference;
    }
    interface RuleRuleAndTagsProperty {
    }
    class RuleRuleAndTagsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleRuleAndTagsProperty | undefined;
        set internalValue(value: RuleRuleAndTagsProperty | undefined);
        get key(): string;
        get matchOptions(): string[];
        get values(): string[];
    }
    class RuleRuleAndTagsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleRuleAndTagsPropertyOutputReference;
    }
    interface RuleRuleAndProperty {
    }
    class RuleRuleAndPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleRuleAndProperty | undefined;
        set internalValue(value: RuleRuleAndProperty | undefined);
        private _and;
        get and(): RuleRuleAndAndPropertyList;
        private _costCategory;
        get costCategory(): RuleRuleAndCostCategoryPropertyList;
        private _dimension;
        get dimension(): RuleRuleAndDimensionPropertyList;
        private _not;
        get not(): RuleRuleAndNotPropertyList;
        private _or;
        get or(): RuleRuleAndOrPropertyList;
        private _tags;
        get tags(): RuleRuleAndTagsPropertyList;
    }
    class RuleRuleAndPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleRuleAndPropertyOutputReference;
    }
    interface RuleRuleCostCategoryProperty {
    }
    class RuleRuleCostCategoryPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleRuleCostCategoryProperty | undefined;
        set internalValue(value: RuleRuleCostCategoryProperty | undefined);
        get key(): string;
        get matchOptions(): string[];
        get values(): string[];
    }
    class RuleRuleCostCategoryPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleRuleCostCategoryPropertyOutputReference;
    }
    interface RuleRuleDimensionProperty {
    }
    class RuleRuleDimensionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleRuleDimensionProperty | undefined;
        set internalValue(value: RuleRuleDimensionProperty | undefined);
        get key(): string;
        get matchOptions(): string[];
        get values(): string[];
    }
    class RuleRuleDimensionPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleRuleDimensionPropertyOutputReference;
    }
    interface RuleRuleNotAndCostCategoryProperty {
    }
    class RuleRuleNotAndCostCategoryPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleRuleNotAndCostCategoryProperty | undefined;
        set internalValue(value: RuleRuleNotAndCostCategoryProperty | undefined);
        get key(): string;
        get matchOptions(): string[];
        get values(): string[];
    }
    class RuleRuleNotAndCostCategoryPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleRuleNotAndCostCategoryPropertyOutputReference;
    }
    interface RuleRuleNotAndDimensionProperty {
    }
    class RuleRuleNotAndDimensionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleRuleNotAndDimensionProperty | undefined;
        set internalValue(value: RuleRuleNotAndDimensionProperty | undefined);
        get key(): string;
        get matchOptions(): string[];
        get values(): string[];
    }
    class RuleRuleNotAndDimensionPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleRuleNotAndDimensionPropertyOutputReference;
    }
    interface RuleRuleNotAndTagsProperty {
    }
    class RuleRuleNotAndTagsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleRuleNotAndTagsProperty | undefined;
        set internalValue(value: RuleRuleNotAndTagsProperty | undefined);
        get key(): string;
        get matchOptions(): string[];
        get values(): string[];
    }
    class RuleRuleNotAndTagsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleRuleNotAndTagsPropertyOutputReference;
    }
    interface RuleRuleNotAndProperty {
    }
    class RuleRuleNotAndPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleRuleNotAndProperty | undefined;
        set internalValue(value: RuleRuleNotAndProperty | undefined);
        private _costCategory;
        get costCategory(): RuleRuleNotAndCostCategoryPropertyList;
        private _dimension;
        get dimension(): RuleRuleNotAndDimensionPropertyList;
        private _tags;
        get tags(): RuleRuleNotAndTagsPropertyList;
    }
    class RuleRuleNotAndPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleRuleNotAndPropertyOutputReference;
    }
    interface RuleRuleNotCostCategoryProperty {
    }
    class RuleRuleNotCostCategoryPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleRuleNotCostCategoryProperty | undefined;
        set internalValue(value: RuleRuleNotCostCategoryProperty | undefined);
        get key(): string;
        get matchOptions(): string[];
        get values(): string[];
    }
    class RuleRuleNotCostCategoryPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleRuleNotCostCategoryPropertyOutputReference;
    }
    interface RuleRuleNotDimensionProperty {
    }
    class RuleRuleNotDimensionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleRuleNotDimensionProperty | undefined;
        set internalValue(value: RuleRuleNotDimensionProperty | undefined);
        get key(): string;
        get matchOptions(): string[];
        get values(): string[];
    }
    class RuleRuleNotDimensionPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleRuleNotDimensionPropertyOutputReference;
    }
    interface RuleRuleNotNotCostCategoryProperty {
    }
    class RuleRuleNotNotCostCategoryPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleRuleNotNotCostCategoryProperty | undefined;
        set internalValue(value: RuleRuleNotNotCostCategoryProperty | undefined);
        get key(): string;
        get matchOptions(): string[];
        get values(): string[];
    }
    class RuleRuleNotNotCostCategoryPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleRuleNotNotCostCategoryPropertyOutputReference;
    }
    interface RuleRuleNotNotDimensionProperty {
    }
    class RuleRuleNotNotDimensionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleRuleNotNotDimensionProperty | undefined;
        set internalValue(value: RuleRuleNotNotDimensionProperty | undefined);
        get key(): string;
        get matchOptions(): string[];
        get values(): string[];
    }
    class RuleRuleNotNotDimensionPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleRuleNotNotDimensionPropertyOutputReference;
    }
    interface RuleRuleNotNotTagsProperty {
    }
    class RuleRuleNotNotTagsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleRuleNotNotTagsProperty | undefined;
        set internalValue(value: RuleRuleNotNotTagsProperty | undefined);
        get key(): string;
        get matchOptions(): string[];
        get values(): string[];
    }
    class RuleRuleNotNotTagsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleRuleNotNotTagsPropertyOutputReference;
    }
    interface RuleRuleNotNotProperty {
    }
    class RuleRuleNotNotPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleRuleNotNotProperty | undefined;
        set internalValue(value: RuleRuleNotNotProperty | undefined);
        private _costCategory;
        get costCategory(): RuleRuleNotNotCostCategoryPropertyList;
        private _dimension;
        get dimension(): RuleRuleNotNotDimensionPropertyList;
        private _tags;
        get tags(): RuleRuleNotNotTagsPropertyList;
    }
    class RuleRuleNotNotPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleRuleNotNotPropertyOutputReference;
    }
    interface RuleRuleNotOrCostCategoryProperty {
    }
    class RuleRuleNotOrCostCategoryPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleRuleNotOrCostCategoryProperty | undefined;
        set internalValue(value: RuleRuleNotOrCostCategoryProperty | undefined);
        get key(): string;
        get matchOptions(): string[];
        get values(): string[];
    }
    class RuleRuleNotOrCostCategoryPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleRuleNotOrCostCategoryPropertyOutputReference;
    }
    interface RuleRuleNotOrDimensionProperty {
    }
    class RuleRuleNotOrDimensionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleRuleNotOrDimensionProperty | undefined;
        set internalValue(value: RuleRuleNotOrDimensionProperty | undefined);
        get key(): string;
        get matchOptions(): string[];
        get values(): string[];
    }
    class RuleRuleNotOrDimensionPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleRuleNotOrDimensionPropertyOutputReference;
    }
    interface RuleRuleNotOrTagsProperty {
    }
    class RuleRuleNotOrTagsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleRuleNotOrTagsProperty | undefined;
        set internalValue(value: RuleRuleNotOrTagsProperty | undefined);
        get key(): string;
        get matchOptions(): string[];
        get values(): string[];
    }
    class RuleRuleNotOrTagsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleRuleNotOrTagsPropertyOutputReference;
    }
    interface RuleRuleNotOrProperty {
    }
    class RuleRuleNotOrPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleRuleNotOrProperty | undefined;
        set internalValue(value: RuleRuleNotOrProperty | undefined);
        private _costCategory;
        get costCategory(): RuleRuleNotOrCostCategoryPropertyList;
        private _dimension;
        get dimension(): RuleRuleNotOrDimensionPropertyList;
        private _tags;
        get tags(): RuleRuleNotOrTagsPropertyList;
    }
    class RuleRuleNotOrPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleRuleNotOrPropertyOutputReference;
    }
    interface RuleRuleNotTagsProperty {
    }
    class RuleRuleNotTagsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleRuleNotTagsProperty | undefined;
        set internalValue(value: RuleRuleNotTagsProperty | undefined);
        get key(): string;
        get matchOptions(): string[];
        get values(): string[];
    }
    class RuleRuleNotTagsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleRuleNotTagsPropertyOutputReference;
    }
    interface RuleRuleNotProperty {
    }
    class RuleRuleNotPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleRuleNotProperty | undefined;
        set internalValue(value: RuleRuleNotProperty | undefined);
        private _and;
        get and(): RuleRuleNotAndPropertyList;
        private _costCategory;
        get costCategory(): RuleRuleNotCostCategoryPropertyList;
        private _dimension;
        get dimension(): RuleRuleNotDimensionPropertyList;
        private _not;
        get not(): RuleRuleNotNotPropertyList;
        private _or;
        get or(): RuleRuleNotOrPropertyList;
        private _tags;
        get tags(): RuleRuleNotTagsPropertyList;
    }
    class RuleRuleNotPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleRuleNotPropertyOutputReference;
    }
    interface RuleRuleOrAndCostCategoryProperty {
    }
    class RuleRuleOrAndCostCategoryPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleRuleOrAndCostCategoryProperty | undefined;
        set internalValue(value: RuleRuleOrAndCostCategoryProperty | undefined);
        get key(): string;
        get matchOptions(): string[];
        get values(): string[];
    }
    class RuleRuleOrAndCostCategoryPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleRuleOrAndCostCategoryPropertyOutputReference;
    }
    interface RuleRuleOrAndDimensionProperty {
    }
    class RuleRuleOrAndDimensionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleRuleOrAndDimensionProperty | undefined;
        set internalValue(value: RuleRuleOrAndDimensionProperty | undefined);
        get key(): string;
        get matchOptions(): string[];
        get values(): string[];
    }
    class RuleRuleOrAndDimensionPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleRuleOrAndDimensionPropertyOutputReference;
    }
    interface RuleRuleOrAndTagsProperty {
    }
    class RuleRuleOrAndTagsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleRuleOrAndTagsProperty | undefined;
        set internalValue(value: RuleRuleOrAndTagsProperty | undefined);
        get key(): string;
        get matchOptions(): string[];
        get values(): string[];
    }
    class RuleRuleOrAndTagsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleRuleOrAndTagsPropertyOutputReference;
    }
    interface RuleRuleOrAndProperty {
    }
    class RuleRuleOrAndPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleRuleOrAndProperty | undefined;
        set internalValue(value: RuleRuleOrAndProperty | undefined);
        private _costCategory;
        get costCategory(): RuleRuleOrAndCostCategoryPropertyList;
        private _dimension;
        get dimension(): RuleRuleOrAndDimensionPropertyList;
        private _tags;
        get tags(): RuleRuleOrAndTagsPropertyList;
    }
    class RuleRuleOrAndPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleRuleOrAndPropertyOutputReference;
    }
    interface RuleRuleOrCostCategoryProperty {
    }
    class RuleRuleOrCostCategoryPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleRuleOrCostCategoryProperty | undefined;
        set internalValue(value: RuleRuleOrCostCategoryProperty | undefined);
        get key(): string;
        get matchOptions(): string[];
        get values(): string[];
    }
    class RuleRuleOrCostCategoryPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleRuleOrCostCategoryPropertyOutputReference;
    }
    interface RuleRuleOrDimensionProperty {
    }
    class RuleRuleOrDimensionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleRuleOrDimensionProperty | undefined;
        set internalValue(value: RuleRuleOrDimensionProperty | undefined);
        get key(): string;
        get matchOptions(): string[];
        get values(): string[];
    }
    class RuleRuleOrDimensionPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleRuleOrDimensionPropertyOutputReference;
    }
    interface RuleRuleOrNotCostCategoryProperty {
    }
    class RuleRuleOrNotCostCategoryPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleRuleOrNotCostCategoryProperty | undefined;
        set internalValue(value: RuleRuleOrNotCostCategoryProperty | undefined);
        get key(): string;
        get matchOptions(): string[];
        get values(): string[];
    }
    class RuleRuleOrNotCostCategoryPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleRuleOrNotCostCategoryPropertyOutputReference;
    }
    interface RuleRuleOrNotDimensionProperty {
    }
    class RuleRuleOrNotDimensionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleRuleOrNotDimensionProperty | undefined;
        set internalValue(value: RuleRuleOrNotDimensionProperty | undefined);
        get key(): string;
        get matchOptions(): string[];
        get values(): string[];
    }
    class RuleRuleOrNotDimensionPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleRuleOrNotDimensionPropertyOutputReference;
    }
    interface RuleRuleOrNotTagsProperty {
    }
    class RuleRuleOrNotTagsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleRuleOrNotTagsProperty | undefined;
        set internalValue(value: RuleRuleOrNotTagsProperty | undefined);
        get key(): string;
        get matchOptions(): string[];
        get values(): string[];
    }
    class RuleRuleOrNotTagsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleRuleOrNotTagsPropertyOutputReference;
    }
    interface RuleRuleOrNotProperty {
    }
    class RuleRuleOrNotPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleRuleOrNotProperty | undefined;
        set internalValue(value: RuleRuleOrNotProperty | undefined);
        private _costCategory;
        get costCategory(): RuleRuleOrNotCostCategoryPropertyList;
        private _dimension;
        get dimension(): RuleRuleOrNotDimensionPropertyList;
        private _tags;
        get tags(): RuleRuleOrNotTagsPropertyList;
    }
    class RuleRuleOrNotPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleRuleOrNotPropertyOutputReference;
    }
    interface RuleRuleOrOrCostCategoryProperty {
    }
    class RuleRuleOrOrCostCategoryPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleRuleOrOrCostCategoryProperty | undefined;
        set internalValue(value: RuleRuleOrOrCostCategoryProperty | undefined);
        get key(): string;
        get matchOptions(): string[];
        get values(): string[];
    }
    class RuleRuleOrOrCostCategoryPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleRuleOrOrCostCategoryPropertyOutputReference;
    }
    interface RuleRuleOrOrDimensionProperty {
    }
    class RuleRuleOrOrDimensionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleRuleOrOrDimensionProperty | undefined;
        set internalValue(value: RuleRuleOrOrDimensionProperty | undefined);
        get key(): string;
        get matchOptions(): string[];
        get values(): string[];
    }
    class RuleRuleOrOrDimensionPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleRuleOrOrDimensionPropertyOutputReference;
    }
    interface RuleRuleOrOrTagsProperty {
    }
    class RuleRuleOrOrTagsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleRuleOrOrTagsProperty | undefined;
        set internalValue(value: RuleRuleOrOrTagsProperty | undefined);
        get key(): string;
        get matchOptions(): string[];
        get values(): string[];
    }
    class RuleRuleOrOrTagsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleRuleOrOrTagsPropertyOutputReference;
    }
    interface RuleRuleOrOrProperty {
    }
    class RuleRuleOrOrPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleRuleOrOrProperty | undefined;
        set internalValue(value: RuleRuleOrOrProperty | undefined);
        private _costCategory;
        get costCategory(): RuleRuleOrOrCostCategoryPropertyList;
        private _dimension;
        get dimension(): RuleRuleOrOrDimensionPropertyList;
        private _tags;
        get tags(): RuleRuleOrOrTagsPropertyList;
    }
    class RuleRuleOrOrPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleRuleOrOrPropertyOutputReference;
    }
    interface RuleRuleOrTagsProperty {
    }
    class RuleRuleOrTagsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleRuleOrTagsProperty | undefined;
        set internalValue(value: RuleRuleOrTagsProperty | undefined);
        get key(): string;
        get matchOptions(): string[];
        get values(): string[];
    }
    class RuleRuleOrTagsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleRuleOrTagsPropertyOutputReference;
    }
    interface RuleRuleOrProperty {
    }
    class RuleRuleOrPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleRuleOrProperty | undefined;
        set internalValue(value: RuleRuleOrProperty | undefined);
        private _and;
        get and(): RuleRuleOrAndPropertyList;
        private _costCategory;
        get costCategory(): RuleRuleOrCostCategoryPropertyList;
        private _dimension;
        get dimension(): RuleRuleOrDimensionPropertyList;
        private _not;
        get not(): RuleRuleOrNotPropertyList;
        private _or;
        get or(): RuleRuleOrOrPropertyList;
        private _tags;
        get tags(): RuleRuleOrTagsPropertyList;
    }
    class RuleRuleOrPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleRuleOrPropertyOutputReference;
    }
    interface RuleRuleTagsProperty {
    }
    class RuleRuleTagsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleRuleTagsProperty | undefined;
        set internalValue(value: RuleRuleTagsProperty | undefined);
        get key(): string;
        get matchOptions(): string[];
        get values(): string[];
    }
    class RuleRuleTagsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleRuleTagsPropertyOutputReference;
    }
    interface RuleRuleProperty {
    }
    class RuleRulePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleRuleProperty | undefined;
        set internalValue(value: RuleRuleProperty | undefined);
        private _and;
        get and(): RuleRuleAndPropertyList;
        private _costCategory;
        get costCategory(): RuleRuleCostCategoryPropertyList;
        private _dimension;
        get dimension(): RuleRuleDimensionPropertyList;
        private _not;
        get not(): RuleRuleNotPropertyList;
        private _or;
        get or(): RuleRuleOrPropertyList;
        private _tags;
        get tags(): RuleRuleTagsPropertyList;
    }
    class RuleRulePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleRulePropertyOutputReference;
    }
    interface RuleProperty {
    }
    class RulePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleProperty | undefined;
        set internalValue(value: RuleProperty | undefined);
        private _inheritedValue;
        get inheritedValue(): InheritedValuePropertyList;
        private _rule;
        get rule(): RuleRulePropertyList;
        get type(): string;
        get value(): string;
    }
    class RulePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RulePropertyOutputReference;
    }
    interface ParameterProperty {
    }
    class ParameterPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ParameterProperty | undefined;
        set internalValue(value: ParameterProperty | undefined);
        get type(): string;
        get values(): string[];
    }
    class ParameterPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ParameterPropertyOutputReference;
    }
    interface SplitChargeRuleProperty {
    }
    class SplitChargeRulePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SplitChargeRuleProperty | undefined;
        set internalValue(value: SplitChargeRuleProperty | undefined);
        get method(): string;
        private _parameter;
        get parameter(): ParameterPropertyList;
        get source(): string;
        get targets(): string[];
    }
    class SplitChargeRulePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SplitChargeRulePropertyOutputReference;
    }
}
