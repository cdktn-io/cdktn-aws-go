import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataTfTagsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#id DataTfTags#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#search_string DataTfTags#search_string}
    */
    readonly searchString?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#tag_key DataTfTags#tag_key}
    */
    readonly tagKey?: string;
    /**
    * filter block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#filter DataTfTags#filter}
    */
    readonly filter?: DataTfTags.FilterProperty;
    /**
    * sort_by block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#sort_by DataTfTags#sort_by}
    */
    readonly sortBy?: DataTfTags.SortByProperty[] | cdktn.IResolvable;
    /**
    * time_period block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#time_period DataTfTags#time_period}
    */
    readonly timePeriod: DataTfTags.TimePeriodProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags aws_ce_tags}
*/
export declare class DataTfTags extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_ce_tags";
    /**
    * Generates CDKTN code for importing a DataTfTags resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataTfTags to import
    * @param importFromId The id of the existing DataTfTags that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataTfTags to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags aws_ce_tags} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataTfTagsConfig
    */
    constructor(scope: Construct, id: string, config: DataTfTagsConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _searchString?;
    get searchString(): string;
    set searchString(value: string);
    resetSearchString(): void;
    get searchStringInput(): string | undefined;
    private _tagKey?;
    get tagKey(): string;
    set tagKey(value: string);
    resetTagKey(): void;
    get tagKeyInput(): string | undefined;
    get tags(): string[];
    private _filter;
    get filter(): DataTfTags.FilterPropertyOutputReference;
    putFilter(value: DataTfTags.FilterProperty): void;
    resetFilter(): void;
    get filterInput(): DataTfTags.FilterProperty | undefined;
    private _sortBy;
    get sortBy(): DataTfTags.SortByPropertyList;
    putSortBy(value: DataTfTags.SortByProperty[] | cdktn.IResolvable): void;
    resetSortBy(): void;
    get sortByInput(): cdktn.IResolvable | DataTfTags.SortByProperty[] | undefined;
    private _timePeriod;
    get timePeriod(): DataTfTags.TimePeriodPropertyOutputReference;
    putTimePeriod(value: DataTfTags.TimePeriodProperty): void;
    get timePeriodInput(): DataTfTags.TimePeriodProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataTfTagsFilterAndCostCategoryPropertyToTerraform(struct?: DataTfTags.FilterAndCostCategoryPropertyOutputReference | DataTfTags.FilterAndCostCategoryProperty): any;
export declare function dataTfTagsFilterAndCostCategoryPropertyToHclTerraform(struct?: DataTfTags.FilterAndCostCategoryPropertyOutputReference | DataTfTags.FilterAndCostCategoryProperty): any;
export declare function dataTfTagsFilterAndDimensionPropertyToTerraform(struct?: DataTfTags.FilterAndDimensionPropertyOutputReference | DataTfTags.FilterAndDimensionProperty): any;
export declare function dataTfTagsFilterAndDimensionPropertyToHclTerraform(struct?: DataTfTags.FilterAndDimensionPropertyOutputReference | DataTfTags.FilterAndDimensionProperty): any;
export declare function dataTfTagsFilterAndTagsPropertyToTerraform(struct?: DataTfTags.FilterAndTagsPropertyOutputReference | DataTfTags.FilterAndTagsProperty): any;
export declare function dataTfTagsFilterAndTagsPropertyToHclTerraform(struct?: DataTfTags.FilterAndTagsPropertyOutputReference | DataTfTags.FilterAndTagsProperty): any;
export declare function dataTfTagsAndPropertyToTerraform(struct?: DataTfTags.AndProperty | cdktn.IResolvable): any;
export declare function dataTfTagsAndPropertyToHclTerraform(struct?: DataTfTags.AndProperty | cdktn.IResolvable): any;
export declare function dataTfTagsFilterCostCategoryPropertyToTerraform(struct?: DataTfTags.FilterCostCategoryPropertyOutputReference | DataTfTags.FilterCostCategoryProperty): any;
export declare function dataTfTagsFilterCostCategoryPropertyToHclTerraform(struct?: DataTfTags.FilterCostCategoryPropertyOutputReference | DataTfTags.FilterCostCategoryProperty): any;
export declare function dataTfTagsFilterDimensionPropertyToTerraform(struct?: DataTfTags.FilterDimensionPropertyOutputReference | DataTfTags.FilterDimensionProperty): any;
export declare function dataTfTagsFilterDimensionPropertyToHclTerraform(struct?: DataTfTags.FilterDimensionPropertyOutputReference | DataTfTags.FilterDimensionProperty): any;
export declare function dataTfTagsFilterNotCostCategoryPropertyToTerraform(struct?: DataTfTags.FilterNotCostCategoryPropertyOutputReference | DataTfTags.FilterNotCostCategoryProperty): any;
export declare function dataTfTagsFilterNotCostCategoryPropertyToHclTerraform(struct?: DataTfTags.FilterNotCostCategoryPropertyOutputReference | DataTfTags.FilterNotCostCategoryProperty): any;
export declare function dataTfTagsFilterNotDimensionPropertyToTerraform(struct?: DataTfTags.FilterNotDimensionPropertyOutputReference | DataTfTags.FilterNotDimensionProperty): any;
export declare function dataTfTagsFilterNotDimensionPropertyToHclTerraform(struct?: DataTfTags.FilterNotDimensionPropertyOutputReference | DataTfTags.FilterNotDimensionProperty): any;
export declare function dataTfTagsFilterNotTagsPropertyToTerraform(struct?: DataTfTags.FilterNotTagsPropertyOutputReference | DataTfTags.FilterNotTagsProperty): any;
export declare function dataTfTagsFilterNotTagsPropertyToHclTerraform(struct?: DataTfTags.FilterNotTagsPropertyOutputReference | DataTfTags.FilterNotTagsProperty): any;
export declare function dataTfTagsNotPropertyToTerraform(struct?: DataTfTags.NotPropertyOutputReference | DataTfTags.NotProperty): any;
export declare function dataTfTagsNotPropertyToHclTerraform(struct?: DataTfTags.NotPropertyOutputReference | DataTfTags.NotProperty): any;
export declare function dataTfTagsFilterOrCostCategoryPropertyToTerraform(struct?: DataTfTags.FilterOrCostCategoryPropertyOutputReference | DataTfTags.FilterOrCostCategoryProperty): any;
export declare function dataTfTagsFilterOrCostCategoryPropertyToHclTerraform(struct?: DataTfTags.FilterOrCostCategoryPropertyOutputReference | DataTfTags.FilterOrCostCategoryProperty): any;
export declare function dataTfTagsFilterOrDimensionPropertyToTerraform(struct?: DataTfTags.FilterOrDimensionPropertyOutputReference | DataTfTags.FilterOrDimensionProperty): any;
export declare function dataTfTagsFilterOrDimensionPropertyToHclTerraform(struct?: DataTfTags.FilterOrDimensionPropertyOutputReference | DataTfTags.FilterOrDimensionProperty): any;
export declare function dataTfTagsFilterOrTagsPropertyToTerraform(struct?: DataTfTags.FilterOrTagsPropertyOutputReference | DataTfTags.FilterOrTagsProperty): any;
export declare function dataTfTagsFilterOrTagsPropertyToHclTerraform(struct?: DataTfTags.FilterOrTagsPropertyOutputReference | DataTfTags.FilterOrTagsProperty): any;
export declare function dataTfTagsOrPropertyToTerraform(struct?: DataTfTags.OrProperty | cdktn.IResolvable): any;
export declare function dataTfTagsOrPropertyToHclTerraform(struct?: DataTfTags.OrProperty | cdktn.IResolvable): any;
export declare function dataTfTagsFilterTagsPropertyToTerraform(struct?: DataTfTags.FilterTagsPropertyOutputReference | DataTfTags.FilterTagsProperty): any;
export declare function dataTfTagsFilterTagsPropertyToHclTerraform(struct?: DataTfTags.FilterTagsPropertyOutputReference | DataTfTags.FilterTagsProperty): any;
export declare function dataTfTagsFilterPropertyToTerraform(struct?: DataTfTags.FilterPropertyOutputReference | DataTfTags.FilterProperty): any;
export declare function dataTfTagsFilterPropertyToHclTerraform(struct?: DataTfTags.FilterPropertyOutputReference | DataTfTags.FilterProperty): any;
export declare function dataTfTagsSortByPropertyToTerraform(struct?: DataTfTags.SortByProperty | cdktn.IResolvable): any;
export declare function dataTfTagsSortByPropertyToHclTerraform(struct?: DataTfTags.SortByProperty | cdktn.IResolvable): any;
export declare function dataTfTagsTimePeriodPropertyToTerraform(struct?: DataTfTags.TimePeriodPropertyOutputReference | DataTfTags.TimePeriodProperty): any;
export declare function dataTfTagsTimePeriodPropertyToHclTerraform(struct?: DataTfTags.TimePeriodPropertyOutputReference | DataTfTags.TimePeriodProperty): any;
export declare namespace DataTfTags {
    interface FilterAndCostCategoryProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#key DataTfTags#key}
        */
        readonly key?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#match_options DataTfTags#match_options}
        */
        readonly matchOptions?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#values DataTfTags#values}
        */
        readonly values?: string[];
    }
    class FilterAndCostCategoryPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): FilterAndCostCategoryProperty | undefined;
        set internalValue(value: FilterAndCostCategoryProperty | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        resetKey(): void;
        get keyInput(): string | undefined;
        private _matchOptions?;
        get matchOptions(): string[];
        set matchOptions(value: string[]);
        resetMatchOptions(): void;
        get matchOptionsInput(): string[] | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        resetValues(): void;
        get valuesInput(): string[] | undefined;
    }
    interface FilterAndDimensionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#key DataTfTags#key}
        */
        readonly key?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#match_options DataTfTags#match_options}
        */
        readonly matchOptions?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#values DataTfTags#values}
        */
        readonly values?: string[];
    }
    class FilterAndDimensionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): FilterAndDimensionProperty | undefined;
        set internalValue(value: FilterAndDimensionProperty | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        resetKey(): void;
        get keyInput(): string | undefined;
        private _matchOptions?;
        get matchOptions(): string[];
        set matchOptions(value: string[]);
        resetMatchOptions(): void;
        get matchOptionsInput(): string[] | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        resetValues(): void;
        get valuesInput(): string[] | undefined;
    }
    interface FilterAndTagsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#key DataTfTags#key}
        */
        readonly key?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#match_options DataTfTags#match_options}
        */
        readonly matchOptions?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#values DataTfTags#values}
        */
        readonly values?: string[];
    }
    class FilterAndTagsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): FilterAndTagsProperty | undefined;
        set internalValue(value: FilterAndTagsProperty | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        resetKey(): void;
        get keyInput(): string | undefined;
        private _matchOptions?;
        get matchOptions(): string[];
        set matchOptions(value: string[]);
        resetMatchOptions(): void;
        get matchOptionsInput(): string[] | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        resetValues(): void;
        get valuesInput(): string[] | undefined;
    }
    interface AndProperty {
        /**
        * cost_category block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#cost_category DataTfTags#cost_category}
        */
        readonly costCategory?: FilterAndCostCategoryProperty;
        /**
        * dimension block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#dimension DataTfTags#dimension}
        */
        readonly dimension?: FilterAndDimensionProperty;
        /**
        * tags block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#tags DataTfTags#tags}
        */
        readonly tags?: FilterAndTagsProperty;
    }
    class AndPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AndProperty | cdktn.IResolvable | undefined;
        set internalValue(value: AndProperty | cdktn.IResolvable | undefined);
        private _costCategory;
        get costCategory(): FilterAndCostCategoryPropertyOutputReference;
        putCostCategory(value: FilterAndCostCategoryProperty): void;
        resetCostCategory(): void;
        get costCategoryInput(): FilterAndCostCategoryProperty | undefined;
        private _dimension;
        get dimension(): FilterAndDimensionPropertyOutputReference;
        putDimension(value: FilterAndDimensionProperty): void;
        resetDimension(): void;
        get dimensionInput(): FilterAndDimensionProperty | undefined;
        private _tags;
        get tags(): FilterAndTagsPropertyOutputReference;
        putTags(value: FilterAndTagsProperty): void;
        resetTags(): void;
        get tagsInput(): FilterAndTagsProperty | undefined;
    }
    class AndPropertyList extends cdktn.ComplexList {
        internalValue?: AndProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AndPropertyOutputReference;
    }
    interface FilterCostCategoryProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#key DataTfTags#key}
        */
        readonly key?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#match_options DataTfTags#match_options}
        */
        readonly matchOptions?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#values DataTfTags#values}
        */
        readonly values?: string[];
    }
    class FilterCostCategoryPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): FilterCostCategoryProperty | undefined;
        set internalValue(value: FilterCostCategoryProperty | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        resetKey(): void;
        get keyInput(): string | undefined;
        private _matchOptions?;
        get matchOptions(): string[];
        set matchOptions(value: string[]);
        resetMatchOptions(): void;
        get matchOptionsInput(): string[] | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        resetValues(): void;
        get valuesInput(): string[] | undefined;
    }
    interface FilterDimensionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#key DataTfTags#key}
        */
        readonly key?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#match_options DataTfTags#match_options}
        */
        readonly matchOptions?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#values DataTfTags#values}
        */
        readonly values?: string[];
    }
    class FilterDimensionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): FilterDimensionProperty | undefined;
        set internalValue(value: FilterDimensionProperty | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        resetKey(): void;
        get keyInput(): string | undefined;
        private _matchOptions?;
        get matchOptions(): string[];
        set matchOptions(value: string[]);
        resetMatchOptions(): void;
        get matchOptionsInput(): string[] | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        resetValues(): void;
        get valuesInput(): string[] | undefined;
    }
    interface FilterNotCostCategoryProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#key DataTfTags#key}
        */
        readonly key?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#match_options DataTfTags#match_options}
        */
        readonly matchOptions?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#values DataTfTags#values}
        */
        readonly values?: string[];
    }
    class FilterNotCostCategoryPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): FilterNotCostCategoryProperty | undefined;
        set internalValue(value: FilterNotCostCategoryProperty | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        resetKey(): void;
        get keyInput(): string | undefined;
        private _matchOptions?;
        get matchOptions(): string[];
        set matchOptions(value: string[]);
        resetMatchOptions(): void;
        get matchOptionsInput(): string[] | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        resetValues(): void;
        get valuesInput(): string[] | undefined;
    }
    interface FilterNotDimensionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#key DataTfTags#key}
        */
        readonly key?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#match_options DataTfTags#match_options}
        */
        readonly matchOptions?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#values DataTfTags#values}
        */
        readonly values?: string[];
    }
    class FilterNotDimensionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): FilterNotDimensionProperty | undefined;
        set internalValue(value: FilterNotDimensionProperty | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        resetKey(): void;
        get keyInput(): string | undefined;
        private _matchOptions?;
        get matchOptions(): string[];
        set matchOptions(value: string[]);
        resetMatchOptions(): void;
        get matchOptionsInput(): string[] | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        resetValues(): void;
        get valuesInput(): string[] | undefined;
    }
    interface FilterNotTagsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#key DataTfTags#key}
        */
        readonly key?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#match_options DataTfTags#match_options}
        */
        readonly matchOptions?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#values DataTfTags#values}
        */
        readonly values?: string[];
    }
    class FilterNotTagsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): FilterNotTagsProperty | undefined;
        set internalValue(value: FilterNotTagsProperty | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        resetKey(): void;
        get keyInput(): string | undefined;
        private _matchOptions?;
        get matchOptions(): string[];
        set matchOptions(value: string[]);
        resetMatchOptions(): void;
        get matchOptionsInput(): string[] | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        resetValues(): void;
        get valuesInput(): string[] | undefined;
    }
    interface NotProperty {
        /**
        * cost_category block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#cost_category DataTfTags#cost_category}
        */
        readonly costCategory?: FilterNotCostCategoryProperty;
        /**
        * dimension block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#dimension DataTfTags#dimension}
        */
        readonly dimension?: FilterNotDimensionProperty;
        /**
        * tags block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#tags DataTfTags#tags}
        */
        readonly tags?: FilterNotTagsProperty;
    }
    class NotPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): NotProperty | undefined;
        set internalValue(value: NotProperty | undefined);
        private _costCategory;
        get costCategory(): FilterNotCostCategoryPropertyOutputReference;
        putCostCategory(value: FilterNotCostCategoryProperty): void;
        resetCostCategory(): void;
        get costCategoryInput(): FilterNotCostCategoryProperty | undefined;
        private _dimension;
        get dimension(): FilterNotDimensionPropertyOutputReference;
        putDimension(value: FilterNotDimensionProperty): void;
        resetDimension(): void;
        get dimensionInput(): FilterNotDimensionProperty | undefined;
        private _tags;
        get tags(): FilterNotTagsPropertyOutputReference;
        putTags(value: FilterNotTagsProperty): void;
        resetTags(): void;
        get tagsInput(): FilterNotTagsProperty | undefined;
    }
    interface FilterOrCostCategoryProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#key DataTfTags#key}
        */
        readonly key?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#match_options DataTfTags#match_options}
        */
        readonly matchOptions?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#values DataTfTags#values}
        */
        readonly values?: string[];
    }
    class FilterOrCostCategoryPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): FilterOrCostCategoryProperty | undefined;
        set internalValue(value: FilterOrCostCategoryProperty | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        resetKey(): void;
        get keyInput(): string | undefined;
        private _matchOptions?;
        get matchOptions(): string[];
        set matchOptions(value: string[]);
        resetMatchOptions(): void;
        get matchOptionsInput(): string[] | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        resetValues(): void;
        get valuesInput(): string[] | undefined;
    }
    interface FilterOrDimensionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#key DataTfTags#key}
        */
        readonly key?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#match_options DataTfTags#match_options}
        */
        readonly matchOptions?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#values DataTfTags#values}
        */
        readonly values?: string[];
    }
    class FilterOrDimensionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): FilterOrDimensionProperty | undefined;
        set internalValue(value: FilterOrDimensionProperty | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        resetKey(): void;
        get keyInput(): string | undefined;
        private _matchOptions?;
        get matchOptions(): string[];
        set matchOptions(value: string[]);
        resetMatchOptions(): void;
        get matchOptionsInput(): string[] | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        resetValues(): void;
        get valuesInput(): string[] | undefined;
    }
    interface FilterOrTagsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#key DataTfTags#key}
        */
        readonly key?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#match_options DataTfTags#match_options}
        */
        readonly matchOptions?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#values DataTfTags#values}
        */
        readonly values?: string[];
    }
    class FilterOrTagsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): FilterOrTagsProperty | undefined;
        set internalValue(value: FilterOrTagsProperty | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        resetKey(): void;
        get keyInput(): string | undefined;
        private _matchOptions?;
        get matchOptions(): string[];
        set matchOptions(value: string[]);
        resetMatchOptions(): void;
        get matchOptionsInput(): string[] | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        resetValues(): void;
        get valuesInput(): string[] | undefined;
    }
    interface OrProperty {
        /**
        * cost_category block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#cost_category DataTfTags#cost_category}
        */
        readonly costCategory?: FilterOrCostCategoryProperty;
        /**
        * dimension block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#dimension DataTfTags#dimension}
        */
        readonly dimension?: FilterOrDimensionProperty;
        /**
        * tags block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#tags DataTfTags#tags}
        */
        readonly tags?: FilterOrTagsProperty;
    }
    class OrPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): OrProperty | cdktn.IResolvable | undefined;
        set internalValue(value: OrProperty | cdktn.IResolvable | undefined);
        private _costCategory;
        get costCategory(): FilterOrCostCategoryPropertyOutputReference;
        putCostCategory(value: FilterOrCostCategoryProperty): void;
        resetCostCategory(): void;
        get costCategoryInput(): FilterOrCostCategoryProperty | undefined;
        private _dimension;
        get dimension(): FilterOrDimensionPropertyOutputReference;
        putDimension(value: FilterOrDimensionProperty): void;
        resetDimension(): void;
        get dimensionInput(): FilterOrDimensionProperty | undefined;
        private _tags;
        get tags(): FilterOrTagsPropertyOutputReference;
        putTags(value: FilterOrTagsProperty): void;
        resetTags(): void;
        get tagsInput(): FilterOrTagsProperty | undefined;
    }
    class OrPropertyList extends cdktn.ComplexList {
        internalValue?: OrProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): OrPropertyOutputReference;
    }
    interface FilterTagsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#key DataTfTags#key}
        */
        readonly key?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#match_options DataTfTags#match_options}
        */
        readonly matchOptions?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#values DataTfTags#values}
        */
        readonly values?: string[];
    }
    class FilterTagsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): FilterTagsProperty | undefined;
        set internalValue(value: FilterTagsProperty | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        resetKey(): void;
        get keyInput(): string | undefined;
        private _matchOptions?;
        get matchOptions(): string[];
        set matchOptions(value: string[]);
        resetMatchOptions(): void;
        get matchOptionsInput(): string[] | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        resetValues(): void;
        get valuesInput(): string[] | undefined;
    }
    interface FilterProperty {
        /**
        * and block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#and DataTfTags#and}
        */
        readonly and?: AndProperty[] | cdktn.IResolvable;
        /**
        * cost_category block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#cost_category DataTfTags#cost_category}
        */
        readonly costCategory?: FilterCostCategoryProperty;
        /**
        * dimension block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#dimension DataTfTags#dimension}
        */
        readonly dimension?: FilterDimensionProperty;
        /**
        * not block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#not DataTfTags#not}
        */
        readonly not?: NotProperty;
        /**
        * or block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#or DataTfTags#or}
        */
        readonly or?: OrProperty[] | cdktn.IResolvable;
        /**
        * tags block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#tags DataTfTags#tags}
        */
        readonly tags?: FilterTagsProperty;
    }
    class FilterPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): FilterProperty | undefined;
        set internalValue(value: FilterProperty | undefined);
        private _and;
        get and(): AndPropertyList;
        putAnd(value: AndProperty[] | cdktn.IResolvable): void;
        resetAnd(): void;
        get andInput(): cdktn.IResolvable | AndProperty[] | undefined;
        private _costCategory;
        get costCategory(): FilterCostCategoryPropertyOutputReference;
        putCostCategory(value: FilterCostCategoryProperty): void;
        resetCostCategory(): void;
        get costCategoryInput(): FilterCostCategoryProperty | undefined;
        private _dimension;
        get dimension(): FilterDimensionPropertyOutputReference;
        putDimension(value: FilterDimensionProperty): void;
        resetDimension(): void;
        get dimensionInput(): FilterDimensionProperty | undefined;
        private _not;
        get not(): NotPropertyOutputReference;
        putNot(value: NotProperty): void;
        resetNot(): void;
        get notInput(): NotProperty | undefined;
        private _or;
        get or(): OrPropertyList;
        putOr(value: OrProperty[] | cdktn.IResolvable): void;
        resetOr(): void;
        get orInput(): cdktn.IResolvable | OrProperty[] | undefined;
        private _tags;
        get tags(): FilterTagsPropertyOutputReference;
        putTags(value: FilterTagsProperty): void;
        resetTags(): void;
        get tagsInput(): FilterTagsProperty | undefined;
    }
    interface SortByProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#key DataTfTags#key}
        */
        readonly key?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#sort_order DataTfTags#sort_order}
        */
        readonly sortOrder?: string;
    }
    class SortByPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SortByProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SortByProperty | cdktn.IResolvable | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        resetKey(): void;
        get keyInput(): string | undefined;
        private _sortOrder?;
        get sortOrder(): string;
        set sortOrder(value: string);
        resetSortOrder(): void;
        get sortOrderInput(): string | undefined;
    }
    class SortByPropertyList extends cdktn.ComplexList {
        internalValue?: SortByProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SortByPropertyOutputReference;
    }
    interface TimePeriodProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#end DataTfTags#end}
        */
        readonly end: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#start DataTfTags#start}
        */
        readonly start: string;
    }
    class TimePeriodPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimePeriodProperty | undefined;
        set internalValue(value: TimePeriodProperty | undefined);
        private _end?;
        get end(): string;
        set end(value: string);
        get endInput(): string | undefined;
        private _start?;
        get start(): string;
        set start(value: string);
        get startInput(): string | undefined;
    }
}
