import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsScheduledActionConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/redshift_scheduled_action#description AwsScheduledAction#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/redshift_scheduled_action#enable AwsScheduledAction#enable}
    */
    readonly enable?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/redshift_scheduled_action#end_time AwsScheduledAction#end_time}
    */
    readonly endTime?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/redshift_scheduled_action#iam_role AwsScheduledAction#iam_role}
    */
    readonly iamRole: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/redshift_scheduled_action#id AwsScheduledAction#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/redshift_scheduled_action#name AwsScheduledAction#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/redshift_scheduled_action#region AwsScheduledAction#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/redshift_scheduled_action#schedule AwsScheduledAction#schedule}
    */
    readonly schedule: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/redshift_scheduled_action#start_time AwsScheduledAction#start_time}
    */
    readonly startTime?: string;
    /**
    * target_action block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/redshift_scheduled_action#target_action AwsScheduledAction#target_action}
    */
    readonly targetAction: AwsScheduledAction.TargetActionProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/redshift_scheduled_action aws_redshift_scheduled_action}
*/
export declare class AwsScheduledAction extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_redshift_scheduled_action";
    /**
    * Generates CDKTN code for importing a AwsScheduledAction resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsScheduledAction to import
    * @param importFromId The id of the existing AwsScheduledAction that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/redshift_scheduled_action#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsScheduledAction to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/redshift_scheduled_action aws_redshift_scheduled_action} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsScheduledActionConfig
    */
    constructor(scope: Construct, id: string, config: AwsScheduledActionConfig);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _enable?;
    get enable(): boolean | cdktn.IResolvable;
    set enable(value: boolean | cdktn.IResolvable);
    resetEnable(): void;
    get enableInput(): boolean | cdktn.IResolvable | undefined;
    private _endTime?;
    get endTime(): string;
    set endTime(value: string);
    resetEndTime(): void;
    get endTimeInput(): string | undefined;
    private _iamRole?;
    get iamRole(): string;
    set iamRole(value: string);
    get iamRoleInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _schedule?;
    get schedule(): string;
    set schedule(value: string);
    get scheduleInput(): string | undefined;
    private _startTime?;
    get startTime(): string;
    set startTime(value: string);
    resetStartTime(): void;
    get startTimeInput(): string | undefined;
    private _targetAction;
    get targetAction(): AwsScheduledAction.TargetActionPropertyOutputReference;
    putTargetAction(value: AwsScheduledAction.TargetActionProperty): void;
    get targetActionInput(): AwsScheduledAction.TargetActionProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsScheduledActionPauseClusterPropertyToTerraform(struct?: AwsScheduledAction.PauseClusterPropertyOutputReference | AwsScheduledAction.PauseClusterProperty): any;
export declare function awsScheduledActionPauseClusterPropertyToHclTerraform(struct?: AwsScheduledAction.PauseClusterPropertyOutputReference | AwsScheduledAction.PauseClusterProperty): any;
export declare function awsScheduledActionResizeClusterPropertyToTerraform(struct?: AwsScheduledAction.ResizeClusterPropertyOutputReference | AwsScheduledAction.ResizeClusterProperty): any;
export declare function awsScheduledActionResizeClusterPropertyToHclTerraform(struct?: AwsScheduledAction.ResizeClusterPropertyOutputReference | AwsScheduledAction.ResizeClusterProperty): any;
export declare function awsScheduledActionResumeClusterPropertyToTerraform(struct?: AwsScheduledAction.ResumeClusterPropertyOutputReference | AwsScheduledAction.ResumeClusterProperty): any;
export declare function awsScheduledActionResumeClusterPropertyToHclTerraform(struct?: AwsScheduledAction.ResumeClusterPropertyOutputReference | AwsScheduledAction.ResumeClusterProperty): any;
export declare function awsScheduledActionTargetActionPropertyToTerraform(struct?: AwsScheduledAction.TargetActionPropertyOutputReference | AwsScheduledAction.TargetActionProperty): any;
export declare function awsScheduledActionTargetActionPropertyToHclTerraform(struct?: AwsScheduledAction.TargetActionPropertyOutputReference | AwsScheduledAction.TargetActionProperty): any;
export declare namespace AwsScheduledAction {
    interface PauseClusterProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/redshift_scheduled_action#cluster_identifier AwsScheduledAction#cluster_identifier}
        */
        readonly clusterIdentifier: string;
    }
    class PauseClusterPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): PauseClusterProperty | undefined;
        set internalValue(value: PauseClusterProperty | undefined);
        private _clusterIdentifier?;
        get clusterIdentifier(): string;
        set clusterIdentifier(value: string);
        get clusterIdentifierInput(): string | undefined;
    }
    interface ResizeClusterProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/redshift_scheduled_action#classic AwsScheduledAction#classic}
        */
        readonly classic?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/redshift_scheduled_action#cluster_identifier AwsScheduledAction#cluster_identifier}
        */
        readonly clusterIdentifier: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/redshift_scheduled_action#cluster_type AwsScheduledAction#cluster_type}
        */
        readonly clusterType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/redshift_scheduled_action#node_type AwsScheduledAction#node_type}
        */
        readonly nodeType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/redshift_scheduled_action#number_of_nodes AwsScheduledAction#number_of_nodes}
        */
        readonly numberOfNodes?: number;
    }
    class ResizeClusterPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ResizeClusterProperty | undefined;
        set internalValue(value: ResizeClusterProperty | undefined);
        private _classic?;
        get classic(): boolean | cdktn.IResolvable;
        set classic(value: boolean | cdktn.IResolvable);
        resetClassic(): void;
        get classicInput(): boolean | cdktn.IResolvable | undefined;
        private _clusterIdentifier?;
        get clusterIdentifier(): string;
        set clusterIdentifier(value: string);
        get clusterIdentifierInput(): string | undefined;
        private _clusterType?;
        get clusterType(): string;
        set clusterType(value: string);
        resetClusterType(): void;
        get clusterTypeInput(): string | undefined;
        private _nodeType?;
        get nodeType(): string;
        set nodeType(value: string);
        resetNodeType(): void;
        get nodeTypeInput(): string | undefined;
        private _numberOfNodes?;
        get numberOfNodes(): number;
        set numberOfNodes(value: number);
        resetNumberOfNodes(): void;
        get numberOfNodesInput(): number | undefined;
    }
    interface ResumeClusterProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/redshift_scheduled_action#cluster_identifier AwsScheduledAction#cluster_identifier}
        */
        readonly clusterIdentifier: string;
    }
    class ResumeClusterPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ResumeClusterProperty | undefined;
        set internalValue(value: ResumeClusterProperty | undefined);
        private _clusterIdentifier?;
        get clusterIdentifier(): string;
        set clusterIdentifier(value: string);
        get clusterIdentifierInput(): string | undefined;
    }
    interface TargetActionProperty {
        /**
        * pause_cluster block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/redshift_scheduled_action#pause_cluster AwsScheduledAction#pause_cluster}
        */
        readonly pauseCluster?: PauseClusterProperty;
        /**
        * resize_cluster block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/redshift_scheduled_action#resize_cluster AwsScheduledAction#resize_cluster}
        */
        readonly resizeCluster?: ResizeClusterProperty;
        /**
        * resume_cluster block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/redshift_scheduled_action#resume_cluster AwsScheduledAction#resume_cluster}
        */
        readonly resumeCluster?: ResumeClusterProperty;
    }
    class TargetActionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TargetActionProperty | undefined;
        set internalValue(value: TargetActionProperty | undefined);
        private _pauseCluster;
        get pauseCluster(): PauseClusterPropertyOutputReference;
        putPauseCluster(value: PauseClusterProperty): void;
        resetPauseCluster(): void;
        get pauseClusterInput(): PauseClusterProperty | undefined;
        private _resizeCluster;
        get resizeCluster(): ResizeClusterPropertyOutputReference;
        putResizeCluster(value: ResizeClusterProperty): void;
        resetResizeCluster(): void;
        get resizeClusterInput(): ResizeClusterProperty | undefined;
        private _resumeCluster;
        get resumeCluster(): ResumeClusterPropertyOutputReference;
        putResumeCluster(value: ResumeClusterProperty): void;
        resetResumeCluster(): void;
        get resumeClusterInput(): ResumeClusterProperty | undefined;
    }
}
