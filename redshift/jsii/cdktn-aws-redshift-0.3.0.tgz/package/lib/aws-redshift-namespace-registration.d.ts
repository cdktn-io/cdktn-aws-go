import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsNamespaceRegistrationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/redshift_namespace_registration#consumer_identifier AwsNamespaceRegistration#consumer_identifier}
    */
    readonly consumerIdentifier: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/redshift_namespace_registration#namespace_type AwsNamespaceRegistration#namespace_type}
    */
    readonly namespaceType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/redshift_namespace_registration#provisioned_cluster_identifier AwsNamespaceRegistration#provisioned_cluster_identifier}
    */
    readonly provisionedClusterIdentifier?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/redshift_namespace_registration#region AwsNamespaceRegistration#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/redshift_namespace_registration#serverless_namespace_identifier AwsNamespaceRegistration#serverless_namespace_identifier}
    */
    readonly serverlessNamespaceIdentifier?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/redshift_namespace_registration#serverless_workgroup_identifier AwsNamespaceRegistration#serverless_workgroup_identifier}
    */
    readonly serverlessWorkgroupIdentifier?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/redshift_namespace_registration aws_redshift_namespace_registration}
*/
export declare class AwsNamespaceRegistration extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_redshift_namespace_registration";
    /**
    * Generates CDKTN code for importing a AwsNamespaceRegistration resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsNamespaceRegistration to import
    * @param importFromId The id of the existing AwsNamespaceRegistration that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/redshift_namespace_registration#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsNamespaceRegistration to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/redshift_namespace_registration aws_redshift_namespace_registration} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsNamespaceRegistrationConfig
    */
    constructor(scope: Construct, id: string, config: AwsNamespaceRegistrationConfig);
    private _consumerIdentifier?;
    get consumerIdentifier(): string;
    set consumerIdentifier(value: string);
    get consumerIdentifierInput(): string | undefined;
    private _namespaceType?;
    get namespaceType(): string;
    set namespaceType(value: string);
    get namespaceTypeInput(): string | undefined;
    private _provisionedClusterIdentifier?;
    get provisionedClusterIdentifier(): string;
    set provisionedClusterIdentifier(value: string);
    resetProvisionedClusterIdentifier(): void;
    get provisionedClusterIdentifierInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _serverlessNamespaceIdentifier?;
    get serverlessNamespaceIdentifier(): string;
    set serverlessNamespaceIdentifier(value: string);
    resetServerlessNamespaceIdentifier(): void;
    get serverlessNamespaceIdentifierInput(): string | undefined;
    private _serverlessWorkgroupIdentifier?;
    get serverlessWorkgroupIdentifier(): string;
    set serverlessWorkgroupIdentifier(value: string);
    resetServerlessWorkgroupIdentifier(): void;
    get serverlessWorkgroupIdentifierInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
