export * from './data-aws-caller-identity';
export * from './ephemeral-aws-sts-web-identity-token';
