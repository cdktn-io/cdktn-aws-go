import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsCallerIdentityConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/caller_identity#id DataAwsCallerIdentity#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/caller_identity aws_caller_identity}
*/
export declare class DataAwsCallerIdentity extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_caller_identity";
    /**
    * Generates CDKTN code for importing a DataAwsCallerIdentity resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsCallerIdentity to import
    * @param importFromId The id of the existing DataAwsCallerIdentity that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/caller_identity#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsCallerIdentity to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/caller_identity aws_caller_identity} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsCallerIdentityConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataAwsCallerIdentityConfig);
    get accountId(): string;
    get arn(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get userId(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
