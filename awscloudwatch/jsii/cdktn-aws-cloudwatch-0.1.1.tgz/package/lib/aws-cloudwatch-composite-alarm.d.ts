import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsCloudwatchCompositeAlarmConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_composite_alarm#actions_enabled AwsCloudwatchCompositeAlarm#actions_enabled}
    */
    readonly actionsEnabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_composite_alarm#alarm_actions AwsCloudwatchCompositeAlarm#alarm_actions}
    */
    readonly alarmActions?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_composite_alarm#alarm_description AwsCloudwatchCompositeAlarm#alarm_description}
    */
    readonly alarmDescription?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_composite_alarm#alarm_name AwsCloudwatchCompositeAlarm#alarm_name}
    */
    readonly alarmName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_composite_alarm#alarm_rule AwsCloudwatchCompositeAlarm#alarm_rule}
    */
    readonly alarmRule: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_composite_alarm#id AwsCloudwatchCompositeAlarm#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_composite_alarm#insufficient_data_actions AwsCloudwatchCompositeAlarm#insufficient_data_actions}
    */
    readonly insufficientDataActions?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_composite_alarm#ok_actions AwsCloudwatchCompositeAlarm#ok_actions}
    */
    readonly okActions?: string[];
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_composite_alarm#region AwsCloudwatchCompositeAlarm#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_composite_alarm#tags AwsCloudwatchCompositeAlarm#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_composite_alarm#tags_all AwsCloudwatchCompositeAlarm#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * actions_suppressor block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_composite_alarm#actions_suppressor AwsCloudwatchCompositeAlarm#actions_suppressor}
    */
    readonly actionsSuppressor?: AwsCloudwatchCompositeAlarm.ActionsSuppressorProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_composite_alarm aws_cloudwatch_composite_alarm}
*/
export declare class AwsCloudwatchCompositeAlarm extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_cloudwatch_composite_alarm";
    /**
    * Generates CDKTN code for importing a AwsCloudwatchCompositeAlarm resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsCloudwatchCompositeAlarm to import
    * @param importFromId The id of the existing AwsCloudwatchCompositeAlarm that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_composite_alarm#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsCloudwatchCompositeAlarm to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_composite_alarm aws_cloudwatch_composite_alarm} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsCloudwatchCompositeAlarmConfig
    */
    constructor(scope: Construct, id: string, config: AwsCloudwatchCompositeAlarmConfig);
    private _actionsEnabled?;
    get actionsEnabled(): boolean | cdktn.IResolvable;
    set actionsEnabled(value: boolean | cdktn.IResolvable);
    resetActionsEnabled(): void;
    get actionsEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _alarmActions?;
    get alarmActions(): string[];
    set alarmActions(value: string[]);
    resetAlarmActions(): void;
    get alarmActionsInput(): string[] | undefined;
    private _alarmDescription?;
    get alarmDescription(): string;
    set alarmDescription(value: string);
    resetAlarmDescription(): void;
    get alarmDescriptionInput(): string | undefined;
    private _alarmName?;
    get alarmName(): string;
    set alarmName(value: string);
    get alarmNameInput(): string | undefined;
    private _alarmRule?;
    get alarmRule(): string;
    set alarmRule(value: string);
    get alarmRuleInput(): string | undefined;
    get arn(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _insufficientDataActions?;
    get insufficientDataActions(): string[];
    set insufficientDataActions(value: string[]);
    resetInsufficientDataActions(): void;
    get insufficientDataActionsInput(): string[] | undefined;
    private _okActions?;
    get okActions(): string[];
    set okActions(value: string[]);
    resetOkActions(): void;
    get okActionsInput(): string[] | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _actionsSuppressor;
    get actionsSuppressor(): AwsCloudwatchCompositeAlarm.ActionsSuppressorPropertyOutputReference;
    putActionsSuppressor(value: AwsCloudwatchCompositeAlarm.ActionsSuppressorProperty): void;
    resetActionsSuppressor(): void;
    get actionsSuppressorInput(): AwsCloudwatchCompositeAlarm.ActionsSuppressorProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsCloudwatchCompositeAlarmActionsSuppressorPropertyToTerraform(struct?: AwsCloudwatchCompositeAlarm.ActionsSuppressorPropertyOutputReference | AwsCloudwatchCompositeAlarm.ActionsSuppressorProperty): any;
export declare function awsCloudwatchCompositeAlarmActionsSuppressorPropertyToHclTerraform(struct?: AwsCloudwatchCompositeAlarm.ActionsSuppressorPropertyOutputReference | AwsCloudwatchCompositeAlarm.ActionsSuppressorProperty): any;
export declare namespace AwsCloudwatchCompositeAlarm {
    interface ActionsSuppressorProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_composite_alarm#alarm AwsCloudwatchCompositeAlarm#alarm}
        */
        readonly alarm: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_composite_alarm#extension_period AwsCloudwatchCompositeAlarm#extension_period}
        */
        readonly extensionPeriod: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_composite_alarm#wait_period AwsCloudwatchCompositeAlarm#wait_period}
        */
        readonly waitPeriod: number;
    }
    class ActionsSuppressorPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ActionsSuppressorProperty | undefined;
        set internalValue(value: ActionsSuppressorProperty | undefined);
        private _alarm?;
        get alarm(): string;
        set alarm(value: string);
        get alarmInput(): string | undefined;
        private _extensionPeriod?;
        get extensionPeriod(): number;
        set extensionPeriod(value: number);
        get extensionPeriodInput(): number | undefined;
        private _waitPeriod?;
        get waitPeriod(): number;
        set waitPeriod(value: number);
        get waitPeriodInput(): number | undefined;
    }
}
