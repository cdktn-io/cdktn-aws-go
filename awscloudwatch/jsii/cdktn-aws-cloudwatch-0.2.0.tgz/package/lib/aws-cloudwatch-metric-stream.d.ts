import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfMetricStreamConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_metric_stream#firehose_arn TfMetricStream#firehose_arn}
    */
    readonly firehoseArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_metric_stream#id TfMetricStream#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_metric_stream#include_linked_accounts_metrics TfMetricStream#include_linked_accounts_metrics}
    */
    readonly includeLinkedAccountsMetrics?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_metric_stream#name TfMetricStream#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_metric_stream#name_prefix TfMetricStream#name_prefix}
    */
    readonly namePrefix?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_metric_stream#output_format TfMetricStream#output_format}
    */
    readonly outputFormat: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_metric_stream#region TfMetricStream#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_metric_stream#role_arn TfMetricStream#role_arn}
    */
    readonly roleArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_metric_stream#tags TfMetricStream#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_metric_stream#tags_all TfMetricStream#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * exclude_filter block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_metric_stream#exclude_filter TfMetricStream#exclude_filter}
    */
    readonly excludeFilter?: TfMetricStream.ExcludeFilterProperty[] | cdktn.IResolvable;
    /**
    * include_filter block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_metric_stream#include_filter TfMetricStream#include_filter}
    */
    readonly includeFilter?: TfMetricStream.IncludeFilterProperty[] | cdktn.IResolvable;
    /**
    * statistics_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_metric_stream#statistics_configuration TfMetricStream#statistics_configuration}
    */
    readonly statisticsConfiguration?: TfMetricStream.StatisticsConfigurationProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_metric_stream#timeouts TfMetricStream#timeouts}
    */
    readonly timeouts?: TfMetricStream.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_metric_stream aws_cloudwatch_metric_stream}
*/
export declare class TfMetricStream extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_cloudwatch_metric_stream";
    /**
    * Generates CDKTN code for importing a TfMetricStream resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfMetricStream to import
    * @param importFromId The id of the existing TfMetricStream that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_metric_stream#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfMetricStream to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_metric_stream aws_cloudwatch_metric_stream} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfMetricStreamConfig
    */
    constructor(scope: Construct, id: string, config: TfMetricStreamConfig);
    get arn(): string;
    get creationDate(): string;
    private _firehoseArn?;
    get firehoseArn(): string;
    set firehoseArn(value: string);
    get firehoseArnInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _includeLinkedAccountsMetrics?;
    get includeLinkedAccountsMetrics(): boolean | cdktn.IResolvable;
    set includeLinkedAccountsMetrics(value: boolean | cdktn.IResolvable);
    resetIncludeLinkedAccountsMetrics(): void;
    get includeLinkedAccountsMetricsInput(): boolean | cdktn.IResolvable | undefined;
    get lastUpdateDate(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _namePrefix?;
    get namePrefix(): string;
    set namePrefix(value: string);
    resetNamePrefix(): void;
    get namePrefixInput(): string | undefined;
    private _outputFormat?;
    get outputFormat(): string;
    set outputFormat(value: string);
    get outputFormatInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _roleArn?;
    get roleArn(): string;
    set roleArn(value: string);
    get roleArnInput(): string | undefined;
    get state(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _excludeFilter;
    get excludeFilter(): TfMetricStream.ExcludeFilterPropertyList;
    putExcludeFilter(value: TfMetricStream.ExcludeFilterProperty[] | cdktn.IResolvable): void;
    resetExcludeFilter(): void;
    get excludeFilterInput(): cdktn.IResolvable | TfMetricStream.ExcludeFilterProperty[] | undefined;
    private _includeFilter;
    get includeFilter(): TfMetricStream.IncludeFilterPropertyList;
    putIncludeFilter(value: TfMetricStream.IncludeFilterProperty[] | cdktn.IResolvable): void;
    resetIncludeFilter(): void;
    get includeFilterInput(): cdktn.IResolvable | TfMetricStream.IncludeFilterProperty[] | undefined;
    private _statisticsConfiguration;
    get statisticsConfiguration(): TfMetricStream.StatisticsConfigurationPropertyList;
    putStatisticsConfiguration(value: TfMetricStream.StatisticsConfigurationProperty[] | cdktn.IResolvable): void;
    resetStatisticsConfiguration(): void;
    get statisticsConfigurationInput(): cdktn.IResolvable | TfMetricStream.StatisticsConfigurationProperty[] | undefined;
    private _timeouts;
    get timeouts(): TfMetricStream.TimeoutsPropertyOutputReference;
    putTimeouts(value: TfMetricStream.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | TfMetricStream.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfMetricStreamExcludeFilterPropertyToTerraform(struct?: TfMetricStream.ExcludeFilterProperty | cdktn.IResolvable): any;
export declare function tfMetricStreamExcludeFilterPropertyToHclTerraform(struct?: TfMetricStream.ExcludeFilterProperty | cdktn.IResolvable): any;
export declare function tfMetricStreamIncludeFilterPropertyToTerraform(struct?: TfMetricStream.IncludeFilterProperty | cdktn.IResolvable): any;
export declare function tfMetricStreamIncludeFilterPropertyToHclTerraform(struct?: TfMetricStream.IncludeFilterProperty | cdktn.IResolvable): any;
export declare function tfMetricStreamIncludeMetricPropertyToTerraform(struct?: TfMetricStream.IncludeMetricProperty | cdktn.IResolvable): any;
export declare function tfMetricStreamIncludeMetricPropertyToHclTerraform(struct?: TfMetricStream.IncludeMetricProperty | cdktn.IResolvable): any;
export declare function tfMetricStreamStatisticsConfigurationPropertyToTerraform(struct?: TfMetricStream.StatisticsConfigurationProperty | cdktn.IResolvable): any;
export declare function tfMetricStreamStatisticsConfigurationPropertyToHclTerraform(struct?: TfMetricStream.StatisticsConfigurationProperty | cdktn.IResolvable): any;
export declare function tfMetricStreamTimeoutsPropertyToTerraform(struct?: TfMetricStream.TimeoutsProperty | cdktn.IResolvable): any;
export declare function tfMetricStreamTimeoutsPropertyToHclTerraform(struct?: TfMetricStream.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace TfMetricStream {
    interface ExcludeFilterProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_metric_stream#metric_names TfMetricStream#metric_names}
        */
        readonly metricNames?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_metric_stream#namespace TfMetricStream#namespace}
        */
        readonly namespace: string;
    }
    class ExcludeFilterPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ExcludeFilterProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ExcludeFilterProperty | cdktn.IResolvable | undefined);
        private _metricNames?;
        get metricNames(): string[];
        set metricNames(value: string[]);
        resetMetricNames(): void;
        get metricNamesInput(): string[] | undefined;
        private _namespace?;
        get namespace(): string;
        set namespace(value: string);
        get namespaceInput(): string | undefined;
    }
    class ExcludeFilterPropertyList extends cdktn.ComplexList {
        internalValue?: ExcludeFilterProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ExcludeFilterPropertyOutputReference;
    }
    interface IncludeFilterProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_metric_stream#metric_names TfMetricStream#metric_names}
        */
        readonly metricNames?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_metric_stream#namespace TfMetricStream#namespace}
        */
        readonly namespace: string;
    }
    class IncludeFilterPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): IncludeFilterProperty | cdktn.IResolvable | undefined;
        set internalValue(value: IncludeFilterProperty | cdktn.IResolvable | undefined);
        private _metricNames?;
        get metricNames(): string[];
        set metricNames(value: string[]);
        resetMetricNames(): void;
        get metricNamesInput(): string[] | undefined;
        private _namespace?;
        get namespace(): string;
        set namespace(value: string);
        get namespaceInput(): string | undefined;
    }
    class IncludeFilterPropertyList extends cdktn.ComplexList {
        internalValue?: IncludeFilterProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): IncludeFilterPropertyOutputReference;
    }
    interface IncludeMetricProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_metric_stream#metric_name TfMetricStream#metric_name}
        */
        readonly metricName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_metric_stream#namespace TfMetricStream#namespace}
        */
        readonly namespace: string;
    }
    class IncludeMetricPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): IncludeMetricProperty | cdktn.IResolvable | undefined;
        set internalValue(value: IncludeMetricProperty | cdktn.IResolvable | undefined);
        private _metricName?;
        get metricName(): string;
        set metricName(value: string);
        get metricNameInput(): string | undefined;
        private _namespace?;
        get namespace(): string;
        set namespace(value: string);
        get namespaceInput(): string | undefined;
    }
    class IncludeMetricPropertyList extends cdktn.ComplexList {
        internalValue?: IncludeMetricProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): IncludeMetricPropertyOutputReference;
    }
    interface StatisticsConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_metric_stream#additional_statistics TfMetricStream#additional_statistics}
        */
        readonly additionalStatistics: string[];
        /**
        * include_metric block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_metric_stream#include_metric TfMetricStream#include_metric}
        */
        readonly includeMetric: IncludeMetricProperty[] | cdktn.IResolvable;
    }
    class StatisticsConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): StatisticsConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: StatisticsConfigurationProperty | cdktn.IResolvable | undefined);
        private _additionalStatistics?;
        get additionalStatistics(): string[];
        set additionalStatistics(value: string[]);
        get additionalStatisticsInput(): string[] | undefined;
        private _includeMetric;
        get includeMetric(): IncludeMetricPropertyList;
        putIncludeMetric(value: IncludeMetricProperty[] | cdktn.IResolvable): void;
        get includeMetricInput(): cdktn.IResolvable | IncludeMetricProperty[] | undefined;
    }
    class StatisticsConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: StatisticsConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): StatisticsConfigurationPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_metric_stream#create TfMetricStream#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_metric_stream#delete TfMetricStream#delete}
        */
        readonly delete?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_metric_stream#update TfMetricStream#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
