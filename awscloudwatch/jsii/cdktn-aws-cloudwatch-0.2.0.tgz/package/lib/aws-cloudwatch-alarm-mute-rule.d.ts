import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfAlarmMuteRuleConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_alarm_mute_rule#description TfAlarmMuteRule#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_alarm_mute_rule#expire_date TfAlarmMuteRule#expire_date}
    */
    readonly expireDate?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_alarm_mute_rule#name TfAlarmMuteRule#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_alarm_mute_rule#region TfAlarmMuteRule#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_alarm_mute_rule#start_date TfAlarmMuteRule#start_date}
    */
    readonly startDate?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_alarm_mute_rule#tags TfAlarmMuteRule#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * mute_targets block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_alarm_mute_rule#mute_targets TfAlarmMuteRule#mute_targets}
    */
    readonly muteTargets?: TfAlarmMuteRule.MuteTargetsProperty[] | cdktn.IResolvable;
    /**
    * rule block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_alarm_mute_rule#rule TfAlarmMuteRule#rule}
    */
    readonly rule?: TfAlarmMuteRule.RuleProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_alarm_mute_rule aws_cloudwatch_alarm_mute_rule}
*/
export declare class TfAlarmMuteRule extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_cloudwatch_alarm_mute_rule";
    /**
    * Generates CDKTN code for importing a TfAlarmMuteRule resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfAlarmMuteRule to import
    * @param importFromId The id of the existing TfAlarmMuteRule that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_alarm_mute_rule#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfAlarmMuteRule to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_alarm_mute_rule aws_cloudwatch_alarm_mute_rule} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfAlarmMuteRuleConfig
    */
    constructor(scope: Construct, id: string, config: TfAlarmMuteRuleConfig);
    get arn(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _expireDate?;
    get expireDate(): string;
    set expireDate(value: string);
    resetExpireDate(): void;
    get expireDateInput(): string | undefined;
    get lastUpdatedTimestamp(): string;
    get muteType(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _startDate?;
    get startDate(): string;
    set startDate(value: string);
    resetStartDate(): void;
    get startDateInput(): string | undefined;
    get status(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    private _muteTargets;
    get muteTargets(): TfAlarmMuteRule.MuteTargetsPropertyList;
    putMuteTargets(value: TfAlarmMuteRule.MuteTargetsProperty[] | cdktn.IResolvable): void;
    resetMuteTargets(): void;
    get muteTargetsInput(): cdktn.IResolvable | TfAlarmMuteRule.MuteTargetsProperty[] | undefined;
    private _rule;
    get rule(): TfAlarmMuteRule.RulePropertyList;
    putRule(value: TfAlarmMuteRule.RuleProperty[] | cdktn.IResolvable): void;
    resetRule(): void;
    get ruleInput(): cdktn.IResolvable | TfAlarmMuteRule.RuleProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfAlarmMuteRuleMuteTargetsPropertyToTerraform(struct?: TfAlarmMuteRule.MuteTargetsProperty | cdktn.IResolvable): any;
export declare function tfAlarmMuteRuleMuteTargetsPropertyToHclTerraform(struct?: TfAlarmMuteRule.MuteTargetsProperty | cdktn.IResolvable): any;
export declare function tfAlarmMuteRuleSchedulePropertyToTerraform(struct?: TfAlarmMuteRule.ScheduleProperty | cdktn.IResolvable): any;
export declare function tfAlarmMuteRuleSchedulePropertyToHclTerraform(struct?: TfAlarmMuteRule.ScheduleProperty | cdktn.IResolvable): any;
export declare function tfAlarmMuteRuleRulePropertyToTerraform(struct?: TfAlarmMuteRule.RuleProperty | cdktn.IResolvable): any;
export declare function tfAlarmMuteRuleRulePropertyToHclTerraform(struct?: TfAlarmMuteRule.RuleProperty | cdktn.IResolvable): any;
export declare namespace TfAlarmMuteRule {
    interface MuteTargetsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_alarm_mute_rule#alarm_names TfAlarmMuteRule#alarm_names}
        */
        readonly alarmNames: string[];
    }
    class MuteTargetsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): MuteTargetsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: MuteTargetsProperty | cdktn.IResolvable | undefined);
        private _alarmNames?;
        get alarmNames(): string[];
        set alarmNames(value: string[]);
        get alarmNamesInput(): string[] | undefined;
    }
    class MuteTargetsPropertyList extends cdktn.ComplexList {
        internalValue?: MuteTargetsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): MuteTargetsPropertyOutputReference;
    }
    interface ScheduleProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_alarm_mute_rule#duration TfAlarmMuteRule#duration}
        */
        readonly duration: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_alarm_mute_rule#expression TfAlarmMuteRule#expression}
        */
        readonly expression: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_alarm_mute_rule#timezone TfAlarmMuteRule#timezone}
        */
        readonly timezone?: string;
    }
    class SchedulePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ScheduleProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ScheduleProperty | cdktn.IResolvable | undefined);
        private _duration?;
        get duration(): string;
        set duration(value: string);
        get durationInput(): string | undefined;
        private _expression?;
        get expression(): string;
        set expression(value: string);
        get expressionInput(): string | undefined;
        private _timezone?;
        get timezone(): string;
        set timezone(value: string);
        resetTimezone(): void;
        get timezoneInput(): string | undefined;
    }
    class SchedulePropertyList extends cdktn.ComplexList {
        internalValue?: ScheduleProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SchedulePropertyOutputReference;
    }
    interface RuleProperty {
        /**
        * schedule block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_alarm_mute_rule#schedule TfAlarmMuteRule#schedule}
        */
        readonly schedule?: ScheduleProperty[] | cdktn.IResolvable;
    }
    class RulePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RuleProperty | cdktn.IResolvable | undefined);
        private _schedule;
        get schedule(): SchedulePropertyList;
        putSchedule(value: ScheduleProperty[] | cdktn.IResolvable): void;
        resetSchedule(): void;
        get scheduleInput(): cdktn.IResolvable | ScheduleProperty[] | undefined;
    }
    class RulePropertyList extends cdktn.ComplexList {
        internalValue?: RuleProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RulePropertyOutputReference;
    }
}
