import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsTranscribeVocabularyFilterConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transcribe_vocabulary_filter#id AwsTranscribeVocabularyFilter#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transcribe_vocabulary_filter#language_code AwsTranscribeVocabularyFilter#language_code}
    */
    readonly languageCode: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transcribe_vocabulary_filter#region AwsTranscribeVocabularyFilter#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transcribe_vocabulary_filter#tags AwsTranscribeVocabularyFilter#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transcribe_vocabulary_filter#tags_all AwsTranscribeVocabularyFilter#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transcribe_vocabulary_filter#vocabulary_filter_file_uri AwsTranscribeVocabularyFilter#vocabulary_filter_file_uri}
    */
    readonly vocabularyFilterFileUri?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transcribe_vocabulary_filter#vocabulary_filter_name AwsTranscribeVocabularyFilter#vocabulary_filter_name}
    */
    readonly vocabularyFilterName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transcribe_vocabulary_filter#words AwsTranscribeVocabularyFilter#words}
    */
    readonly words?: string[];
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transcribe_vocabulary_filter aws_transcribe_vocabulary_filter}
*/
export declare class AwsTranscribeVocabularyFilter extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_transcribe_vocabulary_filter";
    /**
    * Generates CDKTN code for importing a AwsTranscribeVocabularyFilter resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsTranscribeVocabularyFilter to import
    * @param importFromId The id of the existing AwsTranscribeVocabularyFilter that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transcribe_vocabulary_filter#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsTranscribeVocabularyFilter to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transcribe_vocabulary_filter aws_transcribe_vocabulary_filter} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsTranscribeVocabularyFilterConfig
    */
    constructor(scope: Construct, id: string, config: AwsTranscribeVocabularyFilterConfig);
    get arn(): string;
    get downloadUri(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _languageCode?;
    get languageCode(): string;
    set languageCode(value: string);
    get languageCodeInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _vocabularyFilterFileUri?;
    get vocabularyFilterFileUri(): string;
    set vocabularyFilterFileUri(value: string);
    resetVocabularyFilterFileUri(): void;
    get vocabularyFilterFileUriInput(): string | undefined;
    private _vocabularyFilterName?;
    get vocabularyFilterName(): string;
    set vocabularyFilterName(value: string);
    get vocabularyFilterNameInput(): string | undefined;
    private _words?;
    get words(): string[];
    set words(value: string[]);
    resetWords(): void;
    get wordsInput(): string[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
