import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsTranscribeLanguageModelConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transcribe_language_model#base_model_name AwsTranscribeLanguageModel#base_model_name}
    */
    readonly baseModelName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transcribe_language_model#id AwsTranscribeLanguageModel#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transcribe_language_model#language_code AwsTranscribeLanguageModel#language_code}
    */
    readonly languageCode: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transcribe_language_model#model_name AwsTranscribeLanguageModel#model_name}
    */
    readonly modelName: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transcribe_language_model#region AwsTranscribeLanguageModel#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transcribe_language_model#tags AwsTranscribeLanguageModel#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transcribe_language_model#tags_all AwsTranscribeLanguageModel#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * input_data_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transcribe_language_model#input_data_config AwsTranscribeLanguageModel#input_data_config}
    */
    readonly inputDataConfig: AwsTranscribeLanguageModel.InputDataConfigProperty;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transcribe_language_model#timeouts AwsTranscribeLanguageModel#timeouts}
    */
    readonly timeouts?: AwsTranscribeLanguageModel.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transcribe_language_model aws_transcribe_language_model}
*/
export declare class AwsTranscribeLanguageModel extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_transcribe_language_model";
    /**
    * Generates CDKTN code for importing a AwsTranscribeLanguageModel resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsTranscribeLanguageModel to import
    * @param importFromId The id of the existing AwsTranscribeLanguageModel that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transcribe_language_model#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsTranscribeLanguageModel to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transcribe_language_model aws_transcribe_language_model} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsTranscribeLanguageModelConfig
    */
    constructor(scope: Construct, id: string, config: AwsTranscribeLanguageModelConfig);
    get arn(): string;
    private _baseModelName?;
    get baseModelName(): string;
    set baseModelName(value: string);
    get baseModelNameInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _languageCode?;
    get languageCode(): string;
    set languageCode(value: string);
    get languageCodeInput(): string | undefined;
    private _modelName?;
    get modelName(): string;
    set modelName(value: string);
    get modelNameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _inputDataConfig;
    get inputDataConfig(): AwsTranscribeLanguageModel.InputDataConfigPropertyOutputReference;
    putInputDataConfig(value: AwsTranscribeLanguageModel.InputDataConfigProperty): void;
    get inputDataConfigInput(): AwsTranscribeLanguageModel.InputDataConfigProperty | undefined;
    private _timeouts;
    get timeouts(): AwsTranscribeLanguageModel.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsTranscribeLanguageModel.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): AwsTranscribeLanguageModel.TimeoutsProperty | cdktn.IResolvable | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsTranscribeLanguageModelInputDataConfigPropertyToTerraform(struct?: AwsTranscribeLanguageModel.InputDataConfigPropertyOutputReference | AwsTranscribeLanguageModel.InputDataConfigProperty): any;
export declare function awsTranscribeLanguageModelInputDataConfigPropertyToHclTerraform(struct?: AwsTranscribeLanguageModel.InputDataConfigPropertyOutputReference | AwsTranscribeLanguageModel.InputDataConfigProperty): any;
export declare function awsTranscribeLanguageModelTimeoutsPropertyToTerraform(struct?: AwsTranscribeLanguageModel.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsTranscribeLanguageModelTimeoutsPropertyToHclTerraform(struct?: AwsTranscribeLanguageModel.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsTranscribeLanguageModel {
    interface InputDataConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transcribe_language_model#data_access_role_arn AwsTranscribeLanguageModel#data_access_role_arn}
        */
        readonly dataAccessRoleArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transcribe_language_model#s3_uri AwsTranscribeLanguageModel#s3_uri}
        */
        readonly s3Uri: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transcribe_language_model#tuning_data_s3_uri AwsTranscribeLanguageModel#tuning_data_s3_uri}
        */
        readonly tuningDataS3Uri?: string;
    }
    class InputDataConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): InputDataConfigProperty | undefined;
        set internalValue(value: InputDataConfigProperty | undefined);
        private _dataAccessRoleArn?;
        get dataAccessRoleArn(): string;
        set dataAccessRoleArn(value: string);
        get dataAccessRoleArnInput(): string | undefined;
        private _s3Uri?;
        get s3Uri(): string;
        set s3Uri(value: string);
        get s3UriInput(): string | undefined;
        private _tuningDataS3Uri?;
        get tuningDataS3Uri(): string;
        set tuningDataS3Uri(value: string);
        resetTuningDataS3Uri(): void;
        get tuningDataS3UriInput(): string | undefined;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transcribe_language_model#create AwsTranscribeLanguageModel#create}
        */
        readonly create?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
    }
}
