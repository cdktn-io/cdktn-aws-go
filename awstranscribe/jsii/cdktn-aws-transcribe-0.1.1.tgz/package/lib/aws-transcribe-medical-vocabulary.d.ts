import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsTranscribeMedicalVocabularyConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transcribe_medical_vocabulary#id AwsTranscribeMedicalVocabulary#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transcribe_medical_vocabulary#language_code AwsTranscribeMedicalVocabulary#language_code}
    */
    readonly languageCode: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transcribe_medical_vocabulary#region AwsTranscribeMedicalVocabulary#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transcribe_medical_vocabulary#tags AwsTranscribeMedicalVocabulary#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transcribe_medical_vocabulary#tags_all AwsTranscribeMedicalVocabulary#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transcribe_medical_vocabulary#vocabulary_file_uri AwsTranscribeMedicalVocabulary#vocabulary_file_uri}
    */
    readonly vocabularyFileUri: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transcribe_medical_vocabulary#vocabulary_name AwsTranscribeMedicalVocabulary#vocabulary_name}
    */
    readonly vocabularyName: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transcribe_medical_vocabulary#timeouts AwsTranscribeMedicalVocabulary#timeouts}
    */
    readonly timeouts?: AwsTranscribeMedicalVocabulary.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transcribe_medical_vocabulary aws_transcribe_medical_vocabulary}
*/
export declare class AwsTranscribeMedicalVocabulary extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_transcribe_medical_vocabulary";
    /**
    * Generates CDKTN code for importing a AwsTranscribeMedicalVocabulary resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsTranscribeMedicalVocabulary to import
    * @param importFromId The id of the existing AwsTranscribeMedicalVocabulary that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transcribe_medical_vocabulary#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsTranscribeMedicalVocabulary to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transcribe_medical_vocabulary aws_transcribe_medical_vocabulary} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsTranscribeMedicalVocabularyConfig
    */
    constructor(scope: Construct, id: string, config: AwsTranscribeMedicalVocabularyConfig);
    get arn(): string;
    get downloadUri(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _languageCode?;
    get languageCode(): string;
    set languageCode(value: string);
    get languageCodeInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _vocabularyFileUri?;
    get vocabularyFileUri(): string;
    set vocabularyFileUri(value: string);
    get vocabularyFileUriInput(): string | undefined;
    private _vocabularyName?;
    get vocabularyName(): string;
    set vocabularyName(value: string);
    get vocabularyNameInput(): string | undefined;
    private _timeouts;
    get timeouts(): AwsTranscribeMedicalVocabulary.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsTranscribeMedicalVocabulary.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsTranscribeMedicalVocabulary.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsTranscribeMedicalVocabularyTimeoutsPropertyToTerraform(struct?: AwsTranscribeMedicalVocabulary.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsTranscribeMedicalVocabularyTimeoutsPropertyToHclTerraform(struct?: AwsTranscribeMedicalVocabulary.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsTranscribeMedicalVocabulary {
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transcribe_medical_vocabulary#create AwsTranscribeMedicalVocabulary#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transcribe_medical_vocabulary#delete AwsTranscribeMedicalVocabulary#delete}
        */
        readonly delete?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transcribe_medical_vocabulary#update AwsTranscribeMedicalVocabulary#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
