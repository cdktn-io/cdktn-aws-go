import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfAccountSettingsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_account_settings#region TfAccountSettings#region}
    */
    readonly region?: string;
    /**
    * minimum_throughput_billing_commitment block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_account_settings#minimum_throughput_billing_commitment TfAccountSettings#minimum_throughput_billing_commitment}
    */
    readonly minimumThroughputBillingCommitment?: TfAccountSettings.MinimumThroughputBillingCommitmentProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_account_settings aws_kinesis_account_settings}
*/
export declare class TfAccountSettings extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_kinesis_account_settings";
    /**
    * Generates CDKTN code for importing a TfAccountSettings resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfAccountSettings to import
    * @param importFromId The id of the existing TfAccountSettings that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_account_settings#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfAccountSettings to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_account_settings aws_kinesis_account_settings} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfAccountSettingsConfig = {}
    */
    constructor(scope: Construct, id: string, config?: TfAccountSettingsConfig);
    get id(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _minimumThroughputBillingCommitment;
    get minimumThroughputBillingCommitment(): TfAccountSettings.MinimumThroughputBillingCommitmentPropertyList;
    putMinimumThroughputBillingCommitment(value: TfAccountSettings.MinimumThroughputBillingCommitmentProperty[] | cdktn.IResolvable): void;
    resetMinimumThroughputBillingCommitment(): void;
    get minimumThroughputBillingCommitmentInput(): cdktn.IResolvable | TfAccountSettings.MinimumThroughputBillingCommitmentProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfAccountSettingsMinimumThroughputBillingCommitmentPropertyToTerraform(struct?: TfAccountSettings.MinimumThroughputBillingCommitmentProperty | cdktn.IResolvable): any;
export declare function tfAccountSettingsMinimumThroughputBillingCommitmentPropertyToHclTerraform(struct?: TfAccountSettings.MinimumThroughputBillingCommitmentProperty | cdktn.IResolvable): any;
export declare namespace TfAccountSettings {
    interface MinimumThroughputBillingCommitmentProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_account_settings#status TfAccountSettings#status}
        */
        readonly status: string;
    }
    class MinimumThroughputBillingCommitmentPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): MinimumThroughputBillingCommitmentProperty | cdktn.IResolvable | undefined;
        set internalValue(value: MinimumThroughputBillingCommitmentProperty | cdktn.IResolvable | undefined);
        get earliestAllowedEndAt(): string;
        get endedAt(): string;
        get startedAt(): string;
        private _status?;
        get status(): string;
        set status(value: string);
        get statusInput(): string | undefined;
        get statusActual(): string;
    }
    class MinimumThroughputBillingCommitmentPropertyList extends cdktn.ComplexList {
        internalValue?: MinimumThroughputBillingCommitmentProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): MinimumThroughputBillingCommitmentPropertyOutputReference;
    }
}
