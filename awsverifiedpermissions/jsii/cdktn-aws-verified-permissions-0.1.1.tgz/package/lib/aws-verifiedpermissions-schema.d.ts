import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsVerifiedpermissionsSchemaConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedpermissions_schema#policy_store_id AwsVerifiedpermissionsSchema#policy_store_id}
    */
    readonly policyStoreId: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedpermissions_schema#region AwsVerifiedpermissionsSchema#region}
    */
    readonly region?: string;
    /**
    * definition block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedpermissions_schema#definition AwsVerifiedpermissionsSchema#definition}
    */
    readonly definition?: AwsVerifiedpermissionsSchema.DefinitionProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedpermissions_schema aws_verifiedpermissions_schema}
*/
export declare class AwsVerifiedpermissionsSchema extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_verifiedpermissions_schema";
    /**
    * Generates CDKTN code for importing a AwsVerifiedpermissionsSchema resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsVerifiedpermissionsSchema to import
    * @param importFromId The id of the existing AwsVerifiedpermissionsSchema that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedpermissions_schema#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsVerifiedpermissionsSchema to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedpermissions_schema aws_verifiedpermissions_schema} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsVerifiedpermissionsSchemaConfig
    */
    constructor(scope: Construct, id: string, config: AwsVerifiedpermissionsSchemaConfig);
    get id(): string;
    get namespaces(): string[];
    private _policyStoreId?;
    get policyStoreId(): string;
    set policyStoreId(value: string);
    get policyStoreIdInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _definition;
    get definition(): AwsVerifiedpermissionsSchema.DefinitionPropertyList;
    putDefinition(value: AwsVerifiedpermissionsSchema.DefinitionProperty[] | cdktn.IResolvable): void;
    resetDefinition(): void;
    get definitionInput(): cdktn.IResolvable | AwsVerifiedpermissionsSchema.DefinitionProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsVerifiedpermissionsSchemaDefinitionPropertyToTerraform(struct?: AwsVerifiedpermissionsSchema.DefinitionProperty | cdktn.IResolvable): any;
export declare function awsVerifiedpermissionsSchemaDefinitionPropertyToHclTerraform(struct?: AwsVerifiedpermissionsSchema.DefinitionProperty | cdktn.IResolvable): any;
export declare namespace AwsVerifiedpermissionsSchema {
    interface DefinitionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedpermissions_schema#value AwsVerifiedpermissionsSchema#value}
        */
        readonly value: string;
    }
    class DefinitionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DefinitionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DefinitionProperty | cdktn.IResolvable | undefined);
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class DefinitionPropertyList extends cdktn.ComplexList {
        internalValue?: DefinitionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DefinitionPropertyOutputReference;
    }
}
