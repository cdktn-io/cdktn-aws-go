import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsVerifiedpermissionsPolicyStoreConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/verifiedpermissions_policy_store#id DataAwsVerifiedpermissionsPolicyStore#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/verifiedpermissions_policy_store#region DataAwsVerifiedpermissionsPolicyStore#region}
    */
    readonly region?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/verifiedpermissions_policy_store aws_verifiedpermissions_policy_store}
*/
export declare class DataAwsVerifiedpermissionsPolicyStore extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_verifiedpermissions_policy_store";
    /**
    * Generates CDKTN code for importing a DataAwsVerifiedpermissionsPolicyStore resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsVerifiedpermissionsPolicyStore to import
    * @param importFromId The id of the existing DataAwsVerifiedpermissionsPolicyStore that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/verifiedpermissions_policy_store#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsVerifiedpermissionsPolicyStore to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/verifiedpermissions_policy_store aws_verifiedpermissions_policy_store} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsVerifiedpermissionsPolicyStoreConfig
    */
    constructor(scope: Construct, id: string, config: DataAwsVerifiedpermissionsPolicyStoreConfig);
    get arn(): string;
    get createdDate(): string;
    get deletionProtection(): string;
    get description(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    get lastUpdatedDate(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags;
    get tags(): cdktn.StringMap;
    private _validationSettings;
    get validationSettings(): DataAwsVerifiedpermissionsPolicyStore.ValidationSettingsPropertyList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataAwsVerifiedpermissionsPolicyStoreValidationSettingsPropertyToTerraform(struct?: DataAwsVerifiedpermissionsPolicyStore.ValidationSettingsProperty): any;
export declare function dataAwsVerifiedpermissionsPolicyStoreValidationSettingsPropertyToHclTerraform(struct?: DataAwsVerifiedpermissionsPolicyStore.ValidationSettingsProperty): any;
export declare namespace DataAwsVerifiedpermissionsPolicyStore {
    interface ValidationSettingsProperty {
    }
    class ValidationSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ValidationSettingsProperty | undefined;
        set internalValue(value: ValidationSettingsProperty | undefined);
        get mode(): string;
    }
    class ValidationSettingsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ValidationSettingsPropertyOutputReference;
    }
}
