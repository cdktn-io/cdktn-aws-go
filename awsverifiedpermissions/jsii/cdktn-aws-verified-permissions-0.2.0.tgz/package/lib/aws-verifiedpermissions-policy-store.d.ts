import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfPolicyStoreConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedpermissions_policy_store#deletion_protection TfPolicyStore#deletion_protection}
    */
    readonly deletionProtection?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedpermissions_policy_store#description TfPolicyStore#description}
    */
    readonly description?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedpermissions_policy_store#region TfPolicyStore#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedpermissions_policy_store#tags TfPolicyStore#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * validation_settings block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedpermissions_policy_store#validation_settings TfPolicyStore#validation_settings}
    */
    readonly validationSettings?: TfPolicyStore.ValidationSettingsProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedpermissions_policy_store aws_verifiedpermissions_policy_store}
*/
export declare class TfPolicyStore extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_verifiedpermissions_policy_store";
    /**
    * Generates CDKTN code for importing a TfPolicyStore resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfPolicyStore to import
    * @param importFromId The id of the existing TfPolicyStore that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedpermissions_policy_store#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfPolicyStore to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedpermissions_policy_store aws_verifiedpermissions_policy_store} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfPolicyStoreConfig = {}
    */
    constructor(scope: Construct, id: string, config?: TfPolicyStoreConfig);
    get arn(): string;
    private _deletionProtection?;
    get deletionProtection(): string;
    set deletionProtection(value: string);
    resetDeletionProtection(): void;
    get deletionProtectionInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get id(): string;
    get policyStoreId(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    private _validationSettings;
    get validationSettings(): TfPolicyStore.ValidationSettingsPropertyList;
    putValidationSettings(value: TfPolicyStore.ValidationSettingsProperty[] | cdktn.IResolvable): void;
    resetValidationSettings(): void;
    get validationSettingsInput(): cdktn.IResolvable | TfPolicyStore.ValidationSettingsProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfPolicyStoreValidationSettingsPropertyToTerraform(struct?: TfPolicyStore.ValidationSettingsProperty | cdktn.IResolvable): any;
export declare function tfPolicyStoreValidationSettingsPropertyToHclTerraform(struct?: TfPolicyStore.ValidationSettingsProperty | cdktn.IResolvable): any;
export declare namespace TfPolicyStore {
    interface ValidationSettingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedpermissions_policy_store#mode TfPolicyStore#mode}
        */
        readonly mode: string;
    }
    class ValidationSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ValidationSettingsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ValidationSettingsProperty | cdktn.IResolvable | undefined);
        private _mode?;
        get mode(): string;
        set mode(value: string);
        get modeInput(): string | undefined;
    }
    class ValidationSettingsPropertyList extends cdktn.ComplexList {
        internalValue?: ValidationSettingsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ValidationSettingsPropertyOutputReference;
    }
}
