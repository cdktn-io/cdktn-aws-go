export * from './aws-cloudcontrolapi-resource';
export * from './data-aws-cloudcontrolapi-resource';
