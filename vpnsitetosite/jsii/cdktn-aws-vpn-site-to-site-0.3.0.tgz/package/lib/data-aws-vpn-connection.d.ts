import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsConnectionConfig extends cdktn.TerraformMetaArguments {
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/vpn_connection#region DataAwsConnection#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/vpn_connection#vpn_connection_id DataAwsConnection#vpn_connection_id}
    */
    readonly vpnConnectionId?: string;
    /**
    * filter block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/vpn_connection#filter DataAwsConnection#filter}
    */
    readonly filter?: DataAwsConnection.FilterProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/vpn_connection aws_vpn_connection}
*/
export declare class DataAwsConnection extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_vpn_connection";
    /**
    * Generates CDKTN code for importing a DataAwsConnection resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsConnection to import
    * @param importFromId The id of the existing DataAwsConnection that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/vpn_connection#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsConnection to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/vpn_connection aws_vpn_connection} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsConnectionConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataAwsConnectionConfig);
    get category(): string;
    get coreNetworkArn(): string;
    get coreNetworkAttachmentArn(): string;
    get customerGatewayConfiguration(): string;
    get customerGatewayId(): string;
    get gatewayAssociationState(): string;
    get preSharedKeyArn(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _routes;
    get routes(): DataAwsConnection.RoutesPropertyList;
    get state(): string;
    private _tags;
    get tags(): cdktn.StringMap;
    get transitGatewayId(): string;
    get type(): string;
    private _vgwTelemetries;
    get vgwTelemetries(): DataAwsConnection.VgwTelemetriesPropertyList;
    get vpnConcentratorId(): string;
    private _vpnConnectionId?;
    get vpnConnectionId(): string;
    set vpnConnectionId(value: string);
    resetVpnConnectionId(): void;
    get vpnConnectionIdInput(): string | undefined;
    get vpnGatewayId(): string;
    private _filter;
    get filter(): DataAwsConnection.FilterPropertyList;
    putFilter(value: DataAwsConnection.FilterProperty[] | cdktn.IResolvable): void;
    resetFilter(): void;
    get filterInput(): cdktn.IResolvable | DataAwsConnection.FilterProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataAwsConnectionRoutesPropertyToTerraform(struct?: DataAwsConnection.RoutesProperty): any;
export declare function dataAwsConnectionRoutesPropertyToHclTerraform(struct?: DataAwsConnection.RoutesProperty): any;
export declare function dataAwsConnectionVgwTelemetriesPropertyToTerraform(struct?: DataAwsConnection.VgwTelemetriesProperty): any;
export declare function dataAwsConnectionVgwTelemetriesPropertyToHclTerraform(struct?: DataAwsConnection.VgwTelemetriesProperty): any;
export declare function dataAwsConnectionFilterPropertyToTerraform(struct?: DataAwsConnection.FilterProperty | cdktn.IResolvable): any;
export declare function dataAwsConnectionFilterPropertyToHclTerraform(struct?: DataAwsConnection.FilterProperty | cdktn.IResolvable): any;
export declare namespace DataAwsConnection {
    interface RoutesProperty {
    }
    class RoutesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RoutesProperty | undefined;
        set internalValue(value: RoutesProperty | undefined);
        get destinationCidrBlock(): string;
        get source(): string;
        get state(): string;
    }
    class RoutesPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RoutesPropertyOutputReference;
    }
    interface VgwTelemetriesProperty {
    }
    class VgwTelemetriesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): VgwTelemetriesProperty | undefined;
        set internalValue(value: VgwTelemetriesProperty | undefined);
        get acceptedRouteCount(): number;
        get lastStatusChange(): string;
        get outsideIpAddress(): string;
        get status(): string;
        get statusMessage(): string;
    }
    class VgwTelemetriesPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): VgwTelemetriesPropertyOutputReference;
    }
    interface FilterProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/vpn_connection#name DataAwsConnection#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/vpn_connection#values DataAwsConnection#values}
        */
        readonly values: string[];
    }
    class FilterPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): FilterProperty | cdktn.IResolvable | undefined;
        set internalValue(value: FilterProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        get valuesInput(): string[] | undefined;
    }
    class FilterPropertyList extends cdktn.ComplexList {
        internalValue?: FilterProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): FilterPropertyOutputReference;
    }
}
