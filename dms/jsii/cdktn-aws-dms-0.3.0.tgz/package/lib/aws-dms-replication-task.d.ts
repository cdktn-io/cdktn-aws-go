import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsReplicationTaskConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_replication_task#cdc_start_position AwsReplicationTask#cdc_start_position}
    */
    readonly cdcStartPosition?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_replication_task#cdc_start_time AwsReplicationTask#cdc_start_time}
    */
    readonly cdcStartTime?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_replication_task#id AwsReplicationTask#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_replication_task#migration_type AwsReplicationTask#migration_type}
    */
    readonly migrationType: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_replication_task#region AwsReplicationTask#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_replication_task#replication_instance_arn AwsReplicationTask#replication_instance_arn}
    */
    readonly replicationInstanceArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_replication_task#replication_task_id AwsReplicationTask#replication_task_id}
    */
    readonly replicationTaskId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_replication_task#replication_task_settings AwsReplicationTask#replication_task_settings}
    */
    readonly replicationTaskSettings?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_replication_task#resource_identifier AwsReplicationTask#resource_identifier}
    */
    readonly resourceIdentifier?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_replication_task#source_endpoint_arn AwsReplicationTask#source_endpoint_arn}
    */
    readonly sourceEndpointArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_replication_task#start_replication_task AwsReplicationTask#start_replication_task}
    */
    readonly startReplicationTask?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_replication_task#table_mappings AwsReplicationTask#table_mappings}
    */
    readonly tableMappings: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_replication_task#tags AwsReplicationTask#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_replication_task#tags_all AwsReplicationTask#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_replication_task#target_endpoint_arn AwsReplicationTask#target_endpoint_arn}
    */
    readonly targetEndpointArn: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_replication_task aws_dms_replication_task}
*/
export declare class AwsReplicationTask extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_dms_replication_task";
    /**
    * Generates CDKTN code for importing a AwsReplicationTask resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsReplicationTask to import
    * @param importFromId The id of the existing AwsReplicationTask that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_replication_task#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsReplicationTask to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_replication_task aws_dms_replication_task} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsReplicationTaskConfig
    */
    constructor(scope: Construct, id: string, config: AwsReplicationTaskConfig);
    private _cdcStartPosition?;
    get cdcStartPosition(): string;
    set cdcStartPosition(value: string);
    resetCdcStartPosition(): void;
    get cdcStartPositionInput(): string | undefined;
    private _cdcStartTime?;
    get cdcStartTime(): string;
    set cdcStartTime(value: string);
    resetCdcStartTime(): void;
    get cdcStartTimeInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _migrationType?;
    get migrationType(): string;
    set migrationType(value: string);
    get migrationTypeInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _replicationInstanceArn?;
    get replicationInstanceArn(): string;
    set replicationInstanceArn(value: string);
    get replicationInstanceArnInput(): string | undefined;
    get replicationTaskArn(): string;
    private _replicationTaskId?;
    get replicationTaskId(): string;
    set replicationTaskId(value: string);
    get replicationTaskIdInput(): string | undefined;
    private _replicationTaskSettings?;
    get replicationTaskSettings(): string;
    set replicationTaskSettings(value: string);
    resetReplicationTaskSettings(): void;
    get replicationTaskSettingsInput(): string | undefined;
    private _resourceIdentifier?;
    get resourceIdentifier(): string;
    set resourceIdentifier(value: string);
    resetResourceIdentifier(): void;
    get resourceIdentifierInput(): string | undefined;
    private _sourceEndpointArn?;
    get sourceEndpointArn(): string;
    set sourceEndpointArn(value: string);
    get sourceEndpointArnInput(): string | undefined;
    private _startReplicationTask?;
    get startReplicationTask(): boolean | cdktn.IResolvable;
    set startReplicationTask(value: boolean | cdktn.IResolvable);
    resetStartReplicationTask(): void;
    get startReplicationTaskInput(): boolean | cdktn.IResolvable | undefined;
    get status(): string;
    private _tableMappings?;
    get tableMappings(): string;
    set tableMappings(value: string);
    get tableMappingsInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _targetEndpointArn?;
    get targetEndpointArn(): string;
    set targetEndpointArn(value: string);
    get targetEndpointArnInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
