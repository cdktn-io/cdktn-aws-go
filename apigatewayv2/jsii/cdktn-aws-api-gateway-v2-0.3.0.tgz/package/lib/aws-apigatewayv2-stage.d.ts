import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsStageConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apigatewayv2_stage#api_id AwsStage#api_id}
    */
    readonly apiId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apigatewayv2_stage#auto_deploy AwsStage#auto_deploy}
    */
    readonly autoDeploy?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apigatewayv2_stage#client_certificate_id AwsStage#client_certificate_id}
    */
    readonly clientCertificateId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apigatewayv2_stage#deployment_id AwsStage#deployment_id}
    */
    readonly deploymentId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apigatewayv2_stage#description AwsStage#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apigatewayv2_stage#id AwsStage#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apigatewayv2_stage#name AwsStage#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apigatewayv2_stage#region AwsStage#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apigatewayv2_stage#stage_variables AwsStage#stage_variables}
    */
    readonly stageVariables?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apigatewayv2_stage#tags AwsStage#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apigatewayv2_stage#tags_all AwsStage#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * access_log_settings block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apigatewayv2_stage#access_log_settings AwsStage#access_log_settings}
    */
    readonly accessLogSettings?: AwsStage.AccessLogSettingsProperty;
    /**
    * default_route_settings block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apigatewayv2_stage#default_route_settings AwsStage#default_route_settings}
    */
    readonly defaultRouteSettings?: AwsStage.DefaultRouteSettingsProperty;
    /**
    * route_settings block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apigatewayv2_stage#route_settings AwsStage#route_settings}
    */
    readonly routeSettings?: AwsStage.RouteSettingsProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apigatewayv2_stage aws_apigatewayv2_stage}
*/
export declare class AwsStage extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_apigatewayv2_stage";
    /**
    * Generates CDKTN code for importing a AwsStage resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsStage to import
    * @param importFromId The id of the existing AwsStage that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apigatewayv2_stage#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsStage to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apigatewayv2_stage aws_apigatewayv2_stage} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsStageConfig
    */
    constructor(scope: Construct, id: string, config: AwsStageConfig);
    private _apiId?;
    get apiId(): string;
    set apiId(value: string);
    get apiIdInput(): string | undefined;
    get arn(): string;
    private _autoDeploy?;
    get autoDeploy(): boolean | cdktn.IResolvable;
    set autoDeploy(value: boolean | cdktn.IResolvable);
    resetAutoDeploy(): void;
    get autoDeployInput(): boolean | cdktn.IResolvable | undefined;
    private _clientCertificateId?;
    get clientCertificateId(): string;
    set clientCertificateId(value: string);
    resetClientCertificateId(): void;
    get clientCertificateIdInput(): string | undefined;
    private _deploymentId?;
    get deploymentId(): string;
    set deploymentId(value: string);
    resetDeploymentId(): void;
    get deploymentIdInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get executionArn(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get invokeUrl(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _stageVariables?;
    get stageVariables(): {
        [key: string]: string;
    };
    set stageVariables(value: {
        [key: string]: string;
    });
    resetStageVariables(): void;
    get stageVariablesInput(): {
        [key: string]: string;
    } | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _accessLogSettings;
    get accessLogSettings(): AwsStage.AccessLogSettingsPropertyOutputReference;
    putAccessLogSettings(value: AwsStage.AccessLogSettingsProperty): void;
    resetAccessLogSettings(): void;
    get accessLogSettingsInput(): AwsStage.AccessLogSettingsProperty | undefined;
    private _defaultRouteSettings;
    get defaultRouteSettings(): AwsStage.DefaultRouteSettingsPropertyOutputReference;
    putDefaultRouteSettings(value: AwsStage.DefaultRouteSettingsProperty): void;
    resetDefaultRouteSettings(): void;
    get defaultRouteSettingsInput(): AwsStage.DefaultRouteSettingsProperty | undefined;
    private _routeSettings;
    get routeSettings(): AwsStage.RouteSettingsPropertyList;
    putRouteSettings(value: AwsStage.RouteSettingsProperty[] | cdktn.IResolvable): void;
    resetRouteSettings(): void;
    get routeSettingsInput(): cdktn.IResolvable | AwsStage.RouteSettingsProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsStageAccessLogSettingsPropertyToTerraform(struct?: AwsStage.AccessLogSettingsPropertyOutputReference | AwsStage.AccessLogSettingsProperty): any;
export declare function awsStageAccessLogSettingsPropertyToHclTerraform(struct?: AwsStage.AccessLogSettingsPropertyOutputReference | AwsStage.AccessLogSettingsProperty): any;
export declare function awsStageDefaultRouteSettingsPropertyToTerraform(struct?: AwsStage.DefaultRouteSettingsPropertyOutputReference | AwsStage.DefaultRouteSettingsProperty): any;
export declare function awsStageDefaultRouteSettingsPropertyToHclTerraform(struct?: AwsStage.DefaultRouteSettingsPropertyOutputReference | AwsStage.DefaultRouteSettingsProperty): any;
export declare function awsStageRouteSettingsPropertyToTerraform(struct?: AwsStage.RouteSettingsProperty | cdktn.IResolvable): any;
export declare function awsStageRouteSettingsPropertyToHclTerraform(struct?: AwsStage.RouteSettingsProperty | cdktn.IResolvable): any;
export declare namespace AwsStage {
    interface AccessLogSettingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apigatewayv2_stage#destination_arn AwsStage#destination_arn}
        */
        readonly destinationArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apigatewayv2_stage#format AwsStage#format}
        */
        readonly format: string;
    }
    class AccessLogSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AccessLogSettingsProperty | undefined;
        set internalValue(value: AccessLogSettingsProperty | undefined);
        private _destinationArn?;
        get destinationArn(): string;
        set destinationArn(value: string);
        get destinationArnInput(): string | undefined;
        private _format?;
        get format(): string;
        set format(value: string);
        get formatInput(): string | undefined;
    }
    interface DefaultRouteSettingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apigatewayv2_stage#data_trace_enabled AwsStage#data_trace_enabled}
        */
        readonly dataTraceEnabled?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apigatewayv2_stage#detailed_metrics_enabled AwsStage#detailed_metrics_enabled}
        */
        readonly detailedMetricsEnabled?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apigatewayv2_stage#logging_level AwsStage#logging_level}
        */
        readonly loggingLevel?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apigatewayv2_stage#throttling_burst_limit AwsStage#throttling_burst_limit}
        */
        readonly throttlingBurstLimit?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apigatewayv2_stage#throttling_rate_limit AwsStage#throttling_rate_limit}
        */
        readonly throttlingRateLimit?: number;
    }
    class DefaultRouteSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DefaultRouteSettingsProperty | undefined;
        set internalValue(value: DefaultRouteSettingsProperty | undefined);
        private _dataTraceEnabled?;
        get dataTraceEnabled(): boolean | cdktn.IResolvable;
        set dataTraceEnabled(value: boolean | cdktn.IResolvable);
        resetDataTraceEnabled(): void;
        get dataTraceEnabledInput(): boolean | cdktn.IResolvable | undefined;
        private _detailedMetricsEnabled?;
        get detailedMetricsEnabled(): boolean | cdktn.IResolvable;
        set detailedMetricsEnabled(value: boolean | cdktn.IResolvable);
        resetDetailedMetricsEnabled(): void;
        get detailedMetricsEnabledInput(): boolean | cdktn.IResolvable | undefined;
        private _loggingLevel?;
        get loggingLevel(): string;
        set loggingLevel(value: string);
        resetLoggingLevel(): void;
        get loggingLevelInput(): string | undefined;
        private _throttlingBurstLimit?;
        get throttlingBurstLimit(): number;
        set throttlingBurstLimit(value: number);
        resetThrottlingBurstLimit(): void;
        get throttlingBurstLimitInput(): number | undefined;
        private _throttlingRateLimit?;
        get throttlingRateLimit(): number;
        set throttlingRateLimit(value: number);
        resetThrottlingRateLimit(): void;
        get throttlingRateLimitInput(): number | undefined;
    }
    interface RouteSettingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apigatewayv2_stage#data_trace_enabled AwsStage#data_trace_enabled}
        */
        readonly dataTraceEnabled?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apigatewayv2_stage#detailed_metrics_enabled AwsStage#detailed_metrics_enabled}
        */
        readonly detailedMetricsEnabled?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apigatewayv2_stage#logging_level AwsStage#logging_level}
        */
        readonly loggingLevel?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apigatewayv2_stage#route_key AwsStage#route_key}
        */
        readonly routeKey: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apigatewayv2_stage#throttling_burst_limit AwsStage#throttling_burst_limit}
        */
        readonly throttlingBurstLimit?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apigatewayv2_stage#throttling_rate_limit AwsStage#throttling_rate_limit}
        */
        readonly throttlingRateLimit?: number;
    }
    class RouteSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RouteSettingsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RouteSettingsProperty | cdktn.IResolvable | undefined);
        private _dataTraceEnabled?;
        get dataTraceEnabled(): boolean | cdktn.IResolvable;
        set dataTraceEnabled(value: boolean | cdktn.IResolvable);
        resetDataTraceEnabled(): void;
        get dataTraceEnabledInput(): boolean | cdktn.IResolvable | undefined;
        private _detailedMetricsEnabled?;
        get detailedMetricsEnabled(): boolean | cdktn.IResolvable;
        set detailedMetricsEnabled(value: boolean | cdktn.IResolvable);
        resetDetailedMetricsEnabled(): void;
        get detailedMetricsEnabledInput(): boolean | cdktn.IResolvable | undefined;
        private _loggingLevel?;
        get loggingLevel(): string;
        set loggingLevel(value: string);
        resetLoggingLevel(): void;
        get loggingLevelInput(): string | undefined;
        private _routeKey?;
        get routeKey(): string;
        set routeKey(value: string);
        get routeKeyInput(): string | undefined;
        private _throttlingBurstLimit?;
        get throttlingBurstLimit(): number;
        set throttlingBurstLimit(value: number);
        resetThrottlingBurstLimit(): void;
        get throttlingBurstLimitInput(): number | undefined;
        private _throttlingRateLimit?;
        get throttlingRateLimit(): number;
        set throttlingRateLimit(value: number);
        resetThrottlingRateLimit(): void;
        get throttlingRateLimitInput(): number | undefined;
    }
    class RouteSettingsPropertyList extends cdktn.ComplexList {
        internalValue?: RouteSettingsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RouteSettingsPropertyOutputReference;
    }
}
