import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsArcregionswitchPlanConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#description AwsArcregionswitchPlan#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#execution_role AwsArcregionswitchPlan#execution_role}
    */
    readonly executionRole: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#name AwsArcregionswitchPlan#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#primary_region AwsArcregionswitchPlan#primary_region}
    */
    readonly primaryRegion?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#recovery_approach AwsArcregionswitchPlan#recovery_approach}
    */
    readonly recoveryApproach: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#recovery_time_objective_minutes AwsArcregionswitchPlan#recovery_time_objective_minutes}
    */
    readonly recoveryTimeObjectiveMinutes?: number;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#region AwsArcregionswitchPlan#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#regions AwsArcregionswitchPlan#regions}
    */
    readonly regions: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#tags AwsArcregionswitchPlan#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * associated_alarms block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#associated_alarms AwsArcregionswitchPlan#associated_alarms}
    */
    readonly associatedAlarms?: AwsArcregionswitchPlan.AssociatedAlarmsProperty[] | cdktn.IResolvable;
    /**
    * report_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#report_configuration AwsArcregionswitchPlan#report_configuration}
    */
    readonly reportConfiguration?: AwsArcregionswitchPlan.ReportConfigurationProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#timeouts AwsArcregionswitchPlan#timeouts}
    */
    readonly timeouts?: AwsArcregionswitchPlan.TimeoutsProperty;
    /**
    * triggers block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#triggers AwsArcregionswitchPlan#triggers}
    */
    readonly triggers?: AwsArcregionswitchPlan.TriggersProperty[] | cdktn.IResolvable;
    /**
    * workflow block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#workflow AwsArcregionswitchPlan#workflow}
    */
    readonly workflow?: AwsArcregionswitchPlan.WorkflowProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan aws_arcregionswitch_plan}
*/
export declare class AwsArcregionswitchPlan extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_arcregionswitch_plan";
    /**
    * Generates CDKTN code for importing a AwsArcregionswitchPlan resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsArcregionswitchPlan to import
    * @param importFromId The id of the existing AwsArcregionswitchPlan that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsArcregionswitchPlan to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan aws_arcregionswitch_plan} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsArcregionswitchPlanConfig
    */
    constructor(scope: Construct, id: string, config: AwsArcregionswitchPlanConfig);
    get arn(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _executionRole?;
    get executionRole(): string;
    set executionRole(value: string);
    get executionRoleInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _primaryRegion?;
    get primaryRegion(): string;
    set primaryRegion(value: string);
    resetPrimaryRegion(): void;
    get primaryRegionInput(): string | undefined;
    private _recoveryApproach?;
    get recoveryApproach(): string;
    set recoveryApproach(value: string);
    get recoveryApproachInput(): string | undefined;
    private _recoveryTimeObjectiveMinutes?;
    get recoveryTimeObjectiveMinutes(): number;
    set recoveryTimeObjectiveMinutes(value: number);
    resetRecoveryTimeObjectiveMinutes(): void;
    get recoveryTimeObjectiveMinutesInput(): number | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _regions?;
    get regions(): string[];
    set regions(value: string[]);
    get regionsInput(): string[] | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    private _associatedAlarms;
    get associatedAlarms(): AwsArcregionswitchPlan.AssociatedAlarmsPropertyList;
    putAssociatedAlarms(value: AwsArcregionswitchPlan.AssociatedAlarmsProperty[] | cdktn.IResolvable): void;
    resetAssociatedAlarms(): void;
    get associatedAlarmsInput(): cdktn.IResolvable | AwsArcregionswitchPlan.AssociatedAlarmsProperty[] | undefined;
    private _reportConfiguration;
    get reportConfiguration(): AwsArcregionswitchPlan.ReportConfigurationPropertyList;
    putReportConfiguration(value: AwsArcregionswitchPlan.ReportConfigurationProperty[] | cdktn.IResolvable): void;
    resetReportConfiguration(): void;
    get reportConfigurationInput(): cdktn.IResolvable | AwsArcregionswitchPlan.ReportConfigurationProperty[] | undefined;
    private _timeouts;
    get timeouts(): AwsArcregionswitchPlan.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsArcregionswitchPlan.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsArcregionswitchPlan.TimeoutsProperty | undefined;
    private _triggers;
    get triggers(): AwsArcregionswitchPlan.TriggersPropertyList;
    putTriggers(value: AwsArcregionswitchPlan.TriggersProperty[] | cdktn.IResolvable): void;
    resetTriggers(): void;
    get triggersInput(): cdktn.IResolvable | AwsArcregionswitchPlan.TriggersProperty[] | undefined;
    private _workflow;
    get workflow(): AwsArcregionswitchPlan.WorkflowPropertyList;
    putWorkflow(value: AwsArcregionswitchPlan.WorkflowProperty[] | cdktn.IResolvable): void;
    resetWorkflow(): void;
    get workflowInput(): cdktn.IResolvable | AwsArcregionswitchPlan.WorkflowProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsArcregionswitchPlanAssociatedAlarmsPropertyToTerraform(struct?: AwsArcregionswitchPlan.AssociatedAlarmsProperty | cdktn.IResolvable): any;
export declare function awsArcregionswitchPlanAssociatedAlarmsPropertyToHclTerraform(struct?: AwsArcregionswitchPlan.AssociatedAlarmsProperty | cdktn.IResolvable): any;
export declare function awsArcregionswitchPlanS3ConfigurationPropertyToTerraform(struct?: AwsArcregionswitchPlan.S3ConfigurationProperty | cdktn.IResolvable): any;
export declare function awsArcregionswitchPlanS3ConfigurationPropertyToHclTerraform(struct?: AwsArcregionswitchPlan.S3ConfigurationProperty | cdktn.IResolvable): any;
export declare function awsArcregionswitchPlanReportOutputPropertyToTerraform(struct?: AwsArcregionswitchPlan.ReportOutputProperty | cdktn.IResolvable): any;
export declare function awsArcregionswitchPlanReportOutputPropertyToHclTerraform(struct?: AwsArcregionswitchPlan.ReportOutputProperty | cdktn.IResolvable): any;
export declare function awsArcregionswitchPlanReportConfigurationPropertyToTerraform(struct?: AwsArcregionswitchPlan.ReportConfigurationProperty | cdktn.IResolvable): any;
export declare function awsArcregionswitchPlanReportConfigurationPropertyToHclTerraform(struct?: AwsArcregionswitchPlan.ReportConfigurationProperty | cdktn.IResolvable): any;
export declare function awsArcregionswitchPlanTimeoutsPropertyToTerraform(struct?: AwsArcregionswitchPlan.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsArcregionswitchPlanTimeoutsPropertyToHclTerraform(struct?: AwsArcregionswitchPlan.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsArcregionswitchPlanConditionsPropertyToTerraform(struct?: AwsArcregionswitchPlan.ConditionsProperty | cdktn.IResolvable): any;
export declare function awsArcregionswitchPlanConditionsPropertyToHclTerraform(struct?: AwsArcregionswitchPlan.ConditionsProperty | cdktn.IResolvable): any;
export declare function awsArcregionswitchPlanTriggersPropertyToTerraform(struct?: AwsArcregionswitchPlan.TriggersProperty | cdktn.IResolvable): any;
export declare function awsArcregionswitchPlanTriggersPropertyToHclTerraform(struct?: AwsArcregionswitchPlan.TriggersProperty | cdktn.IResolvable): any;
export declare function awsArcregionswitchPlanWorkflowStepArcRoutingControlConfigRegionAndRoutingControlsRoutingControlPropertyToTerraform(struct?: AwsArcregionswitchPlan.WorkflowStepArcRoutingControlConfigRegionAndRoutingControlsRoutingControlProperty | cdktn.IResolvable): any;
export declare function awsArcregionswitchPlanWorkflowStepArcRoutingControlConfigRegionAndRoutingControlsRoutingControlPropertyToHclTerraform(struct?: AwsArcregionswitchPlan.WorkflowStepArcRoutingControlConfigRegionAndRoutingControlsRoutingControlProperty | cdktn.IResolvable): any;
export declare function awsArcregionswitchPlanWorkflowStepArcRoutingControlConfigRegionAndRoutingControlsPropertyToTerraform(struct?: AwsArcregionswitchPlan.WorkflowStepArcRoutingControlConfigRegionAndRoutingControlsProperty | cdktn.IResolvable): any;
export declare function awsArcregionswitchPlanWorkflowStepArcRoutingControlConfigRegionAndRoutingControlsPropertyToHclTerraform(struct?: AwsArcregionswitchPlan.WorkflowStepArcRoutingControlConfigRegionAndRoutingControlsProperty | cdktn.IResolvable): any;
export declare function awsArcregionswitchPlanWorkflowStepArcRoutingControlConfigPropertyToTerraform(struct?: AwsArcregionswitchPlan.WorkflowStepArcRoutingControlConfigProperty | cdktn.IResolvable): any;
export declare function awsArcregionswitchPlanWorkflowStepArcRoutingControlConfigPropertyToHclTerraform(struct?: AwsArcregionswitchPlan.WorkflowStepArcRoutingControlConfigProperty | cdktn.IResolvable): any;
export declare function awsArcregionswitchPlanWorkflowStepAuroraProvisionedScalingConfigPropertyToTerraform(struct?: AwsArcregionswitchPlan.WorkflowStepAuroraProvisionedScalingConfigProperty | cdktn.IResolvable): any;
export declare function awsArcregionswitchPlanWorkflowStepAuroraProvisionedScalingConfigPropertyToHclTerraform(struct?: AwsArcregionswitchPlan.WorkflowStepAuroraProvisionedScalingConfigProperty | cdktn.IResolvable): any;
export declare function awsArcregionswitchPlanWorkflowStepAuroraServerlessScalingConfigPropertyToTerraform(struct?: AwsArcregionswitchPlan.WorkflowStepAuroraServerlessScalingConfigProperty | cdktn.IResolvable): any;
export declare function awsArcregionswitchPlanWorkflowStepAuroraServerlessScalingConfigPropertyToHclTerraform(struct?: AwsArcregionswitchPlan.WorkflowStepAuroraServerlessScalingConfigProperty | cdktn.IResolvable): any;
export declare function awsArcregionswitchPlanWorkflowStepCustomActionLambdaConfigLambdaPropertyToTerraform(struct?: AwsArcregionswitchPlan.WorkflowStepCustomActionLambdaConfigLambdaProperty | cdktn.IResolvable): any;
export declare function awsArcregionswitchPlanWorkflowStepCustomActionLambdaConfigLambdaPropertyToHclTerraform(struct?: AwsArcregionswitchPlan.WorkflowStepCustomActionLambdaConfigLambdaProperty | cdktn.IResolvable): any;
export declare function awsArcregionswitchPlanWorkflowStepCustomActionLambdaConfigUngracefulPropertyToTerraform(struct?: AwsArcregionswitchPlan.WorkflowStepCustomActionLambdaConfigUngracefulProperty | cdktn.IResolvable): any;
export declare function awsArcregionswitchPlanWorkflowStepCustomActionLambdaConfigUngracefulPropertyToHclTerraform(struct?: AwsArcregionswitchPlan.WorkflowStepCustomActionLambdaConfigUngracefulProperty | cdktn.IResolvable): any;
export declare function awsArcregionswitchPlanWorkflowStepCustomActionLambdaConfigPropertyToTerraform(struct?: AwsArcregionswitchPlan.WorkflowStepCustomActionLambdaConfigProperty | cdktn.IResolvable): any;
export declare function awsArcregionswitchPlanWorkflowStepCustomActionLambdaConfigPropertyToHclTerraform(struct?: AwsArcregionswitchPlan.WorkflowStepCustomActionLambdaConfigProperty | cdktn.IResolvable): any;
export declare function awsArcregionswitchPlanWorkflowStepDocumentDbConfigUngracefulPropertyToTerraform(struct?: AwsArcregionswitchPlan.WorkflowStepDocumentDbConfigUngracefulProperty | cdktn.IResolvable): any;
export declare function awsArcregionswitchPlanWorkflowStepDocumentDbConfigUngracefulPropertyToHclTerraform(struct?: AwsArcregionswitchPlan.WorkflowStepDocumentDbConfigUngracefulProperty | cdktn.IResolvable): any;
export declare function awsArcregionswitchPlanWorkflowStepDocumentDbConfigPropertyToTerraform(struct?: AwsArcregionswitchPlan.WorkflowStepDocumentDbConfigProperty | cdktn.IResolvable): any;
export declare function awsArcregionswitchPlanWorkflowStepDocumentDbConfigPropertyToHclTerraform(struct?: AwsArcregionswitchPlan.WorkflowStepDocumentDbConfigProperty | cdktn.IResolvable): any;
export declare function awsArcregionswitchPlanWorkflowStepEc2AsgCapacityIncreaseConfigAsgPropertyToTerraform(struct?: AwsArcregionswitchPlan.WorkflowStepEc2AsgCapacityIncreaseConfigAsgProperty | cdktn.IResolvable): any;
export declare function awsArcregionswitchPlanWorkflowStepEc2AsgCapacityIncreaseConfigAsgPropertyToHclTerraform(struct?: AwsArcregionswitchPlan.WorkflowStepEc2AsgCapacityIncreaseConfigAsgProperty | cdktn.IResolvable): any;
export declare function awsArcregionswitchPlanWorkflowStepEc2AsgCapacityIncreaseConfigUngracefulPropertyToTerraform(struct?: AwsArcregionswitchPlan.WorkflowStepEc2AsgCapacityIncreaseConfigUngracefulProperty | cdktn.IResolvable): any;
export declare function awsArcregionswitchPlanWorkflowStepEc2AsgCapacityIncreaseConfigUngracefulPropertyToHclTerraform(struct?: AwsArcregionswitchPlan.WorkflowStepEc2AsgCapacityIncreaseConfigUngracefulProperty | cdktn.IResolvable): any;
export declare function awsArcregionswitchPlanWorkflowStepEc2AsgCapacityIncreaseConfigPropertyToTerraform(struct?: AwsArcregionswitchPlan.WorkflowStepEc2AsgCapacityIncreaseConfigProperty | cdktn.IResolvable): any;
export declare function awsArcregionswitchPlanWorkflowStepEc2AsgCapacityIncreaseConfigPropertyToHclTerraform(struct?: AwsArcregionswitchPlan.WorkflowStepEc2AsgCapacityIncreaseConfigProperty | cdktn.IResolvable): any;
export declare function awsArcregionswitchPlanWorkflowStepEcsCapacityIncreaseConfigServicePropertyToTerraform(struct?: AwsArcregionswitchPlan.WorkflowStepEcsCapacityIncreaseConfigServiceProperty | cdktn.IResolvable): any;
export declare function awsArcregionswitchPlanWorkflowStepEcsCapacityIncreaseConfigServicePropertyToHclTerraform(struct?: AwsArcregionswitchPlan.WorkflowStepEcsCapacityIncreaseConfigServiceProperty | cdktn.IResolvable): any;
export declare function awsArcregionswitchPlanWorkflowStepEcsCapacityIncreaseConfigUngracefulPropertyToTerraform(struct?: AwsArcregionswitchPlan.WorkflowStepEcsCapacityIncreaseConfigUngracefulProperty | cdktn.IResolvable): any;
export declare function awsArcregionswitchPlanWorkflowStepEcsCapacityIncreaseConfigUngracefulPropertyToHclTerraform(struct?: AwsArcregionswitchPlan.WorkflowStepEcsCapacityIncreaseConfigUngracefulProperty | cdktn.IResolvable): any;
export declare function awsArcregionswitchPlanWorkflowStepEcsCapacityIncreaseConfigPropertyToTerraform(struct?: AwsArcregionswitchPlan.WorkflowStepEcsCapacityIncreaseConfigProperty | cdktn.IResolvable): any;
export declare function awsArcregionswitchPlanWorkflowStepEcsCapacityIncreaseConfigPropertyToHclTerraform(struct?: AwsArcregionswitchPlan.WorkflowStepEcsCapacityIncreaseConfigProperty | cdktn.IResolvable): any;
export declare function awsArcregionswitchPlanWorkflowStepEksResourceScalingConfigEksClustersPropertyToTerraform(struct?: AwsArcregionswitchPlan.WorkflowStepEksResourceScalingConfigEksClustersProperty | cdktn.IResolvable): any;
export declare function awsArcregionswitchPlanWorkflowStepEksResourceScalingConfigEksClustersPropertyToHclTerraform(struct?: AwsArcregionswitchPlan.WorkflowStepEksResourceScalingConfigEksClustersProperty | cdktn.IResolvable): any;
export declare function awsArcregionswitchPlanWorkflowStepEksResourceScalingConfigKubernetesResourceTypePropertyToTerraform(struct?: AwsArcregionswitchPlan.WorkflowStepEksResourceScalingConfigKubernetesResourceTypeProperty | cdktn.IResolvable): any;
export declare function awsArcregionswitchPlanWorkflowStepEksResourceScalingConfigKubernetesResourceTypePropertyToHclTerraform(struct?: AwsArcregionswitchPlan.WorkflowStepEksResourceScalingConfigKubernetesResourceTypeProperty | cdktn.IResolvable): any;
export declare function awsArcregionswitchPlanWorkflowStepEksResourceScalingConfigScalingResourcesResourcesPropertyToTerraform(struct?: AwsArcregionswitchPlan.WorkflowStepEksResourceScalingConfigScalingResourcesResourcesProperty | cdktn.IResolvable): any;
export declare function awsArcregionswitchPlanWorkflowStepEksResourceScalingConfigScalingResourcesResourcesPropertyToHclTerraform(struct?: AwsArcregionswitchPlan.WorkflowStepEksResourceScalingConfigScalingResourcesResourcesProperty | cdktn.IResolvable): any;
export declare function awsArcregionswitchPlanWorkflowStepEksResourceScalingConfigScalingResourcesPropertyToTerraform(struct?: AwsArcregionswitchPlan.WorkflowStepEksResourceScalingConfigScalingResourcesProperty | cdktn.IResolvable): any;
export declare function awsArcregionswitchPlanWorkflowStepEksResourceScalingConfigScalingResourcesPropertyToHclTerraform(struct?: AwsArcregionswitchPlan.WorkflowStepEksResourceScalingConfigScalingResourcesProperty | cdktn.IResolvable): any;
export declare function awsArcregionswitchPlanWorkflowStepEksResourceScalingConfigUngracefulPropertyToTerraform(struct?: AwsArcregionswitchPlan.WorkflowStepEksResourceScalingConfigUngracefulProperty | cdktn.IResolvable): any;
export declare function awsArcregionswitchPlanWorkflowStepEksResourceScalingConfigUngracefulPropertyToHclTerraform(struct?: AwsArcregionswitchPlan.WorkflowStepEksResourceScalingConfigUngracefulProperty | cdktn.IResolvable): any;
export declare function awsArcregionswitchPlanWorkflowStepEksResourceScalingConfigPropertyToTerraform(struct?: AwsArcregionswitchPlan.WorkflowStepEksResourceScalingConfigProperty | cdktn.IResolvable): any;
export declare function awsArcregionswitchPlanWorkflowStepEksResourceScalingConfigPropertyToHclTerraform(struct?: AwsArcregionswitchPlan.WorkflowStepEksResourceScalingConfigProperty | cdktn.IResolvable): any;
export declare function awsArcregionswitchPlanWorkflowStepExecutionApprovalConfigPropertyToTerraform(struct?: AwsArcregionswitchPlan.WorkflowStepExecutionApprovalConfigProperty | cdktn.IResolvable): any;
export declare function awsArcregionswitchPlanWorkflowStepExecutionApprovalConfigPropertyToHclTerraform(struct?: AwsArcregionswitchPlan.WorkflowStepExecutionApprovalConfigProperty | cdktn.IResolvable): any;
export declare function awsArcregionswitchPlanWorkflowStepGlobalAuroraConfigUngracefulPropertyToTerraform(struct?: AwsArcregionswitchPlan.WorkflowStepGlobalAuroraConfigUngracefulProperty | cdktn.IResolvable): any;
export declare function awsArcregionswitchPlanWorkflowStepGlobalAuroraConfigUngracefulPropertyToHclTerraform(struct?: AwsArcregionswitchPlan.WorkflowStepGlobalAuroraConfigUngracefulProperty | cdktn.IResolvable): any;
export declare function awsArcregionswitchPlanWorkflowStepGlobalAuroraConfigPropertyToTerraform(struct?: AwsArcregionswitchPlan.WorkflowStepGlobalAuroraConfigProperty | cdktn.IResolvable): any;
export declare function awsArcregionswitchPlanWorkflowStepGlobalAuroraConfigPropertyToHclTerraform(struct?: AwsArcregionswitchPlan.WorkflowStepGlobalAuroraConfigProperty | cdktn.IResolvable): any;
export declare function awsArcregionswitchPlanWorkflowStepLambdaEventSourceMappingConfigRegionEventSourceMappingPropertyToTerraform(struct?: AwsArcregionswitchPlan.WorkflowStepLambdaEventSourceMappingConfigRegionEventSourceMappingProperty | cdktn.IResolvable): any;
export declare function awsArcregionswitchPlanWorkflowStepLambdaEventSourceMappingConfigRegionEventSourceMappingPropertyToHclTerraform(struct?: AwsArcregionswitchPlan.WorkflowStepLambdaEventSourceMappingConfigRegionEventSourceMappingProperty | cdktn.IResolvable): any;
export declare function awsArcregionswitchPlanWorkflowStepLambdaEventSourceMappingConfigUngracefulPropertyToTerraform(struct?: AwsArcregionswitchPlan.WorkflowStepLambdaEventSourceMappingConfigUngracefulProperty | cdktn.IResolvable): any;
export declare function awsArcregionswitchPlanWorkflowStepLambdaEventSourceMappingConfigUngracefulPropertyToHclTerraform(struct?: AwsArcregionswitchPlan.WorkflowStepLambdaEventSourceMappingConfigUngracefulProperty | cdktn.IResolvable): any;
export declare function awsArcregionswitchPlanWorkflowStepLambdaEventSourceMappingConfigPropertyToTerraform(struct?: AwsArcregionswitchPlan.WorkflowStepLambdaEventSourceMappingConfigProperty | cdktn.IResolvable): any;
export declare function awsArcregionswitchPlanWorkflowStepLambdaEventSourceMappingConfigPropertyToHclTerraform(struct?: AwsArcregionswitchPlan.WorkflowStepLambdaEventSourceMappingConfigProperty | cdktn.IResolvable): any;
export declare function awsArcregionswitchPlanWorkflowStepNeptuneGlobalDatabaseConfigUngracefulPropertyToTerraform(struct?: AwsArcregionswitchPlan.WorkflowStepNeptuneGlobalDatabaseConfigUngracefulProperty | cdktn.IResolvable): any;
export declare function awsArcregionswitchPlanWorkflowStepNeptuneGlobalDatabaseConfigUngracefulPropertyToHclTerraform(struct?: AwsArcregionswitchPlan.WorkflowStepNeptuneGlobalDatabaseConfigUngracefulProperty | cdktn.IResolvable): any;
export declare function awsArcregionswitchPlanWorkflowStepNeptuneGlobalDatabaseConfigPropertyToTerraform(struct?: AwsArcregionswitchPlan.WorkflowStepNeptuneGlobalDatabaseConfigProperty | cdktn.IResolvable): any;
export declare function awsArcregionswitchPlanWorkflowStepNeptuneGlobalDatabaseConfigPropertyToHclTerraform(struct?: AwsArcregionswitchPlan.WorkflowStepNeptuneGlobalDatabaseConfigProperty | cdktn.IResolvable): any;
export declare function awsArcregionswitchPlanWorkflowStepParallelConfigStepArcRoutingControlConfigRegionAndRoutingControlsRoutingControlPropertyToTerraform(struct?: AwsArcregionswitchPlan.WorkflowStepParallelConfigStepArcRoutingControlConfigRegionAndRoutingControlsRoutingControlProperty | cdktn.IResolvable): any;
export declare function awsArcregionswitchPlanWorkflowStepParallelConfigStepArcRoutingControlConfigRegionAndRoutingControlsRoutingControlPropertyToHclTerraform(struct?: AwsArcregionswitchPlan.WorkflowStepParallelConfigStepArcRoutingControlConfigRegionAndRoutingControlsRoutingControlProperty | cdktn.IResolvable): any;
export declare function awsArcregionswitchPlanWorkflowStepParallelConfigStepArcRoutingControlConfigRegionAndRoutingControlsPropertyToTerraform(struct?: AwsArcregionswitchPlan.WorkflowStepParallelConfigStepArcRoutingControlConfigRegionAndRoutingControlsProperty | cdktn.IResolvable): any;
export declare function awsArcregionswitchPlanWorkflowStepParallelConfigStepArcRoutingControlConfigRegionAndRoutingControlsPropertyToHclTerraform(struct?: AwsArcregionswitchPlan.WorkflowStepParallelConfigStepArcRoutingControlConfigRegionAndRoutingControlsProperty | cdktn.IResolvable): any;
export declare function awsArcregionswitchPlanWorkflowStepParallelConfigStepArcRoutingControlConfigPropertyToTerraform(struct?: AwsArcregionswitchPlan.WorkflowStepParallelConfigStepArcRoutingControlConfigProperty | cdktn.IResolvable): any;
export declare function awsArcregionswitchPlanWorkflowStepParallelConfigStepArcRoutingControlConfigPropertyToHclTerraform(struct?: AwsArcregionswitchPlan.WorkflowStepParallelConfigStepArcRoutingControlConfigProperty | cdktn.IResolvable): any;
export declare function awsArcregionswitchPlanWorkflowStepParallelConfigStepAuroraProvisionedScalingConfigPropertyToTerraform(struct?: AwsArcregionswitchPlan.WorkflowStepParallelConfigStepAuroraProvisionedScalingConfigProperty | cdktn.IResolvable): any;
export declare function awsArcregionswitchPlanWorkflowStepParallelConfigStepAuroraProvisionedScalingConfigPropertyToHclTerraform(struct?: AwsArcregionswitchPlan.WorkflowStepParallelConfigStepAuroraProvisionedScalingConfigProperty | cdktn.IResolvable): any;
export declare function awsArcregionswitchPlanWorkflowStepParallelConfigStepAuroraServerlessScalingConfigPropertyToTerraform(struct?: AwsArcregionswitchPlan.WorkflowStepParallelConfigStepAuroraServerlessScalingConfigProperty | cdktn.IResolvable): any;
export declare function awsArcregionswitchPlanWorkflowStepParallelConfigStepAuroraServerlessScalingConfigPropertyToHclTerraform(struct?: AwsArcregionswitchPlan.WorkflowStepParallelConfigStepAuroraServerlessScalingConfigProperty | cdktn.IResolvable): any;
export declare function awsArcregionswitchPlanWorkflowStepParallelConfigStepCustomActionLambdaConfigLambdaPropertyToTerraform(struct?: AwsArcregionswitchPlan.WorkflowStepParallelConfigStepCustomActionLambdaConfigLambdaProperty | cdktn.IResolvable): any;
export declare function awsArcregionswitchPlanWorkflowStepParallelConfigStepCustomActionLambdaConfigLambdaPropertyToHclTerraform(struct?: AwsArcregionswitchPlan.WorkflowStepParallelConfigStepCustomActionLambdaConfigLambdaProperty | cdktn.IResolvable): any;
export declare function awsArcregionswitchPlanWorkflowStepParallelConfigStepCustomActionLambdaConfigUngracefulPropertyToTerraform(struct?: AwsArcregionswitchPlan.WorkflowStepParallelConfigStepCustomActionLambdaConfigUngracefulProperty | cdktn.IResolvable): any;
export declare function awsArcregionswitchPlanWorkflowStepParallelConfigStepCustomActionLambdaConfigUngracefulPropertyToHclTerraform(struct?: AwsArcregionswitchPlan.WorkflowStepParallelConfigStepCustomActionLambdaConfigUngracefulProperty | cdktn.IResolvable): any;
export declare function awsArcregionswitchPlanWorkflowStepParallelConfigStepCustomActionLambdaConfigPropertyToTerraform(struct?: AwsArcregionswitchPlan.WorkflowStepParallelConfigStepCustomActionLambdaConfigProperty | cdktn.IResolvable): any;
export declare function awsArcregionswitchPlanWorkflowStepParallelConfigStepCustomActionLambdaConfigPropertyToHclTerraform(struct?: AwsArcregionswitchPlan.WorkflowStepParallelConfigStepCustomActionLambdaConfigProperty | cdktn.IResolvable): any;
export declare function awsArcregionswitchPlanWorkflowStepParallelConfigStepDocumentDbConfigUngracefulPropertyToTerraform(struct?: AwsArcregionswitchPlan.WorkflowStepParallelConfigStepDocumentDbConfigUngracefulProperty | cdktn.IResolvable): any;
export declare function awsArcregionswitchPlanWorkflowStepParallelConfigStepDocumentDbConfigUngracefulPropertyToHclTerraform(struct?: AwsArcregionswitchPlan.WorkflowStepParallelConfigStepDocumentDbConfigUngracefulProperty | cdktn.IResolvable): any;
export declare function awsArcregionswitchPlanWorkflowStepParallelConfigStepDocumentDbConfigPropertyToTerraform(struct?: AwsArcregionswitchPlan.WorkflowStepParallelConfigStepDocumentDbConfigProperty | cdktn.IResolvable): any;
export declare function awsArcregionswitchPlanWorkflowStepParallelConfigStepDocumentDbConfigPropertyToHclTerraform(struct?: AwsArcregionswitchPlan.WorkflowStepParallelConfigStepDocumentDbConfigProperty | cdktn.IResolvable): any;
export declare function awsArcregionswitchPlanWorkflowStepParallelConfigStepEc2AsgCapacityIncreaseConfigAsgPropertyToTerraform(struct?: AwsArcregionswitchPlan.WorkflowStepParallelConfigStepEc2AsgCapacityIncreaseConfigAsgProperty | cdktn.IResolvable): any;
export declare function awsArcregionswitchPlanWorkflowStepParallelConfigStepEc2AsgCapacityIncreaseConfigAsgPropertyToHclTerraform(struct?: AwsArcregionswitchPlan.WorkflowStepParallelConfigStepEc2AsgCapacityIncreaseConfigAsgProperty | cdktn.IResolvable): any;
export declare function awsArcregionswitchPlanWorkflowStepParallelConfigStepEc2AsgCapacityIncreaseConfigUngracefulPropertyToTerraform(struct?: AwsArcregionswitchPlan.WorkflowStepParallelConfigStepEc2AsgCapacityIncreaseConfigUngracefulProperty | cdktn.IResolvable): any;
export declare function awsArcregionswitchPlanWorkflowStepParallelConfigStepEc2AsgCapacityIncreaseConfigUngracefulPropertyToHclTerraform(struct?: AwsArcregionswitchPlan.WorkflowStepParallelConfigStepEc2AsgCapacityIncreaseConfigUngracefulProperty | cdktn.IResolvable): any;
export declare function awsArcregionswitchPlanWorkflowStepParallelConfigStepEc2AsgCapacityIncreaseConfigPropertyToTerraform(struct?: AwsArcregionswitchPlan.WorkflowStepParallelConfigStepEc2AsgCapacityIncreaseConfigProperty | cdktn.IResolvable): any;
export declare function awsArcregionswitchPlanWorkflowStepParallelConfigStepEc2AsgCapacityIncreaseConfigPropertyToHclTerraform(struct?: AwsArcregionswitchPlan.WorkflowStepParallelConfigStepEc2AsgCapacityIncreaseConfigProperty | cdktn.IResolvable): any;
export declare function awsArcregionswitchPlanWorkflowStepParallelConfigStepEcsCapacityIncreaseConfigServicePropertyToTerraform(struct?: AwsArcregionswitchPlan.WorkflowStepParallelConfigStepEcsCapacityIncreaseConfigServiceProperty | cdktn.IResolvable): any;
export declare function awsArcregionswitchPlanWorkflowStepParallelConfigStepEcsCapacityIncreaseConfigServicePropertyToHclTerraform(struct?: AwsArcregionswitchPlan.WorkflowStepParallelConfigStepEcsCapacityIncreaseConfigServiceProperty | cdktn.IResolvable): any;
export declare function awsArcregionswitchPlanWorkflowStepParallelConfigStepEcsCapacityIncreaseConfigUngracefulPropertyToTerraform(struct?: AwsArcregionswitchPlan.WorkflowStepParallelConfigStepEcsCapacityIncreaseConfigUngracefulProperty | cdktn.IResolvable): any;
export declare function awsArcregionswitchPlanWorkflowStepParallelConfigStepEcsCapacityIncreaseConfigUngracefulPropertyToHclTerraform(struct?: AwsArcregionswitchPlan.WorkflowStepParallelConfigStepEcsCapacityIncreaseConfigUngracefulProperty | cdktn.IResolvable): any;
export declare function awsArcregionswitchPlanWorkflowStepParallelConfigStepEcsCapacityIncreaseConfigPropertyToTerraform(struct?: AwsArcregionswitchPlan.WorkflowStepParallelConfigStepEcsCapacityIncreaseConfigProperty | cdktn.IResolvable): any;
export declare function awsArcregionswitchPlanWorkflowStepParallelConfigStepEcsCapacityIncreaseConfigPropertyToHclTerraform(struct?: AwsArcregionswitchPlan.WorkflowStepParallelConfigStepEcsCapacityIncreaseConfigProperty | cdktn.IResolvable): any;
export declare function awsArcregionswitchPlanWorkflowStepParallelConfigStepEksResourceScalingConfigEksClustersPropertyToTerraform(struct?: AwsArcregionswitchPlan.WorkflowStepParallelConfigStepEksResourceScalingConfigEksClustersProperty | cdktn.IResolvable): any;
export declare function awsArcregionswitchPlanWorkflowStepParallelConfigStepEksResourceScalingConfigEksClustersPropertyToHclTerraform(struct?: AwsArcregionswitchPlan.WorkflowStepParallelConfigStepEksResourceScalingConfigEksClustersProperty | cdktn.IResolvable): any;
export declare function awsArcregionswitchPlanWorkflowStepParallelConfigStepEksResourceScalingConfigKubernetesResourceTypePropertyToTerraform(struct?: AwsArcregionswitchPlan.WorkflowStepParallelConfigStepEksResourceScalingConfigKubernetesResourceTypeProperty | cdktn.IResolvable): any;
export declare function awsArcregionswitchPlanWorkflowStepParallelConfigStepEksResourceScalingConfigKubernetesResourceTypePropertyToHclTerraform(struct?: AwsArcregionswitchPlan.WorkflowStepParallelConfigStepEksResourceScalingConfigKubernetesResourceTypeProperty | cdktn.IResolvable): any;
export declare function awsArcregionswitchPlanWorkflowStepParallelConfigStepEksResourceScalingConfigScalingResourcesResourcesPropertyToTerraform(struct?: AwsArcregionswitchPlan.WorkflowStepParallelConfigStepEksResourceScalingConfigScalingResourcesResourcesProperty | cdktn.IResolvable): any;
export declare function awsArcregionswitchPlanWorkflowStepParallelConfigStepEksResourceScalingConfigScalingResourcesResourcesPropertyToHclTerraform(struct?: AwsArcregionswitchPlan.WorkflowStepParallelConfigStepEksResourceScalingConfigScalingResourcesResourcesProperty | cdktn.IResolvable): any;
export declare function awsArcregionswitchPlanWorkflowStepParallelConfigStepEksResourceScalingConfigScalingResourcesPropertyToTerraform(struct?: AwsArcregionswitchPlan.WorkflowStepParallelConfigStepEksResourceScalingConfigScalingResourcesProperty | cdktn.IResolvable): any;
export declare function awsArcregionswitchPlanWorkflowStepParallelConfigStepEksResourceScalingConfigScalingResourcesPropertyToHclTerraform(struct?: AwsArcregionswitchPlan.WorkflowStepParallelConfigStepEksResourceScalingConfigScalingResourcesProperty | cdktn.IResolvable): any;
export declare function awsArcregionswitchPlanWorkflowStepParallelConfigStepEksResourceScalingConfigUngracefulPropertyToTerraform(struct?: AwsArcregionswitchPlan.WorkflowStepParallelConfigStepEksResourceScalingConfigUngracefulProperty | cdktn.IResolvable): any;
export declare function awsArcregionswitchPlanWorkflowStepParallelConfigStepEksResourceScalingConfigUngracefulPropertyToHclTerraform(struct?: AwsArcregionswitchPlan.WorkflowStepParallelConfigStepEksResourceScalingConfigUngracefulProperty | cdktn.IResolvable): any;
export declare function awsArcregionswitchPlanWorkflowStepParallelConfigStepEksResourceScalingConfigPropertyToTerraform(struct?: AwsArcregionswitchPlan.WorkflowStepParallelConfigStepEksResourceScalingConfigProperty | cdktn.IResolvable): any;
export declare function awsArcregionswitchPlanWorkflowStepParallelConfigStepEksResourceScalingConfigPropertyToHclTerraform(struct?: AwsArcregionswitchPlan.WorkflowStepParallelConfigStepEksResourceScalingConfigProperty | cdktn.IResolvable): any;
export declare function awsArcregionswitchPlanWorkflowStepParallelConfigStepExecutionApprovalConfigPropertyToTerraform(struct?: AwsArcregionswitchPlan.WorkflowStepParallelConfigStepExecutionApprovalConfigProperty | cdktn.IResolvable): any;
export declare function awsArcregionswitchPlanWorkflowStepParallelConfigStepExecutionApprovalConfigPropertyToHclTerraform(struct?: AwsArcregionswitchPlan.WorkflowStepParallelConfigStepExecutionApprovalConfigProperty | cdktn.IResolvable): any;
export declare function awsArcregionswitchPlanWorkflowStepParallelConfigStepGlobalAuroraConfigUngracefulPropertyToTerraform(struct?: AwsArcregionswitchPlan.WorkflowStepParallelConfigStepGlobalAuroraConfigUngracefulProperty | cdktn.IResolvable): any;
export declare function awsArcregionswitchPlanWorkflowStepParallelConfigStepGlobalAuroraConfigUngracefulPropertyToHclTerraform(struct?: AwsArcregionswitchPlan.WorkflowStepParallelConfigStepGlobalAuroraConfigUngracefulProperty | cdktn.IResolvable): any;
export declare function awsArcregionswitchPlanWorkflowStepParallelConfigStepGlobalAuroraConfigPropertyToTerraform(struct?: AwsArcregionswitchPlan.WorkflowStepParallelConfigStepGlobalAuroraConfigProperty | cdktn.IResolvable): any;
export declare function awsArcregionswitchPlanWorkflowStepParallelConfigStepGlobalAuroraConfigPropertyToHclTerraform(struct?: AwsArcregionswitchPlan.WorkflowStepParallelConfigStepGlobalAuroraConfigProperty | cdktn.IResolvable): any;
export declare function awsArcregionswitchPlanWorkflowStepParallelConfigStepLambdaEventSourceMappingConfigRegionEventSourceMappingPropertyToTerraform(struct?: AwsArcregionswitchPlan.WorkflowStepParallelConfigStepLambdaEventSourceMappingConfigRegionEventSourceMappingProperty | cdktn.IResolvable): any;
export declare function awsArcregionswitchPlanWorkflowStepParallelConfigStepLambdaEventSourceMappingConfigRegionEventSourceMappingPropertyToHclTerraform(struct?: AwsArcregionswitchPlan.WorkflowStepParallelConfigStepLambdaEventSourceMappingConfigRegionEventSourceMappingProperty | cdktn.IResolvable): any;
export declare function awsArcregionswitchPlanWorkflowStepParallelConfigStepLambdaEventSourceMappingConfigUngracefulPropertyToTerraform(struct?: AwsArcregionswitchPlan.WorkflowStepParallelConfigStepLambdaEventSourceMappingConfigUngracefulProperty | cdktn.IResolvable): any;
export declare function awsArcregionswitchPlanWorkflowStepParallelConfigStepLambdaEventSourceMappingConfigUngracefulPropertyToHclTerraform(struct?: AwsArcregionswitchPlan.WorkflowStepParallelConfigStepLambdaEventSourceMappingConfigUngracefulProperty | cdktn.IResolvable): any;
export declare function awsArcregionswitchPlanWorkflowStepParallelConfigStepLambdaEventSourceMappingConfigPropertyToTerraform(struct?: AwsArcregionswitchPlan.WorkflowStepParallelConfigStepLambdaEventSourceMappingConfigProperty | cdktn.IResolvable): any;
export declare function awsArcregionswitchPlanWorkflowStepParallelConfigStepLambdaEventSourceMappingConfigPropertyToHclTerraform(struct?: AwsArcregionswitchPlan.WorkflowStepParallelConfigStepLambdaEventSourceMappingConfigProperty | cdktn.IResolvable): any;
export declare function awsArcregionswitchPlanWorkflowStepParallelConfigStepNeptuneGlobalDatabaseConfigUngracefulPropertyToTerraform(struct?: AwsArcregionswitchPlan.WorkflowStepParallelConfigStepNeptuneGlobalDatabaseConfigUngracefulProperty | cdktn.IResolvable): any;
export declare function awsArcregionswitchPlanWorkflowStepParallelConfigStepNeptuneGlobalDatabaseConfigUngracefulPropertyToHclTerraform(struct?: AwsArcregionswitchPlan.WorkflowStepParallelConfigStepNeptuneGlobalDatabaseConfigUngracefulProperty | cdktn.IResolvable): any;
export declare function awsArcregionswitchPlanWorkflowStepParallelConfigStepNeptuneGlobalDatabaseConfigPropertyToTerraform(struct?: AwsArcregionswitchPlan.WorkflowStepParallelConfigStepNeptuneGlobalDatabaseConfigProperty | cdktn.IResolvable): any;
export declare function awsArcregionswitchPlanWorkflowStepParallelConfigStepNeptuneGlobalDatabaseConfigPropertyToHclTerraform(struct?: AwsArcregionswitchPlan.WorkflowStepParallelConfigStepNeptuneGlobalDatabaseConfigProperty | cdktn.IResolvable): any;
export declare function awsArcregionswitchPlanWorkflowStepParallelConfigStepRdsCreateCrossRegionReadReplicaConfigPropertyToTerraform(struct?: AwsArcregionswitchPlan.WorkflowStepParallelConfigStepRdsCreateCrossRegionReadReplicaConfigProperty | cdktn.IResolvable): any;
export declare function awsArcregionswitchPlanWorkflowStepParallelConfigStepRdsCreateCrossRegionReadReplicaConfigPropertyToHclTerraform(struct?: AwsArcregionswitchPlan.WorkflowStepParallelConfigStepRdsCreateCrossRegionReadReplicaConfigProperty | cdktn.IResolvable): any;
export declare function awsArcregionswitchPlanWorkflowStepParallelConfigStepRdsPromoteReadReplicaConfigPropertyToTerraform(struct?: AwsArcregionswitchPlan.WorkflowStepParallelConfigStepRdsPromoteReadReplicaConfigProperty | cdktn.IResolvable): any;
export declare function awsArcregionswitchPlanWorkflowStepParallelConfigStepRdsPromoteReadReplicaConfigPropertyToHclTerraform(struct?: AwsArcregionswitchPlan.WorkflowStepParallelConfigStepRdsPromoteReadReplicaConfigProperty | cdktn.IResolvable): any;
export declare function awsArcregionswitchPlanWorkflowStepParallelConfigStepRegionSwitchPlanConfigPropertyToTerraform(struct?: AwsArcregionswitchPlan.WorkflowStepParallelConfigStepRegionSwitchPlanConfigProperty | cdktn.IResolvable): any;
export declare function awsArcregionswitchPlanWorkflowStepParallelConfigStepRegionSwitchPlanConfigPropertyToHclTerraform(struct?: AwsArcregionswitchPlan.WorkflowStepParallelConfigStepRegionSwitchPlanConfigProperty | cdktn.IResolvable): any;
export declare function awsArcregionswitchPlanWorkflowStepParallelConfigStepRoute53HealthCheckConfigRecordSetPropertyToTerraform(struct?: AwsArcregionswitchPlan.WorkflowStepParallelConfigStepRoute53HealthCheckConfigRecordSetProperty | cdktn.IResolvable): any;
export declare function awsArcregionswitchPlanWorkflowStepParallelConfigStepRoute53HealthCheckConfigRecordSetPropertyToHclTerraform(struct?: AwsArcregionswitchPlan.WorkflowStepParallelConfigStepRoute53HealthCheckConfigRecordSetProperty | cdktn.IResolvable): any;
export declare function awsArcregionswitchPlanWorkflowStepParallelConfigStepRoute53HealthCheckConfigPropertyToTerraform(struct?: AwsArcregionswitchPlan.WorkflowStepParallelConfigStepRoute53HealthCheckConfigProperty | cdktn.IResolvable): any;
export declare function awsArcregionswitchPlanWorkflowStepParallelConfigStepRoute53HealthCheckConfigPropertyToHclTerraform(struct?: AwsArcregionswitchPlan.WorkflowStepParallelConfigStepRoute53HealthCheckConfigProperty | cdktn.IResolvable): any;
export declare function awsArcregionswitchPlanWorkflowStepParallelConfigStepPropertyToTerraform(struct?: AwsArcregionswitchPlan.WorkflowStepParallelConfigStepProperty | cdktn.IResolvable): any;
export declare function awsArcregionswitchPlanWorkflowStepParallelConfigStepPropertyToHclTerraform(struct?: AwsArcregionswitchPlan.WorkflowStepParallelConfigStepProperty | cdktn.IResolvable): any;
export declare function awsArcregionswitchPlanParallelConfigPropertyToTerraform(struct?: AwsArcregionswitchPlan.ParallelConfigProperty | cdktn.IResolvable): any;
export declare function awsArcregionswitchPlanParallelConfigPropertyToHclTerraform(struct?: AwsArcregionswitchPlan.ParallelConfigProperty | cdktn.IResolvable): any;
export declare function awsArcregionswitchPlanWorkflowStepRdsCreateCrossRegionReadReplicaConfigPropertyToTerraform(struct?: AwsArcregionswitchPlan.WorkflowStepRdsCreateCrossRegionReadReplicaConfigProperty | cdktn.IResolvable): any;
export declare function awsArcregionswitchPlanWorkflowStepRdsCreateCrossRegionReadReplicaConfigPropertyToHclTerraform(struct?: AwsArcregionswitchPlan.WorkflowStepRdsCreateCrossRegionReadReplicaConfigProperty | cdktn.IResolvable): any;
export declare function awsArcregionswitchPlanWorkflowStepRdsPromoteReadReplicaConfigPropertyToTerraform(struct?: AwsArcregionswitchPlan.WorkflowStepRdsPromoteReadReplicaConfigProperty | cdktn.IResolvable): any;
export declare function awsArcregionswitchPlanWorkflowStepRdsPromoteReadReplicaConfigPropertyToHclTerraform(struct?: AwsArcregionswitchPlan.WorkflowStepRdsPromoteReadReplicaConfigProperty | cdktn.IResolvable): any;
export declare function awsArcregionswitchPlanWorkflowStepRegionSwitchPlanConfigPropertyToTerraform(struct?: AwsArcregionswitchPlan.WorkflowStepRegionSwitchPlanConfigProperty | cdktn.IResolvable): any;
export declare function awsArcregionswitchPlanWorkflowStepRegionSwitchPlanConfigPropertyToHclTerraform(struct?: AwsArcregionswitchPlan.WorkflowStepRegionSwitchPlanConfigProperty | cdktn.IResolvable): any;
export declare function awsArcregionswitchPlanWorkflowStepRoute53HealthCheckConfigRecordSetPropertyToTerraform(struct?: AwsArcregionswitchPlan.WorkflowStepRoute53HealthCheckConfigRecordSetProperty | cdktn.IResolvable): any;
export declare function awsArcregionswitchPlanWorkflowStepRoute53HealthCheckConfigRecordSetPropertyToHclTerraform(struct?: AwsArcregionswitchPlan.WorkflowStepRoute53HealthCheckConfigRecordSetProperty | cdktn.IResolvable): any;
export declare function awsArcregionswitchPlanWorkflowStepRoute53HealthCheckConfigPropertyToTerraform(struct?: AwsArcregionswitchPlan.WorkflowStepRoute53HealthCheckConfigProperty | cdktn.IResolvable): any;
export declare function awsArcregionswitchPlanWorkflowStepRoute53HealthCheckConfigPropertyToHclTerraform(struct?: AwsArcregionswitchPlan.WorkflowStepRoute53HealthCheckConfigProperty | cdktn.IResolvable): any;
export declare function awsArcregionswitchPlanWorkflowStepPropertyToTerraform(struct?: AwsArcregionswitchPlan.WorkflowStepProperty | cdktn.IResolvable): any;
export declare function awsArcregionswitchPlanWorkflowStepPropertyToHclTerraform(struct?: AwsArcregionswitchPlan.WorkflowStepProperty | cdktn.IResolvable): any;
export declare function awsArcregionswitchPlanWorkflowPropertyToTerraform(struct?: AwsArcregionswitchPlan.WorkflowProperty | cdktn.IResolvable): any;
export declare function awsArcregionswitchPlanWorkflowPropertyToHclTerraform(struct?: AwsArcregionswitchPlan.WorkflowProperty | cdktn.IResolvable): any;
export declare namespace AwsArcregionswitchPlan {
    interface AssociatedAlarmsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#alarm_type AwsArcregionswitchPlan#alarm_type}
        */
        readonly alarmType: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#cross_account_role AwsArcregionswitchPlan#cross_account_role}
        */
        readonly crossAccountRole?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#external_id AwsArcregionswitchPlan#external_id}
        */
        readonly externalId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#map_block_key AwsArcregionswitchPlan#map_block_key}
        */
        readonly mapBlockKey: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#resource_identifier AwsArcregionswitchPlan#resource_identifier}
        */
        readonly resourceIdentifier: string;
    }
    class AssociatedAlarmsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AssociatedAlarmsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: AssociatedAlarmsProperty | cdktn.IResolvable | undefined);
        private _alarmType?;
        get alarmType(): string;
        set alarmType(value: string);
        get alarmTypeInput(): string | undefined;
        private _crossAccountRole?;
        get crossAccountRole(): string;
        set crossAccountRole(value: string);
        resetCrossAccountRole(): void;
        get crossAccountRoleInput(): string | undefined;
        private _externalId?;
        get externalId(): string;
        set externalId(value: string);
        resetExternalId(): void;
        get externalIdInput(): string | undefined;
        private _mapBlockKey?;
        get mapBlockKey(): string;
        set mapBlockKey(value: string);
        get mapBlockKeyInput(): string | undefined;
        private _resourceIdentifier?;
        get resourceIdentifier(): string;
        set resourceIdentifier(value: string);
        get resourceIdentifierInput(): string | undefined;
    }
    class AssociatedAlarmsPropertyList extends cdktn.ComplexList {
        internalValue?: AssociatedAlarmsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AssociatedAlarmsPropertyOutputReference;
    }
    interface S3ConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#bucket_owner AwsArcregionswitchPlan#bucket_owner}
        */
        readonly bucketOwner: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#bucket_path AwsArcregionswitchPlan#bucket_path}
        */
        readonly bucketPath: string;
    }
    class S3ConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): S3ConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: S3ConfigurationProperty | cdktn.IResolvable | undefined);
        private _bucketOwner?;
        get bucketOwner(): string;
        set bucketOwner(value: string);
        get bucketOwnerInput(): string | undefined;
        private _bucketPath?;
        get bucketPath(): string;
        set bucketPath(value: string);
        get bucketPathInput(): string | undefined;
    }
    class S3ConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: S3ConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): S3ConfigurationPropertyOutputReference;
    }
    interface ReportOutputProperty {
        /**
        * s3_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#s3_configuration AwsArcregionswitchPlan#s3_configuration}
        */
        readonly s3Configuration?: S3ConfigurationProperty[] | cdktn.IResolvable;
    }
    class ReportOutputPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ReportOutputProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ReportOutputProperty | cdktn.IResolvable | undefined);
        private _s3Configuration;
        get s3Configuration(): S3ConfigurationPropertyList;
        putS3Configuration(value: S3ConfigurationProperty[] | cdktn.IResolvable): void;
        resetS3Configuration(): void;
        get s3ConfigurationInput(): cdktn.IResolvable | S3ConfigurationProperty[] | undefined;
    }
    class ReportOutputPropertyList extends cdktn.ComplexList {
        internalValue?: ReportOutputProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ReportOutputPropertyOutputReference;
    }
    interface ReportConfigurationProperty {
        /**
        * report_output block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#report_output AwsArcregionswitchPlan#report_output}
        */
        readonly reportOutput?: ReportOutputProperty[] | cdktn.IResolvable;
    }
    class ReportConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ReportConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ReportConfigurationProperty | cdktn.IResolvable | undefined);
        private _reportOutput;
        get reportOutput(): ReportOutputPropertyList;
        putReportOutput(value: ReportOutputProperty[] | cdktn.IResolvable): void;
        resetReportOutput(): void;
        get reportOutputInput(): cdktn.IResolvable | ReportOutputProperty[] | undefined;
    }
    class ReportConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: ReportConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ReportConfigurationPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#create AwsArcregionswitchPlan#create}
        */
        readonly create?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Setting a timeout for a Delete operation is only applicable if changes are saved into state before the destroy operation occurs.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#delete AwsArcregionswitchPlan#delete}
        */
        readonly delete?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#update AwsArcregionswitchPlan#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
    interface ConditionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#associated_alarm_name AwsArcregionswitchPlan#associated_alarm_name}
        */
        readonly associatedAlarmName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#condition AwsArcregionswitchPlan#condition}
        */
        readonly condition: string;
    }
    class ConditionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ConditionsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ConditionsProperty | cdktn.IResolvable | undefined);
        private _associatedAlarmName?;
        get associatedAlarmName(): string;
        set associatedAlarmName(value: string);
        get associatedAlarmNameInput(): string | undefined;
        private _condition?;
        get condition(): string;
        set condition(value: string);
        get conditionInput(): string | undefined;
    }
    class ConditionsPropertyList extends cdktn.ComplexList {
        internalValue?: ConditionsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ConditionsPropertyOutputReference;
    }
    interface TriggersProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#action AwsArcregionswitchPlan#action}
        */
        readonly action: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#description AwsArcregionswitchPlan#description}
        */
        readonly description?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#min_delay_minutes_between_executions AwsArcregionswitchPlan#min_delay_minutes_between_executions}
        */
        readonly minDelayMinutesBetweenExecutions: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#target_region AwsArcregionswitchPlan#target_region}
        */
        readonly targetRegion: string;
        /**
        * conditions block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#conditions AwsArcregionswitchPlan#conditions}
        */
        readonly conditions?: ConditionsProperty[] | cdktn.IResolvable;
    }
    class TriggersPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TriggersProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TriggersProperty | cdktn.IResolvable | undefined);
        private _action?;
        get action(): string;
        set action(value: string);
        get actionInput(): string | undefined;
        private _description?;
        get description(): string;
        set description(value: string);
        resetDescription(): void;
        get descriptionInput(): string | undefined;
        private _minDelayMinutesBetweenExecutions?;
        get minDelayMinutesBetweenExecutions(): number;
        set minDelayMinutesBetweenExecutions(value: number);
        get minDelayMinutesBetweenExecutionsInput(): number | undefined;
        private _targetRegion?;
        get targetRegion(): string;
        set targetRegion(value: string);
        get targetRegionInput(): string | undefined;
        private _conditions;
        get conditions(): ConditionsPropertyList;
        putConditions(value: ConditionsProperty[] | cdktn.IResolvable): void;
        resetConditions(): void;
        get conditionsInput(): cdktn.IResolvable | ConditionsProperty[] | undefined;
    }
    class TriggersPropertyList extends cdktn.ComplexList {
        internalValue?: TriggersProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TriggersPropertyOutputReference;
    }
    interface WorkflowStepArcRoutingControlConfigRegionAndRoutingControlsRoutingControlProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#routing_control_arn AwsArcregionswitchPlan#routing_control_arn}
        */
        readonly routingControlArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#state AwsArcregionswitchPlan#state}
        */
        readonly state: string;
    }
    class WorkflowStepArcRoutingControlConfigRegionAndRoutingControlsRoutingControlPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepArcRoutingControlConfigRegionAndRoutingControlsRoutingControlProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepArcRoutingControlConfigRegionAndRoutingControlsRoutingControlProperty | cdktn.IResolvable | undefined);
        private _routingControlArn?;
        get routingControlArn(): string;
        set routingControlArn(value: string);
        get routingControlArnInput(): string | undefined;
        private _state?;
        get state(): string;
        set state(value: string);
        get stateInput(): string | undefined;
    }
    class WorkflowStepArcRoutingControlConfigRegionAndRoutingControlsRoutingControlPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepArcRoutingControlConfigRegionAndRoutingControlsRoutingControlProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepArcRoutingControlConfigRegionAndRoutingControlsRoutingControlPropertyOutputReference;
    }
    interface WorkflowStepArcRoutingControlConfigRegionAndRoutingControlsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#region AwsArcregionswitchPlan#region}
        */
        readonly region: string;
        /**
        * routing_control block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#routing_control AwsArcregionswitchPlan#routing_control}
        */
        readonly routingControl?: WorkflowStepArcRoutingControlConfigRegionAndRoutingControlsRoutingControlProperty[] | cdktn.IResolvable;
    }
    class WorkflowStepArcRoutingControlConfigRegionAndRoutingControlsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepArcRoutingControlConfigRegionAndRoutingControlsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepArcRoutingControlConfigRegionAndRoutingControlsProperty | cdktn.IResolvable | undefined);
        private _region?;
        get region(): string;
        set region(value: string);
        get regionInput(): string | undefined;
        private _routingControl;
        get routingControl(): WorkflowStepArcRoutingControlConfigRegionAndRoutingControlsRoutingControlPropertyList;
        putRoutingControl(value: WorkflowStepArcRoutingControlConfigRegionAndRoutingControlsRoutingControlProperty[] | cdktn.IResolvable): void;
        resetRoutingControl(): void;
        get routingControlInput(): cdktn.IResolvable | WorkflowStepArcRoutingControlConfigRegionAndRoutingControlsRoutingControlProperty[] | undefined;
    }
    class WorkflowStepArcRoutingControlConfigRegionAndRoutingControlsPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepArcRoutingControlConfigRegionAndRoutingControlsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepArcRoutingControlConfigRegionAndRoutingControlsPropertyOutputReference;
    }
    interface WorkflowStepArcRoutingControlConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#cross_account_role AwsArcregionswitchPlan#cross_account_role}
        */
        readonly crossAccountRole?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#external_id AwsArcregionswitchPlan#external_id}
        */
        readonly externalId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#timeout_minutes AwsArcregionswitchPlan#timeout_minutes}
        */
        readonly timeoutMinutes?: number;
        /**
        * region_and_routing_controls block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#region_and_routing_controls AwsArcregionswitchPlan#region_and_routing_controls}
        */
        readonly regionAndRoutingControls?: WorkflowStepArcRoutingControlConfigRegionAndRoutingControlsProperty[] | cdktn.IResolvable;
    }
    class WorkflowStepArcRoutingControlConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepArcRoutingControlConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepArcRoutingControlConfigProperty | cdktn.IResolvable | undefined);
        private _crossAccountRole?;
        get crossAccountRole(): string;
        set crossAccountRole(value: string);
        resetCrossAccountRole(): void;
        get crossAccountRoleInput(): string | undefined;
        private _externalId?;
        get externalId(): string;
        set externalId(value: string);
        resetExternalId(): void;
        get externalIdInput(): string | undefined;
        private _timeoutMinutes?;
        get timeoutMinutes(): number;
        set timeoutMinutes(value: number);
        resetTimeoutMinutes(): void;
        get timeoutMinutesInput(): number | undefined;
        private _regionAndRoutingControls;
        get regionAndRoutingControls(): WorkflowStepArcRoutingControlConfigRegionAndRoutingControlsPropertyList;
        putRegionAndRoutingControls(value: WorkflowStepArcRoutingControlConfigRegionAndRoutingControlsProperty[] | cdktn.IResolvable): void;
        resetRegionAndRoutingControls(): void;
        get regionAndRoutingControlsInput(): cdktn.IResolvable | WorkflowStepArcRoutingControlConfigRegionAndRoutingControlsProperty[] | undefined;
    }
    class WorkflowStepArcRoutingControlConfigPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepArcRoutingControlConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepArcRoutingControlConfigPropertyOutputReference;
    }
    interface WorkflowStepAuroraProvisionedScalingConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#cross_account_role AwsArcregionswitchPlan#cross_account_role}
        */
        readonly crossAccountRole?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#external_id AwsArcregionswitchPlan#external_id}
        */
        readonly externalId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#global_cluster_identifier AwsArcregionswitchPlan#global_cluster_identifier}
        */
        readonly globalClusterIdentifier: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#instance_arns AwsArcregionswitchPlan#instance_arns}
        */
        readonly instanceArns: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#region_database_cluster_arns AwsArcregionswitchPlan#region_database_cluster_arns}
        */
        readonly regionDatabaseClusterArns: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#timeout_minutes AwsArcregionswitchPlan#timeout_minutes}
        */
        readonly timeoutMinutes?: number;
    }
    class WorkflowStepAuroraProvisionedScalingConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepAuroraProvisionedScalingConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepAuroraProvisionedScalingConfigProperty | cdktn.IResolvable | undefined);
        private _crossAccountRole?;
        get crossAccountRole(): string;
        set crossAccountRole(value: string);
        resetCrossAccountRole(): void;
        get crossAccountRoleInput(): string | undefined;
        private _externalId?;
        get externalId(): string;
        set externalId(value: string);
        resetExternalId(): void;
        get externalIdInput(): string | undefined;
        private _globalClusterIdentifier?;
        get globalClusterIdentifier(): string;
        set globalClusterIdentifier(value: string);
        get globalClusterIdentifierInput(): string | undefined;
        private _instanceArns?;
        get instanceArns(): {
            [key: string]: string;
        };
        set instanceArns(value: {
            [key: string]: string;
        });
        get instanceArnsInput(): {
            [key: string]: string;
        } | undefined;
        private _regionDatabaseClusterArns?;
        get regionDatabaseClusterArns(): {
            [key: string]: string;
        };
        set regionDatabaseClusterArns(value: {
            [key: string]: string;
        });
        get regionDatabaseClusterArnsInput(): {
            [key: string]: string;
        } | undefined;
        private _timeoutMinutes?;
        get timeoutMinutes(): number;
        set timeoutMinutes(value: number);
        resetTimeoutMinutes(): void;
        get timeoutMinutesInput(): number | undefined;
    }
    class WorkflowStepAuroraProvisionedScalingConfigPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepAuroraProvisionedScalingConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepAuroraProvisionedScalingConfigPropertyOutputReference;
    }
    interface WorkflowStepAuroraServerlessScalingConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#cross_account_role AwsArcregionswitchPlan#cross_account_role}
        */
        readonly crossAccountRole?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#external_id AwsArcregionswitchPlan#external_id}
        */
        readonly externalId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#global_cluster_identifier AwsArcregionswitchPlan#global_cluster_identifier}
        */
        readonly globalClusterIdentifier: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#region_database_cluster_arns AwsArcregionswitchPlan#region_database_cluster_arns}
        */
        readonly regionDatabaseClusterArns: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#target_percent AwsArcregionswitchPlan#target_percent}
        */
        readonly targetPercent?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#timeout_minutes AwsArcregionswitchPlan#timeout_minutes}
        */
        readonly timeoutMinutes?: number;
    }
    class WorkflowStepAuroraServerlessScalingConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepAuroraServerlessScalingConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepAuroraServerlessScalingConfigProperty | cdktn.IResolvable | undefined);
        private _crossAccountRole?;
        get crossAccountRole(): string;
        set crossAccountRole(value: string);
        resetCrossAccountRole(): void;
        get crossAccountRoleInput(): string | undefined;
        private _externalId?;
        get externalId(): string;
        set externalId(value: string);
        resetExternalId(): void;
        get externalIdInput(): string | undefined;
        private _globalClusterIdentifier?;
        get globalClusterIdentifier(): string;
        set globalClusterIdentifier(value: string);
        get globalClusterIdentifierInput(): string | undefined;
        private _regionDatabaseClusterArns?;
        get regionDatabaseClusterArns(): {
            [key: string]: string;
        };
        set regionDatabaseClusterArns(value: {
            [key: string]: string;
        });
        get regionDatabaseClusterArnsInput(): {
            [key: string]: string;
        } | undefined;
        private _targetPercent?;
        get targetPercent(): number;
        set targetPercent(value: number);
        resetTargetPercent(): void;
        get targetPercentInput(): number | undefined;
        private _timeoutMinutes?;
        get timeoutMinutes(): number;
        set timeoutMinutes(value: number);
        resetTimeoutMinutes(): void;
        get timeoutMinutesInput(): number | undefined;
    }
    class WorkflowStepAuroraServerlessScalingConfigPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepAuroraServerlessScalingConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepAuroraServerlessScalingConfigPropertyOutputReference;
    }
    interface WorkflowStepCustomActionLambdaConfigLambdaProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#arn AwsArcregionswitchPlan#arn}
        */
        readonly arn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#cross_account_role AwsArcregionswitchPlan#cross_account_role}
        */
        readonly crossAccountRole?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#external_id AwsArcregionswitchPlan#external_id}
        */
        readonly externalId?: string;
    }
    class WorkflowStepCustomActionLambdaConfigLambdaPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepCustomActionLambdaConfigLambdaProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepCustomActionLambdaConfigLambdaProperty | cdktn.IResolvable | undefined);
        private _arn?;
        get arn(): string;
        set arn(value: string);
        get arnInput(): string | undefined;
        private _crossAccountRole?;
        get crossAccountRole(): string;
        set crossAccountRole(value: string);
        resetCrossAccountRole(): void;
        get crossAccountRoleInput(): string | undefined;
        private _externalId?;
        get externalId(): string;
        set externalId(value: string);
        resetExternalId(): void;
        get externalIdInput(): string | undefined;
    }
    class WorkflowStepCustomActionLambdaConfigLambdaPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepCustomActionLambdaConfigLambdaProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepCustomActionLambdaConfigLambdaPropertyOutputReference;
    }
    interface WorkflowStepCustomActionLambdaConfigUngracefulProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#behavior AwsArcregionswitchPlan#behavior}
        */
        readonly behavior: string;
    }
    class WorkflowStepCustomActionLambdaConfigUngracefulPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepCustomActionLambdaConfigUngracefulProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepCustomActionLambdaConfigUngracefulProperty | cdktn.IResolvable | undefined);
        private _behavior?;
        get behavior(): string;
        set behavior(value: string);
        get behaviorInput(): string | undefined;
    }
    class WorkflowStepCustomActionLambdaConfigUngracefulPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepCustomActionLambdaConfigUngracefulProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepCustomActionLambdaConfigUngracefulPropertyOutputReference;
    }
    interface WorkflowStepCustomActionLambdaConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#region_to_run AwsArcregionswitchPlan#region_to_run}
        */
        readonly regionToRun: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#retry_interval_minutes AwsArcregionswitchPlan#retry_interval_minutes}
        */
        readonly retryIntervalMinutes: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#timeout_minutes AwsArcregionswitchPlan#timeout_minutes}
        */
        readonly timeoutMinutes?: number;
        /**
        * lambda block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#lambda AwsArcregionswitchPlan#lambda}
        */
        readonly lambda?: WorkflowStepCustomActionLambdaConfigLambdaProperty[] | cdktn.IResolvable;
        /**
        * ungraceful block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#ungraceful AwsArcregionswitchPlan#ungraceful}
        */
        readonly ungraceful?: WorkflowStepCustomActionLambdaConfigUngracefulProperty[] | cdktn.IResolvable;
    }
    class WorkflowStepCustomActionLambdaConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepCustomActionLambdaConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepCustomActionLambdaConfigProperty | cdktn.IResolvable | undefined);
        private _regionToRun?;
        get regionToRun(): string;
        set regionToRun(value: string);
        get regionToRunInput(): string | undefined;
        private _retryIntervalMinutes?;
        get retryIntervalMinutes(): number;
        set retryIntervalMinutes(value: number);
        get retryIntervalMinutesInput(): number | undefined;
        private _timeoutMinutes?;
        get timeoutMinutes(): number;
        set timeoutMinutes(value: number);
        resetTimeoutMinutes(): void;
        get timeoutMinutesInput(): number | undefined;
        private _lambda;
        get lambda(): WorkflowStepCustomActionLambdaConfigLambdaPropertyList;
        putLambda(value: WorkflowStepCustomActionLambdaConfigLambdaProperty[] | cdktn.IResolvable): void;
        resetLambda(): void;
        get lambdaInput(): cdktn.IResolvable | WorkflowStepCustomActionLambdaConfigLambdaProperty[] | undefined;
        private _ungraceful;
        get ungraceful(): WorkflowStepCustomActionLambdaConfigUngracefulPropertyList;
        putUngraceful(value: WorkflowStepCustomActionLambdaConfigUngracefulProperty[] | cdktn.IResolvable): void;
        resetUngraceful(): void;
        get ungracefulInput(): cdktn.IResolvable | WorkflowStepCustomActionLambdaConfigUngracefulProperty[] | undefined;
    }
    class WorkflowStepCustomActionLambdaConfigPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepCustomActionLambdaConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepCustomActionLambdaConfigPropertyOutputReference;
    }
    interface WorkflowStepDocumentDbConfigUngracefulProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#ungraceful AwsArcregionswitchPlan#ungraceful}
        */
        readonly ungraceful: string;
    }
    class WorkflowStepDocumentDbConfigUngracefulPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepDocumentDbConfigUngracefulProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepDocumentDbConfigUngracefulProperty | cdktn.IResolvable | undefined);
        private _ungraceful?;
        get ungraceful(): string;
        set ungraceful(value: string);
        get ungracefulInput(): string | undefined;
    }
    class WorkflowStepDocumentDbConfigUngracefulPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepDocumentDbConfigUngracefulProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepDocumentDbConfigUngracefulPropertyOutputReference;
    }
    interface WorkflowStepDocumentDbConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#behavior AwsArcregionswitchPlan#behavior}
        */
        readonly behavior: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#cross_account_role AwsArcregionswitchPlan#cross_account_role}
        */
        readonly crossAccountRole?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#database_cluster_arns AwsArcregionswitchPlan#database_cluster_arns}
        */
        readonly databaseClusterArns: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#external_id AwsArcregionswitchPlan#external_id}
        */
        readonly externalId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#global_cluster_identifier AwsArcregionswitchPlan#global_cluster_identifier}
        */
        readonly globalClusterIdentifier: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#timeout_minutes AwsArcregionswitchPlan#timeout_minutes}
        */
        readonly timeoutMinutes?: number;
        /**
        * ungraceful block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#ungraceful AwsArcregionswitchPlan#ungraceful}
        */
        readonly ungraceful?: WorkflowStepDocumentDbConfigUngracefulProperty[] | cdktn.IResolvable;
    }
    class WorkflowStepDocumentDbConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepDocumentDbConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepDocumentDbConfigProperty | cdktn.IResolvable | undefined);
        private _behavior?;
        get behavior(): string;
        set behavior(value: string);
        get behaviorInput(): string | undefined;
        private _crossAccountRole?;
        get crossAccountRole(): string;
        set crossAccountRole(value: string);
        resetCrossAccountRole(): void;
        get crossAccountRoleInput(): string | undefined;
        private _databaseClusterArns?;
        get databaseClusterArns(): string[];
        set databaseClusterArns(value: string[]);
        get databaseClusterArnsInput(): string[] | undefined;
        private _externalId?;
        get externalId(): string;
        set externalId(value: string);
        resetExternalId(): void;
        get externalIdInput(): string | undefined;
        private _globalClusterIdentifier?;
        get globalClusterIdentifier(): string;
        set globalClusterIdentifier(value: string);
        get globalClusterIdentifierInput(): string | undefined;
        private _timeoutMinutes?;
        get timeoutMinutes(): number;
        set timeoutMinutes(value: number);
        resetTimeoutMinutes(): void;
        get timeoutMinutesInput(): number | undefined;
        private _ungraceful;
        get ungraceful(): WorkflowStepDocumentDbConfigUngracefulPropertyList;
        putUngraceful(value: WorkflowStepDocumentDbConfigUngracefulProperty[] | cdktn.IResolvable): void;
        resetUngraceful(): void;
        get ungracefulInput(): cdktn.IResolvable | WorkflowStepDocumentDbConfigUngracefulProperty[] | undefined;
    }
    class WorkflowStepDocumentDbConfigPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepDocumentDbConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepDocumentDbConfigPropertyOutputReference;
    }
    interface WorkflowStepEc2AsgCapacityIncreaseConfigAsgProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#arn AwsArcregionswitchPlan#arn}
        */
        readonly arn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#cross_account_role AwsArcregionswitchPlan#cross_account_role}
        */
        readonly crossAccountRole?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#external_id AwsArcregionswitchPlan#external_id}
        */
        readonly externalId?: string;
    }
    class WorkflowStepEc2AsgCapacityIncreaseConfigAsgPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepEc2AsgCapacityIncreaseConfigAsgProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepEc2AsgCapacityIncreaseConfigAsgProperty | cdktn.IResolvable | undefined);
        private _arn?;
        get arn(): string;
        set arn(value: string);
        get arnInput(): string | undefined;
        private _crossAccountRole?;
        get crossAccountRole(): string;
        set crossAccountRole(value: string);
        resetCrossAccountRole(): void;
        get crossAccountRoleInput(): string | undefined;
        private _externalId?;
        get externalId(): string;
        set externalId(value: string);
        resetExternalId(): void;
        get externalIdInput(): string | undefined;
    }
    class WorkflowStepEc2AsgCapacityIncreaseConfigAsgPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepEc2AsgCapacityIncreaseConfigAsgProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepEc2AsgCapacityIncreaseConfigAsgPropertyOutputReference;
    }
    interface WorkflowStepEc2AsgCapacityIncreaseConfigUngracefulProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#minimum_success_percentage AwsArcregionswitchPlan#minimum_success_percentage}
        */
        readonly minimumSuccessPercentage: number;
    }
    class WorkflowStepEc2AsgCapacityIncreaseConfigUngracefulPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepEc2AsgCapacityIncreaseConfigUngracefulProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepEc2AsgCapacityIncreaseConfigUngracefulProperty | cdktn.IResolvable | undefined);
        private _minimumSuccessPercentage?;
        get minimumSuccessPercentage(): number;
        set minimumSuccessPercentage(value: number);
        get minimumSuccessPercentageInput(): number | undefined;
    }
    class WorkflowStepEc2AsgCapacityIncreaseConfigUngracefulPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepEc2AsgCapacityIncreaseConfigUngracefulProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepEc2AsgCapacityIncreaseConfigUngracefulPropertyOutputReference;
    }
    interface WorkflowStepEc2AsgCapacityIncreaseConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#capacity_monitoring_approach AwsArcregionswitchPlan#capacity_monitoring_approach}
        */
        readonly capacityMonitoringApproach: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#target_percent AwsArcregionswitchPlan#target_percent}
        */
        readonly targetPercent?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#timeout_minutes AwsArcregionswitchPlan#timeout_minutes}
        */
        readonly timeoutMinutes?: number;
        /**
        * asg block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#asg AwsArcregionswitchPlan#asg}
        */
        readonly asg?: WorkflowStepEc2AsgCapacityIncreaseConfigAsgProperty[] | cdktn.IResolvable;
        /**
        * ungraceful block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#ungraceful AwsArcregionswitchPlan#ungraceful}
        */
        readonly ungraceful?: WorkflowStepEc2AsgCapacityIncreaseConfigUngracefulProperty[] | cdktn.IResolvable;
    }
    class WorkflowStepEc2AsgCapacityIncreaseConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepEc2AsgCapacityIncreaseConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepEc2AsgCapacityIncreaseConfigProperty | cdktn.IResolvable | undefined);
        private _capacityMonitoringApproach?;
        get capacityMonitoringApproach(): string;
        set capacityMonitoringApproach(value: string);
        get capacityMonitoringApproachInput(): string | undefined;
        private _targetPercent?;
        get targetPercent(): number;
        set targetPercent(value: number);
        resetTargetPercent(): void;
        get targetPercentInput(): number | undefined;
        private _timeoutMinutes?;
        get timeoutMinutes(): number;
        set timeoutMinutes(value: number);
        resetTimeoutMinutes(): void;
        get timeoutMinutesInput(): number | undefined;
        private _asg;
        get asg(): WorkflowStepEc2AsgCapacityIncreaseConfigAsgPropertyList;
        putAsg(value: WorkflowStepEc2AsgCapacityIncreaseConfigAsgProperty[] | cdktn.IResolvable): void;
        resetAsg(): void;
        get asgInput(): cdktn.IResolvable | WorkflowStepEc2AsgCapacityIncreaseConfigAsgProperty[] | undefined;
        private _ungraceful;
        get ungraceful(): WorkflowStepEc2AsgCapacityIncreaseConfigUngracefulPropertyList;
        putUngraceful(value: WorkflowStepEc2AsgCapacityIncreaseConfigUngracefulProperty[] | cdktn.IResolvable): void;
        resetUngraceful(): void;
        get ungracefulInput(): cdktn.IResolvable | WorkflowStepEc2AsgCapacityIncreaseConfigUngracefulProperty[] | undefined;
    }
    class WorkflowStepEc2AsgCapacityIncreaseConfigPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepEc2AsgCapacityIncreaseConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepEc2AsgCapacityIncreaseConfigPropertyOutputReference;
    }
    interface WorkflowStepEcsCapacityIncreaseConfigServiceProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#cluster_arn AwsArcregionswitchPlan#cluster_arn}
        */
        readonly clusterArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#cross_account_role AwsArcregionswitchPlan#cross_account_role}
        */
        readonly crossAccountRole?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#external_id AwsArcregionswitchPlan#external_id}
        */
        readonly externalId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#service_arn AwsArcregionswitchPlan#service_arn}
        */
        readonly serviceArn: string;
    }
    class WorkflowStepEcsCapacityIncreaseConfigServicePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepEcsCapacityIncreaseConfigServiceProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepEcsCapacityIncreaseConfigServiceProperty | cdktn.IResolvable | undefined);
        private _clusterArn?;
        get clusterArn(): string;
        set clusterArn(value: string);
        get clusterArnInput(): string | undefined;
        private _crossAccountRole?;
        get crossAccountRole(): string;
        set crossAccountRole(value: string);
        resetCrossAccountRole(): void;
        get crossAccountRoleInput(): string | undefined;
        private _externalId?;
        get externalId(): string;
        set externalId(value: string);
        resetExternalId(): void;
        get externalIdInput(): string | undefined;
        private _serviceArn?;
        get serviceArn(): string;
        set serviceArn(value: string);
        get serviceArnInput(): string | undefined;
    }
    class WorkflowStepEcsCapacityIncreaseConfigServicePropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepEcsCapacityIncreaseConfigServiceProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepEcsCapacityIncreaseConfigServicePropertyOutputReference;
    }
    interface WorkflowStepEcsCapacityIncreaseConfigUngracefulProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#minimum_success_percentage AwsArcregionswitchPlan#minimum_success_percentage}
        */
        readonly minimumSuccessPercentage: number;
    }
    class WorkflowStepEcsCapacityIncreaseConfigUngracefulPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepEcsCapacityIncreaseConfigUngracefulProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepEcsCapacityIncreaseConfigUngracefulProperty | cdktn.IResolvable | undefined);
        private _minimumSuccessPercentage?;
        get minimumSuccessPercentage(): number;
        set minimumSuccessPercentage(value: number);
        get minimumSuccessPercentageInput(): number | undefined;
    }
    class WorkflowStepEcsCapacityIncreaseConfigUngracefulPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepEcsCapacityIncreaseConfigUngracefulProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepEcsCapacityIncreaseConfigUngracefulPropertyOutputReference;
    }
    interface WorkflowStepEcsCapacityIncreaseConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#capacity_monitoring_approach AwsArcregionswitchPlan#capacity_monitoring_approach}
        */
        readonly capacityMonitoringApproach: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#target_percent AwsArcregionswitchPlan#target_percent}
        */
        readonly targetPercent?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#timeout_minutes AwsArcregionswitchPlan#timeout_minutes}
        */
        readonly timeoutMinutes?: number;
        /**
        * service block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#service AwsArcregionswitchPlan#service}
        */
        readonly service?: WorkflowStepEcsCapacityIncreaseConfigServiceProperty[] | cdktn.IResolvable;
        /**
        * ungraceful block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#ungraceful AwsArcregionswitchPlan#ungraceful}
        */
        readonly ungraceful?: WorkflowStepEcsCapacityIncreaseConfigUngracefulProperty[] | cdktn.IResolvable;
    }
    class WorkflowStepEcsCapacityIncreaseConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepEcsCapacityIncreaseConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepEcsCapacityIncreaseConfigProperty | cdktn.IResolvable | undefined);
        private _capacityMonitoringApproach?;
        get capacityMonitoringApproach(): string;
        set capacityMonitoringApproach(value: string);
        get capacityMonitoringApproachInput(): string | undefined;
        private _targetPercent?;
        get targetPercent(): number;
        set targetPercent(value: number);
        resetTargetPercent(): void;
        get targetPercentInput(): number | undefined;
        private _timeoutMinutes?;
        get timeoutMinutes(): number;
        set timeoutMinutes(value: number);
        resetTimeoutMinutes(): void;
        get timeoutMinutesInput(): number | undefined;
        private _service;
        get service(): WorkflowStepEcsCapacityIncreaseConfigServicePropertyList;
        putService(value: WorkflowStepEcsCapacityIncreaseConfigServiceProperty[] | cdktn.IResolvable): void;
        resetService(): void;
        get serviceInput(): cdktn.IResolvable | WorkflowStepEcsCapacityIncreaseConfigServiceProperty[] | undefined;
        private _ungraceful;
        get ungraceful(): WorkflowStepEcsCapacityIncreaseConfigUngracefulPropertyList;
        putUngraceful(value: WorkflowStepEcsCapacityIncreaseConfigUngracefulProperty[] | cdktn.IResolvable): void;
        resetUngraceful(): void;
        get ungracefulInput(): cdktn.IResolvable | WorkflowStepEcsCapacityIncreaseConfigUngracefulProperty[] | undefined;
    }
    class WorkflowStepEcsCapacityIncreaseConfigPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepEcsCapacityIncreaseConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepEcsCapacityIncreaseConfigPropertyOutputReference;
    }
    interface WorkflowStepEksResourceScalingConfigEksClustersProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#cluster_arn AwsArcregionswitchPlan#cluster_arn}
        */
        readonly clusterArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#cross_account_role AwsArcregionswitchPlan#cross_account_role}
        */
        readonly crossAccountRole?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#external_id AwsArcregionswitchPlan#external_id}
        */
        readonly externalId?: string;
    }
    class WorkflowStepEksResourceScalingConfigEksClustersPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepEksResourceScalingConfigEksClustersProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepEksResourceScalingConfigEksClustersProperty | cdktn.IResolvable | undefined);
        private _clusterArn?;
        get clusterArn(): string;
        set clusterArn(value: string);
        get clusterArnInput(): string | undefined;
        private _crossAccountRole?;
        get crossAccountRole(): string;
        set crossAccountRole(value: string);
        resetCrossAccountRole(): void;
        get crossAccountRoleInput(): string | undefined;
        private _externalId?;
        get externalId(): string;
        set externalId(value: string);
        resetExternalId(): void;
        get externalIdInput(): string | undefined;
    }
    class WorkflowStepEksResourceScalingConfigEksClustersPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepEksResourceScalingConfigEksClustersProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepEksResourceScalingConfigEksClustersPropertyOutputReference;
    }
    interface WorkflowStepEksResourceScalingConfigKubernetesResourceTypeProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#api_version AwsArcregionswitchPlan#api_version}
        */
        readonly apiVersion: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#kind AwsArcregionswitchPlan#kind}
        */
        readonly kind: string;
    }
    class WorkflowStepEksResourceScalingConfigKubernetesResourceTypePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepEksResourceScalingConfigKubernetesResourceTypeProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepEksResourceScalingConfigKubernetesResourceTypeProperty | cdktn.IResolvable | undefined);
        private _apiVersion?;
        get apiVersion(): string;
        set apiVersion(value: string);
        get apiVersionInput(): string | undefined;
        private _kind?;
        get kind(): string;
        set kind(value: string);
        get kindInput(): string | undefined;
    }
    class WorkflowStepEksResourceScalingConfigKubernetesResourceTypePropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepEksResourceScalingConfigKubernetesResourceTypeProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepEksResourceScalingConfigKubernetesResourceTypePropertyOutputReference;
    }
    interface WorkflowStepEksResourceScalingConfigScalingResourcesResourcesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#hpa_name AwsArcregionswitchPlan#hpa_name}
        */
        readonly hpaName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#name AwsArcregionswitchPlan#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#namespace AwsArcregionswitchPlan#namespace}
        */
        readonly namespace: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#resource_name AwsArcregionswitchPlan#resource_name}
        */
        readonly resourceName: string;
    }
    class WorkflowStepEksResourceScalingConfigScalingResourcesResourcesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepEksResourceScalingConfigScalingResourcesResourcesProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepEksResourceScalingConfigScalingResourcesResourcesProperty | cdktn.IResolvable | undefined);
        private _hpaName?;
        get hpaName(): string;
        set hpaName(value: string);
        resetHpaName(): void;
        get hpaNameInput(): string | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _namespace?;
        get namespace(): string;
        set namespace(value: string);
        get namespaceInput(): string | undefined;
        private _resourceName?;
        get resourceName(): string;
        set resourceName(value: string);
        get resourceNameInput(): string | undefined;
    }
    class WorkflowStepEksResourceScalingConfigScalingResourcesResourcesPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepEksResourceScalingConfigScalingResourcesResourcesProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepEksResourceScalingConfigScalingResourcesResourcesPropertyOutputReference;
    }
    interface WorkflowStepEksResourceScalingConfigScalingResourcesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#namespace AwsArcregionswitchPlan#namespace}
        */
        readonly namespace: string;
        /**
        * resources block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#resources AwsArcregionswitchPlan#resources}
        */
        readonly resources?: WorkflowStepEksResourceScalingConfigScalingResourcesResourcesProperty[] | cdktn.IResolvable;
    }
    class WorkflowStepEksResourceScalingConfigScalingResourcesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepEksResourceScalingConfigScalingResourcesProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepEksResourceScalingConfigScalingResourcesProperty | cdktn.IResolvable | undefined);
        private _namespace?;
        get namespace(): string;
        set namespace(value: string);
        get namespaceInput(): string | undefined;
        private _resources;
        get resources(): WorkflowStepEksResourceScalingConfigScalingResourcesResourcesPropertyList;
        putResources(value: WorkflowStepEksResourceScalingConfigScalingResourcesResourcesProperty[] | cdktn.IResolvable): void;
        resetResources(): void;
        get resourcesInput(): cdktn.IResolvable | WorkflowStepEksResourceScalingConfigScalingResourcesResourcesProperty[] | undefined;
    }
    class WorkflowStepEksResourceScalingConfigScalingResourcesPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepEksResourceScalingConfigScalingResourcesProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepEksResourceScalingConfigScalingResourcesPropertyOutputReference;
    }
    interface WorkflowStepEksResourceScalingConfigUngracefulProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#minimum_success_percentage AwsArcregionswitchPlan#minimum_success_percentage}
        */
        readonly minimumSuccessPercentage: number;
    }
    class WorkflowStepEksResourceScalingConfigUngracefulPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepEksResourceScalingConfigUngracefulProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepEksResourceScalingConfigUngracefulProperty | cdktn.IResolvable | undefined);
        private _minimumSuccessPercentage?;
        get minimumSuccessPercentage(): number;
        set minimumSuccessPercentage(value: number);
        get minimumSuccessPercentageInput(): number | undefined;
    }
    class WorkflowStepEksResourceScalingConfigUngracefulPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepEksResourceScalingConfigUngracefulProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepEksResourceScalingConfigUngracefulPropertyOutputReference;
    }
    interface WorkflowStepEksResourceScalingConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#capacity_monitoring_approach AwsArcregionswitchPlan#capacity_monitoring_approach}
        */
        readonly capacityMonitoringApproach: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#target_percent AwsArcregionswitchPlan#target_percent}
        */
        readonly targetPercent: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#timeout_minutes AwsArcregionswitchPlan#timeout_minutes}
        */
        readonly timeoutMinutes?: number;
        /**
        * eks_clusters block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#eks_clusters AwsArcregionswitchPlan#eks_clusters}
        */
        readonly eksClusters?: WorkflowStepEksResourceScalingConfigEksClustersProperty[] | cdktn.IResolvable;
        /**
        * kubernetes_resource_type block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#kubernetes_resource_type AwsArcregionswitchPlan#kubernetes_resource_type}
        */
        readonly kubernetesResourceType?: WorkflowStepEksResourceScalingConfigKubernetesResourceTypeProperty[] | cdktn.IResolvable;
        /**
        * scaling_resources block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#scaling_resources AwsArcregionswitchPlan#scaling_resources}
        */
        readonly scalingResources?: WorkflowStepEksResourceScalingConfigScalingResourcesProperty[] | cdktn.IResolvable;
        /**
        * ungraceful block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#ungraceful AwsArcregionswitchPlan#ungraceful}
        */
        readonly ungraceful?: WorkflowStepEksResourceScalingConfigUngracefulProperty[] | cdktn.IResolvable;
    }
    class WorkflowStepEksResourceScalingConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepEksResourceScalingConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepEksResourceScalingConfigProperty | cdktn.IResolvable | undefined);
        private _capacityMonitoringApproach?;
        get capacityMonitoringApproach(): string;
        set capacityMonitoringApproach(value: string);
        get capacityMonitoringApproachInput(): string | undefined;
        private _targetPercent?;
        get targetPercent(): number;
        set targetPercent(value: number);
        get targetPercentInput(): number | undefined;
        private _timeoutMinutes?;
        get timeoutMinutes(): number;
        set timeoutMinutes(value: number);
        resetTimeoutMinutes(): void;
        get timeoutMinutesInput(): number | undefined;
        private _eksClusters;
        get eksClusters(): WorkflowStepEksResourceScalingConfigEksClustersPropertyList;
        putEksClusters(value: WorkflowStepEksResourceScalingConfigEksClustersProperty[] | cdktn.IResolvable): void;
        resetEksClusters(): void;
        get eksClustersInput(): cdktn.IResolvable | WorkflowStepEksResourceScalingConfigEksClustersProperty[] | undefined;
        private _kubernetesResourceType;
        get kubernetesResourceType(): WorkflowStepEksResourceScalingConfigKubernetesResourceTypePropertyList;
        putKubernetesResourceType(value: WorkflowStepEksResourceScalingConfigKubernetesResourceTypeProperty[] | cdktn.IResolvable): void;
        resetKubernetesResourceType(): void;
        get kubernetesResourceTypeInput(): cdktn.IResolvable | WorkflowStepEksResourceScalingConfigKubernetesResourceTypeProperty[] | undefined;
        private _scalingResources;
        get scalingResources(): WorkflowStepEksResourceScalingConfigScalingResourcesPropertyList;
        putScalingResources(value: WorkflowStepEksResourceScalingConfigScalingResourcesProperty[] | cdktn.IResolvable): void;
        resetScalingResources(): void;
        get scalingResourcesInput(): cdktn.IResolvable | WorkflowStepEksResourceScalingConfigScalingResourcesProperty[] | undefined;
        private _ungraceful;
        get ungraceful(): WorkflowStepEksResourceScalingConfigUngracefulPropertyList;
        putUngraceful(value: WorkflowStepEksResourceScalingConfigUngracefulProperty[] | cdktn.IResolvable): void;
        resetUngraceful(): void;
        get ungracefulInput(): cdktn.IResolvable | WorkflowStepEksResourceScalingConfigUngracefulProperty[] | undefined;
    }
    class WorkflowStepEksResourceScalingConfigPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepEksResourceScalingConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepEksResourceScalingConfigPropertyOutputReference;
    }
    interface WorkflowStepExecutionApprovalConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#approval_role AwsArcregionswitchPlan#approval_role}
        */
        readonly approvalRole: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#timeout_minutes AwsArcregionswitchPlan#timeout_minutes}
        */
        readonly timeoutMinutes?: number;
    }
    class WorkflowStepExecutionApprovalConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepExecutionApprovalConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepExecutionApprovalConfigProperty | cdktn.IResolvable | undefined);
        private _approvalRole?;
        get approvalRole(): string;
        set approvalRole(value: string);
        get approvalRoleInput(): string | undefined;
        private _timeoutMinutes?;
        get timeoutMinutes(): number;
        set timeoutMinutes(value: number);
        resetTimeoutMinutes(): void;
        get timeoutMinutesInput(): number | undefined;
    }
    class WorkflowStepExecutionApprovalConfigPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepExecutionApprovalConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepExecutionApprovalConfigPropertyOutputReference;
    }
    interface WorkflowStepGlobalAuroraConfigUngracefulProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#ungraceful AwsArcregionswitchPlan#ungraceful}
        */
        readonly ungraceful: string;
    }
    class WorkflowStepGlobalAuroraConfigUngracefulPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepGlobalAuroraConfigUngracefulProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepGlobalAuroraConfigUngracefulProperty | cdktn.IResolvable | undefined);
        private _ungraceful?;
        get ungraceful(): string;
        set ungraceful(value: string);
        get ungracefulInput(): string | undefined;
    }
    class WorkflowStepGlobalAuroraConfigUngracefulPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepGlobalAuroraConfigUngracefulProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepGlobalAuroraConfigUngracefulPropertyOutputReference;
    }
    interface WorkflowStepGlobalAuroraConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#behavior AwsArcregionswitchPlan#behavior}
        */
        readonly behavior: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#cross_account_role AwsArcregionswitchPlan#cross_account_role}
        */
        readonly crossAccountRole?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#database_cluster_arns AwsArcregionswitchPlan#database_cluster_arns}
        */
        readonly databaseClusterArns: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#external_id AwsArcregionswitchPlan#external_id}
        */
        readonly externalId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#global_cluster_identifier AwsArcregionswitchPlan#global_cluster_identifier}
        */
        readonly globalClusterIdentifier: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#timeout_minutes AwsArcregionswitchPlan#timeout_minutes}
        */
        readonly timeoutMinutes?: number;
        /**
        * ungraceful block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#ungraceful AwsArcregionswitchPlan#ungraceful}
        */
        readonly ungraceful?: WorkflowStepGlobalAuroraConfigUngracefulProperty[] | cdktn.IResolvable;
    }
    class WorkflowStepGlobalAuroraConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepGlobalAuroraConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepGlobalAuroraConfigProperty | cdktn.IResolvable | undefined);
        private _behavior?;
        get behavior(): string;
        set behavior(value: string);
        get behaviorInput(): string | undefined;
        private _crossAccountRole?;
        get crossAccountRole(): string;
        set crossAccountRole(value: string);
        resetCrossAccountRole(): void;
        get crossAccountRoleInput(): string | undefined;
        private _databaseClusterArns?;
        get databaseClusterArns(): string[];
        set databaseClusterArns(value: string[]);
        get databaseClusterArnsInput(): string[] | undefined;
        private _externalId?;
        get externalId(): string;
        set externalId(value: string);
        resetExternalId(): void;
        get externalIdInput(): string | undefined;
        private _globalClusterIdentifier?;
        get globalClusterIdentifier(): string;
        set globalClusterIdentifier(value: string);
        get globalClusterIdentifierInput(): string | undefined;
        private _timeoutMinutes?;
        get timeoutMinutes(): number;
        set timeoutMinutes(value: number);
        resetTimeoutMinutes(): void;
        get timeoutMinutesInput(): number | undefined;
        private _ungraceful;
        get ungraceful(): WorkflowStepGlobalAuroraConfigUngracefulPropertyList;
        putUngraceful(value: WorkflowStepGlobalAuroraConfigUngracefulProperty[] | cdktn.IResolvable): void;
        resetUngraceful(): void;
        get ungracefulInput(): cdktn.IResolvable | WorkflowStepGlobalAuroraConfigUngracefulProperty[] | undefined;
    }
    class WorkflowStepGlobalAuroraConfigPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepGlobalAuroraConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepGlobalAuroraConfigPropertyOutputReference;
    }
    interface WorkflowStepLambdaEventSourceMappingConfigRegionEventSourceMappingProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#arn AwsArcregionswitchPlan#arn}
        */
        readonly arn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#cross_account_role AwsArcregionswitchPlan#cross_account_role}
        */
        readonly crossAccountRole?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#external_id AwsArcregionswitchPlan#external_id}
        */
        readonly externalId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#region AwsArcregionswitchPlan#region}
        */
        readonly region: string;
    }
    class WorkflowStepLambdaEventSourceMappingConfigRegionEventSourceMappingPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepLambdaEventSourceMappingConfigRegionEventSourceMappingProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepLambdaEventSourceMappingConfigRegionEventSourceMappingProperty | cdktn.IResolvable | undefined);
        private _arn?;
        get arn(): string;
        set arn(value: string);
        get arnInput(): string | undefined;
        private _crossAccountRole?;
        get crossAccountRole(): string;
        set crossAccountRole(value: string);
        resetCrossAccountRole(): void;
        get crossAccountRoleInput(): string | undefined;
        private _externalId?;
        get externalId(): string;
        set externalId(value: string);
        resetExternalId(): void;
        get externalIdInput(): string | undefined;
        private _region?;
        get region(): string;
        set region(value: string);
        get regionInput(): string | undefined;
    }
    class WorkflowStepLambdaEventSourceMappingConfigRegionEventSourceMappingPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepLambdaEventSourceMappingConfigRegionEventSourceMappingProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepLambdaEventSourceMappingConfigRegionEventSourceMappingPropertyOutputReference;
    }
    interface WorkflowStepLambdaEventSourceMappingConfigUngracefulProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#behavior AwsArcregionswitchPlan#behavior}
        */
        readonly behavior: string;
    }
    class WorkflowStepLambdaEventSourceMappingConfigUngracefulPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepLambdaEventSourceMappingConfigUngracefulProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepLambdaEventSourceMappingConfigUngracefulProperty | cdktn.IResolvable | undefined);
        private _behavior?;
        get behavior(): string;
        set behavior(value: string);
        get behaviorInput(): string | undefined;
    }
    class WorkflowStepLambdaEventSourceMappingConfigUngracefulPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepLambdaEventSourceMappingConfigUngracefulProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepLambdaEventSourceMappingConfigUngracefulPropertyOutputReference;
    }
    interface WorkflowStepLambdaEventSourceMappingConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#action AwsArcregionswitchPlan#action}
        */
        readonly action: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#timeout_minutes AwsArcregionswitchPlan#timeout_minutes}
        */
        readonly timeoutMinutes?: number;
        /**
        * region_event_source_mapping block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#region_event_source_mapping AwsArcregionswitchPlan#region_event_source_mapping}
        */
        readonly regionEventSourceMapping?: WorkflowStepLambdaEventSourceMappingConfigRegionEventSourceMappingProperty[] | cdktn.IResolvable;
        /**
        * ungraceful block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#ungraceful AwsArcregionswitchPlan#ungraceful}
        */
        readonly ungraceful?: WorkflowStepLambdaEventSourceMappingConfigUngracefulProperty[] | cdktn.IResolvable;
    }
    class WorkflowStepLambdaEventSourceMappingConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepLambdaEventSourceMappingConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepLambdaEventSourceMappingConfigProperty | cdktn.IResolvable | undefined);
        private _action?;
        get action(): string;
        set action(value: string);
        get actionInput(): string | undefined;
        private _timeoutMinutes?;
        get timeoutMinutes(): number;
        set timeoutMinutes(value: number);
        resetTimeoutMinutes(): void;
        get timeoutMinutesInput(): number | undefined;
        private _regionEventSourceMapping;
        get regionEventSourceMapping(): WorkflowStepLambdaEventSourceMappingConfigRegionEventSourceMappingPropertyList;
        putRegionEventSourceMapping(value: WorkflowStepLambdaEventSourceMappingConfigRegionEventSourceMappingProperty[] | cdktn.IResolvable): void;
        resetRegionEventSourceMapping(): void;
        get regionEventSourceMappingInput(): cdktn.IResolvable | WorkflowStepLambdaEventSourceMappingConfigRegionEventSourceMappingProperty[] | undefined;
        private _ungraceful;
        get ungraceful(): WorkflowStepLambdaEventSourceMappingConfigUngracefulPropertyList;
        putUngraceful(value: WorkflowStepLambdaEventSourceMappingConfigUngracefulProperty[] | cdktn.IResolvable): void;
        resetUngraceful(): void;
        get ungracefulInput(): cdktn.IResolvable | WorkflowStepLambdaEventSourceMappingConfigUngracefulProperty[] | undefined;
    }
    class WorkflowStepLambdaEventSourceMappingConfigPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepLambdaEventSourceMappingConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepLambdaEventSourceMappingConfigPropertyOutputReference;
    }
    interface WorkflowStepNeptuneGlobalDatabaseConfigUngracefulProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#ungraceful AwsArcregionswitchPlan#ungraceful}
        */
        readonly ungraceful: string;
    }
    class WorkflowStepNeptuneGlobalDatabaseConfigUngracefulPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepNeptuneGlobalDatabaseConfigUngracefulProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepNeptuneGlobalDatabaseConfigUngracefulProperty | cdktn.IResolvable | undefined);
        private _ungraceful?;
        get ungraceful(): string;
        set ungraceful(value: string);
        get ungracefulInput(): string | undefined;
    }
    class WorkflowStepNeptuneGlobalDatabaseConfigUngracefulPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepNeptuneGlobalDatabaseConfigUngracefulProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepNeptuneGlobalDatabaseConfigUngracefulPropertyOutputReference;
    }
    interface WorkflowStepNeptuneGlobalDatabaseConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#behavior AwsArcregionswitchPlan#behavior}
        */
        readonly behavior: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#cross_account_role AwsArcregionswitchPlan#cross_account_role}
        */
        readonly crossAccountRole?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#external_id AwsArcregionswitchPlan#external_id}
        */
        readonly externalId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#global_cluster_identifier AwsArcregionswitchPlan#global_cluster_identifier}
        */
        readonly globalClusterIdentifier: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#region_database_cluster_arns AwsArcregionswitchPlan#region_database_cluster_arns}
        */
        readonly regionDatabaseClusterArns: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#timeout_minutes AwsArcregionswitchPlan#timeout_minutes}
        */
        readonly timeoutMinutes?: number;
        /**
        * ungraceful block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#ungraceful AwsArcregionswitchPlan#ungraceful}
        */
        readonly ungraceful?: WorkflowStepNeptuneGlobalDatabaseConfigUngracefulProperty[] | cdktn.IResolvable;
    }
    class WorkflowStepNeptuneGlobalDatabaseConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepNeptuneGlobalDatabaseConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepNeptuneGlobalDatabaseConfigProperty | cdktn.IResolvable | undefined);
        private _behavior?;
        get behavior(): string;
        set behavior(value: string);
        get behaviorInput(): string | undefined;
        private _crossAccountRole?;
        get crossAccountRole(): string;
        set crossAccountRole(value: string);
        resetCrossAccountRole(): void;
        get crossAccountRoleInput(): string | undefined;
        private _externalId?;
        get externalId(): string;
        set externalId(value: string);
        resetExternalId(): void;
        get externalIdInput(): string | undefined;
        private _globalClusterIdentifier?;
        get globalClusterIdentifier(): string;
        set globalClusterIdentifier(value: string);
        get globalClusterIdentifierInput(): string | undefined;
        private _regionDatabaseClusterArns?;
        get regionDatabaseClusterArns(): {
            [key: string]: string;
        };
        set regionDatabaseClusterArns(value: {
            [key: string]: string;
        });
        get regionDatabaseClusterArnsInput(): {
            [key: string]: string;
        } | undefined;
        private _timeoutMinutes?;
        get timeoutMinutes(): number;
        set timeoutMinutes(value: number);
        resetTimeoutMinutes(): void;
        get timeoutMinutesInput(): number | undefined;
        private _ungraceful;
        get ungraceful(): WorkflowStepNeptuneGlobalDatabaseConfigUngracefulPropertyList;
        putUngraceful(value: WorkflowStepNeptuneGlobalDatabaseConfigUngracefulProperty[] | cdktn.IResolvable): void;
        resetUngraceful(): void;
        get ungracefulInput(): cdktn.IResolvable | WorkflowStepNeptuneGlobalDatabaseConfigUngracefulProperty[] | undefined;
    }
    class WorkflowStepNeptuneGlobalDatabaseConfigPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepNeptuneGlobalDatabaseConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepNeptuneGlobalDatabaseConfigPropertyOutputReference;
    }
    interface WorkflowStepParallelConfigStepArcRoutingControlConfigRegionAndRoutingControlsRoutingControlProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#routing_control_arn AwsArcregionswitchPlan#routing_control_arn}
        */
        readonly routingControlArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#state AwsArcregionswitchPlan#state}
        */
        readonly state: string;
    }
    class WorkflowStepParallelConfigStepArcRoutingControlConfigRegionAndRoutingControlsRoutingControlPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepParallelConfigStepArcRoutingControlConfigRegionAndRoutingControlsRoutingControlProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepParallelConfigStepArcRoutingControlConfigRegionAndRoutingControlsRoutingControlProperty | cdktn.IResolvable | undefined);
        private _routingControlArn?;
        get routingControlArn(): string;
        set routingControlArn(value: string);
        get routingControlArnInput(): string | undefined;
        private _state?;
        get state(): string;
        set state(value: string);
        get stateInput(): string | undefined;
    }
    class WorkflowStepParallelConfigStepArcRoutingControlConfigRegionAndRoutingControlsRoutingControlPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepParallelConfigStepArcRoutingControlConfigRegionAndRoutingControlsRoutingControlProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepParallelConfigStepArcRoutingControlConfigRegionAndRoutingControlsRoutingControlPropertyOutputReference;
    }
    interface WorkflowStepParallelConfigStepArcRoutingControlConfigRegionAndRoutingControlsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#region AwsArcregionswitchPlan#region}
        */
        readonly region: string;
        /**
        * routing_control block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#routing_control AwsArcregionswitchPlan#routing_control}
        */
        readonly routingControl?: WorkflowStepParallelConfigStepArcRoutingControlConfigRegionAndRoutingControlsRoutingControlProperty[] | cdktn.IResolvable;
    }
    class WorkflowStepParallelConfigStepArcRoutingControlConfigRegionAndRoutingControlsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepParallelConfigStepArcRoutingControlConfigRegionAndRoutingControlsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepParallelConfigStepArcRoutingControlConfigRegionAndRoutingControlsProperty | cdktn.IResolvable | undefined);
        private _region?;
        get region(): string;
        set region(value: string);
        get regionInput(): string | undefined;
        private _routingControl;
        get routingControl(): WorkflowStepParallelConfigStepArcRoutingControlConfigRegionAndRoutingControlsRoutingControlPropertyList;
        putRoutingControl(value: WorkflowStepParallelConfigStepArcRoutingControlConfigRegionAndRoutingControlsRoutingControlProperty[] | cdktn.IResolvable): void;
        resetRoutingControl(): void;
        get routingControlInput(): cdktn.IResolvable | WorkflowStepParallelConfigStepArcRoutingControlConfigRegionAndRoutingControlsRoutingControlProperty[] | undefined;
    }
    class WorkflowStepParallelConfigStepArcRoutingControlConfigRegionAndRoutingControlsPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepParallelConfigStepArcRoutingControlConfigRegionAndRoutingControlsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepParallelConfigStepArcRoutingControlConfigRegionAndRoutingControlsPropertyOutputReference;
    }
    interface WorkflowStepParallelConfigStepArcRoutingControlConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#cross_account_role AwsArcregionswitchPlan#cross_account_role}
        */
        readonly crossAccountRole?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#external_id AwsArcregionswitchPlan#external_id}
        */
        readonly externalId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#timeout_minutes AwsArcregionswitchPlan#timeout_minutes}
        */
        readonly timeoutMinutes?: number;
        /**
        * region_and_routing_controls block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#region_and_routing_controls AwsArcregionswitchPlan#region_and_routing_controls}
        */
        readonly regionAndRoutingControls?: WorkflowStepParallelConfigStepArcRoutingControlConfigRegionAndRoutingControlsProperty[] | cdktn.IResolvable;
    }
    class WorkflowStepParallelConfigStepArcRoutingControlConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepParallelConfigStepArcRoutingControlConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepParallelConfigStepArcRoutingControlConfigProperty | cdktn.IResolvable | undefined);
        private _crossAccountRole?;
        get crossAccountRole(): string;
        set crossAccountRole(value: string);
        resetCrossAccountRole(): void;
        get crossAccountRoleInput(): string | undefined;
        private _externalId?;
        get externalId(): string;
        set externalId(value: string);
        resetExternalId(): void;
        get externalIdInput(): string | undefined;
        private _timeoutMinutes?;
        get timeoutMinutes(): number;
        set timeoutMinutes(value: number);
        resetTimeoutMinutes(): void;
        get timeoutMinutesInput(): number | undefined;
        private _regionAndRoutingControls;
        get regionAndRoutingControls(): WorkflowStepParallelConfigStepArcRoutingControlConfigRegionAndRoutingControlsPropertyList;
        putRegionAndRoutingControls(value: WorkflowStepParallelConfigStepArcRoutingControlConfigRegionAndRoutingControlsProperty[] | cdktn.IResolvable): void;
        resetRegionAndRoutingControls(): void;
        get regionAndRoutingControlsInput(): cdktn.IResolvable | WorkflowStepParallelConfigStepArcRoutingControlConfigRegionAndRoutingControlsProperty[] | undefined;
    }
    class WorkflowStepParallelConfigStepArcRoutingControlConfigPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepParallelConfigStepArcRoutingControlConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepParallelConfigStepArcRoutingControlConfigPropertyOutputReference;
    }
    interface WorkflowStepParallelConfigStepAuroraProvisionedScalingConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#cross_account_role AwsArcregionswitchPlan#cross_account_role}
        */
        readonly crossAccountRole?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#external_id AwsArcregionswitchPlan#external_id}
        */
        readonly externalId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#global_cluster_identifier AwsArcregionswitchPlan#global_cluster_identifier}
        */
        readonly globalClusterIdentifier: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#instance_arns AwsArcregionswitchPlan#instance_arns}
        */
        readonly instanceArns: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#region_database_cluster_arns AwsArcregionswitchPlan#region_database_cluster_arns}
        */
        readonly regionDatabaseClusterArns: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#timeout_minutes AwsArcregionswitchPlan#timeout_minutes}
        */
        readonly timeoutMinutes?: number;
    }
    class WorkflowStepParallelConfigStepAuroraProvisionedScalingConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepParallelConfigStepAuroraProvisionedScalingConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepParallelConfigStepAuroraProvisionedScalingConfigProperty | cdktn.IResolvable | undefined);
        private _crossAccountRole?;
        get crossAccountRole(): string;
        set crossAccountRole(value: string);
        resetCrossAccountRole(): void;
        get crossAccountRoleInput(): string | undefined;
        private _externalId?;
        get externalId(): string;
        set externalId(value: string);
        resetExternalId(): void;
        get externalIdInput(): string | undefined;
        private _globalClusterIdentifier?;
        get globalClusterIdentifier(): string;
        set globalClusterIdentifier(value: string);
        get globalClusterIdentifierInput(): string | undefined;
        private _instanceArns?;
        get instanceArns(): {
            [key: string]: string;
        };
        set instanceArns(value: {
            [key: string]: string;
        });
        get instanceArnsInput(): {
            [key: string]: string;
        } | undefined;
        private _regionDatabaseClusterArns?;
        get regionDatabaseClusterArns(): {
            [key: string]: string;
        };
        set regionDatabaseClusterArns(value: {
            [key: string]: string;
        });
        get regionDatabaseClusterArnsInput(): {
            [key: string]: string;
        } | undefined;
        private _timeoutMinutes?;
        get timeoutMinutes(): number;
        set timeoutMinutes(value: number);
        resetTimeoutMinutes(): void;
        get timeoutMinutesInput(): number | undefined;
    }
    class WorkflowStepParallelConfigStepAuroraProvisionedScalingConfigPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepParallelConfigStepAuroraProvisionedScalingConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepParallelConfigStepAuroraProvisionedScalingConfigPropertyOutputReference;
    }
    interface WorkflowStepParallelConfigStepAuroraServerlessScalingConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#cross_account_role AwsArcregionswitchPlan#cross_account_role}
        */
        readonly crossAccountRole?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#external_id AwsArcregionswitchPlan#external_id}
        */
        readonly externalId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#global_cluster_identifier AwsArcregionswitchPlan#global_cluster_identifier}
        */
        readonly globalClusterIdentifier: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#region_database_cluster_arns AwsArcregionswitchPlan#region_database_cluster_arns}
        */
        readonly regionDatabaseClusterArns: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#target_percent AwsArcregionswitchPlan#target_percent}
        */
        readonly targetPercent?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#timeout_minutes AwsArcregionswitchPlan#timeout_minutes}
        */
        readonly timeoutMinutes?: number;
    }
    class WorkflowStepParallelConfigStepAuroraServerlessScalingConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepParallelConfigStepAuroraServerlessScalingConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepParallelConfigStepAuroraServerlessScalingConfigProperty | cdktn.IResolvable | undefined);
        private _crossAccountRole?;
        get crossAccountRole(): string;
        set crossAccountRole(value: string);
        resetCrossAccountRole(): void;
        get crossAccountRoleInput(): string | undefined;
        private _externalId?;
        get externalId(): string;
        set externalId(value: string);
        resetExternalId(): void;
        get externalIdInput(): string | undefined;
        private _globalClusterIdentifier?;
        get globalClusterIdentifier(): string;
        set globalClusterIdentifier(value: string);
        get globalClusterIdentifierInput(): string | undefined;
        private _regionDatabaseClusterArns?;
        get regionDatabaseClusterArns(): {
            [key: string]: string;
        };
        set regionDatabaseClusterArns(value: {
            [key: string]: string;
        });
        get regionDatabaseClusterArnsInput(): {
            [key: string]: string;
        } | undefined;
        private _targetPercent?;
        get targetPercent(): number;
        set targetPercent(value: number);
        resetTargetPercent(): void;
        get targetPercentInput(): number | undefined;
        private _timeoutMinutes?;
        get timeoutMinutes(): number;
        set timeoutMinutes(value: number);
        resetTimeoutMinutes(): void;
        get timeoutMinutesInput(): number | undefined;
    }
    class WorkflowStepParallelConfigStepAuroraServerlessScalingConfigPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepParallelConfigStepAuroraServerlessScalingConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepParallelConfigStepAuroraServerlessScalingConfigPropertyOutputReference;
    }
    interface WorkflowStepParallelConfigStepCustomActionLambdaConfigLambdaProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#arn AwsArcregionswitchPlan#arn}
        */
        readonly arn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#cross_account_role AwsArcregionswitchPlan#cross_account_role}
        */
        readonly crossAccountRole?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#external_id AwsArcregionswitchPlan#external_id}
        */
        readonly externalId?: string;
    }
    class WorkflowStepParallelConfigStepCustomActionLambdaConfigLambdaPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepParallelConfigStepCustomActionLambdaConfigLambdaProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepParallelConfigStepCustomActionLambdaConfigLambdaProperty | cdktn.IResolvable | undefined);
        private _arn?;
        get arn(): string;
        set arn(value: string);
        get arnInput(): string | undefined;
        private _crossAccountRole?;
        get crossAccountRole(): string;
        set crossAccountRole(value: string);
        resetCrossAccountRole(): void;
        get crossAccountRoleInput(): string | undefined;
        private _externalId?;
        get externalId(): string;
        set externalId(value: string);
        resetExternalId(): void;
        get externalIdInput(): string | undefined;
    }
    class WorkflowStepParallelConfigStepCustomActionLambdaConfigLambdaPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepParallelConfigStepCustomActionLambdaConfigLambdaProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepParallelConfigStepCustomActionLambdaConfigLambdaPropertyOutputReference;
    }
    interface WorkflowStepParallelConfigStepCustomActionLambdaConfigUngracefulProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#behavior AwsArcregionswitchPlan#behavior}
        */
        readonly behavior: string;
    }
    class WorkflowStepParallelConfigStepCustomActionLambdaConfigUngracefulPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepParallelConfigStepCustomActionLambdaConfigUngracefulProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepParallelConfigStepCustomActionLambdaConfigUngracefulProperty | cdktn.IResolvable | undefined);
        private _behavior?;
        get behavior(): string;
        set behavior(value: string);
        get behaviorInput(): string | undefined;
    }
    class WorkflowStepParallelConfigStepCustomActionLambdaConfigUngracefulPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepParallelConfigStepCustomActionLambdaConfigUngracefulProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepParallelConfigStepCustomActionLambdaConfigUngracefulPropertyOutputReference;
    }
    interface WorkflowStepParallelConfigStepCustomActionLambdaConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#region_to_run AwsArcregionswitchPlan#region_to_run}
        */
        readonly regionToRun: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#retry_interval_minutes AwsArcregionswitchPlan#retry_interval_minutes}
        */
        readonly retryIntervalMinutes: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#timeout_minutes AwsArcregionswitchPlan#timeout_minutes}
        */
        readonly timeoutMinutes?: number;
        /**
        * lambda block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#lambda AwsArcregionswitchPlan#lambda}
        */
        readonly lambda?: WorkflowStepParallelConfigStepCustomActionLambdaConfigLambdaProperty[] | cdktn.IResolvable;
        /**
        * ungraceful block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#ungraceful AwsArcregionswitchPlan#ungraceful}
        */
        readonly ungraceful?: WorkflowStepParallelConfigStepCustomActionLambdaConfigUngracefulProperty[] | cdktn.IResolvable;
    }
    class WorkflowStepParallelConfigStepCustomActionLambdaConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepParallelConfigStepCustomActionLambdaConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepParallelConfigStepCustomActionLambdaConfigProperty | cdktn.IResolvable | undefined);
        private _regionToRun?;
        get regionToRun(): string;
        set regionToRun(value: string);
        get regionToRunInput(): string | undefined;
        private _retryIntervalMinutes?;
        get retryIntervalMinutes(): number;
        set retryIntervalMinutes(value: number);
        get retryIntervalMinutesInput(): number | undefined;
        private _timeoutMinutes?;
        get timeoutMinutes(): number;
        set timeoutMinutes(value: number);
        resetTimeoutMinutes(): void;
        get timeoutMinutesInput(): number | undefined;
        private _lambda;
        get lambda(): WorkflowStepParallelConfigStepCustomActionLambdaConfigLambdaPropertyList;
        putLambda(value: WorkflowStepParallelConfigStepCustomActionLambdaConfigLambdaProperty[] | cdktn.IResolvable): void;
        resetLambda(): void;
        get lambdaInput(): cdktn.IResolvable | WorkflowStepParallelConfigStepCustomActionLambdaConfigLambdaProperty[] | undefined;
        private _ungraceful;
        get ungraceful(): WorkflowStepParallelConfigStepCustomActionLambdaConfigUngracefulPropertyList;
        putUngraceful(value: WorkflowStepParallelConfigStepCustomActionLambdaConfigUngracefulProperty[] | cdktn.IResolvable): void;
        resetUngraceful(): void;
        get ungracefulInput(): cdktn.IResolvable | WorkflowStepParallelConfigStepCustomActionLambdaConfigUngracefulProperty[] | undefined;
    }
    class WorkflowStepParallelConfigStepCustomActionLambdaConfigPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepParallelConfigStepCustomActionLambdaConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepParallelConfigStepCustomActionLambdaConfigPropertyOutputReference;
    }
    interface WorkflowStepParallelConfigStepDocumentDbConfigUngracefulProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#ungraceful AwsArcregionswitchPlan#ungraceful}
        */
        readonly ungraceful: string;
    }
    class WorkflowStepParallelConfigStepDocumentDbConfigUngracefulPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepParallelConfigStepDocumentDbConfigUngracefulProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepParallelConfigStepDocumentDbConfigUngracefulProperty | cdktn.IResolvable | undefined);
        private _ungraceful?;
        get ungraceful(): string;
        set ungraceful(value: string);
        get ungracefulInput(): string | undefined;
    }
    class WorkflowStepParallelConfigStepDocumentDbConfigUngracefulPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepParallelConfigStepDocumentDbConfigUngracefulProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepParallelConfigStepDocumentDbConfigUngracefulPropertyOutputReference;
    }
    interface WorkflowStepParallelConfigStepDocumentDbConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#behavior AwsArcregionswitchPlan#behavior}
        */
        readonly behavior: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#cross_account_role AwsArcregionswitchPlan#cross_account_role}
        */
        readonly crossAccountRole?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#database_cluster_arns AwsArcregionswitchPlan#database_cluster_arns}
        */
        readonly databaseClusterArns: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#external_id AwsArcregionswitchPlan#external_id}
        */
        readonly externalId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#global_cluster_identifier AwsArcregionswitchPlan#global_cluster_identifier}
        */
        readonly globalClusterIdentifier: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#timeout_minutes AwsArcregionswitchPlan#timeout_minutes}
        */
        readonly timeoutMinutes?: number;
        /**
        * ungraceful block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#ungraceful AwsArcregionswitchPlan#ungraceful}
        */
        readonly ungraceful?: WorkflowStepParallelConfigStepDocumentDbConfigUngracefulProperty[] | cdktn.IResolvable;
    }
    class WorkflowStepParallelConfigStepDocumentDbConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepParallelConfigStepDocumentDbConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepParallelConfigStepDocumentDbConfigProperty | cdktn.IResolvable | undefined);
        private _behavior?;
        get behavior(): string;
        set behavior(value: string);
        get behaviorInput(): string | undefined;
        private _crossAccountRole?;
        get crossAccountRole(): string;
        set crossAccountRole(value: string);
        resetCrossAccountRole(): void;
        get crossAccountRoleInput(): string | undefined;
        private _databaseClusterArns?;
        get databaseClusterArns(): string[];
        set databaseClusterArns(value: string[]);
        get databaseClusterArnsInput(): string[] | undefined;
        private _externalId?;
        get externalId(): string;
        set externalId(value: string);
        resetExternalId(): void;
        get externalIdInput(): string | undefined;
        private _globalClusterIdentifier?;
        get globalClusterIdentifier(): string;
        set globalClusterIdentifier(value: string);
        get globalClusterIdentifierInput(): string | undefined;
        private _timeoutMinutes?;
        get timeoutMinutes(): number;
        set timeoutMinutes(value: number);
        resetTimeoutMinutes(): void;
        get timeoutMinutesInput(): number | undefined;
        private _ungraceful;
        get ungraceful(): WorkflowStepParallelConfigStepDocumentDbConfigUngracefulPropertyList;
        putUngraceful(value: WorkflowStepParallelConfigStepDocumentDbConfigUngracefulProperty[] | cdktn.IResolvable): void;
        resetUngraceful(): void;
        get ungracefulInput(): cdktn.IResolvable | WorkflowStepParallelConfigStepDocumentDbConfigUngracefulProperty[] | undefined;
    }
    class WorkflowStepParallelConfigStepDocumentDbConfigPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepParallelConfigStepDocumentDbConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepParallelConfigStepDocumentDbConfigPropertyOutputReference;
    }
    interface WorkflowStepParallelConfigStepEc2AsgCapacityIncreaseConfigAsgProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#arn AwsArcregionswitchPlan#arn}
        */
        readonly arn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#cross_account_role AwsArcregionswitchPlan#cross_account_role}
        */
        readonly crossAccountRole?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#external_id AwsArcregionswitchPlan#external_id}
        */
        readonly externalId?: string;
    }
    class WorkflowStepParallelConfigStepEc2AsgCapacityIncreaseConfigAsgPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepParallelConfigStepEc2AsgCapacityIncreaseConfigAsgProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepParallelConfigStepEc2AsgCapacityIncreaseConfigAsgProperty | cdktn.IResolvable | undefined);
        private _arn?;
        get arn(): string;
        set arn(value: string);
        get arnInput(): string | undefined;
        private _crossAccountRole?;
        get crossAccountRole(): string;
        set crossAccountRole(value: string);
        resetCrossAccountRole(): void;
        get crossAccountRoleInput(): string | undefined;
        private _externalId?;
        get externalId(): string;
        set externalId(value: string);
        resetExternalId(): void;
        get externalIdInput(): string | undefined;
    }
    class WorkflowStepParallelConfigStepEc2AsgCapacityIncreaseConfigAsgPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepParallelConfigStepEc2AsgCapacityIncreaseConfigAsgProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepParallelConfigStepEc2AsgCapacityIncreaseConfigAsgPropertyOutputReference;
    }
    interface WorkflowStepParallelConfigStepEc2AsgCapacityIncreaseConfigUngracefulProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#minimum_success_percentage AwsArcregionswitchPlan#minimum_success_percentage}
        */
        readonly minimumSuccessPercentage: number;
    }
    class WorkflowStepParallelConfigStepEc2AsgCapacityIncreaseConfigUngracefulPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepParallelConfigStepEc2AsgCapacityIncreaseConfigUngracefulProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepParallelConfigStepEc2AsgCapacityIncreaseConfigUngracefulProperty | cdktn.IResolvable | undefined);
        private _minimumSuccessPercentage?;
        get minimumSuccessPercentage(): number;
        set minimumSuccessPercentage(value: number);
        get minimumSuccessPercentageInput(): number | undefined;
    }
    class WorkflowStepParallelConfigStepEc2AsgCapacityIncreaseConfigUngracefulPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepParallelConfigStepEc2AsgCapacityIncreaseConfigUngracefulProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepParallelConfigStepEc2AsgCapacityIncreaseConfigUngracefulPropertyOutputReference;
    }
    interface WorkflowStepParallelConfigStepEc2AsgCapacityIncreaseConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#capacity_monitoring_approach AwsArcregionswitchPlan#capacity_monitoring_approach}
        */
        readonly capacityMonitoringApproach: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#target_percent AwsArcregionswitchPlan#target_percent}
        */
        readonly targetPercent?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#timeout_minutes AwsArcregionswitchPlan#timeout_minutes}
        */
        readonly timeoutMinutes?: number;
        /**
        * asg block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#asg AwsArcregionswitchPlan#asg}
        */
        readonly asg?: WorkflowStepParallelConfigStepEc2AsgCapacityIncreaseConfigAsgProperty[] | cdktn.IResolvable;
        /**
        * ungraceful block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#ungraceful AwsArcregionswitchPlan#ungraceful}
        */
        readonly ungraceful?: WorkflowStepParallelConfigStepEc2AsgCapacityIncreaseConfigUngracefulProperty[] | cdktn.IResolvable;
    }
    class WorkflowStepParallelConfigStepEc2AsgCapacityIncreaseConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepParallelConfigStepEc2AsgCapacityIncreaseConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepParallelConfigStepEc2AsgCapacityIncreaseConfigProperty | cdktn.IResolvable | undefined);
        private _capacityMonitoringApproach?;
        get capacityMonitoringApproach(): string;
        set capacityMonitoringApproach(value: string);
        get capacityMonitoringApproachInput(): string | undefined;
        private _targetPercent?;
        get targetPercent(): number;
        set targetPercent(value: number);
        resetTargetPercent(): void;
        get targetPercentInput(): number | undefined;
        private _timeoutMinutes?;
        get timeoutMinutes(): number;
        set timeoutMinutes(value: number);
        resetTimeoutMinutes(): void;
        get timeoutMinutesInput(): number | undefined;
        private _asg;
        get asg(): WorkflowStepParallelConfigStepEc2AsgCapacityIncreaseConfigAsgPropertyList;
        putAsg(value: WorkflowStepParallelConfigStepEc2AsgCapacityIncreaseConfigAsgProperty[] | cdktn.IResolvable): void;
        resetAsg(): void;
        get asgInput(): cdktn.IResolvable | WorkflowStepParallelConfigStepEc2AsgCapacityIncreaseConfigAsgProperty[] | undefined;
        private _ungraceful;
        get ungraceful(): WorkflowStepParallelConfigStepEc2AsgCapacityIncreaseConfigUngracefulPropertyList;
        putUngraceful(value: WorkflowStepParallelConfigStepEc2AsgCapacityIncreaseConfigUngracefulProperty[] | cdktn.IResolvable): void;
        resetUngraceful(): void;
        get ungracefulInput(): cdktn.IResolvable | WorkflowStepParallelConfigStepEc2AsgCapacityIncreaseConfigUngracefulProperty[] | undefined;
    }
    class WorkflowStepParallelConfigStepEc2AsgCapacityIncreaseConfigPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepParallelConfigStepEc2AsgCapacityIncreaseConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepParallelConfigStepEc2AsgCapacityIncreaseConfigPropertyOutputReference;
    }
    interface WorkflowStepParallelConfigStepEcsCapacityIncreaseConfigServiceProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#cluster_arn AwsArcregionswitchPlan#cluster_arn}
        */
        readonly clusterArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#cross_account_role AwsArcregionswitchPlan#cross_account_role}
        */
        readonly crossAccountRole?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#external_id AwsArcregionswitchPlan#external_id}
        */
        readonly externalId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#service_arn AwsArcregionswitchPlan#service_arn}
        */
        readonly serviceArn: string;
    }
    class WorkflowStepParallelConfigStepEcsCapacityIncreaseConfigServicePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepParallelConfigStepEcsCapacityIncreaseConfigServiceProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepParallelConfigStepEcsCapacityIncreaseConfigServiceProperty | cdktn.IResolvable | undefined);
        private _clusterArn?;
        get clusterArn(): string;
        set clusterArn(value: string);
        get clusterArnInput(): string | undefined;
        private _crossAccountRole?;
        get crossAccountRole(): string;
        set crossAccountRole(value: string);
        resetCrossAccountRole(): void;
        get crossAccountRoleInput(): string | undefined;
        private _externalId?;
        get externalId(): string;
        set externalId(value: string);
        resetExternalId(): void;
        get externalIdInput(): string | undefined;
        private _serviceArn?;
        get serviceArn(): string;
        set serviceArn(value: string);
        get serviceArnInput(): string | undefined;
    }
    class WorkflowStepParallelConfigStepEcsCapacityIncreaseConfigServicePropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepParallelConfigStepEcsCapacityIncreaseConfigServiceProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepParallelConfigStepEcsCapacityIncreaseConfigServicePropertyOutputReference;
    }
    interface WorkflowStepParallelConfigStepEcsCapacityIncreaseConfigUngracefulProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#minimum_success_percentage AwsArcregionswitchPlan#minimum_success_percentage}
        */
        readonly minimumSuccessPercentage: number;
    }
    class WorkflowStepParallelConfigStepEcsCapacityIncreaseConfigUngracefulPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepParallelConfigStepEcsCapacityIncreaseConfigUngracefulProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepParallelConfigStepEcsCapacityIncreaseConfigUngracefulProperty | cdktn.IResolvable | undefined);
        private _minimumSuccessPercentage?;
        get minimumSuccessPercentage(): number;
        set minimumSuccessPercentage(value: number);
        get minimumSuccessPercentageInput(): number | undefined;
    }
    class WorkflowStepParallelConfigStepEcsCapacityIncreaseConfigUngracefulPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepParallelConfigStepEcsCapacityIncreaseConfigUngracefulProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepParallelConfigStepEcsCapacityIncreaseConfigUngracefulPropertyOutputReference;
    }
    interface WorkflowStepParallelConfigStepEcsCapacityIncreaseConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#capacity_monitoring_approach AwsArcregionswitchPlan#capacity_monitoring_approach}
        */
        readonly capacityMonitoringApproach: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#target_percent AwsArcregionswitchPlan#target_percent}
        */
        readonly targetPercent?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#timeout_minutes AwsArcregionswitchPlan#timeout_minutes}
        */
        readonly timeoutMinutes?: number;
        /**
        * service block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#service AwsArcregionswitchPlan#service}
        */
        readonly service?: WorkflowStepParallelConfigStepEcsCapacityIncreaseConfigServiceProperty[] | cdktn.IResolvable;
        /**
        * ungraceful block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#ungraceful AwsArcregionswitchPlan#ungraceful}
        */
        readonly ungraceful?: WorkflowStepParallelConfigStepEcsCapacityIncreaseConfigUngracefulProperty[] | cdktn.IResolvable;
    }
    class WorkflowStepParallelConfigStepEcsCapacityIncreaseConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepParallelConfigStepEcsCapacityIncreaseConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepParallelConfigStepEcsCapacityIncreaseConfigProperty | cdktn.IResolvable | undefined);
        private _capacityMonitoringApproach?;
        get capacityMonitoringApproach(): string;
        set capacityMonitoringApproach(value: string);
        get capacityMonitoringApproachInput(): string | undefined;
        private _targetPercent?;
        get targetPercent(): number;
        set targetPercent(value: number);
        resetTargetPercent(): void;
        get targetPercentInput(): number | undefined;
        private _timeoutMinutes?;
        get timeoutMinutes(): number;
        set timeoutMinutes(value: number);
        resetTimeoutMinutes(): void;
        get timeoutMinutesInput(): number | undefined;
        private _service;
        get service(): WorkflowStepParallelConfigStepEcsCapacityIncreaseConfigServicePropertyList;
        putService(value: WorkflowStepParallelConfigStepEcsCapacityIncreaseConfigServiceProperty[] | cdktn.IResolvable): void;
        resetService(): void;
        get serviceInput(): cdktn.IResolvable | WorkflowStepParallelConfigStepEcsCapacityIncreaseConfigServiceProperty[] | undefined;
        private _ungraceful;
        get ungraceful(): WorkflowStepParallelConfigStepEcsCapacityIncreaseConfigUngracefulPropertyList;
        putUngraceful(value: WorkflowStepParallelConfigStepEcsCapacityIncreaseConfigUngracefulProperty[] | cdktn.IResolvable): void;
        resetUngraceful(): void;
        get ungracefulInput(): cdktn.IResolvable | WorkflowStepParallelConfigStepEcsCapacityIncreaseConfigUngracefulProperty[] | undefined;
    }
    class WorkflowStepParallelConfigStepEcsCapacityIncreaseConfigPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepParallelConfigStepEcsCapacityIncreaseConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepParallelConfigStepEcsCapacityIncreaseConfigPropertyOutputReference;
    }
    interface WorkflowStepParallelConfigStepEksResourceScalingConfigEksClustersProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#cluster_arn AwsArcregionswitchPlan#cluster_arn}
        */
        readonly clusterArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#cross_account_role AwsArcregionswitchPlan#cross_account_role}
        */
        readonly crossAccountRole?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#external_id AwsArcregionswitchPlan#external_id}
        */
        readonly externalId?: string;
    }
    class WorkflowStepParallelConfigStepEksResourceScalingConfigEksClustersPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepParallelConfigStepEksResourceScalingConfigEksClustersProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepParallelConfigStepEksResourceScalingConfigEksClustersProperty | cdktn.IResolvable | undefined);
        private _clusterArn?;
        get clusterArn(): string;
        set clusterArn(value: string);
        get clusterArnInput(): string | undefined;
        private _crossAccountRole?;
        get crossAccountRole(): string;
        set crossAccountRole(value: string);
        resetCrossAccountRole(): void;
        get crossAccountRoleInput(): string | undefined;
        private _externalId?;
        get externalId(): string;
        set externalId(value: string);
        resetExternalId(): void;
        get externalIdInput(): string | undefined;
    }
    class WorkflowStepParallelConfigStepEksResourceScalingConfigEksClustersPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepParallelConfigStepEksResourceScalingConfigEksClustersProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepParallelConfigStepEksResourceScalingConfigEksClustersPropertyOutputReference;
    }
    interface WorkflowStepParallelConfigStepEksResourceScalingConfigKubernetesResourceTypeProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#api_version AwsArcregionswitchPlan#api_version}
        */
        readonly apiVersion: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#kind AwsArcregionswitchPlan#kind}
        */
        readonly kind: string;
    }
    class WorkflowStepParallelConfigStepEksResourceScalingConfigKubernetesResourceTypePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepParallelConfigStepEksResourceScalingConfigKubernetesResourceTypeProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepParallelConfigStepEksResourceScalingConfigKubernetesResourceTypeProperty | cdktn.IResolvable | undefined);
        private _apiVersion?;
        get apiVersion(): string;
        set apiVersion(value: string);
        get apiVersionInput(): string | undefined;
        private _kind?;
        get kind(): string;
        set kind(value: string);
        get kindInput(): string | undefined;
    }
    class WorkflowStepParallelConfigStepEksResourceScalingConfigKubernetesResourceTypePropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepParallelConfigStepEksResourceScalingConfigKubernetesResourceTypeProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepParallelConfigStepEksResourceScalingConfigKubernetesResourceTypePropertyOutputReference;
    }
    interface WorkflowStepParallelConfigStepEksResourceScalingConfigScalingResourcesResourcesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#hpa_name AwsArcregionswitchPlan#hpa_name}
        */
        readonly hpaName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#name AwsArcregionswitchPlan#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#namespace AwsArcregionswitchPlan#namespace}
        */
        readonly namespace: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#resource_name AwsArcregionswitchPlan#resource_name}
        */
        readonly resourceName: string;
    }
    class WorkflowStepParallelConfigStepEksResourceScalingConfigScalingResourcesResourcesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepParallelConfigStepEksResourceScalingConfigScalingResourcesResourcesProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepParallelConfigStepEksResourceScalingConfigScalingResourcesResourcesProperty | cdktn.IResolvable | undefined);
        private _hpaName?;
        get hpaName(): string;
        set hpaName(value: string);
        resetHpaName(): void;
        get hpaNameInput(): string | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _namespace?;
        get namespace(): string;
        set namespace(value: string);
        get namespaceInput(): string | undefined;
        private _resourceName?;
        get resourceName(): string;
        set resourceName(value: string);
        get resourceNameInput(): string | undefined;
    }
    class WorkflowStepParallelConfigStepEksResourceScalingConfigScalingResourcesResourcesPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepParallelConfigStepEksResourceScalingConfigScalingResourcesResourcesProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepParallelConfigStepEksResourceScalingConfigScalingResourcesResourcesPropertyOutputReference;
    }
    interface WorkflowStepParallelConfigStepEksResourceScalingConfigScalingResourcesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#namespace AwsArcregionswitchPlan#namespace}
        */
        readonly namespace: string;
        /**
        * resources block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#resources AwsArcregionswitchPlan#resources}
        */
        readonly resources?: WorkflowStepParallelConfigStepEksResourceScalingConfigScalingResourcesResourcesProperty[] | cdktn.IResolvable;
    }
    class WorkflowStepParallelConfigStepEksResourceScalingConfigScalingResourcesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepParallelConfigStepEksResourceScalingConfigScalingResourcesProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepParallelConfigStepEksResourceScalingConfigScalingResourcesProperty | cdktn.IResolvable | undefined);
        private _namespace?;
        get namespace(): string;
        set namespace(value: string);
        get namespaceInput(): string | undefined;
        private _resources;
        get resources(): WorkflowStepParallelConfigStepEksResourceScalingConfigScalingResourcesResourcesPropertyList;
        putResources(value: WorkflowStepParallelConfigStepEksResourceScalingConfigScalingResourcesResourcesProperty[] | cdktn.IResolvable): void;
        resetResources(): void;
        get resourcesInput(): cdktn.IResolvable | WorkflowStepParallelConfigStepEksResourceScalingConfigScalingResourcesResourcesProperty[] | undefined;
    }
    class WorkflowStepParallelConfigStepEksResourceScalingConfigScalingResourcesPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepParallelConfigStepEksResourceScalingConfigScalingResourcesProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepParallelConfigStepEksResourceScalingConfigScalingResourcesPropertyOutputReference;
    }
    interface WorkflowStepParallelConfigStepEksResourceScalingConfigUngracefulProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#minimum_success_percentage AwsArcregionswitchPlan#minimum_success_percentage}
        */
        readonly minimumSuccessPercentage: number;
    }
    class WorkflowStepParallelConfigStepEksResourceScalingConfigUngracefulPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepParallelConfigStepEksResourceScalingConfigUngracefulProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepParallelConfigStepEksResourceScalingConfigUngracefulProperty | cdktn.IResolvable | undefined);
        private _minimumSuccessPercentage?;
        get minimumSuccessPercentage(): number;
        set minimumSuccessPercentage(value: number);
        get minimumSuccessPercentageInput(): number | undefined;
    }
    class WorkflowStepParallelConfigStepEksResourceScalingConfigUngracefulPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepParallelConfigStepEksResourceScalingConfigUngracefulProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepParallelConfigStepEksResourceScalingConfigUngracefulPropertyOutputReference;
    }
    interface WorkflowStepParallelConfigStepEksResourceScalingConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#capacity_monitoring_approach AwsArcregionswitchPlan#capacity_monitoring_approach}
        */
        readonly capacityMonitoringApproach: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#target_percent AwsArcregionswitchPlan#target_percent}
        */
        readonly targetPercent: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#timeout_minutes AwsArcregionswitchPlan#timeout_minutes}
        */
        readonly timeoutMinutes?: number;
        /**
        * eks_clusters block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#eks_clusters AwsArcregionswitchPlan#eks_clusters}
        */
        readonly eksClusters?: WorkflowStepParallelConfigStepEksResourceScalingConfigEksClustersProperty[] | cdktn.IResolvable;
        /**
        * kubernetes_resource_type block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#kubernetes_resource_type AwsArcregionswitchPlan#kubernetes_resource_type}
        */
        readonly kubernetesResourceType?: WorkflowStepParallelConfigStepEksResourceScalingConfigKubernetesResourceTypeProperty[] | cdktn.IResolvable;
        /**
        * scaling_resources block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#scaling_resources AwsArcregionswitchPlan#scaling_resources}
        */
        readonly scalingResources?: WorkflowStepParallelConfigStepEksResourceScalingConfigScalingResourcesProperty[] | cdktn.IResolvable;
        /**
        * ungraceful block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#ungraceful AwsArcregionswitchPlan#ungraceful}
        */
        readonly ungraceful?: WorkflowStepParallelConfigStepEksResourceScalingConfigUngracefulProperty[] | cdktn.IResolvable;
    }
    class WorkflowStepParallelConfigStepEksResourceScalingConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepParallelConfigStepEksResourceScalingConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepParallelConfigStepEksResourceScalingConfigProperty | cdktn.IResolvable | undefined);
        private _capacityMonitoringApproach?;
        get capacityMonitoringApproach(): string;
        set capacityMonitoringApproach(value: string);
        get capacityMonitoringApproachInput(): string | undefined;
        private _targetPercent?;
        get targetPercent(): number;
        set targetPercent(value: number);
        get targetPercentInput(): number | undefined;
        private _timeoutMinutes?;
        get timeoutMinutes(): number;
        set timeoutMinutes(value: number);
        resetTimeoutMinutes(): void;
        get timeoutMinutesInput(): number | undefined;
        private _eksClusters;
        get eksClusters(): WorkflowStepParallelConfigStepEksResourceScalingConfigEksClustersPropertyList;
        putEksClusters(value: WorkflowStepParallelConfigStepEksResourceScalingConfigEksClustersProperty[] | cdktn.IResolvable): void;
        resetEksClusters(): void;
        get eksClustersInput(): cdktn.IResolvable | WorkflowStepParallelConfigStepEksResourceScalingConfigEksClustersProperty[] | undefined;
        private _kubernetesResourceType;
        get kubernetesResourceType(): WorkflowStepParallelConfigStepEksResourceScalingConfigKubernetesResourceTypePropertyList;
        putKubernetesResourceType(value: WorkflowStepParallelConfigStepEksResourceScalingConfigKubernetesResourceTypeProperty[] | cdktn.IResolvable): void;
        resetKubernetesResourceType(): void;
        get kubernetesResourceTypeInput(): cdktn.IResolvable | WorkflowStepParallelConfigStepEksResourceScalingConfigKubernetesResourceTypeProperty[] | undefined;
        private _scalingResources;
        get scalingResources(): WorkflowStepParallelConfigStepEksResourceScalingConfigScalingResourcesPropertyList;
        putScalingResources(value: WorkflowStepParallelConfigStepEksResourceScalingConfigScalingResourcesProperty[] | cdktn.IResolvable): void;
        resetScalingResources(): void;
        get scalingResourcesInput(): cdktn.IResolvable | WorkflowStepParallelConfigStepEksResourceScalingConfigScalingResourcesProperty[] | undefined;
        private _ungraceful;
        get ungraceful(): WorkflowStepParallelConfigStepEksResourceScalingConfigUngracefulPropertyList;
        putUngraceful(value: WorkflowStepParallelConfigStepEksResourceScalingConfigUngracefulProperty[] | cdktn.IResolvable): void;
        resetUngraceful(): void;
        get ungracefulInput(): cdktn.IResolvable | WorkflowStepParallelConfigStepEksResourceScalingConfigUngracefulProperty[] | undefined;
    }
    class WorkflowStepParallelConfigStepEksResourceScalingConfigPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepParallelConfigStepEksResourceScalingConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepParallelConfigStepEksResourceScalingConfigPropertyOutputReference;
    }
    interface WorkflowStepParallelConfigStepExecutionApprovalConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#approval_role AwsArcregionswitchPlan#approval_role}
        */
        readonly approvalRole: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#timeout_minutes AwsArcregionswitchPlan#timeout_minutes}
        */
        readonly timeoutMinutes?: number;
    }
    class WorkflowStepParallelConfigStepExecutionApprovalConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepParallelConfigStepExecutionApprovalConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepParallelConfigStepExecutionApprovalConfigProperty | cdktn.IResolvable | undefined);
        private _approvalRole?;
        get approvalRole(): string;
        set approvalRole(value: string);
        get approvalRoleInput(): string | undefined;
        private _timeoutMinutes?;
        get timeoutMinutes(): number;
        set timeoutMinutes(value: number);
        resetTimeoutMinutes(): void;
        get timeoutMinutesInput(): number | undefined;
    }
    class WorkflowStepParallelConfigStepExecutionApprovalConfigPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepParallelConfigStepExecutionApprovalConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepParallelConfigStepExecutionApprovalConfigPropertyOutputReference;
    }
    interface WorkflowStepParallelConfigStepGlobalAuroraConfigUngracefulProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#ungraceful AwsArcregionswitchPlan#ungraceful}
        */
        readonly ungraceful: string;
    }
    class WorkflowStepParallelConfigStepGlobalAuroraConfigUngracefulPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepParallelConfigStepGlobalAuroraConfigUngracefulProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepParallelConfigStepGlobalAuroraConfigUngracefulProperty | cdktn.IResolvable | undefined);
        private _ungraceful?;
        get ungraceful(): string;
        set ungraceful(value: string);
        get ungracefulInput(): string | undefined;
    }
    class WorkflowStepParallelConfigStepGlobalAuroraConfigUngracefulPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepParallelConfigStepGlobalAuroraConfigUngracefulProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepParallelConfigStepGlobalAuroraConfigUngracefulPropertyOutputReference;
    }
    interface WorkflowStepParallelConfigStepGlobalAuroraConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#behavior AwsArcregionswitchPlan#behavior}
        */
        readonly behavior: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#cross_account_role AwsArcregionswitchPlan#cross_account_role}
        */
        readonly crossAccountRole?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#database_cluster_arns AwsArcregionswitchPlan#database_cluster_arns}
        */
        readonly databaseClusterArns: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#external_id AwsArcregionswitchPlan#external_id}
        */
        readonly externalId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#global_cluster_identifier AwsArcregionswitchPlan#global_cluster_identifier}
        */
        readonly globalClusterIdentifier: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#timeout_minutes AwsArcregionswitchPlan#timeout_minutes}
        */
        readonly timeoutMinutes?: number;
        /**
        * ungraceful block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#ungraceful AwsArcregionswitchPlan#ungraceful}
        */
        readonly ungraceful?: WorkflowStepParallelConfigStepGlobalAuroraConfigUngracefulProperty[] | cdktn.IResolvable;
    }
    class WorkflowStepParallelConfigStepGlobalAuroraConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepParallelConfigStepGlobalAuroraConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepParallelConfigStepGlobalAuroraConfigProperty | cdktn.IResolvable | undefined);
        private _behavior?;
        get behavior(): string;
        set behavior(value: string);
        get behaviorInput(): string | undefined;
        private _crossAccountRole?;
        get crossAccountRole(): string;
        set crossAccountRole(value: string);
        resetCrossAccountRole(): void;
        get crossAccountRoleInput(): string | undefined;
        private _databaseClusterArns?;
        get databaseClusterArns(): string[];
        set databaseClusterArns(value: string[]);
        get databaseClusterArnsInput(): string[] | undefined;
        private _externalId?;
        get externalId(): string;
        set externalId(value: string);
        resetExternalId(): void;
        get externalIdInput(): string | undefined;
        private _globalClusterIdentifier?;
        get globalClusterIdentifier(): string;
        set globalClusterIdentifier(value: string);
        get globalClusterIdentifierInput(): string | undefined;
        private _timeoutMinutes?;
        get timeoutMinutes(): number;
        set timeoutMinutes(value: number);
        resetTimeoutMinutes(): void;
        get timeoutMinutesInput(): number | undefined;
        private _ungraceful;
        get ungraceful(): WorkflowStepParallelConfigStepGlobalAuroraConfigUngracefulPropertyList;
        putUngraceful(value: WorkflowStepParallelConfigStepGlobalAuroraConfigUngracefulProperty[] | cdktn.IResolvable): void;
        resetUngraceful(): void;
        get ungracefulInput(): cdktn.IResolvable | WorkflowStepParallelConfigStepGlobalAuroraConfigUngracefulProperty[] | undefined;
    }
    class WorkflowStepParallelConfigStepGlobalAuroraConfigPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepParallelConfigStepGlobalAuroraConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepParallelConfigStepGlobalAuroraConfigPropertyOutputReference;
    }
    interface WorkflowStepParallelConfigStepLambdaEventSourceMappingConfigRegionEventSourceMappingProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#arn AwsArcregionswitchPlan#arn}
        */
        readonly arn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#cross_account_role AwsArcregionswitchPlan#cross_account_role}
        */
        readonly crossAccountRole?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#external_id AwsArcregionswitchPlan#external_id}
        */
        readonly externalId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#region AwsArcregionswitchPlan#region}
        */
        readonly region: string;
    }
    class WorkflowStepParallelConfigStepLambdaEventSourceMappingConfigRegionEventSourceMappingPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepParallelConfigStepLambdaEventSourceMappingConfigRegionEventSourceMappingProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepParallelConfigStepLambdaEventSourceMappingConfigRegionEventSourceMappingProperty | cdktn.IResolvable | undefined);
        private _arn?;
        get arn(): string;
        set arn(value: string);
        get arnInput(): string | undefined;
        private _crossAccountRole?;
        get crossAccountRole(): string;
        set crossAccountRole(value: string);
        resetCrossAccountRole(): void;
        get crossAccountRoleInput(): string | undefined;
        private _externalId?;
        get externalId(): string;
        set externalId(value: string);
        resetExternalId(): void;
        get externalIdInput(): string | undefined;
        private _region?;
        get region(): string;
        set region(value: string);
        get regionInput(): string | undefined;
    }
    class WorkflowStepParallelConfigStepLambdaEventSourceMappingConfigRegionEventSourceMappingPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepParallelConfigStepLambdaEventSourceMappingConfigRegionEventSourceMappingProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepParallelConfigStepLambdaEventSourceMappingConfigRegionEventSourceMappingPropertyOutputReference;
    }
    interface WorkflowStepParallelConfigStepLambdaEventSourceMappingConfigUngracefulProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#behavior AwsArcregionswitchPlan#behavior}
        */
        readonly behavior: string;
    }
    class WorkflowStepParallelConfigStepLambdaEventSourceMappingConfigUngracefulPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepParallelConfigStepLambdaEventSourceMappingConfigUngracefulProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepParallelConfigStepLambdaEventSourceMappingConfigUngracefulProperty | cdktn.IResolvable | undefined);
        private _behavior?;
        get behavior(): string;
        set behavior(value: string);
        get behaviorInput(): string | undefined;
    }
    class WorkflowStepParallelConfigStepLambdaEventSourceMappingConfigUngracefulPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepParallelConfigStepLambdaEventSourceMappingConfigUngracefulProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepParallelConfigStepLambdaEventSourceMappingConfigUngracefulPropertyOutputReference;
    }
    interface WorkflowStepParallelConfigStepLambdaEventSourceMappingConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#action AwsArcregionswitchPlan#action}
        */
        readonly action: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#timeout_minutes AwsArcregionswitchPlan#timeout_minutes}
        */
        readonly timeoutMinutes?: number;
        /**
        * region_event_source_mapping block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#region_event_source_mapping AwsArcregionswitchPlan#region_event_source_mapping}
        */
        readonly regionEventSourceMapping?: WorkflowStepParallelConfigStepLambdaEventSourceMappingConfigRegionEventSourceMappingProperty[] | cdktn.IResolvable;
        /**
        * ungraceful block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#ungraceful AwsArcregionswitchPlan#ungraceful}
        */
        readonly ungraceful?: WorkflowStepParallelConfigStepLambdaEventSourceMappingConfigUngracefulProperty[] | cdktn.IResolvable;
    }
    class WorkflowStepParallelConfigStepLambdaEventSourceMappingConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepParallelConfigStepLambdaEventSourceMappingConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepParallelConfigStepLambdaEventSourceMappingConfigProperty | cdktn.IResolvable | undefined);
        private _action?;
        get action(): string;
        set action(value: string);
        get actionInput(): string | undefined;
        private _timeoutMinutes?;
        get timeoutMinutes(): number;
        set timeoutMinutes(value: number);
        resetTimeoutMinutes(): void;
        get timeoutMinutesInput(): number | undefined;
        private _regionEventSourceMapping;
        get regionEventSourceMapping(): WorkflowStepParallelConfigStepLambdaEventSourceMappingConfigRegionEventSourceMappingPropertyList;
        putRegionEventSourceMapping(value: WorkflowStepParallelConfigStepLambdaEventSourceMappingConfigRegionEventSourceMappingProperty[] | cdktn.IResolvable): void;
        resetRegionEventSourceMapping(): void;
        get regionEventSourceMappingInput(): cdktn.IResolvable | WorkflowStepParallelConfigStepLambdaEventSourceMappingConfigRegionEventSourceMappingProperty[] | undefined;
        private _ungraceful;
        get ungraceful(): WorkflowStepParallelConfigStepLambdaEventSourceMappingConfigUngracefulPropertyList;
        putUngraceful(value: WorkflowStepParallelConfigStepLambdaEventSourceMappingConfigUngracefulProperty[] | cdktn.IResolvable): void;
        resetUngraceful(): void;
        get ungracefulInput(): cdktn.IResolvable | WorkflowStepParallelConfigStepLambdaEventSourceMappingConfigUngracefulProperty[] | undefined;
    }
    class WorkflowStepParallelConfigStepLambdaEventSourceMappingConfigPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepParallelConfigStepLambdaEventSourceMappingConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepParallelConfigStepLambdaEventSourceMappingConfigPropertyOutputReference;
    }
    interface WorkflowStepParallelConfigStepNeptuneGlobalDatabaseConfigUngracefulProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#ungraceful AwsArcregionswitchPlan#ungraceful}
        */
        readonly ungraceful: string;
    }
    class WorkflowStepParallelConfigStepNeptuneGlobalDatabaseConfigUngracefulPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepParallelConfigStepNeptuneGlobalDatabaseConfigUngracefulProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepParallelConfigStepNeptuneGlobalDatabaseConfigUngracefulProperty | cdktn.IResolvable | undefined);
        private _ungraceful?;
        get ungraceful(): string;
        set ungraceful(value: string);
        get ungracefulInput(): string | undefined;
    }
    class WorkflowStepParallelConfigStepNeptuneGlobalDatabaseConfigUngracefulPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepParallelConfigStepNeptuneGlobalDatabaseConfigUngracefulProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepParallelConfigStepNeptuneGlobalDatabaseConfigUngracefulPropertyOutputReference;
    }
    interface WorkflowStepParallelConfigStepNeptuneGlobalDatabaseConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#behavior AwsArcregionswitchPlan#behavior}
        */
        readonly behavior: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#cross_account_role AwsArcregionswitchPlan#cross_account_role}
        */
        readonly crossAccountRole?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#external_id AwsArcregionswitchPlan#external_id}
        */
        readonly externalId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#global_cluster_identifier AwsArcregionswitchPlan#global_cluster_identifier}
        */
        readonly globalClusterIdentifier: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#region_database_cluster_arns AwsArcregionswitchPlan#region_database_cluster_arns}
        */
        readonly regionDatabaseClusterArns: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#timeout_minutes AwsArcregionswitchPlan#timeout_minutes}
        */
        readonly timeoutMinutes?: number;
        /**
        * ungraceful block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#ungraceful AwsArcregionswitchPlan#ungraceful}
        */
        readonly ungraceful?: WorkflowStepParallelConfigStepNeptuneGlobalDatabaseConfigUngracefulProperty[] | cdktn.IResolvable;
    }
    class WorkflowStepParallelConfigStepNeptuneGlobalDatabaseConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepParallelConfigStepNeptuneGlobalDatabaseConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepParallelConfigStepNeptuneGlobalDatabaseConfigProperty | cdktn.IResolvable | undefined);
        private _behavior?;
        get behavior(): string;
        set behavior(value: string);
        get behaviorInput(): string | undefined;
        private _crossAccountRole?;
        get crossAccountRole(): string;
        set crossAccountRole(value: string);
        resetCrossAccountRole(): void;
        get crossAccountRoleInput(): string | undefined;
        private _externalId?;
        get externalId(): string;
        set externalId(value: string);
        resetExternalId(): void;
        get externalIdInput(): string | undefined;
        private _globalClusterIdentifier?;
        get globalClusterIdentifier(): string;
        set globalClusterIdentifier(value: string);
        get globalClusterIdentifierInput(): string | undefined;
        private _regionDatabaseClusterArns?;
        get regionDatabaseClusterArns(): {
            [key: string]: string;
        };
        set regionDatabaseClusterArns(value: {
            [key: string]: string;
        });
        get regionDatabaseClusterArnsInput(): {
            [key: string]: string;
        } | undefined;
        private _timeoutMinutes?;
        get timeoutMinutes(): number;
        set timeoutMinutes(value: number);
        resetTimeoutMinutes(): void;
        get timeoutMinutesInput(): number | undefined;
        private _ungraceful;
        get ungraceful(): WorkflowStepParallelConfigStepNeptuneGlobalDatabaseConfigUngracefulPropertyList;
        putUngraceful(value: WorkflowStepParallelConfigStepNeptuneGlobalDatabaseConfigUngracefulProperty[] | cdktn.IResolvable): void;
        resetUngraceful(): void;
        get ungracefulInput(): cdktn.IResolvable | WorkflowStepParallelConfigStepNeptuneGlobalDatabaseConfigUngracefulProperty[] | undefined;
    }
    class WorkflowStepParallelConfigStepNeptuneGlobalDatabaseConfigPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepParallelConfigStepNeptuneGlobalDatabaseConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepParallelConfigStepNeptuneGlobalDatabaseConfigPropertyOutputReference;
    }
    interface WorkflowStepParallelConfigStepRdsCreateCrossRegionReadReplicaConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#cross_account_role AwsArcregionswitchPlan#cross_account_role}
        */
        readonly crossAccountRole?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#db_instance_arn_map AwsArcregionswitchPlan#db_instance_arn_map}
        */
        readonly dbInstanceArnMap: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#external_id AwsArcregionswitchPlan#external_id}
        */
        readonly externalId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#timeout_minutes AwsArcregionswitchPlan#timeout_minutes}
        */
        readonly timeoutMinutes?: number;
    }
    class WorkflowStepParallelConfigStepRdsCreateCrossRegionReadReplicaConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepParallelConfigStepRdsCreateCrossRegionReadReplicaConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepParallelConfigStepRdsCreateCrossRegionReadReplicaConfigProperty | cdktn.IResolvable | undefined);
        private _crossAccountRole?;
        get crossAccountRole(): string;
        set crossAccountRole(value: string);
        resetCrossAccountRole(): void;
        get crossAccountRoleInput(): string | undefined;
        private _dbInstanceArnMap?;
        get dbInstanceArnMap(): {
            [key: string]: string;
        };
        set dbInstanceArnMap(value: {
            [key: string]: string;
        });
        get dbInstanceArnMapInput(): {
            [key: string]: string;
        } | undefined;
        private _externalId?;
        get externalId(): string;
        set externalId(value: string);
        resetExternalId(): void;
        get externalIdInput(): string | undefined;
        private _timeoutMinutes?;
        get timeoutMinutes(): number;
        set timeoutMinutes(value: number);
        resetTimeoutMinutes(): void;
        get timeoutMinutesInput(): number | undefined;
    }
    class WorkflowStepParallelConfigStepRdsCreateCrossRegionReadReplicaConfigPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepParallelConfigStepRdsCreateCrossRegionReadReplicaConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepParallelConfigStepRdsCreateCrossRegionReadReplicaConfigPropertyOutputReference;
    }
    interface WorkflowStepParallelConfigStepRdsPromoteReadReplicaConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#cross_account_role AwsArcregionswitchPlan#cross_account_role}
        */
        readonly crossAccountRole?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#db_instance_arn_map AwsArcregionswitchPlan#db_instance_arn_map}
        */
        readonly dbInstanceArnMap: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#external_id AwsArcregionswitchPlan#external_id}
        */
        readonly externalId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#timeout_minutes AwsArcregionswitchPlan#timeout_minutes}
        */
        readonly timeoutMinutes?: number;
    }
    class WorkflowStepParallelConfigStepRdsPromoteReadReplicaConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepParallelConfigStepRdsPromoteReadReplicaConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepParallelConfigStepRdsPromoteReadReplicaConfigProperty | cdktn.IResolvable | undefined);
        private _crossAccountRole?;
        get crossAccountRole(): string;
        set crossAccountRole(value: string);
        resetCrossAccountRole(): void;
        get crossAccountRoleInput(): string | undefined;
        private _dbInstanceArnMap?;
        get dbInstanceArnMap(): {
            [key: string]: string;
        };
        set dbInstanceArnMap(value: {
            [key: string]: string;
        });
        get dbInstanceArnMapInput(): {
            [key: string]: string;
        } | undefined;
        private _externalId?;
        get externalId(): string;
        set externalId(value: string);
        resetExternalId(): void;
        get externalIdInput(): string | undefined;
        private _timeoutMinutes?;
        get timeoutMinutes(): number;
        set timeoutMinutes(value: number);
        resetTimeoutMinutes(): void;
        get timeoutMinutesInput(): number | undefined;
    }
    class WorkflowStepParallelConfigStepRdsPromoteReadReplicaConfigPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepParallelConfigStepRdsPromoteReadReplicaConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepParallelConfigStepRdsPromoteReadReplicaConfigPropertyOutputReference;
    }
    interface WorkflowStepParallelConfigStepRegionSwitchPlanConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#arn AwsArcregionswitchPlan#arn}
        */
        readonly arn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#cross_account_role AwsArcregionswitchPlan#cross_account_role}
        */
        readonly crossAccountRole?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#external_id AwsArcregionswitchPlan#external_id}
        */
        readonly externalId?: string;
    }
    class WorkflowStepParallelConfigStepRegionSwitchPlanConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepParallelConfigStepRegionSwitchPlanConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepParallelConfigStepRegionSwitchPlanConfigProperty | cdktn.IResolvable | undefined);
        private _arn?;
        get arn(): string;
        set arn(value: string);
        get arnInput(): string | undefined;
        private _crossAccountRole?;
        get crossAccountRole(): string;
        set crossAccountRole(value: string);
        resetCrossAccountRole(): void;
        get crossAccountRoleInput(): string | undefined;
        private _externalId?;
        get externalId(): string;
        set externalId(value: string);
        resetExternalId(): void;
        get externalIdInput(): string | undefined;
    }
    class WorkflowStepParallelConfigStepRegionSwitchPlanConfigPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepParallelConfigStepRegionSwitchPlanConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepParallelConfigStepRegionSwitchPlanConfigPropertyOutputReference;
    }
    interface WorkflowStepParallelConfigStepRoute53HealthCheckConfigRecordSetProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#record_set_identifier AwsArcregionswitchPlan#record_set_identifier}
        */
        readonly recordSetIdentifier: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#region AwsArcregionswitchPlan#region}
        */
        readonly region: string;
    }
    class WorkflowStepParallelConfigStepRoute53HealthCheckConfigRecordSetPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepParallelConfigStepRoute53HealthCheckConfigRecordSetProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepParallelConfigStepRoute53HealthCheckConfigRecordSetProperty | cdktn.IResolvable | undefined);
        private _recordSetIdentifier?;
        get recordSetIdentifier(): string;
        set recordSetIdentifier(value: string);
        get recordSetIdentifierInput(): string | undefined;
        private _region?;
        get region(): string;
        set region(value: string);
        get regionInput(): string | undefined;
    }
    class WorkflowStepParallelConfigStepRoute53HealthCheckConfigRecordSetPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepParallelConfigStepRoute53HealthCheckConfigRecordSetProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepParallelConfigStepRoute53HealthCheckConfigRecordSetPropertyOutputReference;
    }
    interface WorkflowStepParallelConfigStepRoute53HealthCheckConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#cross_account_role AwsArcregionswitchPlan#cross_account_role}
        */
        readonly crossAccountRole?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#external_id AwsArcregionswitchPlan#external_id}
        */
        readonly externalId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#hosted_zone_id AwsArcregionswitchPlan#hosted_zone_id}
        */
        readonly hostedZoneId: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#record_name AwsArcregionswitchPlan#record_name}
        */
        readonly recordName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#timeout_minutes AwsArcregionswitchPlan#timeout_minutes}
        */
        readonly timeoutMinutes?: number;
        /**
        * record_set block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#record_set AwsArcregionswitchPlan#record_set}
        */
        readonly recordSet?: WorkflowStepParallelConfigStepRoute53HealthCheckConfigRecordSetProperty[] | cdktn.IResolvable;
    }
    class WorkflowStepParallelConfigStepRoute53HealthCheckConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepParallelConfigStepRoute53HealthCheckConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepParallelConfigStepRoute53HealthCheckConfigProperty | cdktn.IResolvable | undefined);
        private _crossAccountRole?;
        get crossAccountRole(): string;
        set crossAccountRole(value: string);
        resetCrossAccountRole(): void;
        get crossAccountRoleInput(): string | undefined;
        private _externalId?;
        get externalId(): string;
        set externalId(value: string);
        resetExternalId(): void;
        get externalIdInput(): string | undefined;
        private _hostedZoneId?;
        get hostedZoneId(): string;
        set hostedZoneId(value: string);
        get hostedZoneIdInput(): string | undefined;
        private _recordName?;
        get recordName(): string;
        set recordName(value: string);
        get recordNameInput(): string | undefined;
        private _timeoutMinutes?;
        get timeoutMinutes(): number;
        set timeoutMinutes(value: number);
        resetTimeoutMinutes(): void;
        get timeoutMinutesInput(): number | undefined;
        private _recordSet;
        get recordSet(): WorkflowStepParallelConfigStepRoute53HealthCheckConfigRecordSetPropertyList;
        putRecordSet(value: WorkflowStepParallelConfigStepRoute53HealthCheckConfigRecordSetProperty[] | cdktn.IResolvable): void;
        resetRecordSet(): void;
        get recordSetInput(): cdktn.IResolvable | WorkflowStepParallelConfigStepRoute53HealthCheckConfigRecordSetProperty[] | undefined;
    }
    class WorkflowStepParallelConfigStepRoute53HealthCheckConfigPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepParallelConfigStepRoute53HealthCheckConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepParallelConfigStepRoute53HealthCheckConfigPropertyOutputReference;
    }
    interface WorkflowStepParallelConfigStepProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#description AwsArcregionswitchPlan#description}
        */
        readonly description?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#execution_block_type AwsArcregionswitchPlan#execution_block_type}
        */
        readonly executionBlockType: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#name AwsArcregionswitchPlan#name}
        */
        readonly name: string;
        /**
        * arc_routing_control_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#arc_routing_control_config AwsArcregionswitchPlan#arc_routing_control_config}
        */
        readonly arcRoutingControlConfig?: WorkflowStepParallelConfigStepArcRoutingControlConfigProperty[] | cdktn.IResolvable;
        /**
        * aurora_provisioned_scaling_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#aurora_provisioned_scaling_config AwsArcregionswitchPlan#aurora_provisioned_scaling_config}
        */
        readonly auroraProvisionedScalingConfig?: WorkflowStepParallelConfigStepAuroraProvisionedScalingConfigProperty[] | cdktn.IResolvable;
        /**
        * aurora_serverless_scaling_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#aurora_serverless_scaling_config AwsArcregionswitchPlan#aurora_serverless_scaling_config}
        */
        readonly auroraServerlessScalingConfig?: WorkflowStepParallelConfigStepAuroraServerlessScalingConfigProperty[] | cdktn.IResolvable;
        /**
        * custom_action_lambda_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#custom_action_lambda_config AwsArcregionswitchPlan#custom_action_lambda_config}
        */
        readonly customActionLambdaConfig?: WorkflowStepParallelConfigStepCustomActionLambdaConfigProperty[] | cdktn.IResolvable;
        /**
        * document_db_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#document_db_config AwsArcregionswitchPlan#document_db_config}
        */
        readonly documentDbConfig?: WorkflowStepParallelConfigStepDocumentDbConfigProperty[] | cdktn.IResolvable;
        /**
        * ec2_asg_capacity_increase_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#ec2_asg_capacity_increase_config AwsArcregionswitchPlan#ec2_asg_capacity_increase_config}
        */
        readonly ec2AsgCapacityIncreaseConfig?: WorkflowStepParallelConfigStepEc2AsgCapacityIncreaseConfigProperty[] | cdktn.IResolvable;
        /**
        * ecs_capacity_increase_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#ecs_capacity_increase_config AwsArcregionswitchPlan#ecs_capacity_increase_config}
        */
        readonly ecsCapacityIncreaseConfig?: WorkflowStepParallelConfigStepEcsCapacityIncreaseConfigProperty[] | cdktn.IResolvable;
        /**
        * eks_resource_scaling_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#eks_resource_scaling_config AwsArcregionswitchPlan#eks_resource_scaling_config}
        */
        readonly eksResourceScalingConfig?: WorkflowStepParallelConfigStepEksResourceScalingConfigProperty[] | cdktn.IResolvable;
        /**
        * execution_approval_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#execution_approval_config AwsArcregionswitchPlan#execution_approval_config}
        */
        readonly executionApprovalConfig?: WorkflowStepParallelConfigStepExecutionApprovalConfigProperty[] | cdktn.IResolvable;
        /**
        * global_aurora_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#global_aurora_config AwsArcregionswitchPlan#global_aurora_config}
        */
        readonly globalAuroraConfig?: WorkflowStepParallelConfigStepGlobalAuroraConfigProperty[] | cdktn.IResolvable;
        /**
        * lambda_event_source_mapping_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#lambda_event_source_mapping_config AwsArcregionswitchPlan#lambda_event_source_mapping_config}
        */
        readonly lambdaEventSourceMappingConfig?: WorkflowStepParallelConfigStepLambdaEventSourceMappingConfigProperty[] | cdktn.IResolvable;
        /**
        * neptune_global_database_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#neptune_global_database_config AwsArcregionswitchPlan#neptune_global_database_config}
        */
        readonly neptuneGlobalDatabaseConfig?: WorkflowStepParallelConfigStepNeptuneGlobalDatabaseConfigProperty[] | cdktn.IResolvable;
        /**
        * rds_create_cross_region_read_replica_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#rds_create_cross_region_read_replica_config AwsArcregionswitchPlan#rds_create_cross_region_read_replica_config}
        */
        readonly rdsCreateCrossRegionReadReplicaConfig?: WorkflowStepParallelConfigStepRdsCreateCrossRegionReadReplicaConfigProperty[] | cdktn.IResolvable;
        /**
        * rds_promote_read_replica_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#rds_promote_read_replica_config AwsArcregionswitchPlan#rds_promote_read_replica_config}
        */
        readonly rdsPromoteReadReplicaConfig?: WorkflowStepParallelConfigStepRdsPromoteReadReplicaConfigProperty[] | cdktn.IResolvable;
        /**
        * region_switch_plan_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#region_switch_plan_config AwsArcregionswitchPlan#region_switch_plan_config}
        */
        readonly regionSwitchPlanConfig?: WorkflowStepParallelConfigStepRegionSwitchPlanConfigProperty[] | cdktn.IResolvable;
        /**
        * route53_health_check_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#route53_health_check_config AwsArcregionswitchPlan#route53_health_check_config}
        */
        readonly route53HealthCheckConfig?: WorkflowStepParallelConfigStepRoute53HealthCheckConfigProperty[] | cdktn.IResolvable;
    }
    class WorkflowStepParallelConfigStepPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepParallelConfigStepProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepParallelConfigStepProperty | cdktn.IResolvable | undefined);
        private _description?;
        get description(): string;
        set description(value: string);
        resetDescription(): void;
        get descriptionInput(): string | undefined;
        private _executionBlockType?;
        get executionBlockType(): string;
        set executionBlockType(value: string);
        get executionBlockTypeInput(): string | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _arcRoutingControlConfig;
        get arcRoutingControlConfig(): WorkflowStepParallelConfigStepArcRoutingControlConfigPropertyList;
        putArcRoutingControlConfig(value: WorkflowStepParallelConfigStepArcRoutingControlConfigProperty[] | cdktn.IResolvable): void;
        resetArcRoutingControlConfig(): void;
        get arcRoutingControlConfigInput(): cdktn.IResolvable | WorkflowStepParallelConfigStepArcRoutingControlConfigProperty[] | undefined;
        private _auroraProvisionedScalingConfig;
        get auroraProvisionedScalingConfig(): WorkflowStepParallelConfigStepAuroraProvisionedScalingConfigPropertyList;
        putAuroraProvisionedScalingConfig(value: WorkflowStepParallelConfigStepAuroraProvisionedScalingConfigProperty[] | cdktn.IResolvable): void;
        resetAuroraProvisionedScalingConfig(): void;
        get auroraProvisionedScalingConfigInput(): cdktn.IResolvable | WorkflowStepParallelConfigStepAuroraProvisionedScalingConfigProperty[] | undefined;
        private _auroraServerlessScalingConfig;
        get auroraServerlessScalingConfig(): WorkflowStepParallelConfigStepAuroraServerlessScalingConfigPropertyList;
        putAuroraServerlessScalingConfig(value: WorkflowStepParallelConfigStepAuroraServerlessScalingConfigProperty[] | cdktn.IResolvable): void;
        resetAuroraServerlessScalingConfig(): void;
        get auroraServerlessScalingConfigInput(): cdktn.IResolvable | WorkflowStepParallelConfigStepAuroraServerlessScalingConfigProperty[] | undefined;
        private _customActionLambdaConfig;
        get customActionLambdaConfig(): WorkflowStepParallelConfigStepCustomActionLambdaConfigPropertyList;
        putCustomActionLambdaConfig(value: WorkflowStepParallelConfigStepCustomActionLambdaConfigProperty[] | cdktn.IResolvable): void;
        resetCustomActionLambdaConfig(): void;
        get customActionLambdaConfigInput(): cdktn.IResolvable | WorkflowStepParallelConfigStepCustomActionLambdaConfigProperty[] | undefined;
        private _documentDbConfig;
        get documentDbConfig(): WorkflowStepParallelConfigStepDocumentDbConfigPropertyList;
        putDocumentDbConfig(value: WorkflowStepParallelConfigStepDocumentDbConfigProperty[] | cdktn.IResolvable): void;
        resetDocumentDbConfig(): void;
        get documentDbConfigInput(): cdktn.IResolvable | WorkflowStepParallelConfigStepDocumentDbConfigProperty[] | undefined;
        private _ec2AsgCapacityIncreaseConfig;
        get ec2AsgCapacityIncreaseConfig(): WorkflowStepParallelConfigStepEc2AsgCapacityIncreaseConfigPropertyList;
        putEc2AsgCapacityIncreaseConfig(value: WorkflowStepParallelConfigStepEc2AsgCapacityIncreaseConfigProperty[] | cdktn.IResolvable): void;
        resetEc2AsgCapacityIncreaseConfig(): void;
        get ec2AsgCapacityIncreaseConfigInput(): cdktn.IResolvable | WorkflowStepParallelConfigStepEc2AsgCapacityIncreaseConfigProperty[] | undefined;
        private _ecsCapacityIncreaseConfig;
        get ecsCapacityIncreaseConfig(): WorkflowStepParallelConfigStepEcsCapacityIncreaseConfigPropertyList;
        putEcsCapacityIncreaseConfig(value: WorkflowStepParallelConfigStepEcsCapacityIncreaseConfigProperty[] | cdktn.IResolvable): void;
        resetEcsCapacityIncreaseConfig(): void;
        get ecsCapacityIncreaseConfigInput(): cdktn.IResolvable | WorkflowStepParallelConfigStepEcsCapacityIncreaseConfigProperty[] | undefined;
        private _eksResourceScalingConfig;
        get eksResourceScalingConfig(): WorkflowStepParallelConfigStepEksResourceScalingConfigPropertyList;
        putEksResourceScalingConfig(value: WorkflowStepParallelConfigStepEksResourceScalingConfigProperty[] | cdktn.IResolvable): void;
        resetEksResourceScalingConfig(): void;
        get eksResourceScalingConfigInput(): cdktn.IResolvable | WorkflowStepParallelConfigStepEksResourceScalingConfigProperty[] | undefined;
        private _executionApprovalConfig;
        get executionApprovalConfig(): WorkflowStepParallelConfigStepExecutionApprovalConfigPropertyList;
        putExecutionApprovalConfig(value: WorkflowStepParallelConfigStepExecutionApprovalConfigProperty[] | cdktn.IResolvable): void;
        resetExecutionApprovalConfig(): void;
        get executionApprovalConfigInput(): cdktn.IResolvable | WorkflowStepParallelConfigStepExecutionApprovalConfigProperty[] | undefined;
        private _globalAuroraConfig;
        get globalAuroraConfig(): WorkflowStepParallelConfigStepGlobalAuroraConfigPropertyList;
        putGlobalAuroraConfig(value: WorkflowStepParallelConfigStepGlobalAuroraConfigProperty[] | cdktn.IResolvable): void;
        resetGlobalAuroraConfig(): void;
        get globalAuroraConfigInput(): cdktn.IResolvable | WorkflowStepParallelConfigStepGlobalAuroraConfigProperty[] | undefined;
        private _lambdaEventSourceMappingConfig;
        get lambdaEventSourceMappingConfig(): WorkflowStepParallelConfigStepLambdaEventSourceMappingConfigPropertyList;
        putLambdaEventSourceMappingConfig(value: WorkflowStepParallelConfigStepLambdaEventSourceMappingConfigProperty[] | cdktn.IResolvable): void;
        resetLambdaEventSourceMappingConfig(): void;
        get lambdaEventSourceMappingConfigInput(): cdktn.IResolvable | WorkflowStepParallelConfigStepLambdaEventSourceMappingConfigProperty[] | undefined;
        private _neptuneGlobalDatabaseConfig;
        get neptuneGlobalDatabaseConfig(): WorkflowStepParallelConfigStepNeptuneGlobalDatabaseConfigPropertyList;
        putNeptuneGlobalDatabaseConfig(value: WorkflowStepParallelConfigStepNeptuneGlobalDatabaseConfigProperty[] | cdktn.IResolvable): void;
        resetNeptuneGlobalDatabaseConfig(): void;
        get neptuneGlobalDatabaseConfigInput(): cdktn.IResolvable | WorkflowStepParallelConfigStepNeptuneGlobalDatabaseConfigProperty[] | undefined;
        private _rdsCreateCrossRegionReadReplicaConfig;
        get rdsCreateCrossRegionReadReplicaConfig(): WorkflowStepParallelConfigStepRdsCreateCrossRegionReadReplicaConfigPropertyList;
        putRdsCreateCrossRegionReadReplicaConfig(value: WorkflowStepParallelConfigStepRdsCreateCrossRegionReadReplicaConfigProperty[] | cdktn.IResolvable): void;
        resetRdsCreateCrossRegionReadReplicaConfig(): void;
        get rdsCreateCrossRegionReadReplicaConfigInput(): cdktn.IResolvable | WorkflowStepParallelConfigStepRdsCreateCrossRegionReadReplicaConfigProperty[] | undefined;
        private _rdsPromoteReadReplicaConfig;
        get rdsPromoteReadReplicaConfig(): WorkflowStepParallelConfigStepRdsPromoteReadReplicaConfigPropertyList;
        putRdsPromoteReadReplicaConfig(value: WorkflowStepParallelConfigStepRdsPromoteReadReplicaConfigProperty[] | cdktn.IResolvable): void;
        resetRdsPromoteReadReplicaConfig(): void;
        get rdsPromoteReadReplicaConfigInput(): cdktn.IResolvable | WorkflowStepParallelConfigStepRdsPromoteReadReplicaConfigProperty[] | undefined;
        private _regionSwitchPlanConfig;
        get regionSwitchPlanConfig(): WorkflowStepParallelConfigStepRegionSwitchPlanConfigPropertyList;
        putRegionSwitchPlanConfig(value: WorkflowStepParallelConfigStepRegionSwitchPlanConfigProperty[] | cdktn.IResolvable): void;
        resetRegionSwitchPlanConfig(): void;
        get regionSwitchPlanConfigInput(): cdktn.IResolvable | WorkflowStepParallelConfigStepRegionSwitchPlanConfigProperty[] | undefined;
        private _route53HealthCheckConfig;
        get route53HealthCheckConfig(): WorkflowStepParallelConfigStepRoute53HealthCheckConfigPropertyList;
        putRoute53HealthCheckConfig(value: WorkflowStepParallelConfigStepRoute53HealthCheckConfigProperty[] | cdktn.IResolvable): void;
        resetRoute53HealthCheckConfig(): void;
        get route53HealthCheckConfigInput(): cdktn.IResolvable | WorkflowStepParallelConfigStepRoute53HealthCheckConfigProperty[] | undefined;
    }
    class WorkflowStepParallelConfigStepPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepParallelConfigStepProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepParallelConfigStepPropertyOutputReference;
    }
    interface ParallelConfigProperty {
        /**
        * step block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#step AwsArcregionswitchPlan#step}
        */
        readonly step?: WorkflowStepParallelConfigStepProperty[] | cdktn.IResolvable;
    }
    class ParallelConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ParallelConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ParallelConfigProperty | cdktn.IResolvable | undefined);
        private _step;
        get step(): WorkflowStepParallelConfigStepPropertyList;
        putStep(value: WorkflowStepParallelConfigStepProperty[] | cdktn.IResolvable): void;
        resetStep(): void;
        get stepInput(): cdktn.IResolvable | WorkflowStepParallelConfigStepProperty[] | undefined;
    }
    class ParallelConfigPropertyList extends cdktn.ComplexList {
        internalValue?: ParallelConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ParallelConfigPropertyOutputReference;
    }
    interface WorkflowStepRdsCreateCrossRegionReadReplicaConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#cross_account_role AwsArcregionswitchPlan#cross_account_role}
        */
        readonly crossAccountRole?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#db_instance_arn_map AwsArcregionswitchPlan#db_instance_arn_map}
        */
        readonly dbInstanceArnMap: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#external_id AwsArcregionswitchPlan#external_id}
        */
        readonly externalId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#timeout_minutes AwsArcregionswitchPlan#timeout_minutes}
        */
        readonly timeoutMinutes?: number;
    }
    class WorkflowStepRdsCreateCrossRegionReadReplicaConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepRdsCreateCrossRegionReadReplicaConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepRdsCreateCrossRegionReadReplicaConfigProperty | cdktn.IResolvable | undefined);
        private _crossAccountRole?;
        get crossAccountRole(): string;
        set crossAccountRole(value: string);
        resetCrossAccountRole(): void;
        get crossAccountRoleInput(): string | undefined;
        private _dbInstanceArnMap?;
        get dbInstanceArnMap(): {
            [key: string]: string;
        };
        set dbInstanceArnMap(value: {
            [key: string]: string;
        });
        get dbInstanceArnMapInput(): {
            [key: string]: string;
        } | undefined;
        private _externalId?;
        get externalId(): string;
        set externalId(value: string);
        resetExternalId(): void;
        get externalIdInput(): string | undefined;
        private _timeoutMinutes?;
        get timeoutMinutes(): number;
        set timeoutMinutes(value: number);
        resetTimeoutMinutes(): void;
        get timeoutMinutesInput(): number | undefined;
    }
    class WorkflowStepRdsCreateCrossRegionReadReplicaConfigPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepRdsCreateCrossRegionReadReplicaConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepRdsCreateCrossRegionReadReplicaConfigPropertyOutputReference;
    }
    interface WorkflowStepRdsPromoteReadReplicaConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#cross_account_role AwsArcregionswitchPlan#cross_account_role}
        */
        readonly crossAccountRole?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#db_instance_arn_map AwsArcregionswitchPlan#db_instance_arn_map}
        */
        readonly dbInstanceArnMap: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#external_id AwsArcregionswitchPlan#external_id}
        */
        readonly externalId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#timeout_minutes AwsArcregionswitchPlan#timeout_minutes}
        */
        readonly timeoutMinutes?: number;
    }
    class WorkflowStepRdsPromoteReadReplicaConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepRdsPromoteReadReplicaConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepRdsPromoteReadReplicaConfigProperty | cdktn.IResolvable | undefined);
        private _crossAccountRole?;
        get crossAccountRole(): string;
        set crossAccountRole(value: string);
        resetCrossAccountRole(): void;
        get crossAccountRoleInput(): string | undefined;
        private _dbInstanceArnMap?;
        get dbInstanceArnMap(): {
            [key: string]: string;
        };
        set dbInstanceArnMap(value: {
            [key: string]: string;
        });
        get dbInstanceArnMapInput(): {
            [key: string]: string;
        } | undefined;
        private _externalId?;
        get externalId(): string;
        set externalId(value: string);
        resetExternalId(): void;
        get externalIdInput(): string | undefined;
        private _timeoutMinutes?;
        get timeoutMinutes(): number;
        set timeoutMinutes(value: number);
        resetTimeoutMinutes(): void;
        get timeoutMinutesInput(): number | undefined;
    }
    class WorkflowStepRdsPromoteReadReplicaConfigPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepRdsPromoteReadReplicaConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepRdsPromoteReadReplicaConfigPropertyOutputReference;
    }
    interface WorkflowStepRegionSwitchPlanConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#arn AwsArcregionswitchPlan#arn}
        */
        readonly arn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#cross_account_role AwsArcregionswitchPlan#cross_account_role}
        */
        readonly crossAccountRole?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#external_id AwsArcregionswitchPlan#external_id}
        */
        readonly externalId?: string;
    }
    class WorkflowStepRegionSwitchPlanConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepRegionSwitchPlanConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepRegionSwitchPlanConfigProperty | cdktn.IResolvable | undefined);
        private _arn?;
        get arn(): string;
        set arn(value: string);
        get arnInput(): string | undefined;
        private _crossAccountRole?;
        get crossAccountRole(): string;
        set crossAccountRole(value: string);
        resetCrossAccountRole(): void;
        get crossAccountRoleInput(): string | undefined;
        private _externalId?;
        get externalId(): string;
        set externalId(value: string);
        resetExternalId(): void;
        get externalIdInput(): string | undefined;
    }
    class WorkflowStepRegionSwitchPlanConfigPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepRegionSwitchPlanConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepRegionSwitchPlanConfigPropertyOutputReference;
    }
    interface WorkflowStepRoute53HealthCheckConfigRecordSetProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#record_set_identifier AwsArcregionswitchPlan#record_set_identifier}
        */
        readonly recordSetIdentifier: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#region AwsArcregionswitchPlan#region}
        */
        readonly region: string;
    }
    class WorkflowStepRoute53HealthCheckConfigRecordSetPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepRoute53HealthCheckConfigRecordSetProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepRoute53HealthCheckConfigRecordSetProperty | cdktn.IResolvable | undefined);
        private _recordSetIdentifier?;
        get recordSetIdentifier(): string;
        set recordSetIdentifier(value: string);
        get recordSetIdentifierInput(): string | undefined;
        private _region?;
        get region(): string;
        set region(value: string);
        get regionInput(): string | undefined;
    }
    class WorkflowStepRoute53HealthCheckConfigRecordSetPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepRoute53HealthCheckConfigRecordSetProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepRoute53HealthCheckConfigRecordSetPropertyOutputReference;
    }
    interface WorkflowStepRoute53HealthCheckConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#cross_account_role AwsArcregionswitchPlan#cross_account_role}
        */
        readonly crossAccountRole?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#external_id AwsArcregionswitchPlan#external_id}
        */
        readonly externalId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#hosted_zone_id AwsArcregionswitchPlan#hosted_zone_id}
        */
        readonly hostedZoneId: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#record_name AwsArcregionswitchPlan#record_name}
        */
        readonly recordName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#timeout_minutes AwsArcregionswitchPlan#timeout_minutes}
        */
        readonly timeoutMinutes?: number;
        /**
        * record_set block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#record_set AwsArcregionswitchPlan#record_set}
        */
        readonly recordSet?: WorkflowStepRoute53HealthCheckConfigRecordSetProperty[] | cdktn.IResolvable;
    }
    class WorkflowStepRoute53HealthCheckConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepRoute53HealthCheckConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepRoute53HealthCheckConfigProperty | cdktn.IResolvable | undefined);
        private _crossAccountRole?;
        get crossAccountRole(): string;
        set crossAccountRole(value: string);
        resetCrossAccountRole(): void;
        get crossAccountRoleInput(): string | undefined;
        private _externalId?;
        get externalId(): string;
        set externalId(value: string);
        resetExternalId(): void;
        get externalIdInput(): string | undefined;
        private _hostedZoneId?;
        get hostedZoneId(): string;
        set hostedZoneId(value: string);
        get hostedZoneIdInput(): string | undefined;
        private _recordName?;
        get recordName(): string;
        set recordName(value: string);
        get recordNameInput(): string | undefined;
        private _timeoutMinutes?;
        get timeoutMinutes(): number;
        set timeoutMinutes(value: number);
        resetTimeoutMinutes(): void;
        get timeoutMinutesInput(): number | undefined;
        private _recordSet;
        get recordSet(): WorkflowStepRoute53HealthCheckConfigRecordSetPropertyList;
        putRecordSet(value: WorkflowStepRoute53HealthCheckConfigRecordSetProperty[] | cdktn.IResolvable): void;
        resetRecordSet(): void;
        get recordSetInput(): cdktn.IResolvable | WorkflowStepRoute53HealthCheckConfigRecordSetProperty[] | undefined;
    }
    class WorkflowStepRoute53HealthCheckConfigPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepRoute53HealthCheckConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepRoute53HealthCheckConfigPropertyOutputReference;
    }
    interface WorkflowStepProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#description AwsArcregionswitchPlan#description}
        */
        readonly description?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#execution_block_type AwsArcregionswitchPlan#execution_block_type}
        */
        readonly executionBlockType: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#name AwsArcregionswitchPlan#name}
        */
        readonly name: string;
        /**
        * arc_routing_control_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#arc_routing_control_config AwsArcregionswitchPlan#arc_routing_control_config}
        */
        readonly arcRoutingControlConfig?: WorkflowStepArcRoutingControlConfigProperty[] | cdktn.IResolvable;
        /**
        * aurora_provisioned_scaling_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#aurora_provisioned_scaling_config AwsArcregionswitchPlan#aurora_provisioned_scaling_config}
        */
        readonly auroraProvisionedScalingConfig?: WorkflowStepAuroraProvisionedScalingConfigProperty[] | cdktn.IResolvable;
        /**
        * aurora_serverless_scaling_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#aurora_serverless_scaling_config AwsArcregionswitchPlan#aurora_serverless_scaling_config}
        */
        readonly auroraServerlessScalingConfig?: WorkflowStepAuroraServerlessScalingConfigProperty[] | cdktn.IResolvable;
        /**
        * custom_action_lambda_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#custom_action_lambda_config AwsArcregionswitchPlan#custom_action_lambda_config}
        */
        readonly customActionLambdaConfig?: WorkflowStepCustomActionLambdaConfigProperty[] | cdktn.IResolvable;
        /**
        * document_db_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#document_db_config AwsArcregionswitchPlan#document_db_config}
        */
        readonly documentDbConfig?: WorkflowStepDocumentDbConfigProperty[] | cdktn.IResolvable;
        /**
        * ec2_asg_capacity_increase_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#ec2_asg_capacity_increase_config AwsArcregionswitchPlan#ec2_asg_capacity_increase_config}
        */
        readonly ec2AsgCapacityIncreaseConfig?: WorkflowStepEc2AsgCapacityIncreaseConfigProperty[] | cdktn.IResolvable;
        /**
        * ecs_capacity_increase_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#ecs_capacity_increase_config AwsArcregionswitchPlan#ecs_capacity_increase_config}
        */
        readonly ecsCapacityIncreaseConfig?: WorkflowStepEcsCapacityIncreaseConfigProperty[] | cdktn.IResolvable;
        /**
        * eks_resource_scaling_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#eks_resource_scaling_config AwsArcregionswitchPlan#eks_resource_scaling_config}
        */
        readonly eksResourceScalingConfig?: WorkflowStepEksResourceScalingConfigProperty[] | cdktn.IResolvable;
        /**
        * execution_approval_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#execution_approval_config AwsArcregionswitchPlan#execution_approval_config}
        */
        readonly executionApprovalConfig?: WorkflowStepExecutionApprovalConfigProperty[] | cdktn.IResolvable;
        /**
        * global_aurora_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#global_aurora_config AwsArcregionswitchPlan#global_aurora_config}
        */
        readonly globalAuroraConfig?: WorkflowStepGlobalAuroraConfigProperty[] | cdktn.IResolvable;
        /**
        * lambda_event_source_mapping_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#lambda_event_source_mapping_config AwsArcregionswitchPlan#lambda_event_source_mapping_config}
        */
        readonly lambdaEventSourceMappingConfig?: WorkflowStepLambdaEventSourceMappingConfigProperty[] | cdktn.IResolvable;
        /**
        * neptune_global_database_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#neptune_global_database_config AwsArcregionswitchPlan#neptune_global_database_config}
        */
        readonly neptuneGlobalDatabaseConfig?: WorkflowStepNeptuneGlobalDatabaseConfigProperty[] | cdktn.IResolvable;
        /**
        * parallel_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#parallel_config AwsArcregionswitchPlan#parallel_config}
        */
        readonly parallelConfig?: ParallelConfigProperty[] | cdktn.IResolvable;
        /**
        * rds_create_cross_region_read_replica_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#rds_create_cross_region_read_replica_config AwsArcregionswitchPlan#rds_create_cross_region_read_replica_config}
        */
        readonly rdsCreateCrossRegionReadReplicaConfig?: WorkflowStepRdsCreateCrossRegionReadReplicaConfigProperty[] | cdktn.IResolvable;
        /**
        * rds_promote_read_replica_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#rds_promote_read_replica_config AwsArcregionswitchPlan#rds_promote_read_replica_config}
        */
        readonly rdsPromoteReadReplicaConfig?: WorkflowStepRdsPromoteReadReplicaConfigProperty[] | cdktn.IResolvable;
        /**
        * region_switch_plan_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#region_switch_plan_config AwsArcregionswitchPlan#region_switch_plan_config}
        */
        readonly regionSwitchPlanConfig?: WorkflowStepRegionSwitchPlanConfigProperty[] | cdktn.IResolvable;
        /**
        * route53_health_check_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#route53_health_check_config AwsArcregionswitchPlan#route53_health_check_config}
        */
        readonly route53HealthCheckConfig?: WorkflowStepRoute53HealthCheckConfigProperty[] | cdktn.IResolvable;
    }
    class WorkflowStepPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepProperty | cdktn.IResolvable | undefined);
        private _description?;
        get description(): string;
        set description(value: string);
        resetDescription(): void;
        get descriptionInput(): string | undefined;
        private _executionBlockType?;
        get executionBlockType(): string;
        set executionBlockType(value: string);
        get executionBlockTypeInput(): string | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _arcRoutingControlConfig;
        get arcRoutingControlConfig(): WorkflowStepArcRoutingControlConfigPropertyList;
        putArcRoutingControlConfig(value: WorkflowStepArcRoutingControlConfigProperty[] | cdktn.IResolvable): void;
        resetArcRoutingControlConfig(): void;
        get arcRoutingControlConfigInput(): cdktn.IResolvable | WorkflowStepArcRoutingControlConfigProperty[] | undefined;
        private _auroraProvisionedScalingConfig;
        get auroraProvisionedScalingConfig(): WorkflowStepAuroraProvisionedScalingConfigPropertyList;
        putAuroraProvisionedScalingConfig(value: WorkflowStepAuroraProvisionedScalingConfigProperty[] | cdktn.IResolvable): void;
        resetAuroraProvisionedScalingConfig(): void;
        get auroraProvisionedScalingConfigInput(): cdktn.IResolvable | WorkflowStepAuroraProvisionedScalingConfigProperty[] | undefined;
        private _auroraServerlessScalingConfig;
        get auroraServerlessScalingConfig(): WorkflowStepAuroraServerlessScalingConfigPropertyList;
        putAuroraServerlessScalingConfig(value: WorkflowStepAuroraServerlessScalingConfigProperty[] | cdktn.IResolvable): void;
        resetAuroraServerlessScalingConfig(): void;
        get auroraServerlessScalingConfigInput(): cdktn.IResolvable | WorkflowStepAuroraServerlessScalingConfigProperty[] | undefined;
        private _customActionLambdaConfig;
        get customActionLambdaConfig(): WorkflowStepCustomActionLambdaConfigPropertyList;
        putCustomActionLambdaConfig(value: WorkflowStepCustomActionLambdaConfigProperty[] | cdktn.IResolvable): void;
        resetCustomActionLambdaConfig(): void;
        get customActionLambdaConfigInput(): cdktn.IResolvable | WorkflowStepCustomActionLambdaConfigProperty[] | undefined;
        private _documentDbConfig;
        get documentDbConfig(): WorkflowStepDocumentDbConfigPropertyList;
        putDocumentDbConfig(value: WorkflowStepDocumentDbConfigProperty[] | cdktn.IResolvable): void;
        resetDocumentDbConfig(): void;
        get documentDbConfigInput(): cdktn.IResolvable | WorkflowStepDocumentDbConfigProperty[] | undefined;
        private _ec2AsgCapacityIncreaseConfig;
        get ec2AsgCapacityIncreaseConfig(): WorkflowStepEc2AsgCapacityIncreaseConfigPropertyList;
        putEc2AsgCapacityIncreaseConfig(value: WorkflowStepEc2AsgCapacityIncreaseConfigProperty[] | cdktn.IResolvable): void;
        resetEc2AsgCapacityIncreaseConfig(): void;
        get ec2AsgCapacityIncreaseConfigInput(): cdktn.IResolvable | WorkflowStepEc2AsgCapacityIncreaseConfigProperty[] | undefined;
        private _ecsCapacityIncreaseConfig;
        get ecsCapacityIncreaseConfig(): WorkflowStepEcsCapacityIncreaseConfigPropertyList;
        putEcsCapacityIncreaseConfig(value: WorkflowStepEcsCapacityIncreaseConfigProperty[] | cdktn.IResolvable): void;
        resetEcsCapacityIncreaseConfig(): void;
        get ecsCapacityIncreaseConfigInput(): cdktn.IResolvable | WorkflowStepEcsCapacityIncreaseConfigProperty[] | undefined;
        private _eksResourceScalingConfig;
        get eksResourceScalingConfig(): WorkflowStepEksResourceScalingConfigPropertyList;
        putEksResourceScalingConfig(value: WorkflowStepEksResourceScalingConfigProperty[] | cdktn.IResolvable): void;
        resetEksResourceScalingConfig(): void;
        get eksResourceScalingConfigInput(): cdktn.IResolvable | WorkflowStepEksResourceScalingConfigProperty[] | undefined;
        private _executionApprovalConfig;
        get executionApprovalConfig(): WorkflowStepExecutionApprovalConfigPropertyList;
        putExecutionApprovalConfig(value: WorkflowStepExecutionApprovalConfigProperty[] | cdktn.IResolvable): void;
        resetExecutionApprovalConfig(): void;
        get executionApprovalConfigInput(): cdktn.IResolvable | WorkflowStepExecutionApprovalConfigProperty[] | undefined;
        private _globalAuroraConfig;
        get globalAuroraConfig(): WorkflowStepGlobalAuroraConfigPropertyList;
        putGlobalAuroraConfig(value: WorkflowStepGlobalAuroraConfigProperty[] | cdktn.IResolvable): void;
        resetGlobalAuroraConfig(): void;
        get globalAuroraConfigInput(): cdktn.IResolvable | WorkflowStepGlobalAuroraConfigProperty[] | undefined;
        private _lambdaEventSourceMappingConfig;
        get lambdaEventSourceMappingConfig(): WorkflowStepLambdaEventSourceMappingConfigPropertyList;
        putLambdaEventSourceMappingConfig(value: WorkflowStepLambdaEventSourceMappingConfigProperty[] | cdktn.IResolvable): void;
        resetLambdaEventSourceMappingConfig(): void;
        get lambdaEventSourceMappingConfigInput(): cdktn.IResolvable | WorkflowStepLambdaEventSourceMappingConfigProperty[] | undefined;
        private _neptuneGlobalDatabaseConfig;
        get neptuneGlobalDatabaseConfig(): WorkflowStepNeptuneGlobalDatabaseConfigPropertyList;
        putNeptuneGlobalDatabaseConfig(value: WorkflowStepNeptuneGlobalDatabaseConfigProperty[] | cdktn.IResolvable): void;
        resetNeptuneGlobalDatabaseConfig(): void;
        get neptuneGlobalDatabaseConfigInput(): cdktn.IResolvable | WorkflowStepNeptuneGlobalDatabaseConfigProperty[] | undefined;
        private _parallelConfig;
        get parallelConfig(): ParallelConfigPropertyList;
        putParallelConfig(value: ParallelConfigProperty[] | cdktn.IResolvable): void;
        resetParallelConfig(): void;
        get parallelConfigInput(): cdktn.IResolvable | ParallelConfigProperty[] | undefined;
        private _rdsCreateCrossRegionReadReplicaConfig;
        get rdsCreateCrossRegionReadReplicaConfig(): WorkflowStepRdsCreateCrossRegionReadReplicaConfigPropertyList;
        putRdsCreateCrossRegionReadReplicaConfig(value: WorkflowStepRdsCreateCrossRegionReadReplicaConfigProperty[] | cdktn.IResolvable): void;
        resetRdsCreateCrossRegionReadReplicaConfig(): void;
        get rdsCreateCrossRegionReadReplicaConfigInput(): cdktn.IResolvable | WorkflowStepRdsCreateCrossRegionReadReplicaConfigProperty[] | undefined;
        private _rdsPromoteReadReplicaConfig;
        get rdsPromoteReadReplicaConfig(): WorkflowStepRdsPromoteReadReplicaConfigPropertyList;
        putRdsPromoteReadReplicaConfig(value: WorkflowStepRdsPromoteReadReplicaConfigProperty[] | cdktn.IResolvable): void;
        resetRdsPromoteReadReplicaConfig(): void;
        get rdsPromoteReadReplicaConfigInput(): cdktn.IResolvable | WorkflowStepRdsPromoteReadReplicaConfigProperty[] | undefined;
        private _regionSwitchPlanConfig;
        get regionSwitchPlanConfig(): WorkflowStepRegionSwitchPlanConfigPropertyList;
        putRegionSwitchPlanConfig(value: WorkflowStepRegionSwitchPlanConfigProperty[] | cdktn.IResolvable): void;
        resetRegionSwitchPlanConfig(): void;
        get regionSwitchPlanConfigInput(): cdktn.IResolvable | WorkflowStepRegionSwitchPlanConfigProperty[] | undefined;
        private _route53HealthCheckConfig;
        get route53HealthCheckConfig(): WorkflowStepRoute53HealthCheckConfigPropertyList;
        putRoute53HealthCheckConfig(value: WorkflowStepRoute53HealthCheckConfigProperty[] | cdktn.IResolvable): void;
        resetRoute53HealthCheckConfig(): void;
        get route53HealthCheckConfigInput(): cdktn.IResolvable | WorkflowStepRoute53HealthCheckConfigProperty[] | undefined;
    }
    class WorkflowStepPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepPropertyOutputReference;
    }
    interface WorkflowProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#workflow_description AwsArcregionswitchPlan#workflow_description}
        */
        readonly workflowDescription?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#workflow_target_action AwsArcregionswitchPlan#workflow_target_action}
        */
        readonly workflowTargetAction: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#workflow_target_region AwsArcregionswitchPlan#workflow_target_region}
        */
        readonly workflowTargetRegion?: string;
        /**
        * step block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#step AwsArcregionswitchPlan#step}
        */
        readonly step?: WorkflowStepProperty[] | cdktn.IResolvable;
    }
    class WorkflowPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowProperty | cdktn.IResolvable | undefined);
        private _workflowDescription?;
        get workflowDescription(): string;
        set workflowDescription(value: string);
        resetWorkflowDescription(): void;
        get workflowDescriptionInput(): string | undefined;
        private _workflowTargetAction?;
        get workflowTargetAction(): string;
        set workflowTargetAction(value: string);
        get workflowTargetActionInput(): string | undefined;
        private _workflowTargetRegion?;
        get workflowTargetRegion(): string;
        set workflowTargetRegion(value: string);
        resetWorkflowTargetRegion(): void;
        get workflowTargetRegionInput(): string | undefined;
        private _step;
        get step(): WorkflowStepPropertyList;
        putStep(value: WorkflowStepProperty[] | cdktn.IResolvable): void;
        resetStep(): void;
        get stepInput(): cdktn.IResolvable | WorkflowStepProperty[] | undefined;
    }
    class WorkflowPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowPropertyOutputReference;
    }
}
