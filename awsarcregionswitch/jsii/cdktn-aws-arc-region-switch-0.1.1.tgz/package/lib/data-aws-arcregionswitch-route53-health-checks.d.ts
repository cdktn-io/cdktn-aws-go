import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsArcregionswitchRoute53HealthChecksConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/arcregionswitch_route53_health_checks#plan_arn DataAwsArcregionswitchRoute53HealthChecks#plan_arn}
    */
    readonly planArn: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/arcregionswitch_route53_health_checks#region DataAwsArcregionswitchRoute53HealthChecks#region}
    */
    readonly region?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/arcregionswitch_route53_health_checks aws_arcregionswitch_route53_health_checks}
*/
export declare class DataAwsArcregionswitchRoute53HealthChecks extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_arcregionswitch_route53_health_checks";
    /**
    * Generates CDKTN code for importing a DataAwsArcregionswitchRoute53HealthChecks resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsArcregionswitchRoute53HealthChecks to import
    * @param importFromId The id of the existing DataAwsArcregionswitchRoute53HealthChecks that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/arcregionswitch_route53_health_checks#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsArcregionswitchRoute53HealthChecks to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/arcregionswitch_route53_health_checks aws_arcregionswitch_route53_health_checks} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsArcregionswitchRoute53HealthChecksConfig
    */
    constructor(scope: Construct, id: string, config: DataAwsArcregionswitchRoute53HealthChecksConfig);
    private _healthChecks;
    get healthChecks(): DataAwsArcregionswitchRoute53HealthChecks.HealthChecksPropertyList;
    private _planArn?;
    get planArn(): string;
    set planArn(value: string);
    get planArnInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataAwsArcregionswitchRoute53HealthChecksHealthChecksPropertyToTerraform(struct?: DataAwsArcregionswitchRoute53HealthChecks.HealthChecksProperty): any;
export declare function dataAwsArcregionswitchRoute53HealthChecksHealthChecksPropertyToHclTerraform(struct?: DataAwsArcregionswitchRoute53HealthChecks.HealthChecksProperty): any;
export declare namespace DataAwsArcregionswitchRoute53HealthChecks {
    interface HealthChecksProperty {
    }
    class HealthChecksPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): HealthChecksProperty | undefined;
        set internalValue(value: HealthChecksProperty | undefined);
        get healthCheckId(): string;
        get hostedZoneId(): string;
        get recordName(): string;
        get region(): string;
        get status(): string;
    }
    class HealthChecksPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): HealthChecksPropertyOutputReference;
    }
}
