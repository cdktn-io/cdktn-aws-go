import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfPlanConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#description TfPlan#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#execution_role TfPlan#execution_role}
    */
    readonly executionRole: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#name TfPlan#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#primary_region TfPlan#primary_region}
    */
    readonly primaryRegion?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#recovery_approach TfPlan#recovery_approach}
    */
    readonly recoveryApproach: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#recovery_time_objective_minutes TfPlan#recovery_time_objective_minutes}
    */
    readonly recoveryTimeObjectiveMinutes?: number;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#region TfPlan#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#regions TfPlan#regions}
    */
    readonly regions: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#tags TfPlan#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * associated_alarms block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#associated_alarms TfPlan#associated_alarms}
    */
    readonly associatedAlarms?: TfPlan.AssociatedAlarmsProperty[] | cdktn.IResolvable;
    /**
    * report_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#report_configuration TfPlan#report_configuration}
    */
    readonly reportConfiguration?: TfPlan.ReportConfigurationProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#timeouts TfPlan#timeouts}
    */
    readonly timeouts?: TfPlan.TimeoutsProperty;
    /**
    * triggers block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#triggers TfPlan#triggers}
    */
    readonly triggers?: TfPlan.TriggersProperty[] | cdktn.IResolvable;
    /**
    * workflow block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#workflow TfPlan#workflow}
    */
    readonly workflow?: TfPlan.WorkflowProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan aws_arcregionswitch_plan}
*/
export declare class TfPlan extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_arcregionswitch_plan";
    /**
    * Generates CDKTN code for importing a TfPlan resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfPlan to import
    * @param importFromId The id of the existing TfPlan that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfPlan to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan aws_arcregionswitch_plan} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfPlanConfig
    */
    constructor(scope: Construct, id: string, config: TfPlanConfig);
    get arn(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _executionRole?;
    get executionRole(): string;
    set executionRole(value: string);
    get executionRoleInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _primaryRegion?;
    get primaryRegion(): string;
    set primaryRegion(value: string);
    resetPrimaryRegion(): void;
    get primaryRegionInput(): string | undefined;
    private _recoveryApproach?;
    get recoveryApproach(): string;
    set recoveryApproach(value: string);
    get recoveryApproachInput(): string | undefined;
    private _recoveryTimeObjectiveMinutes?;
    get recoveryTimeObjectiveMinutes(): number;
    set recoveryTimeObjectiveMinutes(value: number);
    resetRecoveryTimeObjectiveMinutes(): void;
    get recoveryTimeObjectiveMinutesInput(): number | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _regions?;
    get regions(): string[];
    set regions(value: string[]);
    get regionsInput(): string[] | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    private _associatedAlarms;
    get associatedAlarms(): TfPlan.AssociatedAlarmsPropertyList;
    putAssociatedAlarms(value: TfPlan.AssociatedAlarmsProperty[] | cdktn.IResolvable): void;
    resetAssociatedAlarms(): void;
    get associatedAlarmsInput(): cdktn.IResolvable | TfPlan.AssociatedAlarmsProperty[] | undefined;
    private _reportConfiguration;
    get reportConfiguration(): TfPlan.ReportConfigurationPropertyList;
    putReportConfiguration(value: TfPlan.ReportConfigurationProperty[] | cdktn.IResolvable): void;
    resetReportConfiguration(): void;
    get reportConfigurationInput(): cdktn.IResolvable | TfPlan.ReportConfigurationProperty[] | undefined;
    private _timeouts;
    get timeouts(): TfPlan.TimeoutsPropertyOutputReference;
    putTimeouts(value: TfPlan.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | TfPlan.TimeoutsProperty | undefined;
    private _triggers;
    get triggers(): TfPlan.TriggersPropertyList;
    putTriggers(value: TfPlan.TriggersProperty[] | cdktn.IResolvable): void;
    resetTriggers(): void;
    get triggersInput(): cdktn.IResolvable | TfPlan.TriggersProperty[] | undefined;
    private _workflow;
    get workflow(): TfPlan.WorkflowPropertyList;
    putWorkflow(value: TfPlan.WorkflowProperty[] | cdktn.IResolvable): void;
    resetWorkflow(): void;
    get workflowInput(): cdktn.IResolvable | TfPlan.WorkflowProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfPlanAssociatedAlarmsPropertyToTerraform(struct?: TfPlan.AssociatedAlarmsProperty | cdktn.IResolvable): any;
export declare function tfPlanAssociatedAlarmsPropertyToHclTerraform(struct?: TfPlan.AssociatedAlarmsProperty | cdktn.IResolvable): any;
export declare function tfPlanS3ConfigurationPropertyToTerraform(struct?: TfPlan.S3ConfigurationProperty | cdktn.IResolvable): any;
export declare function tfPlanS3ConfigurationPropertyToHclTerraform(struct?: TfPlan.S3ConfigurationProperty | cdktn.IResolvable): any;
export declare function tfPlanReportOutputPropertyToTerraform(struct?: TfPlan.ReportOutputProperty | cdktn.IResolvable): any;
export declare function tfPlanReportOutputPropertyToHclTerraform(struct?: TfPlan.ReportOutputProperty | cdktn.IResolvable): any;
export declare function tfPlanReportConfigurationPropertyToTerraform(struct?: TfPlan.ReportConfigurationProperty | cdktn.IResolvable): any;
export declare function tfPlanReportConfigurationPropertyToHclTerraform(struct?: TfPlan.ReportConfigurationProperty | cdktn.IResolvable): any;
export declare function tfPlanTimeoutsPropertyToTerraform(struct?: TfPlan.TimeoutsProperty | cdktn.IResolvable): any;
export declare function tfPlanTimeoutsPropertyToHclTerraform(struct?: TfPlan.TimeoutsProperty | cdktn.IResolvable): any;
export declare function tfPlanConditionsPropertyToTerraform(struct?: TfPlan.ConditionsProperty | cdktn.IResolvable): any;
export declare function tfPlanConditionsPropertyToHclTerraform(struct?: TfPlan.ConditionsProperty | cdktn.IResolvable): any;
export declare function tfPlanTriggersPropertyToTerraform(struct?: TfPlan.TriggersProperty | cdktn.IResolvable): any;
export declare function tfPlanTriggersPropertyToHclTerraform(struct?: TfPlan.TriggersProperty | cdktn.IResolvable): any;
export declare function tfPlanWorkflowStepArcRoutingControlConfigRegionAndRoutingControlsRoutingControlPropertyToTerraform(struct?: TfPlan.WorkflowStepArcRoutingControlConfigRegionAndRoutingControlsRoutingControlProperty | cdktn.IResolvable): any;
export declare function tfPlanWorkflowStepArcRoutingControlConfigRegionAndRoutingControlsRoutingControlPropertyToHclTerraform(struct?: TfPlan.WorkflowStepArcRoutingControlConfigRegionAndRoutingControlsRoutingControlProperty | cdktn.IResolvable): any;
export declare function tfPlanWorkflowStepArcRoutingControlConfigRegionAndRoutingControlsPropertyToTerraform(struct?: TfPlan.WorkflowStepArcRoutingControlConfigRegionAndRoutingControlsProperty | cdktn.IResolvable): any;
export declare function tfPlanWorkflowStepArcRoutingControlConfigRegionAndRoutingControlsPropertyToHclTerraform(struct?: TfPlan.WorkflowStepArcRoutingControlConfigRegionAndRoutingControlsProperty | cdktn.IResolvable): any;
export declare function tfPlanWorkflowStepArcRoutingControlConfigPropertyToTerraform(struct?: TfPlan.WorkflowStepArcRoutingControlConfigProperty | cdktn.IResolvable): any;
export declare function tfPlanWorkflowStepArcRoutingControlConfigPropertyToHclTerraform(struct?: TfPlan.WorkflowStepArcRoutingControlConfigProperty | cdktn.IResolvable): any;
export declare function tfPlanWorkflowStepAuroraProvisionedScalingConfigPropertyToTerraform(struct?: TfPlan.WorkflowStepAuroraProvisionedScalingConfigProperty | cdktn.IResolvable): any;
export declare function tfPlanWorkflowStepAuroraProvisionedScalingConfigPropertyToHclTerraform(struct?: TfPlan.WorkflowStepAuroraProvisionedScalingConfigProperty | cdktn.IResolvable): any;
export declare function tfPlanWorkflowStepAuroraServerlessScalingConfigPropertyToTerraform(struct?: TfPlan.WorkflowStepAuroraServerlessScalingConfigProperty | cdktn.IResolvable): any;
export declare function tfPlanWorkflowStepAuroraServerlessScalingConfigPropertyToHclTerraform(struct?: TfPlan.WorkflowStepAuroraServerlessScalingConfigProperty | cdktn.IResolvable): any;
export declare function tfPlanWorkflowStepCustomActionLambdaConfigLambdaPropertyToTerraform(struct?: TfPlan.WorkflowStepCustomActionLambdaConfigLambdaProperty | cdktn.IResolvable): any;
export declare function tfPlanWorkflowStepCustomActionLambdaConfigLambdaPropertyToHclTerraform(struct?: TfPlan.WorkflowStepCustomActionLambdaConfigLambdaProperty | cdktn.IResolvable): any;
export declare function tfPlanWorkflowStepCustomActionLambdaConfigUngracefulPropertyToTerraform(struct?: TfPlan.WorkflowStepCustomActionLambdaConfigUngracefulProperty | cdktn.IResolvable): any;
export declare function tfPlanWorkflowStepCustomActionLambdaConfigUngracefulPropertyToHclTerraform(struct?: TfPlan.WorkflowStepCustomActionLambdaConfigUngracefulProperty | cdktn.IResolvable): any;
export declare function tfPlanWorkflowStepCustomActionLambdaConfigPropertyToTerraform(struct?: TfPlan.WorkflowStepCustomActionLambdaConfigProperty | cdktn.IResolvable): any;
export declare function tfPlanWorkflowStepCustomActionLambdaConfigPropertyToHclTerraform(struct?: TfPlan.WorkflowStepCustomActionLambdaConfigProperty | cdktn.IResolvable): any;
export declare function tfPlanWorkflowStepDocumentDbConfigUngracefulPropertyToTerraform(struct?: TfPlan.WorkflowStepDocumentDbConfigUngracefulProperty | cdktn.IResolvable): any;
export declare function tfPlanWorkflowStepDocumentDbConfigUngracefulPropertyToHclTerraform(struct?: TfPlan.WorkflowStepDocumentDbConfigUngracefulProperty | cdktn.IResolvable): any;
export declare function tfPlanWorkflowStepDocumentDbConfigPropertyToTerraform(struct?: TfPlan.WorkflowStepDocumentDbConfigProperty | cdktn.IResolvable): any;
export declare function tfPlanWorkflowStepDocumentDbConfigPropertyToHclTerraform(struct?: TfPlan.WorkflowStepDocumentDbConfigProperty | cdktn.IResolvable): any;
export declare function tfPlanWorkflowStepEc2AsgCapacityIncreaseConfigAsgPropertyToTerraform(struct?: TfPlan.WorkflowStepEc2AsgCapacityIncreaseConfigAsgProperty | cdktn.IResolvable): any;
export declare function tfPlanWorkflowStepEc2AsgCapacityIncreaseConfigAsgPropertyToHclTerraform(struct?: TfPlan.WorkflowStepEc2AsgCapacityIncreaseConfigAsgProperty | cdktn.IResolvable): any;
export declare function tfPlanWorkflowStepEc2AsgCapacityIncreaseConfigUngracefulPropertyToTerraform(struct?: TfPlan.WorkflowStepEc2AsgCapacityIncreaseConfigUngracefulProperty | cdktn.IResolvable): any;
export declare function tfPlanWorkflowStepEc2AsgCapacityIncreaseConfigUngracefulPropertyToHclTerraform(struct?: TfPlan.WorkflowStepEc2AsgCapacityIncreaseConfigUngracefulProperty | cdktn.IResolvable): any;
export declare function tfPlanWorkflowStepEc2AsgCapacityIncreaseConfigPropertyToTerraform(struct?: TfPlan.WorkflowStepEc2AsgCapacityIncreaseConfigProperty | cdktn.IResolvable): any;
export declare function tfPlanWorkflowStepEc2AsgCapacityIncreaseConfigPropertyToHclTerraform(struct?: TfPlan.WorkflowStepEc2AsgCapacityIncreaseConfigProperty | cdktn.IResolvable): any;
export declare function tfPlanWorkflowStepEcsCapacityIncreaseConfigServicePropertyToTerraform(struct?: TfPlan.WorkflowStepEcsCapacityIncreaseConfigServiceProperty | cdktn.IResolvable): any;
export declare function tfPlanWorkflowStepEcsCapacityIncreaseConfigServicePropertyToHclTerraform(struct?: TfPlan.WorkflowStepEcsCapacityIncreaseConfigServiceProperty | cdktn.IResolvable): any;
export declare function tfPlanWorkflowStepEcsCapacityIncreaseConfigUngracefulPropertyToTerraform(struct?: TfPlan.WorkflowStepEcsCapacityIncreaseConfigUngracefulProperty | cdktn.IResolvable): any;
export declare function tfPlanWorkflowStepEcsCapacityIncreaseConfigUngracefulPropertyToHclTerraform(struct?: TfPlan.WorkflowStepEcsCapacityIncreaseConfigUngracefulProperty | cdktn.IResolvable): any;
export declare function tfPlanWorkflowStepEcsCapacityIncreaseConfigPropertyToTerraform(struct?: TfPlan.WorkflowStepEcsCapacityIncreaseConfigProperty | cdktn.IResolvable): any;
export declare function tfPlanWorkflowStepEcsCapacityIncreaseConfigPropertyToHclTerraform(struct?: TfPlan.WorkflowStepEcsCapacityIncreaseConfigProperty | cdktn.IResolvable): any;
export declare function tfPlanWorkflowStepEksResourceScalingConfigEksClustersPropertyToTerraform(struct?: TfPlan.WorkflowStepEksResourceScalingConfigEksClustersProperty | cdktn.IResolvable): any;
export declare function tfPlanWorkflowStepEksResourceScalingConfigEksClustersPropertyToHclTerraform(struct?: TfPlan.WorkflowStepEksResourceScalingConfigEksClustersProperty | cdktn.IResolvable): any;
export declare function tfPlanWorkflowStepEksResourceScalingConfigKubernetesResourceTypePropertyToTerraform(struct?: TfPlan.WorkflowStepEksResourceScalingConfigKubernetesResourceTypeProperty | cdktn.IResolvable): any;
export declare function tfPlanWorkflowStepEksResourceScalingConfigKubernetesResourceTypePropertyToHclTerraform(struct?: TfPlan.WorkflowStepEksResourceScalingConfigKubernetesResourceTypeProperty | cdktn.IResolvable): any;
export declare function tfPlanWorkflowStepEksResourceScalingConfigScalingResourcesResourcesPropertyToTerraform(struct?: TfPlan.WorkflowStepEksResourceScalingConfigScalingResourcesResourcesProperty | cdktn.IResolvable): any;
export declare function tfPlanWorkflowStepEksResourceScalingConfigScalingResourcesResourcesPropertyToHclTerraform(struct?: TfPlan.WorkflowStepEksResourceScalingConfigScalingResourcesResourcesProperty | cdktn.IResolvable): any;
export declare function tfPlanWorkflowStepEksResourceScalingConfigScalingResourcesPropertyToTerraform(struct?: TfPlan.WorkflowStepEksResourceScalingConfigScalingResourcesProperty | cdktn.IResolvable): any;
export declare function tfPlanWorkflowStepEksResourceScalingConfigScalingResourcesPropertyToHclTerraform(struct?: TfPlan.WorkflowStepEksResourceScalingConfigScalingResourcesProperty | cdktn.IResolvable): any;
export declare function tfPlanWorkflowStepEksResourceScalingConfigUngracefulPropertyToTerraform(struct?: TfPlan.WorkflowStepEksResourceScalingConfigUngracefulProperty | cdktn.IResolvable): any;
export declare function tfPlanWorkflowStepEksResourceScalingConfigUngracefulPropertyToHclTerraform(struct?: TfPlan.WorkflowStepEksResourceScalingConfigUngracefulProperty | cdktn.IResolvable): any;
export declare function tfPlanWorkflowStepEksResourceScalingConfigPropertyToTerraform(struct?: TfPlan.WorkflowStepEksResourceScalingConfigProperty | cdktn.IResolvable): any;
export declare function tfPlanWorkflowStepEksResourceScalingConfigPropertyToHclTerraform(struct?: TfPlan.WorkflowStepEksResourceScalingConfigProperty | cdktn.IResolvable): any;
export declare function tfPlanWorkflowStepExecutionApprovalConfigPropertyToTerraform(struct?: TfPlan.WorkflowStepExecutionApprovalConfigProperty | cdktn.IResolvable): any;
export declare function tfPlanWorkflowStepExecutionApprovalConfigPropertyToHclTerraform(struct?: TfPlan.WorkflowStepExecutionApprovalConfigProperty | cdktn.IResolvable): any;
export declare function tfPlanWorkflowStepGlobalAuroraConfigUngracefulPropertyToTerraform(struct?: TfPlan.WorkflowStepGlobalAuroraConfigUngracefulProperty | cdktn.IResolvable): any;
export declare function tfPlanWorkflowStepGlobalAuroraConfigUngracefulPropertyToHclTerraform(struct?: TfPlan.WorkflowStepGlobalAuroraConfigUngracefulProperty | cdktn.IResolvable): any;
export declare function tfPlanWorkflowStepGlobalAuroraConfigPropertyToTerraform(struct?: TfPlan.WorkflowStepGlobalAuroraConfigProperty | cdktn.IResolvable): any;
export declare function tfPlanWorkflowStepGlobalAuroraConfigPropertyToHclTerraform(struct?: TfPlan.WorkflowStepGlobalAuroraConfigProperty | cdktn.IResolvable): any;
export declare function tfPlanWorkflowStepLambdaEventSourceMappingConfigRegionEventSourceMappingPropertyToTerraform(struct?: TfPlan.WorkflowStepLambdaEventSourceMappingConfigRegionEventSourceMappingProperty | cdktn.IResolvable): any;
export declare function tfPlanWorkflowStepLambdaEventSourceMappingConfigRegionEventSourceMappingPropertyToHclTerraform(struct?: TfPlan.WorkflowStepLambdaEventSourceMappingConfigRegionEventSourceMappingProperty | cdktn.IResolvable): any;
export declare function tfPlanWorkflowStepLambdaEventSourceMappingConfigUngracefulPropertyToTerraform(struct?: TfPlan.WorkflowStepLambdaEventSourceMappingConfigUngracefulProperty | cdktn.IResolvable): any;
export declare function tfPlanWorkflowStepLambdaEventSourceMappingConfigUngracefulPropertyToHclTerraform(struct?: TfPlan.WorkflowStepLambdaEventSourceMappingConfigUngracefulProperty | cdktn.IResolvable): any;
export declare function tfPlanWorkflowStepLambdaEventSourceMappingConfigPropertyToTerraform(struct?: TfPlan.WorkflowStepLambdaEventSourceMappingConfigProperty | cdktn.IResolvable): any;
export declare function tfPlanWorkflowStepLambdaEventSourceMappingConfigPropertyToHclTerraform(struct?: TfPlan.WorkflowStepLambdaEventSourceMappingConfigProperty | cdktn.IResolvable): any;
export declare function tfPlanWorkflowStepNeptuneGlobalDatabaseConfigUngracefulPropertyToTerraform(struct?: TfPlan.WorkflowStepNeptuneGlobalDatabaseConfigUngracefulProperty | cdktn.IResolvable): any;
export declare function tfPlanWorkflowStepNeptuneGlobalDatabaseConfigUngracefulPropertyToHclTerraform(struct?: TfPlan.WorkflowStepNeptuneGlobalDatabaseConfigUngracefulProperty | cdktn.IResolvable): any;
export declare function tfPlanWorkflowStepNeptuneGlobalDatabaseConfigPropertyToTerraform(struct?: TfPlan.WorkflowStepNeptuneGlobalDatabaseConfigProperty | cdktn.IResolvable): any;
export declare function tfPlanWorkflowStepNeptuneGlobalDatabaseConfigPropertyToHclTerraform(struct?: TfPlan.WorkflowStepNeptuneGlobalDatabaseConfigProperty | cdktn.IResolvable): any;
export declare function tfPlanWorkflowStepParallelConfigStepArcRoutingControlConfigRegionAndRoutingControlsRoutingControlPropertyToTerraform(struct?: TfPlan.WorkflowStepParallelConfigStepArcRoutingControlConfigRegionAndRoutingControlsRoutingControlProperty | cdktn.IResolvable): any;
export declare function tfPlanWorkflowStepParallelConfigStepArcRoutingControlConfigRegionAndRoutingControlsRoutingControlPropertyToHclTerraform(struct?: TfPlan.WorkflowStepParallelConfigStepArcRoutingControlConfigRegionAndRoutingControlsRoutingControlProperty | cdktn.IResolvable): any;
export declare function tfPlanWorkflowStepParallelConfigStepArcRoutingControlConfigRegionAndRoutingControlsPropertyToTerraform(struct?: TfPlan.WorkflowStepParallelConfigStepArcRoutingControlConfigRegionAndRoutingControlsProperty | cdktn.IResolvable): any;
export declare function tfPlanWorkflowStepParallelConfigStepArcRoutingControlConfigRegionAndRoutingControlsPropertyToHclTerraform(struct?: TfPlan.WorkflowStepParallelConfigStepArcRoutingControlConfigRegionAndRoutingControlsProperty | cdktn.IResolvable): any;
export declare function tfPlanWorkflowStepParallelConfigStepArcRoutingControlConfigPropertyToTerraform(struct?: TfPlan.WorkflowStepParallelConfigStepArcRoutingControlConfigProperty | cdktn.IResolvable): any;
export declare function tfPlanWorkflowStepParallelConfigStepArcRoutingControlConfigPropertyToHclTerraform(struct?: TfPlan.WorkflowStepParallelConfigStepArcRoutingControlConfigProperty | cdktn.IResolvable): any;
export declare function tfPlanWorkflowStepParallelConfigStepAuroraProvisionedScalingConfigPropertyToTerraform(struct?: TfPlan.WorkflowStepParallelConfigStepAuroraProvisionedScalingConfigProperty | cdktn.IResolvable): any;
export declare function tfPlanWorkflowStepParallelConfigStepAuroraProvisionedScalingConfigPropertyToHclTerraform(struct?: TfPlan.WorkflowStepParallelConfigStepAuroraProvisionedScalingConfigProperty | cdktn.IResolvable): any;
export declare function tfPlanWorkflowStepParallelConfigStepAuroraServerlessScalingConfigPropertyToTerraform(struct?: TfPlan.WorkflowStepParallelConfigStepAuroraServerlessScalingConfigProperty | cdktn.IResolvable): any;
export declare function tfPlanWorkflowStepParallelConfigStepAuroraServerlessScalingConfigPropertyToHclTerraform(struct?: TfPlan.WorkflowStepParallelConfigStepAuroraServerlessScalingConfigProperty | cdktn.IResolvable): any;
export declare function tfPlanWorkflowStepParallelConfigStepCustomActionLambdaConfigLambdaPropertyToTerraform(struct?: TfPlan.WorkflowStepParallelConfigStepCustomActionLambdaConfigLambdaProperty | cdktn.IResolvable): any;
export declare function tfPlanWorkflowStepParallelConfigStepCustomActionLambdaConfigLambdaPropertyToHclTerraform(struct?: TfPlan.WorkflowStepParallelConfigStepCustomActionLambdaConfigLambdaProperty | cdktn.IResolvable): any;
export declare function tfPlanWorkflowStepParallelConfigStepCustomActionLambdaConfigUngracefulPropertyToTerraform(struct?: TfPlan.WorkflowStepParallelConfigStepCustomActionLambdaConfigUngracefulProperty | cdktn.IResolvable): any;
export declare function tfPlanWorkflowStepParallelConfigStepCustomActionLambdaConfigUngracefulPropertyToHclTerraform(struct?: TfPlan.WorkflowStepParallelConfigStepCustomActionLambdaConfigUngracefulProperty | cdktn.IResolvable): any;
export declare function tfPlanWorkflowStepParallelConfigStepCustomActionLambdaConfigPropertyToTerraform(struct?: TfPlan.WorkflowStepParallelConfigStepCustomActionLambdaConfigProperty | cdktn.IResolvable): any;
export declare function tfPlanWorkflowStepParallelConfigStepCustomActionLambdaConfigPropertyToHclTerraform(struct?: TfPlan.WorkflowStepParallelConfigStepCustomActionLambdaConfigProperty | cdktn.IResolvable): any;
export declare function tfPlanWorkflowStepParallelConfigStepDocumentDbConfigUngracefulPropertyToTerraform(struct?: TfPlan.WorkflowStepParallelConfigStepDocumentDbConfigUngracefulProperty | cdktn.IResolvable): any;
export declare function tfPlanWorkflowStepParallelConfigStepDocumentDbConfigUngracefulPropertyToHclTerraform(struct?: TfPlan.WorkflowStepParallelConfigStepDocumentDbConfigUngracefulProperty | cdktn.IResolvable): any;
export declare function tfPlanWorkflowStepParallelConfigStepDocumentDbConfigPropertyToTerraform(struct?: TfPlan.WorkflowStepParallelConfigStepDocumentDbConfigProperty | cdktn.IResolvable): any;
export declare function tfPlanWorkflowStepParallelConfigStepDocumentDbConfigPropertyToHclTerraform(struct?: TfPlan.WorkflowStepParallelConfigStepDocumentDbConfigProperty | cdktn.IResolvable): any;
export declare function tfPlanWorkflowStepParallelConfigStepEc2AsgCapacityIncreaseConfigAsgPropertyToTerraform(struct?: TfPlan.WorkflowStepParallelConfigStepEc2AsgCapacityIncreaseConfigAsgProperty | cdktn.IResolvable): any;
export declare function tfPlanWorkflowStepParallelConfigStepEc2AsgCapacityIncreaseConfigAsgPropertyToHclTerraform(struct?: TfPlan.WorkflowStepParallelConfigStepEc2AsgCapacityIncreaseConfigAsgProperty | cdktn.IResolvable): any;
export declare function tfPlanWorkflowStepParallelConfigStepEc2AsgCapacityIncreaseConfigUngracefulPropertyToTerraform(struct?: TfPlan.WorkflowStepParallelConfigStepEc2AsgCapacityIncreaseConfigUngracefulProperty | cdktn.IResolvable): any;
export declare function tfPlanWorkflowStepParallelConfigStepEc2AsgCapacityIncreaseConfigUngracefulPropertyToHclTerraform(struct?: TfPlan.WorkflowStepParallelConfigStepEc2AsgCapacityIncreaseConfigUngracefulProperty | cdktn.IResolvable): any;
export declare function tfPlanWorkflowStepParallelConfigStepEc2AsgCapacityIncreaseConfigPropertyToTerraform(struct?: TfPlan.WorkflowStepParallelConfigStepEc2AsgCapacityIncreaseConfigProperty | cdktn.IResolvable): any;
export declare function tfPlanWorkflowStepParallelConfigStepEc2AsgCapacityIncreaseConfigPropertyToHclTerraform(struct?: TfPlan.WorkflowStepParallelConfigStepEc2AsgCapacityIncreaseConfigProperty | cdktn.IResolvable): any;
export declare function tfPlanWorkflowStepParallelConfigStepEcsCapacityIncreaseConfigServicePropertyToTerraform(struct?: TfPlan.WorkflowStepParallelConfigStepEcsCapacityIncreaseConfigServiceProperty | cdktn.IResolvable): any;
export declare function tfPlanWorkflowStepParallelConfigStepEcsCapacityIncreaseConfigServicePropertyToHclTerraform(struct?: TfPlan.WorkflowStepParallelConfigStepEcsCapacityIncreaseConfigServiceProperty | cdktn.IResolvable): any;
export declare function tfPlanWorkflowStepParallelConfigStepEcsCapacityIncreaseConfigUngracefulPropertyToTerraform(struct?: TfPlan.WorkflowStepParallelConfigStepEcsCapacityIncreaseConfigUngracefulProperty | cdktn.IResolvable): any;
export declare function tfPlanWorkflowStepParallelConfigStepEcsCapacityIncreaseConfigUngracefulPropertyToHclTerraform(struct?: TfPlan.WorkflowStepParallelConfigStepEcsCapacityIncreaseConfigUngracefulProperty | cdktn.IResolvable): any;
export declare function tfPlanWorkflowStepParallelConfigStepEcsCapacityIncreaseConfigPropertyToTerraform(struct?: TfPlan.WorkflowStepParallelConfigStepEcsCapacityIncreaseConfigProperty | cdktn.IResolvable): any;
export declare function tfPlanWorkflowStepParallelConfigStepEcsCapacityIncreaseConfigPropertyToHclTerraform(struct?: TfPlan.WorkflowStepParallelConfigStepEcsCapacityIncreaseConfigProperty | cdktn.IResolvable): any;
export declare function tfPlanWorkflowStepParallelConfigStepEksResourceScalingConfigEksClustersPropertyToTerraform(struct?: TfPlan.WorkflowStepParallelConfigStepEksResourceScalingConfigEksClustersProperty | cdktn.IResolvable): any;
export declare function tfPlanWorkflowStepParallelConfigStepEksResourceScalingConfigEksClustersPropertyToHclTerraform(struct?: TfPlan.WorkflowStepParallelConfigStepEksResourceScalingConfigEksClustersProperty | cdktn.IResolvable): any;
export declare function tfPlanWorkflowStepParallelConfigStepEksResourceScalingConfigKubernetesResourceTypePropertyToTerraform(struct?: TfPlan.WorkflowStepParallelConfigStepEksResourceScalingConfigKubernetesResourceTypeProperty | cdktn.IResolvable): any;
export declare function tfPlanWorkflowStepParallelConfigStepEksResourceScalingConfigKubernetesResourceTypePropertyToHclTerraform(struct?: TfPlan.WorkflowStepParallelConfigStepEksResourceScalingConfigKubernetesResourceTypeProperty | cdktn.IResolvable): any;
export declare function tfPlanWorkflowStepParallelConfigStepEksResourceScalingConfigScalingResourcesResourcesPropertyToTerraform(struct?: TfPlan.WorkflowStepParallelConfigStepEksResourceScalingConfigScalingResourcesResourcesProperty | cdktn.IResolvable): any;
export declare function tfPlanWorkflowStepParallelConfigStepEksResourceScalingConfigScalingResourcesResourcesPropertyToHclTerraform(struct?: TfPlan.WorkflowStepParallelConfigStepEksResourceScalingConfigScalingResourcesResourcesProperty | cdktn.IResolvable): any;
export declare function tfPlanWorkflowStepParallelConfigStepEksResourceScalingConfigScalingResourcesPropertyToTerraform(struct?: TfPlan.WorkflowStepParallelConfigStepEksResourceScalingConfigScalingResourcesProperty | cdktn.IResolvable): any;
export declare function tfPlanWorkflowStepParallelConfigStepEksResourceScalingConfigScalingResourcesPropertyToHclTerraform(struct?: TfPlan.WorkflowStepParallelConfigStepEksResourceScalingConfigScalingResourcesProperty | cdktn.IResolvable): any;
export declare function tfPlanWorkflowStepParallelConfigStepEksResourceScalingConfigUngracefulPropertyToTerraform(struct?: TfPlan.WorkflowStepParallelConfigStepEksResourceScalingConfigUngracefulProperty | cdktn.IResolvable): any;
export declare function tfPlanWorkflowStepParallelConfigStepEksResourceScalingConfigUngracefulPropertyToHclTerraform(struct?: TfPlan.WorkflowStepParallelConfigStepEksResourceScalingConfigUngracefulProperty | cdktn.IResolvable): any;
export declare function tfPlanWorkflowStepParallelConfigStepEksResourceScalingConfigPropertyToTerraform(struct?: TfPlan.WorkflowStepParallelConfigStepEksResourceScalingConfigProperty | cdktn.IResolvable): any;
export declare function tfPlanWorkflowStepParallelConfigStepEksResourceScalingConfigPropertyToHclTerraform(struct?: TfPlan.WorkflowStepParallelConfigStepEksResourceScalingConfigProperty | cdktn.IResolvable): any;
export declare function tfPlanWorkflowStepParallelConfigStepExecutionApprovalConfigPropertyToTerraform(struct?: TfPlan.WorkflowStepParallelConfigStepExecutionApprovalConfigProperty | cdktn.IResolvable): any;
export declare function tfPlanWorkflowStepParallelConfigStepExecutionApprovalConfigPropertyToHclTerraform(struct?: TfPlan.WorkflowStepParallelConfigStepExecutionApprovalConfigProperty | cdktn.IResolvable): any;
export declare function tfPlanWorkflowStepParallelConfigStepGlobalAuroraConfigUngracefulPropertyToTerraform(struct?: TfPlan.WorkflowStepParallelConfigStepGlobalAuroraConfigUngracefulProperty | cdktn.IResolvable): any;
export declare function tfPlanWorkflowStepParallelConfigStepGlobalAuroraConfigUngracefulPropertyToHclTerraform(struct?: TfPlan.WorkflowStepParallelConfigStepGlobalAuroraConfigUngracefulProperty | cdktn.IResolvable): any;
export declare function tfPlanWorkflowStepParallelConfigStepGlobalAuroraConfigPropertyToTerraform(struct?: TfPlan.WorkflowStepParallelConfigStepGlobalAuroraConfigProperty | cdktn.IResolvable): any;
export declare function tfPlanWorkflowStepParallelConfigStepGlobalAuroraConfigPropertyToHclTerraform(struct?: TfPlan.WorkflowStepParallelConfigStepGlobalAuroraConfigProperty | cdktn.IResolvable): any;
export declare function tfPlanWorkflowStepParallelConfigStepLambdaEventSourceMappingConfigRegionEventSourceMappingPropertyToTerraform(struct?: TfPlan.WorkflowStepParallelConfigStepLambdaEventSourceMappingConfigRegionEventSourceMappingProperty | cdktn.IResolvable): any;
export declare function tfPlanWorkflowStepParallelConfigStepLambdaEventSourceMappingConfigRegionEventSourceMappingPropertyToHclTerraform(struct?: TfPlan.WorkflowStepParallelConfigStepLambdaEventSourceMappingConfigRegionEventSourceMappingProperty | cdktn.IResolvable): any;
export declare function tfPlanWorkflowStepParallelConfigStepLambdaEventSourceMappingConfigUngracefulPropertyToTerraform(struct?: TfPlan.WorkflowStepParallelConfigStepLambdaEventSourceMappingConfigUngracefulProperty | cdktn.IResolvable): any;
export declare function tfPlanWorkflowStepParallelConfigStepLambdaEventSourceMappingConfigUngracefulPropertyToHclTerraform(struct?: TfPlan.WorkflowStepParallelConfigStepLambdaEventSourceMappingConfigUngracefulProperty | cdktn.IResolvable): any;
export declare function tfPlanWorkflowStepParallelConfigStepLambdaEventSourceMappingConfigPropertyToTerraform(struct?: TfPlan.WorkflowStepParallelConfigStepLambdaEventSourceMappingConfigProperty | cdktn.IResolvable): any;
export declare function tfPlanWorkflowStepParallelConfigStepLambdaEventSourceMappingConfigPropertyToHclTerraform(struct?: TfPlan.WorkflowStepParallelConfigStepLambdaEventSourceMappingConfigProperty | cdktn.IResolvable): any;
export declare function tfPlanWorkflowStepParallelConfigStepNeptuneGlobalDatabaseConfigUngracefulPropertyToTerraform(struct?: TfPlan.WorkflowStepParallelConfigStepNeptuneGlobalDatabaseConfigUngracefulProperty | cdktn.IResolvable): any;
export declare function tfPlanWorkflowStepParallelConfigStepNeptuneGlobalDatabaseConfigUngracefulPropertyToHclTerraform(struct?: TfPlan.WorkflowStepParallelConfigStepNeptuneGlobalDatabaseConfigUngracefulProperty | cdktn.IResolvable): any;
export declare function tfPlanWorkflowStepParallelConfigStepNeptuneGlobalDatabaseConfigPropertyToTerraform(struct?: TfPlan.WorkflowStepParallelConfigStepNeptuneGlobalDatabaseConfigProperty | cdktn.IResolvable): any;
export declare function tfPlanWorkflowStepParallelConfigStepNeptuneGlobalDatabaseConfigPropertyToHclTerraform(struct?: TfPlan.WorkflowStepParallelConfigStepNeptuneGlobalDatabaseConfigProperty | cdktn.IResolvable): any;
export declare function tfPlanWorkflowStepParallelConfigStepRdsCreateCrossRegionReadReplicaConfigPropertyToTerraform(struct?: TfPlan.WorkflowStepParallelConfigStepRdsCreateCrossRegionReadReplicaConfigProperty | cdktn.IResolvable): any;
export declare function tfPlanWorkflowStepParallelConfigStepRdsCreateCrossRegionReadReplicaConfigPropertyToHclTerraform(struct?: TfPlan.WorkflowStepParallelConfigStepRdsCreateCrossRegionReadReplicaConfigProperty | cdktn.IResolvable): any;
export declare function tfPlanWorkflowStepParallelConfigStepRdsPromoteReadReplicaConfigPropertyToTerraform(struct?: TfPlan.WorkflowStepParallelConfigStepRdsPromoteReadReplicaConfigProperty | cdktn.IResolvable): any;
export declare function tfPlanWorkflowStepParallelConfigStepRdsPromoteReadReplicaConfigPropertyToHclTerraform(struct?: TfPlan.WorkflowStepParallelConfigStepRdsPromoteReadReplicaConfigProperty | cdktn.IResolvable): any;
export declare function tfPlanWorkflowStepParallelConfigStepRegionSwitchPlanConfigPropertyToTerraform(struct?: TfPlan.WorkflowStepParallelConfigStepRegionSwitchPlanConfigProperty | cdktn.IResolvable): any;
export declare function tfPlanWorkflowStepParallelConfigStepRegionSwitchPlanConfigPropertyToHclTerraform(struct?: TfPlan.WorkflowStepParallelConfigStepRegionSwitchPlanConfigProperty | cdktn.IResolvable): any;
export declare function tfPlanWorkflowStepParallelConfigStepRoute53HealthCheckConfigRecordSetPropertyToTerraform(struct?: TfPlan.WorkflowStepParallelConfigStepRoute53HealthCheckConfigRecordSetProperty | cdktn.IResolvable): any;
export declare function tfPlanWorkflowStepParallelConfigStepRoute53HealthCheckConfigRecordSetPropertyToHclTerraform(struct?: TfPlan.WorkflowStepParallelConfigStepRoute53HealthCheckConfigRecordSetProperty | cdktn.IResolvable): any;
export declare function tfPlanWorkflowStepParallelConfigStepRoute53HealthCheckConfigPropertyToTerraform(struct?: TfPlan.WorkflowStepParallelConfigStepRoute53HealthCheckConfigProperty | cdktn.IResolvable): any;
export declare function tfPlanWorkflowStepParallelConfigStepRoute53HealthCheckConfigPropertyToHclTerraform(struct?: TfPlan.WorkflowStepParallelConfigStepRoute53HealthCheckConfigProperty | cdktn.IResolvable): any;
export declare function tfPlanWorkflowStepParallelConfigStepPropertyToTerraform(struct?: TfPlan.WorkflowStepParallelConfigStepProperty | cdktn.IResolvable): any;
export declare function tfPlanWorkflowStepParallelConfigStepPropertyToHclTerraform(struct?: TfPlan.WorkflowStepParallelConfigStepProperty | cdktn.IResolvable): any;
export declare function tfPlanParallelConfigPropertyToTerraform(struct?: TfPlan.ParallelConfigProperty | cdktn.IResolvable): any;
export declare function tfPlanParallelConfigPropertyToHclTerraform(struct?: TfPlan.ParallelConfigProperty | cdktn.IResolvable): any;
export declare function tfPlanWorkflowStepRdsCreateCrossRegionReadReplicaConfigPropertyToTerraform(struct?: TfPlan.WorkflowStepRdsCreateCrossRegionReadReplicaConfigProperty | cdktn.IResolvable): any;
export declare function tfPlanWorkflowStepRdsCreateCrossRegionReadReplicaConfigPropertyToHclTerraform(struct?: TfPlan.WorkflowStepRdsCreateCrossRegionReadReplicaConfigProperty | cdktn.IResolvable): any;
export declare function tfPlanWorkflowStepRdsPromoteReadReplicaConfigPropertyToTerraform(struct?: TfPlan.WorkflowStepRdsPromoteReadReplicaConfigProperty | cdktn.IResolvable): any;
export declare function tfPlanWorkflowStepRdsPromoteReadReplicaConfigPropertyToHclTerraform(struct?: TfPlan.WorkflowStepRdsPromoteReadReplicaConfigProperty | cdktn.IResolvable): any;
export declare function tfPlanWorkflowStepRegionSwitchPlanConfigPropertyToTerraform(struct?: TfPlan.WorkflowStepRegionSwitchPlanConfigProperty | cdktn.IResolvable): any;
export declare function tfPlanWorkflowStepRegionSwitchPlanConfigPropertyToHclTerraform(struct?: TfPlan.WorkflowStepRegionSwitchPlanConfigProperty | cdktn.IResolvable): any;
export declare function tfPlanWorkflowStepRoute53HealthCheckConfigRecordSetPropertyToTerraform(struct?: TfPlan.WorkflowStepRoute53HealthCheckConfigRecordSetProperty | cdktn.IResolvable): any;
export declare function tfPlanWorkflowStepRoute53HealthCheckConfigRecordSetPropertyToHclTerraform(struct?: TfPlan.WorkflowStepRoute53HealthCheckConfigRecordSetProperty | cdktn.IResolvable): any;
export declare function tfPlanWorkflowStepRoute53HealthCheckConfigPropertyToTerraform(struct?: TfPlan.WorkflowStepRoute53HealthCheckConfigProperty | cdktn.IResolvable): any;
export declare function tfPlanWorkflowStepRoute53HealthCheckConfigPropertyToHclTerraform(struct?: TfPlan.WorkflowStepRoute53HealthCheckConfigProperty | cdktn.IResolvable): any;
export declare function tfPlanWorkflowStepPropertyToTerraform(struct?: TfPlan.WorkflowStepProperty | cdktn.IResolvable): any;
export declare function tfPlanWorkflowStepPropertyToHclTerraform(struct?: TfPlan.WorkflowStepProperty | cdktn.IResolvable): any;
export declare function tfPlanWorkflowPropertyToTerraform(struct?: TfPlan.WorkflowProperty | cdktn.IResolvable): any;
export declare function tfPlanWorkflowPropertyToHclTerraform(struct?: TfPlan.WorkflowProperty | cdktn.IResolvable): any;
export declare namespace TfPlan {
    interface AssociatedAlarmsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#alarm_type TfPlan#alarm_type}
        */
        readonly alarmType: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#cross_account_role TfPlan#cross_account_role}
        */
        readonly crossAccountRole?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#external_id TfPlan#external_id}
        */
        readonly externalId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#map_block_key TfPlan#map_block_key}
        */
        readonly mapBlockKey: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#resource_identifier TfPlan#resource_identifier}
        */
        readonly resourceIdentifier: string;
    }
    class AssociatedAlarmsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AssociatedAlarmsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: AssociatedAlarmsProperty | cdktn.IResolvable | undefined);
        private _alarmType?;
        get alarmType(): string;
        set alarmType(value: string);
        get alarmTypeInput(): string | undefined;
        private _crossAccountRole?;
        get crossAccountRole(): string;
        set crossAccountRole(value: string);
        resetCrossAccountRole(): void;
        get crossAccountRoleInput(): string | undefined;
        private _externalId?;
        get externalId(): string;
        set externalId(value: string);
        resetExternalId(): void;
        get externalIdInput(): string | undefined;
        private _mapBlockKey?;
        get mapBlockKey(): string;
        set mapBlockKey(value: string);
        get mapBlockKeyInput(): string | undefined;
        private _resourceIdentifier?;
        get resourceIdentifier(): string;
        set resourceIdentifier(value: string);
        get resourceIdentifierInput(): string | undefined;
    }
    class AssociatedAlarmsPropertyList extends cdktn.ComplexList {
        internalValue?: AssociatedAlarmsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AssociatedAlarmsPropertyOutputReference;
    }
    interface S3ConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#bucket_owner TfPlan#bucket_owner}
        */
        readonly bucketOwner: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#bucket_path TfPlan#bucket_path}
        */
        readonly bucketPath: string;
    }
    class S3ConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): S3ConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: S3ConfigurationProperty | cdktn.IResolvable | undefined);
        private _bucketOwner?;
        get bucketOwner(): string;
        set bucketOwner(value: string);
        get bucketOwnerInput(): string | undefined;
        private _bucketPath?;
        get bucketPath(): string;
        set bucketPath(value: string);
        get bucketPathInput(): string | undefined;
    }
    class S3ConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: S3ConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): S3ConfigurationPropertyOutputReference;
    }
    interface ReportOutputProperty {
        /**
        * s3_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#s3_configuration TfPlan#s3_configuration}
        */
        readonly s3Configuration?: S3ConfigurationProperty[] | cdktn.IResolvable;
    }
    class ReportOutputPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ReportOutputProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ReportOutputProperty | cdktn.IResolvable | undefined);
        private _s3Configuration;
        get s3Configuration(): S3ConfigurationPropertyList;
        putS3Configuration(value: S3ConfigurationProperty[] | cdktn.IResolvable): void;
        resetS3Configuration(): void;
        get s3ConfigurationInput(): cdktn.IResolvable | S3ConfigurationProperty[] | undefined;
    }
    class ReportOutputPropertyList extends cdktn.ComplexList {
        internalValue?: ReportOutputProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ReportOutputPropertyOutputReference;
    }
    interface ReportConfigurationProperty {
        /**
        * report_output block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#report_output TfPlan#report_output}
        */
        readonly reportOutput?: ReportOutputProperty[] | cdktn.IResolvable;
    }
    class ReportConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ReportConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ReportConfigurationProperty | cdktn.IResolvable | undefined);
        private _reportOutput;
        get reportOutput(): ReportOutputPropertyList;
        putReportOutput(value: ReportOutputProperty[] | cdktn.IResolvable): void;
        resetReportOutput(): void;
        get reportOutputInput(): cdktn.IResolvable | ReportOutputProperty[] | undefined;
    }
    class ReportConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: ReportConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ReportConfigurationPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#create TfPlan#create}
        */
        readonly create?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Setting a timeout for a Delete operation is only applicable if changes are saved into state before the destroy operation occurs.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#delete TfPlan#delete}
        */
        readonly delete?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#update TfPlan#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
    interface ConditionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#associated_alarm_name TfPlan#associated_alarm_name}
        */
        readonly associatedAlarmName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#condition TfPlan#condition}
        */
        readonly condition: string;
    }
    class ConditionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ConditionsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ConditionsProperty | cdktn.IResolvable | undefined);
        private _associatedAlarmName?;
        get associatedAlarmName(): string;
        set associatedAlarmName(value: string);
        get associatedAlarmNameInput(): string | undefined;
        private _condition?;
        get condition(): string;
        set condition(value: string);
        get conditionInput(): string | undefined;
    }
    class ConditionsPropertyList extends cdktn.ComplexList {
        internalValue?: ConditionsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ConditionsPropertyOutputReference;
    }
    interface TriggersProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#action TfPlan#action}
        */
        readonly action: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#description TfPlan#description}
        */
        readonly description?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#min_delay_minutes_between_executions TfPlan#min_delay_minutes_between_executions}
        */
        readonly minDelayMinutesBetweenExecutions: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#target_region TfPlan#target_region}
        */
        readonly targetRegion: string;
        /**
        * conditions block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#conditions TfPlan#conditions}
        */
        readonly conditions?: ConditionsProperty[] | cdktn.IResolvable;
    }
    class TriggersPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TriggersProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TriggersProperty | cdktn.IResolvable | undefined);
        private _action?;
        get action(): string;
        set action(value: string);
        get actionInput(): string | undefined;
        private _description?;
        get description(): string;
        set description(value: string);
        resetDescription(): void;
        get descriptionInput(): string | undefined;
        private _minDelayMinutesBetweenExecutions?;
        get minDelayMinutesBetweenExecutions(): number;
        set minDelayMinutesBetweenExecutions(value: number);
        get minDelayMinutesBetweenExecutionsInput(): number | undefined;
        private _targetRegion?;
        get targetRegion(): string;
        set targetRegion(value: string);
        get targetRegionInput(): string | undefined;
        private _conditions;
        get conditions(): ConditionsPropertyList;
        putConditions(value: ConditionsProperty[] | cdktn.IResolvable): void;
        resetConditions(): void;
        get conditionsInput(): cdktn.IResolvable | ConditionsProperty[] | undefined;
    }
    class TriggersPropertyList extends cdktn.ComplexList {
        internalValue?: TriggersProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TriggersPropertyOutputReference;
    }
    interface WorkflowStepArcRoutingControlConfigRegionAndRoutingControlsRoutingControlProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#routing_control_arn TfPlan#routing_control_arn}
        */
        readonly routingControlArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#state TfPlan#state}
        */
        readonly state: string;
    }
    class WorkflowStepArcRoutingControlConfigRegionAndRoutingControlsRoutingControlPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepArcRoutingControlConfigRegionAndRoutingControlsRoutingControlProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepArcRoutingControlConfigRegionAndRoutingControlsRoutingControlProperty | cdktn.IResolvable | undefined);
        private _routingControlArn?;
        get routingControlArn(): string;
        set routingControlArn(value: string);
        get routingControlArnInput(): string | undefined;
        private _state?;
        get state(): string;
        set state(value: string);
        get stateInput(): string | undefined;
    }
    class WorkflowStepArcRoutingControlConfigRegionAndRoutingControlsRoutingControlPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepArcRoutingControlConfigRegionAndRoutingControlsRoutingControlProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepArcRoutingControlConfigRegionAndRoutingControlsRoutingControlPropertyOutputReference;
    }
    interface WorkflowStepArcRoutingControlConfigRegionAndRoutingControlsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#region TfPlan#region}
        */
        readonly region: string;
        /**
        * routing_control block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#routing_control TfPlan#routing_control}
        */
        readonly routingControl?: WorkflowStepArcRoutingControlConfigRegionAndRoutingControlsRoutingControlProperty[] | cdktn.IResolvable;
    }
    class WorkflowStepArcRoutingControlConfigRegionAndRoutingControlsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepArcRoutingControlConfigRegionAndRoutingControlsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepArcRoutingControlConfigRegionAndRoutingControlsProperty | cdktn.IResolvable | undefined);
        private _region?;
        get region(): string;
        set region(value: string);
        get regionInput(): string | undefined;
        private _routingControl;
        get routingControl(): WorkflowStepArcRoutingControlConfigRegionAndRoutingControlsRoutingControlPropertyList;
        putRoutingControl(value: WorkflowStepArcRoutingControlConfigRegionAndRoutingControlsRoutingControlProperty[] | cdktn.IResolvable): void;
        resetRoutingControl(): void;
        get routingControlInput(): cdktn.IResolvable | WorkflowStepArcRoutingControlConfigRegionAndRoutingControlsRoutingControlProperty[] | undefined;
    }
    class WorkflowStepArcRoutingControlConfigRegionAndRoutingControlsPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepArcRoutingControlConfigRegionAndRoutingControlsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepArcRoutingControlConfigRegionAndRoutingControlsPropertyOutputReference;
    }
    interface WorkflowStepArcRoutingControlConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#cross_account_role TfPlan#cross_account_role}
        */
        readonly crossAccountRole?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#external_id TfPlan#external_id}
        */
        readonly externalId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#timeout_minutes TfPlan#timeout_minutes}
        */
        readonly timeoutMinutes?: number;
        /**
        * region_and_routing_controls block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#region_and_routing_controls TfPlan#region_and_routing_controls}
        */
        readonly regionAndRoutingControls?: WorkflowStepArcRoutingControlConfigRegionAndRoutingControlsProperty[] | cdktn.IResolvable;
    }
    class WorkflowStepArcRoutingControlConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepArcRoutingControlConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepArcRoutingControlConfigProperty | cdktn.IResolvable | undefined);
        private _crossAccountRole?;
        get crossAccountRole(): string;
        set crossAccountRole(value: string);
        resetCrossAccountRole(): void;
        get crossAccountRoleInput(): string | undefined;
        private _externalId?;
        get externalId(): string;
        set externalId(value: string);
        resetExternalId(): void;
        get externalIdInput(): string | undefined;
        private _timeoutMinutes?;
        get timeoutMinutes(): number;
        set timeoutMinutes(value: number);
        resetTimeoutMinutes(): void;
        get timeoutMinutesInput(): number | undefined;
        private _regionAndRoutingControls;
        get regionAndRoutingControls(): WorkflowStepArcRoutingControlConfigRegionAndRoutingControlsPropertyList;
        putRegionAndRoutingControls(value: WorkflowStepArcRoutingControlConfigRegionAndRoutingControlsProperty[] | cdktn.IResolvable): void;
        resetRegionAndRoutingControls(): void;
        get regionAndRoutingControlsInput(): cdktn.IResolvable | WorkflowStepArcRoutingControlConfigRegionAndRoutingControlsProperty[] | undefined;
    }
    class WorkflowStepArcRoutingControlConfigPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepArcRoutingControlConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepArcRoutingControlConfigPropertyOutputReference;
    }
    interface WorkflowStepAuroraProvisionedScalingConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#cross_account_role TfPlan#cross_account_role}
        */
        readonly crossAccountRole?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#external_id TfPlan#external_id}
        */
        readonly externalId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#global_cluster_identifier TfPlan#global_cluster_identifier}
        */
        readonly globalClusterIdentifier: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#instance_arns TfPlan#instance_arns}
        */
        readonly instanceArns: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#region_database_cluster_arns TfPlan#region_database_cluster_arns}
        */
        readonly regionDatabaseClusterArns: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#timeout_minutes TfPlan#timeout_minutes}
        */
        readonly timeoutMinutes?: number;
    }
    class WorkflowStepAuroraProvisionedScalingConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepAuroraProvisionedScalingConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepAuroraProvisionedScalingConfigProperty | cdktn.IResolvable | undefined);
        private _crossAccountRole?;
        get crossAccountRole(): string;
        set crossAccountRole(value: string);
        resetCrossAccountRole(): void;
        get crossAccountRoleInput(): string | undefined;
        private _externalId?;
        get externalId(): string;
        set externalId(value: string);
        resetExternalId(): void;
        get externalIdInput(): string | undefined;
        private _globalClusterIdentifier?;
        get globalClusterIdentifier(): string;
        set globalClusterIdentifier(value: string);
        get globalClusterIdentifierInput(): string | undefined;
        private _instanceArns?;
        get instanceArns(): {
            [key: string]: string;
        };
        set instanceArns(value: {
            [key: string]: string;
        });
        get instanceArnsInput(): {
            [key: string]: string;
        } | undefined;
        private _regionDatabaseClusterArns?;
        get regionDatabaseClusterArns(): {
            [key: string]: string;
        };
        set regionDatabaseClusterArns(value: {
            [key: string]: string;
        });
        get regionDatabaseClusterArnsInput(): {
            [key: string]: string;
        } | undefined;
        private _timeoutMinutes?;
        get timeoutMinutes(): number;
        set timeoutMinutes(value: number);
        resetTimeoutMinutes(): void;
        get timeoutMinutesInput(): number | undefined;
    }
    class WorkflowStepAuroraProvisionedScalingConfigPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepAuroraProvisionedScalingConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepAuroraProvisionedScalingConfigPropertyOutputReference;
    }
    interface WorkflowStepAuroraServerlessScalingConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#cross_account_role TfPlan#cross_account_role}
        */
        readonly crossAccountRole?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#external_id TfPlan#external_id}
        */
        readonly externalId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#global_cluster_identifier TfPlan#global_cluster_identifier}
        */
        readonly globalClusterIdentifier: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#region_database_cluster_arns TfPlan#region_database_cluster_arns}
        */
        readonly regionDatabaseClusterArns: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#target_percent TfPlan#target_percent}
        */
        readonly targetPercent?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#timeout_minutes TfPlan#timeout_minutes}
        */
        readonly timeoutMinutes?: number;
    }
    class WorkflowStepAuroraServerlessScalingConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepAuroraServerlessScalingConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepAuroraServerlessScalingConfigProperty | cdktn.IResolvable | undefined);
        private _crossAccountRole?;
        get crossAccountRole(): string;
        set crossAccountRole(value: string);
        resetCrossAccountRole(): void;
        get crossAccountRoleInput(): string | undefined;
        private _externalId?;
        get externalId(): string;
        set externalId(value: string);
        resetExternalId(): void;
        get externalIdInput(): string | undefined;
        private _globalClusterIdentifier?;
        get globalClusterIdentifier(): string;
        set globalClusterIdentifier(value: string);
        get globalClusterIdentifierInput(): string | undefined;
        private _regionDatabaseClusterArns?;
        get regionDatabaseClusterArns(): {
            [key: string]: string;
        };
        set regionDatabaseClusterArns(value: {
            [key: string]: string;
        });
        get regionDatabaseClusterArnsInput(): {
            [key: string]: string;
        } | undefined;
        private _targetPercent?;
        get targetPercent(): number;
        set targetPercent(value: number);
        resetTargetPercent(): void;
        get targetPercentInput(): number | undefined;
        private _timeoutMinutes?;
        get timeoutMinutes(): number;
        set timeoutMinutes(value: number);
        resetTimeoutMinutes(): void;
        get timeoutMinutesInput(): number | undefined;
    }
    class WorkflowStepAuroraServerlessScalingConfigPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepAuroraServerlessScalingConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepAuroraServerlessScalingConfigPropertyOutputReference;
    }
    interface WorkflowStepCustomActionLambdaConfigLambdaProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#arn TfPlan#arn}
        */
        readonly arn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#cross_account_role TfPlan#cross_account_role}
        */
        readonly crossAccountRole?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#external_id TfPlan#external_id}
        */
        readonly externalId?: string;
    }
    class WorkflowStepCustomActionLambdaConfigLambdaPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepCustomActionLambdaConfigLambdaProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepCustomActionLambdaConfigLambdaProperty | cdktn.IResolvable | undefined);
        private _arn?;
        get arn(): string;
        set arn(value: string);
        get arnInput(): string | undefined;
        private _crossAccountRole?;
        get crossAccountRole(): string;
        set crossAccountRole(value: string);
        resetCrossAccountRole(): void;
        get crossAccountRoleInput(): string | undefined;
        private _externalId?;
        get externalId(): string;
        set externalId(value: string);
        resetExternalId(): void;
        get externalIdInput(): string | undefined;
    }
    class WorkflowStepCustomActionLambdaConfigLambdaPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepCustomActionLambdaConfigLambdaProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepCustomActionLambdaConfigLambdaPropertyOutputReference;
    }
    interface WorkflowStepCustomActionLambdaConfigUngracefulProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#behavior TfPlan#behavior}
        */
        readonly behavior: string;
    }
    class WorkflowStepCustomActionLambdaConfigUngracefulPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepCustomActionLambdaConfigUngracefulProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepCustomActionLambdaConfigUngracefulProperty | cdktn.IResolvable | undefined);
        private _behavior?;
        get behavior(): string;
        set behavior(value: string);
        get behaviorInput(): string | undefined;
    }
    class WorkflowStepCustomActionLambdaConfigUngracefulPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepCustomActionLambdaConfigUngracefulProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepCustomActionLambdaConfigUngracefulPropertyOutputReference;
    }
    interface WorkflowStepCustomActionLambdaConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#region_to_run TfPlan#region_to_run}
        */
        readonly regionToRun: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#retry_interval_minutes TfPlan#retry_interval_minutes}
        */
        readonly retryIntervalMinutes: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#timeout_minutes TfPlan#timeout_minutes}
        */
        readonly timeoutMinutes?: number;
        /**
        * lambda block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#lambda TfPlan#lambda}
        */
        readonly lambda?: WorkflowStepCustomActionLambdaConfigLambdaProperty[] | cdktn.IResolvable;
        /**
        * ungraceful block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#ungraceful TfPlan#ungraceful}
        */
        readonly ungraceful?: WorkflowStepCustomActionLambdaConfigUngracefulProperty[] | cdktn.IResolvable;
    }
    class WorkflowStepCustomActionLambdaConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepCustomActionLambdaConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepCustomActionLambdaConfigProperty | cdktn.IResolvable | undefined);
        private _regionToRun?;
        get regionToRun(): string;
        set regionToRun(value: string);
        get regionToRunInput(): string | undefined;
        private _retryIntervalMinutes?;
        get retryIntervalMinutes(): number;
        set retryIntervalMinutes(value: number);
        get retryIntervalMinutesInput(): number | undefined;
        private _timeoutMinutes?;
        get timeoutMinutes(): number;
        set timeoutMinutes(value: number);
        resetTimeoutMinutes(): void;
        get timeoutMinutesInput(): number | undefined;
        private _lambda;
        get lambda(): WorkflowStepCustomActionLambdaConfigLambdaPropertyList;
        putLambda(value: WorkflowStepCustomActionLambdaConfigLambdaProperty[] | cdktn.IResolvable): void;
        resetLambda(): void;
        get lambdaInput(): cdktn.IResolvable | WorkflowStepCustomActionLambdaConfigLambdaProperty[] | undefined;
        private _ungraceful;
        get ungraceful(): WorkflowStepCustomActionLambdaConfigUngracefulPropertyList;
        putUngraceful(value: WorkflowStepCustomActionLambdaConfigUngracefulProperty[] | cdktn.IResolvable): void;
        resetUngraceful(): void;
        get ungracefulInput(): cdktn.IResolvable | WorkflowStepCustomActionLambdaConfigUngracefulProperty[] | undefined;
    }
    class WorkflowStepCustomActionLambdaConfigPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepCustomActionLambdaConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepCustomActionLambdaConfigPropertyOutputReference;
    }
    interface WorkflowStepDocumentDbConfigUngracefulProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#ungraceful TfPlan#ungraceful}
        */
        readonly ungraceful: string;
    }
    class WorkflowStepDocumentDbConfigUngracefulPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepDocumentDbConfigUngracefulProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepDocumentDbConfigUngracefulProperty | cdktn.IResolvable | undefined);
        private _ungraceful?;
        get ungraceful(): string;
        set ungraceful(value: string);
        get ungracefulInput(): string | undefined;
    }
    class WorkflowStepDocumentDbConfigUngracefulPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepDocumentDbConfigUngracefulProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepDocumentDbConfigUngracefulPropertyOutputReference;
    }
    interface WorkflowStepDocumentDbConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#behavior TfPlan#behavior}
        */
        readonly behavior: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#cross_account_role TfPlan#cross_account_role}
        */
        readonly crossAccountRole?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#database_cluster_arns TfPlan#database_cluster_arns}
        */
        readonly databaseClusterArns: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#external_id TfPlan#external_id}
        */
        readonly externalId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#global_cluster_identifier TfPlan#global_cluster_identifier}
        */
        readonly globalClusterIdentifier: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#timeout_minutes TfPlan#timeout_minutes}
        */
        readonly timeoutMinutes?: number;
        /**
        * ungraceful block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#ungraceful TfPlan#ungraceful}
        */
        readonly ungraceful?: WorkflowStepDocumentDbConfigUngracefulProperty[] | cdktn.IResolvable;
    }
    class WorkflowStepDocumentDbConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepDocumentDbConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepDocumentDbConfigProperty | cdktn.IResolvable | undefined);
        private _behavior?;
        get behavior(): string;
        set behavior(value: string);
        get behaviorInput(): string | undefined;
        private _crossAccountRole?;
        get crossAccountRole(): string;
        set crossAccountRole(value: string);
        resetCrossAccountRole(): void;
        get crossAccountRoleInput(): string | undefined;
        private _databaseClusterArns?;
        get databaseClusterArns(): string[];
        set databaseClusterArns(value: string[]);
        get databaseClusterArnsInput(): string[] | undefined;
        private _externalId?;
        get externalId(): string;
        set externalId(value: string);
        resetExternalId(): void;
        get externalIdInput(): string | undefined;
        private _globalClusterIdentifier?;
        get globalClusterIdentifier(): string;
        set globalClusterIdentifier(value: string);
        get globalClusterIdentifierInput(): string | undefined;
        private _timeoutMinutes?;
        get timeoutMinutes(): number;
        set timeoutMinutes(value: number);
        resetTimeoutMinutes(): void;
        get timeoutMinutesInput(): number | undefined;
        private _ungraceful;
        get ungraceful(): WorkflowStepDocumentDbConfigUngracefulPropertyList;
        putUngraceful(value: WorkflowStepDocumentDbConfigUngracefulProperty[] | cdktn.IResolvable): void;
        resetUngraceful(): void;
        get ungracefulInput(): cdktn.IResolvable | WorkflowStepDocumentDbConfigUngracefulProperty[] | undefined;
    }
    class WorkflowStepDocumentDbConfigPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepDocumentDbConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepDocumentDbConfigPropertyOutputReference;
    }
    interface WorkflowStepEc2AsgCapacityIncreaseConfigAsgProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#arn TfPlan#arn}
        */
        readonly arn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#cross_account_role TfPlan#cross_account_role}
        */
        readonly crossAccountRole?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#external_id TfPlan#external_id}
        */
        readonly externalId?: string;
    }
    class WorkflowStepEc2AsgCapacityIncreaseConfigAsgPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepEc2AsgCapacityIncreaseConfigAsgProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepEc2AsgCapacityIncreaseConfigAsgProperty | cdktn.IResolvable | undefined);
        private _arn?;
        get arn(): string;
        set arn(value: string);
        get arnInput(): string | undefined;
        private _crossAccountRole?;
        get crossAccountRole(): string;
        set crossAccountRole(value: string);
        resetCrossAccountRole(): void;
        get crossAccountRoleInput(): string | undefined;
        private _externalId?;
        get externalId(): string;
        set externalId(value: string);
        resetExternalId(): void;
        get externalIdInput(): string | undefined;
    }
    class WorkflowStepEc2AsgCapacityIncreaseConfigAsgPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepEc2AsgCapacityIncreaseConfigAsgProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepEc2AsgCapacityIncreaseConfigAsgPropertyOutputReference;
    }
    interface WorkflowStepEc2AsgCapacityIncreaseConfigUngracefulProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#minimum_success_percentage TfPlan#minimum_success_percentage}
        */
        readonly minimumSuccessPercentage: number;
    }
    class WorkflowStepEc2AsgCapacityIncreaseConfigUngracefulPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepEc2AsgCapacityIncreaseConfigUngracefulProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepEc2AsgCapacityIncreaseConfigUngracefulProperty | cdktn.IResolvable | undefined);
        private _minimumSuccessPercentage?;
        get minimumSuccessPercentage(): number;
        set minimumSuccessPercentage(value: number);
        get minimumSuccessPercentageInput(): number | undefined;
    }
    class WorkflowStepEc2AsgCapacityIncreaseConfigUngracefulPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepEc2AsgCapacityIncreaseConfigUngracefulProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepEc2AsgCapacityIncreaseConfigUngracefulPropertyOutputReference;
    }
    interface WorkflowStepEc2AsgCapacityIncreaseConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#capacity_monitoring_approach TfPlan#capacity_monitoring_approach}
        */
        readonly capacityMonitoringApproach: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#target_percent TfPlan#target_percent}
        */
        readonly targetPercent?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#timeout_minutes TfPlan#timeout_minutes}
        */
        readonly timeoutMinutes?: number;
        /**
        * asg block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#asg TfPlan#asg}
        */
        readonly asg?: WorkflowStepEc2AsgCapacityIncreaseConfigAsgProperty[] | cdktn.IResolvable;
        /**
        * ungraceful block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#ungraceful TfPlan#ungraceful}
        */
        readonly ungraceful?: WorkflowStepEc2AsgCapacityIncreaseConfigUngracefulProperty[] | cdktn.IResolvable;
    }
    class WorkflowStepEc2AsgCapacityIncreaseConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepEc2AsgCapacityIncreaseConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepEc2AsgCapacityIncreaseConfigProperty | cdktn.IResolvable | undefined);
        private _capacityMonitoringApproach?;
        get capacityMonitoringApproach(): string;
        set capacityMonitoringApproach(value: string);
        get capacityMonitoringApproachInput(): string | undefined;
        private _targetPercent?;
        get targetPercent(): number;
        set targetPercent(value: number);
        resetTargetPercent(): void;
        get targetPercentInput(): number | undefined;
        private _timeoutMinutes?;
        get timeoutMinutes(): number;
        set timeoutMinutes(value: number);
        resetTimeoutMinutes(): void;
        get timeoutMinutesInput(): number | undefined;
        private _asg;
        get asg(): WorkflowStepEc2AsgCapacityIncreaseConfigAsgPropertyList;
        putAsg(value: WorkflowStepEc2AsgCapacityIncreaseConfigAsgProperty[] | cdktn.IResolvable): void;
        resetAsg(): void;
        get asgInput(): cdktn.IResolvable | WorkflowStepEc2AsgCapacityIncreaseConfigAsgProperty[] | undefined;
        private _ungraceful;
        get ungraceful(): WorkflowStepEc2AsgCapacityIncreaseConfigUngracefulPropertyList;
        putUngraceful(value: WorkflowStepEc2AsgCapacityIncreaseConfigUngracefulProperty[] | cdktn.IResolvable): void;
        resetUngraceful(): void;
        get ungracefulInput(): cdktn.IResolvable | WorkflowStepEc2AsgCapacityIncreaseConfigUngracefulProperty[] | undefined;
    }
    class WorkflowStepEc2AsgCapacityIncreaseConfigPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepEc2AsgCapacityIncreaseConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepEc2AsgCapacityIncreaseConfigPropertyOutputReference;
    }
    interface WorkflowStepEcsCapacityIncreaseConfigServiceProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#cluster_arn TfPlan#cluster_arn}
        */
        readonly clusterArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#cross_account_role TfPlan#cross_account_role}
        */
        readonly crossAccountRole?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#external_id TfPlan#external_id}
        */
        readonly externalId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#service_arn TfPlan#service_arn}
        */
        readonly serviceArn: string;
    }
    class WorkflowStepEcsCapacityIncreaseConfigServicePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepEcsCapacityIncreaseConfigServiceProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepEcsCapacityIncreaseConfigServiceProperty | cdktn.IResolvable | undefined);
        private _clusterArn?;
        get clusterArn(): string;
        set clusterArn(value: string);
        get clusterArnInput(): string | undefined;
        private _crossAccountRole?;
        get crossAccountRole(): string;
        set crossAccountRole(value: string);
        resetCrossAccountRole(): void;
        get crossAccountRoleInput(): string | undefined;
        private _externalId?;
        get externalId(): string;
        set externalId(value: string);
        resetExternalId(): void;
        get externalIdInput(): string | undefined;
        private _serviceArn?;
        get serviceArn(): string;
        set serviceArn(value: string);
        get serviceArnInput(): string | undefined;
    }
    class WorkflowStepEcsCapacityIncreaseConfigServicePropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepEcsCapacityIncreaseConfigServiceProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepEcsCapacityIncreaseConfigServicePropertyOutputReference;
    }
    interface WorkflowStepEcsCapacityIncreaseConfigUngracefulProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#minimum_success_percentage TfPlan#minimum_success_percentage}
        */
        readonly minimumSuccessPercentage: number;
    }
    class WorkflowStepEcsCapacityIncreaseConfigUngracefulPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepEcsCapacityIncreaseConfigUngracefulProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepEcsCapacityIncreaseConfigUngracefulProperty | cdktn.IResolvable | undefined);
        private _minimumSuccessPercentage?;
        get minimumSuccessPercentage(): number;
        set minimumSuccessPercentage(value: number);
        get minimumSuccessPercentageInput(): number | undefined;
    }
    class WorkflowStepEcsCapacityIncreaseConfigUngracefulPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepEcsCapacityIncreaseConfigUngracefulProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepEcsCapacityIncreaseConfigUngracefulPropertyOutputReference;
    }
    interface WorkflowStepEcsCapacityIncreaseConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#capacity_monitoring_approach TfPlan#capacity_monitoring_approach}
        */
        readonly capacityMonitoringApproach: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#target_percent TfPlan#target_percent}
        */
        readonly targetPercent?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#timeout_minutes TfPlan#timeout_minutes}
        */
        readonly timeoutMinutes?: number;
        /**
        * service block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#service TfPlan#service}
        */
        readonly service?: WorkflowStepEcsCapacityIncreaseConfigServiceProperty[] | cdktn.IResolvable;
        /**
        * ungraceful block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#ungraceful TfPlan#ungraceful}
        */
        readonly ungraceful?: WorkflowStepEcsCapacityIncreaseConfigUngracefulProperty[] | cdktn.IResolvable;
    }
    class WorkflowStepEcsCapacityIncreaseConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepEcsCapacityIncreaseConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepEcsCapacityIncreaseConfigProperty | cdktn.IResolvable | undefined);
        private _capacityMonitoringApproach?;
        get capacityMonitoringApproach(): string;
        set capacityMonitoringApproach(value: string);
        get capacityMonitoringApproachInput(): string | undefined;
        private _targetPercent?;
        get targetPercent(): number;
        set targetPercent(value: number);
        resetTargetPercent(): void;
        get targetPercentInput(): number | undefined;
        private _timeoutMinutes?;
        get timeoutMinutes(): number;
        set timeoutMinutes(value: number);
        resetTimeoutMinutes(): void;
        get timeoutMinutesInput(): number | undefined;
        private _service;
        get service(): WorkflowStepEcsCapacityIncreaseConfigServicePropertyList;
        putService(value: WorkflowStepEcsCapacityIncreaseConfigServiceProperty[] | cdktn.IResolvable): void;
        resetService(): void;
        get serviceInput(): cdktn.IResolvable | WorkflowStepEcsCapacityIncreaseConfigServiceProperty[] | undefined;
        private _ungraceful;
        get ungraceful(): WorkflowStepEcsCapacityIncreaseConfigUngracefulPropertyList;
        putUngraceful(value: WorkflowStepEcsCapacityIncreaseConfigUngracefulProperty[] | cdktn.IResolvable): void;
        resetUngraceful(): void;
        get ungracefulInput(): cdktn.IResolvable | WorkflowStepEcsCapacityIncreaseConfigUngracefulProperty[] | undefined;
    }
    class WorkflowStepEcsCapacityIncreaseConfigPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepEcsCapacityIncreaseConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepEcsCapacityIncreaseConfigPropertyOutputReference;
    }
    interface WorkflowStepEksResourceScalingConfigEksClustersProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#cluster_arn TfPlan#cluster_arn}
        */
        readonly clusterArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#cross_account_role TfPlan#cross_account_role}
        */
        readonly crossAccountRole?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#external_id TfPlan#external_id}
        */
        readonly externalId?: string;
    }
    class WorkflowStepEksResourceScalingConfigEksClustersPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepEksResourceScalingConfigEksClustersProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepEksResourceScalingConfigEksClustersProperty | cdktn.IResolvable | undefined);
        private _clusterArn?;
        get clusterArn(): string;
        set clusterArn(value: string);
        get clusterArnInput(): string | undefined;
        private _crossAccountRole?;
        get crossAccountRole(): string;
        set crossAccountRole(value: string);
        resetCrossAccountRole(): void;
        get crossAccountRoleInput(): string | undefined;
        private _externalId?;
        get externalId(): string;
        set externalId(value: string);
        resetExternalId(): void;
        get externalIdInput(): string | undefined;
    }
    class WorkflowStepEksResourceScalingConfigEksClustersPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepEksResourceScalingConfigEksClustersProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepEksResourceScalingConfigEksClustersPropertyOutputReference;
    }
    interface WorkflowStepEksResourceScalingConfigKubernetesResourceTypeProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#api_version TfPlan#api_version}
        */
        readonly apiVersion: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#kind TfPlan#kind}
        */
        readonly kind: string;
    }
    class WorkflowStepEksResourceScalingConfigKubernetesResourceTypePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepEksResourceScalingConfigKubernetesResourceTypeProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepEksResourceScalingConfigKubernetesResourceTypeProperty | cdktn.IResolvable | undefined);
        private _apiVersion?;
        get apiVersion(): string;
        set apiVersion(value: string);
        get apiVersionInput(): string | undefined;
        private _kind?;
        get kind(): string;
        set kind(value: string);
        get kindInput(): string | undefined;
    }
    class WorkflowStepEksResourceScalingConfigKubernetesResourceTypePropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepEksResourceScalingConfigKubernetesResourceTypeProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepEksResourceScalingConfigKubernetesResourceTypePropertyOutputReference;
    }
    interface WorkflowStepEksResourceScalingConfigScalingResourcesResourcesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#hpa_name TfPlan#hpa_name}
        */
        readonly hpaName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#name TfPlan#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#namespace TfPlan#namespace}
        */
        readonly namespace: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#resource_name TfPlan#resource_name}
        */
        readonly resourceName: string;
    }
    class WorkflowStepEksResourceScalingConfigScalingResourcesResourcesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepEksResourceScalingConfigScalingResourcesResourcesProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepEksResourceScalingConfigScalingResourcesResourcesProperty | cdktn.IResolvable | undefined);
        private _hpaName?;
        get hpaName(): string;
        set hpaName(value: string);
        resetHpaName(): void;
        get hpaNameInput(): string | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _namespace?;
        get namespace(): string;
        set namespace(value: string);
        get namespaceInput(): string | undefined;
        private _resourceName?;
        get resourceName(): string;
        set resourceName(value: string);
        get resourceNameInput(): string | undefined;
    }
    class WorkflowStepEksResourceScalingConfigScalingResourcesResourcesPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepEksResourceScalingConfigScalingResourcesResourcesProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepEksResourceScalingConfigScalingResourcesResourcesPropertyOutputReference;
    }
    interface WorkflowStepEksResourceScalingConfigScalingResourcesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#namespace TfPlan#namespace}
        */
        readonly namespace: string;
        /**
        * resources block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#resources TfPlan#resources}
        */
        readonly resources?: WorkflowStepEksResourceScalingConfigScalingResourcesResourcesProperty[] | cdktn.IResolvable;
    }
    class WorkflowStepEksResourceScalingConfigScalingResourcesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepEksResourceScalingConfigScalingResourcesProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepEksResourceScalingConfigScalingResourcesProperty | cdktn.IResolvable | undefined);
        private _namespace?;
        get namespace(): string;
        set namespace(value: string);
        get namespaceInput(): string | undefined;
        private _resources;
        get resources(): WorkflowStepEksResourceScalingConfigScalingResourcesResourcesPropertyList;
        putResources(value: WorkflowStepEksResourceScalingConfigScalingResourcesResourcesProperty[] | cdktn.IResolvable): void;
        resetResources(): void;
        get resourcesInput(): cdktn.IResolvable | WorkflowStepEksResourceScalingConfigScalingResourcesResourcesProperty[] | undefined;
    }
    class WorkflowStepEksResourceScalingConfigScalingResourcesPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepEksResourceScalingConfigScalingResourcesProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepEksResourceScalingConfigScalingResourcesPropertyOutputReference;
    }
    interface WorkflowStepEksResourceScalingConfigUngracefulProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#minimum_success_percentage TfPlan#minimum_success_percentage}
        */
        readonly minimumSuccessPercentage: number;
    }
    class WorkflowStepEksResourceScalingConfigUngracefulPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepEksResourceScalingConfigUngracefulProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepEksResourceScalingConfigUngracefulProperty | cdktn.IResolvable | undefined);
        private _minimumSuccessPercentage?;
        get minimumSuccessPercentage(): number;
        set minimumSuccessPercentage(value: number);
        get minimumSuccessPercentageInput(): number | undefined;
    }
    class WorkflowStepEksResourceScalingConfigUngracefulPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepEksResourceScalingConfigUngracefulProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepEksResourceScalingConfigUngracefulPropertyOutputReference;
    }
    interface WorkflowStepEksResourceScalingConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#capacity_monitoring_approach TfPlan#capacity_monitoring_approach}
        */
        readonly capacityMonitoringApproach: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#target_percent TfPlan#target_percent}
        */
        readonly targetPercent: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#timeout_minutes TfPlan#timeout_minutes}
        */
        readonly timeoutMinutes?: number;
        /**
        * eks_clusters block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#eks_clusters TfPlan#eks_clusters}
        */
        readonly eksClusters?: WorkflowStepEksResourceScalingConfigEksClustersProperty[] | cdktn.IResolvable;
        /**
        * kubernetes_resource_type block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#kubernetes_resource_type TfPlan#kubernetes_resource_type}
        */
        readonly kubernetesResourceType?: WorkflowStepEksResourceScalingConfigKubernetesResourceTypeProperty[] | cdktn.IResolvable;
        /**
        * scaling_resources block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#scaling_resources TfPlan#scaling_resources}
        */
        readonly scalingResources?: WorkflowStepEksResourceScalingConfigScalingResourcesProperty[] | cdktn.IResolvable;
        /**
        * ungraceful block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#ungraceful TfPlan#ungraceful}
        */
        readonly ungraceful?: WorkflowStepEksResourceScalingConfigUngracefulProperty[] | cdktn.IResolvable;
    }
    class WorkflowStepEksResourceScalingConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepEksResourceScalingConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepEksResourceScalingConfigProperty | cdktn.IResolvable | undefined);
        private _capacityMonitoringApproach?;
        get capacityMonitoringApproach(): string;
        set capacityMonitoringApproach(value: string);
        get capacityMonitoringApproachInput(): string | undefined;
        private _targetPercent?;
        get targetPercent(): number;
        set targetPercent(value: number);
        get targetPercentInput(): number | undefined;
        private _timeoutMinutes?;
        get timeoutMinutes(): number;
        set timeoutMinutes(value: number);
        resetTimeoutMinutes(): void;
        get timeoutMinutesInput(): number | undefined;
        private _eksClusters;
        get eksClusters(): WorkflowStepEksResourceScalingConfigEksClustersPropertyList;
        putEksClusters(value: WorkflowStepEksResourceScalingConfigEksClustersProperty[] | cdktn.IResolvable): void;
        resetEksClusters(): void;
        get eksClustersInput(): cdktn.IResolvable | WorkflowStepEksResourceScalingConfigEksClustersProperty[] | undefined;
        private _kubernetesResourceType;
        get kubernetesResourceType(): WorkflowStepEksResourceScalingConfigKubernetesResourceTypePropertyList;
        putKubernetesResourceType(value: WorkflowStepEksResourceScalingConfigKubernetesResourceTypeProperty[] | cdktn.IResolvable): void;
        resetKubernetesResourceType(): void;
        get kubernetesResourceTypeInput(): cdktn.IResolvable | WorkflowStepEksResourceScalingConfigKubernetesResourceTypeProperty[] | undefined;
        private _scalingResources;
        get scalingResources(): WorkflowStepEksResourceScalingConfigScalingResourcesPropertyList;
        putScalingResources(value: WorkflowStepEksResourceScalingConfigScalingResourcesProperty[] | cdktn.IResolvable): void;
        resetScalingResources(): void;
        get scalingResourcesInput(): cdktn.IResolvable | WorkflowStepEksResourceScalingConfigScalingResourcesProperty[] | undefined;
        private _ungraceful;
        get ungraceful(): WorkflowStepEksResourceScalingConfigUngracefulPropertyList;
        putUngraceful(value: WorkflowStepEksResourceScalingConfigUngracefulProperty[] | cdktn.IResolvable): void;
        resetUngraceful(): void;
        get ungracefulInput(): cdktn.IResolvable | WorkflowStepEksResourceScalingConfigUngracefulProperty[] | undefined;
    }
    class WorkflowStepEksResourceScalingConfigPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepEksResourceScalingConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepEksResourceScalingConfigPropertyOutputReference;
    }
    interface WorkflowStepExecutionApprovalConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#approval_role TfPlan#approval_role}
        */
        readonly approvalRole: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#timeout_minutes TfPlan#timeout_minutes}
        */
        readonly timeoutMinutes?: number;
    }
    class WorkflowStepExecutionApprovalConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepExecutionApprovalConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepExecutionApprovalConfigProperty | cdktn.IResolvable | undefined);
        private _approvalRole?;
        get approvalRole(): string;
        set approvalRole(value: string);
        get approvalRoleInput(): string | undefined;
        private _timeoutMinutes?;
        get timeoutMinutes(): number;
        set timeoutMinutes(value: number);
        resetTimeoutMinutes(): void;
        get timeoutMinutesInput(): number | undefined;
    }
    class WorkflowStepExecutionApprovalConfigPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepExecutionApprovalConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepExecutionApprovalConfigPropertyOutputReference;
    }
    interface WorkflowStepGlobalAuroraConfigUngracefulProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#ungraceful TfPlan#ungraceful}
        */
        readonly ungraceful: string;
    }
    class WorkflowStepGlobalAuroraConfigUngracefulPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepGlobalAuroraConfigUngracefulProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepGlobalAuroraConfigUngracefulProperty | cdktn.IResolvable | undefined);
        private _ungraceful?;
        get ungraceful(): string;
        set ungraceful(value: string);
        get ungracefulInput(): string | undefined;
    }
    class WorkflowStepGlobalAuroraConfigUngracefulPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepGlobalAuroraConfigUngracefulProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepGlobalAuroraConfigUngracefulPropertyOutputReference;
    }
    interface WorkflowStepGlobalAuroraConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#behavior TfPlan#behavior}
        */
        readonly behavior: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#cross_account_role TfPlan#cross_account_role}
        */
        readonly crossAccountRole?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#database_cluster_arns TfPlan#database_cluster_arns}
        */
        readonly databaseClusterArns: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#external_id TfPlan#external_id}
        */
        readonly externalId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#global_cluster_identifier TfPlan#global_cluster_identifier}
        */
        readonly globalClusterIdentifier: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#timeout_minutes TfPlan#timeout_minutes}
        */
        readonly timeoutMinutes?: number;
        /**
        * ungraceful block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#ungraceful TfPlan#ungraceful}
        */
        readonly ungraceful?: WorkflowStepGlobalAuroraConfigUngracefulProperty[] | cdktn.IResolvable;
    }
    class WorkflowStepGlobalAuroraConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepGlobalAuroraConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepGlobalAuroraConfigProperty | cdktn.IResolvable | undefined);
        private _behavior?;
        get behavior(): string;
        set behavior(value: string);
        get behaviorInput(): string | undefined;
        private _crossAccountRole?;
        get crossAccountRole(): string;
        set crossAccountRole(value: string);
        resetCrossAccountRole(): void;
        get crossAccountRoleInput(): string | undefined;
        private _databaseClusterArns?;
        get databaseClusterArns(): string[];
        set databaseClusterArns(value: string[]);
        get databaseClusterArnsInput(): string[] | undefined;
        private _externalId?;
        get externalId(): string;
        set externalId(value: string);
        resetExternalId(): void;
        get externalIdInput(): string | undefined;
        private _globalClusterIdentifier?;
        get globalClusterIdentifier(): string;
        set globalClusterIdentifier(value: string);
        get globalClusterIdentifierInput(): string | undefined;
        private _timeoutMinutes?;
        get timeoutMinutes(): number;
        set timeoutMinutes(value: number);
        resetTimeoutMinutes(): void;
        get timeoutMinutesInput(): number | undefined;
        private _ungraceful;
        get ungraceful(): WorkflowStepGlobalAuroraConfigUngracefulPropertyList;
        putUngraceful(value: WorkflowStepGlobalAuroraConfigUngracefulProperty[] | cdktn.IResolvable): void;
        resetUngraceful(): void;
        get ungracefulInput(): cdktn.IResolvable | WorkflowStepGlobalAuroraConfigUngracefulProperty[] | undefined;
    }
    class WorkflowStepGlobalAuroraConfigPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepGlobalAuroraConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepGlobalAuroraConfigPropertyOutputReference;
    }
    interface WorkflowStepLambdaEventSourceMappingConfigRegionEventSourceMappingProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#arn TfPlan#arn}
        */
        readonly arn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#cross_account_role TfPlan#cross_account_role}
        */
        readonly crossAccountRole?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#external_id TfPlan#external_id}
        */
        readonly externalId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#region TfPlan#region}
        */
        readonly region: string;
    }
    class WorkflowStepLambdaEventSourceMappingConfigRegionEventSourceMappingPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepLambdaEventSourceMappingConfigRegionEventSourceMappingProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepLambdaEventSourceMappingConfigRegionEventSourceMappingProperty | cdktn.IResolvable | undefined);
        private _arn?;
        get arn(): string;
        set arn(value: string);
        get arnInput(): string | undefined;
        private _crossAccountRole?;
        get crossAccountRole(): string;
        set crossAccountRole(value: string);
        resetCrossAccountRole(): void;
        get crossAccountRoleInput(): string | undefined;
        private _externalId?;
        get externalId(): string;
        set externalId(value: string);
        resetExternalId(): void;
        get externalIdInput(): string | undefined;
        private _region?;
        get region(): string;
        set region(value: string);
        get regionInput(): string | undefined;
    }
    class WorkflowStepLambdaEventSourceMappingConfigRegionEventSourceMappingPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepLambdaEventSourceMappingConfigRegionEventSourceMappingProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepLambdaEventSourceMappingConfigRegionEventSourceMappingPropertyOutputReference;
    }
    interface WorkflowStepLambdaEventSourceMappingConfigUngracefulProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#behavior TfPlan#behavior}
        */
        readonly behavior: string;
    }
    class WorkflowStepLambdaEventSourceMappingConfigUngracefulPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepLambdaEventSourceMappingConfigUngracefulProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepLambdaEventSourceMappingConfigUngracefulProperty | cdktn.IResolvable | undefined);
        private _behavior?;
        get behavior(): string;
        set behavior(value: string);
        get behaviorInput(): string | undefined;
    }
    class WorkflowStepLambdaEventSourceMappingConfigUngracefulPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepLambdaEventSourceMappingConfigUngracefulProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepLambdaEventSourceMappingConfigUngracefulPropertyOutputReference;
    }
    interface WorkflowStepLambdaEventSourceMappingConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#action TfPlan#action}
        */
        readonly action: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#timeout_minutes TfPlan#timeout_minutes}
        */
        readonly timeoutMinutes?: number;
        /**
        * region_event_source_mapping block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#region_event_source_mapping TfPlan#region_event_source_mapping}
        */
        readonly regionEventSourceMapping?: WorkflowStepLambdaEventSourceMappingConfigRegionEventSourceMappingProperty[] | cdktn.IResolvable;
        /**
        * ungraceful block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#ungraceful TfPlan#ungraceful}
        */
        readonly ungraceful?: WorkflowStepLambdaEventSourceMappingConfigUngracefulProperty[] | cdktn.IResolvable;
    }
    class WorkflowStepLambdaEventSourceMappingConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepLambdaEventSourceMappingConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepLambdaEventSourceMappingConfigProperty | cdktn.IResolvable | undefined);
        private _action?;
        get action(): string;
        set action(value: string);
        get actionInput(): string | undefined;
        private _timeoutMinutes?;
        get timeoutMinutes(): number;
        set timeoutMinutes(value: number);
        resetTimeoutMinutes(): void;
        get timeoutMinutesInput(): number | undefined;
        private _regionEventSourceMapping;
        get regionEventSourceMapping(): WorkflowStepLambdaEventSourceMappingConfigRegionEventSourceMappingPropertyList;
        putRegionEventSourceMapping(value: WorkflowStepLambdaEventSourceMappingConfigRegionEventSourceMappingProperty[] | cdktn.IResolvable): void;
        resetRegionEventSourceMapping(): void;
        get regionEventSourceMappingInput(): cdktn.IResolvable | WorkflowStepLambdaEventSourceMappingConfigRegionEventSourceMappingProperty[] | undefined;
        private _ungraceful;
        get ungraceful(): WorkflowStepLambdaEventSourceMappingConfigUngracefulPropertyList;
        putUngraceful(value: WorkflowStepLambdaEventSourceMappingConfigUngracefulProperty[] | cdktn.IResolvable): void;
        resetUngraceful(): void;
        get ungracefulInput(): cdktn.IResolvable | WorkflowStepLambdaEventSourceMappingConfigUngracefulProperty[] | undefined;
    }
    class WorkflowStepLambdaEventSourceMappingConfigPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepLambdaEventSourceMappingConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepLambdaEventSourceMappingConfigPropertyOutputReference;
    }
    interface WorkflowStepNeptuneGlobalDatabaseConfigUngracefulProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#ungraceful TfPlan#ungraceful}
        */
        readonly ungraceful: string;
    }
    class WorkflowStepNeptuneGlobalDatabaseConfigUngracefulPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepNeptuneGlobalDatabaseConfigUngracefulProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepNeptuneGlobalDatabaseConfigUngracefulProperty | cdktn.IResolvable | undefined);
        private _ungraceful?;
        get ungraceful(): string;
        set ungraceful(value: string);
        get ungracefulInput(): string | undefined;
    }
    class WorkflowStepNeptuneGlobalDatabaseConfigUngracefulPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepNeptuneGlobalDatabaseConfigUngracefulProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepNeptuneGlobalDatabaseConfigUngracefulPropertyOutputReference;
    }
    interface WorkflowStepNeptuneGlobalDatabaseConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#behavior TfPlan#behavior}
        */
        readonly behavior: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#cross_account_role TfPlan#cross_account_role}
        */
        readonly crossAccountRole?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#external_id TfPlan#external_id}
        */
        readonly externalId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#global_cluster_identifier TfPlan#global_cluster_identifier}
        */
        readonly globalClusterIdentifier: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#region_database_cluster_arns TfPlan#region_database_cluster_arns}
        */
        readonly regionDatabaseClusterArns: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#timeout_minutes TfPlan#timeout_minutes}
        */
        readonly timeoutMinutes?: number;
        /**
        * ungraceful block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#ungraceful TfPlan#ungraceful}
        */
        readonly ungraceful?: WorkflowStepNeptuneGlobalDatabaseConfigUngracefulProperty[] | cdktn.IResolvable;
    }
    class WorkflowStepNeptuneGlobalDatabaseConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepNeptuneGlobalDatabaseConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepNeptuneGlobalDatabaseConfigProperty | cdktn.IResolvable | undefined);
        private _behavior?;
        get behavior(): string;
        set behavior(value: string);
        get behaviorInput(): string | undefined;
        private _crossAccountRole?;
        get crossAccountRole(): string;
        set crossAccountRole(value: string);
        resetCrossAccountRole(): void;
        get crossAccountRoleInput(): string | undefined;
        private _externalId?;
        get externalId(): string;
        set externalId(value: string);
        resetExternalId(): void;
        get externalIdInput(): string | undefined;
        private _globalClusterIdentifier?;
        get globalClusterIdentifier(): string;
        set globalClusterIdentifier(value: string);
        get globalClusterIdentifierInput(): string | undefined;
        private _regionDatabaseClusterArns?;
        get regionDatabaseClusterArns(): {
            [key: string]: string;
        };
        set regionDatabaseClusterArns(value: {
            [key: string]: string;
        });
        get regionDatabaseClusterArnsInput(): {
            [key: string]: string;
        } | undefined;
        private _timeoutMinutes?;
        get timeoutMinutes(): number;
        set timeoutMinutes(value: number);
        resetTimeoutMinutes(): void;
        get timeoutMinutesInput(): number | undefined;
        private _ungraceful;
        get ungraceful(): WorkflowStepNeptuneGlobalDatabaseConfigUngracefulPropertyList;
        putUngraceful(value: WorkflowStepNeptuneGlobalDatabaseConfigUngracefulProperty[] | cdktn.IResolvable): void;
        resetUngraceful(): void;
        get ungracefulInput(): cdktn.IResolvable | WorkflowStepNeptuneGlobalDatabaseConfigUngracefulProperty[] | undefined;
    }
    class WorkflowStepNeptuneGlobalDatabaseConfigPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepNeptuneGlobalDatabaseConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepNeptuneGlobalDatabaseConfigPropertyOutputReference;
    }
    interface WorkflowStepParallelConfigStepArcRoutingControlConfigRegionAndRoutingControlsRoutingControlProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#routing_control_arn TfPlan#routing_control_arn}
        */
        readonly routingControlArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#state TfPlan#state}
        */
        readonly state: string;
    }
    class WorkflowStepParallelConfigStepArcRoutingControlConfigRegionAndRoutingControlsRoutingControlPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepParallelConfigStepArcRoutingControlConfigRegionAndRoutingControlsRoutingControlProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepParallelConfigStepArcRoutingControlConfigRegionAndRoutingControlsRoutingControlProperty | cdktn.IResolvable | undefined);
        private _routingControlArn?;
        get routingControlArn(): string;
        set routingControlArn(value: string);
        get routingControlArnInput(): string | undefined;
        private _state?;
        get state(): string;
        set state(value: string);
        get stateInput(): string | undefined;
    }
    class WorkflowStepParallelConfigStepArcRoutingControlConfigRegionAndRoutingControlsRoutingControlPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepParallelConfigStepArcRoutingControlConfigRegionAndRoutingControlsRoutingControlProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepParallelConfigStepArcRoutingControlConfigRegionAndRoutingControlsRoutingControlPropertyOutputReference;
    }
    interface WorkflowStepParallelConfigStepArcRoutingControlConfigRegionAndRoutingControlsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#region TfPlan#region}
        */
        readonly region: string;
        /**
        * routing_control block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#routing_control TfPlan#routing_control}
        */
        readonly routingControl?: WorkflowStepParallelConfigStepArcRoutingControlConfigRegionAndRoutingControlsRoutingControlProperty[] | cdktn.IResolvable;
    }
    class WorkflowStepParallelConfigStepArcRoutingControlConfigRegionAndRoutingControlsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepParallelConfigStepArcRoutingControlConfigRegionAndRoutingControlsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepParallelConfigStepArcRoutingControlConfigRegionAndRoutingControlsProperty | cdktn.IResolvable | undefined);
        private _region?;
        get region(): string;
        set region(value: string);
        get regionInput(): string | undefined;
        private _routingControl;
        get routingControl(): WorkflowStepParallelConfigStepArcRoutingControlConfigRegionAndRoutingControlsRoutingControlPropertyList;
        putRoutingControl(value: WorkflowStepParallelConfigStepArcRoutingControlConfigRegionAndRoutingControlsRoutingControlProperty[] | cdktn.IResolvable): void;
        resetRoutingControl(): void;
        get routingControlInput(): cdktn.IResolvable | WorkflowStepParallelConfigStepArcRoutingControlConfigRegionAndRoutingControlsRoutingControlProperty[] | undefined;
    }
    class WorkflowStepParallelConfigStepArcRoutingControlConfigRegionAndRoutingControlsPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepParallelConfigStepArcRoutingControlConfigRegionAndRoutingControlsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepParallelConfigStepArcRoutingControlConfigRegionAndRoutingControlsPropertyOutputReference;
    }
    interface WorkflowStepParallelConfigStepArcRoutingControlConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#cross_account_role TfPlan#cross_account_role}
        */
        readonly crossAccountRole?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#external_id TfPlan#external_id}
        */
        readonly externalId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#timeout_minutes TfPlan#timeout_minutes}
        */
        readonly timeoutMinutes?: number;
        /**
        * region_and_routing_controls block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#region_and_routing_controls TfPlan#region_and_routing_controls}
        */
        readonly regionAndRoutingControls?: WorkflowStepParallelConfigStepArcRoutingControlConfigRegionAndRoutingControlsProperty[] | cdktn.IResolvable;
    }
    class WorkflowStepParallelConfigStepArcRoutingControlConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepParallelConfigStepArcRoutingControlConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepParallelConfigStepArcRoutingControlConfigProperty | cdktn.IResolvable | undefined);
        private _crossAccountRole?;
        get crossAccountRole(): string;
        set crossAccountRole(value: string);
        resetCrossAccountRole(): void;
        get crossAccountRoleInput(): string | undefined;
        private _externalId?;
        get externalId(): string;
        set externalId(value: string);
        resetExternalId(): void;
        get externalIdInput(): string | undefined;
        private _timeoutMinutes?;
        get timeoutMinutes(): number;
        set timeoutMinutes(value: number);
        resetTimeoutMinutes(): void;
        get timeoutMinutesInput(): number | undefined;
        private _regionAndRoutingControls;
        get regionAndRoutingControls(): WorkflowStepParallelConfigStepArcRoutingControlConfigRegionAndRoutingControlsPropertyList;
        putRegionAndRoutingControls(value: WorkflowStepParallelConfigStepArcRoutingControlConfigRegionAndRoutingControlsProperty[] | cdktn.IResolvable): void;
        resetRegionAndRoutingControls(): void;
        get regionAndRoutingControlsInput(): cdktn.IResolvable | WorkflowStepParallelConfigStepArcRoutingControlConfigRegionAndRoutingControlsProperty[] | undefined;
    }
    class WorkflowStepParallelConfigStepArcRoutingControlConfigPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepParallelConfigStepArcRoutingControlConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepParallelConfigStepArcRoutingControlConfigPropertyOutputReference;
    }
    interface WorkflowStepParallelConfigStepAuroraProvisionedScalingConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#cross_account_role TfPlan#cross_account_role}
        */
        readonly crossAccountRole?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#external_id TfPlan#external_id}
        */
        readonly externalId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#global_cluster_identifier TfPlan#global_cluster_identifier}
        */
        readonly globalClusterIdentifier: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#instance_arns TfPlan#instance_arns}
        */
        readonly instanceArns: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#region_database_cluster_arns TfPlan#region_database_cluster_arns}
        */
        readonly regionDatabaseClusterArns: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#timeout_minutes TfPlan#timeout_minutes}
        */
        readonly timeoutMinutes?: number;
    }
    class WorkflowStepParallelConfigStepAuroraProvisionedScalingConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepParallelConfigStepAuroraProvisionedScalingConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepParallelConfigStepAuroraProvisionedScalingConfigProperty | cdktn.IResolvable | undefined);
        private _crossAccountRole?;
        get crossAccountRole(): string;
        set crossAccountRole(value: string);
        resetCrossAccountRole(): void;
        get crossAccountRoleInput(): string | undefined;
        private _externalId?;
        get externalId(): string;
        set externalId(value: string);
        resetExternalId(): void;
        get externalIdInput(): string | undefined;
        private _globalClusterIdentifier?;
        get globalClusterIdentifier(): string;
        set globalClusterIdentifier(value: string);
        get globalClusterIdentifierInput(): string | undefined;
        private _instanceArns?;
        get instanceArns(): {
            [key: string]: string;
        };
        set instanceArns(value: {
            [key: string]: string;
        });
        get instanceArnsInput(): {
            [key: string]: string;
        } | undefined;
        private _regionDatabaseClusterArns?;
        get regionDatabaseClusterArns(): {
            [key: string]: string;
        };
        set regionDatabaseClusterArns(value: {
            [key: string]: string;
        });
        get regionDatabaseClusterArnsInput(): {
            [key: string]: string;
        } | undefined;
        private _timeoutMinutes?;
        get timeoutMinutes(): number;
        set timeoutMinutes(value: number);
        resetTimeoutMinutes(): void;
        get timeoutMinutesInput(): number | undefined;
    }
    class WorkflowStepParallelConfigStepAuroraProvisionedScalingConfigPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepParallelConfigStepAuroraProvisionedScalingConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepParallelConfigStepAuroraProvisionedScalingConfigPropertyOutputReference;
    }
    interface WorkflowStepParallelConfigStepAuroraServerlessScalingConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#cross_account_role TfPlan#cross_account_role}
        */
        readonly crossAccountRole?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#external_id TfPlan#external_id}
        */
        readonly externalId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#global_cluster_identifier TfPlan#global_cluster_identifier}
        */
        readonly globalClusterIdentifier: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#region_database_cluster_arns TfPlan#region_database_cluster_arns}
        */
        readonly regionDatabaseClusterArns: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#target_percent TfPlan#target_percent}
        */
        readonly targetPercent?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#timeout_minutes TfPlan#timeout_minutes}
        */
        readonly timeoutMinutes?: number;
    }
    class WorkflowStepParallelConfigStepAuroraServerlessScalingConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepParallelConfigStepAuroraServerlessScalingConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepParallelConfigStepAuroraServerlessScalingConfigProperty | cdktn.IResolvable | undefined);
        private _crossAccountRole?;
        get crossAccountRole(): string;
        set crossAccountRole(value: string);
        resetCrossAccountRole(): void;
        get crossAccountRoleInput(): string | undefined;
        private _externalId?;
        get externalId(): string;
        set externalId(value: string);
        resetExternalId(): void;
        get externalIdInput(): string | undefined;
        private _globalClusterIdentifier?;
        get globalClusterIdentifier(): string;
        set globalClusterIdentifier(value: string);
        get globalClusterIdentifierInput(): string | undefined;
        private _regionDatabaseClusterArns?;
        get regionDatabaseClusterArns(): {
            [key: string]: string;
        };
        set regionDatabaseClusterArns(value: {
            [key: string]: string;
        });
        get regionDatabaseClusterArnsInput(): {
            [key: string]: string;
        } | undefined;
        private _targetPercent?;
        get targetPercent(): number;
        set targetPercent(value: number);
        resetTargetPercent(): void;
        get targetPercentInput(): number | undefined;
        private _timeoutMinutes?;
        get timeoutMinutes(): number;
        set timeoutMinutes(value: number);
        resetTimeoutMinutes(): void;
        get timeoutMinutesInput(): number | undefined;
    }
    class WorkflowStepParallelConfigStepAuroraServerlessScalingConfigPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepParallelConfigStepAuroraServerlessScalingConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepParallelConfigStepAuroraServerlessScalingConfigPropertyOutputReference;
    }
    interface WorkflowStepParallelConfigStepCustomActionLambdaConfigLambdaProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#arn TfPlan#arn}
        */
        readonly arn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#cross_account_role TfPlan#cross_account_role}
        */
        readonly crossAccountRole?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#external_id TfPlan#external_id}
        */
        readonly externalId?: string;
    }
    class WorkflowStepParallelConfigStepCustomActionLambdaConfigLambdaPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepParallelConfigStepCustomActionLambdaConfigLambdaProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepParallelConfigStepCustomActionLambdaConfigLambdaProperty | cdktn.IResolvable | undefined);
        private _arn?;
        get arn(): string;
        set arn(value: string);
        get arnInput(): string | undefined;
        private _crossAccountRole?;
        get crossAccountRole(): string;
        set crossAccountRole(value: string);
        resetCrossAccountRole(): void;
        get crossAccountRoleInput(): string | undefined;
        private _externalId?;
        get externalId(): string;
        set externalId(value: string);
        resetExternalId(): void;
        get externalIdInput(): string | undefined;
    }
    class WorkflowStepParallelConfigStepCustomActionLambdaConfigLambdaPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepParallelConfigStepCustomActionLambdaConfigLambdaProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepParallelConfigStepCustomActionLambdaConfigLambdaPropertyOutputReference;
    }
    interface WorkflowStepParallelConfigStepCustomActionLambdaConfigUngracefulProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#behavior TfPlan#behavior}
        */
        readonly behavior: string;
    }
    class WorkflowStepParallelConfigStepCustomActionLambdaConfigUngracefulPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepParallelConfigStepCustomActionLambdaConfigUngracefulProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepParallelConfigStepCustomActionLambdaConfigUngracefulProperty | cdktn.IResolvable | undefined);
        private _behavior?;
        get behavior(): string;
        set behavior(value: string);
        get behaviorInput(): string | undefined;
    }
    class WorkflowStepParallelConfigStepCustomActionLambdaConfigUngracefulPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepParallelConfigStepCustomActionLambdaConfigUngracefulProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepParallelConfigStepCustomActionLambdaConfigUngracefulPropertyOutputReference;
    }
    interface WorkflowStepParallelConfigStepCustomActionLambdaConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#region_to_run TfPlan#region_to_run}
        */
        readonly regionToRun: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#retry_interval_minutes TfPlan#retry_interval_minutes}
        */
        readonly retryIntervalMinutes: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#timeout_minutes TfPlan#timeout_minutes}
        */
        readonly timeoutMinutes?: number;
        /**
        * lambda block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#lambda TfPlan#lambda}
        */
        readonly lambda?: WorkflowStepParallelConfigStepCustomActionLambdaConfigLambdaProperty[] | cdktn.IResolvable;
        /**
        * ungraceful block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#ungraceful TfPlan#ungraceful}
        */
        readonly ungraceful?: WorkflowStepParallelConfigStepCustomActionLambdaConfigUngracefulProperty[] | cdktn.IResolvable;
    }
    class WorkflowStepParallelConfigStepCustomActionLambdaConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepParallelConfigStepCustomActionLambdaConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepParallelConfigStepCustomActionLambdaConfigProperty | cdktn.IResolvable | undefined);
        private _regionToRun?;
        get regionToRun(): string;
        set regionToRun(value: string);
        get regionToRunInput(): string | undefined;
        private _retryIntervalMinutes?;
        get retryIntervalMinutes(): number;
        set retryIntervalMinutes(value: number);
        get retryIntervalMinutesInput(): number | undefined;
        private _timeoutMinutes?;
        get timeoutMinutes(): number;
        set timeoutMinutes(value: number);
        resetTimeoutMinutes(): void;
        get timeoutMinutesInput(): number | undefined;
        private _lambda;
        get lambda(): WorkflowStepParallelConfigStepCustomActionLambdaConfigLambdaPropertyList;
        putLambda(value: WorkflowStepParallelConfigStepCustomActionLambdaConfigLambdaProperty[] | cdktn.IResolvable): void;
        resetLambda(): void;
        get lambdaInput(): cdktn.IResolvable | WorkflowStepParallelConfigStepCustomActionLambdaConfigLambdaProperty[] | undefined;
        private _ungraceful;
        get ungraceful(): WorkflowStepParallelConfigStepCustomActionLambdaConfigUngracefulPropertyList;
        putUngraceful(value: WorkflowStepParallelConfigStepCustomActionLambdaConfigUngracefulProperty[] | cdktn.IResolvable): void;
        resetUngraceful(): void;
        get ungracefulInput(): cdktn.IResolvable | WorkflowStepParallelConfigStepCustomActionLambdaConfigUngracefulProperty[] | undefined;
    }
    class WorkflowStepParallelConfigStepCustomActionLambdaConfigPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepParallelConfigStepCustomActionLambdaConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepParallelConfigStepCustomActionLambdaConfigPropertyOutputReference;
    }
    interface WorkflowStepParallelConfigStepDocumentDbConfigUngracefulProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#ungraceful TfPlan#ungraceful}
        */
        readonly ungraceful: string;
    }
    class WorkflowStepParallelConfigStepDocumentDbConfigUngracefulPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepParallelConfigStepDocumentDbConfigUngracefulProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepParallelConfigStepDocumentDbConfigUngracefulProperty | cdktn.IResolvable | undefined);
        private _ungraceful?;
        get ungraceful(): string;
        set ungraceful(value: string);
        get ungracefulInput(): string | undefined;
    }
    class WorkflowStepParallelConfigStepDocumentDbConfigUngracefulPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepParallelConfigStepDocumentDbConfigUngracefulProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepParallelConfigStepDocumentDbConfigUngracefulPropertyOutputReference;
    }
    interface WorkflowStepParallelConfigStepDocumentDbConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#behavior TfPlan#behavior}
        */
        readonly behavior: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#cross_account_role TfPlan#cross_account_role}
        */
        readonly crossAccountRole?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#database_cluster_arns TfPlan#database_cluster_arns}
        */
        readonly databaseClusterArns: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#external_id TfPlan#external_id}
        */
        readonly externalId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#global_cluster_identifier TfPlan#global_cluster_identifier}
        */
        readonly globalClusterIdentifier: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#timeout_minutes TfPlan#timeout_minutes}
        */
        readonly timeoutMinutes?: number;
        /**
        * ungraceful block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#ungraceful TfPlan#ungraceful}
        */
        readonly ungraceful?: WorkflowStepParallelConfigStepDocumentDbConfigUngracefulProperty[] | cdktn.IResolvable;
    }
    class WorkflowStepParallelConfigStepDocumentDbConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepParallelConfigStepDocumentDbConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepParallelConfigStepDocumentDbConfigProperty | cdktn.IResolvable | undefined);
        private _behavior?;
        get behavior(): string;
        set behavior(value: string);
        get behaviorInput(): string | undefined;
        private _crossAccountRole?;
        get crossAccountRole(): string;
        set crossAccountRole(value: string);
        resetCrossAccountRole(): void;
        get crossAccountRoleInput(): string | undefined;
        private _databaseClusterArns?;
        get databaseClusterArns(): string[];
        set databaseClusterArns(value: string[]);
        get databaseClusterArnsInput(): string[] | undefined;
        private _externalId?;
        get externalId(): string;
        set externalId(value: string);
        resetExternalId(): void;
        get externalIdInput(): string | undefined;
        private _globalClusterIdentifier?;
        get globalClusterIdentifier(): string;
        set globalClusterIdentifier(value: string);
        get globalClusterIdentifierInput(): string | undefined;
        private _timeoutMinutes?;
        get timeoutMinutes(): number;
        set timeoutMinutes(value: number);
        resetTimeoutMinutes(): void;
        get timeoutMinutesInput(): number | undefined;
        private _ungraceful;
        get ungraceful(): WorkflowStepParallelConfigStepDocumentDbConfigUngracefulPropertyList;
        putUngraceful(value: WorkflowStepParallelConfigStepDocumentDbConfigUngracefulProperty[] | cdktn.IResolvable): void;
        resetUngraceful(): void;
        get ungracefulInput(): cdktn.IResolvable | WorkflowStepParallelConfigStepDocumentDbConfigUngracefulProperty[] | undefined;
    }
    class WorkflowStepParallelConfigStepDocumentDbConfigPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepParallelConfigStepDocumentDbConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepParallelConfigStepDocumentDbConfigPropertyOutputReference;
    }
    interface WorkflowStepParallelConfigStepEc2AsgCapacityIncreaseConfigAsgProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#arn TfPlan#arn}
        */
        readonly arn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#cross_account_role TfPlan#cross_account_role}
        */
        readonly crossAccountRole?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#external_id TfPlan#external_id}
        */
        readonly externalId?: string;
    }
    class WorkflowStepParallelConfigStepEc2AsgCapacityIncreaseConfigAsgPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepParallelConfigStepEc2AsgCapacityIncreaseConfigAsgProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepParallelConfigStepEc2AsgCapacityIncreaseConfigAsgProperty | cdktn.IResolvable | undefined);
        private _arn?;
        get arn(): string;
        set arn(value: string);
        get arnInput(): string | undefined;
        private _crossAccountRole?;
        get crossAccountRole(): string;
        set crossAccountRole(value: string);
        resetCrossAccountRole(): void;
        get crossAccountRoleInput(): string | undefined;
        private _externalId?;
        get externalId(): string;
        set externalId(value: string);
        resetExternalId(): void;
        get externalIdInput(): string | undefined;
    }
    class WorkflowStepParallelConfigStepEc2AsgCapacityIncreaseConfigAsgPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepParallelConfigStepEc2AsgCapacityIncreaseConfigAsgProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepParallelConfigStepEc2AsgCapacityIncreaseConfigAsgPropertyOutputReference;
    }
    interface WorkflowStepParallelConfigStepEc2AsgCapacityIncreaseConfigUngracefulProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#minimum_success_percentage TfPlan#minimum_success_percentage}
        */
        readonly minimumSuccessPercentage: number;
    }
    class WorkflowStepParallelConfigStepEc2AsgCapacityIncreaseConfigUngracefulPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepParallelConfigStepEc2AsgCapacityIncreaseConfigUngracefulProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepParallelConfigStepEc2AsgCapacityIncreaseConfigUngracefulProperty | cdktn.IResolvable | undefined);
        private _minimumSuccessPercentage?;
        get minimumSuccessPercentage(): number;
        set minimumSuccessPercentage(value: number);
        get minimumSuccessPercentageInput(): number | undefined;
    }
    class WorkflowStepParallelConfigStepEc2AsgCapacityIncreaseConfigUngracefulPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepParallelConfigStepEc2AsgCapacityIncreaseConfigUngracefulProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepParallelConfigStepEc2AsgCapacityIncreaseConfigUngracefulPropertyOutputReference;
    }
    interface WorkflowStepParallelConfigStepEc2AsgCapacityIncreaseConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#capacity_monitoring_approach TfPlan#capacity_monitoring_approach}
        */
        readonly capacityMonitoringApproach: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#target_percent TfPlan#target_percent}
        */
        readonly targetPercent?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#timeout_minutes TfPlan#timeout_minutes}
        */
        readonly timeoutMinutes?: number;
        /**
        * asg block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#asg TfPlan#asg}
        */
        readonly asg?: WorkflowStepParallelConfigStepEc2AsgCapacityIncreaseConfigAsgProperty[] | cdktn.IResolvable;
        /**
        * ungraceful block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#ungraceful TfPlan#ungraceful}
        */
        readonly ungraceful?: WorkflowStepParallelConfigStepEc2AsgCapacityIncreaseConfigUngracefulProperty[] | cdktn.IResolvable;
    }
    class WorkflowStepParallelConfigStepEc2AsgCapacityIncreaseConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepParallelConfigStepEc2AsgCapacityIncreaseConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepParallelConfigStepEc2AsgCapacityIncreaseConfigProperty | cdktn.IResolvable | undefined);
        private _capacityMonitoringApproach?;
        get capacityMonitoringApproach(): string;
        set capacityMonitoringApproach(value: string);
        get capacityMonitoringApproachInput(): string | undefined;
        private _targetPercent?;
        get targetPercent(): number;
        set targetPercent(value: number);
        resetTargetPercent(): void;
        get targetPercentInput(): number | undefined;
        private _timeoutMinutes?;
        get timeoutMinutes(): number;
        set timeoutMinutes(value: number);
        resetTimeoutMinutes(): void;
        get timeoutMinutesInput(): number | undefined;
        private _asg;
        get asg(): WorkflowStepParallelConfigStepEc2AsgCapacityIncreaseConfigAsgPropertyList;
        putAsg(value: WorkflowStepParallelConfigStepEc2AsgCapacityIncreaseConfigAsgProperty[] | cdktn.IResolvable): void;
        resetAsg(): void;
        get asgInput(): cdktn.IResolvable | WorkflowStepParallelConfigStepEc2AsgCapacityIncreaseConfigAsgProperty[] | undefined;
        private _ungraceful;
        get ungraceful(): WorkflowStepParallelConfigStepEc2AsgCapacityIncreaseConfigUngracefulPropertyList;
        putUngraceful(value: WorkflowStepParallelConfigStepEc2AsgCapacityIncreaseConfigUngracefulProperty[] | cdktn.IResolvable): void;
        resetUngraceful(): void;
        get ungracefulInput(): cdktn.IResolvable | WorkflowStepParallelConfigStepEc2AsgCapacityIncreaseConfigUngracefulProperty[] | undefined;
    }
    class WorkflowStepParallelConfigStepEc2AsgCapacityIncreaseConfigPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepParallelConfigStepEc2AsgCapacityIncreaseConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepParallelConfigStepEc2AsgCapacityIncreaseConfigPropertyOutputReference;
    }
    interface WorkflowStepParallelConfigStepEcsCapacityIncreaseConfigServiceProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#cluster_arn TfPlan#cluster_arn}
        */
        readonly clusterArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#cross_account_role TfPlan#cross_account_role}
        */
        readonly crossAccountRole?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#external_id TfPlan#external_id}
        */
        readonly externalId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#service_arn TfPlan#service_arn}
        */
        readonly serviceArn: string;
    }
    class WorkflowStepParallelConfigStepEcsCapacityIncreaseConfigServicePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepParallelConfigStepEcsCapacityIncreaseConfigServiceProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepParallelConfigStepEcsCapacityIncreaseConfigServiceProperty | cdktn.IResolvable | undefined);
        private _clusterArn?;
        get clusterArn(): string;
        set clusterArn(value: string);
        get clusterArnInput(): string | undefined;
        private _crossAccountRole?;
        get crossAccountRole(): string;
        set crossAccountRole(value: string);
        resetCrossAccountRole(): void;
        get crossAccountRoleInput(): string | undefined;
        private _externalId?;
        get externalId(): string;
        set externalId(value: string);
        resetExternalId(): void;
        get externalIdInput(): string | undefined;
        private _serviceArn?;
        get serviceArn(): string;
        set serviceArn(value: string);
        get serviceArnInput(): string | undefined;
    }
    class WorkflowStepParallelConfigStepEcsCapacityIncreaseConfigServicePropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepParallelConfigStepEcsCapacityIncreaseConfigServiceProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepParallelConfigStepEcsCapacityIncreaseConfigServicePropertyOutputReference;
    }
    interface WorkflowStepParallelConfigStepEcsCapacityIncreaseConfigUngracefulProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#minimum_success_percentage TfPlan#minimum_success_percentage}
        */
        readonly minimumSuccessPercentage: number;
    }
    class WorkflowStepParallelConfigStepEcsCapacityIncreaseConfigUngracefulPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepParallelConfigStepEcsCapacityIncreaseConfigUngracefulProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepParallelConfigStepEcsCapacityIncreaseConfigUngracefulProperty | cdktn.IResolvable | undefined);
        private _minimumSuccessPercentage?;
        get minimumSuccessPercentage(): number;
        set minimumSuccessPercentage(value: number);
        get minimumSuccessPercentageInput(): number | undefined;
    }
    class WorkflowStepParallelConfigStepEcsCapacityIncreaseConfigUngracefulPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepParallelConfigStepEcsCapacityIncreaseConfigUngracefulProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepParallelConfigStepEcsCapacityIncreaseConfigUngracefulPropertyOutputReference;
    }
    interface WorkflowStepParallelConfigStepEcsCapacityIncreaseConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#capacity_monitoring_approach TfPlan#capacity_monitoring_approach}
        */
        readonly capacityMonitoringApproach: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#target_percent TfPlan#target_percent}
        */
        readonly targetPercent?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#timeout_minutes TfPlan#timeout_minutes}
        */
        readonly timeoutMinutes?: number;
        /**
        * service block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#service TfPlan#service}
        */
        readonly service?: WorkflowStepParallelConfigStepEcsCapacityIncreaseConfigServiceProperty[] | cdktn.IResolvable;
        /**
        * ungraceful block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#ungraceful TfPlan#ungraceful}
        */
        readonly ungraceful?: WorkflowStepParallelConfigStepEcsCapacityIncreaseConfigUngracefulProperty[] | cdktn.IResolvable;
    }
    class WorkflowStepParallelConfigStepEcsCapacityIncreaseConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepParallelConfigStepEcsCapacityIncreaseConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepParallelConfigStepEcsCapacityIncreaseConfigProperty | cdktn.IResolvable | undefined);
        private _capacityMonitoringApproach?;
        get capacityMonitoringApproach(): string;
        set capacityMonitoringApproach(value: string);
        get capacityMonitoringApproachInput(): string | undefined;
        private _targetPercent?;
        get targetPercent(): number;
        set targetPercent(value: number);
        resetTargetPercent(): void;
        get targetPercentInput(): number | undefined;
        private _timeoutMinutes?;
        get timeoutMinutes(): number;
        set timeoutMinutes(value: number);
        resetTimeoutMinutes(): void;
        get timeoutMinutesInput(): number | undefined;
        private _service;
        get service(): WorkflowStepParallelConfigStepEcsCapacityIncreaseConfigServicePropertyList;
        putService(value: WorkflowStepParallelConfigStepEcsCapacityIncreaseConfigServiceProperty[] | cdktn.IResolvable): void;
        resetService(): void;
        get serviceInput(): cdktn.IResolvable | WorkflowStepParallelConfigStepEcsCapacityIncreaseConfigServiceProperty[] | undefined;
        private _ungraceful;
        get ungraceful(): WorkflowStepParallelConfigStepEcsCapacityIncreaseConfigUngracefulPropertyList;
        putUngraceful(value: WorkflowStepParallelConfigStepEcsCapacityIncreaseConfigUngracefulProperty[] | cdktn.IResolvable): void;
        resetUngraceful(): void;
        get ungracefulInput(): cdktn.IResolvable | WorkflowStepParallelConfigStepEcsCapacityIncreaseConfigUngracefulProperty[] | undefined;
    }
    class WorkflowStepParallelConfigStepEcsCapacityIncreaseConfigPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepParallelConfigStepEcsCapacityIncreaseConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepParallelConfigStepEcsCapacityIncreaseConfigPropertyOutputReference;
    }
    interface WorkflowStepParallelConfigStepEksResourceScalingConfigEksClustersProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#cluster_arn TfPlan#cluster_arn}
        */
        readonly clusterArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#cross_account_role TfPlan#cross_account_role}
        */
        readonly crossAccountRole?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#external_id TfPlan#external_id}
        */
        readonly externalId?: string;
    }
    class WorkflowStepParallelConfigStepEksResourceScalingConfigEksClustersPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepParallelConfigStepEksResourceScalingConfigEksClustersProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepParallelConfigStepEksResourceScalingConfigEksClustersProperty | cdktn.IResolvable | undefined);
        private _clusterArn?;
        get clusterArn(): string;
        set clusterArn(value: string);
        get clusterArnInput(): string | undefined;
        private _crossAccountRole?;
        get crossAccountRole(): string;
        set crossAccountRole(value: string);
        resetCrossAccountRole(): void;
        get crossAccountRoleInput(): string | undefined;
        private _externalId?;
        get externalId(): string;
        set externalId(value: string);
        resetExternalId(): void;
        get externalIdInput(): string | undefined;
    }
    class WorkflowStepParallelConfigStepEksResourceScalingConfigEksClustersPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepParallelConfigStepEksResourceScalingConfigEksClustersProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepParallelConfigStepEksResourceScalingConfigEksClustersPropertyOutputReference;
    }
    interface WorkflowStepParallelConfigStepEksResourceScalingConfigKubernetesResourceTypeProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#api_version TfPlan#api_version}
        */
        readonly apiVersion: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#kind TfPlan#kind}
        */
        readonly kind: string;
    }
    class WorkflowStepParallelConfigStepEksResourceScalingConfigKubernetesResourceTypePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepParallelConfigStepEksResourceScalingConfigKubernetesResourceTypeProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepParallelConfigStepEksResourceScalingConfigKubernetesResourceTypeProperty | cdktn.IResolvable | undefined);
        private _apiVersion?;
        get apiVersion(): string;
        set apiVersion(value: string);
        get apiVersionInput(): string | undefined;
        private _kind?;
        get kind(): string;
        set kind(value: string);
        get kindInput(): string | undefined;
    }
    class WorkflowStepParallelConfigStepEksResourceScalingConfigKubernetesResourceTypePropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepParallelConfigStepEksResourceScalingConfigKubernetesResourceTypeProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepParallelConfigStepEksResourceScalingConfigKubernetesResourceTypePropertyOutputReference;
    }
    interface WorkflowStepParallelConfigStepEksResourceScalingConfigScalingResourcesResourcesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#hpa_name TfPlan#hpa_name}
        */
        readonly hpaName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#name TfPlan#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#namespace TfPlan#namespace}
        */
        readonly namespace: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#resource_name TfPlan#resource_name}
        */
        readonly resourceName: string;
    }
    class WorkflowStepParallelConfigStepEksResourceScalingConfigScalingResourcesResourcesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepParallelConfigStepEksResourceScalingConfigScalingResourcesResourcesProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepParallelConfigStepEksResourceScalingConfigScalingResourcesResourcesProperty | cdktn.IResolvable | undefined);
        private _hpaName?;
        get hpaName(): string;
        set hpaName(value: string);
        resetHpaName(): void;
        get hpaNameInput(): string | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _namespace?;
        get namespace(): string;
        set namespace(value: string);
        get namespaceInput(): string | undefined;
        private _resourceName?;
        get resourceName(): string;
        set resourceName(value: string);
        get resourceNameInput(): string | undefined;
    }
    class WorkflowStepParallelConfigStepEksResourceScalingConfigScalingResourcesResourcesPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepParallelConfigStepEksResourceScalingConfigScalingResourcesResourcesProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepParallelConfigStepEksResourceScalingConfigScalingResourcesResourcesPropertyOutputReference;
    }
    interface WorkflowStepParallelConfigStepEksResourceScalingConfigScalingResourcesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#namespace TfPlan#namespace}
        */
        readonly namespace: string;
        /**
        * resources block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#resources TfPlan#resources}
        */
        readonly resources?: WorkflowStepParallelConfigStepEksResourceScalingConfigScalingResourcesResourcesProperty[] | cdktn.IResolvable;
    }
    class WorkflowStepParallelConfigStepEksResourceScalingConfigScalingResourcesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepParallelConfigStepEksResourceScalingConfigScalingResourcesProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepParallelConfigStepEksResourceScalingConfigScalingResourcesProperty | cdktn.IResolvable | undefined);
        private _namespace?;
        get namespace(): string;
        set namespace(value: string);
        get namespaceInput(): string | undefined;
        private _resources;
        get resources(): WorkflowStepParallelConfigStepEksResourceScalingConfigScalingResourcesResourcesPropertyList;
        putResources(value: WorkflowStepParallelConfigStepEksResourceScalingConfigScalingResourcesResourcesProperty[] | cdktn.IResolvable): void;
        resetResources(): void;
        get resourcesInput(): cdktn.IResolvable | WorkflowStepParallelConfigStepEksResourceScalingConfigScalingResourcesResourcesProperty[] | undefined;
    }
    class WorkflowStepParallelConfigStepEksResourceScalingConfigScalingResourcesPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepParallelConfigStepEksResourceScalingConfigScalingResourcesProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepParallelConfigStepEksResourceScalingConfigScalingResourcesPropertyOutputReference;
    }
    interface WorkflowStepParallelConfigStepEksResourceScalingConfigUngracefulProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#minimum_success_percentage TfPlan#minimum_success_percentage}
        */
        readonly minimumSuccessPercentage: number;
    }
    class WorkflowStepParallelConfigStepEksResourceScalingConfigUngracefulPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepParallelConfigStepEksResourceScalingConfigUngracefulProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepParallelConfigStepEksResourceScalingConfigUngracefulProperty | cdktn.IResolvable | undefined);
        private _minimumSuccessPercentage?;
        get minimumSuccessPercentage(): number;
        set minimumSuccessPercentage(value: number);
        get minimumSuccessPercentageInput(): number | undefined;
    }
    class WorkflowStepParallelConfigStepEksResourceScalingConfigUngracefulPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepParallelConfigStepEksResourceScalingConfigUngracefulProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepParallelConfigStepEksResourceScalingConfigUngracefulPropertyOutputReference;
    }
    interface WorkflowStepParallelConfigStepEksResourceScalingConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#capacity_monitoring_approach TfPlan#capacity_monitoring_approach}
        */
        readonly capacityMonitoringApproach: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#target_percent TfPlan#target_percent}
        */
        readonly targetPercent: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#timeout_minutes TfPlan#timeout_minutes}
        */
        readonly timeoutMinutes?: number;
        /**
        * eks_clusters block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#eks_clusters TfPlan#eks_clusters}
        */
        readonly eksClusters?: WorkflowStepParallelConfigStepEksResourceScalingConfigEksClustersProperty[] | cdktn.IResolvable;
        /**
        * kubernetes_resource_type block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#kubernetes_resource_type TfPlan#kubernetes_resource_type}
        */
        readonly kubernetesResourceType?: WorkflowStepParallelConfigStepEksResourceScalingConfigKubernetesResourceTypeProperty[] | cdktn.IResolvable;
        /**
        * scaling_resources block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#scaling_resources TfPlan#scaling_resources}
        */
        readonly scalingResources?: WorkflowStepParallelConfigStepEksResourceScalingConfigScalingResourcesProperty[] | cdktn.IResolvable;
        /**
        * ungraceful block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#ungraceful TfPlan#ungraceful}
        */
        readonly ungraceful?: WorkflowStepParallelConfigStepEksResourceScalingConfigUngracefulProperty[] | cdktn.IResolvable;
    }
    class WorkflowStepParallelConfigStepEksResourceScalingConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepParallelConfigStepEksResourceScalingConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepParallelConfigStepEksResourceScalingConfigProperty | cdktn.IResolvable | undefined);
        private _capacityMonitoringApproach?;
        get capacityMonitoringApproach(): string;
        set capacityMonitoringApproach(value: string);
        get capacityMonitoringApproachInput(): string | undefined;
        private _targetPercent?;
        get targetPercent(): number;
        set targetPercent(value: number);
        get targetPercentInput(): number | undefined;
        private _timeoutMinutes?;
        get timeoutMinutes(): number;
        set timeoutMinutes(value: number);
        resetTimeoutMinutes(): void;
        get timeoutMinutesInput(): number | undefined;
        private _eksClusters;
        get eksClusters(): WorkflowStepParallelConfigStepEksResourceScalingConfigEksClustersPropertyList;
        putEksClusters(value: WorkflowStepParallelConfigStepEksResourceScalingConfigEksClustersProperty[] | cdktn.IResolvable): void;
        resetEksClusters(): void;
        get eksClustersInput(): cdktn.IResolvable | WorkflowStepParallelConfigStepEksResourceScalingConfigEksClustersProperty[] | undefined;
        private _kubernetesResourceType;
        get kubernetesResourceType(): WorkflowStepParallelConfigStepEksResourceScalingConfigKubernetesResourceTypePropertyList;
        putKubernetesResourceType(value: WorkflowStepParallelConfigStepEksResourceScalingConfigKubernetesResourceTypeProperty[] | cdktn.IResolvable): void;
        resetKubernetesResourceType(): void;
        get kubernetesResourceTypeInput(): cdktn.IResolvable | WorkflowStepParallelConfigStepEksResourceScalingConfigKubernetesResourceTypeProperty[] | undefined;
        private _scalingResources;
        get scalingResources(): WorkflowStepParallelConfigStepEksResourceScalingConfigScalingResourcesPropertyList;
        putScalingResources(value: WorkflowStepParallelConfigStepEksResourceScalingConfigScalingResourcesProperty[] | cdktn.IResolvable): void;
        resetScalingResources(): void;
        get scalingResourcesInput(): cdktn.IResolvable | WorkflowStepParallelConfigStepEksResourceScalingConfigScalingResourcesProperty[] | undefined;
        private _ungraceful;
        get ungraceful(): WorkflowStepParallelConfigStepEksResourceScalingConfigUngracefulPropertyList;
        putUngraceful(value: WorkflowStepParallelConfigStepEksResourceScalingConfigUngracefulProperty[] | cdktn.IResolvable): void;
        resetUngraceful(): void;
        get ungracefulInput(): cdktn.IResolvable | WorkflowStepParallelConfigStepEksResourceScalingConfigUngracefulProperty[] | undefined;
    }
    class WorkflowStepParallelConfigStepEksResourceScalingConfigPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepParallelConfigStepEksResourceScalingConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepParallelConfigStepEksResourceScalingConfigPropertyOutputReference;
    }
    interface WorkflowStepParallelConfigStepExecutionApprovalConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#approval_role TfPlan#approval_role}
        */
        readonly approvalRole: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#timeout_minutes TfPlan#timeout_minutes}
        */
        readonly timeoutMinutes?: number;
    }
    class WorkflowStepParallelConfigStepExecutionApprovalConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepParallelConfigStepExecutionApprovalConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepParallelConfigStepExecutionApprovalConfigProperty | cdktn.IResolvable | undefined);
        private _approvalRole?;
        get approvalRole(): string;
        set approvalRole(value: string);
        get approvalRoleInput(): string | undefined;
        private _timeoutMinutes?;
        get timeoutMinutes(): number;
        set timeoutMinutes(value: number);
        resetTimeoutMinutes(): void;
        get timeoutMinutesInput(): number | undefined;
    }
    class WorkflowStepParallelConfigStepExecutionApprovalConfigPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepParallelConfigStepExecutionApprovalConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepParallelConfigStepExecutionApprovalConfigPropertyOutputReference;
    }
    interface WorkflowStepParallelConfigStepGlobalAuroraConfigUngracefulProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#ungraceful TfPlan#ungraceful}
        */
        readonly ungraceful: string;
    }
    class WorkflowStepParallelConfigStepGlobalAuroraConfigUngracefulPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepParallelConfigStepGlobalAuroraConfigUngracefulProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepParallelConfigStepGlobalAuroraConfigUngracefulProperty | cdktn.IResolvable | undefined);
        private _ungraceful?;
        get ungraceful(): string;
        set ungraceful(value: string);
        get ungracefulInput(): string | undefined;
    }
    class WorkflowStepParallelConfigStepGlobalAuroraConfigUngracefulPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepParallelConfigStepGlobalAuroraConfigUngracefulProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepParallelConfigStepGlobalAuroraConfigUngracefulPropertyOutputReference;
    }
    interface WorkflowStepParallelConfigStepGlobalAuroraConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#behavior TfPlan#behavior}
        */
        readonly behavior: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#cross_account_role TfPlan#cross_account_role}
        */
        readonly crossAccountRole?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#database_cluster_arns TfPlan#database_cluster_arns}
        */
        readonly databaseClusterArns: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#external_id TfPlan#external_id}
        */
        readonly externalId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#global_cluster_identifier TfPlan#global_cluster_identifier}
        */
        readonly globalClusterIdentifier: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#timeout_minutes TfPlan#timeout_minutes}
        */
        readonly timeoutMinutes?: number;
        /**
        * ungraceful block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#ungraceful TfPlan#ungraceful}
        */
        readonly ungraceful?: WorkflowStepParallelConfigStepGlobalAuroraConfigUngracefulProperty[] | cdktn.IResolvable;
    }
    class WorkflowStepParallelConfigStepGlobalAuroraConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepParallelConfigStepGlobalAuroraConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepParallelConfigStepGlobalAuroraConfigProperty | cdktn.IResolvable | undefined);
        private _behavior?;
        get behavior(): string;
        set behavior(value: string);
        get behaviorInput(): string | undefined;
        private _crossAccountRole?;
        get crossAccountRole(): string;
        set crossAccountRole(value: string);
        resetCrossAccountRole(): void;
        get crossAccountRoleInput(): string | undefined;
        private _databaseClusterArns?;
        get databaseClusterArns(): string[];
        set databaseClusterArns(value: string[]);
        get databaseClusterArnsInput(): string[] | undefined;
        private _externalId?;
        get externalId(): string;
        set externalId(value: string);
        resetExternalId(): void;
        get externalIdInput(): string | undefined;
        private _globalClusterIdentifier?;
        get globalClusterIdentifier(): string;
        set globalClusterIdentifier(value: string);
        get globalClusterIdentifierInput(): string | undefined;
        private _timeoutMinutes?;
        get timeoutMinutes(): number;
        set timeoutMinutes(value: number);
        resetTimeoutMinutes(): void;
        get timeoutMinutesInput(): number | undefined;
        private _ungraceful;
        get ungraceful(): WorkflowStepParallelConfigStepGlobalAuroraConfigUngracefulPropertyList;
        putUngraceful(value: WorkflowStepParallelConfigStepGlobalAuroraConfigUngracefulProperty[] | cdktn.IResolvable): void;
        resetUngraceful(): void;
        get ungracefulInput(): cdktn.IResolvable | WorkflowStepParallelConfigStepGlobalAuroraConfigUngracefulProperty[] | undefined;
    }
    class WorkflowStepParallelConfigStepGlobalAuroraConfigPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepParallelConfigStepGlobalAuroraConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepParallelConfigStepGlobalAuroraConfigPropertyOutputReference;
    }
    interface WorkflowStepParallelConfigStepLambdaEventSourceMappingConfigRegionEventSourceMappingProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#arn TfPlan#arn}
        */
        readonly arn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#cross_account_role TfPlan#cross_account_role}
        */
        readonly crossAccountRole?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#external_id TfPlan#external_id}
        */
        readonly externalId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#region TfPlan#region}
        */
        readonly region: string;
    }
    class WorkflowStepParallelConfigStepLambdaEventSourceMappingConfigRegionEventSourceMappingPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepParallelConfigStepLambdaEventSourceMappingConfigRegionEventSourceMappingProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepParallelConfigStepLambdaEventSourceMappingConfigRegionEventSourceMappingProperty | cdktn.IResolvable | undefined);
        private _arn?;
        get arn(): string;
        set arn(value: string);
        get arnInput(): string | undefined;
        private _crossAccountRole?;
        get crossAccountRole(): string;
        set crossAccountRole(value: string);
        resetCrossAccountRole(): void;
        get crossAccountRoleInput(): string | undefined;
        private _externalId?;
        get externalId(): string;
        set externalId(value: string);
        resetExternalId(): void;
        get externalIdInput(): string | undefined;
        private _region?;
        get region(): string;
        set region(value: string);
        get regionInput(): string | undefined;
    }
    class WorkflowStepParallelConfigStepLambdaEventSourceMappingConfigRegionEventSourceMappingPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepParallelConfigStepLambdaEventSourceMappingConfigRegionEventSourceMappingProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepParallelConfigStepLambdaEventSourceMappingConfigRegionEventSourceMappingPropertyOutputReference;
    }
    interface WorkflowStepParallelConfigStepLambdaEventSourceMappingConfigUngracefulProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#behavior TfPlan#behavior}
        */
        readonly behavior: string;
    }
    class WorkflowStepParallelConfigStepLambdaEventSourceMappingConfigUngracefulPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepParallelConfigStepLambdaEventSourceMappingConfigUngracefulProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepParallelConfigStepLambdaEventSourceMappingConfigUngracefulProperty | cdktn.IResolvable | undefined);
        private _behavior?;
        get behavior(): string;
        set behavior(value: string);
        get behaviorInput(): string | undefined;
    }
    class WorkflowStepParallelConfigStepLambdaEventSourceMappingConfigUngracefulPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepParallelConfigStepLambdaEventSourceMappingConfigUngracefulProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepParallelConfigStepLambdaEventSourceMappingConfigUngracefulPropertyOutputReference;
    }
    interface WorkflowStepParallelConfigStepLambdaEventSourceMappingConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#action TfPlan#action}
        */
        readonly action: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#timeout_minutes TfPlan#timeout_minutes}
        */
        readonly timeoutMinutes?: number;
        /**
        * region_event_source_mapping block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#region_event_source_mapping TfPlan#region_event_source_mapping}
        */
        readonly regionEventSourceMapping?: WorkflowStepParallelConfigStepLambdaEventSourceMappingConfigRegionEventSourceMappingProperty[] | cdktn.IResolvable;
        /**
        * ungraceful block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#ungraceful TfPlan#ungraceful}
        */
        readonly ungraceful?: WorkflowStepParallelConfigStepLambdaEventSourceMappingConfigUngracefulProperty[] | cdktn.IResolvable;
    }
    class WorkflowStepParallelConfigStepLambdaEventSourceMappingConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepParallelConfigStepLambdaEventSourceMappingConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepParallelConfigStepLambdaEventSourceMappingConfigProperty | cdktn.IResolvable | undefined);
        private _action?;
        get action(): string;
        set action(value: string);
        get actionInput(): string | undefined;
        private _timeoutMinutes?;
        get timeoutMinutes(): number;
        set timeoutMinutes(value: number);
        resetTimeoutMinutes(): void;
        get timeoutMinutesInput(): number | undefined;
        private _regionEventSourceMapping;
        get regionEventSourceMapping(): WorkflowStepParallelConfigStepLambdaEventSourceMappingConfigRegionEventSourceMappingPropertyList;
        putRegionEventSourceMapping(value: WorkflowStepParallelConfigStepLambdaEventSourceMappingConfigRegionEventSourceMappingProperty[] | cdktn.IResolvable): void;
        resetRegionEventSourceMapping(): void;
        get regionEventSourceMappingInput(): cdktn.IResolvable | WorkflowStepParallelConfigStepLambdaEventSourceMappingConfigRegionEventSourceMappingProperty[] | undefined;
        private _ungraceful;
        get ungraceful(): WorkflowStepParallelConfigStepLambdaEventSourceMappingConfigUngracefulPropertyList;
        putUngraceful(value: WorkflowStepParallelConfigStepLambdaEventSourceMappingConfigUngracefulProperty[] | cdktn.IResolvable): void;
        resetUngraceful(): void;
        get ungracefulInput(): cdktn.IResolvable | WorkflowStepParallelConfigStepLambdaEventSourceMappingConfigUngracefulProperty[] | undefined;
    }
    class WorkflowStepParallelConfigStepLambdaEventSourceMappingConfigPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepParallelConfigStepLambdaEventSourceMappingConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepParallelConfigStepLambdaEventSourceMappingConfigPropertyOutputReference;
    }
    interface WorkflowStepParallelConfigStepNeptuneGlobalDatabaseConfigUngracefulProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#ungraceful TfPlan#ungraceful}
        */
        readonly ungraceful: string;
    }
    class WorkflowStepParallelConfigStepNeptuneGlobalDatabaseConfigUngracefulPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepParallelConfigStepNeptuneGlobalDatabaseConfigUngracefulProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepParallelConfigStepNeptuneGlobalDatabaseConfigUngracefulProperty | cdktn.IResolvable | undefined);
        private _ungraceful?;
        get ungraceful(): string;
        set ungraceful(value: string);
        get ungracefulInput(): string | undefined;
    }
    class WorkflowStepParallelConfigStepNeptuneGlobalDatabaseConfigUngracefulPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepParallelConfigStepNeptuneGlobalDatabaseConfigUngracefulProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepParallelConfigStepNeptuneGlobalDatabaseConfigUngracefulPropertyOutputReference;
    }
    interface WorkflowStepParallelConfigStepNeptuneGlobalDatabaseConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#behavior TfPlan#behavior}
        */
        readonly behavior: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#cross_account_role TfPlan#cross_account_role}
        */
        readonly crossAccountRole?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#external_id TfPlan#external_id}
        */
        readonly externalId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#global_cluster_identifier TfPlan#global_cluster_identifier}
        */
        readonly globalClusterIdentifier: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#region_database_cluster_arns TfPlan#region_database_cluster_arns}
        */
        readonly regionDatabaseClusterArns: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#timeout_minutes TfPlan#timeout_minutes}
        */
        readonly timeoutMinutes?: number;
        /**
        * ungraceful block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#ungraceful TfPlan#ungraceful}
        */
        readonly ungraceful?: WorkflowStepParallelConfigStepNeptuneGlobalDatabaseConfigUngracefulProperty[] | cdktn.IResolvable;
    }
    class WorkflowStepParallelConfigStepNeptuneGlobalDatabaseConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepParallelConfigStepNeptuneGlobalDatabaseConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepParallelConfigStepNeptuneGlobalDatabaseConfigProperty | cdktn.IResolvable | undefined);
        private _behavior?;
        get behavior(): string;
        set behavior(value: string);
        get behaviorInput(): string | undefined;
        private _crossAccountRole?;
        get crossAccountRole(): string;
        set crossAccountRole(value: string);
        resetCrossAccountRole(): void;
        get crossAccountRoleInput(): string | undefined;
        private _externalId?;
        get externalId(): string;
        set externalId(value: string);
        resetExternalId(): void;
        get externalIdInput(): string | undefined;
        private _globalClusterIdentifier?;
        get globalClusterIdentifier(): string;
        set globalClusterIdentifier(value: string);
        get globalClusterIdentifierInput(): string | undefined;
        private _regionDatabaseClusterArns?;
        get regionDatabaseClusterArns(): {
            [key: string]: string;
        };
        set regionDatabaseClusterArns(value: {
            [key: string]: string;
        });
        get regionDatabaseClusterArnsInput(): {
            [key: string]: string;
        } | undefined;
        private _timeoutMinutes?;
        get timeoutMinutes(): number;
        set timeoutMinutes(value: number);
        resetTimeoutMinutes(): void;
        get timeoutMinutesInput(): number | undefined;
        private _ungraceful;
        get ungraceful(): WorkflowStepParallelConfigStepNeptuneGlobalDatabaseConfigUngracefulPropertyList;
        putUngraceful(value: WorkflowStepParallelConfigStepNeptuneGlobalDatabaseConfigUngracefulProperty[] | cdktn.IResolvable): void;
        resetUngraceful(): void;
        get ungracefulInput(): cdktn.IResolvable | WorkflowStepParallelConfigStepNeptuneGlobalDatabaseConfigUngracefulProperty[] | undefined;
    }
    class WorkflowStepParallelConfigStepNeptuneGlobalDatabaseConfigPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepParallelConfigStepNeptuneGlobalDatabaseConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepParallelConfigStepNeptuneGlobalDatabaseConfigPropertyOutputReference;
    }
    interface WorkflowStepParallelConfigStepRdsCreateCrossRegionReadReplicaConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#cross_account_role TfPlan#cross_account_role}
        */
        readonly crossAccountRole?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#db_instance_arn_map TfPlan#db_instance_arn_map}
        */
        readonly dbInstanceArnMap: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#external_id TfPlan#external_id}
        */
        readonly externalId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#timeout_minutes TfPlan#timeout_minutes}
        */
        readonly timeoutMinutes?: number;
    }
    class WorkflowStepParallelConfigStepRdsCreateCrossRegionReadReplicaConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepParallelConfigStepRdsCreateCrossRegionReadReplicaConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepParallelConfigStepRdsCreateCrossRegionReadReplicaConfigProperty | cdktn.IResolvable | undefined);
        private _crossAccountRole?;
        get crossAccountRole(): string;
        set crossAccountRole(value: string);
        resetCrossAccountRole(): void;
        get crossAccountRoleInput(): string | undefined;
        private _dbInstanceArnMap?;
        get dbInstanceArnMap(): {
            [key: string]: string;
        };
        set dbInstanceArnMap(value: {
            [key: string]: string;
        });
        get dbInstanceArnMapInput(): {
            [key: string]: string;
        } | undefined;
        private _externalId?;
        get externalId(): string;
        set externalId(value: string);
        resetExternalId(): void;
        get externalIdInput(): string | undefined;
        private _timeoutMinutes?;
        get timeoutMinutes(): number;
        set timeoutMinutes(value: number);
        resetTimeoutMinutes(): void;
        get timeoutMinutesInput(): number | undefined;
    }
    class WorkflowStepParallelConfigStepRdsCreateCrossRegionReadReplicaConfigPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepParallelConfigStepRdsCreateCrossRegionReadReplicaConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepParallelConfigStepRdsCreateCrossRegionReadReplicaConfigPropertyOutputReference;
    }
    interface WorkflowStepParallelConfigStepRdsPromoteReadReplicaConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#cross_account_role TfPlan#cross_account_role}
        */
        readonly crossAccountRole?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#db_instance_arn_map TfPlan#db_instance_arn_map}
        */
        readonly dbInstanceArnMap: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#external_id TfPlan#external_id}
        */
        readonly externalId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#timeout_minutes TfPlan#timeout_minutes}
        */
        readonly timeoutMinutes?: number;
    }
    class WorkflowStepParallelConfigStepRdsPromoteReadReplicaConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepParallelConfigStepRdsPromoteReadReplicaConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepParallelConfigStepRdsPromoteReadReplicaConfigProperty | cdktn.IResolvable | undefined);
        private _crossAccountRole?;
        get crossAccountRole(): string;
        set crossAccountRole(value: string);
        resetCrossAccountRole(): void;
        get crossAccountRoleInput(): string | undefined;
        private _dbInstanceArnMap?;
        get dbInstanceArnMap(): {
            [key: string]: string;
        };
        set dbInstanceArnMap(value: {
            [key: string]: string;
        });
        get dbInstanceArnMapInput(): {
            [key: string]: string;
        } | undefined;
        private _externalId?;
        get externalId(): string;
        set externalId(value: string);
        resetExternalId(): void;
        get externalIdInput(): string | undefined;
        private _timeoutMinutes?;
        get timeoutMinutes(): number;
        set timeoutMinutes(value: number);
        resetTimeoutMinutes(): void;
        get timeoutMinutesInput(): number | undefined;
    }
    class WorkflowStepParallelConfigStepRdsPromoteReadReplicaConfigPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepParallelConfigStepRdsPromoteReadReplicaConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepParallelConfigStepRdsPromoteReadReplicaConfigPropertyOutputReference;
    }
    interface WorkflowStepParallelConfigStepRegionSwitchPlanConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#arn TfPlan#arn}
        */
        readonly arn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#cross_account_role TfPlan#cross_account_role}
        */
        readonly crossAccountRole?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#external_id TfPlan#external_id}
        */
        readonly externalId?: string;
    }
    class WorkflowStepParallelConfigStepRegionSwitchPlanConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepParallelConfigStepRegionSwitchPlanConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepParallelConfigStepRegionSwitchPlanConfigProperty | cdktn.IResolvable | undefined);
        private _arn?;
        get arn(): string;
        set arn(value: string);
        get arnInput(): string | undefined;
        private _crossAccountRole?;
        get crossAccountRole(): string;
        set crossAccountRole(value: string);
        resetCrossAccountRole(): void;
        get crossAccountRoleInput(): string | undefined;
        private _externalId?;
        get externalId(): string;
        set externalId(value: string);
        resetExternalId(): void;
        get externalIdInput(): string | undefined;
    }
    class WorkflowStepParallelConfigStepRegionSwitchPlanConfigPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepParallelConfigStepRegionSwitchPlanConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepParallelConfigStepRegionSwitchPlanConfigPropertyOutputReference;
    }
    interface WorkflowStepParallelConfigStepRoute53HealthCheckConfigRecordSetProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#record_set_identifier TfPlan#record_set_identifier}
        */
        readonly recordSetIdentifier: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#region TfPlan#region}
        */
        readonly region: string;
    }
    class WorkflowStepParallelConfigStepRoute53HealthCheckConfigRecordSetPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepParallelConfigStepRoute53HealthCheckConfigRecordSetProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepParallelConfigStepRoute53HealthCheckConfigRecordSetProperty | cdktn.IResolvable | undefined);
        private _recordSetIdentifier?;
        get recordSetIdentifier(): string;
        set recordSetIdentifier(value: string);
        get recordSetIdentifierInput(): string | undefined;
        private _region?;
        get region(): string;
        set region(value: string);
        get regionInput(): string | undefined;
    }
    class WorkflowStepParallelConfigStepRoute53HealthCheckConfigRecordSetPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepParallelConfigStepRoute53HealthCheckConfigRecordSetProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepParallelConfigStepRoute53HealthCheckConfigRecordSetPropertyOutputReference;
    }
    interface WorkflowStepParallelConfigStepRoute53HealthCheckConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#cross_account_role TfPlan#cross_account_role}
        */
        readonly crossAccountRole?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#external_id TfPlan#external_id}
        */
        readonly externalId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#hosted_zone_id TfPlan#hosted_zone_id}
        */
        readonly hostedZoneId: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#record_name TfPlan#record_name}
        */
        readonly recordName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#timeout_minutes TfPlan#timeout_minutes}
        */
        readonly timeoutMinutes?: number;
        /**
        * record_set block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#record_set TfPlan#record_set}
        */
        readonly recordSet?: WorkflowStepParallelConfigStepRoute53HealthCheckConfigRecordSetProperty[] | cdktn.IResolvable;
    }
    class WorkflowStepParallelConfigStepRoute53HealthCheckConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepParallelConfigStepRoute53HealthCheckConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepParallelConfigStepRoute53HealthCheckConfigProperty | cdktn.IResolvable | undefined);
        private _crossAccountRole?;
        get crossAccountRole(): string;
        set crossAccountRole(value: string);
        resetCrossAccountRole(): void;
        get crossAccountRoleInput(): string | undefined;
        private _externalId?;
        get externalId(): string;
        set externalId(value: string);
        resetExternalId(): void;
        get externalIdInput(): string | undefined;
        private _hostedZoneId?;
        get hostedZoneId(): string;
        set hostedZoneId(value: string);
        get hostedZoneIdInput(): string | undefined;
        private _recordName?;
        get recordName(): string;
        set recordName(value: string);
        get recordNameInput(): string | undefined;
        private _timeoutMinutes?;
        get timeoutMinutes(): number;
        set timeoutMinutes(value: number);
        resetTimeoutMinutes(): void;
        get timeoutMinutesInput(): number | undefined;
        private _recordSet;
        get recordSet(): WorkflowStepParallelConfigStepRoute53HealthCheckConfigRecordSetPropertyList;
        putRecordSet(value: WorkflowStepParallelConfigStepRoute53HealthCheckConfigRecordSetProperty[] | cdktn.IResolvable): void;
        resetRecordSet(): void;
        get recordSetInput(): cdktn.IResolvable | WorkflowStepParallelConfigStepRoute53HealthCheckConfigRecordSetProperty[] | undefined;
    }
    class WorkflowStepParallelConfigStepRoute53HealthCheckConfigPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepParallelConfigStepRoute53HealthCheckConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepParallelConfigStepRoute53HealthCheckConfigPropertyOutputReference;
    }
    interface WorkflowStepParallelConfigStepProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#description TfPlan#description}
        */
        readonly description?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#execution_block_type TfPlan#execution_block_type}
        */
        readonly executionBlockType: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#name TfPlan#name}
        */
        readonly name: string;
        /**
        * arc_routing_control_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#arc_routing_control_config TfPlan#arc_routing_control_config}
        */
        readonly arcRoutingControlConfig?: WorkflowStepParallelConfigStepArcRoutingControlConfigProperty[] | cdktn.IResolvable;
        /**
        * aurora_provisioned_scaling_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#aurora_provisioned_scaling_config TfPlan#aurora_provisioned_scaling_config}
        */
        readonly auroraProvisionedScalingConfig?: WorkflowStepParallelConfigStepAuroraProvisionedScalingConfigProperty[] | cdktn.IResolvable;
        /**
        * aurora_serverless_scaling_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#aurora_serverless_scaling_config TfPlan#aurora_serverless_scaling_config}
        */
        readonly auroraServerlessScalingConfig?: WorkflowStepParallelConfigStepAuroraServerlessScalingConfigProperty[] | cdktn.IResolvable;
        /**
        * custom_action_lambda_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#custom_action_lambda_config TfPlan#custom_action_lambda_config}
        */
        readonly customActionLambdaConfig?: WorkflowStepParallelConfigStepCustomActionLambdaConfigProperty[] | cdktn.IResolvable;
        /**
        * document_db_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#document_db_config TfPlan#document_db_config}
        */
        readonly documentDbConfig?: WorkflowStepParallelConfigStepDocumentDbConfigProperty[] | cdktn.IResolvable;
        /**
        * ec2_asg_capacity_increase_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#ec2_asg_capacity_increase_config TfPlan#ec2_asg_capacity_increase_config}
        */
        readonly ec2AsgCapacityIncreaseConfig?: WorkflowStepParallelConfigStepEc2AsgCapacityIncreaseConfigProperty[] | cdktn.IResolvable;
        /**
        * ecs_capacity_increase_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#ecs_capacity_increase_config TfPlan#ecs_capacity_increase_config}
        */
        readonly ecsCapacityIncreaseConfig?: WorkflowStepParallelConfigStepEcsCapacityIncreaseConfigProperty[] | cdktn.IResolvable;
        /**
        * eks_resource_scaling_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#eks_resource_scaling_config TfPlan#eks_resource_scaling_config}
        */
        readonly eksResourceScalingConfig?: WorkflowStepParallelConfigStepEksResourceScalingConfigProperty[] | cdktn.IResolvable;
        /**
        * execution_approval_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#execution_approval_config TfPlan#execution_approval_config}
        */
        readonly executionApprovalConfig?: WorkflowStepParallelConfigStepExecutionApprovalConfigProperty[] | cdktn.IResolvable;
        /**
        * global_aurora_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#global_aurora_config TfPlan#global_aurora_config}
        */
        readonly globalAuroraConfig?: WorkflowStepParallelConfigStepGlobalAuroraConfigProperty[] | cdktn.IResolvable;
        /**
        * lambda_event_source_mapping_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#lambda_event_source_mapping_config TfPlan#lambda_event_source_mapping_config}
        */
        readonly lambdaEventSourceMappingConfig?: WorkflowStepParallelConfigStepLambdaEventSourceMappingConfigProperty[] | cdktn.IResolvable;
        /**
        * neptune_global_database_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#neptune_global_database_config TfPlan#neptune_global_database_config}
        */
        readonly neptuneGlobalDatabaseConfig?: WorkflowStepParallelConfigStepNeptuneGlobalDatabaseConfigProperty[] | cdktn.IResolvable;
        /**
        * rds_create_cross_region_read_replica_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#rds_create_cross_region_read_replica_config TfPlan#rds_create_cross_region_read_replica_config}
        */
        readonly rdsCreateCrossRegionReadReplicaConfig?: WorkflowStepParallelConfigStepRdsCreateCrossRegionReadReplicaConfigProperty[] | cdktn.IResolvable;
        /**
        * rds_promote_read_replica_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#rds_promote_read_replica_config TfPlan#rds_promote_read_replica_config}
        */
        readonly rdsPromoteReadReplicaConfig?: WorkflowStepParallelConfigStepRdsPromoteReadReplicaConfigProperty[] | cdktn.IResolvable;
        /**
        * region_switch_plan_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#region_switch_plan_config TfPlan#region_switch_plan_config}
        */
        readonly regionSwitchPlanConfig?: WorkflowStepParallelConfigStepRegionSwitchPlanConfigProperty[] | cdktn.IResolvable;
        /**
        * route53_health_check_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#route53_health_check_config TfPlan#route53_health_check_config}
        */
        readonly route53HealthCheckConfig?: WorkflowStepParallelConfigStepRoute53HealthCheckConfigProperty[] | cdktn.IResolvable;
    }
    class WorkflowStepParallelConfigStepPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepParallelConfigStepProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepParallelConfigStepProperty | cdktn.IResolvable | undefined);
        private _description?;
        get description(): string;
        set description(value: string);
        resetDescription(): void;
        get descriptionInput(): string | undefined;
        private _executionBlockType?;
        get executionBlockType(): string;
        set executionBlockType(value: string);
        get executionBlockTypeInput(): string | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _arcRoutingControlConfig;
        get arcRoutingControlConfig(): WorkflowStepParallelConfigStepArcRoutingControlConfigPropertyList;
        putArcRoutingControlConfig(value: WorkflowStepParallelConfigStepArcRoutingControlConfigProperty[] | cdktn.IResolvable): void;
        resetArcRoutingControlConfig(): void;
        get arcRoutingControlConfigInput(): cdktn.IResolvable | WorkflowStepParallelConfigStepArcRoutingControlConfigProperty[] | undefined;
        private _auroraProvisionedScalingConfig;
        get auroraProvisionedScalingConfig(): WorkflowStepParallelConfigStepAuroraProvisionedScalingConfigPropertyList;
        putAuroraProvisionedScalingConfig(value: WorkflowStepParallelConfigStepAuroraProvisionedScalingConfigProperty[] | cdktn.IResolvable): void;
        resetAuroraProvisionedScalingConfig(): void;
        get auroraProvisionedScalingConfigInput(): cdktn.IResolvable | WorkflowStepParallelConfigStepAuroraProvisionedScalingConfigProperty[] | undefined;
        private _auroraServerlessScalingConfig;
        get auroraServerlessScalingConfig(): WorkflowStepParallelConfigStepAuroraServerlessScalingConfigPropertyList;
        putAuroraServerlessScalingConfig(value: WorkflowStepParallelConfigStepAuroraServerlessScalingConfigProperty[] | cdktn.IResolvable): void;
        resetAuroraServerlessScalingConfig(): void;
        get auroraServerlessScalingConfigInput(): cdktn.IResolvable | WorkflowStepParallelConfigStepAuroraServerlessScalingConfigProperty[] | undefined;
        private _customActionLambdaConfig;
        get customActionLambdaConfig(): WorkflowStepParallelConfigStepCustomActionLambdaConfigPropertyList;
        putCustomActionLambdaConfig(value: WorkflowStepParallelConfigStepCustomActionLambdaConfigProperty[] | cdktn.IResolvable): void;
        resetCustomActionLambdaConfig(): void;
        get customActionLambdaConfigInput(): cdktn.IResolvable | WorkflowStepParallelConfigStepCustomActionLambdaConfigProperty[] | undefined;
        private _documentDbConfig;
        get documentDbConfig(): WorkflowStepParallelConfigStepDocumentDbConfigPropertyList;
        putDocumentDbConfig(value: WorkflowStepParallelConfigStepDocumentDbConfigProperty[] | cdktn.IResolvable): void;
        resetDocumentDbConfig(): void;
        get documentDbConfigInput(): cdktn.IResolvable | WorkflowStepParallelConfigStepDocumentDbConfigProperty[] | undefined;
        private _ec2AsgCapacityIncreaseConfig;
        get ec2AsgCapacityIncreaseConfig(): WorkflowStepParallelConfigStepEc2AsgCapacityIncreaseConfigPropertyList;
        putEc2AsgCapacityIncreaseConfig(value: WorkflowStepParallelConfigStepEc2AsgCapacityIncreaseConfigProperty[] | cdktn.IResolvable): void;
        resetEc2AsgCapacityIncreaseConfig(): void;
        get ec2AsgCapacityIncreaseConfigInput(): cdktn.IResolvable | WorkflowStepParallelConfigStepEc2AsgCapacityIncreaseConfigProperty[] | undefined;
        private _ecsCapacityIncreaseConfig;
        get ecsCapacityIncreaseConfig(): WorkflowStepParallelConfigStepEcsCapacityIncreaseConfigPropertyList;
        putEcsCapacityIncreaseConfig(value: WorkflowStepParallelConfigStepEcsCapacityIncreaseConfigProperty[] | cdktn.IResolvable): void;
        resetEcsCapacityIncreaseConfig(): void;
        get ecsCapacityIncreaseConfigInput(): cdktn.IResolvable | WorkflowStepParallelConfigStepEcsCapacityIncreaseConfigProperty[] | undefined;
        private _eksResourceScalingConfig;
        get eksResourceScalingConfig(): WorkflowStepParallelConfigStepEksResourceScalingConfigPropertyList;
        putEksResourceScalingConfig(value: WorkflowStepParallelConfigStepEksResourceScalingConfigProperty[] | cdktn.IResolvable): void;
        resetEksResourceScalingConfig(): void;
        get eksResourceScalingConfigInput(): cdktn.IResolvable | WorkflowStepParallelConfigStepEksResourceScalingConfigProperty[] | undefined;
        private _executionApprovalConfig;
        get executionApprovalConfig(): WorkflowStepParallelConfigStepExecutionApprovalConfigPropertyList;
        putExecutionApprovalConfig(value: WorkflowStepParallelConfigStepExecutionApprovalConfigProperty[] | cdktn.IResolvable): void;
        resetExecutionApprovalConfig(): void;
        get executionApprovalConfigInput(): cdktn.IResolvable | WorkflowStepParallelConfigStepExecutionApprovalConfigProperty[] | undefined;
        private _globalAuroraConfig;
        get globalAuroraConfig(): WorkflowStepParallelConfigStepGlobalAuroraConfigPropertyList;
        putGlobalAuroraConfig(value: WorkflowStepParallelConfigStepGlobalAuroraConfigProperty[] | cdktn.IResolvable): void;
        resetGlobalAuroraConfig(): void;
        get globalAuroraConfigInput(): cdktn.IResolvable | WorkflowStepParallelConfigStepGlobalAuroraConfigProperty[] | undefined;
        private _lambdaEventSourceMappingConfig;
        get lambdaEventSourceMappingConfig(): WorkflowStepParallelConfigStepLambdaEventSourceMappingConfigPropertyList;
        putLambdaEventSourceMappingConfig(value: WorkflowStepParallelConfigStepLambdaEventSourceMappingConfigProperty[] | cdktn.IResolvable): void;
        resetLambdaEventSourceMappingConfig(): void;
        get lambdaEventSourceMappingConfigInput(): cdktn.IResolvable | WorkflowStepParallelConfigStepLambdaEventSourceMappingConfigProperty[] | undefined;
        private _neptuneGlobalDatabaseConfig;
        get neptuneGlobalDatabaseConfig(): WorkflowStepParallelConfigStepNeptuneGlobalDatabaseConfigPropertyList;
        putNeptuneGlobalDatabaseConfig(value: WorkflowStepParallelConfigStepNeptuneGlobalDatabaseConfigProperty[] | cdktn.IResolvable): void;
        resetNeptuneGlobalDatabaseConfig(): void;
        get neptuneGlobalDatabaseConfigInput(): cdktn.IResolvable | WorkflowStepParallelConfigStepNeptuneGlobalDatabaseConfigProperty[] | undefined;
        private _rdsCreateCrossRegionReadReplicaConfig;
        get rdsCreateCrossRegionReadReplicaConfig(): WorkflowStepParallelConfigStepRdsCreateCrossRegionReadReplicaConfigPropertyList;
        putRdsCreateCrossRegionReadReplicaConfig(value: WorkflowStepParallelConfigStepRdsCreateCrossRegionReadReplicaConfigProperty[] | cdktn.IResolvable): void;
        resetRdsCreateCrossRegionReadReplicaConfig(): void;
        get rdsCreateCrossRegionReadReplicaConfigInput(): cdktn.IResolvable | WorkflowStepParallelConfigStepRdsCreateCrossRegionReadReplicaConfigProperty[] | undefined;
        private _rdsPromoteReadReplicaConfig;
        get rdsPromoteReadReplicaConfig(): WorkflowStepParallelConfigStepRdsPromoteReadReplicaConfigPropertyList;
        putRdsPromoteReadReplicaConfig(value: WorkflowStepParallelConfigStepRdsPromoteReadReplicaConfigProperty[] | cdktn.IResolvable): void;
        resetRdsPromoteReadReplicaConfig(): void;
        get rdsPromoteReadReplicaConfigInput(): cdktn.IResolvable | WorkflowStepParallelConfigStepRdsPromoteReadReplicaConfigProperty[] | undefined;
        private _regionSwitchPlanConfig;
        get regionSwitchPlanConfig(): WorkflowStepParallelConfigStepRegionSwitchPlanConfigPropertyList;
        putRegionSwitchPlanConfig(value: WorkflowStepParallelConfigStepRegionSwitchPlanConfigProperty[] | cdktn.IResolvable): void;
        resetRegionSwitchPlanConfig(): void;
        get regionSwitchPlanConfigInput(): cdktn.IResolvable | WorkflowStepParallelConfigStepRegionSwitchPlanConfigProperty[] | undefined;
        private _route53HealthCheckConfig;
        get route53HealthCheckConfig(): WorkflowStepParallelConfigStepRoute53HealthCheckConfigPropertyList;
        putRoute53HealthCheckConfig(value: WorkflowStepParallelConfigStepRoute53HealthCheckConfigProperty[] | cdktn.IResolvable): void;
        resetRoute53HealthCheckConfig(): void;
        get route53HealthCheckConfigInput(): cdktn.IResolvable | WorkflowStepParallelConfigStepRoute53HealthCheckConfigProperty[] | undefined;
    }
    class WorkflowStepParallelConfigStepPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepParallelConfigStepProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepParallelConfigStepPropertyOutputReference;
    }
    interface ParallelConfigProperty {
        /**
        * step block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#step TfPlan#step}
        */
        readonly step?: WorkflowStepParallelConfigStepProperty[] | cdktn.IResolvable;
    }
    class ParallelConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ParallelConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ParallelConfigProperty | cdktn.IResolvable | undefined);
        private _step;
        get step(): WorkflowStepParallelConfigStepPropertyList;
        putStep(value: WorkflowStepParallelConfigStepProperty[] | cdktn.IResolvable): void;
        resetStep(): void;
        get stepInput(): cdktn.IResolvable | WorkflowStepParallelConfigStepProperty[] | undefined;
    }
    class ParallelConfigPropertyList extends cdktn.ComplexList {
        internalValue?: ParallelConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ParallelConfigPropertyOutputReference;
    }
    interface WorkflowStepRdsCreateCrossRegionReadReplicaConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#cross_account_role TfPlan#cross_account_role}
        */
        readonly crossAccountRole?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#db_instance_arn_map TfPlan#db_instance_arn_map}
        */
        readonly dbInstanceArnMap: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#external_id TfPlan#external_id}
        */
        readonly externalId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#timeout_minutes TfPlan#timeout_minutes}
        */
        readonly timeoutMinutes?: number;
    }
    class WorkflowStepRdsCreateCrossRegionReadReplicaConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepRdsCreateCrossRegionReadReplicaConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepRdsCreateCrossRegionReadReplicaConfigProperty | cdktn.IResolvable | undefined);
        private _crossAccountRole?;
        get crossAccountRole(): string;
        set crossAccountRole(value: string);
        resetCrossAccountRole(): void;
        get crossAccountRoleInput(): string | undefined;
        private _dbInstanceArnMap?;
        get dbInstanceArnMap(): {
            [key: string]: string;
        };
        set dbInstanceArnMap(value: {
            [key: string]: string;
        });
        get dbInstanceArnMapInput(): {
            [key: string]: string;
        } | undefined;
        private _externalId?;
        get externalId(): string;
        set externalId(value: string);
        resetExternalId(): void;
        get externalIdInput(): string | undefined;
        private _timeoutMinutes?;
        get timeoutMinutes(): number;
        set timeoutMinutes(value: number);
        resetTimeoutMinutes(): void;
        get timeoutMinutesInput(): number | undefined;
    }
    class WorkflowStepRdsCreateCrossRegionReadReplicaConfigPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepRdsCreateCrossRegionReadReplicaConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepRdsCreateCrossRegionReadReplicaConfigPropertyOutputReference;
    }
    interface WorkflowStepRdsPromoteReadReplicaConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#cross_account_role TfPlan#cross_account_role}
        */
        readonly crossAccountRole?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#db_instance_arn_map TfPlan#db_instance_arn_map}
        */
        readonly dbInstanceArnMap: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#external_id TfPlan#external_id}
        */
        readonly externalId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#timeout_minutes TfPlan#timeout_minutes}
        */
        readonly timeoutMinutes?: number;
    }
    class WorkflowStepRdsPromoteReadReplicaConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepRdsPromoteReadReplicaConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepRdsPromoteReadReplicaConfigProperty | cdktn.IResolvable | undefined);
        private _crossAccountRole?;
        get crossAccountRole(): string;
        set crossAccountRole(value: string);
        resetCrossAccountRole(): void;
        get crossAccountRoleInput(): string | undefined;
        private _dbInstanceArnMap?;
        get dbInstanceArnMap(): {
            [key: string]: string;
        };
        set dbInstanceArnMap(value: {
            [key: string]: string;
        });
        get dbInstanceArnMapInput(): {
            [key: string]: string;
        } | undefined;
        private _externalId?;
        get externalId(): string;
        set externalId(value: string);
        resetExternalId(): void;
        get externalIdInput(): string | undefined;
        private _timeoutMinutes?;
        get timeoutMinutes(): number;
        set timeoutMinutes(value: number);
        resetTimeoutMinutes(): void;
        get timeoutMinutesInput(): number | undefined;
    }
    class WorkflowStepRdsPromoteReadReplicaConfigPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepRdsPromoteReadReplicaConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepRdsPromoteReadReplicaConfigPropertyOutputReference;
    }
    interface WorkflowStepRegionSwitchPlanConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#arn TfPlan#arn}
        */
        readonly arn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#cross_account_role TfPlan#cross_account_role}
        */
        readonly crossAccountRole?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#external_id TfPlan#external_id}
        */
        readonly externalId?: string;
    }
    class WorkflowStepRegionSwitchPlanConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepRegionSwitchPlanConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepRegionSwitchPlanConfigProperty | cdktn.IResolvable | undefined);
        private _arn?;
        get arn(): string;
        set arn(value: string);
        get arnInput(): string | undefined;
        private _crossAccountRole?;
        get crossAccountRole(): string;
        set crossAccountRole(value: string);
        resetCrossAccountRole(): void;
        get crossAccountRoleInput(): string | undefined;
        private _externalId?;
        get externalId(): string;
        set externalId(value: string);
        resetExternalId(): void;
        get externalIdInput(): string | undefined;
    }
    class WorkflowStepRegionSwitchPlanConfigPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepRegionSwitchPlanConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepRegionSwitchPlanConfigPropertyOutputReference;
    }
    interface WorkflowStepRoute53HealthCheckConfigRecordSetProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#record_set_identifier TfPlan#record_set_identifier}
        */
        readonly recordSetIdentifier: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#region TfPlan#region}
        */
        readonly region: string;
    }
    class WorkflowStepRoute53HealthCheckConfigRecordSetPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepRoute53HealthCheckConfigRecordSetProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepRoute53HealthCheckConfigRecordSetProperty | cdktn.IResolvable | undefined);
        private _recordSetIdentifier?;
        get recordSetIdentifier(): string;
        set recordSetIdentifier(value: string);
        get recordSetIdentifierInput(): string | undefined;
        private _region?;
        get region(): string;
        set region(value: string);
        get regionInput(): string | undefined;
    }
    class WorkflowStepRoute53HealthCheckConfigRecordSetPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepRoute53HealthCheckConfigRecordSetProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepRoute53HealthCheckConfigRecordSetPropertyOutputReference;
    }
    interface WorkflowStepRoute53HealthCheckConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#cross_account_role TfPlan#cross_account_role}
        */
        readonly crossAccountRole?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#external_id TfPlan#external_id}
        */
        readonly externalId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#hosted_zone_id TfPlan#hosted_zone_id}
        */
        readonly hostedZoneId: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#record_name TfPlan#record_name}
        */
        readonly recordName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#timeout_minutes TfPlan#timeout_minutes}
        */
        readonly timeoutMinutes?: number;
        /**
        * record_set block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#record_set TfPlan#record_set}
        */
        readonly recordSet?: WorkflowStepRoute53HealthCheckConfigRecordSetProperty[] | cdktn.IResolvable;
    }
    class WorkflowStepRoute53HealthCheckConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepRoute53HealthCheckConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepRoute53HealthCheckConfigProperty | cdktn.IResolvable | undefined);
        private _crossAccountRole?;
        get crossAccountRole(): string;
        set crossAccountRole(value: string);
        resetCrossAccountRole(): void;
        get crossAccountRoleInput(): string | undefined;
        private _externalId?;
        get externalId(): string;
        set externalId(value: string);
        resetExternalId(): void;
        get externalIdInput(): string | undefined;
        private _hostedZoneId?;
        get hostedZoneId(): string;
        set hostedZoneId(value: string);
        get hostedZoneIdInput(): string | undefined;
        private _recordName?;
        get recordName(): string;
        set recordName(value: string);
        get recordNameInput(): string | undefined;
        private _timeoutMinutes?;
        get timeoutMinutes(): number;
        set timeoutMinutes(value: number);
        resetTimeoutMinutes(): void;
        get timeoutMinutesInput(): number | undefined;
        private _recordSet;
        get recordSet(): WorkflowStepRoute53HealthCheckConfigRecordSetPropertyList;
        putRecordSet(value: WorkflowStepRoute53HealthCheckConfigRecordSetProperty[] | cdktn.IResolvable): void;
        resetRecordSet(): void;
        get recordSetInput(): cdktn.IResolvable | WorkflowStepRoute53HealthCheckConfigRecordSetProperty[] | undefined;
    }
    class WorkflowStepRoute53HealthCheckConfigPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepRoute53HealthCheckConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepRoute53HealthCheckConfigPropertyOutputReference;
    }
    interface WorkflowStepProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#description TfPlan#description}
        */
        readonly description?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#execution_block_type TfPlan#execution_block_type}
        */
        readonly executionBlockType: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#name TfPlan#name}
        */
        readonly name: string;
        /**
        * arc_routing_control_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#arc_routing_control_config TfPlan#arc_routing_control_config}
        */
        readonly arcRoutingControlConfig?: WorkflowStepArcRoutingControlConfigProperty[] | cdktn.IResolvable;
        /**
        * aurora_provisioned_scaling_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#aurora_provisioned_scaling_config TfPlan#aurora_provisioned_scaling_config}
        */
        readonly auroraProvisionedScalingConfig?: WorkflowStepAuroraProvisionedScalingConfigProperty[] | cdktn.IResolvable;
        /**
        * aurora_serverless_scaling_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#aurora_serverless_scaling_config TfPlan#aurora_serverless_scaling_config}
        */
        readonly auroraServerlessScalingConfig?: WorkflowStepAuroraServerlessScalingConfigProperty[] | cdktn.IResolvable;
        /**
        * custom_action_lambda_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#custom_action_lambda_config TfPlan#custom_action_lambda_config}
        */
        readonly customActionLambdaConfig?: WorkflowStepCustomActionLambdaConfigProperty[] | cdktn.IResolvable;
        /**
        * document_db_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#document_db_config TfPlan#document_db_config}
        */
        readonly documentDbConfig?: WorkflowStepDocumentDbConfigProperty[] | cdktn.IResolvable;
        /**
        * ec2_asg_capacity_increase_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#ec2_asg_capacity_increase_config TfPlan#ec2_asg_capacity_increase_config}
        */
        readonly ec2AsgCapacityIncreaseConfig?: WorkflowStepEc2AsgCapacityIncreaseConfigProperty[] | cdktn.IResolvable;
        /**
        * ecs_capacity_increase_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#ecs_capacity_increase_config TfPlan#ecs_capacity_increase_config}
        */
        readonly ecsCapacityIncreaseConfig?: WorkflowStepEcsCapacityIncreaseConfigProperty[] | cdktn.IResolvable;
        /**
        * eks_resource_scaling_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#eks_resource_scaling_config TfPlan#eks_resource_scaling_config}
        */
        readonly eksResourceScalingConfig?: WorkflowStepEksResourceScalingConfigProperty[] | cdktn.IResolvable;
        /**
        * execution_approval_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#execution_approval_config TfPlan#execution_approval_config}
        */
        readonly executionApprovalConfig?: WorkflowStepExecutionApprovalConfigProperty[] | cdktn.IResolvable;
        /**
        * global_aurora_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#global_aurora_config TfPlan#global_aurora_config}
        */
        readonly globalAuroraConfig?: WorkflowStepGlobalAuroraConfigProperty[] | cdktn.IResolvable;
        /**
        * lambda_event_source_mapping_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#lambda_event_source_mapping_config TfPlan#lambda_event_source_mapping_config}
        */
        readonly lambdaEventSourceMappingConfig?: WorkflowStepLambdaEventSourceMappingConfigProperty[] | cdktn.IResolvable;
        /**
        * neptune_global_database_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#neptune_global_database_config TfPlan#neptune_global_database_config}
        */
        readonly neptuneGlobalDatabaseConfig?: WorkflowStepNeptuneGlobalDatabaseConfigProperty[] | cdktn.IResolvable;
        /**
        * parallel_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#parallel_config TfPlan#parallel_config}
        */
        readonly parallelConfig?: ParallelConfigProperty[] | cdktn.IResolvable;
        /**
        * rds_create_cross_region_read_replica_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#rds_create_cross_region_read_replica_config TfPlan#rds_create_cross_region_read_replica_config}
        */
        readonly rdsCreateCrossRegionReadReplicaConfig?: WorkflowStepRdsCreateCrossRegionReadReplicaConfigProperty[] | cdktn.IResolvable;
        /**
        * rds_promote_read_replica_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#rds_promote_read_replica_config TfPlan#rds_promote_read_replica_config}
        */
        readonly rdsPromoteReadReplicaConfig?: WorkflowStepRdsPromoteReadReplicaConfigProperty[] | cdktn.IResolvable;
        /**
        * region_switch_plan_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#region_switch_plan_config TfPlan#region_switch_plan_config}
        */
        readonly regionSwitchPlanConfig?: WorkflowStepRegionSwitchPlanConfigProperty[] | cdktn.IResolvable;
        /**
        * route53_health_check_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#route53_health_check_config TfPlan#route53_health_check_config}
        */
        readonly route53HealthCheckConfig?: WorkflowStepRoute53HealthCheckConfigProperty[] | cdktn.IResolvable;
    }
    class WorkflowStepPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowStepProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowStepProperty | cdktn.IResolvable | undefined);
        private _description?;
        get description(): string;
        set description(value: string);
        resetDescription(): void;
        get descriptionInput(): string | undefined;
        private _executionBlockType?;
        get executionBlockType(): string;
        set executionBlockType(value: string);
        get executionBlockTypeInput(): string | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _arcRoutingControlConfig;
        get arcRoutingControlConfig(): WorkflowStepArcRoutingControlConfigPropertyList;
        putArcRoutingControlConfig(value: WorkflowStepArcRoutingControlConfigProperty[] | cdktn.IResolvable): void;
        resetArcRoutingControlConfig(): void;
        get arcRoutingControlConfigInput(): cdktn.IResolvable | WorkflowStepArcRoutingControlConfigProperty[] | undefined;
        private _auroraProvisionedScalingConfig;
        get auroraProvisionedScalingConfig(): WorkflowStepAuroraProvisionedScalingConfigPropertyList;
        putAuroraProvisionedScalingConfig(value: WorkflowStepAuroraProvisionedScalingConfigProperty[] | cdktn.IResolvable): void;
        resetAuroraProvisionedScalingConfig(): void;
        get auroraProvisionedScalingConfigInput(): cdktn.IResolvable | WorkflowStepAuroraProvisionedScalingConfigProperty[] | undefined;
        private _auroraServerlessScalingConfig;
        get auroraServerlessScalingConfig(): WorkflowStepAuroraServerlessScalingConfigPropertyList;
        putAuroraServerlessScalingConfig(value: WorkflowStepAuroraServerlessScalingConfigProperty[] | cdktn.IResolvable): void;
        resetAuroraServerlessScalingConfig(): void;
        get auroraServerlessScalingConfigInput(): cdktn.IResolvable | WorkflowStepAuroraServerlessScalingConfigProperty[] | undefined;
        private _customActionLambdaConfig;
        get customActionLambdaConfig(): WorkflowStepCustomActionLambdaConfigPropertyList;
        putCustomActionLambdaConfig(value: WorkflowStepCustomActionLambdaConfigProperty[] | cdktn.IResolvable): void;
        resetCustomActionLambdaConfig(): void;
        get customActionLambdaConfigInput(): cdktn.IResolvable | WorkflowStepCustomActionLambdaConfigProperty[] | undefined;
        private _documentDbConfig;
        get documentDbConfig(): WorkflowStepDocumentDbConfigPropertyList;
        putDocumentDbConfig(value: WorkflowStepDocumentDbConfigProperty[] | cdktn.IResolvable): void;
        resetDocumentDbConfig(): void;
        get documentDbConfigInput(): cdktn.IResolvable | WorkflowStepDocumentDbConfigProperty[] | undefined;
        private _ec2AsgCapacityIncreaseConfig;
        get ec2AsgCapacityIncreaseConfig(): WorkflowStepEc2AsgCapacityIncreaseConfigPropertyList;
        putEc2AsgCapacityIncreaseConfig(value: WorkflowStepEc2AsgCapacityIncreaseConfigProperty[] | cdktn.IResolvable): void;
        resetEc2AsgCapacityIncreaseConfig(): void;
        get ec2AsgCapacityIncreaseConfigInput(): cdktn.IResolvable | WorkflowStepEc2AsgCapacityIncreaseConfigProperty[] | undefined;
        private _ecsCapacityIncreaseConfig;
        get ecsCapacityIncreaseConfig(): WorkflowStepEcsCapacityIncreaseConfigPropertyList;
        putEcsCapacityIncreaseConfig(value: WorkflowStepEcsCapacityIncreaseConfigProperty[] | cdktn.IResolvable): void;
        resetEcsCapacityIncreaseConfig(): void;
        get ecsCapacityIncreaseConfigInput(): cdktn.IResolvable | WorkflowStepEcsCapacityIncreaseConfigProperty[] | undefined;
        private _eksResourceScalingConfig;
        get eksResourceScalingConfig(): WorkflowStepEksResourceScalingConfigPropertyList;
        putEksResourceScalingConfig(value: WorkflowStepEksResourceScalingConfigProperty[] | cdktn.IResolvable): void;
        resetEksResourceScalingConfig(): void;
        get eksResourceScalingConfigInput(): cdktn.IResolvable | WorkflowStepEksResourceScalingConfigProperty[] | undefined;
        private _executionApprovalConfig;
        get executionApprovalConfig(): WorkflowStepExecutionApprovalConfigPropertyList;
        putExecutionApprovalConfig(value: WorkflowStepExecutionApprovalConfigProperty[] | cdktn.IResolvable): void;
        resetExecutionApprovalConfig(): void;
        get executionApprovalConfigInput(): cdktn.IResolvable | WorkflowStepExecutionApprovalConfigProperty[] | undefined;
        private _globalAuroraConfig;
        get globalAuroraConfig(): WorkflowStepGlobalAuroraConfigPropertyList;
        putGlobalAuroraConfig(value: WorkflowStepGlobalAuroraConfigProperty[] | cdktn.IResolvable): void;
        resetGlobalAuroraConfig(): void;
        get globalAuroraConfigInput(): cdktn.IResolvable | WorkflowStepGlobalAuroraConfigProperty[] | undefined;
        private _lambdaEventSourceMappingConfig;
        get lambdaEventSourceMappingConfig(): WorkflowStepLambdaEventSourceMappingConfigPropertyList;
        putLambdaEventSourceMappingConfig(value: WorkflowStepLambdaEventSourceMappingConfigProperty[] | cdktn.IResolvable): void;
        resetLambdaEventSourceMappingConfig(): void;
        get lambdaEventSourceMappingConfigInput(): cdktn.IResolvable | WorkflowStepLambdaEventSourceMappingConfigProperty[] | undefined;
        private _neptuneGlobalDatabaseConfig;
        get neptuneGlobalDatabaseConfig(): WorkflowStepNeptuneGlobalDatabaseConfigPropertyList;
        putNeptuneGlobalDatabaseConfig(value: WorkflowStepNeptuneGlobalDatabaseConfigProperty[] | cdktn.IResolvable): void;
        resetNeptuneGlobalDatabaseConfig(): void;
        get neptuneGlobalDatabaseConfigInput(): cdktn.IResolvable | WorkflowStepNeptuneGlobalDatabaseConfigProperty[] | undefined;
        private _parallelConfig;
        get parallelConfig(): ParallelConfigPropertyList;
        putParallelConfig(value: ParallelConfigProperty[] | cdktn.IResolvable): void;
        resetParallelConfig(): void;
        get parallelConfigInput(): cdktn.IResolvable | ParallelConfigProperty[] | undefined;
        private _rdsCreateCrossRegionReadReplicaConfig;
        get rdsCreateCrossRegionReadReplicaConfig(): WorkflowStepRdsCreateCrossRegionReadReplicaConfigPropertyList;
        putRdsCreateCrossRegionReadReplicaConfig(value: WorkflowStepRdsCreateCrossRegionReadReplicaConfigProperty[] | cdktn.IResolvable): void;
        resetRdsCreateCrossRegionReadReplicaConfig(): void;
        get rdsCreateCrossRegionReadReplicaConfigInput(): cdktn.IResolvable | WorkflowStepRdsCreateCrossRegionReadReplicaConfigProperty[] | undefined;
        private _rdsPromoteReadReplicaConfig;
        get rdsPromoteReadReplicaConfig(): WorkflowStepRdsPromoteReadReplicaConfigPropertyList;
        putRdsPromoteReadReplicaConfig(value: WorkflowStepRdsPromoteReadReplicaConfigProperty[] | cdktn.IResolvable): void;
        resetRdsPromoteReadReplicaConfig(): void;
        get rdsPromoteReadReplicaConfigInput(): cdktn.IResolvable | WorkflowStepRdsPromoteReadReplicaConfigProperty[] | undefined;
        private _regionSwitchPlanConfig;
        get regionSwitchPlanConfig(): WorkflowStepRegionSwitchPlanConfigPropertyList;
        putRegionSwitchPlanConfig(value: WorkflowStepRegionSwitchPlanConfigProperty[] | cdktn.IResolvable): void;
        resetRegionSwitchPlanConfig(): void;
        get regionSwitchPlanConfigInput(): cdktn.IResolvable | WorkflowStepRegionSwitchPlanConfigProperty[] | undefined;
        private _route53HealthCheckConfig;
        get route53HealthCheckConfig(): WorkflowStepRoute53HealthCheckConfigPropertyList;
        putRoute53HealthCheckConfig(value: WorkflowStepRoute53HealthCheckConfigProperty[] | cdktn.IResolvable): void;
        resetRoute53HealthCheckConfig(): void;
        get route53HealthCheckConfigInput(): cdktn.IResolvable | WorkflowStepRoute53HealthCheckConfigProperty[] | undefined;
    }
    class WorkflowStepPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowStepProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowStepPropertyOutputReference;
    }
    interface WorkflowProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#workflow_description TfPlan#workflow_description}
        */
        readonly workflowDescription?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#workflow_target_action TfPlan#workflow_target_action}
        */
        readonly workflowTargetAction: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#workflow_target_region TfPlan#workflow_target_region}
        */
        readonly workflowTargetRegion?: string;
        /**
        * step block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/arcregionswitch_plan#step TfPlan#step}
        */
        readonly step?: WorkflowStepProperty[] | cdktn.IResolvable;
    }
    class WorkflowPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowProperty | cdktn.IResolvable | undefined);
        private _workflowDescription?;
        get workflowDescription(): string;
        set workflowDescription(value: string);
        resetWorkflowDescription(): void;
        get workflowDescriptionInput(): string | undefined;
        private _workflowTargetAction?;
        get workflowTargetAction(): string;
        set workflowTargetAction(value: string);
        get workflowTargetActionInput(): string | undefined;
        private _workflowTargetRegion?;
        get workflowTargetRegion(): string;
        set workflowTargetRegion(value: string);
        resetWorkflowTargetRegion(): void;
        get workflowTargetRegionInput(): string | undefined;
        private _step;
        get step(): WorkflowStepPropertyList;
        putStep(value: WorkflowStepProperty[] | cdktn.IResolvable): void;
        resetStep(): void;
        get stepInput(): cdktn.IResolvable | WorkflowStepProperty[] | undefined;
    }
    class WorkflowPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowPropertyOutputReference;
    }
}
