import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataTfPlanConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/arcregionswitch_plan#arn DataTfPlan#arn}
    */
    readonly arn: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/arcregionswitch_plan#region DataTfPlan#region}
    */
    readonly region?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/arcregionswitch_plan aws_arcregionswitch_plan}
*/
export declare class DataTfPlan extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_arcregionswitch_plan";
    /**
    * Generates CDKTN code for importing a DataTfPlan resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataTfPlan to import
    * @param importFromId The id of the existing DataTfPlan that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/arcregionswitch_plan#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataTfPlan to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/arcregionswitch_plan aws_arcregionswitch_plan} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataTfPlanConfig
    */
    constructor(scope: Construct, id: string, config: DataTfPlanConfig);
    private _arn?;
    get arn(): string;
    set arn(value: string);
    get arnInput(): string | undefined;
    get description(): string;
    get executionRole(): string;
    get name(): string;
    get owner(): string;
    get primaryRegion(): string;
    get recoveryApproach(): string;
    get recoveryTimeObjectiveMinutes(): number;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get regions(): string[];
    private _tags;
    get tags(): cdktn.StringMap;
    get updatedAt(): string;
    get version(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
