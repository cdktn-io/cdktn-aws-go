import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsSigningJobConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/signer_signing_job#id DataAwsSigningJob#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/signer_signing_job#job_id DataAwsSigningJob#job_id}
    */
    readonly jobId: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/signer_signing_job#region DataAwsSigningJob#region}
    */
    readonly region?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/signer_signing_job aws_signer_signing_job}
*/
export declare class DataAwsSigningJob extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_signer_signing_job";
    /**
    * Generates CDKTN code for importing a DataAwsSigningJob resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsSigningJob to import
    * @param importFromId The id of the existing DataAwsSigningJob that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/signer_signing_job#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsSigningJob to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/signer_signing_job aws_signer_signing_job} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsSigningJobConfig
    */
    constructor(scope: Construct, id: string, config: DataAwsSigningJobConfig);
    get completedAt(): string;
    get createdAt(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _jobId?;
    get jobId(): string;
    set jobId(value: string);
    get jobIdInput(): string | undefined;
    get jobInvoker(): string;
    get jobOwner(): string;
    get platformDisplayName(): string;
    get platformId(): string;
    get profileName(): string;
    get profileVersion(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get requestedBy(): string;
    private _revocationRecord;
    get revocationRecord(): DataAwsSigningJob.RevocationRecordPropertyList;
    get signatureExpiresAt(): string;
    private _signedObject;
    get signedObject(): DataAwsSigningJob.SignedObjectPropertyList;
    private _source;
    get source(): DataAwsSigningJob.SourcePropertyList;
    get status(): string;
    get statusReason(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataAwsSigningJobRevocationRecordPropertyToTerraform(struct?: DataAwsSigningJob.RevocationRecordProperty): any;
export declare function dataAwsSigningJobRevocationRecordPropertyToHclTerraform(struct?: DataAwsSigningJob.RevocationRecordProperty): any;
export declare function dataAwsSigningJobSignedObjectS3PropertyToTerraform(struct?: DataAwsSigningJob.SignedObjectS3Property): any;
export declare function dataAwsSigningJobSignedObjectS3PropertyToHclTerraform(struct?: DataAwsSigningJob.SignedObjectS3Property): any;
export declare function dataAwsSigningJobSignedObjectPropertyToTerraform(struct?: DataAwsSigningJob.SignedObjectProperty): any;
export declare function dataAwsSigningJobSignedObjectPropertyToHclTerraform(struct?: DataAwsSigningJob.SignedObjectProperty): any;
export declare function dataAwsSigningJobSourceS3PropertyToTerraform(struct?: DataAwsSigningJob.SourceS3Property): any;
export declare function dataAwsSigningJobSourceS3PropertyToHclTerraform(struct?: DataAwsSigningJob.SourceS3Property): any;
export declare function dataAwsSigningJobSourcePropertyToTerraform(struct?: DataAwsSigningJob.SourceProperty): any;
export declare function dataAwsSigningJobSourcePropertyToHclTerraform(struct?: DataAwsSigningJob.SourceProperty): any;
export declare namespace DataAwsSigningJob {
    interface RevocationRecordProperty {
    }
    class RevocationRecordPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RevocationRecordProperty | undefined;
        set internalValue(value: RevocationRecordProperty | undefined);
        get reason(): string;
        get revokedAt(): string;
        get revokedBy(): string;
    }
    class RevocationRecordPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RevocationRecordPropertyOutputReference;
    }
    interface SignedObjectS3Property {
    }
    class SignedObjectS3PropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SignedObjectS3Property | undefined;
        set internalValue(value: SignedObjectS3Property | undefined);
        get bucket(): string;
        get key(): string;
    }
    class SignedObjectS3PropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SignedObjectS3PropertyOutputReference;
    }
    interface SignedObjectProperty {
    }
    class SignedObjectPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SignedObjectProperty | undefined;
        set internalValue(value: SignedObjectProperty | undefined);
        private _s3;
        get s3(): SignedObjectS3PropertyList;
    }
    class SignedObjectPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SignedObjectPropertyOutputReference;
    }
    interface SourceS3Property {
    }
    class SourceS3PropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SourceS3Property | undefined;
        set internalValue(value: SourceS3Property | undefined);
        get bucket(): string;
        get key(): string;
        get version(): string;
    }
    class SourceS3PropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SourceS3PropertyOutputReference;
    }
    interface SourceProperty {
    }
    class SourcePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SourceProperty | undefined;
        set internalValue(value: SourceProperty | undefined);
        private _s3;
        get s3(): SourceS3PropertyList;
    }
    class SourcePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SourcePropertyOutputReference;
    }
}
