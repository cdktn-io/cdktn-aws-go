import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfPipeConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#description TfPipe#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#desired_state TfPipe#desired_state}
    */
    readonly desiredState?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#enrichment TfPipe#enrichment}
    */
    readonly enrichment?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#id TfPipe#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#kms_key_identifier TfPipe#kms_key_identifier}
    */
    readonly kmsKeyIdentifier?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#name TfPipe#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#name_prefix TfPipe#name_prefix}
    */
    readonly namePrefix?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#region TfPipe#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#role_arn TfPipe#role_arn}
    */
    readonly roleArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#source TfPipe#source}
    */
    readonly source: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#tags TfPipe#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#tags_all TfPipe#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#target TfPipe#target}
    */
    readonly target: string;
    /**
    * enrichment_parameters block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#enrichment_parameters TfPipe#enrichment_parameters}
    */
    readonly enrichmentParameters?: TfPipe.EnrichmentParametersProperty;
    /**
    * log_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#log_configuration TfPipe#log_configuration}
    */
    readonly logConfiguration?: TfPipe.LogConfigurationProperty;
    /**
    * source_parameters block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#source_parameters TfPipe#source_parameters}
    */
    readonly sourceParameters?: TfPipe.SourceParametersProperty;
    /**
    * target_parameters block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#target_parameters TfPipe#target_parameters}
    */
    readonly targetParameters?: TfPipe.TargetParametersProperty;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#timeouts TfPipe#timeouts}
    */
    readonly timeouts?: TfPipe.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe aws_pipes_pipe}
*/
export declare class TfPipe extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_pipes_pipe";
    /**
    * Generates CDKTN code for importing a TfPipe resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfPipe to import
    * @param importFromId The id of the existing TfPipe that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfPipe to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe aws_pipes_pipe} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfPipeConfig
    */
    constructor(scope: Construct, id: string, config: TfPipeConfig);
    get arn(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _desiredState?;
    get desiredState(): string;
    set desiredState(value: string);
    resetDesiredState(): void;
    get desiredStateInput(): string | undefined;
    private _enrichment?;
    get enrichment(): string;
    set enrichment(value: string);
    resetEnrichment(): void;
    get enrichmentInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _kmsKeyIdentifier?;
    get kmsKeyIdentifier(): string;
    set kmsKeyIdentifier(value: string);
    resetKmsKeyIdentifier(): void;
    get kmsKeyIdentifierInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _namePrefix?;
    get namePrefix(): string;
    set namePrefix(value: string);
    resetNamePrefix(): void;
    get namePrefixInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _roleArn?;
    get roleArn(): string;
    set roleArn(value: string);
    get roleArnInput(): string | undefined;
    private _source?;
    get source(): string;
    set source(value: string);
    get sourceInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _target?;
    get target(): string;
    set target(value: string);
    get targetInput(): string | undefined;
    private _enrichmentParameters;
    get enrichmentParameters(): TfPipe.EnrichmentParametersPropertyOutputReference;
    putEnrichmentParameters(value: TfPipe.EnrichmentParametersProperty): void;
    resetEnrichmentParameters(): void;
    get enrichmentParametersInput(): TfPipe.EnrichmentParametersProperty | undefined;
    private _logConfiguration;
    get logConfiguration(): TfPipe.LogConfigurationPropertyOutputReference;
    putLogConfiguration(value: TfPipe.LogConfigurationProperty): void;
    resetLogConfiguration(): void;
    get logConfigurationInput(): TfPipe.LogConfigurationProperty | undefined;
    private _sourceParameters;
    get sourceParameters(): TfPipe.SourceParametersPropertyOutputReference;
    putSourceParameters(value: TfPipe.SourceParametersProperty): void;
    resetSourceParameters(): void;
    get sourceParametersInput(): TfPipe.SourceParametersProperty | undefined;
    private _targetParameters;
    get targetParameters(): TfPipe.TargetParametersPropertyOutputReference;
    putTargetParameters(value: TfPipe.TargetParametersProperty): void;
    resetTargetParameters(): void;
    get targetParametersInput(): TfPipe.TargetParametersProperty | undefined;
    private _timeouts;
    get timeouts(): TfPipe.TimeoutsPropertyOutputReference;
    putTimeouts(value: TfPipe.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): TfPipe.TimeoutsProperty | cdktn.IResolvable | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfPipeEnrichmentParametersHttpParametersPropertyToTerraform(struct?: TfPipe.EnrichmentParametersHttpParametersPropertyOutputReference | TfPipe.EnrichmentParametersHttpParametersProperty): any;
export declare function tfPipeEnrichmentParametersHttpParametersPropertyToHclTerraform(struct?: TfPipe.EnrichmentParametersHttpParametersPropertyOutputReference | TfPipe.EnrichmentParametersHttpParametersProperty): any;
export declare function tfPipeEnrichmentParametersPropertyToTerraform(struct?: TfPipe.EnrichmentParametersPropertyOutputReference | TfPipe.EnrichmentParametersProperty): any;
export declare function tfPipeEnrichmentParametersPropertyToHclTerraform(struct?: TfPipe.EnrichmentParametersPropertyOutputReference | TfPipe.EnrichmentParametersProperty): any;
export declare function tfPipeCloudwatchLogsLogDestinationPropertyToTerraform(struct?: TfPipe.CloudwatchLogsLogDestinationPropertyOutputReference | TfPipe.CloudwatchLogsLogDestinationProperty): any;
export declare function tfPipeCloudwatchLogsLogDestinationPropertyToHclTerraform(struct?: TfPipe.CloudwatchLogsLogDestinationPropertyOutputReference | TfPipe.CloudwatchLogsLogDestinationProperty): any;
export declare function tfPipeFirehoseLogDestinationPropertyToTerraform(struct?: TfPipe.FirehoseLogDestinationPropertyOutputReference | TfPipe.FirehoseLogDestinationProperty): any;
export declare function tfPipeFirehoseLogDestinationPropertyToHclTerraform(struct?: TfPipe.FirehoseLogDestinationPropertyOutputReference | TfPipe.FirehoseLogDestinationProperty): any;
export declare function tfPipeS3LogDestinationPropertyToTerraform(struct?: TfPipe.S3LogDestinationPropertyOutputReference | TfPipe.S3LogDestinationProperty): any;
export declare function tfPipeS3LogDestinationPropertyToHclTerraform(struct?: TfPipe.S3LogDestinationPropertyOutputReference | TfPipe.S3LogDestinationProperty): any;
export declare function tfPipeLogConfigurationPropertyToTerraform(struct?: TfPipe.LogConfigurationPropertyOutputReference | TfPipe.LogConfigurationProperty): any;
export declare function tfPipeLogConfigurationPropertyToHclTerraform(struct?: TfPipe.LogConfigurationPropertyOutputReference | TfPipe.LogConfigurationProperty): any;
export declare function tfPipeSourceParametersActivemqBrokerParametersCredentialsPropertyToTerraform(struct?: TfPipe.SourceParametersActivemqBrokerParametersCredentialsPropertyOutputReference | TfPipe.SourceParametersActivemqBrokerParametersCredentialsProperty): any;
export declare function tfPipeSourceParametersActivemqBrokerParametersCredentialsPropertyToHclTerraform(struct?: TfPipe.SourceParametersActivemqBrokerParametersCredentialsPropertyOutputReference | TfPipe.SourceParametersActivemqBrokerParametersCredentialsProperty): any;
export declare function tfPipeActivemqBrokerParametersPropertyToTerraform(struct?: TfPipe.ActivemqBrokerParametersPropertyOutputReference | TfPipe.ActivemqBrokerParametersProperty): any;
export declare function tfPipeActivemqBrokerParametersPropertyToHclTerraform(struct?: TfPipe.ActivemqBrokerParametersPropertyOutputReference | TfPipe.ActivemqBrokerParametersProperty): any;
export declare function tfPipeSourceParametersDynamodbStreamParametersDeadLetterConfigPropertyToTerraform(struct?: TfPipe.SourceParametersDynamodbStreamParametersDeadLetterConfigPropertyOutputReference | TfPipe.SourceParametersDynamodbStreamParametersDeadLetterConfigProperty): any;
export declare function tfPipeSourceParametersDynamodbStreamParametersDeadLetterConfigPropertyToHclTerraform(struct?: TfPipe.SourceParametersDynamodbStreamParametersDeadLetterConfigPropertyOutputReference | TfPipe.SourceParametersDynamodbStreamParametersDeadLetterConfigProperty): any;
export declare function tfPipeDynamodbStreamParametersPropertyToTerraform(struct?: TfPipe.DynamodbStreamParametersPropertyOutputReference | TfPipe.DynamodbStreamParametersProperty): any;
export declare function tfPipeDynamodbStreamParametersPropertyToHclTerraform(struct?: TfPipe.DynamodbStreamParametersPropertyOutputReference | TfPipe.DynamodbStreamParametersProperty): any;
export declare function tfPipeFilterPropertyToTerraform(struct?: TfPipe.FilterProperty | cdktn.IResolvable): any;
export declare function tfPipeFilterPropertyToHclTerraform(struct?: TfPipe.FilterProperty | cdktn.IResolvable): any;
export declare function tfPipeFilterCriteriaPropertyToTerraform(struct?: TfPipe.FilterCriteriaPropertyOutputReference | TfPipe.FilterCriteriaProperty): any;
export declare function tfPipeFilterCriteriaPropertyToHclTerraform(struct?: TfPipe.FilterCriteriaPropertyOutputReference | TfPipe.FilterCriteriaProperty): any;
export declare function tfPipeSourceParametersKinesisStreamParametersDeadLetterConfigPropertyToTerraform(struct?: TfPipe.SourceParametersKinesisStreamParametersDeadLetterConfigPropertyOutputReference | TfPipe.SourceParametersKinesisStreamParametersDeadLetterConfigProperty): any;
export declare function tfPipeSourceParametersKinesisStreamParametersDeadLetterConfigPropertyToHclTerraform(struct?: TfPipe.SourceParametersKinesisStreamParametersDeadLetterConfigPropertyOutputReference | TfPipe.SourceParametersKinesisStreamParametersDeadLetterConfigProperty): any;
export declare function tfPipeSourceParametersKinesisStreamParametersPropertyToTerraform(struct?: TfPipe.SourceParametersKinesisStreamParametersPropertyOutputReference | TfPipe.SourceParametersKinesisStreamParametersProperty): any;
export declare function tfPipeSourceParametersKinesisStreamParametersPropertyToHclTerraform(struct?: TfPipe.SourceParametersKinesisStreamParametersPropertyOutputReference | TfPipe.SourceParametersKinesisStreamParametersProperty): any;
export declare function tfPipeSourceParametersManagedStreamingKafkaParametersCredentialsPropertyToTerraform(struct?: TfPipe.SourceParametersManagedStreamingKafkaParametersCredentialsPropertyOutputReference | TfPipe.SourceParametersManagedStreamingKafkaParametersCredentialsProperty): any;
export declare function tfPipeSourceParametersManagedStreamingKafkaParametersCredentialsPropertyToHclTerraform(struct?: TfPipe.SourceParametersManagedStreamingKafkaParametersCredentialsPropertyOutputReference | TfPipe.SourceParametersManagedStreamingKafkaParametersCredentialsProperty): any;
export declare function tfPipeManagedStreamingKafkaParametersPropertyToTerraform(struct?: TfPipe.ManagedStreamingKafkaParametersPropertyOutputReference | TfPipe.ManagedStreamingKafkaParametersProperty): any;
export declare function tfPipeManagedStreamingKafkaParametersPropertyToHclTerraform(struct?: TfPipe.ManagedStreamingKafkaParametersPropertyOutputReference | TfPipe.ManagedStreamingKafkaParametersProperty): any;
export declare function tfPipeSourceParametersRabbitmqBrokerParametersCredentialsPropertyToTerraform(struct?: TfPipe.SourceParametersRabbitmqBrokerParametersCredentialsPropertyOutputReference | TfPipe.SourceParametersRabbitmqBrokerParametersCredentialsProperty): any;
export declare function tfPipeSourceParametersRabbitmqBrokerParametersCredentialsPropertyToHclTerraform(struct?: TfPipe.SourceParametersRabbitmqBrokerParametersCredentialsPropertyOutputReference | TfPipe.SourceParametersRabbitmqBrokerParametersCredentialsProperty): any;
export declare function tfPipeRabbitmqBrokerParametersPropertyToTerraform(struct?: TfPipe.RabbitmqBrokerParametersPropertyOutputReference | TfPipe.RabbitmqBrokerParametersProperty): any;
export declare function tfPipeRabbitmqBrokerParametersPropertyToHclTerraform(struct?: TfPipe.RabbitmqBrokerParametersPropertyOutputReference | TfPipe.RabbitmqBrokerParametersProperty): any;
export declare function tfPipeSourceParametersSelfManagedKafkaParametersCredentialsPropertyToTerraform(struct?: TfPipe.SourceParametersSelfManagedKafkaParametersCredentialsPropertyOutputReference | TfPipe.SourceParametersSelfManagedKafkaParametersCredentialsProperty): any;
export declare function tfPipeSourceParametersSelfManagedKafkaParametersCredentialsPropertyToHclTerraform(struct?: TfPipe.SourceParametersSelfManagedKafkaParametersCredentialsPropertyOutputReference | TfPipe.SourceParametersSelfManagedKafkaParametersCredentialsProperty): any;
export declare function tfPipeVpcPropertyToTerraform(struct?: TfPipe.VpcPropertyOutputReference | TfPipe.VpcProperty): any;
export declare function tfPipeVpcPropertyToHclTerraform(struct?: TfPipe.VpcPropertyOutputReference | TfPipe.VpcProperty): any;
export declare function tfPipeSelfManagedKafkaParametersPropertyToTerraform(struct?: TfPipe.SelfManagedKafkaParametersPropertyOutputReference | TfPipe.SelfManagedKafkaParametersProperty): any;
export declare function tfPipeSelfManagedKafkaParametersPropertyToHclTerraform(struct?: TfPipe.SelfManagedKafkaParametersPropertyOutputReference | TfPipe.SelfManagedKafkaParametersProperty): any;
export declare function tfPipeSourceParametersSqsQueueParametersPropertyToTerraform(struct?: TfPipe.SourceParametersSqsQueueParametersPropertyOutputReference | TfPipe.SourceParametersSqsQueueParametersProperty): any;
export declare function tfPipeSourceParametersSqsQueueParametersPropertyToHclTerraform(struct?: TfPipe.SourceParametersSqsQueueParametersPropertyOutputReference | TfPipe.SourceParametersSqsQueueParametersProperty): any;
export declare function tfPipeSourceParametersPropertyToTerraform(struct?: TfPipe.SourceParametersPropertyOutputReference | TfPipe.SourceParametersProperty): any;
export declare function tfPipeSourceParametersPropertyToHclTerraform(struct?: TfPipe.SourceParametersPropertyOutputReference | TfPipe.SourceParametersProperty): any;
export declare function tfPipeArrayPropertiesPropertyToTerraform(struct?: TfPipe.ArrayPropertiesPropertyOutputReference | TfPipe.ArrayPropertiesProperty): any;
export declare function tfPipeArrayPropertiesPropertyToHclTerraform(struct?: TfPipe.ArrayPropertiesPropertyOutputReference | TfPipe.ArrayPropertiesProperty): any;
export declare function tfPipeTargetParametersBatchJobParametersContainerOverridesEnvironmentPropertyToTerraform(struct?: TfPipe.TargetParametersBatchJobParametersContainerOverridesEnvironmentProperty | cdktn.IResolvable): any;
export declare function tfPipeTargetParametersBatchJobParametersContainerOverridesEnvironmentPropertyToHclTerraform(struct?: TfPipe.TargetParametersBatchJobParametersContainerOverridesEnvironmentProperty | cdktn.IResolvable): any;
export declare function tfPipeTargetParametersBatchJobParametersContainerOverridesResourceRequirementPropertyToTerraform(struct?: TfPipe.TargetParametersBatchJobParametersContainerOverridesResourceRequirementProperty | cdktn.IResolvable): any;
export declare function tfPipeTargetParametersBatchJobParametersContainerOverridesResourceRequirementPropertyToHclTerraform(struct?: TfPipe.TargetParametersBatchJobParametersContainerOverridesResourceRequirementProperty | cdktn.IResolvable): any;
export declare function tfPipeContainerOverridesPropertyToTerraform(struct?: TfPipe.ContainerOverridesPropertyOutputReference | TfPipe.ContainerOverridesProperty): any;
export declare function tfPipeContainerOverridesPropertyToHclTerraform(struct?: TfPipe.ContainerOverridesPropertyOutputReference | TfPipe.ContainerOverridesProperty): any;
export declare function tfPipeDependsOnPropertyToTerraform(struct?: TfPipe.DependsOnProperty | cdktn.IResolvable): any;
export declare function tfPipeDependsOnPropertyToHclTerraform(struct?: TfPipe.DependsOnProperty | cdktn.IResolvable): any;
export declare function tfPipeRetryStrategyPropertyToTerraform(struct?: TfPipe.RetryStrategyPropertyOutputReference | TfPipe.RetryStrategyProperty): any;
export declare function tfPipeRetryStrategyPropertyToHclTerraform(struct?: TfPipe.RetryStrategyPropertyOutputReference | TfPipe.RetryStrategyProperty): any;
export declare function tfPipeBatchJobParametersPropertyToTerraform(struct?: TfPipe.BatchJobParametersPropertyOutputReference | TfPipe.BatchJobParametersProperty): any;
export declare function tfPipeBatchJobParametersPropertyToHclTerraform(struct?: TfPipe.BatchJobParametersPropertyOutputReference | TfPipe.BatchJobParametersProperty): any;
export declare function tfPipeCloudwatchLogsParametersPropertyToTerraform(struct?: TfPipe.CloudwatchLogsParametersPropertyOutputReference | TfPipe.CloudwatchLogsParametersProperty): any;
export declare function tfPipeCloudwatchLogsParametersPropertyToHclTerraform(struct?: TfPipe.CloudwatchLogsParametersPropertyOutputReference | TfPipe.CloudwatchLogsParametersProperty): any;
export declare function tfPipeCapacityProviderStrategyPropertyToTerraform(struct?: TfPipe.CapacityProviderStrategyProperty | cdktn.IResolvable): any;
export declare function tfPipeCapacityProviderStrategyPropertyToHclTerraform(struct?: TfPipe.CapacityProviderStrategyProperty | cdktn.IResolvable): any;
export declare function tfPipeAwsVpcConfigurationPropertyToTerraform(struct?: TfPipe.AwsVpcConfigurationPropertyOutputReference | TfPipe.AwsVpcConfigurationProperty): any;
export declare function tfPipeAwsVpcConfigurationPropertyToHclTerraform(struct?: TfPipe.AwsVpcConfigurationPropertyOutputReference | TfPipe.AwsVpcConfigurationProperty): any;
export declare function tfPipeNetworkConfigurationPropertyToTerraform(struct?: TfPipe.NetworkConfigurationPropertyOutputReference | TfPipe.NetworkConfigurationProperty): any;
export declare function tfPipeNetworkConfigurationPropertyToHclTerraform(struct?: TfPipe.NetworkConfigurationPropertyOutputReference | TfPipe.NetworkConfigurationProperty): any;
export declare function tfPipeTargetParametersEcsTaskParametersOverridesContainerOverrideEnvironmentPropertyToTerraform(struct?: TfPipe.TargetParametersEcsTaskParametersOverridesContainerOverrideEnvironmentProperty | cdktn.IResolvable): any;
export declare function tfPipeTargetParametersEcsTaskParametersOverridesContainerOverrideEnvironmentPropertyToHclTerraform(struct?: TfPipe.TargetParametersEcsTaskParametersOverridesContainerOverrideEnvironmentProperty | cdktn.IResolvable): any;
export declare function tfPipeEnvironmentFilePropertyToTerraform(struct?: TfPipe.EnvironmentFileProperty | cdktn.IResolvable): any;
export declare function tfPipeEnvironmentFilePropertyToHclTerraform(struct?: TfPipe.EnvironmentFileProperty | cdktn.IResolvable): any;
export declare function tfPipeTargetParametersEcsTaskParametersOverridesContainerOverrideResourceRequirementPropertyToTerraform(struct?: TfPipe.TargetParametersEcsTaskParametersOverridesContainerOverrideResourceRequirementProperty | cdktn.IResolvable): any;
export declare function tfPipeTargetParametersEcsTaskParametersOverridesContainerOverrideResourceRequirementPropertyToHclTerraform(struct?: TfPipe.TargetParametersEcsTaskParametersOverridesContainerOverrideResourceRequirementProperty | cdktn.IResolvable): any;
export declare function tfPipeContainerOverridePropertyToTerraform(struct?: TfPipe.ContainerOverrideProperty | cdktn.IResolvable): any;
export declare function tfPipeContainerOverridePropertyToHclTerraform(struct?: TfPipe.ContainerOverrideProperty | cdktn.IResolvable): any;
export declare function tfPipeEphemeralStoragePropertyToTerraform(struct?: TfPipe.EphemeralStoragePropertyOutputReference | TfPipe.EphemeralStorageProperty): any;
export declare function tfPipeEphemeralStoragePropertyToHclTerraform(struct?: TfPipe.EphemeralStoragePropertyOutputReference | TfPipe.EphemeralStorageProperty): any;
export declare function tfPipeInferenceAcceleratorOverridePropertyToTerraform(struct?: TfPipe.InferenceAcceleratorOverrideProperty | cdktn.IResolvable): any;
export declare function tfPipeInferenceAcceleratorOverridePropertyToHclTerraform(struct?: TfPipe.InferenceAcceleratorOverrideProperty | cdktn.IResolvable): any;
export declare function tfPipeOverridesPropertyToTerraform(struct?: TfPipe.OverridesPropertyOutputReference | TfPipe.OverridesProperty): any;
export declare function tfPipeOverridesPropertyToHclTerraform(struct?: TfPipe.OverridesPropertyOutputReference | TfPipe.OverridesProperty): any;
export declare function tfPipePlacementConstraintPropertyToTerraform(struct?: TfPipe.PlacementConstraintProperty | cdktn.IResolvable): any;
export declare function tfPipePlacementConstraintPropertyToHclTerraform(struct?: TfPipe.PlacementConstraintProperty | cdktn.IResolvable): any;
export declare function tfPipePlacementStrategyPropertyToTerraform(struct?: TfPipe.PlacementStrategyProperty | cdktn.IResolvable): any;
export declare function tfPipePlacementStrategyPropertyToHclTerraform(struct?: TfPipe.PlacementStrategyProperty | cdktn.IResolvable): any;
export declare function tfPipeEcsTaskParametersPropertyToTerraform(struct?: TfPipe.EcsTaskParametersPropertyOutputReference | TfPipe.EcsTaskParametersProperty): any;
export declare function tfPipeEcsTaskParametersPropertyToHclTerraform(struct?: TfPipe.EcsTaskParametersPropertyOutputReference | TfPipe.EcsTaskParametersProperty): any;
export declare function tfPipeEventbridgeEventBusParametersPropertyToTerraform(struct?: TfPipe.EventbridgeEventBusParametersPropertyOutputReference | TfPipe.EventbridgeEventBusParametersProperty): any;
export declare function tfPipeEventbridgeEventBusParametersPropertyToHclTerraform(struct?: TfPipe.EventbridgeEventBusParametersPropertyOutputReference | TfPipe.EventbridgeEventBusParametersProperty): any;
export declare function tfPipeTargetParametersHttpParametersPropertyToTerraform(struct?: TfPipe.TargetParametersHttpParametersPropertyOutputReference | TfPipe.TargetParametersHttpParametersProperty): any;
export declare function tfPipeTargetParametersHttpParametersPropertyToHclTerraform(struct?: TfPipe.TargetParametersHttpParametersPropertyOutputReference | TfPipe.TargetParametersHttpParametersProperty): any;
export declare function tfPipeTargetParametersKinesisStreamParametersPropertyToTerraform(struct?: TfPipe.TargetParametersKinesisStreamParametersPropertyOutputReference | TfPipe.TargetParametersKinesisStreamParametersProperty): any;
export declare function tfPipeTargetParametersKinesisStreamParametersPropertyToHclTerraform(struct?: TfPipe.TargetParametersKinesisStreamParametersPropertyOutputReference | TfPipe.TargetParametersKinesisStreamParametersProperty): any;
export declare function tfPipeLambdaFunctionParametersPropertyToTerraform(struct?: TfPipe.LambdaFunctionParametersPropertyOutputReference | TfPipe.LambdaFunctionParametersProperty): any;
export declare function tfPipeLambdaFunctionParametersPropertyToHclTerraform(struct?: TfPipe.LambdaFunctionParametersPropertyOutputReference | TfPipe.LambdaFunctionParametersProperty): any;
export declare function tfPipeRedshiftDataParametersPropertyToTerraform(struct?: TfPipe.RedshiftDataParametersPropertyOutputReference | TfPipe.RedshiftDataParametersProperty): any;
export declare function tfPipeRedshiftDataParametersPropertyToHclTerraform(struct?: TfPipe.RedshiftDataParametersPropertyOutputReference | TfPipe.RedshiftDataParametersProperty): any;
export declare function tfPipePipelineParameterPropertyToTerraform(struct?: TfPipe.PipelineParameterProperty | cdktn.IResolvable): any;
export declare function tfPipePipelineParameterPropertyToHclTerraform(struct?: TfPipe.PipelineParameterProperty | cdktn.IResolvable): any;
export declare function tfPipeSagemakerPipelineParametersPropertyToTerraform(struct?: TfPipe.SagemakerPipelineParametersPropertyOutputReference | TfPipe.SagemakerPipelineParametersProperty): any;
export declare function tfPipeSagemakerPipelineParametersPropertyToHclTerraform(struct?: TfPipe.SagemakerPipelineParametersPropertyOutputReference | TfPipe.SagemakerPipelineParametersProperty): any;
export declare function tfPipeTargetParametersSqsQueueParametersPropertyToTerraform(struct?: TfPipe.TargetParametersSqsQueueParametersPropertyOutputReference | TfPipe.TargetParametersSqsQueueParametersProperty): any;
export declare function tfPipeTargetParametersSqsQueueParametersPropertyToHclTerraform(struct?: TfPipe.TargetParametersSqsQueueParametersPropertyOutputReference | TfPipe.TargetParametersSqsQueueParametersProperty): any;
export declare function tfPipeStepFunctionStateMachineParametersPropertyToTerraform(struct?: TfPipe.StepFunctionStateMachineParametersPropertyOutputReference | TfPipe.StepFunctionStateMachineParametersProperty): any;
export declare function tfPipeStepFunctionStateMachineParametersPropertyToHclTerraform(struct?: TfPipe.StepFunctionStateMachineParametersPropertyOutputReference | TfPipe.StepFunctionStateMachineParametersProperty): any;
export declare function tfPipeTargetParametersPropertyToTerraform(struct?: TfPipe.TargetParametersPropertyOutputReference | TfPipe.TargetParametersProperty): any;
export declare function tfPipeTargetParametersPropertyToHclTerraform(struct?: TfPipe.TargetParametersPropertyOutputReference | TfPipe.TargetParametersProperty): any;
export declare function tfPipeTimeoutsPropertyToTerraform(struct?: TfPipe.TimeoutsProperty | cdktn.IResolvable): any;
export declare function tfPipeTimeoutsPropertyToHclTerraform(struct?: TfPipe.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace TfPipe {
    interface EnrichmentParametersHttpParametersProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#header_parameters TfPipe#header_parameters}
        */
        readonly headerParameters?: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#path_parameter_values TfPipe#path_parameter_values}
        */
        readonly pathParameterValues?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#query_string_parameters TfPipe#query_string_parameters}
        */
        readonly queryStringParameters?: {
            [key: string]: string;
        };
    }
    class EnrichmentParametersHttpParametersPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): EnrichmentParametersHttpParametersProperty | undefined;
        set internalValue(value: EnrichmentParametersHttpParametersProperty | undefined);
        private _headerParameters?;
        get headerParameters(): {
            [key: string]: string;
        };
        set headerParameters(value: {
            [key: string]: string;
        });
        resetHeaderParameters(): void;
        get headerParametersInput(): {
            [key: string]: string;
        } | undefined;
        private _pathParameterValues?;
        get pathParameterValues(): string[];
        set pathParameterValues(value: string[]);
        resetPathParameterValues(): void;
        get pathParameterValuesInput(): string[] | undefined;
        private _queryStringParameters?;
        get queryStringParameters(): {
            [key: string]: string;
        };
        set queryStringParameters(value: {
            [key: string]: string;
        });
        resetQueryStringParameters(): void;
        get queryStringParametersInput(): {
            [key: string]: string;
        } | undefined;
    }
    interface EnrichmentParametersProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#input_template TfPipe#input_template}
        */
        readonly inputTemplate?: string;
        /**
        * http_parameters block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#http_parameters TfPipe#http_parameters}
        */
        readonly httpParameters?: EnrichmentParametersHttpParametersProperty;
    }
    class EnrichmentParametersPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): EnrichmentParametersProperty | undefined;
        set internalValue(value: EnrichmentParametersProperty | undefined);
        private _inputTemplate?;
        get inputTemplate(): string;
        set inputTemplate(value: string);
        resetInputTemplate(): void;
        get inputTemplateInput(): string | undefined;
        private _httpParameters;
        get httpParameters(): EnrichmentParametersHttpParametersPropertyOutputReference;
        putHttpParameters(value: EnrichmentParametersHttpParametersProperty): void;
        resetHttpParameters(): void;
        get httpParametersInput(): EnrichmentParametersHttpParametersProperty | undefined;
    }
    interface CloudwatchLogsLogDestinationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#log_group_arn TfPipe#log_group_arn}
        */
        readonly logGroupArn: string;
    }
    class CloudwatchLogsLogDestinationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CloudwatchLogsLogDestinationProperty | undefined;
        set internalValue(value: CloudwatchLogsLogDestinationProperty | undefined);
        private _logGroupArn?;
        get logGroupArn(): string;
        set logGroupArn(value: string);
        get logGroupArnInput(): string | undefined;
    }
    interface FirehoseLogDestinationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#delivery_stream_arn TfPipe#delivery_stream_arn}
        */
        readonly deliveryStreamArn: string;
    }
    class FirehoseLogDestinationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): FirehoseLogDestinationProperty | undefined;
        set internalValue(value: FirehoseLogDestinationProperty | undefined);
        private _deliveryStreamArn?;
        get deliveryStreamArn(): string;
        set deliveryStreamArn(value: string);
        get deliveryStreamArnInput(): string | undefined;
    }
    interface S3LogDestinationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#bucket_name TfPipe#bucket_name}
        */
        readonly bucketName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#bucket_owner TfPipe#bucket_owner}
        */
        readonly bucketOwner: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#output_format TfPipe#output_format}
        */
        readonly outputFormat?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#prefix TfPipe#prefix}
        */
        readonly prefix?: string;
    }
    class S3LogDestinationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): S3LogDestinationProperty | undefined;
        set internalValue(value: S3LogDestinationProperty | undefined);
        private _bucketName?;
        get bucketName(): string;
        set bucketName(value: string);
        get bucketNameInput(): string | undefined;
        private _bucketOwner?;
        get bucketOwner(): string;
        set bucketOwner(value: string);
        get bucketOwnerInput(): string | undefined;
        private _outputFormat?;
        get outputFormat(): string;
        set outputFormat(value: string);
        resetOutputFormat(): void;
        get outputFormatInput(): string | undefined;
        private _prefix?;
        get prefix(): string;
        set prefix(value: string);
        resetPrefix(): void;
        get prefixInput(): string | undefined;
    }
    interface LogConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#include_execution_data TfPipe#include_execution_data}
        */
        readonly includeExecutionData?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#level TfPipe#level}
        */
        readonly level: string;
        /**
        * cloudwatch_logs_log_destination block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#cloudwatch_logs_log_destination TfPipe#cloudwatch_logs_log_destination}
        */
        readonly cloudwatchLogsLogDestination?: CloudwatchLogsLogDestinationProperty;
        /**
        * firehose_log_destination block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#firehose_log_destination TfPipe#firehose_log_destination}
        */
        readonly firehoseLogDestination?: FirehoseLogDestinationProperty;
        /**
        * s3_log_destination block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#s3_log_destination TfPipe#s3_log_destination}
        */
        readonly s3LogDestination?: S3LogDestinationProperty;
    }
    class LogConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): LogConfigurationProperty | undefined;
        set internalValue(value: LogConfigurationProperty | undefined);
        private _includeExecutionData?;
        get includeExecutionData(): string[];
        set includeExecutionData(value: string[]);
        resetIncludeExecutionData(): void;
        get includeExecutionDataInput(): string[] | undefined;
        private _level?;
        get level(): string;
        set level(value: string);
        get levelInput(): string | undefined;
        private _cloudwatchLogsLogDestination;
        get cloudwatchLogsLogDestination(): CloudwatchLogsLogDestinationPropertyOutputReference;
        putCloudwatchLogsLogDestination(value: CloudwatchLogsLogDestinationProperty): void;
        resetCloudwatchLogsLogDestination(): void;
        get cloudwatchLogsLogDestinationInput(): CloudwatchLogsLogDestinationProperty | undefined;
        private _firehoseLogDestination;
        get firehoseLogDestination(): FirehoseLogDestinationPropertyOutputReference;
        putFirehoseLogDestination(value: FirehoseLogDestinationProperty): void;
        resetFirehoseLogDestination(): void;
        get firehoseLogDestinationInput(): FirehoseLogDestinationProperty | undefined;
        private _s3LogDestination;
        get s3LogDestination(): S3LogDestinationPropertyOutputReference;
        putS3LogDestination(value: S3LogDestinationProperty): void;
        resetS3LogDestination(): void;
        get s3LogDestinationInput(): S3LogDestinationProperty | undefined;
    }
    interface SourceParametersActivemqBrokerParametersCredentialsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#basic_auth TfPipe#basic_auth}
        */
        readonly basicAuth: string;
    }
    class SourceParametersActivemqBrokerParametersCredentialsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SourceParametersActivemqBrokerParametersCredentialsProperty | undefined;
        set internalValue(value: SourceParametersActivemqBrokerParametersCredentialsProperty | undefined);
        private _basicAuth?;
        get basicAuth(): string;
        set basicAuth(value: string);
        get basicAuthInput(): string | undefined;
    }
    interface ActivemqBrokerParametersProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#batch_size TfPipe#batch_size}
        */
        readonly batchSize?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#maximum_batching_window_in_seconds TfPipe#maximum_batching_window_in_seconds}
        */
        readonly maximumBatchingWindowInSeconds?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#queue_name TfPipe#queue_name}
        */
        readonly queueName: string;
        /**
        * credentials block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#credentials TfPipe#credentials}
        */
        readonly credentials: SourceParametersActivemqBrokerParametersCredentialsProperty;
    }
    class ActivemqBrokerParametersPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ActivemqBrokerParametersProperty | undefined;
        set internalValue(value: ActivemqBrokerParametersProperty | undefined);
        private _batchSize?;
        get batchSize(): number;
        set batchSize(value: number);
        resetBatchSize(): void;
        get batchSizeInput(): number | undefined;
        private _maximumBatchingWindowInSeconds?;
        get maximumBatchingWindowInSeconds(): number;
        set maximumBatchingWindowInSeconds(value: number);
        resetMaximumBatchingWindowInSeconds(): void;
        get maximumBatchingWindowInSecondsInput(): number | undefined;
        private _queueName?;
        get queueName(): string;
        set queueName(value: string);
        get queueNameInput(): string | undefined;
        private _credentials;
        get credentials(): SourceParametersActivemqBrokerParametersCredentialsPropertyOutputReference;
        putCredentials(value: SourceParametersActivemqBrokerParametersCredentialsProperty): void;
        get credentialsInput(): SourceParametersActivemqBrokerParametersCredentialsProperty | undefined;
    }
    interface SourceParametersDynamodbStreamParametersDeadLetterConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#arn TfPipe#arn}
        */
        readonly arn?: string;
    }
    class SourceParametersDynamodbStreamParametersDeadLetterConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SourceParametersDynamodbStreamParametersDeadLetterConfigProperty | undefined;
        set internalValue(value: SourceParametersDynamodbStreamParametersDeadLetterConfigProperty | undefined);
        private _arn?;
        get arn(): string;
        set arn(value: string);
        resetArn(): void;
        get arnInput(): string | undefined;
    }
    interface DynamodbStreamParametersProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#batch_size TfPipe#batch_size}
        */
        readonly batchSize?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#maximum_batching_window_in_seconds TfPipe#maximum_batching_window_in_seconds}
        */
        readonly maximumBatchingWindowInSeconds?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#maximum_record_age_in_seconds TfPipe#maximum_record_age_in_seconds}
        */
        readonly maximumRecordAgeInSeconds?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#maximum_retry_attempts TfPipe#maximum_retry_attempts}
        */
        readonly maximumRetryAttempts?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#on_partial_batch_item_failure TfPipe#on_partial_batch_item_failure}
        */
        readonly onPartialBatchItemFailure?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#parallelization_factor TfPipe#parallelization_factor}
        */
        readonly parallelizationFactor?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#starting_position TfPipe#starting_position}
        */
        readonly startingPosition: string;
        /**
        * dead_letter_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#dead_letter_config TfPipe#dead_letter_config}
        */
        readonly deadLetterConfig?: SourceParametersDynamodbStreamParametersDeadLetterConfigProperty;
    }
    class DynamodbStreamParametersPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DynamodbStreamParametersProperty | undefined;
        set internalValue(value: DynamodbStreamParametersProperty | undefined);
        private _batchSize?;
        get batchSize(): number;
        set batchSize(value: number);
        resetBatchSize(): void;
        get batchSizeInput(): number | undefined;
        private _maximumBatchingWindowInSeconds?;
        get maximumBatchingWindowInSeconds(): number;
        set maximumBatchingWindowInSeconds(value: number);
        resetMaximumBatchingWindowInSeconds(): void;
        get maximumBatchingWindowInSecondsInput(): number | undefined;
        private _maximumRecordAgeInSeconds?;
        get maximumRecordAgeInSeconds(): number;
        set maximumRecordAgeInSeconds(value: number);
        resetMaximumRecordAgeInSeconds(): void;
        get maximumRecordAgeInSecondsInput(): number | undefined;
        private _maximumRetryAttempts?;
        get maximumRetryAttempts(): number;
        set maximumRetryAttempts(value: number);
        resetMaximumRetryAttempts(): void;
        get maximumRetryAttemptsInput(): number | undefined;
        private _onPartialBatchItemFailure?;
        get onPartialBatchItemFailure(): string;
        set onPartialBatchItemFailure(value: string);
        resetOnPartialBatchItemFailure(): void;
        get onPartialBatchItemFailureInput(): string | undefined;
        private _parallelizationFactor?;
        get parallelizationFactor(): number;
        set parallelizationFactor(value: number);
        resetParallelizationFactor(): void;
        get parallelizationFactorInput(): number | undefined;
        private _startingPosition?;
        get startingPosition(): string;
        set startingPosition(value: string);
        get startingPositionInput(): string | undefined;
        private _deadLetterConfig;
        get deadLetterConfig(): SourceParametersDynamodbStreamParametersDeadLetterConfigPropertyOutputReference;
        putDeadLetterConfig(value: SourceParametersDynamodbStreamParametersDeadLetterConfigProperty): void;
        resetDeadLetterConfig(): void;
        get deadLetterConfigInput(): SourceParametersDynamodbStreamParametersDeadLetterConfigProperty | undefined;
    }
    interface FilterProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#pattern TfPipe#pattern}
        */
        readonly pattern: string;
    }
    class FilterPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): FilterProperty | cdktn.IResolvable | undefined;
        set internalValue(value: FilterProperty | cdktn.IResolvable | undefined);
        private _pattern?;
        get pattern(): string;
        set pattern(value: string);
        get patternInput(): string | undefined;
    }
    class FilterPropertyList extends cdktn.ComplexList {
        internalValue?: FilterProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): FilterPropertyOutputReference;
    }
    interface FilterCriteriaProperty {
        /**
        * filter block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#filter TfPipe#filter}
        */
        readonly filter?: FilterProperty[] | cdktn.IResolvable;
    }
    class FilterCriteriaPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): FilterCriteriaProperty | undefined;
        set internalValue(value: FilterCriteriaProperty | undefined);
        private _filter;
        get filter(): FilterPropertyList;
        putFilter(value: FilterProperty[] | cdktn.IResolvable): void;
        resetFilter(): void;
        get filterInput(): cdktn.IResolvable | FilterProperty[] | undefined;
    }
    interface SourceParametersKinesisStreamParametersDeadLetterConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#arn TfPipe#arn}
        */
        readonly arn?: string;
    }
    class SourceParametersKinesisStreamParametersDeadLetterConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SourceParametersKinesisStreamParametersDeadLetterConfigProperty | undefined;
        set internalValue(value: SourceParametersKinesisStreamParametersDeadLetterConfigProperty | undefined);
        private _arn?;
        get arn(): string;
        set arn(value: string);
        resetArn(): void;
        get arnInput(): string | undefined;
    }
    interface SourceParametersKinesisStreamParametersProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#batch_size TfPipe#batch_size}
        */
        readonly batchSize?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#maximum_batching_window_in_seconds TfPipe#maximum_batching_window_in_seconds}
        */
        readonly maximumBatchingWindowInSeconds?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#maximum_record_age_in_seconds TfPipe#maximum_record_age_in_seconds}
        */
        readonly maximumRecordAgeInSeconds?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#maximum_retry_attempts TfPipe#maximum_retry_attempts}
        */
        readonly maximumRetryAttempts?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#on_partial_batch_item_failure TfPipe#on_partial_batch_item_failure}
        */
        readonly onPartialBatchItemFailure?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#parallelization_factor TfPipe#parallelization_factor}
        */
        readonly parallelizationFactor?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#starting_position TfPipe#starting_position}
        */
        readonly startingPosition: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#starting_position_timestamp TfPipe#starting_position_timestamp}
        */
        readonly startingPositionTimestamp?: string;
        /**
        * dead_letter_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#dead_letter_config TfPipe#dead_letter_config}
        */
        readonly deadLetterConfig?: SourceParametersKinesisStreamParametersDeadLetterConfigProperty;
    }
    class SourceParametersKinesisStreamParametersPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SourceParametersKinesisStreamParametersProperty | undefined;
        set internalValue(value: SourceParametersKinesisStreamParametersProperty | undefined);
        private _batchSize?;
        get batchSize(): number;
        set batchSize(value: number);
        resetBatchSize(): void;
        get batchSizeInput(): number | undefined;
        private _maximumBatchingWindowInSeconds?;
        get maximumBatchingWindowInSeconds(): number;
        set maximumBatchingWindowInSeconds(value: number);
        resetMaximumBatchingWindowInSeconds(): void;
        get maximumBatchingWindowInSecondsInput(): number | undefined;
        private _maximumRecordAgeInSeconds?;
        get maximumRecordAgeInSeconds(): number;
        set maximumRecordAgeInSeconds(value: number);
        resetMaximumRecordAgeInSeconds(): void;
        get maximumRecordAgeInSecondsInput(): number | undefined;
        private _maximumRetryAttempts?;
        get maximumRetryAttempts(): number;
        set maximumRetryAttempts(value: number);
        resetMaximumRetryAttempts(): void;
        get maximumRetryAttemptsInput(): number | undefined;
        private _onPartialBatchItemFailure?;
        get onPartialBatchItemFailure(): string;
        set onPartialBatchItemFailure(value: string);
        resetOnPartialBatchItemFailure(): void;
        get onPartialBatchItemFailureInput(): string | undefined;
        private _parallelizationFactor?;
        get parallelizationFactor(): number;
        set parallelizationFactor(value: number);
        resetParallelizationFactor(): void;
        get parallelizationFactorInput(): number | undefined;
        private _startingPosition?;
        get startingPosition(): string;
        set startingPosition(value: string);
        get startingPositionInput(): string | undefined;
        private _startingPositionTimestamp?;
        get startingPositionTimestamp(): string;
        set startingPositionTimestamp(value: string);
        resetStartingPositionTimestamp(): void;
        get startingPositionTimestampInput(): string | undefined;
        private _deadLetterConfig;
        get deadLetterConfig(): SourceParametersKinesisStreamParametersDeadLetterConfigPropertyOutputReference;
        putDeadLetterConfig(value: SourceParametersKinesisStreamParametersDeadLetterConfigProperty): void;
        resetDeadLetterConfig(): void;
        get deadLetterConfigInput(): SourceParametersKinesisStreamParametersDeadLetterConfigProperty | undefined;
    }
    interface SourceParametersManagedStreamingKafkaParametersCredentialsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#client_certificate_tls_auth TfPipe#client_certificate_tls_auth}
        */
        readonly clientCertificateTlsAuth?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#sasl_scram_512_auth TfPipe#sasl_scram_512_auth}
        */
        readonly saslScram512Auth?: string;
    }
    class SourceParametersManagedStreamingKafkaParametersCredentialsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SourceParametersManagedStreamingKafkaParametersCredentialsProperty | undefined;
        set internalValue(value: SourceParametersManagedStreamingKafkaParametersCredentialsProperty | undefined);
        private _clientCertificateTlsAuth?;
        get clientCertificateTlsAuth(): string;
        set clientCertificateTlsAuth(value: string);
        resetClientCertificateTlsAuth(): void;
        get clientCertificateTlsAuthInput(): string | undefined;
        private _saslScram512Auth?;
        get saslScram512Auth(): string;
        set saslScram512Auth(value: string);
        resetSaslScram512Auth(): void;
        get saslScram512AuthInput(): string | undefined;
    }
    interface ManagedStreamingKafkaParametersProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#batch_size TfPipe#batch_size}
        */
        readonly batchSize?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#consumer_group_id TfPipe#consumer_group_id}
        */
        readonly consumerGroupId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#maximum_batching_window_in_seconds TfPipe#maximum_batching_window_in_seconds}
        */
        readonly maximumBatchingWindowInSeconds?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#starting_position TfPipe#starting_position}
        */
        readonly startingPosition?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#topic_name TfPipe#topic_name}
        */
        readonly topicName: string;
        /**
        * credentials block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#credentials TfPipe#credentials}
        */
        readonly credentials?: SourceParametersManagedStreamingKafkaParametersCredentialsProperty;
    }
    class ManagedStreamingKafkaParametersPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ManagedStreamingKafkaParametersProperty | undefined;
        set internalValue(value: ManagedStreamingKafkaParametersProperty | undefined);
        private _batchSize?;
        get batchSize(): number;
        set batchSize(value: number);
        resetBatchSize(): void;
        get batchSizeInput(): number | undefined;
        private _consumerGroupId?;
        get consumerGroupId(): string;
        set consumerGroupId(value: string);
        resetConsumerGroupId(): void;
        get consumerGroupIdInput(): string | undefined;
        private _maximumBatchingWindowInSeconds?;
        get maximumBatchingWindowInSeconds(): number;
        set maximumBatchingWindowInSeconds(value: number);
        resetMaximumBatchingWindowInSeconds(): void;
        get maximumBatchingWindowInSecondsInput(): number | undefined;
        private _startingPosition?;
        get startingPosition(): string;
        set startingPosition(value: string);
        resetStartingPosition(): void;
        get startingPositionInput(): string | undefined;
        private _topicName?;
        get topicName(): string;
        set topicName(value: string);
        get topicNameInput(): string | undefined;
        private _credentials;
        get credentials(): SourceParametersManagedStreamingKafkaParametersCredentialsPropertyOutputReference;
        putCredentials(value: SourceParametersManagedStreamingKafkaParametersCredentialsProperty): void;
        resetCredentials(): void;
        get credentialsInput(): SourceParametersManagedStreamingKafkaParametersCredentialsProperty | undefined;
    }
    interface SourceParametersRabbitmqBrokerParametersCredentialsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#basic_auth TfPipe#basic_auth}
        */
        readonly basicAuth: string;
    }
    class SourceParametersRabbitmqBrokerParametersCredentialsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SourceParametersRabbitmqBrokerParametersCredentialsProperty | undefined;
        set internalValue(value: SourceParametersRabbitmqBrokerParametersCredentialsProperty | undefined);
        private _basicAuth?;
        get basicAuth(): string;
        set basicAuth(value: string);
        get basicAuthInput(): string | undefined;
    }
    interface RabbitmqBrokerParametersProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#batch_size TfPipe#batch_size}
        */
        readonly batchSize?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#maximum_batching_window_in_seconds TfPipe#maximum_batching_window_in_seconds}
        */
        readonly maximumBatchingWindowInSeconds?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#queue_name TfPipe#queue_name}
        */
        readonly queueName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#virtual_host TfPipe#virtual_host}
        */
        readonly virtualHost?: string;
        /**
        * credentials block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#credentials TfPipe#credentials}
        */
        readonly credentials: SourceParametersRabbitmqBrokerParametersCredentialsProperty;
    }
    class RabbitmqBrokerParametersPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RabbitmqBrokerParametersProperty | undefined;
        set internalValue(value: RabbitmqBrokerParametersProperty | undefined);
        private _batchSize?;
        get batchSize(): number;
        set batchSize(value: number);
        resetBatchSize(): void;
        get batchSizeInput(): number | undefined;
        private _maximumBatchingWindowInSeconds?;
        get maximumBatchingWindowInSeconds(): number;
        set maximumBatchingWindowInSeconds(value: number);
        resetMaximumBatchingWindowInSeconds(): void;
        get maximumBatchingWindowInSecondsInput(): number | undefined;
        private _queueName?;
        get queueName(): string;
        set queueName(value: string);
        get queueNameInput(): string | undefined;
        private _virtualHost?;
        get virtualHost(): string;
        set virtualHost(value: string);
        resetVirtualHost(): void;
        get virtualHostInput(): string | undefined;
        private _credentials;
        get credentials(): SourceParametersRabbitmqBrokerParametersCredentialsPropertyOutputReference;
        putCredentials(value: SourceParametersRabbitmqBrokerParametersCredentialsProperty): void;
        get credentialsInput(): SourceParametersRabbitmqBrokerParametersCredentialsProperty | undefined;
    }
    interface SourceParametersSelfManagedKafkaParametersCredentialsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#basic_auth TfPipe#basic_auth}
        */
        readonly basicAuth?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#client_certificate_tls_auth TfPipe#client_certificate_tls_auth}
        */
        readonly clientCertificateTlsAuth?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#sasl_scram_256_auth TfPipe#sasl_scram_256_auth}
        */
        readonly saslScram256Auth?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#sasl_scram_512_auth TfPipe#sasl_scram_512_auth}
        */
        readonly saslScram512Auth?: string;
    }
    class SourceParametersSelfManagedKafkaParametersCredentialsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SourceParametersSelfManagedKafkaParametersCredentialsProperty | undefined;
        set internalValue(value: SourceParametersSelfManagedKafkaParametersCredentialsProperty | undefined);
        private _basicAuth?;
        get basicAuth(): string;
        set basicAuth(value: string);
        resetBasicAuth(): void;
        get basicAuthInput(): string | undefined;
        private _clientCertificateTlsAuth?;
        get clientCertificateTlsAuth(): string;
        set clientCertificateTlsAuth(value: string);
        resetClientCertificateTlsAuth(): void;
        get clientCertificateTlsAuthInput(): string | undefined;
        private _saslScram256Auth?;
        get saslScram256Auth(): string;
        set saslScram256Auth(value: string);
        resetSaslScram256Auth(): void;
        get saslScram256AuthInput(): string | undefined;
        private _saslScram512Auth?;
        get saslScram512Auth(): string;
        set saslScram512Auth(value: string);
        resetSaslScram512Auth(): void;
        get saslScram512AuthInput(): string | undefined;
    }
    interface VpcProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#security_groups TfPipe#security_groups}
        */
        readonly securityGroups?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#subnets TfPipe#subnets}
        */
        readonly subnets?: string[];
    }
    class VpcPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): VpcProperty | undefined;
        set internalValue(value: VpcProperty | undefined);
        private _securityGroups?;
        get securityGroups(): string[];
        set securityGroups(value: string[]);
        resetSecurityGroups(): void;
        get securityGroupsInput(): string[] | undefined;
        private _subnets?;
        get subnets(): string[];
        set subnets(value: string[]);
        resetSubnets(): void;
        get subnetsInput(): string[] | undefined;
    }
    interface SelfManagedKafkaParametersProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#additional_bootstrap_servers TfPipe#additional_bootstrap_servers}
        */
        readonly additionalBootstrapServers?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#batch_size TfPipe#batch_size}
        */
        readonly batchSize?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#consumer_group_id TfPipe#consumer_group_id}
        */
        readonly consumerGroupId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#maximum_batching_window_in_seconds TfPipe#maximum_batching_window_in_seconds}
        */
        readonly maximumBatchingWindowInSeconds?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#server_root_ca_certificate TfPipe#server_root_ca_certificate}
        */
        readonly serverRootCaCertificate?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#starting_position TfPipe#starting_position}
        */
        readonly startingPosition?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#topic_name TfPipe#topic_name}
        */
        readonly topicName: string;
        /**
        * credentials block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#credentials TfPipe#credentials}
        */
        readonly credentials?: SourceParametersSelfManagedKafkaParametersCredentialsProperty;
        /**
        * vpc block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#vpc TfPipe#vpc}
        */
        readonly vpc?: VpcProperty;
    }
    class SelfManagedKafkaParametersPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SelfManagedKafkaParametersProperty | undefined;
        set internalValue(value: SelfManagedKafkaParametersProperty | undefined);
        private _additionalBootstrapServers?;
        get additionalBootstrapServers(): string[];
        set additionalBootstrapServers(value: string[]);
        resetAdditionalBootstrapServers(): void;
        get additionalBootstrapServersInput(): string[] | undefined;
        private _batchSize?;
        get batchSize(): number;
        set batchSize(value: number);
        resetBatchSize(): void;
        get batchSizeInput(): number | undefined;
        private _consumerGroupId?;
        get consumerGroupId(): string;
        set consumerGroupId(value: string);
        resetConsumerGroupId(): void;
        get consumerGroupIdInput(): string | undefined;
        private _maximumBatchingWindowInSeconds?;
        get maximumBatchingWindowInSeconds(): number;
        set maximumBatchingWindowInSeconds(value: number);
        resetMaximumBatchingWindowInSeconds(): void;
        get maximumBatchingWindowInSecondsInput(): number | undefined;
        private _serverRootCaCertificate?;
        get serverRootCaCertificate(): string;
        set serverRootCaCertificate(value: string);
        resetServerRootCaCertificate(): void;
        get serverRootCaCertificateInput(): string | undefined;
        private _startingPosition?;
        get startingPosition(): string;
        set startingPosition(value: string);
        resetStartingPosition(): void;
        get startingPositionInput(): string | undefined;
        private _topicName?;
        get topicName(): string;
        set topicName(value: string);
        get topicNameInput(): string | undefined;
        private _credentials;
        get credentials(): SourceParametersSelfManagedKafkaParametersCredentialsPropertyOutputReference;
        putCredentials(value: SourceParametersSelfManagedKafkaParametersCredentialsProperty): void;
        resetCredentials(): void;
        get credentialsInput(): SourceParametersSelfManagedKafkaParametersCredentialsProperty | undefined;
        private _vpc;
        get vpc(): VpcPropertyOutputReference;
        putVpc(value: VpcProperty): void;
        resetVpc(): void;
        get vpcInput(): VpcProperty | undefined;
    }
    interface SourceParametersSqsQueueParametersProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#batch_size TfPipe#batch_size}
        */
        readonly batchSize?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#maximum_batching_window_in_seconds TfPipe#maximum_batching_window_in_seconds}
        */
        readonly maximumBatchingWindowInSeconds?: number;
    }
    class SourceParametersSqsQueueParametersPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SourceParametersSqsQueueParametersProperty | undefined;
        set internalValue(value: SourceParametersSqsQueueParametersProperty | undefined);
        private _batchSize?;
        get batchSize(): number;
        set batchSize(value: number);
        resetBatchSize(): void;
        get batchSizeInput(): number | undefined;
        private _maximumBatchingWindowInSeconds?;
        get maximumBatchingWindowInSeconds(): number;
        set maximumBatchingWindowInSeconds(value: number);
        resetMaximumBatchingWindowInSeconds(): void;
        get maximumBatchingWindowInSecondsInput(): number | undefined;
    }
    interface SourceParametersProperty {
        /**
        * activemq_broker_parameters block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#activemq_broker_parameters TfPipe#activemq_broker_parameters}
        */
        readonly activemqBrokerParameters?: ActivemqBrokerParametersProperty;
        /**
        * dynamodb_stream_parameters block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#dynamodb_stream_parameters TfPipe#dynamodb_stream_parameters}
        */
        readonly dynamodbStreamParameters?: DynamodbStreamParametersProperty;
        /**
        * filter_criteria block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#filter_criteria TfPipe#filter_criteria}
        */
        readonly filterCriteria?: FilterCriteriaProperty;
        /**
        * kinesis_stream_parameters block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#kinesis_stream_parameters TfPipe#kinesis_stream_parameters}
        */
        readonly kinesisStreamParameters?: SourceParametersKinesisStreamParametersProperty;
        /**
        * managed_streaming_kafka_parameters block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#managed_streaming_kafka_parameters TfPipe#managed_streaming_kafka_parameters}
        */
        readonly managedStreamingKafkaParameters?: ManagedStreamingKafkaParametersProperty;
        /**
        * rabbitmq_broker_parameters block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#rabbitmq_broker_parameters TfPipe#rabbitmq_broker_parameters}
        */
        readonly rabbitmqBrokerParameters?: RabbitmqBrokerParametersProperty;
        /**
        * self_managed_kafka_parameters block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#self_managed_kafka_parameters TfPipe#self_managed_kafka_parameters}
        */
        readonly selfManagedKafkaParameters?: SelfManagedKafkaParametersProperty;
        /**
        * sqs_queue_parameters block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#sqs_queue_parameters TfPipe#sqs_queue_parameters}
        */
        readonly sqsQueueParameters?: SourceParametersSqsQueueParametersProperty;
    }
    class SourceParametersPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SourceParametersProperty | undefined;
        set internalValue(value: SourceParametersProperty | undefined);
        private _activemqBrokerParameters;
        get activemqBrokerParameters(): ActivemqBrokerParametersPropertyOutputReference;
        putActivemqBrokerParameters(value: ActivemqBrokerParametersProperty): void;
        resetActivemqBrokerParameters(): void;
        get activemqBrokerParametersInput(): ActivemqBrokerParametersProperty | undefined;
        private _dynamodbStreamParameters;
        get dynamodbStreamParameters(): DynamodbStreamParametersPropertyOutputReference;
        putDynamodbStreamParameters(value: DynamodbStreamParametersProperty): void;
        resetDynamodbStreamParameters(): void;
        get dynamodbStreamParametersInput(): DynamodbStreamParametersProperty | undefined;
        private _filterCriteria;
        get filterCriteria(): FilterCriteriaPropertyOutputReference;
        putFilterCriteria(value: FilterCriteriaProperty): void;
        resetFilterCriteria(): void;
        get filterCriteriaInput(): FilterCriteriaProperty | undefined;
        private _kinesisStreamParameters;
        get kinesisStreamParameters(): SourceParametersKinesisStreamParametersPropertyOutputReference;
        putKinesisStreamParameters(value: SourceParametersKinesisStreamParametersProperty): void;
        resetKinesisStreamParameters(): void;
        get kinesisStreamParametersInput(): SourceParametersKinesisStreamParametersProperty | undefined;
        private _managedStreamingKafkaParameters;
        get managedStreamingKafkaParameters(): ManagedStreamingKafkaParametersPropertyOutputReference;
        putManagedStreamingKafkaParameters(value: ManagedStreamingKafkaParametersProperty): void;
        resetManagedStreamingKafkaParameters(): void;
        get managedStreamingKafkaParametersInput(): ManagedStreamingKafkaParametersProperty | undefined;
        private _rabbitmqBrokerParameters;
        get rabbitmqBrokerParameters(): RabbitmqBrokerParametersPropertyOutputReference;
        putRabbitmqBrokerParameters(value: RabbitmqBrokerParametersProperty): void;
        resetRabbitmqBrokerParameters(): void;
        get rabbitmqBrokerParametersInput(): RabbitmqBrokerParametersProperty | undefined;
        private _selfManagedKafkaParameters;
        get selfManagedKafkaParameters(): SelfManagedKafkaParametersPropertyOutputReference;
        putSelfManagedKafkaParameters(value: SelfManagedKafkaParametersProperty): void;
        resetSelfManagedKafkaParameters(): void;
        get selfManagedKafkaParametersInput(): SelfManagedKafkaParametersProperty | undefined;
        private _sqsQueueParameters;
        get sqsQueueParameters(): SourceParametersSqsQueueParametersPropertyOutputReference;
        putSqsQueueParameters(value: SourceParametersSqsQueueParametersProperty): void;
        resetSqsQueueParameters(): void;
        get sqsQueueParametersInput(): SourceParametersSqsQueueParametersProperty | undefined;
    }
    interface ArrayPropertiesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#size TfPipe#size}
        */
        readonly size?: number;
    }
    class ArrayPropertiesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ArrayPropertiesProperty | undefined;
        set internalValue(value: ArrayPropertiesProperty | undefined);
        private _size?;
        get size(): number;
        set size(value: number);
        resetSize(): void;
        get sizeInput(): number | undefined;
    }
    interface TargetParametersBatchJobParametersContainerOverridesEnvironmentProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#name TfPipe#name}
        */
        readonly name?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#value TfPipe#value}
        */
        readonly value?: string;
    }
    class TargetParametersBatchJobParametersContainerOverridesEnvironmentPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TargetParametersBatchJobParametersContainerOverridesEnvironmentProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TargetParametersBatchJobParametersContainerOverridesEnvironmentProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        resetName(): void;
        get nameInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        resetValue(): void;
        get valueInput(): string | undefined;
    }
    class TargetParametersBatchJobParametersContainerOverridesEnvironmentPropertyList extends cdktn.ComplexList {
        internalValue?: TargetParametersBatchJobParametersContainerOverridesEnvironmentProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TargetParametersBatchJobParametersContainerOverridesEnvironmentPropertyOutputReference;
    }
    interface TargetParametersBatchJobParametersContainerOverridesResourceRequirementProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#type TfPipe#type}
        */
        readonly type: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#value TfPipe#value}
        */
        readonly value: string;
    }
    class TargetParametersBatchJobParametersContainerOverridesResourceRequirementPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TargetParametersBatchJobParametersContainerOverridesResourceRequirementProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TargetParametersBatchJobParametersContainerOverridesResourceRequirementProperty | cdktn.IResolvable | undefined);
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class TargetParametersBatchJobParametersContainerOverridesResourceRequirementPropertyList extends cdktn.ComplexList {
        internalValue?: TargetParametersBatchJobParametersContainerOverridesResourceRequirementProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TargetParametersBatchJobParametersContainerOverridesResourceRequirementPropertyOutputReference;
    }
    interface ContainerOverridesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#command TfPipe#command}
        */
        readonly command?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#instance_type TfPipe#instance_type}
        */
        readonly instanceType?: string;
        /**
        * environment block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#environment TfPipe#environment}
        */
        readonly environment?: TargetParametersBatchJobParametersContainerOverridesEnvironmentProperty[] | cdktn.IResolvable;
        /**
        * resource_requirement block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#resource_requirement TfPipe#resource_requirement}
        */
        readonly resourceRequirement?: TargetParametersBatchJobParametersContainerOverridesResourceRequirementProperty[] | cdktn.IResolvable;
    }
    class ContainerOverridesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ContainerOverridesProperty | undefined;
        set internalValue(value: ContainerOverridesProperty | undefined);
        private _command?;
        get command(): string[];
        set command(value: string[]);
        resetCommand(): void;
        get commandInput(): string[] | undefined;
        private _instanceType?;
        get instanceType(): string;
        set instanceType(value: string);
        resetInstanceType(): void;
        get instanceTypeInput(): string | undefined;
        private _environment;
        get environment(): TargetParametersBatchJobParametersContainerOverridesEnvironmentPropertyList;
        putEnvironment(value: TargetParametersBatchJobParametersContainerOverridesEnvironmentProperty[] | cdktn.IResolvable): void;
        resetEnvironment(): void;
        get environmentInput(): cdktn.IResolvable | TargetParametersBatchJobParametersContainerOverridesEnvironmentProperty[] | undefined;
        private _resourceRequirement;
        get resourceRequirement(): TargetParametersBatchJobParametersContainerOverridesResourceRequirementPropertyList;
        putResourceRequirement(value: TargetParametersBatchJobParametersContainerOverridesResourceRequirementProperty[] | cdktn.IResolvable): void;
        resetResourceRequirement(): void;
        get resourceRequirementInput(): cdktn.IResolvable | TargetParametersBatchJobParametersContainerOverridesResourceRequirementProperty[] | undefined;
    }
    interface DependsOnProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#job_id TfPipe#job_id}
        */
        readonly jobId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#type TfPipe#type}
        */
        readonly type?: string;
    }
    class DependsOnPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DependsOnProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DependsOnProperty | cdktn.IResolvable | undefined);
        private _jobId?;
        get jobId(): string;
        set jobId(value: string);
        resetJobId(): void;
        get jobIdInput(): string | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        resetType(): void;
        get typeInput(): string | undefined;
    }
    class DependsOnPropertyList extends cdktn.ComplexList {
        internalValue?: DependsOnProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DependsOnPropertyOutputReference;
    }
    interface RetryStrategyProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#attempts TfPipe#attempts}
        */
        readonly attempts?: number;
    }
    class RetryStrategyPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RetryStrategyProperty | undefined;
        set internalValue(value: RetryStrategyProperty | undefined);
        private _attempts?;
        get attempts(): number;
        set attempts(value: number);
        resetAttempts(): void;
        get attemptsInput(): number | undefined;
    }
    interface BatchJobParametersProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#job_definition TfPipe#job_definition}
        */
        readonly jobDefinition: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#job_name TfPipe#job_name}
        */
        readonly jobName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#parameters TfPipe#parameters}
        */
        readonly parameters?: {
            [key: string]: string;
        };
        /**
        * array_properties block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#array_properties TfPipe#array_properties}
        */
        readonly arrayProperties?: ArrayPropertiesProperty;
        /**
        * container_overrides block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#container_overrides TfPipe#container_overrides}
        */
        readonly containerOverrides?: ContainerOverridesProperty;
        /**
        * depends_on block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#depends_on TfPipe#depends_on}
        */
        readonly dependsOn?: DependsOnProperty[] | cdktn.IResolvable;
        /**
        * retry_strategy block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#retry_strategy TfPipe#retry_strategy}
        */
        readonly retryStrategy?: RetryStrategyProperty;
    }
    class BatchJobParametersPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): BatchJobParametersProperty | undefined;
        set internalValue(value: BatchJobParametersProperty | undefined);
        private _jobDefinition?;
        get jobDefinition(): string;
        set jobDefinition(value: string);
        get jobDefinitionInput(): string | undefined;
        private _jobName?;
        get jobName(): string;
        set jobName(value: string);
        get jobNameInput(): string | undefined;
        private _parameters?;
        get parameters(): {
            [key: string]: string;
        };
        set parameters(value: {
            [key: string]: string;
        });
        resetParameters(): void;
        get parametersInput(): {
            [key: string]: string;
        } | undefined;
        private _arrayProperties;
        get arrayProperties(): ArrayPropertiesPropertyOutputReference;
        putArrayProperties(value: ArrayPropertiesProperty): void;
        resetArrayProperties(): void;
        get arrayPropertiesInput(): ArrayPropertiesProperty | undefined;
        private _containerOverrides;
        get containerOverrides(): ContainerOverridesPropertyOutputReference;
        putContainerOverrides(value: ContainerOverridesProperty): void;
        resetContainerOverrides(): void;
        get containerOverridesInput(): ContainerOverridesProperty | undefined;
        private _dependsOn;
        get dependsOn(): DependsOnPropertyList;
        putDependsOn(value: DependsOnProperty[] | cdktn.IResolvable): void;
        resetDependsOn(): void;
        get dependsOnInput(): cdktn.IResolvable | DependsOnProperty[] | undefined;
        private _retryStrategy;
        get retryStrategy(): RetryStrategyPropertyOutputReference;
        putRetryStrategy(value: RetryStrategyProperty): void;
        resetRetryStrategy(): void;
        get retryStrategyInput(): RetryStrategyProperty | undefined;
    }
    interface CloudwatchLogsParametersProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#log_stream_name TfPipe#log_stream_name}
        */
        readonly logStreamName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#timestamp TfPipe#timestamp}
        */
        readonly timestamp?: string;
    }
    class CloudwatchLogsParametersPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CloudwatchLogsParametersProperty | undefined;
        set internalValue(value: CloudwatchLogsParametersProperty | undefined);
        private _logStreamName?;
        get logStreamName(): string;
        set logStreamName(value: string);
        resetLogStreamName(): void;
        get logStreamNameInput(): string | undefined;
        private _timestamp?;
        get timestamp(): string;
        set timestamp(value: string);
        resetTimestamp(): void;
        get timestampInput(): string | undefined;
    }
    interface CapacityProviderStrategyProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#base TfPipe#base}
        */
        readonly base?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#capacity_provider TfPipe#capacity_provider}
        */
        readonly capacityProvider: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#weight TfPipe#weight}
        */
        readonly weight?: number;
    }
    class CapacityProviderStrategyPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CapacityProviderStrategyProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CapacityProviderStrategyProperty | cdktn.IResolvable | undefined);
        private _base?;
        get base(): number;
        set base(value: number);
        resetBase(): void;
        get baseInput(): number | undefined;
        private _capacityProvider?;
        get capacityProvider(): string;
        set capacityProvider(value: string);
        get capacityProviderInput(): string | undefined;
        private _weight?;
        get weight(): number;
        set weight(value: number);
        resetWeight(): void;
        get weightInput(): number | undefined;
    }
    class CapacityProviderStrategyPropertyList extends cdktn.ComplexList {
        internalValue?: CapacityProviderStrategyProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CapacityProviderStrategyPropertyOutputReference;
    }
    interface AwsVpcConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#assign_public_ip TfPipe#assign_public_ip}
        */
        readonly assignPublicIp?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#security_groups TfPipe#security_groups}
        */
        readonly securityGroups?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#subnets TfPipe#subnets}
        */
        readonly subnets?: string[];
    }
    class AwsVpcConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AwsVpcConfigurationProperty | undefined;
        set internalValue(value: AwsVpcConfigurationProperty | undefined);
        private _assignPublicIp?;
        get assignPublicIp(): string;
        set assignPublicIp(value: string);
        resetAssignPublicIp(): void;
        get assignPublicIpInput(): string | undefined;
        private _securityGroups?;
        get securityGroups(): string[];
        set securityGroups(value: string[]);
        resetSecurityGroups(): void;
        get securityGroupsInput(): string[] | undefined;
        private _subnets?;
        get subnets(): string[];
        set subnets(value: string[]);
        resetSubnets(): void;
        get subnetsInput(): string[] | undefined;
    }
    interface NetworkConfigurationProperty {
        /**
        * aws_vpc_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#aws_vpc_configuration TfPipe#aws_vpc_configuration}
        */
        readonly awsVpcConfiguration?: AwsVpcConfigurationProperty;
    }
    class NetworkConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): NetworkConfigurationProperty | undefined;
        set internalValue(value: NetworkConfigurationProperty | undefined);
        private _awsVpcConfiguration;
        get awsVpcConfiguration(): AwsVpcConfigurationPropertyOutputReference;
        putAwsVpcConfiguration(value: AwsVpcConfigurationProperty): void;
        resetAwsVpcConfiguration(): void;
        get awsVpcConfigurationInput(): AwsVpcConfigurationProperty | undefined;
    }
    interface TargetParametersEcsTaskParametersOverridesContainerOverrideEnvironmentProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#name TfPipe#name}
        */
        readonly name?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#value TfPipe#value}
        */
        readonly value?: string;
    }
    class TargetParametersEcsTaskParametersOverridesContainerOverrideEnvironmentPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TargetParametersEcsTaskParametersOverridesContainerOverrideEnvironmentProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TargetParametersEcsTaskParametersOverridesContainerOverrideEnvironmentProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        resetName(): void;
        get nameInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        resetValue(): void;
        get valueInput(): string | undefined;
    }
    class TargetParametersEcsTaskParametersOverridesContainerOverrideEnvironmentPropertyList extends cdktn.ComplexList {
        internalValue?: TargetParametersEcsTaskParametersOverridesContainerOverrideEnvironmentProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TargetParametersEcsTaskParametersOverridesContainerOverrideEnvironmentPropertyOutputReference;
    }
    interface EnvironmentFileProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#type TfPipe#type}
        */
        readonly type: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#value TfPipe#value}
        */
        readonly value: string;
    }
    class EnvironmentFilePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EnvironmentFileProperty | cdktn.IResolvable | undefined;
        set internalValue(value: EnvironmentFileProperty | cdktn.IResolvable | undefined);
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class EnvironmentFilePropertyList extends cdktn.ComplexList {
        internalValue?: EnvironmentFileProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EnvironmentFilePropertyOutputReference;
    }
    interface TargetParametersEcsTaskParametersOverridesContainerOverrideResourceRequirementProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#type TfPipe#type}
        */
        readonly type: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#value TfPipe#value}
        */
        readonly value: string;
    }
    class TargetParametersEcsTaskParametersOverridesContainerOverrideResourceRequirementPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TargetParametersEcsTaskParametersOverridesContainerOverrideResourceRequirementProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TargetParametersEcsTaskParametersOverridesContainerOverrideResourceRequirementProperty | cdktn.IResolvable | undefined);
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class TargetParametersEcsTaskParametersOverridesContainerOverrideResourceRequirementPropertyList extends cdktn.ComplexList {
        internalValue?: TargetParametersEcsTaskParametersOverridesContainerOverrideResourceRequirementProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TargetParametersEcsTaskParametersOverridesContainerOverrideResourceRequirementPropertyOutputReference;
    }
    interface ContainerOverrideProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#command TfPipe#command}
        */
        readonly command?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#cpu TfPipe#cpu}
        */
        readonly cpu?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#memory TfPipe#memory}
        */
        readonly memory?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#memory_reservation TfPipe#memory_reservation}
        */
        readonly memoryReservation?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#name TfPipe#name}
        */
        readonly name?: string;
        /**
        * environment block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#environment TfPipe#environment}
        */
        readonly environment?: TargetParametersEcsTaskParametersOverridesContainerOverrideEnvironmentProperty[] | cdktn.IResolvable;
        /**
        * environment_file block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#environment_file TfPipe#environment_file}
        */
        readonly environmentFile?: EnvironmentFileProperty[] | cdktn.IResolvable;
        /**
        * resource_requirement block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#resource_requirement TfPipe#resource_requirement}
        */
        readonly resourceRequirement?: TargetParametersEcsTaskParametersOverridesContainerOverrideResourceRequirementProperty[] | cdktn.IResolvable;
    }
    class ContainerOverridePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ContainerOverrideProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ContainerOverrideProperty | cdktn.IResolvable | undefined);
        private _command?;
        get command(): string[];
        set command(value: string[]);
        resetCommand(): void;
        get commandInput(): string[] | undefined;
        private _cpu?;
        get cpu(): number;
        set cpu(value: number);
        resetCpu(): void;
        get cpuInput(): number | undefined;
        private _memory?;
        get memory(): number;
        set memory(value: number);
        resetMemory(): void;
        get memoryInput(): number | undefined;
        private _memoryReservation?;
        get memoryReservation(): number;
        set memoryReservation(value: number);
        resetMemoryReservation(): void;
        get memoryReservationInput(): number | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        resetName(): void;
        get nameInput(): string | undefined;
        private _environment;
        get environment(): TargetParametersEcsTaskParametersOverridesContainerOverrideEnvironmentPropertyList;
        putEnvironment(value: TargetParametersEcsTaskParametersOverridesContainerOverrideEnvironmentProperty[] | cdktn.IResolvable): void;
        resetEnvironment(): void;
        get environmentInput(): cdktn.IResolvable | TargetParametersEcsTaskParametersOverridesContainerOverrideEnvironmentProperty[] | undefined;
        private _environmentFile;
        get environmentFile(): EnvironmentFilePropertyList;
        putEnvironmentFile(value: EnvironmentFileProperty[] | cdktn.IResolvable): void;
        resetEnvironmentFile(): void;
        get environmentFileInput(): cdktn.IResolvable | EnvironmentFileProperty[] | undefined;
        private _resourceRequirement;
        get resourceRequirement(): TargetParametersEcsTaskParametersOverridesContainerOverrideResourceRequirementPropertyList;
        putResourceRequirement(value: TargetParametersEcsTaskParametersOverridesContainerOverrideResourceRequirementProperty[] | cdktn.IResolvable): void;
        resetResourceRequirement(): void;
        get resourceRequirementInput(): cdktn.IResolvable | TargetParametersEcsTaskParametersOverridesContainerOverrideResourceRequirementProperty[] | undefined;
    }
    class ContainerOverridePropertyList extends cdktn.ComplexList {
        internalValue?: ContainerOverrideProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ContainerOverridePropertyOutputReference;
    }
    interface EphemeralStorageProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#size_in_gib TfPipe#size_in_gib}
        */
        readonly sizeInGib: number;
    }
    class EphemeralStoragePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): EphemeralStorageProperty | undefined;
        set internalValue(value: EphemeralStorageProperty | undefined);
        private _sizeInGib?;
        get sizeInGib(): number;
        set sizeInGib(value: number);
        get sizeInGibInput(): number | undefined;
    }
    interface InferenceAcceleratorOverrideProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#device_name TfPipe#device_name}
        */
        readonly deviceName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#device_type TfPipe#device_type}
        */
        readonly deviceType?: string;
    }
    class InferenceAcceleratorOverridePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): InferenceAcceleratorOverrideProperty | cdktn.IResolvable | undefined;
        set internalValue(value: InferenceAcceleratorOverrideProperty | cdktn.IResolvable | undefined);
        private _deviceName?;
        get deviceName(): string;
        set deviceName(value: string);
        resetDeviceName(): void;
        get deviceNameInput(): string | undefined;
        private _deviceType?;
        get deviceType(): string;
        set deviceType(value: string);
        resetDeviceType(): void;
        get deviceTypeInput(): string | undefined;
    }
    class InferenceAcceleratorOverridePropertyList extends cdktn.ComplexList {
        internalValue?: InferenceAcceleratorOverrideProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): InferenceAcceleratorOverridePropertyOutputReference;
    }
    interface OverridesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#cpu TfPipe#cpu}
        */
        readonly cpu?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#execution_role_arn TfPipe#execution_role_arn}
        */
        readonly executionRoleArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#memory TfPipe#memory}
        */
        readonly memory?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#task_role_arn TfPipe#task_role_arn}
        */
        readonly taskRoleArn?: string;
        /**
        * container_override block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#container_override TfPipe#container_override}
        */
        readonly containerOverride?: ContainerOverrideProperty[] | cdktn.IResolvable;
        /**
        * ephemeral_storage block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#ephemeral_storage TfPipe#ephemeral_storage}
        */
        readonly ephemeralStorage?: EphemeralStorageProperty;
        /**
        * inference_accelerator_override block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#inference_accelerator_override TfPipe#inference_accelerator_override}
        */
        readonly inferenceAcceleratorOverride?: InferenceAcceleratorOverrideProperty[] | cdktn.IResolvable;
    }
    class OverridesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): OverridesProperty | undefined;
        set internalValue(value: OverridesProperty | undefined);
        private _cpu?;
        get cpu(): string;
        set cpu(value: string);
        resetCpu(): void;
        get cpuInput(): string | undefined;
        private _executionRoleArn?;
        get executionRoleArn(): string;
        set executionRoleArn(value: string);
        resetExecutionRoleArn(): void;
        get executionRoleArnInput(): string | undefined;
        private _memory?;
        get memory(): string;
        set memory(value: string);
        resetMemory(): void;
        get memoryInput(): string | undefined;
        private _taskRoleArn?;
        get taskRoleArn(): string;
        set taskRoleArn(value: string);
        resetTaskRoleArn(): void;
        get taskRoleArnInput(): string | undefined;
        private _containerOverride;
        get containerOverride(): ContainerOverridePropertyList;
        putContainerOverride(value: ContainerOverrideProperty[] | cdktn.IResolvable): void;
        resetContainerOverride(): void;
        get containerOverrideInput(): cdktn.IResolvable | ContainerOverrideProperty[] | undefined;
        private _ephemeralStorage;
        get ephemeralStorage(): EphemeralStoragePropertyOutputReference;
        putEphemeralStorage(value: EphemeralStorageProperty): void;
        resetEphemeralStorage(): void;
        get ephemeralStorageInput(): EphemeralStorageProperty | undefined;
        private _inferenceAcceleratorOverride;
        get inferenceAcceleratorOverride(): InferenceAcceleratorOverridePropertyList;
        putInferenceAcceleratorOverride(value: InferenceAcceleratorOverrideProperty[] | cdktn.IResolvable): void;
        resetInferenceAcceleratorOverride(): void;
        get inferenceAcceleratorOverrideInput(): cdktn.IResolvable | InferenceAcceleratorOverrideProperty[] | undefined;
    }
    interface PlacementConstraintProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#expression TfPipe#expression}
        */
        readonly expression?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#type TfPipe#type}
        */
        readonly type?: string;
    }
    class PlacementConstraintPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): PlacementConstraintProperty | cdktn.IResolvable | undefined;
        set internalValue(value: PlacementConstraintProperty | cdktn.IResolvable | undefined);
        private _expression?;
        get expression(): string;
        set expression(value: string);
        resetExpression(): void;
        get expressionInput(): string | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        resetType(): void;
        get typeInput(): string | undefined;
    }
    class PlacementConstraintPropertyList extends cdktn.ComplexList {
        internalValue?: PlacementConstraintProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): PlacementConstraintPropertyOutputReference;
    }
    interface PlacementStrategyProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#field TfPipe#field}
        */
        readonly field?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#type TfPipe#type}
        */
        readonly type?: string;
    }
    class PlacementStrategyPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): PlacementStrategyProperty | cdktn.IResolvable | undefined;
        set internalValue(value: PlacementStrategyProperty | cdktn.IResolvable | undefined);
        private _field?;
        get field(): string;
        set field(value: string);
        resetField(): void;
        get fieldInput(): string | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        resetType(): void;
        get typeInput(): string | undefined;
    }
    class PlacementStrategyPropertyList extends cdktn.ComplexList {
        internalValue?: PlacementStrategyProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): PlacementStrategyPropertyOutputReference;
    }
    interface EcsTaskParametersProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#enable_ecs_managed_tags TfPipe#enable_ecs_managed_tags}
        */
        readonly enableEcsManagedTags?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#enable_execute_command TfPipe#enable_execute_command}
        */
        readonly enableExecuteCommand?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#group TfPipe#group}
        */
        readonly group?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#launch_type TfPipe#launch_type}
        */
        readonly launchType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#platform_version TfPipe#platform_version}
        */
        readonly platformVersion?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#propagate_tags TfPipe#propagate_tags}
        */
        readonly propagateTags?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#reference_id TfPipe#reference_id}
        */
        readonly referenceId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#tags TfPipe#tags}
        */
        readonly tags?: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#task_count TfPipe#task_count}
        */
        readonly taskCount?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#task_definition_arn TfPipe#task_definition_arn}
        */
        readonly taskDefinitionArn: string;
        /**
        * capacity_provider_strategy block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#capacity_provider_strategy TfPipe#capacity_provider_strategy}
        */
        readonly capacityProviderStrategy?: CapacityProviderStrategyProperty[] | cdktn.IResolvable;
        /**
        * network_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#network_configuration TfPipe#network_configuration}
        */
        readonly networkConfiguration?: NetworkConfigurationProperty;
        /**
        * overrides block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#overrides TfPipe#overrides}
        */
        readonly overrides?: OverridesProperty;
        /**
        * placement_constraint block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#placement_constraint TfPipe#placement_constraint}
        */
        readonly placementConstraint?: PlacementConstraintProperty[] | cdktn.IResolvable;
        /**
        * placement_strategy block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#placement_strategy TfPipe#placement_strategy}
        */
        readonly placementStrategy?: PlacementStrategyProperty[] | cdktn.IResolvable;
    }
    class EcsTaskParametersPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): EcsTaskParametersProperty | undefined;
        set internalValue(value: EcsTaskParametersProperty | undefined);
        private _enableEcsManagedTags?;
        get enableEcsManagedTags(): boolean | cdktn.IResolvable;
        set enableEcsManagedTags(value: boolean | cdktn.IResolvable);
        resetEnableEcsManagedTags(): void;
        get enableEcsManagedTagsInput(): boolean | cdktn.IResolvable | undefined;
        private _enableExecuteCommand?;
        get enableExecuteCommand(): boolean | cdktn.IResolvable;
        set enableExecuteCommand(value: boolean | cdktn.IResolvable);
        resetEnableExecuteCommand(): void;
        get enableExecuteCommandInput(): boolean | cdktn.IResolvable | undefined;
        private _group?;
        get group(): string;
        set group(value: string);
        resetGroup(): void;
        get groupInput(): string | undefined;
        private _launchType?;
        get launchType(): string;
        set launchType(value: string);
        resetLaunchType(): void;
        get launchTypeInput(): string | undefined;
        private _platformVersion?;
        get platformVersion(): string;
        set platformVersion(value: string);
        resetPlatformVersion(): void;
        get platformVersionInput(): string | undefined;
        private _propagateTags?;
        get propagateTags(): string;
        set propagateTags(value: string);
        resetPropagateTags(): void;
        get propagateTagsInput(): string | undefined;
        private _referenceId?;
        get referenceId(): string;
        set referenceId(value: string);
        resetReferenceId(): void;
        get referenceIdInput(): string | undefined;
        private _tags?;
        get tags(): {
            [key: string]: string;
        };
        set tags(value: {
            [key: string]: string;
        });
        resetTags(): void;
        get tagsInput(): {
            [key: string]: string;
        } | undefined;
        private _taskCount?;
        get taskCount(): number;
        set taskCount(value: number);
        resetTaskCount(): void;
        get taskCountInput(): number | undefined;
        private _taskDefinitionArn?;
        get taskDefinitionArn(): string;
        set taskDefinitionArn(value: string);
        get taskDefinitionArnInput(): string | undefined;
        private _capacityProviderStrategy;
        get capacityProviderStrategy(): CapacityProviderStrategyPropertyList;
        putCapacityProviderStrategy(value: CapacityProviderStrategyProperty[] | cdktn.IResolvable): void;
        resetCapacityProviderStrategy(): void;
        get capacityProviderStrategyInput(): cdktn.IResolvable | CapacityProviderStrategyProperty[] | undefined;
        private _networkConfiguration;
        get networkConfiguration(): NetworkConfigurationPropertyOutputReference;
        putNetworkConfiguration(value: NetworkConfigurationProperty): void;
        resetNetworkConfiguration(): void;
        get networkConfigurationInput(): NetworkConfigurationProperty | undefined;
        private _overrides;
        get overrides(): OverridesPropertyOutputReference;
        putOverrides(value: OverridesProperty): void;
        resetOverrides(): void;
        get overridesInput(): OverridesProperty | undefined;
        private _placementConstraint;
        get placementConstraint(): PlacementConstraintPropertyList;
        putPlacementConstraint(value: PlacementConstraintProperty[] | cdktn.IResolvable): void;
        resetPlacementConstraint(): void;
        get placementConstraintInput(): cdktn.IResolvable | PlacementConstraintProperty[] | undefined;
        private _placementStrategy;
        get placementStrategy(): PlacementStrategyPropertyList;
        putPlacementStrategy(value: PlacementStrategyProperty[] | cdktn.IResolvable): void;
        resetPlacementStrategy(): void;
        get placementStrategyInput(): cdktn.IResolvable | PlacementStrategyProperty[] | undefined;
    }
    interface EventbridgeEventBusParametersProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#detail_type TfPipe#detail_type}
        */
        readonly detailType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#endpoint_id TfPipe#endpoint_id}
        */
        readonly endpointId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#resources TfPipe#resources}
        */
        readonly resources?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#source TfPipe#source}
        */
        readonly source?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#time TfPipe#time}
        */
        readonly time?: string;
    }
    class EventbridgeEventBusParametersPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): EventbridgeEventBusParametersProperty | undefined;
        set internalValue(value: EventbridgeEventBusParametersProperty | undefined);
        private _detailType?;
        get detailType(): string;
        set detailType(value: string);
        resetDetailType(): void;
        get detailTypeInput(): string | undefined;
        private _endpointId?;
        get endpointId(): string;
        set endpointId(value: string);
        resetEndpointId(): void;
        get endpointIdInput(): string | undefined;
        private _resources?;
        get resources(): string[];
        set resources(value: string[]);
        resetResources(): void;
        get resourcesInput(): string[] | undefined;
        private _source?;
        get source(): string;
        set source(value: string);
        resetSource(): void;
        get sourceInput(): string | undefined;
        private _time?;
        get time(): string;
        set time(value: string);
        resetTime(): void;
        get timeInput(): string | undefined;
    }
    interface TargetParametersHttpParametersProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#header_parameters TfPipe#header_parameters}
        */
        readonly headerParameters?: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#path_parameter_values TfPipe#path_parameter_values}
        */
        readonly pathParameterValues?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#query_string_parameters TfPipe#query_string_parameters}
        */
        readonly queryStringParameters?: {
            [key: string]: string;
        };
    }
    class TargetParametersHttpParametersPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TargetParametersHttpParametersProperty | undefined;
        set internalValue(value: TargetParametersHttpParametersProperty | undefined);
        private _headerParameters?;
        get headerParameters(): {
            [key: string]: string;
        };
        set headerParameters(value: {
            [key: string]: string;
        });
        resetHeaderParameters(): void;
        get headerParametersInput(): {
            [key: string]: string;
        } | undefined;
        private _pathParameterValues?;
        get pathParameterValues(): string[];
        set pathParameterValues(value: string[]);
        resetPathParameterValues(): void;
        get pathParameterValuesInput(): string[] | undefined;
        private _queryStringParameters?;
        get queryStringParameters(): {
            [key: string]: string;
        };
        set queryStringParameters(value: {
            [key: string]: string;
        });
        resetQueryStringParameters(): void;
        get queryStringParametersInput(): {
            [key: string]: string;
        } | undefined;
    }
    interface TargetParametersKinesisStreamParametersProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#partition_key TfPipe#partition_key}
        */
        readonly partitionKey: string;
    }
    class TargetParametersKinesisStreamParametersPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TargetParametersKinesisStreamParametersProperty | undefined;
        set internalValue(value: TargetParametersKinesisStreamParametersProperty | undefined);
        private _partitionKey?;
        get partitionKey(): string;
        set partitionKey(value: string);
        get partitionKeyInput(): string | undefined;
    }
    interface LambdaFunctionParametersProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#invocation_type TfPipe#invocation_type}
        */
        readonly invocationType: string;
    }
    class LambdaFunctionParametersPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): LambdaFunctionParametersProperty | undefined;
        set internalValue(value: LambdaFunctionParametersProperty | undefined);
        private _invocationType?;
        get invocationType(): string;
        set invocationType(value: string);
        get invocationTypeInput(): string | undefined;
    }
    interface RedshiftDataParametersProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#database TfPipe#database}
        */
        readonly database: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#db_user TfPipe#db_user}
        */
        readonly dbUser?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#secret_manager_arn TfPipe#secret_manager_arn}
        */
        readonly secretManagerArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#sqls TfPipe#sqls}
        */
        readonly sqls: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#statement_name TfPipe#statement_name}
        */
        readonly statementName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#with_event TfPipe#with_event}
        */
        readonly withEvent?: boolean | cdktn.IResolvable;
    }
    class RedshiftDataParametersPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RedshiftDataParametersProperty | undefined;
        set internalValue(value: RedshiftDataParametersProperty | undefined);
        private _database?;
        get database(): string;
        set database(value: string);
        get databaseInput(): string | undefined;
        private _dbUser?;
        get dbUser(): string;
        set dbUser(value: string);
        resetDbUser(): void;
        get dbUserInput(): string | undefined;
        private _secretManagerArn?;
        get secretManagerArn(): string;
        set secretManagerArn(value: string);
        resetSecretManagerArn(): void;
        get secretManagerArnInput(): string | undefined;
        private _sqls?;
        get sqls(): string[];
        set sqls(value: string[]);
        get sqlsInput(): string[] | undefined;
        private _statementName?;
        get statementName(): string;
        set statementName(value: string);
        resetStatementName(): void;
        get statementNameInput(): string | undefined;
        private _withEvent?;
        get withEvent(): boolean | cdktn.IResolvable;
        set withEvent(value: boolean | cdktn.IResolvable);
        resetWithEvent(): void;
        get withEventInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface PipelineParameterProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#name TfPipe#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#value TfPipe#value}
        */
        readonly value: string;
    }
    class PipelineParameterPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): PipelineParameterProperty | cdktn.IResolvable | undefined;
        set internalValue(value: PipelineParameterProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class PipelineParameterPropertyList extends cdktn.ComplexList {
        internalValue?: PipelineParameterProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): PipelineParameterPropertyOutputReference;
    }
    interface SagemakerPipelineParametersProperty {
        /**
        * pipeline_parameter block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#pipeline_parameter TfPipe#pipeline_parameter}
        */
        readonly pipelineParameter?: PipelineParameterProperty[] | cdktn.IResolvable;
    }
    class SagemakerPipelineParametersPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SagemakerPipelineParametersProperty | undefined;
        set internalValue(value: SagemakerPipelineParametersProperty | undefined);
        private _pipelineParameter;
        get pipelineParameter(): PipelineParameterPropertyList;
        putPipelineParameter(value: PipelineParameterProperty[] | cdktn.IResolvable): void;
        resetPipelineParameter(): void;
        get pipelineParameterInput(): cdktn.IResolvable | PipelineParameterProperty[] | undefined;
    }
    interface TargetParametersSqsQueueParametersProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#message_deduplication_id TfPipe#message_deduplication_id}
        */
        readonly messageDeduplicationId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#message_group_id TfPipe#message_group_id}
        */
        readonly messageGroupId?: string;
    }
    class TargetParametersSqsQueueParametersPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TargetParametersSqsQueueParametersProperty | undefined;
        set internalValue(value: TargetParametersSqsQueueParametersProperty | undefined);
        private _messageDeduplicationId?;
        get messageDeduplicationId(): string;
        set messageDeduplicationId(value: string);
        resetMessageDeduplicationId(): void;
        get messageDeduplicationIdInput(): string | undefined;
        private _messageGroupId?;
        get messageGroupId(): string;
        set messageGroupId(value: string);
        resetMessageGroupId(): void;
        get messageGroupIdInput(): string | undefined;
    }
    interface StepFunctionStateMachineParametersProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#invocation_type TfPipe#invocation_type}
        */
        readonly invocationType: string;
    }
    class StepFunctionStateMachineParametersPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): StepFunctionStateMachineParametersProperty | undefined;
        set internalValue(value: StepFunctionStateMachineParametersProperty | undefined);
        private _invocationType?;
        get invocationType(): string;
        set invocationType(value: string);
        get invocationTypeInput(): string | undefined;
    }
    interface TargetParametersProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#input_template TfPipe#input_template}
        */
        readonly inputTemplate?: string;
        /**
        * batch_job_parameters block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#batch_job_parameters TfPipe#batch_job_parameters}
        */
        readonly batchJobParameters?: BatchJobParametersProperty;
        /**
        * cloudwatch_logs_parameters block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#cloudwatch_logs_parameters TfPipe#cloudwatch_logs_parameters}
        */
        readonly cloudwatchLogsParameters?: CloudwatchLogsParametersProperty;
        /**
        * ecs_task_parameters block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#ecs_task_parameters TfPipe#ecs_task_parameters}
        */
        readonly ecsTaskParameters?: EcsTaskParametersProperty;
        /**
        * eventbridge_event_bus_parameters block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#eventbridge_event_bus_parameters TfPipe#eventbridge_event_bus_parameters}
        */
        readonly eventbridgeEventBusParameters?: EventbridgeEventBusParametersProperty;
        /**
        * http_parameters block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#http_parameters TfPipe#http_parameters}
        */
        readonly httpParameters?: TargetParametersHttpParametersProperty;
        /**
        * kinesis_stream_parameters block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#kinesis_stream_parameters TfPipe#kinesis_stream_parameters}
        */
        readonly kinesisStreamParameters?: TargetParametersKinesisStreamParametersProperty;
        /**
        * lambda_function_parameters block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#lambda_function_parameters TfPipe#lambda_function_parameters}
        */
        readonly lambdaFunctionParameters?: LambdaFunctionParametersProperty;
        /**
        * redshift_data_parameters block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#redshift_data_parameters TfPipe#redshift_data_parameters}
        */
        readonly redshiftDataParameters?: RedshiftDataParametersProperty;
        /**
        * sagemaker_pipeline_parameters block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#sagemaker_pipeline_parameters TfPipe#sagemaker_pipeline_parameters}
        */
        readonly sagemakerPipelineParameters?: SagemakerPipelineParametersProperty;
        /**
        * sqs_queue_parameters block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#sqs_queue_parameters TfPipe#sqs_queue_parameters}
        */
        readonly sqsQueueParameters?: TargetParametersSqsQueueParametersProperty;
        /**
        * step_function_state_machine_parameters block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#step_function_state_machine_parameters TfPipe#step_function_state_machine_parameters}
        */
        readonly stepFunctionStateMachineParameters?: StepFunctionStateMachineParametersProperty;
    }
    class TargetParametersPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TargetParametersProperty | undefined;
        set internalValue(value: TargetParametersProperty | undefined);
        private _inputTemplate?;
        get inputTemplate(): string;
        set inputTemplate(value: string);
        resetInputTemplate(): void;
        get inputTemplateInput(): string | undefined;
        private _batchJobParameters;
        get batchJobParameters(): BatchJobParametersPropertyOutputReference;
        putBatchJobParameters(value: BatchJobParametersProperty): void;
        resetBatchJobParameters(): void;
        get batchJobParametersInput(): BatchJobParametersProperty | undefined;
        private _cloudwatchLogsParameters;
        get cloudwatchLogsParameters(): CloudwatchLogsParametersPropertyOutputReference;
        putCloudwatchLogsParameters(value: CloudwatchLogsParametersProperty): void;
        resetCloudwatchLogsParameters(): void;
        get cloudwatchLogsParametersInput(): CloudwatchLogsParametersProperty | undefined;
        private _ecsTaskParameters;
        get ecsTaskParameters(): EcsTaskParametersPropertyOutputReference;
        putEcsTaskParameters(value: EcsTaskParametersProperty): void;
        resetEcsTaskParameters(): void;
        get ecsTaskParametersInput(): EcsTaskParametersProperty | undefined;
        private _eventbridgeEventBusParameters;
        get eventbridgeEventBusParameters(): EventbridgeEventBusParametersPropertyOutputReference;
        putEventbridgeEventBusParameters(value: EventbridgeEventBusParametersProperty): void;
        resetEventbridgeEventBusParameters(): void;
        get eventbridgeEventBusParametersInput(): EventbridgeEventBusParametersProperty | undefined;
        private _httpParameters;
        get httpParameters(): TargetParametersHttpParametersPropertyOutputReference;
        putHttpParameters(value: TargetParametersHttpParametersProperty): void;
        resetHttpParameters(): void;
        get httpParametersInput(): TargetParametersHttpParametersProperty | undefined;
        private _kinesisStreamParameters;
        get kinesisStreamParameters(): TargetParametersKinesisStreamParametersPropertyOutputReference;
        putKinesisStreamParameters(value: TargetParametersKinesisStreamParametersProperty): void;
        resetKinesisStreamParameters(): void;
        get kinesisStreamParametersInput(): TargetParametersKinesisStreamParametersProperty | undefined;
        private _lambdaFunctionParameters;
        get lambdaFunctionParameters(): LambdaFunctionParametersPropertyOutputReference;
        putLambdaFunctionParameters(value: LambdaFunctionParametersProperty): void;
        resetLambdaFunctionParameters(): void;
        get lambdaFunctionParametersInput(): LambdaFunctionParametersProperty | undefined;
        private _redshiftDataParameters;
        get redshiftDataParameters(): RedshiftDataParametersPropertyOutputReference;
        putRedshiftDataParameters(value: RedshiftDataParametersProperty): void;
        resetRedshiftDataParameters(): void;
        get redshiftDataParametersInput(): RedshiftDataParametersProperty | undefined;
        private _sagemakerPipelineParameters;
        get sagemakerPipelineParameters(): SagemakerPipelineParametersPropertyOutputReference;
        putSagemakerPipelineParameters(value: SagemakerPipelineParametersProperty): void;
        resetSagemakerPipelineParameters(): void;
        get sagemakerPipelineParametersInput(): SagemakerPipelineParametersProperty | undefined;
        private _sqsQueueParameters;
        get sqsQueueParameters(): TargetParametersSqsQueueParametersPropertyOutputReference;
        putSqsQueueParameters(value: TargetParametersSqsQueueParametersProperty): void;
        resetSqsQueueParameters(): void;
        get sqsQueueParametersInput(): TargetParametersSqsQueueParametersProperty | undefined;
        private _stepFunctionStateMachineParameters;
        get stepFunctionStateMachineParameters(): StepFunctionStateMachineParametersPropertyOutputReference;
        putStepFunctionStateMachineParameters(value: StepFunctionStateMachineParametersProperty): void;
        resetStepFunctionStateMachineParameters(): void;
        get stepFunctionStateMachineParametersInput(): StepFunctionStateMachineParametersProperty | undefined;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#create TfPipe#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#delete TfPipe#delete}
        */
        readonly delete?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pipes_pipe#update TfPipe#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
