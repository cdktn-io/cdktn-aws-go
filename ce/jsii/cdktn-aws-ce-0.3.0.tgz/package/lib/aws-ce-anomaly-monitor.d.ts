import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsAnomalyMonitorConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_anomaly_monitor#id AwsAnomalyMonitor#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_anomaly_monitor#monitor_dimension AwsAnomalyMonitor#monitor_dimension}
    */
    readonly monitorDimension?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_anomaly_monitor#monitor_specification AwsAnomalyMonitor#monitor_specification}
    */
    readonly monitorSpecification?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_anomaly_monitor#monitor_type AwsAnomalyMonitor#monitor_type}
    */
    readonly monitorType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_anomaly_monitor#name AwsAnomalyMonitor#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_anomaly_monitor#tags AwsAnomalyMonitor#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_anomaly_monitor#tags_all AwsAnomalyMonitor#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_anomaly_monitor aws_ce_anomaly_monitor}
*/
export declare class AwsAnomalyMonitor extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_ce_anomaly_monitor";
    /**
    * Generates CDKTN code for importing a AwsAnomalyMonitor resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsAnomalyMonitor to import
    * @param importFromId The id of the existing AwsAnomalyMonitor that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_anomaly_monitor#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsAnomalyMonitor to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_anomaly_monitor aws_ce_anomaly_monitor} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsAnomalyMonitorConfig
    */
    constructor(scope: Construct, id: string, config: AwsAnomalyMonitorConfig);
    get arn(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _monitorDimension?;
    get monitorDimension(): string;
    set monitorDimension(value: string);
    resetMonitorDimension(): void;
    get monitorDimensionInput(): string | undefined;
    private _monitorSpecification?;
    get monitorSpecification(): string;
    set monitorSpecification(value: string);
    resetMonitorSpecification(): void;
    get monitorSpecificationInput(): string | undefined;
    private _monitorType?;
    get monitorType(): string;
    set monitorType(value: string);
    get monitorTypeInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
