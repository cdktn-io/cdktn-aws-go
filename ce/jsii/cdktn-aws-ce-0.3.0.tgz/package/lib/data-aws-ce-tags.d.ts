import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsTagsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#id DataAwsTags#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#search_string DataAwsTags#search_string}
    */
    readonly searchString?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#tag_key DataAwsTags#tag_key}
    */
    readonly tagKey?: string;
    /**
    * filter block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#filter DataAwsTags#filter}
    */
    readonly filter?: DataAwsTags.FilterProperty;
    /**
    * sort_by block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#sort_by DataAwsTags#sort_by}
    */
    readonly sortBy?: DataAwsTags.SortByProperty[] | cdktn.IResolvable;
    /**
    * time_period block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#time_period DataAwsTags#time_period}
    */
    readonly timePeriod: DataAwsTags.TimePeriodProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags aws_ce_tags}
*/
export declare class DataAwsTags extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_ce_tags";
    /**
    * Generates CDKTN code for importing a DataAwsTags resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsTags to import
    * @param importFromId The id of the existing DataAwsTags that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsTags to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags aws_ce_tags} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsTagsConfig
    */
    constructor(scope: Construct, id: string, config: DataAwsTagsConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _searchString?;
    get searchString(): string;
    set searchString(value: string);
    resetSearchString(): void;
    get searchStringInput(): string | undefined;
    private _tagKey?;
    get tagKey(): string;
    set tagKey(value: string);
    resetTagKey(): void;
    get tagKeyInput(): string | undefined;
    get tags(): string[];
    private _filter;
    get filter(): DataAwsTags.FilterPropertyOutputReference;
    putFilter(value: DataAwsTags.FilterProperty): void;
    resetFilter(): void;
    get filterInput(): DataAwsTags.FilterProperty | undefined;
    private _sortBy;
    get sortBy(): DataAwsTags.SortByPropertyList;
    putSortBy(value: DataAwsTags.SortByProperty[] | cdktn.IResolvable): void;
    resetSortBy(): void;
    get sortByInput(): cdktn.IResolvable | DataAwsTags.SortByProperty[] | undefined;
    private _timePeriod;
    get timePeriod(): DataAwsTags.TimePeriodPropertyOutputReference;
    putTimePeriod(value: DataAwsTags.TimePeriodProperty): void;
    get timePeriodInput(): DataAwsTags.TimePeriodProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataAwsTagsFilterAndCostCategoryPropertyToTerraform(struct?: DataAwsTags.FilterAndCostCategoryPropertyOutputReference | DataAwsTags.FilterAndCostCategoryProperty): any;
export declare function dataAwsTagsFilterAndCostCategoryPropertyToHclTerraform(struct?: DataAwsTags.FilterAndCostCategoryPropertyOutputReference | DataAwsTags.FilterAndCostCategoryProperty): any;
export declare function dataAwsTagsFilterAndDimensionPropertyToTerraform(struct?: DataAwsTags.FilterAndDimensionPropertyOutputReference | DataAwsTags.FilterAndDimensionProperty): any;
export declare function dataAwsTagsFilterAndDimensionPropertyToHclTerraform(struct?: DataAwsTags.FilterAndDimensionPropertyOutputReference | DataAwsTags.FilterAndDimensionProperty): any;
export declare function dataAwsTagsFilterAndTagsPropertyToTerraform(struct?: DataAwsTags.FilterAndTagsPropertyOutputReference | DataAwsTags.FilterAndTagsProperty): any;
export declare function dataAwsTagsFilterAndTagsPropertyToHclTerraform(struct?: DataAwsTags.FilterAndTagsPropertyOutputReference | DataAwsTags.FilterAndTagsProperty): any;
export declare function dataAwsTagsAndPropertyToTerraform(struct?: DataAwsTags.AndProperty | cdktn.IResolvable): any;
export declare function dataAwsTagsAndPropertyToHclTerraform(struct?: DataAwsTags.AndProperty | cdktn.IResolvable): any;
export declare function dataAwsTagsFilterCostCategoryPropertyToTerraform(struct?: DataAwsTags.FilterCostCategoryPropertyOutputReference | DataAwsTags.FilterCostCategoryProperty): any;
export declare function dataAwsTagsFilterCostCategoryPropertyToHclTerraform(struct?: DataAwsTags.FilterCostCategoryPropertyOutputReference | DataAwsTags.FilterCostCategoryProperty): any;
export declare function dataAwsTagsFilterDimensionPropertyToTerraform(struct?: DataAwsTags.FilterDimensionPropertyOutputReference | DataAwsTags.FilterDimensionProperty): any;
export declare function dataAwsTagsFilterDimensionPropertyToHclTerraform(struct?: DataAwsTags.FilterDimensionPropertyOutputReference | DataAwsTags.FilterDimensionProperty): any;
export declare function dataAwsTagsFilterNotCostCategoryPropertyToTerraform(struct?: DataAwsTags.FilterNotCostCategoryPropertyOutputReference | DataAwsTags.FilterNotCostCategoryProperty): any;
export declare function dataAwsTagsFilterNotCostCategoryPropertyToHclTerraform(struct?: DataAwsTags.FilterNotCostCategoryPropertyOutputReference | DataAwsTags.FilterNotCostCategoryProperty): any;
export declare function dataAwsTagsFilterNotDimensionPropertyToTerraform(struct?: DataAwsTags.FilterNotDimensionPropertyOutputReference | DataAwsTags.FilterNotDimensionProperty): any;
export declare function dataAwsTagsFilterNotDimensionPropertyToHclTerraform(struct?: DataAwsTags.FilterNotDimensionPropertyOutputReference | DataAwsTags.FilterNotDimensionProperty): any;
export declare function dataAwsTagsFilterNotTagsPropertyToTerraform(struct?: DataAwsTags.FilterNotTagsPropertyOutputReference | DataAwsTags.FilterNotTagsProperty): any;
export declare function dataAwsTagsFilterNotTagsPropertyToHclTerraform(struct?: DataAwsTags.FilterNotTagsPropertyOutputReference | DataAwsTags.FilterNotTagsProperty): any;
export declare function dataAwsTagsNotPropertyToTerraform(struct?: DataAwsTags.NotPropertyOutputReference | DataAwsTags.NotProperty): any;
export declare function dataAwsTagsNotPropertyToHclTerraform(struct?: DataAwsTags.NotPropertyOutputReference | DataAwsTags.NotProperty): any;
export declare function dataAwsTagsFilterOrCostCategoryPropertyToTerraform(struct?: DataAwsTags.FilterOrCostCategoryPropertyOutputReference | DataAwsTags.FilterOrCostCategoryProperty): any;
export declare function dataAwsTagsFilterOrCostCategoryPropertyToHclTerraform(struct?: DataAwsTags.FilterOrCostCategoryPropertyOutputReference | DataAwsTags.FilterOrCostCategoryProperty): any;
export declare function dataAwsTagsFilterOrDimensionPropertyToTerraform(struct?: DataAwsTags.FilterOrDimensionPropertyOutputReference | DataAwsTags.FilterOrDimensionProperty): any;
export declare function dataAwsTagsFilterOrDimensionPropertyToHclTerraform(struct?: DataAwsTags.FilterOrDimensionPropertyOutputReference | DataAwsTags.FilterOrDimensionProperty): any;
export declare function dataAwsTagsFilterOrTagsPropertyToTerraform(struct?: DataAwsTags.FilterOrTagsPropertyOutputReference | DataAwsTags.FilterOrTagsProperty): any;
export declare function dataAwsTagsFilterOrTagsPropertyToHclTerraform(struct?: DataAwsTags.FilterOrTagsPropertyOutputReference | DataAwsTags.FilterOrTagsProperty): any;
export declare function dataAwsTagsOrPropertyToTerraform(struct?: DataAwsTags.OrProperty | cdktn.IResolvable): any;
export declare function dataAwsTagsOrPropertyToHclTerraform(struct?: DataAwsTags.OrProperty | cdktn.IResolvable): any;
export declare function dataAwsTagsFilterTagsPropertyToTerraform(struct?: DataAwsTags.FilterTagsPropertyOutputReference | DataAwsTags.FilterTagsProperty): any;
export declare function dataAwsTagsFilterTagsPropertyToHclTerraform(struct?: DataAwsTags.FilterTagsPropertyOutputReference | DataAwsTags.FilterTagsProperty): any;
export declare function dataAwsTagsFilterPropertyToTerraform(struct?: DataAwsTags.FilterPropertyOutputReference | DataAwsTags.FilterProperty): any;
export declare function dataAwsTagsFilterPropertyToHclTerraform(struct?: DataAwsTags.FilterPropertyOutputReference | DataAwsTags.FilterProperty): any;
export declare function dataAwsTagsSortByPropertyToTerraform(struct?: DataAwsTags.SortByProperty | cdktn.IResolvable): any;
export declare function dataAwsTagsSortByPropertyToHclTerraform(struct?: DataAwsTags.SortByProperty | cdktn.IResolvable): any;
export declare function dataAwsTagsTimePeriodPropertyToTerraform(struct?: DataAwsTags.TimePeriodPropertyOutputReference | DataAwsTags.TimePeriodProperty): any;
export declare function dataAwsTagsTimePeriodPropertyToHclTerraform(struct?: DataAwsTags.TimePeriodPropertyOutputReference | DataAwsTags.TimePeriodProperty): any;
export declare namespace DataAwsTags {
    interface FilterAndCostCategoryProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#key DataAwsTags#key}
        */
        readonly key?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#match_options DataAwsTags#match_options}
        */
        readonly matchOptions?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#values DataAwsTags#values}
        */
        readonly values?: string[];
    }
    class FilterAndCostCategoryPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): FilterAndCostCategoryProperty | undefined;
        set internalValue(value: FilterAndCostCategoryProperty | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        resetKey(): void;
        get keyInput(): string | undefined;
        private _matchOptions?;
        get matchOptions(): string[];
        set matchOptions(value: string[]);
        resetMatchOptions(): void;
        get matchOptionsInput(): string[] | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        resetValues(): void;
        get valuesInput(): string[] | undefined;
    }
    interface FilterAndDimensionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#key DataAwsTags#key}
        */
        readonly key?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#match_options DataAwsTags#match_options}
        */
        readonly matchOptions?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#values DataAwsTags#values}
        */
        readonly values?: string[];
    }
    class FilterAndDimensionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): FilterAndDimensionProperty | undefined;
        set internalValue(value: FilterAndDimensionProperty | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        resetKey(): void;
        get keyInput(): string | undefined;
        private _matchOptions?;
        get matchOptions(): string[];
        set matchOptions(value: string[]);
        resetMatchOptions(): void;
        get matchOptionsInput(): string[] | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        resetValues(): void;
        get valuesInput(): string[] | undefined;
    }
    interface FilterAndTagsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#key DataAwsTags#key}
        */
        readonly key?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#match_options DataAwsTags#match_options}
        */
        readonly matchOptions?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#values DataAwsTags#values}
        */
        readonly values?: string[];
    }
    class FilterAndTagsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): FilterAndTagsProperty | undefined;
        set internalValue(value: FilterAndTagsProperty | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        resetKey(): void;
        get keyInput(): string | undefined;
        private _matchOptions?;
        get matchOptions(): string[];
        set matchOptions(value: string[]);
        resetMatchOptions(): void;
        get matchOptionsInput(): string[] | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        resetValues(): void;
        get valuesInput(): string[] | undefined;
    }
    interface AndProperty {
        /**
        * cost_category block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#cost_category DataAwsTags#cost_category}
        */
        readonly costCategory?: FilterAndCostCategoryProperty;
        /**
        * dimension block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#dimension DataAwsTags#dimension}
        */
        readonly dimension?: FilterAndDimensionProperty;
        /**
        * tags block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#tags DataAwsTags#tags}
        */
        readonly tags?: FilterAndTagsProperty;
    }
    class AndPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AndProperty | cdktn.IResolvable | undefined;
        set internalValue(value: AndProperty | cdktn.IResolvable | undefined);
        private _costCategory;
        get costCategory(): FilterAndCostCategoryPropertyOutputReference;
        putCostCategory(value: FilterAndCostCategoryProperty): void;
        resetCostCategory(): void;
        get costCategoryInput(): FilterAndCostCategoryProperty | undefined;
        private _dimension;
        get dimension(): FilterAndDimensionPropertyOutputReference;
        putDimension(value: FilterAndDimensionProperty): void;
        resetDimension(): void;
        get dimensionInput(): FilterAndDimensionProperty | undefined;
        private _tags;
        get tags(): FilterAndTagsPropertyOutputReference;
        putTags(value: FilterAndTagsProperty): void;
        resetTags(): void;
        get tagsInput(): FilterAndTagsProperty | undefined;
    }
    class AndPropertyList extends cdktn.ComplexList {
        internalValue?: AndProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AndPropertyOutputReference;
    }
    interface FilterCostCategoryProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#key DataAwsTags#key}
        */
        readonly key?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#match_options DataAwsTags#match_options}
        */
        readonly matchOptions?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#values DataAwsTags#values}
        */
        readonly values?: string[];
    }
    class FilterCostCategoryPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): FilterCostCategoryProperty | undefined;
        set internalValue(value: FilterCostCategoryProperty | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        resetKey(): void;
        get keyInput(): string | undefined;
        private _matchOptions?;
        get matchOptions(): string[];
        set matchOptions(value: string[]);
        resetMatchOptions(): void;
        get matchOptionsInput(): string[] | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        resetValues(): void;
        get valuesInput(): string[] | undefined;
    }
    interface FilterDimensionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#key DataAwsTags#key}
        */
        readonly key?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#match_options DataAwsTags#match_options}
        */
        readonly matchOptions?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#values DataAwsTags#values}
        */
        readonly values?: string[];
    }
    class FilterDimensionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): FilterDimensionProperty | undefined;
        set internalValue(value: FilterDimensionProperty | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        resetKey(): void;
        get keyInput(): string | undefined;
        private _matchOptions?;
        get matchOptions(): string[];
        set matchOptions(value: string[]);
        resetMatchOptions(): void;
        get matchOptionsInput(): string[] | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        resetValues(): void;
        get valuesInput(): string[] | undefined;
    }
    interface FilterNotCostCategoryProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#key DataAwsTags#key}
        */
        readonly key?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#match_options DataAwsTags#match_options}
        */
        readonly matchOptions?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#values DataAwsTags#values}
        */
        readonly values?: string[];
    }
    class FilterNotCostCategoryPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): FilterNotCostCategoryProperty | undefined;
        set internalValue(value: FilterNotCostCategoryProperty | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        resetKey(): void;
        get keyInput(): string | undefined;
        private _matchOptions?;
        get matchOptions(): string[];
        set matchOptions(value: string[]);
        resetMatchOptions(): void;
        get matchOptionsInput(): string[] | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        resetValues(): void;
        get valuesInput(): string[] | undefined;
    }
    interface FilterNotDimensionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#key DataAwsTags#key}
        */
        readonly key?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#match_options DataAwsTags#match_options}
        */
        readonly matchOptions?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#values DataAwsTags#values}
        */
        readonly values?: string[];
    }
    class FilterNotDimensionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): FilterNotDimensionProperty | undefined;
        set internalValue(value: FilterNotDimensionProperty | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        resetKey(): void;
        get keyInput(): string | undefined;
        private _matchOptions?;
        get matchOptions(): string[];
        set matchOptions(value: string[]);
        resetMatchOptions(): void;
        get matchOptionsInput(): string[] | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        resetValues(): void;
        get valuesInput(): string[] | undefined;
    }
    interface FilterNotTagsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#key DataAwsTags#key}
        */
        readonly key?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#match_options DataAwsTags#match_options}
        */
        readonly matchOptions?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#values DataAwsTags#values}
        */
        readonly values?: string[];
    }
    class FilterNotTagsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): FilterNotTagsProperty | undefined;
        set internalValue(value: FilterNotTagsProperty | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        resetKey(): void;
        get keyInput(): string | undefined;
        private _matchOptions?;
        get matchOptions(): string[];
        set matchOptions(value: string[]);
        resetMatchOptions(): void;
        get matchOptionsInput(): string[] | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        resetValues(): void;
        get valuesInput(): string[] | undefined;
    }
    interface NotProperty {
        /**
        * cost_category block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#cost_category DataAwsTags#cost_category}
        */
        readonly costCategory?: FilterNotCostCategoryProperty;
        /**
        * dimension block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#dimension DataAwsTags#dimension}
        */
        readonly dimension?: FilterNotDimensionProperty;
        /**
        * tags block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#tags DataAwsTags#tags}
        */
        readonly tags?: FilterNotTagsProperty;
    }
    class NotPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): NotProperty | undefined;
        set internalValue(value: NotProperty | undefined);
        private _costCategory;
        get costCategory(): FilterNotCostCategoryPropertyOutputReference;
        putCostCategory(value: FilterNotCostCategoryProperty): void;
        resetCostCategory(): void;
        get costCategoryInput(): FilterNotCostCategoryProperty | undefined;
        private _dimension;
        get dimension(): FilterNotDimensionPropertyOutputReference;
        putDimension(value: FilterNotDimensionProperty): void;
        resetDimension(): void;
        get dimensionInput(): FilterNotDimensionProperty | undefined;
        private _tags;
        get tags(): FilterNotTagsPropertyOutputReference;
        putTags(value: FilterNotTagsProperty): void;
        resetTags(): void;
        get tagsInput(): FilterNotTagsProperty | undefined;
    }
    interface FilterOrCostCategoryProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#key DataAwsTags#key}
        */
        readonly key?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#match_options DataAwsTags#match_options}
        */
        readonly matchOptions?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#values DataAwsTags#values}
        */
        readonly values?: string[];
    }
    class FilterOrCostCategoryPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): FilterOrCostCategoryProperty | undefined;
        set internalValue(value: FilterOrCostCategoryProperty | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        resetKey(): void;
        get keyInput(): string | undefined;
        private _matchOptions?;
        get matchOptions(): string[];
        set matchOptions(value: string[]);
        resetMatchOptions(): void;
        get matchOptionsInput(): string[] | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        resetValues(): void;
        get valuesInput(): string[] | undefined;
    }
    interface FilterOrDimensionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#key DataAwsTags#key}
        */
        readonly key?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#match_options DataAwsTags#match_options}
        */
        readonly matchOptions?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#values DataAwsTags#values}
        */
        readonly values?: string[];
    }
    class FilterOrDimensionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): FilterOrDimensionProperty | undefined;
        set internalValue(value: FilterOrDimensionProperty | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        resetKey(): void;
        get keyInput(): string | undefined;
        private _matchOptions?;
        get matchOptions(): string[];
        set matchOptions(value: string[]);
        resetMatchOptions(): void;
        get matchOptionsInput(): string[] | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        resetValues(): void;
        get valuesInput(): string[] | undefined;
    }
    interface FilterOrTagsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#key DataAwsTags#key}
        */
        readonly key?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#match_options DataAwsTags#match_options}
        */
        readonly matchOptions?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#values DataAwsTags#values}
        */
        readonly values?: string[];
    }
    class FilterOrTagsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): FilterOrTagsProperty | undefined;
        set internalValue(value: FilterOrTagsProperty | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        resetKey(): void;
        get keyInput(): string | undefined;
        private _matchOptions?;
        get matchOptions(): string[];
        set matchOptions(value: string[]);
        resetMatchOptions(): void;
        get matchOptionsInput(): string[] | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        resetValues(): void;
        get valuesInput(): string[] | undefined;
    }
    interface OrProperty {
        /**
        * cost_category block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#cost_category DataAwsTags#cost_category}
        */
        readonly costCategory?: FilterOrCostCategoryProperty;
        /**
        * dimension block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#dimension DataAwsTags#dimension}
        */
        readonly dimension?: FilterOrDimensionProperty;
        /**
        * tags block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#tags DataAwsTags#tags}
        */
        readonly tags?: FilterOrTagsProperty;
    }
    class OrPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): OrProperty | cdktn.IResolvable | undefined;
        set internalValue(value: OrProperty | cdktn.IResolvable | undefined);
        private _costCategory;
        get costCategory(): FilterOrCostCategoryPropertyOutputReference;
        putCostCategory(value: FilterOrCostCategoryProperty): void;
        resetCostCategory(): void;
        get costCategoryInput(): FilterOrCostCategoryProperty | undefined;
        private _dimension;
        get dimension(): FilterOrDimensionPropertyOutputReference;
        putDimension(value: FilterOrDimensionProperty): void;
        resetDimension(): void;
        get dimensionInput(): FilterOrDimensionProperty | undefined;
        private _tags;
        get tags(): FilterOrTagsPropertyOutputReference;
        putTags(value: FilterOrTagsProperty): void;
        resetTags(): void;
        get tagsInput(): FilterOrTagsProperty | undefined;
    }
    class OrPropertyList extends cdktn.ComplexList {
        internalValue?: OrProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): OrPropertyOutputReference;
    }
    interface FilterTagsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#key DataAwsTags#key}
        */
        readonly key?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#match_options DataAwsTags#match_options}
        */
        readonly matchOptions?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#values DataAwsTags#values}
        */
        readonly values?: string[];
    }
    class FilterTagsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): FilterTagsProperty | undefined;
        set internalValue(value: FilterTagsProperty | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        resetKey(): void;
        get keyInput(): string | undefined;
        private _matchOptions?;
        get matchOptions(): string[];
        set matchOptions(value: string[]);
        resetMatchOptions(): void;
        get matchOptionsInput(): string[] | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        resetValues(): void;
        get valuesInput(): string[] | undefined;
    }
    interface FilterProperty {
        /**
        * and block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#and DataAwsTags#and}
        */
        readonly and?: AndProperty[] | cdktn.IResolvable;
        /**
        * cost_category block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#cost_category DataAwsTags#cost_category}
        */
        readonly costCategory?: FilterCostCategoryProperty;
        /**
        * dimension block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#dimension DataAwsTags#dimension}
        */
        readonly dimension?: FilterDimensionProperty;
        /**
        * not block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#not DataAwsTags#not}
        */
        readonly not?: NotProperty;
        /**
        * or block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#or DataAwsTags#or}
        */
        readonly or?: OrProperty[] | cdktn.IResolvable;
        /**
        * tags block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#tags DataAwsTags#tags}
        */
        readonly tags?: FilterTagsProperty;
    }
    class FilterPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): FilterProperty | undefined;
        set internalValue(value: FilterProperty | undefined);
        private _and;
        get and(): AndPropertyList;
        putAnd(value: AndProperty[] | cdktn.IResolvable): void;
        resetAnd(): void;
        get andInput(): cdktn.IResolvable | AndProperty[] | undefined;
        private _costCategory;
        get costCategory(): FilterCostCategoryPropertyOutputReference;
        putCostCategory(value: FilterCostCategoryProperty): void;
        resetCostCategory(): void;
        get costCategoryInput(): FilterCostCategoryProperty | undefined;
        private _dimension;
        get dimension(): FilterDimensionPropertyOutputReference;
        putDimension(value: FilterDimensionProperty): void;
        resetDimension(): void;
        get dimensionInput(): FilterDimensionProperty | undefined;
        private _not;
        get not(): NotPropertyOutputReference;
        putNot(value: NotProperty): void;
        resetNot(): void;
        get notInput(): NotProperty | undefined;
        private _or;
        get or(): OrPropertyList;
        putOr(value: OrProperty[] | cdktn.IResolvable): void;
        resetOr(): void;
        get orInput(): cdktn.IResolvable | OrProperty[] | undefined;
        private _tags;
        get tags(): FilterTagsPropertyOutputReference;
        putTags(value: FilterTagsProperty): void;
        resetTags(): void;
        get tagsInput(): FilterTagsProperty | undefined;
    }
    interface SortByProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#key DataAwsTags#key}
        */
        readonly key?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#sort_order DataAwsTags#sort_order}
        */
        readonly sortOrder?: string;
    }
    class SortByPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SortByProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SortByProperty | cdktn.IResolvable | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        resetKey(): void;
        get keyInput(): string | undefined;
        private _sortOrder?;
        get sortOrder(): string;
        set sortOrder(value: string);
        resetSortOrder(): void;
        get sortOrderInput(): string | undefined;
    }
    class SortByPropertyList extends cdktn.ComplexList {
        internalValue?: SortByProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SortByPropertyOutputReference;
    }
    interface TimePeriodProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#end DataAwsTags#end}
        */
        readonly end: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_tags#start DataAwsTags#start}
        */
        readonly start: string;
    }
    class TimePeriodPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimePeriodProperty | undefined;
        set internalValue(value: TimePeriodProperty | undefined);
        private _end?;
        get end(): string;
        set end(value: string);
        get endInput(): string | undefined;
        private _start?;
        get start(): string;
        set start(value: string);
        get startInput(): string | undefined;
    }
}
