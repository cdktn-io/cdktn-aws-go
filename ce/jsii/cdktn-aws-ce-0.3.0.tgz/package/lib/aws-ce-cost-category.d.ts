import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsCostCategoryConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#default_value AwsCostCategory#default_value}
    */
    readonly defaultValue?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#effective_start AwsCostCategory#effective_start}
    */
    readonly effectiveStart?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#id AwsCostCategory#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#name AwsCostCategory#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#rule_version AwsCostCategory#rule_version}
    */
    readonly ruleVersion: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#tags AwsCostCategory#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#tags_all AwsCostCategory#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * rule block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#rule AwsCostCategory#rule}
    */
    readonly rule: AwsCostCategory.RuleProperty[] | cdktn.IResolvable;
    /**
    * split_charge_rule block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#split_charge_rule AwsCostCategory#split_charge_rule}
    */
    readonly splitChargeRule?: AwsCostCategory.SplitChargeRuleProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category aws_ce_cost_category}
*/
export declare class AwsCostCategory extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_ce_cost_category";
    /**
    * Generates CDKTN code for importing a AwsCostCategory resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsCostCategory to import
    * @param importFromId The id of the existing AwsCostCategory that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsCostCategory to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category aws_ce_cost_category} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsCostCategoryConfig
    */
    constructor(scope: Construct, id: string, config: AwsCostCategoryConfig);
    get arn(): string;
    private _defaultValue?;
    get defaultValue(): string;
    set defaultValue(value: string);
    resetDefaultValue(): void;
    get defaultValueInput(): string | undefined;
    get effectiveEnd(): string;
    private _effectiveStart?;
    get effectiveStart(): string;
    set effectiveStart(value: string);
    resetEffectiveStart(): void;
    get effectiveStartInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _ruleVersion?;
    get ruleVersion(): string;
    set ruleVersion(value: string);
    get ruleVersionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _rule;
    get rule(): AwsCostCategory.RulePropertyList;
    putRule(value: AwsCostCategory.RuleProperty[] | cdktn.IResolvable): void;
    get ruleInput(): cdktn.IResolvable | AwsCostCategory.RuleProperty[] | undefined;
    private _splitChargeRule;
    get splitChargeRule(): AwsCostCategory.SplitChargeRulePropertyList;
    putSplitChargeRule(value: AwsCostCategory.SplitChargeRuleProperty[] | cdktn.IResolvable): void;
    resetSplitChargeRule(): void;
    get splitChargeRuleInput(): cdktn.IResolvable | AwsCostCategory.SplitChargeRuleProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsCostCategoryInheritedValuePropertyToTerraform(struct?: AwsCostCategory.InheritedValuePropertyOutputReference | AwsCostCategory.InheritedValueProperty): any;
export declare function awsCostCategoryInheritedValuePropertyToHclTerraform(struct?: AwsCostCategory.InheritedValuePropertyOutputReference | AwsCostCategory.InheritedValueProperty): any;
export declare function awsCostCategoryRuleRuleAndAndCostCategoryPropertyToTerraform(struct?: AwsCostCategory.RuleRuleAndAndCostCategoryPropertyOutputReference | AwsCostCategory.RuleRuleAndAndCostCategoryProperty): any;
export declare function awsCostCategoryRuleRuleAndAndCostCategoryPropertyToHclTerraform(struct?: AwsCostCategory.RuleRuleAndAndCostCategoryPropertyOutputReference | AwsCostCategory.RuleRuleAndAndCostCategoryProperty): any;
export declare function awsCostCategoryRuleRuleAndAndDimensionPropertyToTerraform(struct?: AwsCostCategory.RuleRuleAndAndDimensionPropertyOutputReference | AwsCostCategory.RuleRuleAndAndDimensionProperty): any;
export declare function awsCostCategoryRuleRuleAndAndDimensionPropertyToHclTerraform(struct?: AwsCostCategory.RuleRuleAndAndDimensionPropertyOutputReference | AwsCostCategory.RuleRuleAndAndDimensionProperty): any;
export declare function awsCostCategoryRuleRuleAndAndTagsPropertyToTerraform(struct?: AwsCostCategory.RuleRuleAndAndTagsPropertyOutputReference | AwsCostCategory.RuleRuleAndAndTagsProperty): any;
export declare function awsCostCategoryRuleRuleAndAndTagsPropertyToHclTerraform(struct?: AwsCostCategory.RuleRuleAndAndTagsPropertyOutputReference | AwsCostCategory.RuleRuleAndAndTagsProperty): any;
export declare function awsCostCategoryRuleRuleAndAndPropertyToTerraform(struct?: AwsCostCategory.RuleRuleAndAndProperty | cdktn.IResolvable): any;
export declare function awsCostCategoryRuleRuleAndAndPropertyToHclTerraform(struct?: AwsCostCategory.RuleRuleAndAndProperty | cdktn.IResolvable): any;
export declare function awsCostCategoryRuleRuleAndCostCategoryPropertyToTerraform(struct?: AwsCostCategory.RuleRuleAndCostCategoryPropertyOutputReference | AwsCostCategory.RuleRuleAndCostCategoryProperty): any;
export declare function awsCostCategoryRuleRuleAndCostCategoryPropertyToHclTerraform(struct?: AwsCostCategory.RuleRuleAndCostCategoryPropertyOutputReference | AwsCostCategory.RuleRuleAndCostCategoryProperty): any;
export declare function awsCostCategoryRuleRuleAndDimensionPropertyToTerraform(struct?: AwsCostCategory.RuleRuleAndDimensionPropertyOutputReference | AwsCostCategory.RuleRuleAndDimensionProperty): any;
export declare function awsCostCategoryRuleRuleAndDimensionPropertyToHclTerraform(struct?: AwsCostCategory.RuleRuleAndDimensionPropertyOutputReference | AwsCostCategory.RuleRuleAndDimensionProperty): any;
export declare function awsCostCategoryRuleRuleAndNotCostCategoryPropertyToTerraform(struct?: AwsCostCategory.RuleRuleAndNotCostCategoryPropertyOutputReference | AwsCostCategory.RuleRuleAndNotCostCategoryProperty): any;
export declare function awsCostCategoryRuleRuleAndNotCostCategoryPropertyToHclTerraform(struct?: AwsCostCategory.RuleRuleAndNotCostCategoryPropertyOutputReference | AwsCostCategory.RuleRuleAndNotCostCategoryProperty): any;
export declare function awsCostCategoryRuleRuleAndNotDimensionPropertyToTerraform(struct?: AwsCostCategory.RuleRuleAndNotDimensionPropertyOutputReference | AwsCostCategory.RuleRuleAndNotDimensionProperty): any;
export declare function awsCostCategoryRuleRuleAndNotDimensionPropertyToHclTerraform(struct?: AwsCostCategory.RuleRuleAndNotDimensionPropertyOutputReference | AwsCostCategory.RuleRuleAndNotDimensionProperty): any;
export declare function awsCostCategoryRuleRuleAndNotTagsPropertyToTerraform(struct?: AwsCostCategory.RuleRuleAndNotTagsPropertyOutputReference | AwsCostCategory.RuleRuleAndNotTagsProperty): any;
export declare function awsCostCategoryRuleRuleAndNotTagsPropertyToHclTerraform(struct?: AwsCostCategory.RuleRuleAndNotTagsPropertyOutputReference | AwsCostCategory.RuleRuleAndNotTagsProperty): any;
export declare function awsCostCategoryRuleRuleAndNotPropertyToTerraform(struct?: AwsCostCategory.RuleRuleAndNotPropertyOutputReference | AwsCostCategory.RuleRuleAndNotProperty): any;
export declare function awsCostCategoryRuleRuleAndNotPropertyToHclTerraform(struct?: AwsCostCategory.RuleRuleAndNotPropertyOutputReference | AwsCostCategory.RuleRuleAndNotProperty): any;
export declare function awsCostCategoryRuleRuleAndOrCostCategoryPropertyToTerraform(struct?: AwsCostCategory.RuleRuleAndOrCostCategoryPropertyOutputReference | AwsCostCategory.RuleRuleAndOrCostCategoryProperty): any;
export declare function awsCostCategoryRuleRuleAndOrCostCategoryPropertyToHclTerraform(struct?: AwsCostCategory.RuleRuleAndOrCostCategoryPropertyOutputReference | AwsCostCategory.RuleRuleAndOrCostCategoryProperty): any;
export declare function awsCostCategoryRuleRuleAndOrDimensionPropertyToTerraform(struct?: AwsCostCategory.RuleRuleAndOrDimensionPropertyOutputReference | AwsCostCategory.RuleRuleAndOrDimensionProperty): any;
export declare function awsCostCategoryRuleRuleAndOrDimensionPropertyToHclTerraform(struct?: AwsCostCategory.RuleRuleAndOrDimensionPropertyOutputReference | AwsCostCategory.RuleRuleAndOrDimensionProperty): any;
export declare function awsCostCategoryRuleRuleAndOrTagsPropertyToTerraform(struct?: AwsCostCategory.RuleRuleAndOrTagsPropertyOutputReference | AwsCostCategory.RuleRuleAndOrTagsProperty): any;
export declare function awsCostCategoryRuleRuleAndOrTagsPropertyToHclTerraform(struct?: AwsCostCategory.RuleRuleAndOrTagsPropertyOutputReference | AwsCostCategory.RuleRuleAndOrTagsProperty): any;
export declare function awsCostCategoryRuleRuleAndOrPropertyToTerraform(struct?: AwsCostCategory.RuleRuleAndOrProperty | cdktn.IResolvable): any;
export declare function awsCostCategoryRuleRuleAndOrPropertyToHclTerraform(struct?: AwsCostCategory.RuleRuleAndOrProperty | cdktn.IResolvable): any;
export declare function awsCostCategoryRuleRuleAndTagsPropertyToTerraform(struct?: AwsCostCategory.RuleRuleAndTagsPropertyOutputReference | AwsCostCategory.RuleRuleAndTagsProperty): any;
export declare function awsCostCategoryRuleRuleAndTagsPropertyToHclTerraform(struct?: AwsCostCategory.RuleRuleAndTagsPropertyOutputReference | AwsCostCategory.RuleRuleAndTagsProperty): any;
export declare function awsCostCategoryRuleRuleAndPropertyToTerraform(struct?: AwsCostCategory.RuleRuleAndProperty | cdktn.IResolvable): any;
export declare function awsCostCategoryRuleRuleAndPropertyToHclTerraform(struct?: AwsCostCategory.RuleRuleAndProperty | cdktn.IResolvable): any;
export declare function awsCostCategoryRuleRuleCostCategoryPropertyToTerraform(struct?: AwsCostCategory.RuleRuleCostCategoryPropertyOutputReference | AwsCostCategory.RuleRuleCostCategoryProperty): any;
export declare function awsCostCategoryRuleRuleCostCategoryPropertyToHclTerraform(struct?: AwsCostCategory.RuleRuleCostCategoryPropertyOutputReference | AwsCostCategory.RuleRuleCostCategoryProperty): any;
export declare function awsCostCategoryRuleRuleDimensionPropertyToTerraform(struct?: AwsCostCategory.RuleRuleDimensionPropertyOutputReference | AwsCostCategory.RuleRuleDimensionProperty): any;
export declare function awsCostCategoryRuleRuleDimensionPropertyToHclTerraform(struct?: AwsCostCategory.RuleRuleDimensionPropertyOutputReference | AwsCostCategory.RuleRuleDimensionProperty): any;
export declare function awsCostCategoryRuleRuleNotAndCostCategoryPropertyToTerraform(struct?: AwsCostCategory.RuleRuleNotAndCostCategoryPropertyOutputReference | AwsCostCategory.RuleRuleNotAndCostCategoryProperty): any;
export declare function awsCostCategoryRuleRuleNotAndCostCategoryPropertyToHclTerraform(struct?: AwsCostCategory.RuleRuleNotAndCostCategoryPropertyOutputReference | AwsCostCategory.RuleRuleNotAndCostCategoryProperty): any;
export declare function awsCostCategoryRuleRuleNotAndDimensionPropertyToTerraform(struct?: AwsCostCategory.RuleRuleNotAndDimensionPropertyOutputReference | AwsCostCategory.RuleRuleNotAndDimensionProperty): any;
export declare function awsCostCategoryRuleRuleNotAndDimensionPropertyToHclTerraform(struct?: AwsCostCategory.RuleRuleNotAndDimensionPropertyOutputReference | AwsCostCategory.RuleRuleNotAndDimensionProperty): any;
export declare function awsCostCategoryRuleRuleNotAndTagsPropertyToTerraform(struct?: AwsCostCategory.RuleRuleNotAndTagsPropertyOutputReference | AwsCostCategory.RuleRuleNotAndTagsProperty): any;
export declare function awsCostCategoryRuleRuleNotAndTagsPropertyToHclTerraform(struct?: AwsCostCategory.RuleRuleNotAndTagsPropertyOutputReference | AwsCostCategory.RuleRuleNotAndTagsProperty): any;
export declare function awsCostCategoryRuleRuleNotAndPropertyToTerraform(struct?: AwsCostCategory.RuleRuleNotAndProperty | cdktn.IResolvable): any;
export declare function awsCostCategoryRuleRuleNotAndPropertyToHclTerraform(struct?: AwsCostCategory.RuleRuleNotAndProperty | cdktn.IResolvable): any;
export declare function awsCostCategoryRuleRuleNotCostCategoryPropertyToTerraform(struct?: AwsCostCategory.RuleRuleNotCostCategoryPropertyOutputReference | AwsCostCategory.RuleRuleNotCostCategoryProperty): any;
export declare function awsCostCategoryRuleRuleNotCostCategoryPropertyToHclTerraform(struct?: AwsCostCategory.RuleRuleNotCostCategoryPropertyOutputReference | AwsCostCategory.RuleRuleNotCostCategoryProperty): any;
export declare function awsCostCategoryRuleRuleNotDimensionPropertyToTerraform(struct?: AwsCostCategory.RuleRuleNotDimensionPropertyOutputReference | AwsCostCategory.RuleRuleNotDimensionProperty): any;
export declare function awsCostCategoryRuleRuleNotDimensionPropertyToHclTerraform(struct?: AwsCostCategory.RuleRuleNotDimensionPropertyOutputReference | AwsCostCategory.RuleRuleNotDimensionProperty): any;
export declare function awsCostCategoryRuleRuleNotNotCostCategoryPropertyToTerraform(struct?: AwsCostCategory.RuleRuleNotNotCostCategoryPropertyOutputReference | AwsCostCategory.RuleRuleNotNotCostCategoryProperty): any;
export declare function awsCostCategoryRuleRuleNotNotCostCategoryPropertyToHclTerraform(struct?: AwsCostCategory.RuleRuleNotNotCostCategoryPropertyOutputReference | AwsCostCategory.RuleRuleNotNotCostCategoryProperty): any;
export declare function awsCostCategoryRuleRuleNotNotDimensionPropertyToTerraform(struct?: AwsCostCategory.RuleRuleNotNotDimensionPropertyOutputReference | AwsCostCategory.RuleRuleNotNotDimensionProperty): any;
export declare function awsCostCategoryRuleRuleNotNotDimensionPropertyToHclTerraform(struct?: AwsCostCategory.RuleRuleNotNotDimensionPropertyOutputReference | AwsCostCategory.RuleRuleNotNotDimensionProperty): any;
export declare function awsCostCategoryRuleRuleNotNotTagsPropertyToTerraform(struct?: AwsCostCategory.RuleRuleNotNotTagsPropertyOutputReference | AwsCostCategory.RuleRuleNotNotTagsProperty): any;
export declare function awsCostCategoryRuleRuleNotNotTagsPropertyToHclTerraform(struct?: AwsCostCategory.RuleRuleNotNotTagsPropertyOutputReference | AwsCostCategory.RuleRuleNotNotTagsProperty): any;
export declare function awsCostCategoryRuleRuleNotNotPropertyToTerraform(struct?: AwsCostCategory.RuleRuleNotNotPropertyOutputReference | AwsCostCategory.RuleRuleNotNotProperty): any;
export declare function awsCostCategoryRuleRuleNotNotPropertyToHclTerraform(struct?: AwsCostCategory.RuleRuleNotNotPropertyOutputReference | AwsCostCategory.RuleRuleNotNotProperty): any;
export declare function awsCostCategoryRuleRuleNotOrCostCategoryPropertyToTerraform(struct?: AwsCostCategory.RuleRuleNotOrCostCategoryPropertyOutputReference | AwsCostCategory.RuleRuleNotOrCostCategoryProperty): any;
export declare function awsCostCategoryRuleRuleNotOrCostCategoryPropertyToHclTerraform(struct?: AwsCostCategory.RuleRuleNotOrCostCategoryPropertyOutputReference | AwsCostCategory.RuleRuleNotOrCostCategoryProperty): any;
export declare function awsCostCategoryRuleRuleNotOrDimensionPropertyToTerraform(struct?: AwsCostCategory.RuleRuleNotOrDimensionPropertyOutputReference | AwsCostCategory.RuleRuleNotOrDimensionProperty): any;
export declare function awsCostCategoryRuleRuleNotOrDimensionPropertyToHclTerraform(struct?: AwsCostCategory.RuleRuleNotOrDimensionPropertyOutputReference | AwsCostCategory.RuleRuleNotOrDimensionProperty): any;
export declare function awsCostCategoryRuleRuleNotOrTagsPropertyToTerraform(struct?: AwsCostCategory.RuleRuleNotOrTagsPropertyOutputReference | AwsCostCategory.RuleRuleNotOrTagsProperty): any;
export declare function awsCostCategoryRuleRuleNotOrTagsPropertyToHclTerraform(struct?: AwsCostCategory.RuleRuleNotOrTagsPropertyOutputReference | AwsCostCategory.RuleRuleNotOrTagsProperty): any;
export declare function awsCostCategoryRuleRuleNotOrPropertyToTerraform(struct?: AwsCostCategory.RuleRuleNotOrProperty | cdktn.IResolvable): any;
export declare function awsCostCategoryRuleRuleNotOrPropertyToHclTerraform(struct?: AwsCostCategory.RuleRuleNotOrProperty | cdktn.IResolvable): any;
export declare function awsCostCategoryRuleRuleNotTagsPropertyToTerraform(struct?: AwsCostCategory.RuleRuleNotTagsPropertyOutputReference | AwsCostCategory.RuleRuleNotTagsProperty): any;
export declare function awsCostCategoryRuleRuleNotTagsPropertyToHclTerraform(struct?: AwsCostCategory.RuleRuleNotTagsPropertyOutputReference | AwsCostCategory.RuleRuleNotTagsProperty): any;
export declare function awsCostCategoryRuleRuleNotPropertyToTerraform(struct?: AwsCostCategory.RuleRuleNotPropertyOutputReference | AwsCostCategory.RuleRuleNotProperty): any;
export declare function awsCostCategoryRuleRuleNotPropertyToHclTerraform(struct?: AwsCostCategory.RuleRuleNotPropertyOutputReference | AwsCostCategory.RuleRuleNotProperty): any;
export declare function awsCostCategoryRuleRuleOrAndCostCategoryPropertyToTerraform(struct?: AwsCostCategory.RuleRuleOrAndCostCategoryPropertyOutputReference | AwsCostCategory.RuleRuleOrAndCostCategoryProperty): any;
export declare function awsCostCategoryRuleRuleOrAndCostCategoryPropertyToHclTerraform(struct?: AwsCostCategory.RuleRuleOrAndCostCategoryPropertyOutputReference | AwsCostCategory.RuleRuleOrAndCostCategoryProperty): any;
export declare function awsCostCategoryRuleRuleOrAndDimensionPropertyToTerraform(struct?: AwsCostCategory.RuleRuleOrAndDimensionPropertyOutputReference | AwsCostCategory.RuleRuleOrAndDimensionProperty): any;
export declare function awsCostCategoryRuleRuleOrAndDimensionPropertyToHclTerraform(struct?: AwsCostCategory.RuleRuleOrAndDimensionPropertyOutputReference | AwsCostCategory.RuleRuleOrAndDimensionProperty): any;
export declare function awsCostCategoryRuleRuleOrAndTagsPropertyToTerraform(struct?: AwsCostCategory.RuleRuleOrAndTagsPropertyOutputReference | AwsCostCategory.RuleRuleOrAndTagsProperty): any;
export declare function awsCostCategoryRuleRuleOrAndTagsPropertyToHclTerraform(struct?: AwsCostCategory.RuleRuleOrAndTagsPropertyOutputReference | AwsCostCategory.RuleRuleOrAndTagsProperty): any;
export declare function awsCostCategoryRuleRuleOrAndPropertyToTerraform(struct?: AwsCostCategory.RuleRuleOrAndProperty | cdktn.IResolvable): any;
export declare function awsCostCategoryRuleRuleOrAndPropertyToHclTerraform(struct?: AwsCostCategory.RuleRuleOrAndProperty | cdktn.IResolvable): any;
export declare function awsCostCategoryRuleRuleOrCostCategoryPropertyToTerraform(struct?: AwsCostCategory.RuleRuleOrCostCategoryPropertyOutputReference | AwsCostCategory.RuleRuleOrCostCategoryProperty): any;
export declare function awsCostCategoryRuleRuleOrCostCategoryPropertyToHclTerraform(struct?: AwsCostCategory.RuleRuleOrCostCategoryPropertyOutputReference | AwsCostCategory.RuleRuleOrCostCategoryProperty): any;
export declare function awsCostCategoryRuleRuleOrDimensionPropertyToTerraform(struct?: AwsCostCategory.RuleRuleOrDimensionPropertyOutputReference | AwsCostCategory.RuleRuleOrDimensionProperty): any;
export declare function awsCostCategoryRuleRuleOrDimensionPropertyToHclTerraform(struct?: AwsCostCategory.RuleRuleOrDimensionPropertyOutputReference | AwsCostCategory.RuleRuleOrDimensionProperty): any;
export declare function awsCostCategoryRuleRuleOrNotCostCategoryPropertyToTerraform(struct?: AwsCostCategory.RuleRuleOrNotCostCategoryPropertyOutputReference | AwsCostCategory.RuleRuleOrNotCostCategoryProperty): any;
export declare function awsCostCategoryRuleRuleOrNotCostCategoryPropertyToHclTerraform(struct?: AwsCostCategory.RuleRuleOrNotCostCategoryPropertyOutputReference | AwsCostCategory.RuleRuleOrNotCostCategoryProperty): any;
export declare function awsCostCategoryRuleRuleOrNotDimensionPropertyToTerraform(struct?: AwsCostCategory.RuleRuleOrNotDimensionPropertyOutputReference | AwsCostCategory.RuleRuleOrNotDimensionProperty): any;
export declare function awsCostCategoryRuleRuleOrNotDimensionPropertyToHclTerraform(struct?: AwsCostCategory.RuleRuleOrNotDimensionPropertyOutputReference | AwsCostCategory.RuleRuleOrNotDimensionProperty): any;
export declare function awsCostCategoryRuleRuleOrNotTagsPropertyToTerraform(struct?: AwsCostCategory.RuleRuleOrNotTagsPropertyOutputReference | AwsCostCategory.RuleRuleOrNotTagsProperty): any;
export declare function awsCostCategoryRuleRuleOrNotTagsPropertyToHclTerraform(struct?: AwsCostCategory.RuleRuleOrNotTagsPropertyOutputReference | AwsCostCategory.RuleRuleOrNotTagsProperty): any;
export declare function awsCostCategoryRuleRuleOrNotPropertyToTerraform(struct?: AwsCostCategory.RuleRuleOrNotPropertyOutputReference | AwsCostCategory.RuleRuleOrNotProperty): any;
export declare function awsCostCategoryRuleRuleOrNotPropertyToHclTerraform(struct?: AwsCostCategory.RuleRuleOrNotPropertyOutputReference | AwsCostCategory.RuleRuleOrNotProperty): any;
export declare function awsCostCategoryRuleRuleOrOrCostCategoryPropertyToTerraform(struct?: AwsCostCategory.RuleRuleOrOrCostCategoryPropertyOutputReference | AwsCostCategory.RuleRuleOrOrCostCategoryProperty): any;
export declare function awsCostCategoryRuleRuleOrOrCostCategoryPropertyToHclTerraform(struct?: AwsCostCategory.RuleRuleOrOrCostCategoryPropertyOutputReference | AwsCostCategory.RuleRuleOrOrCostCategoryProperty): any;
export declare function awsCostCategoryRuleRuleOrOrDimensionPropertyToTerraform(struct?: AwsCostCategory.RuleRuleOrOrDimensionPropertyOutputReference | AwsCostCategory.RuleRuleOrOrDimensionProperty): any;
export declare function awsCostCategoryRuleRuleOrOrDimensionPropertyToHclTerraform(struct?: AwsCostCategory.RuleRuleOrOrDimensionPropertyOutputReference | AwsCostCategory.RuleRuleOrOrDimensionProperty): any;
export declare function awsCostCategoryRuleRuleOrOrTagsPropertyToTerraform(struct?: AwsCostCategory.RuleRuleOrOrTagsPropertyOutputReference | AwsCostCategory.RuleRuleOrOrTagsProperty): any;
export declare function awsCostCategoryRuleRuleOrOrTagsPropertyToHclTerraform(struct?: AwsCostCategory.RuleRuleOrOrTagsPropertyOutputReference | AwsCostCategory.RuleRuleOrOrTagsProperty): any;
export declare function awsCostCategoryRuleRuleOrOrPropertyToTerraform(struct?: AwsCostCategory.RuleRuleOrOrProperty | cdktn.IResolvable): any;
export declare function awsCostCategoryRuleRuleOrOrPropertyToHclTerraform(struct?: AwsCostCategory.RuleRuleOrOrProperty | cdktn.IResolvable): any;
export declare function awsCostCategoryRuleRuleOrTagsPropertyToTerraform(struct?: AwsCostCategory.RuleRuleOrTagsPropertyOutputReference | AwsCostCategory.RuleRuleOrTagsProperty): any;
export declare function awsCostCategoryRuleRuleOrTagsPropertyToHclTerraform(struct?: AwsCostCategory.RuleRuleOrTagsPropertyOutputReference | AwsCostCategory.RuleRuleOrTagsProperty): any;
export declare function awsCostCategoryRuleRuleOrPropertyToTerraform(struct?: AwsCostCategory.RuleRuleOrProperty | cdktn.IResolvable): any;
export declare function awsCostCategoryRuleRuleOrPropertyToHclTerraform(struct?: AwsCostCategory.RuleRuleOrProperty | cdktn.IResolvable): any;
export declare function awsCostCategoryRuleRuleTagsPropertyToTerraform(struct?: AwsCostCategory.RuleRuleTagsPropertyOutputReference | AwsCostCategory.RuleRuleTagsProperty): any;
export declare function awsCostCategoryRuleRuleTagsPropertyToHclTerraform(struct?: AwsCostCategory.RuleRuleTagsPropertyOutputReference | AwsCostCategory.RuleRuleTagsProperty): any;
export declare function awsCostCategoryRuleRulePropertyToTerraform(struct?: AwsCostCategory.RuleRulePropertyOutputReference | AwsCostCategory.RuleRuleProperty): any;
export declare function awsCostCategoryRuleRulePropertyToHclTerraform(struct?: AwsCostCategory.RuleRulePropertyOutputReference | AwsCostCategory.RuleRuleProperty): any;
export declare function awsCostCategoryRulePropertyToTerraform(struct?: AwsCostCategory.RuleProperty | cdktn.IResolvable): any;
export declare function awsCostCategoryRulePropertyToHclTerraform(struct?: AwsCostCategory.RuleProperty | cdktn.IResolvable): any;
export declare function awsCostCategoryParameterPropertyToTerraform(struct?: AwsCostCategory.ParameterProperty | cdktn.IResolvable): any;
export declare function awsCostCategoryParameterPropertyToHclTerraform(struct?: AwsCostCategory.ParameterProperty | cdktn.IResolvable): any;
export declare function awsCostCategorySplitChargeRulePropertyToTerraform(struct?: AwsCostCategory.SplitChargeRuleProperty | cdktn.IResolvable): any;
export declare function awsCostCategorySplitChargeRulePropertyToHclTerraform(struct?: AwsCostCategory.SplitChargeRuleProperty | cdktn.IResolvable): any;
export declare namespace AwsCostCategory {
    interface InheritedValueProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#dimension_key AwsCostCategory#dimension_key}
        */
        readonly dimensionKey?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#dimension_name AwsCostCategory#dimension_name}
        */
        readonly dimensionName?: string;
    }
    class InheritedValuePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): InheritedValueProperty | undefined;
        set internalValue(value: InheritedValueProperty | undefined);
        private _dimensionKey?;
        get dimensionKey(): string;
        set dimensionKey(value: string);
        resetDimensionKey(): void;
        get dimensionKeyInput(): string | undefined;
        private _dimensionName?;
        get dimensionName(): string;
        set dimensionName(value: string);
        resetDimensionName(): void;
        get dimensionNameInput(): string | undefined;
    }
    interface RuleRuleAndAndCostCategoryProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#key AwsCostCategory#key}
        */
        readonly key?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#match_options AwsCostCategory#match_options}
        */
        readonly matchOptions?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#values AwsCostCategory#values}
        */
        readonly values?: string[];
    }
    class RuleRuleAndAndCostCategoryPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RuleRuleAndAndCostCategoryProperty | undefined;
        set internalValue(value: RuleRuleAndAndCostCategoryProperty | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        resetKey(): void;
        get keyInput(): string | undefined;
        private _matchOptions?;
        get matchOptions(): string[];
        set matchOptions(value: string[]);
        resetMatchOptions(): void;
        get matchOptionsInput(): string[] | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        resetValues(): void;
        get valuesInput(): string[] | undefined;
    }
    interface RuleRuleAndAndDimensionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#key AwsCostCategory#key}
        */
        readonly key?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#match_options AwsCostCategory#match_options}
        */
        readonly matchOptions?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#values AwsCostCategory#values}
        */
        readonly values?: string[];
    }
    class RuleRuleAndAndDimensionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RuleRuleAndAndDimensionProperty | undefined;
        set internalValue(value: RuleRuleAndAndDimensionProperty | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        resetKey(): void;
        get keyInput(): string | undefined;
        private _matchOptions?;
        get matchOptions(): string[];
        set matchOptions(value: string[]);
        resetMatchOptions(): void;
        get matchOptionsInput(): string[] | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        resetValues(): void;
        get valuesInput(): string[] | undefined;
    }
    interface RuleRuleAndAndTagsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#key AwsCostCategory#key}
        */
        readonly key?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#match_options AwsCostCategory#match_options}
        */
        readonly matchOptions?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#values AwsCostCategory#values}
        */
        readonly values?: string[];
    }
    class RuleRuleAndAndTagsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RuleRuleAndAndTagsProperty | undefined;
        set internalValue(value: RuleRuleAndAndTagsProperty | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        resetKey(): void;
        get keyInput(): string | undefined;
        private _matchOptions?;
        get matchOptions(): string[];
        set matchOptions(value: string[]);
        resetMatchOptions(): void;
        get matchOptionsInput(): string[] | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        resetValues(): void;
        get valuesInput(): string[] | undefined;
    }
    interface RuleRuleAndAndProperty {
        /**
        * cost_category block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#cost_category AwsCostCategory#cost_category}
        */
        readonly costCategory?: RuleRuleAndAndCostCategoryProperty;
        /**
        * dimension block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#dimension AwsCostCategory#dimension}
        */
        readonly dimension?: RuleRuleAndAndDimensionProperty;
        /**
        * tags block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#tags AwsCostCategory#tags}
        */
        readonly tags?: RuleRuleAndAndTagsProperty;
    }
    class RuleRuleAndAndPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleRuleAndAndProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RuleRuleAndAndProperty | cdktn.IResolvable | undefined);
        private _costCategory;
        get costCategory(): RuleRuleAndAndCostCategoryPropertyOutputReference;
        putCostCategory(value: RuleRuleAndAndCostCategoryProperty): void;
        resetCostCategory(): void;
        get costCategoryInput(): RuleRuleAndAndCostCategoryProperty | undefined;
        private _dimension;
        get dimension(): RuleRuleAndAndDimensionPropertyOutputReference;
        putDimension(value: RuleRuleAndAndDimensionProperty): void;
        resetDimension(): void;
        get dimensionInput(): RuleRuleAndAndDimensionProperty | undefined;
        private _tags;
        get tags(): RuleRuleAndAndTagsPropertyOutputReference;
        putTags(value: RuleRuleAndAndTagsProperty): void;
        resetTags(): void;
        get tagsInput(): RuleRuleAndAndTagsProperty | undefined;
    }
    class RuleRuleAndAndPropertyList extends cdktn.ComplexList {
        internalValue?: RuleRuleAndAndProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleRuleAndAndPropertyOutputReference;
    }
    interface RuleRuleAndCostCategoryProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#key AwsCostCategory#key}
        */
        readonly key?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#match_options AwsCostCategory#match_options}
        */
        readonly matchOptions?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#values AwsCostCategory#values}
        */
        readonly values?: string[];
    }
    class RuleRuleAndCostCategoryPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RuleRuleAndCostCategoryProperty | undefined;
        set internalValue(value: RuleRuleAndCostCategoryProperty | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        resetKey(): void;
        get keyInput(): string | undefined;
        private _matchOptions?;
        get matchOptions(): string[];
        set matchOptions(value: string[]);
        resetMatchOptions(): void;
        get matchOptionsInput(): string[] | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        resetValues(): void;
        get valuesInput(): string[] | undefined;
    }
    interface RuleRuleAndDimensionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#key AwsCostCategory#key}
        */
        readonly key?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#match_options AwsCostCategory#match_options}
        */
        readonly matchOptions?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#values AwsCostCategory#values}
        */
        readonly values?: string[];
    }
    class RuleRuleAndDimensionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RuleRuleAndDimensionProperty | undefined;
        set internalValue(value: RuleRuleAndDimensionProperty | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        resetKey(): void;
        get keyInput(): string | undefined;
        private _matchOptions?;
        get matchOptions(): string[];
        set matchOptions(value: string[]);
        resetMatchOptions(): void;
        get matchOptionsInput(): string[] | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        resetValues(): void;
        get valuesInput(): string[] | undefined;
    }
    interface RuleRuleAndNotCostCategoryProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#key AwsCostCategory#key}
        */
        readonly key?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#match_options AwsCostCategory#match_options}
        */
        readonly matchOptions?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#values AwsCostCategory#values}
        */
        readonly values?: string[];
    }
    class RuleRuleAndNotCostCategoryPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RuleRuleAndNotCostCategoryProperty | undefined;
        set internalValue(value: RuleRuleAndNotCostCategoryProperty | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        resetKey(): void;
        get keyInput(): string | undefined;
        private _matchOptions?;
        get matchOptions(): string[];
        set matchOptions(value: string[]);
        resetMatchOptions(): void;
        get matchOptionsInput(): string[] | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        resetValues(): void;
        get valuesInput(): string[] | undefined;
    }
    interface RuleRuleAndNotDimensionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#key AwsCostCategory#key}
        */
        readonly key?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#match_options AwsCostCategory#match_options}
        */
        readonly matchOptions?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#values AwsCostCategory#values}
        */
        readonly values?: string[];
    }
    class RuleRuleAndNotDimensionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RuleRuleAndNotDimensionProperty | undefined;
        set internalValue(value: RuleRuleAndNotDimensionProperty | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        resetKey(): void;
        get keyInput(): string | undefined;
        private _matchOptions?;
        get matchOptions(): string[];
        set matchOptions(value: string[]);
        resetMatchOptions(): void;
        get matchOptionsInput(): string[] | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        resetValues(): void;
        get valuesInput(): string[] | undefined;
    }
    interface RuleRuleAndNotTagsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#key AwsCostCategory#key}
        */
        readonly key?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#match_options AwsCostCategory#match_options}
        */
        readonly matchOptions?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#values AwsCostCategory#values}
        */
        readonly values?: string[];
    }
    class RuleRuleAndNotTagsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RuleRuleAndNotTagsProperty | undefined;
        set internalValue(value: RuleRuleAndNotTagsProperty | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        resetKey(): void;
        get keyInput(): string | undefined;
        private _matchOptions?;
        get matchOptions(): string[];
        set matchOptions(value: string[]);
        resetMatchOptions(): void;
        get matchOptionsInput(): string[] | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        resetValues(): void;
        get valuesInput(): string[] | undefined;
    }
    interface RuleRuleAndNotProperty {
        /**
        * cost_category block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#cost_category AwsCostCategory#cost_category}
        */
        readonly costCategory?: RuleRuleAndNotCostCategoryProperty;
        /**
        * dimension block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#dimension AwsCostCategory#dimension}
        */
        readonly dimension?: RuleRuleAndNotDimensionProperty;
        /**
        * tags block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#tags AwsCostCategory#tags}
        */
        readonly tags?: RuleRuleAndNotTagsProperty;
    }
    class RuleRuleAndNotPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RuleRuleAndNotProperty | undefined;
        set internalValue(value: RuleRuleAndNotProperty | undefined);
        private _costCategory;
        get costCategory(): RuleRuleAndNotCostCategoryPropertyOutputReference;
        putCostCategory(value: RuleRuleAndNotCostCategoryProperty): void;
        resetCostCategory(): void;
        get costCategoryInput(): RuleRuleAndNotCostCategoryProperty | undefined;
        private _dimension;
        get dimension(): RuleRuleAndNotDimensionPropertyOutputReference;
        putDimension(value: RuleRuleAndNotDimensionProperty): void;
        resetDimension(): void;
        get dimensionInput(): RuleRuleAndNotDimensionProperty | undefined;
        private _tags;
        get tags(): RuleRuleAndNotTagsPropertyOutputReference;
        putTags(value: RuleRuleAndNotTagsProperty): void;
        resetTags(): void;
        get tagsInput(): RuleRuleAndNotTagsProperty | undefined;
    }
    interface RuleRuleAndOrCostCategoryProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#key AwsCostCategory#key}
        */
        readonly key?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#match_options AwsCostCategory#match_options}
        */
        readonly matchOptions?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#values AwsCostCategory#values}
        */
        readonly values?: string[];
    }
    class RuleRuleAndOrCostCategoryPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RuleRuleAndOrCostCategoryProperty | undefined;
        set internalValue(value: RuleRuleAndOrCostCategoryProperty | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        resetKey(): void;
        get keyInput(): string | undefined;
        private _matchOptions?;
        get matchOptions(): string[];
        set matchOptions(value: string[]);
        resetMatchOptions(): void;
        get matchOptionsInput(): string[] | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        resetValues(): void;
        get valuesInput(): string[] | undefined;
    }
    interface RuleRuleAndOrDimensionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#key AwsCostCategory#key}
        */
        readonly key?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#match_options AwsCostCategory#match_options}
        */
        readonly matchOptions?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#values AwsCostCategory#values}
        */
        readonly values?: string[];
    }
    class RuleRuleAndOrDimensionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RuleRuleAndOrDimensionProperty | undefined;
        set internalValue(value: RuleRuleAndOrDimensionProperty | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        resetKey(): void;
        get keyInput(): string | undefined;
        private _matchOptions?;
        get matchOptions(): string[];
        set matchOptions(value: string[]);
        resetMatchOptions(): void;
        get matchOptionsInput(): string[] | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        resetValues(): void;
        get valuesInput(): string[] | undefined;
    }
    interface RuleRuleAndOrTagsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#key AwsCostCategory#key}
        */
        readonly key?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#match_options AwsCostCategory#match_options}
        */
        readonly matchOptions?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#values AwsCostCategory#values}
        */
        readonly values?: string[];
    }
    class RuleRuleAndOrTagsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RuleRuleAndOrTagsProperty | undefined;
        set internalValue(value: RuleRuleAndOrTagsProperty | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        resetKey(): void;
        get keyInput(): string | undefined;
        private _matchOptions?;
        get matchOptions(): string[];
        set matchOptions(value: string[]);
        resetMatchOptions(): void;
        get matchOptionsInput(): string[] | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        resetValues(): void;
        get valuesInput(): string[] | undefined;
    }
    interface RuleRuleAndOrProperty {
        /**
        * cost_category block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#cost_category AwsCostCategory#cost_category}
        */
        readonly costCategory?: RuleRuleAndOrCostCategoryProperty;
        /**
        * dimension block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#dimension AwsCostCategory#dimension}
        */
        readonly dimension?: RuleRuleAndOrDimensionProperty;
        /**
        * tags block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#tags AwsCostCategory#tags}
        */
        readonly tags?: RuleRuleAndOrTagsProperty;
    }
    class RuleRuleAndOrPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleRuleAndOrProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RuleRuleAndOrProperty | cdktn.IResolvable | undefined);
        private _costCategory;
        get costCategory(): RuleRuleAndOrCostCategoryPropertyOutputReference;
        putCostCategory(value: RuleRuleAndOrCostCategoryProperty): void;
        resetCostCategory(): void;
        get costCategoryInput(): RuleRuleAndOrCostCategoryProperty | undefined;
        private _dimension;
        get dimension(): RuleRuleAndOrDimensionPropertyOutputReference;
        putDimension(value: RuleRuleAndOrDimensionProperty): void;
        resetDimension(): void;
        get dimensionInput(): RuleRuleAndOrDimensionProperty | undefined;
        private _tags;
        get tags(): RuleRuleAndOrTagsPropertyOutputReference;
        putTags(value: RuleRuleAndOrTagsProperty): void;
        resetTags(): void;
        get tagsInput(): RuleRuleAndOrTagsProperty | undefined;
    }
    class RuleRuleAndOrPropertyList extends cdktn.ComplexList {
        internalValue?: RuleRuleAndOrProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleRuleAndOrPropertyOutputReference;
    }
    interface RuleRuleAndTagsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#key AwsCostCategory#key}
        */
        readonly key?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#match_options AwsCostCategory#match_options}
        */
        readonly matchOptions?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#values AwsCostCategory#values}
        */
        readonly values?: string[];
    }
    class RuleRuleAndTagsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RuleRuleAndTagsProperty | undefined;
        set internalValue(value: RuleRuleAndTagsProperty | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        resetKey(): void;
        get keyInput(): string | undefined;
        private _matchOptions?;
        get matchOptions(): string[];
        set matchOptions(value: string[]);
        resetMatchOptions(): void;
        get matchOptionsInput(): string[] | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        resetValues(): void;
        get valuesInput(): string[] | undefined;
    }
    interface RuleRuleAndProperty {
        /**
        * and block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#and AwsCostCategory#and}
        */
        readonly and?: RuleRuleAndAndProperty[] | cdktn.IResolvable;
        /**
        * cost_category block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#cost_category AwsCostCategory#cost_category}
        */
        readonly costCategory?: RuleRuleAndCostCategoryProperty;
        /**
        * dimension block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#dimension AwsCostCategory#dimension}
        */
        readonly dimension?: RuleRuleAndDimensionProperty;
        /**
        * not block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#not AwsCostCategory#not}
        */
        readonly not?: RuleRuleAndNotProperty;
        /**
        * or block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#or AwsCostCategory#or}
        */
        readonly or?: RuleRuleAndOrProperty[] | cdktn.IResolvable;
        /**
        * tags block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#tags AwsCostCategory#tags}
        */
        readonly tags?: RuleRuleAndTagsProperty;
    }
    class RuleRuleAndPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleRuleAndProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RuleRuleAndProperty | cdktn.IResolvable | undefined);
        private _and;
        get and(): RuleRuleAndAndPropertyList;
        putAnd(value: RuleRuleAndAndProperty[] | cdktn.IResolvable): void;
        resetAnd(): void;
        get andInput(): cdktn.IResolvable | RuleRuleAndAndProperty[] | undefined;
        private _costCategory;
        get costCategory(): RuleRuleAndCostCategoryPropertyOutputReference;
        putCostCategory(value: RuleRuleAndCostCategoryProperty): void;
        resetCostCategory(): void;
        get costCategoryInput(): RuleRuleAndCostCategoryProperty | undefined;
        private _dimension;
        get dimension(): RuleRuleAndDimensionPropertyOutputReference;
        putDimension(value: RuleRuleAndDimensionProperty): void;
        resetDimension(): void;
        get dimensionInput(): RuleRuleAndDimensionProperty | undefined;
        private _not;
        get not(): RuleRuleAndNotPropertyOutputReference;
        putNot(value: RuleRuleAndNotProperty): void;
        resetNot(): void;
        get notInput(): RuleRuleAndNotProperty | undefined;
        private _or;
        get or(): RuleRuleAndOrPropertyList;
        putOr(value: RuleRuleAndOrProperty[] | cdktn.IResolvable): void;
        resetOr(): void;
        get orInput(): cdktn.IResolvable | RuleRuleAndOrProperty[] | undefined;
        private _tags;
        get tags(): RuleRuleAndTagsPropertyOutputReference;
        putTags(value: RuleRuleAndTagsProperty): void;
        resetTags(): void;
        get tagsInput(): RuleRuleAndTagsProperty | undefined;
    }
    class RuleRuleAndPropertyList extends cdktn.ComplexList {
        internalValue?: RuleRuleAndProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleRuleAndPropertyOutputReference;
    }
    interface RuleRuleCostCategoryProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#key AwsCostCategory#key}
        */
        readonly key?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#match_options AwsCostCategory#match_options}
        */
        readonly matchOptions?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#values AwsCostCategory#values}
        */
        readonly values?: string[];
    }
    class RuleRuleCostCategoryPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RuleRuleCostCategoryProperty | undefined;
        set internalValue(value: RuleRuleCostCategoryProperty | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        resetKey(): void;
        get keyInput(): string | undefined;
        private _matchOptions?;
        get matchOptions(): string[];
        set matchOptions(value: string[]);
        resetMatchOptions(): void;
        get matchOptionsInput(): string[] | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        resetValues(): void;
        get valuesInput(): string[] | undefined;
    }
    interface RuleRuleDimensionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#key AwsCostCategory#key}
        */
        readonly key?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#match_options AwsCostCategory#match_options}
        */
        readonly matchOptions?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#values AwsCostCategory#values}
        */
        readonly values?: string[];
    }
    class RuleRuleDimensionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RuleRuleDimensionProperty | undefined;
        set internalValue(value: RuleRuleDimensionProperty | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        resetKey(): void;
        get keyInput(): string | undefined;
        private _matchOptions?;
        get matchOptions(): string[];
        set matchOptions(value: string[]);
        resetMatchOptions(): void;
        get matchOptionsInput(): string[] | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        resetValues(): void;
        get valuesInput(): string[] | undefined;
    }
    interface RuleRuleNotAndCostCategoryProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#key AwsCostCategory#key}
        */
        readonly key?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#match_options AwsCostCategory#match_options}
        */
        readonly matchOptions?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#values AwsCostCategory#values}
        */
        readonly values?: string[];
    }
    class RuleRuleNotAndCostCategoryPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RuleRuleNotAndCostCategoryProperty | undefined;
        set internalValue(value: RuleRuleNotAndCostCategoryProperty | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        resetKey(): void;
        get keyInput(): string | undefined;
        private _matchOptions?;
        get matchOptions(): string[];
        set matchOptions(value: string[]);
        resetMatchOptions(): void;
        get matchOptionsInput(): string[] | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        resetValues(): void;
        get valuesInput(): string[] | undefined;
    }
    interface RuleRuleNotAndDimensionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#key AwsCostCategory#key}
        */
        readonly key?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#match_options AwsCostCategory#match_options}
        */
        readonly matchOptions?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#values AwsCostCategory#values}
        */
        readonly values?: string[];
    }
    class RuleRuleNotAndDimensionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RuleRuleNotAndDimensionProperty | undefined;
        set internalValue(value: RuleRuleNotAndDimensionProperty | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        resetKey(): void;
        get keyInput(): string | undefined;
        private _matchOptions?;
        get matchOptions(): string[];
        set matchOptions(value: string[]);
        resetMatchOptions(): void;
        get matchOptionsInput(): string[] | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        resetValues(): void;
        get valuesInput(): string[] | undefined;
    }
    interface RuleRuleNotAndTagsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#key AwsCostCategory#key}
        */
        readonly key?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#match_options AwsCostCategory#match_options}
        */
        readonly matchOptions?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#values AwsCostCategory#values}
        */
        readonly values?: string[];
    }
    class RuleRuleNotAndTagsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RuleRuleNotAndTagsProperty | undefined;
        set internalValue(value: RuleRuleNotAndTagsProperty | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        resetKey(): void;
        get keyInput(): string | undefined;
        private _matchOptions?;
        get matchOptions(): string[];
        set matchOptions(value: string[]);
        resetMatchOptions(): void;
        get matchOptionsInput(): string[] | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        resetValues(): void;
        get valuesInput(): string[] | undefined;
    }
    interface RuleRuleNotAndProperty {
        /**
        * cost_category block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#cost_category AwsCostCategory#cost_category}
        */
        readonly costCategory?: RuleRuleNotAndCostCategoryProperty;
        /**
        * dimension block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#dimension AwsCostCategory#dimension}
        */
        readonly dimension?: RuleRuleNotAndDimensionProperty;
        /**
        * tags block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#tags AwsCostCategory#tags}
        */
        readonly tags?: RuleRuleNotAndTagsProperty;
    }
    class RuleRuleNotAndPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleRuleNotAndProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RuleRuleNotAndProperty | cdktn.IResolvable | undefined);
        private _costCategory;
        get costCategory(): RuleRuleNotAndCostCategoryPropertyOutputReference;
        putCostCategory(value: RuleRuleNotAndCostCategoryProperty): void;
        resetCostCategory(): void;
        get costCategoryInput(): RuleRuleNotAndCostCategoryProperty | undefined;
        private _dimension;
        get dimension(): RuleRuleNotAndDimensionPropertyOutputReference;
        putDimension(value: RuleRuleNotAndDimensionProperty): void;
        resetDimension(): void;
        get dimensionInput(): RuleRuleNotAndDimensionProperty | undefined;
        private _tags;
        get tags(): RuleRuleNotAndTagsPropertyOutputReference;
        putTags(value: RuleRuleNotAndTagsProperty): void;
        resetTags(): void;
        get tagsInput(): RuleRuleNotAndTagsProperty | undefined;
    }
    class RuleRuleNotAndPropertyList extends cdktn.ComplexList {
        internalValue?: RuleRuleNotAndProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleRuleNotAndPropertyOutputReference;
    }
    interface RuleRuleNotCostCategoryProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#key AwsCostCategory#key}
        */
        readonly key?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#match_options AwsCostCategory#match_options}
        */
        readonly matchOptions?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#values AwsCostCategory#values}
        */
        readonly values?: string[];
    }
    class RuleRuleNotCostCategoryPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RuleRuleNotCostCategoryProperty | undefined;
        set internalValue(value: RuleRuleNotCostCategoryProperty | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        resetKey(): void;
        get keyInput(): string | undefined;
        private _matchOptions?;
        get matchOptions(): string[];
        set matchOptions(value: string[]);
        resetMatchOptions(): void;
        get matchOptionsInput(): string[] | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        resetValues(): void;
        get valuesInput(): string[] | undefined;
    }
    interface RuleRuleNotDimensionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#key AwsCostCategory#key}
        */
        readonly key?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#match_options AwsCostCategory#match_options}
        */
        readonly matchOptions?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#values AwsCostCategory#values}
        */
        readonly values?: string[];
    }
    class RuleRuleNotDimensionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RuleRuleNotDimensionProperty | undefined;
        set internalValue(value: RuleRuleNotDimensionProperty | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        resetKey(): void;
        get keyInput(): string | undefined;
        private _matchOptions?;
        get matchOptions(): string[];
        set matchOptions(value: string[]);
        resetMatchOptions(): void;
        get matchOptionsInput(): string[] | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        resetValues(): void;
        get valuesInput(): string[] | undefined;
    }
    interface RuleRuleNotNotCostCategoryProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#key AwsCostCategory#key}
        */
        readonly key?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#match_options AwsCostCategory#match_options}
        */
        readonly matchOptions?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#values AwsCostCategory#values}
        */
        readonly values?: string[];
    }
    class RuleRuleNotNotCostCategoryPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RuleRuleNotNotCostCategoryProperty | undefined;
        set internalValue(value: RuleRuleNotNotCostCategoryProperty | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        resetKey(): void;
        get keyInput(): string | undefined;
        private _matchOptions?;
        get matchOptions(): string[];
        set matchOptions(value: string[]);
        resetMatchOptions(): void;
        get matchOptionsInput(): string[] | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        resetValues(): void;
        get valuesInput(): string[] | undefined;
    }
    interface RuleRuleNotNotDimensionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#key AwsCostCategory#key}
        */
        readonly key?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#match_options AwsCostCategory#match_options}
        */
        readonly matchOptions?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#values AwsCostCategory#values}
        */
        readonly values?: string[];
    }
    class RuleRuleNotNotDimensionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RuleRuleNotNotDimensionProperty | undefined;
        set internalValue(value: RuleRuleNotNotDimensionProperty | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        resetKey(): void;
        get keyInput(): string | undefined;
        private _matchOptions?;
        get matchOptions(): string[];
        set matchOptions(value: string[]);
        resetMatchOptions(): void;
        get matchOptionsInput(): string[] | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        resetValues(): void;
        get valuesInput(): string[] | undefined;
    }
    interface RuleRuleNotNotTagsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#key AwsCostCategory#key}
        */
        readonly key?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#match_options AwsCostCategory#match_options}
        */
        readonly matchOptions?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#values AwsCostCategory#values}
        */
        readonly values?: string[];
    }
    class RuleRuleNotNotTagsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RuleRuleNotNotTagsProperty | undefined;
        set internalValue(value: RuleRuleNotNotTagsProperty | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        resetKey(): void;
        get keyInput(): string | undefined;
        private _matchOptions?;
        get matchOptions(): string[];
        set matchOptions(value: string[]);
        resetMatchOptions(): void;
        get matchOptionsInput(): string[] | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        resetValues(): void;
        get valuesInput(): string[] | undefined;
    }
    interface RuleRuleNotNotProperty {
        /**
        * cost_category block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#cost_category AwsCostCategory#cost_category}
        */
        readonly costCategory?: RuleRuleNotNotCostCategoryProperty;
        /**
        * dimension block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#dimension AwsCostCategory#dimension}
        */
        readonly dimension?: RuleRuleNotNotDimensionProperty;
        /**
        * tags block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#tags AwsCostCategory#tags}
        */
        readonly tags?: RuleRuleNotNotTagsProperty;
    }
    class RuleRuleNotNotPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RuleRuleNotNotProperty | undefined;
        set internalValue(value: RuleRuleNotNotProperty | undefined);
        private _costCategory;
        get costCategory(): RuleRuleNotNotCostCategoryPropertyOutputReference;
        putCostCategory(value: RuleRuleNotNotCostCategoryProperty): void;
        resetCostCategory(): void;
        get costCategoryInput(): RuleRuleNotNotCostCategoryProperty | undefined;
        private _dimension;
        get dimension(): RuleRuleNotNotDimensionPropertyOutputReference;
        putDimension(value: RuleRuleNotNotDimensionProperty): void;
        resetDimension(): void;
        get dimensionInput(): RuleRuleNotNotDimensionProperty | undefined;
        private _tags;
        get tags(): RuleRuleNotNotTagsPropertyOutputReference;
        putTags(value: RuleRuleNotNotTagsProperty): void;
        resetTags(): void;
        get tagsInput(): RuleRuleNotNotTagsProperty | undefined;
    }
    interface RuleRuleNotOrCostCategoryProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#key AwsCostCategory#key}
        */
        readonly key?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#match_options AwsCostCategory#match_options}
        */
        readonly matchOptions?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#values AwsCostCategory#values}
        */
        readonly values?: string[];
    }
    class RuleRuleNotOrCostCategoryPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RuleRuleNotOrCostCategoryProperty | undefined;
        set internalValue(value: RuleRuleNotOrCostCategoryProperty | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        resetKey(): void;
        get keyInput(): string | undefined;
        private _matchOptions?;
        get matchOptions(): string[];
        set matchOptions(value: string[]);
        resetMatchOptions(): void;
        get matchOptionsInput(): string[] | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        resetValues(): void;
        get valuesInput(): string[] | undefined;
    }
    interface RuleRuleNotOrDimensionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#key AwsCostCategory#key}
        */
        readonly key?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#match_options AwsCostCategory#match_options}
        */
        readonly matchOptions?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#values AwsCostCategory#values}
        */
        readonly values?: string[];
    }
    class RuleRuleNotOrDimensionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RuleRuleNotOrDimensionProperty | undefined;
        set internalValue(value: RuleRuleNotOrDimensionProperty | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        resetKey(): void;
        get keyInput(): string | undefined;
        private _matchOptions?;
        get matchOptions(): string[];
        set matchOptions(value: string[]);
        resetMatchOptions(): void;
        get matchOptionsInput(): string[] | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        resetValues(): void;
        get valuesInput(): string[] | undefined;
    }
    interface RuleRuleNotOrTagsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#key AwsCostCategory#key}
        */
        readonly key?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#match_options AwsCostCategory#match_options}
        */
        readonly matchOptions?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#values AwsCostCategory#values}
        */
        readonly values?: string[];
    }
    class RuleRuleNotOrTagsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RuleRuleNotOrTagsProperty | undefined;
        set internalValue(value: RuleRuleNotOrTagsProperty | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        resetKey(): void;
        get keyInput(): string | undefined;
        private _matchOptions?;
        get matchOptions(): string[];
        set matchOptions(value: string[]);
        resetMatchOptions(): void;
        get matchOptionsInput(): string[] | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        resetValues(): void;
        get valuesInput(): string[] | undefined;
    }
    interface RuleRuleNotOrProperty {
        /**
        * cost_category block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#cost_category AwsCostCategory#cost_category}
        */
        readonly costCategory?: RuleRuleNotOrCostCategoryProperty;
        /**
        * dimension block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#dimension AwsCostCategory#dimension}
        */
        readonly dimension?: RuleRuleNotOrDimensionProperty;
        /**
        * tags block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#tags AwsCostCategory#tags}
        */
        readonly tags?: RuleRuleNotOrTagsProperty;
    }
    class RuleRuleNotOrPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleRuleNotOrProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RuleRuleNotOrProperty | cdktn.IResolvable | undefined);
        private _costCategory;
        get costCategory(): RuleRuleNotOrCostCategoryPropertyOutputReference;
        putCostCategory(value: RuleRuleNotOrCostCategoryProperty): void;
        resetCostCategory(): void;
        get costCategoryInput(): RuleRuleNotOrCostCategoryProperty | undefined;
        private _dimension;
        get dimension(): RuleRuleNotOrDimensionPropertyOutputReference;
        putDimension(value: RuleRuleNotOrDimensionProperty): void;
        resetDimension(): void;
        get dimensionInput(): RuleRuleNotOrDimensionProperty | undefined;
        private _tags;
        get tags(): RuleRuleNotOrTagsPropertyOutputReference;
        putTags(value: RuleRuleNotOrTagsProperty): void;
        resetTags(): void;
        get tagsInput(): RuleRuleNotOrTagsProperty | undefined;
    }
    class RuleRuleNotOrPropertyList extends cdktn.ComplexList {
        internalValue?: RuleRuleNotOrProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleRuleNotOrPropertyOutputReference;
    }
    interface RuleRuleNotTagsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#key AwsCostCategory#key}
        */
        readonly key?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#match_options AwsCostCategory#match_options}
        */
        readonly matchOptions?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#values AwsCostCategory#values}
        */
        readonly values?: string[];
    }
    class RuleRuleNotTagsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RuleRuleNotTagsProperty | undefined;
        set internalValue(value: RuleRuleNotTagsProperty | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        resetKey(): void;
        get keyInput(): string | undefined;
        private _matchOptions?;
        get matchOptions(): string[];
        set matchOptions(value: string[]);
        resetMatchOptions(): void;
        get matchOptionsInput(): string[] | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        resetValues(): void;
        get valuesInput(): string[] | undefined;
    }
    interface RuleRuleNotProperty {
        /**
        * and block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#and AwsCostCategory#and}
        */
        readonly and?: RuleRuleNotAndProperty[] | cdktn.IResolvable;
        /**
        * cost_category block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#cost_category AwsCostCategory#cost_category}
        */
        readonly costCategory?: RuleRuleNotCostCategoryProperty;
        /**
        * dimension block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#dimension AwsCostCategory#dimension}
        */
        readonly dimension?: RuleRuleNotDimensionProperty;
        /**
        * not block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#not AwsCostCategory#not}
        */
        readonly not?: RuleRuleNotNotProperty;
        /**
        * or block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#or AwsCostCategory#or}
        */
        readonly or?: RuleRuleNotOrProperty[] | cdktn.IResolvable;
        /**
        * tags block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#tags AwsCostCategory#tags}
        */
        readonly tags?: RuleRuleNotTagsProperty;
    }
    class RuleRuleNotPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RuleRuleNotProperty | undefined;
        set internalValue(value: RuleRuleNotProperty | undefined);
        private _and;
        get and(): RuleRuleNotAndPropertyList;
        putAnd(value: RuleRuleNotAndProperty[] | cdktn.IResolvable): void;
        resetAnd(): void;
        get andInput(): cdktn.IResolvable | RuleRuleNotAndProperty[] | undefined;
        private _costCategory;
        get costCategory(): RuleRuleNotCostCategoryPropertyOutputReference;
        putCostCategory(value: RuleRuleNotCostCategoryProperty): void;
        resetCostCategory(): void;
        get costCategoryInput(): RuleRuleNotCostCategoryProperty | undefined;
        private _dimension;
        get dimension(): RuleRuleNotDimensionPropertyOutputReference;
        putDimension(value: RuleRuleNotDimensionProperty): void;
        resetDimension(): void;
        get dimensionInput(): RuleRuleNotDimensionProperty | undefined;
        private _not;
        get not(): RuleRuleNotNotPropertyOutputReference;
        putNot(value: RuleRuleNotNotProperty): void;
        resetNot(): void;
        get notInput(): RuleRuleNotNotProperty | undefined;
        private _or;
        get or(): RuleRuleNotOrPropertyList;
        putOr(value: RuleRuleNotOrProperty[] | cdktn.IResolvable): void;
        resetOr(): void;
        get orInput(): cdktn.IResolvable | RuleRuleNotOrProperty[] | undefined;
        private _tags;
        get tags(): RuleRuleNotTagsPropertyOutputReference;
        putTags(value: RuleRuleNotTagsProperty): void;
        resetTags(): void;
        get tagsInput(): RuleRuleNotTagsProperty | undefined;
    }
    interface RuleRuleOrAndCostCategoryProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#key AwsCostCategory#key}
        */
        readonly key?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#match_options AwsCostCategory#match_options}
        */
        readonly matchOptions?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#values AwsCostCategory#values}
        */
        readonly values?: string[];
    }
    class RuleRuleOrAndCostCategoryPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RuleRuleOrAndCostCategoryProperty | undefined;
        set internalValue(value: RuleRuleOrAndCostCategoryProperty | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        resetKey(): void;
        get keyInput(): string | undefined;
        private _matchOptions?;
        get matchOptions(): string[];
        set matchOptions(value: string[]);
        resetMatchOptions(): void;
        get matchOptionsInput(): string[] | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        resetValues(): void;
        get valuesInput(): string[] | undefined;
    }
    interface RuleRuleOrAndDimensionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#key AwsCostCategory#key}
        */
        readonly key?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#match_options AwsCostCategory#match_options}
        */
        readonly matchOptions?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#values AwsCostCategory#values}
        */
        readonly values?: string[];
    }
    class RuleRuleOrAndDimensionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RuleRuleOrAndDimensionProperty | undefined;
        set internalValue(value: RuleRuleOrAndDimensionProperty | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        resetKey(): void;
        get keyInput(): string | undefined;
        private _matchOptions?;
        get matchOptions(): string[];
        set matchOptions(value: string[]);
        resetMatchOptions(): void;
        get matchOptionsInput(): string[] | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        resetValues(): void;
        get valuesInput(): string[] | undefined;
    }
    interface RuleRuleOrAndTagsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#key AwsCostCategory#key}
        */
        readonly key?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#match_options AwsCostCategory#match_options}
        */
        readonly matchOptions?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#values AwsCostCategory#values}
        */
        readonly values?: string[];
    }
    class RuleRuleOrAndTagsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RuleRuleOrAndTagsProperty | undefined;
        set internalValue(value: RuleRuleOrAndTagsProperty | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        resetKey(): void;
        get keyInput(): string | undefined;
        private _matchOptions?;
        get matchOptions(): string[];
        set matchOptions(value: string[]);
        resetMatchOptions(): void;
        get matchOptionsInput(): string[] | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        resetValues(): void;
        get valuesInput(): string[] | undefined;
    }
    interface RuleRuleOrAndProperty {
        /**
        * cost_category block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#cost_category AwsCostCategory#cost_category}
        */
        readonly costCategory?: RuleRuleOrAndCostCategoryProperty;
        /**
        * dimension block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#dimension AwsCostCategory#dimension}
        */
        readonly dimension?: RuleRuleOrAndDimensionProperty;
        /**
        * tags block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#tags AwsCostCategory#tags}
        */
        readonly tags?: RuleRuleOrAndTagsProperty;
    }
    class RuleRuleOrAndPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleRuleOrAndProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RuleRuleOrAndProperty | cdktn.IResolvable | undefined);
        private _costCategory;
        get costCategory(): RuleRuleOrAndCostCategoryPropertyOutputReference;
        putCostCategory(value: RuleRuleOrAndCostCategoryProperty): void;
        resetCostCategory(): void;
        get costCategoryInput(): RuleRuleOrAndCostCategoryProperty | undefined;
        private _dimension;
        get dimension(): RuleRuleOrAndDimensionPropertyOutputReference;
        putDimension(value: RuleRuleOrAndDimensionProperty): void;
        resetDimension(): void;
        get dimensionInput(): RuleRuleOrAndDimensionProperty | undefined;
        private _tags;
        get tags(): RuleRuleOrAndTagsPropertyOutputReference;
        putTags(value: RuleRuleOrAndTagsProperty): void;
        resetTags(): void;
        get tagsInput(): RuleRuleOrAndTagsProperty | undefined;
    }
    class RuleRuleOrAndPropertyList extends cdktn.ComplexList {
        internalValue?: RuleRuleOrAndProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleRuleOrAndPropertyOutputReference;
    }
    interface RuleRuleOrCostCategoryProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#key AwsCostCategory#key}
        */
        readonly key?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#match_options AwsCostCategory#match_options}
        */
        readonly matchOptions?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#values AwsCostCategory#values}
        */
        readonly values?: string[];
    }
    class RuleRuleOrCostCategoryPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RuleRuleOrCostCategoryProperty | undefined;
        set internalValue(value: RuleRuleOrCostCategoryProperty | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        resetKey(): void;
        get keyInput(): string | undefined;
        private _matchOptions?;
        get matchOptions(): string[];
        set matchOptions(value: string[]);
        resetMatchOptions(): void;
        get matchOptionsInput(): string[] | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        resetValues(): void;
        get valuesInput(): string[] | undefined;
    }
    interface RuleRuleOrDimensionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#key AwsCostCategory#key}
        */
        readonly key?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#match_options AwsCostCategory#match_options}
        */
        readonly matchOptions?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#values AwsCostCategory#values}
        */
        readonly values?: string[];
    }
    class RuleRuleOrDimensionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RuleRuleOrDimensionProperty | undefined;
        set internalValue(value: RuleRuleOrDimensionProperty | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        resetKey(): void;
        get keyInput(): string | undefined;
        private _matchOptions?;
        get matchOptions(): string[];
        set matchOptions(value: string[]);
        resetMatchOptions(): void;
        get matchOptionsInput(): string[] | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        resetValues(): void;
        get valuesInput(): string[] | undefined;
    }
    interface RuleRuleOrNotCostCategoryProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#key AwsCostCategory#key}
        */
        readonly key?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#match_options AwsCostCategory#match_options}
        */
        readonly matchOptions?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#values AwsCostCategory#values}
        */
        readonly values?: string[];
    }
    class RuleRuleOrNotCostCategoryPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RuleRuleOrNotCostCategoryProperty | undefined;
        set internalValue(value: RuleRuleOrNotCostCategoryProperty | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        resetKey(): void;
        get keyInput(): string | undefined;
        private _matchOptions?;
        get matchOptions(): string[];
        set matchOptions(value: string[]);
        resetMatchOptions(): void;
        get matchOptionsInput(): string[] | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        resetValues(): void;
        get valuesInput(): string[] | undefined;
    }
    interface RuleRuleOrNotDimensionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#key AwsCostCategory#key}
        */
        readonly key?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#match_options AwsCostCategory#match_options}
        */
        readonly matchOptions?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#values AwsCostCategory#values}
        */
        readonly values?: string[];
    }
    class RuleRuleOrNotDimensionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RuleRuleOrNotDimensionProperty | undefined;
        set internalValue(value: RuleRuleOrNotDimensionProperty | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        resetKey(): void;
        get keyInput(): string | undefined;
        private _matchOptions?;
        get matchOptions(): string[];
        set matchOptions(value: string[]);
        resetMatchOptions(): void;
        get matchOptionsInput(): string[] | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        resetValues(): void;
        get valuesInput(): string[] | undefined;
    }
    interface RuleRuleOrNotTagsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#key AwsCostCategory#key}
        */
        readonly key?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#match_options AwsCostCategory#match_options}
        */
        readonly matchOptions?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#values AwsCostCategory#values}
        */
        readonly values?: string[];
    }
    class RuleRuleOrNotTagsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RuleRuleOrNotTagsProperty | undefined;
        set internalValue(value: RuleRuleOrNotTagsProperty | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        resetKey(): void;
        get keyInput(): string | undefined;
        private _matchOptions?;
        get matchOptions(): string[];
        set matchOptions(value: string[]);
        resetMatchOptions(): void;
        get matchOptionsInput(): string[] | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        resetValues(): void;
        get valuesInput(): string[] | undefined;
    }
    interface RuleRuleOrNotProperty {
        /**
        * cost_category block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#cost_category AwsCostCategory#cost_category}
        */
        readonly costCategory?: RuleRuleOrNotCostCategoryProperty;
        /**
        * dimension block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#dimension AwsCostCategory#dimension}
        */
        readonly dimension?: RuleRuleOrNotDimensionProperty;
        /**
        * tags block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#tags AwsCostCategory#tags}
        */
        readonly tags?: RuleRuleOrNotTagsProperty;
    }
    class RuleRuleOrNotPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RuleRuleOrNotProperty | undefined;
        set internalValue(value: RuleRuleOrNotProperty | undefined);
        private _costCategory;
        get costCategory(): RuleRuleOrNotCostCategoryPropertyOutputReference;
        putCostCategory(value: RuleRuleOrNotCostCategoryProperty): void;
        resetCostCategory(): void;
        get costCategoryInput(): RuleRuleOrNotCostCategoryProperty | undefined;
        private _dimension;
        get dimension(): RuleRuleOrNotDimensionPropertyOutputReference;
        putDimension(value: RuleRuleOrNotDimensionProperty): void;
        resetDimension(): void;
        get dimensionInput(): RuleRuleOrNotDimensionProperty | undefined;
        private _tags;
        get tags(): RuleRuleOrNotTagsPropertyOutputReference;
        putTags(value: RuleRuleOrNotTagsProperty): void;
        resetTags(): void;
        get tagsInput(): RuleRuleOrNotTagsProperty | undefined;
    }
    interface RuleRuleOrOrCostCategoryProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#key AwsCostCategory#key}
        */
        readonly key?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#match_options AwsCostCategory#match_options}
        */
        readonly matchOptions?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#values AwsCostCategory#values}
        */
        readonly values?: string[];
    }
    class RuleRuleOrOrCostCategoryPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RuleRuleOrOrCostCategoryProperty | undefined;
        set internalValue(value: RuleRuleOrOrCostCategoryProperty | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        resetKey(): void;
        get keyInput(): string | undefined;
        private _matchOptions?;
        get matchOptions(): string[];
        set matchOptions(value: string[]);
        resetMatchOptions(): void;
        get matchOptionsInput(): string[] | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        resetValues(): void;
        get valuesInput(): string[] | undefined;
    }
    interface RuleRuleOrOrDimensionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#key AwsCostCategory#key}
        */
        readonly key?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#match_options AwsCostCategory#match_options}
        */
        readonly matchOptions?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#values AwsCostCategory#values}
        */
        readonly values?: string[];
    }
    class RuleRuleOrOrDimensionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RuleRuleOrOrDimensionProperty | undefined;
        set internalValue(value: RuleRuleOrOrDimensionProperty | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        resetKey(): void;
        get keyInput(): string | undefined;
        private _matchOptions?;
        get matchOptions(): string[];
        set matchOptions(value: string[]);
        resetMatchOptions(): void;
        get matchOptionsInput(): string[] | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        resetValues(): void;
        get valuesInput(): string[] | undefined;
    }
    interface RuleRuleOrOrTagsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#key AwsCostCategory#key}
        */
        readonly key?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#match_options AwsCostCategory#match_options}
        */
        readonly matchOptions?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#values AwsCostCategory#values}
        */
        readonly values?: string[];
    }
    class RuleRuleOrOrTagsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RuleRuleOrOrTagsProperty | undefined;
        set internalValue(value: RuleRuleOrOrTagsProperty | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        resetKey(): void;
        get keyInput(): string | undefined;
        private _matchOptions?;
        get matchOptions(): string[];
        set matchOptions(value: string[]);
        resetMatchOptions(): void;
        get matchOptionsInput(): string[] | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        resetValues(): void;
        get valuesInput(): string[] | undefined;
    }
    interface RuleRuleOrOrProperty {
        /**
        * cost_category block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#cost_category AwsCostCategory#cost_category}
        */
        readonly costCategory?: RuleRuleOrOrCostCategoryProperty;
        /**
        * dimension block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#dimension AwsCostCategory#dimension}
        */
        readonly dimension?: RuleRuleOrOrDimensionProperty;
        /**
        * tags block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#tags AwsCostCategory#tags}
        */
        readonly tags?: RuleRuleOrOrTagsProperty;
    }
    class RuleRuleOrOrPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleRuleOrOrProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RuleRuleOrOrProperty | cdktn.IResolvable | undefined);
        private _costCategory;
        get costCategory(): RuleRuleOrOrCostCategoryPropertyOutputReference;
        putCostCategory(value: RuleRuleOrOrCostCategoryProperty): void;
        resetCostCategory(): void;
        get costCategoryInput(): RuleRuleOrOrCostCategoryProperty | undefined;
        private _dimension;
        get dimension(): RuleRuleOrOrDimensionPropertyOutputReference;
        putDimension(value: RuleRuleOrOrDimensionProperty): void;
        resetDimension(): void;
        get dimensionInput(): RuleRuleOrOrDimensionProperty | undefined;
        private _tags;
        get tags(): RuleRuleOrOrTagsPropertyOutputReference;
        putTags(value: RuleRuleOrOrTagsProperty): void;
        resetTags(): void;
        get tagsInput(): RuleRuleOrOrTagsProperty | undefined;
    }
    class RuleRuleOrOrPropertyList extends cdktn.ComplexList {
        internalValue?: RuleRuleOrOrProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleRuleOrOrPropertyOutputReference;
    }
    interface RuleRuleOrTagsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#key AwsCostCategory#key}
        */
        readonly key?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#match_options AwsCostCategory#match_options}
        */
        readonly matchOptions?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#values AwsCostCategory#values}
        */
        readonly values?: string[];
    }
    class RuleRuleOrTagsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RuleRuleOrTagsProperty | undefined;
        set internalValue(value: RuleRuleOrTagsProperty | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        resetKey(): void;
        get keyInput(): string | undefined;
        private _matchOptions?;
        get matchOptions(): string[];
        set matchOptions(value: string[]);
        resetMatchOptions(): void;
        get matchOptionsInput(): string[] | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        resetValues(): void;
        get valuesInput(): string[] | undefined;
    }
    interface RuleRuleOrProperty {
        /**
        * and block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#and AwsCostCategory#and}
        */
        readonly and?: RuleRuleOrAndProperty[] | cdktn.IResolvable;
        /**
        * cost_category block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#cost_category AwsCostCategory#cost_category}
        */
        readonly costCategory?: RuleRuleOrCostCategoryProperty;
        /**
        * dimension block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#dimension AwsCostCategory#dimension}
        */
        readonly dimension?: RuleRuleOrDimensionProperty;
        /**
        * not block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#not AwsCostCategory#not}
        */
        readonly not?: RuleRuleOrNotProperty;
        /**
        * or block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#or AwsCostCategory#or}
        */
        readonly or?: RuleRuleOrOrProperty[] | cdktn.IResolvable;
        /**
        * tags block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#tags AwsCostCategory#tags}
        */
        readonly tags?: RuleRuleOrTagsProperty;
    }
    class RuleRuleOrPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleRuleOrProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RuleRuleOrProperty | cdktn.IResolvable | undefined);
        private _and;
        get and(): RuleRuleOrAndPropertyList;
        putAnd(value: RuleRuleOrAndProperty[] | cdktn.IResolvable): void;
        resetAnd(): void;
        get andInput(): cdktn.IResolvable | RuleRuleOrAndProperty[] | undefined;
        private _costCategory;
        get costCategory(): RuleRuleOrCostCategoryPropertyOutputReference;
        putCostCategory(value: RuleRuleOrCostCategoryProperty): void;
        resetCostCategory(): void;
        get costCategoryInput(): RuleRuleOrCostCategoryProperty | undefined;
        private _dimension;
        get dimension(): RuleRuleOrDimensionPropertyOutputReference;
        putDimension(value: RuleRuleOrDimensionProperty): void;
        resetDimension(): void;
        get dimensionInput(): RuleRuleOrDimensionProperty | undefined;
        private _not;
        get not(): RuleRuleOrNotPropertyOutputReference;
        putNot(value: RuleRuleOrNotProperty): void;
        resetNot(): void;
        get notInput(): RuleRuleOrNotProperty | undefined;
        private _or;
        get or(): RuleRuleOrOrPropertyList;
        putOr(value: RuleRuleOrOrProperty[] | cdktn.IResolvable): void;
        resetOr(): void;
        get orInput(): cdktn.IResolvable | RuleRuleOrOrProperty[] | undefined;
        private _tags;
        get tags(): RuleRuleOrTagsPropertyOutputReference;
        putTags(value: RuleRuleOrTagsProperty): void;
        resetTags(): void;
        get tagsInput(): RuleRuleOrTagsProperty | undefined;
    }
    class RuleRuleOrPropertyList extends cdktn.ComplexList {
        internalValue?: RuleRuleOrProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleRuleOrPropertyOutputReference;
    }
    interface RuleRuleTagsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#key AwsCostCategory#key}
        */
        readonly key?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#match_options AwsCostCategory#match_options}
        */
        readonly matchOptions?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#values AwsCostCategory#values}
        */
        readonly values?: string[];
    }
    class RuleRuleTagsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RuleRuleTagsProperty | undefined;
        set internalValue(value: RuleRuleTagsProperty | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        resetKey(): void;
        get keyInput(): string | undefined;
        private _matchOptions?;
        get matchOptions(): string[];
        set matchOptions(value: string[]);
        resetMatchOptions(): void;
        get matchOptionsInput(): string[] | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        resetValues(): void;
        get valuesInput(): string[] | undefined;
    }
    interface RuleRuleProperty {
        /**
        * and block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#and AwsCostCategory#and}
        */
        readonly and?: RuleRuleAndProperty[] | cdktn.IResolvable;
        /**
        * cost_category block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#cost_category AwsCostCategory#cost_category}
        */
        readonly costCategory?: RuleRuleCostCategoryProperty;
        /**
        * dimension block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#dimension AwsCostCategory#dimension}
        */
        readonly dimension?: RuleRuleDimensionProperty;
        /**
        * not block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#not AwsCostCategory#not}
        */
        readonly not?: RuleRuleNotProperty;
        /**
        * or block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#or AwsCostCategory#or}
        */
        readonly or?: RuleRuleOrProperty[] | cdktn.IResolvable;
        /**
        * tags block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#tags AwsCostCategory#tags}
        */
        readonly tags?: RuleRuleTagsProperty;
    }
    class RuleRulePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RuleRuleProperty | undefined;
        set internalValue(value: RuleRuleProperty | undefined);
        private _and;
        get and(): RuleRuleAndPropertyList;
        putAnd(value: RuleRuleAndProperty[] | cdktn.IResolvable): void;
        resetAnd(): void;
        get andInput(): cdktn.IResolvable | RuleRuleAndProperty[] | undefined;
        private _costCategory;
        get costCategory(): RuleRuleCostCategoryPropertyOutputReference;
        putCostCategory(value: RuleRuleCostCategoryProperty): void;
        resetCostCategory(): void;
        get costCategoryInput(): RuleRuleCostCategoryProperty | undefined;
        private _dimension;
        get dimension(): RuleRuleDimensionPropertyOutputReference;
        putDimension(value: RuleRuleDimensionProperty): void;
        resetDimension(): void;
        get dimensionInput(): RuleRuleDimensionProperty | undefined;
        private _not;
        get not(): RuleRuleNotPropertyOutputReference;
        putNot(value: RuleRuleNotProperty): void;
        resetNot(): void;
        get notInput(): RuleRuleNotProperty | undefined;
        private _or;
        get or(): RuleRuleOrPropertyList;
        putOr(value: RuleRuleOrProperty[] | cdktn.IResolvable): void;
        resetOr(): void;
        get orInput(): cdktn.IResolvable | RuleRuleOrProperty[] | undefined;
        private _tags;
        get tags(): RuleRuleTagsPropertyOutputReference;
        putTags(value: RuleRuleTagsProperty): void;
        resetTags(): void;
        get tagsInput(): RuleRuleTagsProperty | undefined;
    }
    interface RuleProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#type AwsCostCategory#type}
        */
        readonly type?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#value AwsCostCategory#value}
        */
        readonly value?: string;
        /**
        * inherited_value block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#inherited_value AwsCostCategory#inherited_value}
        */
        readonly inheritedValue?: InheritedValueProperty;
        /**
        * rule block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#rule AwsCostCategory#rule}
        */
        readonly rule?: RuleRuleProperty;
    }
    class RulePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RuleProperty | cdktn.IResolvable | undefined);
        private _type?;
        get type(): string;
        set type(value: string);
        resetType(): void;
        get typeInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        resetValue(): void;
        get valueInput(): string | undefined;
        private _inheritedValue;
        get inheritedValue(): InheritedValuePropertyOutputReference;
        putInheritedValue(value: InheritedValueProperty): void;
        resetInheritedValue(): void;
        get inheritedValueInput(): InheritedValueProperty | undefined;
        private _rule;
        get rule(): RuleRulePropertyOutputReference;
        putRule(value: RuleRuleProperty): void;
        resetRule(): void;
        get ruleInput(): RuleRuleProperty | undefined;
    }
    class RulePropertyList extends cdktn.ComplexList {
        internalValue?: RuleProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RulePropertyOutputReference;
    }
    interface ParameterProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#type AwsCostCategory#type}
        */
        readonly type?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#values AwsCostCategory#values}
        */
        readonly values?: string[];
    }
    class ParameterPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ParameterProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ParameterProperty | cdktn.IResolvable | undefined);
        private _type?;
        get type(): string;
        set type(value: string);
        resetType(): void;
        get typeInput(): string | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        resetValues(): void;
        get valuesInput(): string[] | undefined;
    }
    class ParameterPropertyList extends cdktn.ComplexList {
        internalValue?: ParameterProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ParameterPropertyOutputReference;
    }
    interface SplitChargeRuleProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#method AwsCostCategory#method}
        */
        readonly method: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#source AwsCostCategory#source}
        */
        readonly source: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#targets AwsCostCategory#targets}
        */
        readonly targets: string[];
        /**
        * parameter block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_cost_category#parameter AwsCostCategory#parameter}
        */
        readonly parameter?: ParameterProperty[] | cdktn.IResolvable;
    }
    class SplitChargeRulePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SplitChargeRuleProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SplitChargeRuleProperty | cdktn.IResolvable | undefined);
        private _method?;
        get method(): string;
        set method(value: string);
        get methodInput(): string | undefined;
        private _source?;
        get source(): string;
        set source(value: string);
        get sourceInput(): string | undefined;
        private _targets?;
        get targets(): string[];
        set targets(value: string[]);
        get targetsInput(): string[] | undefined;
        private _parameter;
        get parameter(): ParameterPropertyList;
        putParameter(value: ParameterProperty[] | cdktn.IResolvable): void;
        resetParameter(): void;
        get parameterInput(): cdktn.IResolvable | ParameterProperty[] | undefined;
    }
    class SplitChargeRulePropertyList extends cdktn.ComplexList {
        internalValue?: SplitChargeRuleProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SplitChargeRulePropertyOutputReference;
    }
}
