import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsAnomalySubscriptionConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_anomaly_subscription#account_id AwsAnomalySubscription#account_id}
    */
    readonly accountId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_anomaly_subscription#frequency AwsAnomalySubscription#frequency}
    */
    readonly frequency: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_anomaly_subscription#id AwsAnomalySubscription#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_anomaly_subscription#monitor_arn_list AwsAnomalySubscription#monitor_arn_list}
    */
    readonly monitorArnList: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_anomaly_subscription#name AwsAnomalySubscription#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_anomaly_subscription#tags AwsAnomalySubscription#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_anomaly_subscription#tags_all AwsAnomalySubscription#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * subscriber block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_anomaly_subscription#subscriber AwsAnomalySubscription#subscriber}
    */
    readonly subscriber: AwsAnomalySubscription.SubscriberProperty[] | cdktn.IResolvable;
    /**
    * threshold_expression block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_anomaly_subscription#threshold_expression AwsAnomalySubscription#threshold_expression}
    */
    readonly thresholdExpression?: AwsAnomalySubscription.ThresholdExpressionProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_anomaly_subscription aws_ce_anomaly_subscription}
*/
export declare class AwsAnomalySubscription extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_ce_anomaly_subscription";
    /**
    * Generates CDKTN code for importing a AwsAnomalySubscription resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsAnomalySubscription to import
    * @param importFromId The id of the existing AwsAnomalySubscription that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_anomaly_subscription#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsAnomalySubscription to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_anomaly_subscription aws_ce_anomaly_subscription} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsAnomalySubscriptionConfig
    */
    constructor(scope: Construct, id: string, config: AwsAnomalySubscriptionConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    resetAccountId(): void;
    get accountIdInput(): string | undefined;
    get arn(): string;
    private _frequency?;
    get frequency(): string;
    set frequency(value: string);
    get frequencyInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _monitorArnList?;
    get monitorArnList(): string[];
    set monitorArnList(value: string[]);
    get monitorArnListInput(): string[] | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _subscriber;
    get subscriber(): AwsAnomalySubscription.SubscriberPropertyList;
    putSubscriber(value: AwsAnomalySubscription.SubscriberProperty[] | cdktn.IResolvable): void;
    get subscriberInput(): cdktn.IResolvable | AwsAnomalySubscription.SubscriberProperty[] | undefined;
    private _thresholdExpression;
    get thresholdExpression(): AwsAnomalySubscription.ThresholdExpressionPropertyOutputReference;
    putThresholdExpression(value: AwsAnomalySubscription.ThresholdExpressionProperty): void;
    resetThresholdExpression(): void;
    get thresholdExpressionInput(): AwsAnomalySubscription.ThresholdExpressionProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsAnomalySubscriptionSubscriberPropertyToTerraform(struct?: AwsAnomalySubscription.SubscriberProperty | cdktn.IResolvable): any;
export declare function awsAnomalySubscriptionSubscriberPropertyToHclTerraform(struct?: AwsAnomalySubscription.SubscriberProperty | cdktn.IResolvable): any;
export declare function awsAnomalySubscriptionThresholdExpressionAndCostCategoryPropertyToTerraform(struct?: AwsAnomalySubscription.ThresholdExpressionAndCostCategoryPropertyOutputReference | AwsAnomalySubscription.ThresholdExpressionAndCostCategoryProperty): any;
export declare function awsAnomalySubscriptionThresholdExpressionAndCostCategoryPropertyToHclTerraform(struct?: AwsAnomalySubscription.ThresholdExpressionAndCostCategoryPropertyOutputReference | AwsAnomalySubscription.ThresholdExpressionAndCostCategoryProperty): any;
export declare function awsAnomalySubscriptionThresholdExpressionAndDimensionPropertyToTerraform(struct?: AwsAnomalySubscription.ThresholdExpressionAndDimensionPropertyOutputReference | AwsAnomalySubscription.ThresholdExpressionAndDimensionProperty): any;
export declare function awsAnomalySubscriptionThresholdExpressionAndDimensionPropertyToHclTerraform(struct?: AwsAnomalySubscription.ThresholdExpressionAndDimensionPropertyOutputReference | AwsAnomalySubscription.ThresholdExpressionAndDimensionProperty): any;
export declare function awsAnomalySubscriptionThresholdExpressionAndTagsPropertyToTerraform(struct?: AwsAnomalySubscription.ThresholdExpressionAndTagsPropertyOutputReference | AwsAnomalySubscription.ThresholdExpressionAndTagsProperty): any;
export declare function awsAnomalySubscriptionThresholdExpressionAndTagsPropertyToHclTerraform(struct?: AwsAnomalySubscription.ThresholdExpressionAndTagsPropertyOutputReference | AwsAnomalySubscription.ThresholdExpressionAndTagsProperty): any;
export declare function awsAnomalySubscriptionAndPropertyToTerraform(struct?: AwsAnomalySubscription.AndProperty | cdktn.IResolvable): any;
export declare function awsAnomalySubscriptionAndPropertyToHclTerraform(struct?: AwsAnomalySubscription.AndProperty | cdktn.IResolvable): any;
export declare function awsAnomalySubscriptionThresholdExpressionCostCategoryPropertyToTerraform(struct?: AwsAnomalySubscription.ThresholdExpressionCostCategoryPropertyOutputReference | AwsAnomalySubscription.ThresholdExpressionCostCategoryProperty): any;
export declare function awsAnomalySubscriptionThresholdExpressionCostCategoryPropertyToHclTerraform(struct?: AwsAnomalySubscription.ThresholdExpressionCostCategoryPropertyOutputReference | AwsAnomalySubscription.ThresholdExpressionCostCategoryProperty): any;
export declare function awsAnomalySubscriptionThresholdExpressionDimensionPropertyToTerraform(struct?: AwsAnomalySubscription.ThresholdExpressionDimensionPropertyOutputReference | AwsAnomalySubscription.ThresholdExpressionDimensionProperty): any;
export declare function awsAnomalySubscriptionThresholdExpressionDimensionPropertyToHclTerraform(struct?: AwsAnomalySubscription.ThresholdExpressionDimensionPropertyOutputReference | AwsAnomalySubscription.ThresholdExpressionDimensionProperty): any;
export declare function awsAnomalySubscriptionThresholdExpressionNotCostCategoryPropertyToTerraform(struct?: AwsAnomalySubscription.ThresholdExpressionNotCostCategoryPropertyOutputReference | AwsAnomalySubscription.ThresholdExpressionNotCostCategoryProperty): any;
export declare function awsAnomalySubscriptionThresholdExpressionNotCostCategoryPropertyToHclTerraform(struct?: AwsAnomalySubscription.ThresholdExpressionNotCostCategoryPropertyOutputReference | AwsAnomalySubscription.ThresholdExpressionNotCostCategoryProperty): any;
export declare function awsAnomalySubscriptionThresholdExpressionNotDimensionPropertyToTerraform(struct?: AwsAnomalySubscription.ThresholdExpressionNotDimensionPropertyOutputReference | AwsAnomalySubscription.ThresholdExpressionNotDimensionProperty): any;
export declare function awsAnomalySubscriptionThresholdExpressionNotDimensionPropertyToHclTerraform(struct?: AwsAnomalySubscription.ThresholdExpressionNotDimensionPropertyOutputReference | AwsAnomalySubscription.ThresholdExpressionNotDimensionProperty): any;
export declare function awsAnomalySubscriptionThresholdExpressionNotTagsPropertyToTerraform(struct?: AwsAnomalySubscription.ThresholdExpressionNotTagsPropertyOutputReference | AwsAnomalySubscription.ThresholdExpressionNotTagsProperty): any;
export declare function awsAnomalySubscriptionThresholdExpressionNotTagsPropertyToHclTerraform(struct?: AwsAnomalySubscription.ThresholdExpressionNotTagsPropertyOutputReference | AwsAnomalySubscription.ThresholdExpressionNotTagsProperty): any;
export declare function awsAnomalySubscriptionNotPropertyToTerraform(struct?: AwsAnomalySubscription.NotPropertyOutputReference | AwsAnomalySubscription.NotProperty): any;
export declare function awsAnomalySubscriptionNotPropertyToHclTerraform(struct?: AwsAnomalySubscription.NotPropertyOutputReference | AwsAnomalySubscription.NotProperty): any;
export declare function awsAnomalySubscriptionThresholdExpressionOrCostCategoryPropertyToTerraform(struct?: AwsAnomalySubscription.ThresholdExpressionOrCostCategoryPropertyOutputReference | AwsAnomalySubscription.ThresholdExpressionOrCostCategoryProperty): any;
export declare function awsAnomalySubscriptionThresholdExpressionOrCostCategoryPropertyToHclTerraform(struct?: AwsAnomalySubscription.ThresholdExpressionOrCostCategoryPropertyOutputReference | AwsAnomalySubscription.ThresholdExpressionOrCostCategoryProperty): any;
export declare function awsAnomalySubscriptionThresholdExpressionOrDimensionPropertyToTerraform(struct?: AwsAnomalySubscription.ThresholdExpressionOrDimensionPropertyOutputReference | AwsAnomalySubscription.ThresholdExpressionOrDimensionProperty): any;
export declare function awsAnomalySubscriptionThresholdExpressionOrDimensionPropertyToHclTerraform(struct?: AwsAnomalySubscription.ThresholdExpressionOrDimensionPropertyOutputReference | AwsAnomalySubscription.ThresholdExpressionOrDimensionProperty): any;
export declare function awsAnomalySubscriptionThresholdExpressionOrTagsPropertyToTerraform(struct?: AwsAnomalySubscription.ThresholdExpressionOrTagsPropertyOutputReference | AwsAnomalySubscription.ThresholdExpressionOrTagsProperty): any;
export declare function awsAnomalySubscriptionThresholdExpressionOrTagsPropertyToHclTerraform(struct?: AwsAnomalySubscription.ThresholdExpressionOrTagsPropertyOutputReference | AwsAnomalySubscription.ThresholdExpressionOrTagsProperty): any;
export declare function awsAnomalySubscriptionOrPropertyToTerraform(struct?: AwsAnomalySubscription.OrProperty | cdktn.IResolvable): any;
export declare function awsAnomalySubscriptionOrPropertyToHclTerraform(struct?: AwsAnomalySubscription.OrProperty | cdktn.IResolvable): any;
export declare function awsAnomalySubscriptionThresholdExpressionTagsPropertyToTerraform(struct?: AwsAnomalySubscription.ThresholdExpressionTagsPropertyOutputReference | AwsAnomalySubscription.ThresholdExpressionTagsProperty): any;
export declare function awsAnomalySubscriptionThresholdExpressionTagsPropertyToHclTerraform(struct?: AwsAnomalySubscription.ThresholdExpressionTagsPropertyOutputReference | AwsAnomalySubscription.ThresholdExpressionTagsProperty): any;
export declare function awsAnomalySubscriptionThresholdExpressionPropertyToTerraform(struct?: AwsAnomalySubscription.ThresholdExpressionPropertyOutputReference | AwsAnomalySubscription.ThresholdExpressionProperty): any;
export declare function awsAnomalySubscriptionThresholdExpressionPropertyToHclTerraform(struct?: AwsAnomalySubscription.ThresholdExpressionPropertyOutputReference | AwsAnomalySubscription.ThresholdExpressionProperty): any;
export declare namespace AwsAnomalySubscription {
    interface SubscriberProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_anomaly_subscription#address AwsAnomalySubscription#address}
        */
        readonly address: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_anomaly_subscription#type AwsAnomalySubscription#type}
        */
        readonly type: string;
    }
    class SubscriberPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SubscriberProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SubscriberProperty | cdktn.IResolvable | undefined);
        private _address?;
        get address(): string;
        set address(value: string);
        get addressInput(): string | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
    }
    class SubscriberPropertyList extends cdktn.ComplexList {
        internalValue?: SubscriberProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SubscriberPropertyOutputReference;
    }
    interface ThresholdExpressionAndCostCategoryProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_anomaly_subscription#key AwsAnomalySubscription#key}
        */
        readonly key?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_anomaly_subscription#match_options AwsAnomalySubscription#match_options}
        */
        readonly matchOptions?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_anomaly_subscription#values AwsAnomalySubscription#values}
        */
        readonly values?: string[];
    }
    class ThresholdExpressionAndCostCategoryPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ThresholdExpressionAndCostCategoryProperty | undefined;
        set internalValue(value: ThresholdExpressionAndCostCategoryProperty | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        resetKey(): void;
        get keyInput(): string | undefined;
        private _matchOptions?;
        get matchOptions(): string[];
        set matchOptions(value: string[]);
        resetMatchOptions(): void;
        get matchOptionsInput(): string[] | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        resetValues(): void;
        get valuesInput(): string[] | undefined;
    }
    interface ThresholdExpressionAndDimensionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_anomaly_subscription#key AwsAnomalySubscription#key}
        */
        readonly key?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_anomaly_subscription#match_options AwsAnomalySubscription#match_options}
        */
        readonly matchOptions?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_anomaly_subscription#values AwsAnomalySubscription#values}
        */
        readonly values?: string[];
    }
    class ThresholdExpressionAndDimensionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ThresholdExpressionAndDimensionProperty | undefined;
        set internalValue(value: ThresholdExpressionAndDimensionProperty | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        resetKey(): void;
        get keyInput(): string | undefined;
        private _matchOptions?;
        get matchOptions(): string[];
        set matchOptions(value: string[]);
        resetMatchOptions(): void;
        get matchOptionsInput(): string[] | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        resetValues(): void;
        get valuesInput(): string[] | undefined;
    }
    interface ThresholdExpressionAndTagsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_anomaly_subscription#key AwsAnomalySubscription#key}
        */
        readonly key?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_anomaly_subscription#match_options AwsAnomalySubscription#match_options}
        */
        readonly matchOptions?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_anomaly_subscription#values AwsAnomalySubscription#values}
        */
        readonly values?: string[];
    }
    class ThresholdExpressionAndTagsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ThresholdExpressionAndTagsProperty | undefined;
        set internalValue(value: ThresholdExpressionAndTagsProperty | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        resetKey(): void;
        get keyInput(): string | undefined;
        private _matchOptions?;
        get matchOptions(): string[];
        set matchOptions(value: string[]);
        resetMatchOptions(): void;
        get matchOptionsInput(): string[] | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        resetValues(): void;
        get valuesInput(): string[] | undefined;
    }
    interface AndProperty {
        /**
        * cost_category block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_anomaly_subscription#cost_category AwsAnomalySubscription#cost_category}
        */
        readonly costCategory?: ThresholdExpressionAndCostCategoryProperty;
        /**
        * dimension block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_anomaly_subscription#dimension AwsAnomalySubscription#dimension}
        */
        readonly dimension?: ThresholdExpressionAndDimensionProperty;
        /**
        * tags block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_anomaly_subscription#tags AwsAnomalySubscription#tags}
        */
        readonly tags?: ThresholdExpressionAndTagsProperty;
    }
    class AndPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AndProperty | cdktn.IResolvable | undefined;
        set internalValue(value: AndProperty | cdktn.IResolvable | undefined);
        private _costCategory;
        get costCategory(): ThresholdExpressionAndCostCategoryPropertyOutputReference;
        putCostCategory(value: ThresholdExpressionAndCostCategoryProperty): void;
        resetCostCategory(): void;
        get costCategoryInput(): ThresholdExpressionAndCostCategoryProperty | undefined;
        private _dimension;
        get dimension(): ThresholdExpressionAndDimensionPropertyOutputReference;
        putDimension(value: ThresholdExpressionAndDimensionProperty): void;
        resetDimension(): void;
        get dimensionInput(): ThresholdExpressionAndDimensionProperty | undefined;
        private _tags;
        get tags(): ThresholdExpressionAndTagsPropertyOutputReference;
        putTags(value: ThresholdExpressionAndTagsProperty): void;
        resetTags(): void;
        get tagsInput(): ThresholdExpressionAndTagsProperty | undefined;
    }
    class AndPropertyList extends cdktn.ComplexList {
        internalValue?: AndProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AndPropertyOutputReference;
    }
    interface ThresholdExpressionCostCategoryProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_anomaly_subscription#key AwsAnomalySubscription#key}
        */
        readonly key?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_anomaly_subscription#match_options AwsAnomalySubscription#match_options}
        */
        readonly matchOptions?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_anomaly_subscription#values AwsAnomalySubscription#values}
        */
        readonly values?: string[];
    }
    class ThresholdExpressionCostCategoryPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ThresholdExpressionCostCategoryProperty | undefined;
        set internalValue(value: ThresholdExpressionCostCategoryProperty | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        resetKey(): void;
        get keyInput(): string | undefined;
        private _matchOptions?;
        get matchOptions(): string[];
        set matchOptions(value: string[]);
        resetMatchOptions(): void;
        get matchOptionsInput(): string[] | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        resetValues(): void;
        get valuesInput(): string[] | undefined;
    }
    interface ThresholdExpressionDimensionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_anomaly_subscription#key AwsAnomalySubscription#key}
        */
        readonly key?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_anomaly_subscription#match_options AwsAnomalySubscription#match_options}
        */
        readonly matchOptions?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_anomaly_subscription#values AwsAnomalySubscription#values}
        */
        readonly values?: string[];
    }
    class ThresholdExpressionDimensionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ThresholdExpressionDimensionProperty | undefined;
        set internalValue(value: ThresholdExpressionDimensionProperty | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        resetKey(): void;
        get keyInput(): string | undefined;
        private _matchOptions?;
        get matchOptions(): string[];
        set matchOptions(value: string[]);
        resetMatchOptions(): void;
        get matchOptionsInput(): string[] | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        resetValues(): void;
        get valuesInput(): string[] | undefined;
    }
    interface ThresholdExpressionNotCostCategoryProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_anomaly_subscription#key AwsAnomalySubscription#key}
        */
        readonly key?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_anomaly_subscription#match_options AwsAnomalySubscription#match_options}
        */
        readonly matchOptions?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_anomaly_subscription#values AwsAnomalySubscription#values}
        */
        readonly values?: string[];
    }
    class ThresholdExpressionNotCostCategoryPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ThresholdExpressionNotCostCategoryProperty | undefined;
        set internalValue(value: ThresholdExpressionNotCostCategoryProperty | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        resetKey(): void;
        get keyInput(): string | undefined;
        private _matchOptions?;
        get matchOptions(): string[];
        set matchOptions(value: string[]);
        resetMatchOptions(): void;
        get matchOptionsInput(): string[] | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        resetValues(): void;
        get valuesInput(): string[] | undefined;
    }
    interface ThresholdExpressionNotDimensionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_anomaly_subscription#key AwsAnomalySubscription#key}
        */
        readonly key?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_anomaly_subscription#match_options AwsAnomalySubscription#match_options}
        */
        readonly matchOptions?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_anomaly_subscription#values AwsAnomalySubscription#values}
        */
        readonly values?: string[];
    }
    class ThresholdExpressionNotDimensionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ThresholdExpressionNotDimensionProperty | undefined;
        set internalValue(value: ThresholdExpressionNotDimensionProperty | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        resetKey(): void;
        get keyInput(): string | undefined;
        private _matchOptions?;
        get matchOptions(): string[];
        set matchOptions(value: string[]);
        resetMatchOptions(): void;
        get matchOptionsInput(): string[] | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        resetValues(): void;
        get valuesInput(): string[] | undefined;
    }
    interface ThresholdExpressionNotTagsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_anomaly_subscription#key AwsAnomalySubscription#key}
        */
        readonly key?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_anomaly_subscription#match_options AwsAnomalySubscription#match_options}
        */
        readonly matchOptions?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_anomaly_subscription#values AwsAnomalySubscription#values}
        */
        readonly values?: string[];
    }
    class ThresholdExpressionNotTagsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ThresholdExpressionNotTagsProperty | undefined;
        set internalValue(value: ThresholdExpressionNotTagsProperty | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        resetKey(): void;
        get keyInput(): string | undefined;
        private _matchOptions?;
        get matchOptions(): string[];
        set matchOptions(value: string[]);
        resetMatchOptions(): void;
        get matchOptionsInput(): string[] | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        resetValues(): void;
        get valuesInput(): string[] | undefined;
    }
    interface NotProperty {
        /**
        * cost_category block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_anomaly_subscription#cost_category AwsAnomalySubscription#cost_category}
        */
        readonly costCategory?: ThresholdExpressionNotCostCategoryProperty;
        /**
        * dimension block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_anomaly_subscription#dimension AwsAnomalySubscription#dimension}
        */
        readonly dimension?: ThresholdExpressionNotDimensionProperty;
        /**
        * tags block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_anomaly_subscription#tags AwsAnomalySubscription#tags}
        */
        readonly tags?: ThresholdExpressionNotTagsProperty;
    }
    class NotPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): NotProperty | undefined;
        set internalValue(value: NotProperty | undefined);
        private _costCategory;
        get costCategory(): ThresholdExpressionNotCostCategoryPropertyOutputReference;
        putCostCategory(value: ThresholdExpressionNotCostCategoryProperty): void;
        resetCostCategory(): void;
        get costCategoryInput(): ThresholdExpressionNotCostCategoryProperty | undefined;
        private _dimension;
        get dimension(): ThresholdExpressionNotDimensionPropertyOutputReference;
        putDimension(value: ThresholdExpressionNotDimensionProperty): void;
        resetDimension(): void;
        get dimensionInput(): ThresholdExpressionNotDimensionProperty | undefined;
        private _tags;
        get tags(): ThresholdExpressionNotTagsPropertyOutputReference;
        putTags(value: ThresholdExpressionNotTagsProperty): void;
        resetTags(): void;
        get tagsInput(): ThresholdExpressionNotTagsProperty | undefined;
    }
    interface ThresholdExpressionOrCostCategoryProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_anomaly_subscription#key AwsAnomalySubscription#key}
        */
        readonly key?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_anomaly_subscription#match_options AwsAnomalySubscription#match_options}
        */
        readonly matchOptions?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_anomaly_subscription#values AwsAnomalySubscription#values}
        */
        readonly values?: string[];
    }
    class ThresholdExpressionOrCostCategoryPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ThresholdExpressionOrCostCategoryProperty | undefined;
        set internalValue(value: ThresholdExpressionOrCostCategoryProperty | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        resetKey(): void;
        get keyInput(): string | undefined;
        private _matchOptions?;
        get matchOptions(): string[];
        set matchOptions(value: string[]);
        resetMatchOptions(): void;
        get matchOptionsInput(): string[] | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        resetValues(): void;
        get valuesInput(): string[] | undefined;
    }
    interface ThresholdExpressionOrDimensionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_anomaly_subscription#key AwsAnomalySubscription#key}
        */
        readonly key?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_anomaly_subscription#match_options AwsAnomalySubscription#match_options}
        */
        readonly matchOptions?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_anomaly_subscription#values AwsAnomalySubscription#values}
        */
        readonly values?: string[];
    }
    class ThresholdExpressionOrDimensionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ThresholdExpressionOrDimensionProperty | undefined;
        set internalValue(value: ThresholdExpressionOrDimensionProperty | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        resetKey(): void;
        get keyInput(): string | undefined;
        private _matchOptions?;
        get matchOptions(): string[];
        set matchOptions(value: string[]);
        resetMatchOptions(): void;
        get matchOptionsInput(): string[] | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        resetValues(): void;
        get valuesInput(): string[] | undefined;
    }
    interface ThresholdExpressionOrTagsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_anomaly_subscription#key AwsAnomalySubscription#key}
        */
        readonly key?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_anomaly_subscription#match_options AwsAnomalySubscription#match_options}
        */
        readonly matchOptions?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_anomaly_subscription#values AwsAnomalySubscription#values}
        */
        readonly values?: string[];
    }
    class ThresholdExpressionOrTagsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ThresholdExpressionOrTagsProperty | undefined;
        set internalValue(value: ThresholdExpressionOrTagsProperty | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        resetKey(): void;
        get keyInput(): string | undefined;
        private _matchOptions?;
        get matchOptions(): string[];
        set matchOptions(value: string[]);
        resetMatchOptions(): void;
        get matchOptionsInput(): string[] | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        resetValues(): void;
        get valuesInput(): string[] | undefined;
    }
    interface OrProperty {
        /**
        * cost_category block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_anomaly_subscription#cost_category AwsAnomalySubscription#cost_category}
        */
        readonly costCategory?: ThresholdExpressionOrCostCategoryProperty;
        /**
        * dimension block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_anomaly_subscription#dimension AwsAnomalySubscription#dimension}
        */
        readonly dimension?: ThresholdExpressionOrDimensionProperty;
        /**
        * tags block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_anomaly_subscription#tags AwsAnomalySubscription#tags}
        */
        readonly tags?: ThresholdExpressionOrTagsProperty;
    }
    class OrPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): OrProperty | cdktn.IResolvable | undefined;
        set internalValue(value: OrProperty | cdktn.IResolvable | undefined);
        private _costCategory;
        get costCategory(): ThresholdExpressionOrCostCategoryPropertyOutputReference;
        putCostCategory(value: ThresholdExpressionOrCostCategoryProperty): void;
        resetCostCategory(): void;
        get costCategoryInput(): ThresholdExpressionOrCostCategoryProperty | undefined;
        private _dimension;
        get dimension(): ThresholdExpressionOrDimensionPropertyOutputReference;
        putDimension(value: ThresholdExpressionOrDimensionProperty): void;
        resetDimension(): void;
        get dimensionInput(): ThresholdExpressionOrDimensionProperty | undefined;
        private _tags;
        get tags(): ThresholdExpressionOrTagsPropertyOutputReference;
        putTags(value: ThresholdExpressionOrTagsProperty): void;
        resetTags(): void;
        get tagsInput(): ThresholdExpressionOrTagsProperty | undefined;
    }
    class OrPropertyList extends cdktn.ComplexList {
        internalValue?: OrProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): OrPropertyOutputReference;
    }
    interface ThresholdExpressionTagsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_anomaly_subscription#key AwsAnomalySubscription#key}
        */
        readonly key?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_anomaly_subscription#match_options AwsAnomalySubscription#match_options}
        */
        readonly matchOptions?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_anomaly_subscription#values AwsAnomalySubscription#values}
        */
        readonly values?: string[];
    }
    class ThresholdExpressionTagsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ThresholdExpressionTagsProperty | undefined;
        set internalValue(value: ThresholdExpressionTagsProperty | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        resetKey(): void;
        get keyInput(): string | undefined;
        private _matchOptions?;
        get matchOptions(): string[];
        set matchOptions(value: string[]);
        resetMatchOptions(): void;
        get matchOptionsInput(): string[] | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        resetValues(): void;
        get valuesInput(): string[] | undefined;
    }
    interface ThresholdExpressionProperty {
        /**
        * and block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_anomaly_subscription#and AwsAnomalySubscription#and}
        */
        readonly and?: AndProperty[] | cdktn.IResolvable;
        /**
        * cost_category block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_anomaly_subscription#cost_category AwsAnomalySubscription#cost_category}
        */
        readonly costCategory?: ThresholdExpressionCostCategoryProperty;
        /**
        * dimension block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_anomaly_subscription#dimension AwsAnomalySubscription#dimension}
        */
        readonly dimension?: ThresholdExpressionDimensionProperty;
        /**
        * not block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_anomaly_subscription#not AwsAnomalySubscription#not}
        */
        readonly not?: NotProperty;
        /**
        * or block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_anomaly_subscription#or AwsAnomalySubscription#or}
        */
        readonly or?: OrProperty[] | cdktn.IResolvable;
        /**
        * tags block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ce_anomaly_subscription#tags AwsAnomalySubscription#tags}
        */
        readonly tags?: ThresholdExpressionTagsProperty;
    }
    class ThresholdExpressionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ThresholdExpressionProperty | undefined;
        set internalValue(value: ThresholdExpressionProperty | undefined);
        private _and;
        get and(): AndPropertyList;
        putAnd(value: AndProperty[] | cdktn.IResolvable): void;
        resetAnd(): void;
        get andInput(): cdktn.IResolvable | AndProperty[] | undefined;
        private _costCategory;
        get costCategory(): ThresholdExpressionCostCategoryPropertyOutputReference;
        putCostCategory(value: ThresholdExpressionCostCategoryProperty): void;
        resetCostCategory(): void;
        get costCategoryInput(): ThresholdExpressionCostCategoryProperty | undefined;
        private _dimension;
        get dimension(): ThresholdExpressionDimensionPropertyOutputReference;
        putDimension(value: ThresholdExpressionDimensionProperty): void;
        resetDimension(): void;
        get dimensionInput(): ThresholdExpressionDimensionProperty | undefined;
        private _not;
        get not(): NotPropertyOutputReference;
        putNot(value: NotProperty): void;
        resetNot(): void;
        get notInput(): NotProperty | undefined;
        private _or;
        get or(): OrPropertyList;
        putOr(value: OrProperty[] | cdktn.IResolvable): void;
        resetOr(): void;
        get orInput(): cdktn.IResolvable | OrProperty[] | undefined;
        private _tags;
        get tags(): ThresholdExpressionTagsPropertyOutputReference;
        putTags(value: ThresholdExpressionTagsProperty): void;
        resetTags(): void;
        get tagsInput(): ThresholdExpressionTagsProperty | undefined;
    }
}
