import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsCostCategoryConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_cost_category#cost_category_arn DataAwsCostCategory#cost_category_arn}
    */
    readonly costCategoryArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_cost_category#id DataAwsCostCategory#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_cost_category#tags DataAwsCostCategory#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_cost_category aws_ce_cost_category}
*/
export declare class DataAwsCostCategory extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_ce_cost_category";
    /**
    * Generates CDKTN code for importing a DataAwsCostCategory resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsCostCategory to import
    * @param importFromId The id of the existing DataAwsCostCategory that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_cost_category#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsCostCategory to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ce_cost_category aws_ce_cost_category} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsCostCategoryConfig
    */
    constructor(scope: Construct, id: string, config: DataAwsCostCategoryConfig);
    private _costCategoryArn?;
    get costCategoryArn(): string;
    set costCategoryArn(value: string);
    get costCategoryArnInput(): string | undefined;
    get defaultValue(): string;
    get effectiveEnd(): string;
    get effectiveStart(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get name(): string;
    private _rule;
    get rule(): DataAwsCostCategory.RulePropertyList;
    get ruleVersion(): string;
    private _splitChargeRule;
    get splitChargeRule(): DataAwsCostCategory.SplitChargeRulePropertyList;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataAwsCostCategoryInheritedValuePropertyToTerraform(struct?: DataAwsCostCategory.InheritedValueProperty): any;
export declare function dataAwsCostCategoryInheritedValuePropertyToHclTerraform(struct?: DataAwsCostCategory.InheritedValueProperty): any;
export declare function dataAwsCostCategoryRuleRuleAndAndCostCategoryPropertyToTerraform(struct?: DataAwsCostCategory.RuleRuleAndAndCostCategoryProperty): any;
export declare function dataAwsCostCategoryRuleRuleAndAndCostCategoryPropertyToHclTerraform(struct?: DataAwsCostCategory.RuleRuleAndAndCostCategoryProperty): any;
export declare function dataAwsCostCategoryRuleRuleAndAndDimensionPropertyToTerraform(struct?: DataAwsCostCategory.RuleRuleAndAndDimensionProperty): any;
export declare function dataAwsCostCategoryRuleRuleAndAndDimensionPropertyToHclTerraform(struct?: DataAwsCostCategory.RuleRuleAndAndDimensionProperty): any;
export declare function dataAwsCostCategoryRuleRuleAndAndTagsPropertyToTerraform(struct?: DataAwsCostCategory.RuleRuleAndAndTagsProperty): any;
export declare function dataAwsCostCategoryRuleRuleAndAndTagsPropertyToHclTerraform(struct?: DataAwsCostCategory.RuleRuleAndAndTagsProperty): any;
export declare function dataAwsCostCategoryRuleRuleAndAndPropertyToTerraform(struct?: DataAwsCostCategory.RuleRuleAndAndProperty): any;
export declare function dataAwsCostCategoryRuleRuleAndAndPropertyToHclTerraform(struct?: DataAwsCostCategory.RuleRuleAndAndProperty): any;
export declare function dataAwsCostCategoryRuleRuleAndCostCategoryPropertyToTerraform(struct?: DataAwsCostCategory.RuleRuleAndCostCategoryProperty): any;
export declare function dataAwsCostCategoryRuleRuleAndCostCategoryPropertyToHclTerraform(struct?: DataAwsCostCategory.RuleRuleAndCostCategoryProperty): any;
export declare function dataAwsCostCategoryRuleRuleAndDimensionPropertyToTerraform(struct?: DataAwsCostCategory.RuleRuleAndDimensionProperty): any;
export declare function dataAwsCostCategoryRuleRuleAndDimensionPropertyToHclTerraform(struct?: DataAwsCostCategory.RuleRuleAndDimensionProperty): any;
export declare function dataAwsCostCategoryRuleRuleAndNotCostCategoryPropertyToTerraform(struct?: DataAwsCostCategory.RuleRuleAndNotCostCategoryProperty): any;
export declare function dataAwsCostCategoryRuleRuleAndNotCostCategoryPropertyToHclTerraform(struct?: DataAwsCostCategory.RuleRuleAndNotCostCategoryProperty): any;
export declare function dataAwsCostCategoryRuleRuleAndNotDimensionPropertyToTerraform(struct?: DataAwsCostCategory.RuleRuleAndNotDimensionProperty): any;
export declare function dataAwsCostCategoryRuleRuleAndNotDimensionPropertyToHclTerraform(struct?: DataAwsCostCategory.RuleRuleAndNotDimensionProperty): any;
export declare function dataAwsCostCategoryRuleRuleAndNotTagsPropertyToTerraform(struct?: DataAwsCostCategory.RuleRuleAndNotTagsProperty): any;
export declare function dataAwsCostCategoryRuleRuleAndNotTagsPropertyToHclTerraform(struct?: DataAwsCostCategory.RuleRuleAndNotTagsProperty): any;
export declare function dataAwsCostCategoryRuleRuleAndNotPropertyToTerraform(struct?: DataAwsCostCategory.RuleRuleAndNotProperty): any;
export declare function dataAwsCostCategoryRuleRuleAndNotPropertyToHclTerraform(struct?: DataAwsCostCategory.RuleRuleAndNotProperty): any;
export declare function dataAwsCostCategoryRuleRuleAndOrCostCategoryPropertyToTerraform(struct?: DataAwsCostCategory.RuleRuleAndOrCostCategoryProperty): any;
export declare function dataAwsCostCategoryRuleRuleAndOrCostCategoryPropertyToHclTerraform(struct?: DataAwsCostCategory.RuleRuleAndOrCostCategoryProperty): any;
export declare function dataAwsCostCategoryRuleRuleAndOrDimensionPropertyToTerraform(struct?: DataAwsCostCategory.RuleRuleAndOrDimensionProperty): any;
export declare function dataAwsCostCategoryRuleRuleAndOrDimensionPropertyToHclTerraform(struct?: DataAwsCostCategory.RuleRuleAndOrDimensionProperty): any;
export declare function dataAwsCostCategoryRuleRuleAndOrTagsPropertyToTerraform(struct?: DataAwsCostCategory.RuleRuleAndOrTagsProperty): any;
export declare function dataAwsCostCategoryRuleRuleAndOrTagsPropertyToHclTerraform(struct?: DataAwsCostCategory.RuleRuleAndOrTagsProperty): any;
export declare function dataAwsCostCategoryRuleRuleAndOrPropertyToTerraform(struct?: DataAwsCostCategory.RuleRuleAndOrProperty): any;
export declare function dataAwsCostCategoryRuleRuleAndOrPropertyToHclTerraform(struct?: DataAwsCostCategory.RuleRuleAndOrProperty): any;
export declare function dataAwsCostCategoryRuleRuleAndTagsPropertyToTerraform(struct?: DataAwsCostCategory.RuleRuleAndTagsProperty): any;
export declare function dataAwsCostCategoryRuleRuleAndTagsPropertyToHclTerraform(struct?: DataAwsCostCategory.RuleRuleAndTagsProperty): any;
export declare function dataAwsCostCategoryRuleRuleAndPropertyToTerraform(struct?: DataAwsCostCategory.RuleRuleAndProperty): any;
export declare function dataAwsCostCategoryRuleRuleAndPropertyToHclTerraform(struct?: DataAwsCostCategory.RuleRuleAndProperty): any;
export declare function dataAwsCostCategoryRuleRuleCostCategoryPropertyToTerraform(struct?: DataAwsCostCategory.RuleRuleCostCategoryProperty): any;
export declare function dataAwsCostCategoryRuleRuleCostCategoryPropertyToHclTerraform(struct?: DataAwsCostCategory.RuleRuleCostCategoryProperty): any;
export declare function dataAwsCostCategoryRuleRuleDimensionPropertyToTerraform(struct?: DataAwsCostCategory.RuleRuleDimensionProperty): any;
export declare function dataAwsCostCategoryRuleRuleDimensionPropertyToHclTerraform(struct?: DataAwsCostCategory.RuleRuleDimensionProperty): any;
export declare function dataAwsCostCategoryRuleRuleNotAndCostCategoryPropertyToTerraform(struct?: DataAwsCostCategory.RuleRuleNotAndCostCategoryProperty): any;
export declare function dataAwsCostCategoryRuleRuleNotAndCostCategoryPropertyToHclTerraform(struct?: DataAwsCostCategory.RuleRuleNotAndCostCategoryProperty): any;
export declare function dataAwsCostCategoryRuleRuleNotAndDimensionPropertyToTerraform(struct?: DataAwsCostCategory.RuleRuleNotAndDimensionProperty): any;
export declare function dataAwsCostCategoryRuleRuleNotAndDimensionPropertyToHclTerraform(struct?: DataAwsCostCategory.RuleRuleNotAndDimensionProperty): any;
export declare function dataAwsCostCategoryRuleRuleNotAndTagsPropertyToTerraform(struct?: DataAwsCostCategory.RuleRuleNotAndTagsProperty): any;
export declare function dataAwsCostCategoryRuleRuleNotAndTagsPropertyToHclTerraform(struct?: DataAwsCostCategory.RuleRuleNotAndTagsProperty): any;
export declare function dataAwsCostCategoryRuleRuleNotAndPropertyToTerraform(struct?: DataAwsCostCategory.RuleRuleNotAndProperty): any;
export declare function dataAwsCostCategoryRuleRuleNotAndPropertyToHclTerraform(struct?: DataAwsCostCategory.RuleRuleNotAndProperty): any;
export declare function dataAwsCostCategoryRuleRuleNotCostCategoryPropertyToTerraform(struct?: DataAwsCostCategory.RuleRuleNotCostCategoryProperty): any;
export declare function dataAwsCostCategoryRuleRuleNotCostCategoryPropertyToHclTerraform(struct?: DataAwsCostCategory.RuleRuleNotCostCategoryProperty): any;
export declare function dataAwsCostCategoryRuleRuleNotDimensionPropertyToTerraform(struct?: DataAwsCostCategory.RuleRuleNotDimensionProperty): any;
export declare function dataAwsCostCategoryRuleRuleNotDimensionPropertyToHclTerraform(struct?: DataAwsCostCategory.RuleRuleNotDimensionProperty): any;
export declare function dataAwsCostCategoryRuleRuleNotNotCostCategoryPropertyToTerraform(struct?: DataAwsCostCategory.RuleRuleNotNotCostCategoryProperty): any;
export declare function dataAwsCostCategoryRuleRuleNotNotCostCategoryPropertyToHclTerraform(struct?: DataAwsCostCategory.RuleRuleNotNotCostCategoryProperty): any;
export declare function dataAwsCostCategoryRuleRuleNotNotDimensionPropertyToTerraform(struct?: DataAwsCostCategory.RuleRuleNotNotDimensionProperty): any;
export declare function dataAwsCostCategoryRuleRuleNotNotDimensionPropertyToHclTerraform(struct?: DataAwsCostCategory.RuleRuleNotNotDimensionProperty): any;
export declare function dataAwsCostCategoryRuleRuleNotNotTagsPropertyToTerraform(struct?: DataAwsCostCategory.RuleRuleNotNotTagsProperty): any;
export declare function dataAwsCostCategoryRuleRuleNotNotTagsPropertyToHclTerraform(struct?: DataAwsCostCategory.RuleRuleNotNotTagsProperty): any;
export declare function dataAwsCostCategoryRuleRuleNotNotPropertyToTerraform(struct?: DataAwsCostCategory.RuleRuleNotNotProperty): any;
export declare function dataAwsCostCategoryRuleRuleNotNotPropertyToHclTerraform(struct?: DataAwsCostCategory.RuleRuleNotNotProperty): any;
export declare function dataAwsCostCategoryRuleRuleNotOrCostCategoryPropertyToTerraform(struct?: DataAwsCostCategory.RuleRuleNotOrCostCategoryProperty): any;
export declare function dataAwsCostCategoryRuleRuleNotOrCostCategoryPropertyToHclTerraform(struct?: DataAwsCostCategory.RuleRuleNotOrCostCategoryProperty): any;
export declare function dataAwsCostCategoryRuleRuleNotOrDimensionPropertyToTerraform(struct?: DataAwsCostCategory.RuleRuleNotOrDimensionProperty): any;
export declare function dataAwsCostCategoryRuleRuleNotOrDimensionPropertyToHclTerraform(struct?: DataAwsCostCategory.RuleRuleNotOrDimensionProperty): any;
export declare function dataAwsCostCategoryRuleRuleNotOrTagsPropertyToTerraform(struct?: DataAwsCostCategory.RuleRuleNotOrTagsProperty): any;
export declare function dataAwsCostCategoryRuleRuleNotOrTagsPropertyToHclTerraform(struct?: DataAwsCostCategory.RuleRuleNotOrTagsProperty): any;
export declare function dataAwsCostCategoryRuleRuleNotOrPropertyToTerraform(struct?: DataAwsCostCategory.RuleRuleNotOrProperty): any;
export declare function dataAwsCostCategoryRuleRuleNotOrPropertyToHclTerraform(struct?: DataAwsCostCategory.RuleRuleNotOrProperty): any;
export declare function dataAwsCostCategoryRuleRuleNotTagsPropertyToTerraform(struct?: DataAwsCostCategory.RuleRuleNotTagsProperty): any;
export declare function dataAwsCostCategoryRuleRuleNotTagsPropertyToHclTerraform(struct?: DataAwsCostCategory.RuleRuleNotTagsProperty): any;
export declare function dataAwsCostCategoryRuleRuleNotPropertyToTerraform(struct?: DataAwsCostCategory.RuleRuleNotProperty): any;
export declare function dataAwsCostCategoryRuleRuleNotPropertyToHclTerraform(struct?: DataAwsCostCategory.RuleRuleNotProperty): any;
export declare function dataAwsCostCategoryRuleRuleOrAndCostCategoryPropertyToTerraform(struct?: DataAwsCostCategory.RuleRuleOrAndCostCategoryProperty): any;
export declare function dataAwsCostCategoryRuleRuleOrAndCostCategoryPropertyToHclTerraform(struct?: DataAwsCostCategory.RuleRuleOrAndCostCategoryProperty): any;
export declare function dataAwsCostCategoryRuleRuleOrAndDimensionPropertyToTerraform(struct?: DataAwsCostCategory.RuleRuleOrAndDimensionProperty): any;
export declare function dataAwsCostCategoryRuleRuleOrAndDimensionPropertyToHclTerraform(struct?: DataAwsCostCategory.RuleRuleOrAndDimensionProperty): any;
export declare function dataAwsCostCategoryRuleRuleOrAndTagsPropertyToTerraform(struct?: DataAwsCostCategory.RuleRuleOrAndTagsProperty): any;
export declare function dataAwsCostCategoryRuleRuleOrAndTagsPropertyToHclTerraform(struct?: DataAwsCostCategory.RuleRuleOrAndTagsProperty): any;
export declare function dataAwsCostCategoryRuleRuleOrAndPropertyToTerraform(struct?: DataAwsCostCategory.RuleRuleOrAndProperty): any;
export declare function dataAwsCostCategoryRuleRuleOrAndPropertyToHclTerraform(struct?: DataAwsCostCategory.RuleRuleOrAndProperty): any;
export declare function dataAwsCostCategoryRuleRuleOrCostCategoryPropertyToTerraform(struct?: DataAwsCostCategory.RuleRuleOrCostCategoryProperty): any;
export declare function dataAwsCostCategoryRuleRuleOrCostCategoryPropertyToHclTerraform(struct?: DataAwsCostCategory.RuleRuleOrCostCategoryProperty): any;
export declare function dataAwsCostCategoryRuleRuleOrDimensionPropertyToTerraform(struct?: DataAwsCostCategory.RuleRuleOrDimensionProperty): any;
export declare function dataAwsCostCategoryRuleRuleOrDimensionPropertyToHclTerraform(struct?: DataAwsCostCategory.RuleRuleOrDimensionProperty): any;
export declare function dataAwsCostCategoryRuleRuleOrNotCostCategoryPropertyToTerraform(struct?: DataAwsCostCategory.RuleRuleOrNotCostCategoryProperty): any;
export declare function dataAwsCostCategoryRuleRuleOrNotCostCategoryPropertyToHclTerraform(struct?: DataAwsCostCategory.RuleRuleOrNotCostCategoryProperty): any;
export declare function dataAwsCostCategoryRuleRuleOrNotDimensionPropertyToTerraform(struct?: DataAwsCostCategory.RuleRuleOrNotDimensionProperty): any;
export declare function dataAwsCostCategoryRuleRuleOrNotDimensionPropertyToHclTerraform(struct?: DataAwsCostCategory.RuleRuleOrNotDimensionProperty): any;
export declare function dataAwsCostCategoryRuleRuleOrNotTagsPropertyToTerraform(struct?: DataAwsCostCategory.RuleRuleOrNotTagsProperty): any;
export declare function dataAwsCostCategoryRuleRuleOrNotTagsPropertyToHclTerraform(struct?: DataAwsCostCategory.RuleRuleOrNotTagsProperty): any;
export declare function dataAwsCostCategoryRuleRuleOrNotPropertyToTerraform(struct?: DataAwsCostCategory.RuleRuleOrNotProperty): any;
export declare function dataAwsCostCategoryRuleRuleOrNotPropertyToHclTerraform(struct?: DataAwsCostCategory.RuleRuleOrNotProperty): any;
export declare function dataAwsCostCategoryRuleRuleOrOrCostCategoryPropertyToTerraform(struct?: DataAwsCostCategory.RuleRuleOrOrCostCategoryProperty): any;
export declare function dataAwsCostCategoryRuleRuleOrOrCostCategoryPropertyToHclTerraform(struct?: DataAwsCostCategory.RuleRuleOrOrCostCategoryProperty): any;
export declare function dataAwsCostCategoryRuleRuleOrOrDimensionPropertyToTerraform(struct?: DataAwsCostCategory.RuleRuleOrOrDimensionProperty): any;
export declare function dataAwsCostCategoryRuleRuleOrOrDimensionPropertyToHclTerraform(struct?: DataAwsCostCategory.RuleRuleOrOrDimensionProperty): any;
export declare function dataAwsCostCategoryRuleRuleOrOrTagsPropertyToTerraform(struct?: DataAwsCostCategory.RuleRuleOrOrTagsProperty): any;
export declare function dataAwsCostCategoryRuleRuleOrOrTagsPropertyToHclTerraform(struct?: DataAwsCostCategory.RuleRuleOrOrTagsProperty): any;
export declare function dataAwsCostCategoryRuleRuleOrOrPropertyToTerraform(struct?: DataAwsCostCategory.RuleRuleOrOrProperty): any;
export declare function dataAwsCostCategoryRuleRuleOrOrPropertyToHclTerraform(struct?: DataAwsCostCategory.RuleRuleOrOrProperty): any;
export declare function dataAwsCostCategoryRuleRuleOrTagsPropertyToTerraform(struct?: DataAwsCostCategory.RuleRuleOrTagsProperty): any;
export declare function dataAwsCostCategoryRuleRuleOrTagsPropertyToHclTerraform(struct?: DataAwsCostCategory.RuleRuleOrTagsProperty): any;
export declare function dataAwsCostCategoryRuleRuleOrPropertyToTerraform(struct?: DataAwsCostCategory.RuleRuleOrProperty): any;
export declare function dataAwsCostCategoryRuleRuleOrPropertyToHclTerraform(struct?: DataAwsCostCategory.RuleRuleOrProperty): any;
export declare function dataAwsCostCategoryRuleRuleTagsPropertyToTerraform(struct?: DataAwsCostCategory.RuleRuleTagsProperty): any;
export declare function dataAwsCostCategoryRuleRuleTagsPropertyToHclTerraform(struct?: DataAwsCostCategory.RuleRuleTagsProperty): any;
export declare function dataAwsCostCategoryRuleRulePropertyToTerraform(struct?: DataAwsCostCategory.RuleRuleProperty): any;
export declare function dataAwsCostCategoryRuleRulePropertyToHclTerraform(struct?: DataAwsCostCategory.RuleRuleProperty): any;
export declare function dataAwsCostCategoryRulePropertyToTerraform(struct?: DataAwsCostCategory.RuleProperty): any;
export declare function dataAwsCostCategoryRulePropertyToHclTerraform(struct?: DataAwsCostCategory.RuleProperty): any;
export declare function dataAwsCostCategoryParameterPropertyToTerraform(struct?: DataAwsCostCategory.ParameterProperty): any;
export declare function dataAwsCostCategoryParameterPropertyToHclTerraform(struct?: DataAwsCostCategory.ParameterProperty): any;
export declare function dataAwsCostCategorySplitChargeRulePropertyToTerraform(struct?: DataAwsCostCategory.SplitChargeRuleProperty): any;
export declare function dataAwsCostCategorySplitChargeRulePropertyToHclTerraform(struct?: DataAwsCostCategory.SplitChargeRuleProperty): any;
export declare namespace DataAwsCostCategory {
    interface InheritedValueProperty {
    }
    class InheritedValuePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): InheritedValueProperty | undefined;
        set internalValue(value: InheritedValueProperty | undefined);
        get dimensionKey(): string;
        get dimensionName(): string;
    }
    class InheritedValuePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): InheritedValuePropertyOutputReference;
    }
    interface RuleRuleAndAndCostCategoryProperty {
    }
    class RuleRuleAndAndCostCategoryPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleRuleAndAndCostCategoryProperty | undefined;
        set internalValue(value: RuleRuleAndAndCostCategoryProperty | undefined);
        get key(): string;
        get matchOptions(): string[];
        get values(): string[];
    }
    class RuleRuleAndAndCostCategoryPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleRuleAndAndCostCategoryPropertyOutputReference;
    }
    interface RuleRuleAndAndDimensionProperty {
    }
    class RuleRuleAndAndDimensionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleRuleAndAndDimensionProperty | undefined;
        set internalValue(value: RuleRuleAndAndDimensionProperty | undefined);
        get key(): string;
        get matchOptions(): string[];
        get values(): string[];
    }
    class RuleRuleAndAndDimensionPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleRuleAndAndDimensionPropertyOutputReference;
    }
    interface RuleRuleAndAndTagsProperty {
    }
    class RuleRuleAndAndTagsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleRuleAndAndTagsProperty | undefined;
        set internalValue(value: RuleRuleAndAndTagsProperty | undefined);
        get key(): string;
        get matchOptions(): string[];
        get values(): string[];
    }
    class RuleRuleAndAndTagsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleRuleAndAndTagsPropertyOutputReference;
    }
    interface RuleRuleAndAndProperty {
    }
    class RuleRuleAndAndPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleRuleAndAndProperty | undefined;
        set internalValue(value: RuleRuleAndAndProperty | undefined);
        private _costCategory;
        get costCategory(): RuleRuleAndAndCostCategoryPropertyList;
        private _dimension;
        get dimension(): RuleRuleAndAndDimensionPropertyList;
        private _tags;
        get tags(): RuleRuleAndAndTagsPropertyList;
    }
    class RuleRuleAndAndPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleRuleAndAndPropertyOutputReference;
    }
    interface RuleRuleAndCostCategoryProperty {
    }
    class RuleRuleAndCostCategoryPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleRuleAndCostCategoryProperty | undefined;
        set internalValue(value: RuleRuleAndCostCategoryProperty | undefined);
        get key(): string;
        get matchOptions(): string[];
        get values(): string[];
    }
    class RuleRuleAndCostCategoryPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleRuleAndCostCategoryPropertyOutputReference;
    }
    interface RuleRuleAndDimensionProperty {
    }
    class RuleRuleAndDimensionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleRuleAndDimensionProperty | undefined;
        set internalValue(value: RuleRuleAndDimensionProperty | undefined);
        get key(): string;
        get matchOptions(): string[];
        get values(): string[];
    }
    class RuleRuleAndDimensionPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleRuleAndDimensionPropertyOutputReference;
    }
    interface RuleRuleAndNotCostCategoryProperty {
    }
    class RuleRuleAndNotCostCategoryPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleRuleAndNotCostCategoryProperty | undefined;
        set internalValue(value: RuleRuleAndNotCostCategoryProperty | undefined);
        get key(): string;
        get matchOptions(): string[];
        get values(): string[];
    }
    class RuleRuleAndNotCostCategoryPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleRuleAndNotCostCategoryPropertyOutputReference;
    }
    interface RuleRuleAndNotDimensionProperty {
    }
    class RuleRuleAndNotDimensionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleRuleAndNotDimensionProperty | undefined;
        set internalValue(value: RuleRuleAndNotDimensionProperty | undefined);
        get key(): string;
        get matchOptions(): string[];
        get values(): string[];
    }
    class RuleRuleAndNotDimensionPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleRuleAndNotDimensionPropertyOutputReference;
    }
    interface RuleRuleAndNotTagsProperty {
    }
    class RuleRuleAndNotTagsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleRuleAndNotTagsProperty | undefined;
        set internalValue(value: RuleRuleAndNotTagsProperty | undefined);
        get key(): string;
        get matchOptions(): string[];
        get values(): string[];
    }
    class RuleRuleAndNotTagsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleRuleAndNotTagsPropertyOutputReference;
    }
    interface RuleRuleAndNotProperty {
    }
    class RuleRuleAndNotPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleRuleAndNotProperty | undefined;
        set internalValue(value: RuleRuleAndNotProperty | undefined);
        private _costCategory;
        get costCategory(): RuleRuleAndNotCostCategoryPropertyList;
        private _dimension;
        get dimension(): RuleRuleAndNotDimensionPropertyList;
        private _tags;
        get tags(): RuleRuleAndNotTagsPropertyList;
    }
    class RuleRuleAndNotPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleRuleAndNotPropertyOutputReference;
    }
    interface RuleRuleAndOrCostCategoryProperty {
    }
    class RuleRuleAndOrCostCategoryPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleRuleAndOrCostCategoryProperty | undefined;
        set internalValue(value: RuleRuleAndOrCostCategoryProperty | undefined);
        get key(): string;
        get matchOptions(): string[];
        get values(): string[];
    }
    class RuleRuleAndOrCostCategoryPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleRuleAndOrCostCategoryPropertyOutputReference;
    }
    interface RuleRuleAndOrDimensionProperty {
    }
    class RuleRuleAndOrDimensionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleRuleAndOrDimensionProperty | undefined;
        set internalValue(value: RuleRuleAndOrDimensionProperty | undefined);
        get key(): string;
        get matchOptions(): string[];
        get values(): string[];
    }
    class RuleRuleAndOrDimensionPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleRuleAndOrDimensionPropertyOutputReference;
    }
    interface RuleRuleAndOrTagsProperty {
    }
    class RuleRuleAndOrTagsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleRuleAndOrTagsProperty | undefined;
        set internalValue(value: RuleRuleAndOrTagsProperty | undefined);
        get key(): string;
        get matchOptions(): string[];
        get values(): string[];
    }
    class RuleRuleAndOrTagsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleRuleAndOrTagsPropertyOutputReference;
    }
    interface RuleRuleAndOrProperty {
    }
    class RuleRuleAndOrPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleRuleAndOrProperty | undefined;
        set internalValue(value: RuleRuleAndOrProperty | undefined);
        private _costCategory;
        get costCategory(): RuleRuleAndOrCostCategoryPropertyList;
        private _dimension;
        get dimension(): RuleRuleAndOrDimensionPropertyList;
        private _tags;
        get tags(): RuleRuleAndOrTagsPropertyList;
    }
    class RuleRuleAndOrPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleRuleAndOrPropertyOutputReference;
    }
    interface RuleRuleAndTagsProperty {
    }
    class RuleRuleAndTagsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleRuleAndTagsProperty | undefined;
        set internalValue(value: RuleRuleAndTagsProperty | undefined);
        get key(): string;
        get matchOptions(): string[];
        get values(): string[];
    }
    class RuleRuleAndTagsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleRuleAndTagsPropertyOutputReference;
    }
    interface RuleRuleAndProperty {
    }
    class RuleRuleAndPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleRuleAndProperty | undefined;
        set internalValue(value: RuleRuleAndProperty | undefined);
        private _and;
        get and(): RuleRuleAndAndPropertyList;
        private _costCategory;
        get costCategory(): RuleRuleAndCostCategoryPropertyList;
        private _dimension;
        get dimension(): RuleRuleAndDimensionPropertyList;
        private _not;
        get not(): RuleRuleAndNotPropertyList;
        private _or;
        get or(): RuleRuleAndOrPropertyList;
        private _tags;
        get tags(): RuleRuleAndTagsPropertyList;
    }
    class RuleRuleAndPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleRuleAndPropertyOutputReference;
    }
    interface RuleRuleCostCategoryProperty {
    }
    class RuleRuleCostCategoryPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleRuleCostCategoryProperty | undefined;
        set internalValue(value: RuleRuleCostCategoryProperty | undefined);
        get key(): string;
        get matchOptions(): string[];
        get values(): string[];
    }
    class RuleRuleCostCategoryPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleRuleCostCategoryPropertyOutputReference;
    }
    interface RuleRuleDimensionProperty {
    }
    class RuleRuleDimensionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleRuleDimensionProperty | undefined;
        set internalValue(value: RuleRuleDimensionProperty | undefined);
        get key(): string;
        get matchOptions(): string[];
        get values(): string[];
    }
    class RuleRuleDimensionPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleRuleDimensionPropertyOutputReference;
    }
    interface RuleRuleNotAndCostCategoryProperty {
    }
    class RuleRuleNotAndCostCategoryPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleRuleNotAndCostCategoryProperty | undefined;
        set internalValue(value: RuleRuleNotAndCostCategoryProperty | undefined);
        get key(): string;
        get matchOptions(): string[];
        get values(): string[];
    }
    class RuleRuleNotAndCostCategoryPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleRuleNotAndCostCategoryPropertyOutputReference;
    }
    interface RuleRuleNotAndDimensionProperty {
    }
    class RuleRuleNotAndDimensionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleRuleNotAndDimensionProperty | undefined;
        set internalValue(value: RuleRuleNotAndDimensionProperty | undefined);
        get key(): string;
        get matchOptions(): string[];
        get values(): string[];
    }
    class RuleRuleNotAndDimensionPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleRuleNotAndDimensionPropertyOutputReference;
    }
    interface RuleRuleNotAndTagsProperty {
    }
    class RuleRuleNotAndTagsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleRuleNotAndTagsProperty | undefined;
        set internalValue(value: RuleRuleNotAndTagsProperty | undefined);
        get key(): string;
        get matchOptions(): string[];
        get values(): string[];
    }
    class RuleRuleNotAndTagsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleRuleNotAndTagsPropertyOutputReference;
    }
    interface RuleRuleNotAndProperty {
    }
    class RuleRuleNotAndPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleRuleNotAndProperty | undefined;
        set internalValue(value: RuleRuleNotAndProperty | undefined);
        private _costCategory;
        get costCategory(): RuleRuleNotAndCostCategoryPropertyList;
        private _dimension;
        get dimension(): RuleRuleNotAndDimensionPropertyList;
        private _tags;
        get tags(): RuleRuleNotAndTagsPropertyList;
    }
    class RuleRuleNotAndPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleRuleNotAndPropertyOutputReference;
    }
    interface RuleRuleNotCostCategoryProperty {
    }
    class RuleRuleNotCostCategoryPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleRuleNotCostCategoryProperty | undefined;
        set internalValue(value: RuleRuleNotCostCategoryProperty | undefined);
        get key(): string;
        get matchOptions(): string[];
        get values(): string[];
    }
    class RuleRuleNotCostCategoryPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleRuleNotCostCategoryPropertyOutputReference;
    }
    interface RuleRuleNotDimensionProperty {
    }
    class RuleRuleNotDimensionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleRuleNotDimensionProperty | undefined;
        set internalValue(value: RuleRuleNotDimensionProperty | undefined);
        get key(): string;
        get matchOptions(): string[];
        get values(): string[];
    }
    class RuleRuleNotDimensionPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleRuleNotDimensionPropertyOutputReference;
    }
    interface RuleRuleNotNotCostCategoryProperty {
    }
    class RuleRuleNotNotCostCategoryPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleRuleNotNotCostCategoryProperty | undefined;
        set internalValue(value: RuleRuleNotNotCostCategoryProperty | undefined);
        get key(): string;
        get matchOptions(): string[];
        get values(): string[];
    }
    class RuleRuleNotNotCostCategoryPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleRuleNotNotCostCategoryPropertyOutputReference;
    }
    interface RuleRuleNotNotDimensionProperty {
    }
    class RuleRuleNotNotDimensionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleRuleNotNotDimensionProperty | undefined;
        set internalValue(value: RuleRuleNotNotDimensionProperty | undefined);
        get key(): string;
        get matchOptions(): string[];
        get values(): string[];
    }
    class RuleRuleNotNotDimensionPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleRuleNotNotDimensionPropertyOutputReference;
    }
    interface RuleRuleNotNotTagsProperty {
    }
    class RuleRuleNotNotTagsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleRuleNotNotTagsProperty | undefined;
        set internalValue(value: RuleRuleNotNotTagsProperty | undefined);
        get key(): string;
        get matchOptions(): string[];
        get values(): string[];
    }
    class RuleRuleNotNotTagsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleRuleNotNotTagsPropertyOutputReference;
    }
    interface RuleRuleNotNotProperty {
    }
    class RuleRuleNotNotPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleRuleNotNotProperty | undefined;
        set internalValue(value: RuleRuleNotNotProperty | undefined);
        private _costCategory;
        get costCategory(): RuleRuleNotNotCostCategoryPropertyList;
        private _dimension;
        get dimension(): RuleRuleNotNotDimensionPropertyList;
        private _tags;
        get tags(): RuleRuleNotNotTagsPropertyList;
    }
    class RuleRuleNotNotPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleRuleNotNotPropertyOutputReference;
    }
    interface RuleRuleNotOrCostCategoryProperty {
    }
    class RuleRuleNotOrCostCategoryPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleRuleNotOrCostCategoryProperty | undefined;
        set internalValue(value: RuleRuleNotOrCostCategoryProperty | undefined);
        get key(): string;
        get matchOptions(): string[];
        get values(): string[];
    }
    class RuleRuleNotOrCostCategoryPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleRuleNotOrCostCategoryPropertyOutputReference;
    }
    interface RuleRuleNotOrDimensionProperty {
    }
    class RuleRuleNotOrDimensionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleRuleNotOrDimensionProperty | undefined;
        set internalValue(value: RuleRuleNotOrDimensionProperty | undefined);
        get key(): string;
        get matchOptions(): string[];
        get values(): string[];
    }
    class RuleRuleNotOrDimensionPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleRuleNotOrDimensionPropertyOutputReference;
    }
    interface RuleRuleNotOrTagsProperty {
    }
    class RuleRuleNotOrTagsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleRuleNotOrTagsProperty | undefined;
        set internalValue(value: RuleRuleNotOrTagsProperty | undefined);
        get key(): string;
        get matchOptions(): string[];
        get values(): string[];
    }
    class RuleRuleNotOrTagsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleRuleNotOrTagsPropertyOutputReference;
    }
    interface RuleRuleNotOrProperty {
    }
    class RuleRuleNotOrPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleRuleNotOrProperty | undefined;
        set internalValue(value: RuleRuleNotOrProperty | undefined);
        private _costCategory;
        get costCategory(): RuleRuleNotOrCostCategoryPropertyList;
        private _dimension;
        get dimension(): RuleRuleNotOrDimensionPropertyList;
        private _tags;
        get tags(): RuleRuleNotOrTagsPropertyList;
    }
    class RuleRuleNotOrPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleRuleNotOrPropertyOutputReference;
    }
    interface RuleRuleNotTagsProperty {
    }
    class RuleRuleNotTagsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleRuleNotTagsProperty | undefined;
        set internalValue(value: RuleRuleNotTagsProperty | undefined);
        get key(): string;
        get matchOptions(): string[];
        get values(): string[];
    }
    class RuleRuleNotTagsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleRuleNotTagsPropertyOutputReference;
    }
    interface RuleRuleNotProperty {
    }
    class RuleRuleNotPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleRuleNotProperty | undefined;
        set internalValue(value: RuleRuleNotProperty | undefined);
        private _and;
        get and(): RuleRuleNotAndPropertyList;
        private _costCategory;
        get costCategory(): RuleRuleNotCostCategoryPropertyList;
        private _dimension;
        get dimension(): RuleRuleNotDimensionPropertyList;
        private _not;
        get not(): RuleRuleNotNotPropertyList;
        private _or;
        get or(): RuleRuleNotOrPropertyList;
        private _tags;
        get tags(): RuleRuleNotTagsPropertyList;
    }
    class RuleRuleNotPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleRuleNotPropertyOutputReference;
    }
    interface RuleRuleOrAndCostCategoryProperty {
    }
    class RuleRuleOrAndCostCategoryPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleRuleOrAndCostCategoryProperty | undefined;
        set internalValue(value: RuleRuleOrAndCostCategoryProperty | undefined);
        get key(): string;
        get matchOptions(): string[];
        get values(): string[];
    }
    class RuleRuleOrAndCostCategoryPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleRuleOrAndCostCategoryPropertyOutputReference;
    }
    interface RuleRuleOrAndDimensionProperty {
    }
    class RuleRuleOrAndDimensionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleRuleOrAndDimensionProperty | undefined;
        set internalValue(value: RuleRuleOrAndDimensionProperty | undefined);
        get key(): string;
        get matchOptions(): string[];
        get values(): string[];
    }
    class RuleRuleOrAndDimensionPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleRuleOrAndDimensionPropertyOutputReference;
    }
    interface RuleRuleOrAndTagsProperty {
    }
    class RuleRuleOrAndTagsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleRuleOrAndTagsProperty | undefined;
        set internalValue(value: RuleRuleOrAndTagsProperty | undefined);
        get key(): string;
        get matchOptions(): string[];
        get values(): string[];
    }
    class RuleRuleOrAndTagsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleRuleOrAndTagsPropertyOutputReference;
    }
    interface RuleRuleOrAndProperty {
    }
    class RuleRuleOrAndPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleRuleOrAndProperty | undefined;
        set internalValue(value: RuleRuleOrAndProperty | undefined);
        private _costCategory;
        get costCategory(): RuleRuleOrAndCostCategoryPropertyList;
        private _dimension;
        get dimension(): RuleRuleOrAndDimensionPropertyList;
        private _tags;
        get tags(): RuleRuleOrAndTagsPropertyList;
    }
    class RuleRuleOrAndPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleRuleOrAndPropertyOutputReference;
    }
    interface RuleRuleOrCostCategoryProperty {
    }
    class RuleRuleOrCostCategoryPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleRuleOrCostCategoryProperty | undefined;
        set internalValue(value: RuleRuleOrCostCategoryProperty | undefined);
        get key(): string;
        get matchOptions(): string[];
        get values(): string[];
    }
    class RuleRuleOrCostCategoryPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleRuleOrCostCategoryPropertyOutputReference;
    }
    interface RuleRuleOrDimensionProperty {
    }
    class RuleRuleOrDimensionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleRuleOrDimensionProperty | undefined;
        set internalValue(value: RuleRuleOrDimensionProperty | undefined);
        get key(): string;
        get matchOptions(): string[];
        get values(): string[];
    }
    class RuleRuleOrDimensionPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleRuleOrDimensionPropertyOutputReference;
    }
    interface RuleRuleOrNotCostCategoryProperty {
    }
    class RuleRuleOrNotCostCategoryPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleRuleOrNotCostCategoryProperty | undefined;
        set internalValue(value: RuleRuleOrNotCostCategoryProperty | undefined);
        get key(): string;
        get matchOptions(): string[];
        get values(): string[];
    }
    class RuleRuleOrNotCostCategoryPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleRuleOrNotCostCategoryPropertyOutputReference;
    }
    interface RuleRuleOrNotDimensionProperty {
    }
    class RuleRuleOrNotDimensionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleRuleOrNotDimensionProperty | undefined;
        set internalValue(value: RuleRuleOrNotDimensionProperty | undefined);
        get key(): string;
        get matchOptions(): string[];
        get values(): string[];
    }
    class RuleRuleOrNotDimensionPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleRuleOrNotDimensionPropertyOutputReference;
    }
    interface RuleRuleOrNotTagsProperty {
    }
    class RuleRuleOrNotTagsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleRuleOrNotTagsProperty | undefined;
        set internalValue(value: RuleRuleOrNotTagsProperty | undefined);
        get key(): string;
        get matchOptions(): string[];
        get values(): string[];
    }
    class RuleRuleOrNotTagsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleRuleOrNotTagsPropertyOutputReference;
    }
    interface RuleRuleOrNotProperty {
    }
    class RuleRuleOrNotPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleRuleOrNotProperty | undefined;
        set internalValue(value: RuleRuleOrNotProperty | undefined);
        private _costCategory;
        get costCategory(): RuleRuleOrNotCostCategoryPropertyList;
        private _dimension;
        get dimension(): RuleRuleOrNotDimensionPropertyList;
        private _tags;
        get tags(): RuleRuleOrNotTagsPropertyList;
    }
    class RuleRuleOrNotPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleRuleOrNotPropertyOutputReference;
    }
    interface RuleRuleOrOrCostCategoryProperty {
    }
    class RuleRuleOrOrCostCategoryPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleRuleOrOrCostCategoryProperty | undefined;
        set internalValue(value: RuleRuleOrOrCostCategoryProperty | undefined);
        get key(): string;
        get matchOptions(): string[];
        get values(): string[];
    }
    class RuleRuleOrOrCostCategoryPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleRuleOrOrCostCategoryPropertyOutputReference;
    }
    interface RuleRuleOrOrDimensionProperty {
    }
    class RuleRuleOrOrDimensionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleRuleOrOrDimensionProperty | undefined;
        set internalValue(value: RuleRuleOrOrDimensionProperty | undefined);
        get key(): string;
        get matchOptions(): string[];
        get values(): string[];
    }
    class RuleRuleOrOrDimensionPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleRuleOrOrDimensionPropertyOutputReference;
    }
    interface RuleRuleOrOrTagsProperty {
    }
    class RuleRuleOrOrTagsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleRuleOrOrTagsProperty | undefined;
        set internalValue(value: RuleRuleOrOrTagsProperty | undefined);
        get key(): string;
        get matchOptions(): string[];
        get values(): string[];
    }
    class RuleRuleOrOrTagsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleRuleOrOrTagsPropertyOutputReference;
    }
    interface RuleRuleOrOrProperty {
    }
    class RuleRuleOrOrPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleRuleOrOrProperty | undefined;
        set internalValue(value: RuleRuleOrOrProperty | undefined);
        private _costCategory;
        get costCategory(): RuleRuleOrOrCostCategoryPropertyList;
        private _dimension;
        get dimension(): RuleRuleOrOrDimensionPropertyList;
        private _tags;
        get tags(): RuleRuleOrOrTagsPropertyList;
    }
    class RuleRuleOrOrPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleRuleOrOrPropertyOutputReference;
    }
    interface RuleRuleOrTagsProperty {
    }
    class RuleRuleOrTagsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleRuleOrTagsProperty | undefined;
        set internalValue(value: RuleRuleOrTagsProperty | undefined);
        get key(): string;
        get matchOptions(): string[];
        get values(): string[];
    }
    class RuleRuleOrTagsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleRuleOrTagsPropertyOutputReference;
    }
    interface RuleRuleOrProperty {
    }
    class RuleRuleOrPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleRuleOrProperty | undefined;
        set internalValue(value: RuleRuleOrProperty | undefined);
        private _and;
        get and(): RuleRuleOrAndPropertyList;
        private _costCategory;
        get costCategory(): RuleRuleOrCostCategoryPropertyList;
        private _dimension;
        get dimension(): RuleRuleOrDimensionPropertyList;
        private _not;
        get not(): RuleRuleOrNotPropertyList;
        private _or;
        get or(): RuleRuleOrOrPropertyList;
        private _tags;
        get tags(): RuleRuleOrTagsPropertyList;
    }
    class RuleRuleOrPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleRuleOrPropertyOutputReference;
    }
    interface RuleRuleTagsProperty {
    }
    class RuleRuleTagsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleRuleTagsProperty | undefined;
        set internalValue(value: RuleRuleTagsProperty | undefined);
        get key(): string;
        get matchOptions(): string[];
        get values(): string[];
    }
    class RuleRuleTagsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleRuleTagsPropertyOutputReference;
    }
    interface RuleRuleProperty {
    }
    class RuleRulePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleRuleProperty | undefined;
        set internalValue(value: RuleRuleProperty | undefined);
        private _and;
        get and(): RuleRuleAndPropertyList;
        private _costCategory;
        get costCategory(): RuleRuleCostCategoryPropertyList;
        private _dimension;
        get dimension(): RuleRuleDimensionPropertyList;
        private _not;
        get not(): RuleRuleNotPropertyList;
        private _or;
        get or(): RuleRuleOrPropertyList;
        private _tags;
        get tags(): RuleRuleTagsPropertyList;
    }
    class RuleRulePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleRulePropertyOutputReference;
    }
    interface RuleProperty {
    }
    class RulePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleProperty | undefined;
        set internalValue(value: RuleProperty | undefined);
        private _inheritedValue;
        get inheritedValue(): InheritedValuePropertyList;
        private _rule;
        get rule(): RuleRulePropertyList;
        get type(): string;
        get value(): string;
    }
    class RulePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RulePropertyOutputReference;
    }
    interface ParameterProperty {
    }
    class ParameterPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ParameterProperty | undefined;
        set internalValue(value: ParameterProperty | undefined);
        get type(): string;
        get values(): string[];
    }
    class ParameterPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ParameterPropertyOutputReference;
    }
    interface SplitChargeRuleProperty {
    }
    class SplitChargeRulePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SplitChargeRuleProperty | undefined;
        set internalValue(value: SplitChargeRuleProperty | undefined);
        get method(): string;
        private _parameter;
        get parameter(): ParameterPropertyList;
        get source(): string;
        get targets(): string[];
    }
    class SplitChargeRulePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SplitChargeRulePropertyOutputReference;
    }
}
