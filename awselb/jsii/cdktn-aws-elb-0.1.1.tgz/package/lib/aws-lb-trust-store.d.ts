import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsLbTrustStoreConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_trust_store#ca_certificates_bundle_s3_bucket AwsLbTrustStore#ca_certificates_bundle_s3_bucket}
    */
    readonly caCertificatesBundleS3Bucket: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_trust_store#ca_certificates_bundle_s3_key AwsLbTrustStore#ca_certificates_bundle_s3_key}
    */
    readonly caCertificatesBundleS3Key: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_trust_store#ca_certificates_bundle_s3_object_version AwsLbTrustStore#ca_certificates_bundle_s3_object_version}
    */
    readonly caCertificatesBundleS3ObjectVersion?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_trust_store#id AwsLbTrustStore#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_trust_store#name AwsLbTrustStore#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_trust_store#name_prefix AwsLbTrustStore#name_prefix}
    */
    readonly namePrefix?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_trust_store#region AwsLbTrustStore#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_trust_store#tags AwsLbTrustStore#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_trust_store#tags_all AwsLbTrustStore#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_trust_store#timeouts AwsLbTrustStore#timeouts}
    */
    readonly timeouts?: AwsLbTrustStore.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_trust_store aws_lb_trust_store}
*/
export declare class AwsLbTrustStore extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_lb_trust_store";
    /**
    * Generates CDKTN code for importing a AwsLbTrustStore resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsLbTrustStore to import
    * @param importFromId The id of the existing AwsLbTrustStore that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_trust_store#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsLbTrustStore to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_trust_store aws_lb_trust_store} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsLbTrustStoreConfig
    */
    constructor(scope: Construct, id: string, config: AwsLbTrustStoreConfig);
    get arn(): string;
    get arnSuffix(): string;
    private _caCertificatesBundleS3Bucket?;
    get caCertificatesBundleS3Bucket(): string;
    set caCertificatesBundleS3Bucket(value: string);
    get caCertificatesBundleS3BucketInput(): string | undefined;
    private _caCertificatesBundleS3Key?;
    get caCertificatesBundleS3Key(): string;
    set caCertificatesBundleS3Key(value: string);
    get caCertificatesBundleS3KeyInput(): string | undefined;
    private _caCertificatesBundleS3ObjectVersion?;
    get caCertificatesBundleS3ObjectVersion(): string;
    set caCertificatesBundleS3ObjectVersion(value: string);
    resetCaCertificatesBundleS3ObjectVersion(): void;
    get caCertificatesBundleS3ObjectVersionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _namePrefix?;
    get namePrefix(): string;
    set namePrefix(value: string);
    resetNamePrefix(): void;
    get namePrefixInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _timeouts;
    get timeouts(): AwsLbTrustStore.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsLbTrustStore.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsLbTrustStore.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsLbTrustStoreTimeoutsPropertyToTerraform(struct?: AwsLbTrustStore.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsLbTrustStoreTimeoutsPropertyToHclTerraform(struct?: AwsLbTrustStore.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsLbTrustStore {
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_trust_store#create AwsLbTrustStore#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_trust_store#delete AwsLbTrustStore#delete}
        */
        readonly delete?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
    }
}
