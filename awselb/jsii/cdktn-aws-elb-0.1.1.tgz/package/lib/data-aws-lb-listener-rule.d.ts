import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsLbListenerRuleConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lb_listener_rule#arn DataAwsLbListenerRule#arn}
    */
    readonly arn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lb_listener_rule#listener_arn DataAwsLbListenerRule#listener_arn}
    */
    readonly listenerArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lb_listener_rule#priority DataAwsLbListenerRule#priority}
    */
    readonly priority?: number;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lb_listener_rule#region DataAwsLbListenerRule#region}
    */
    readonly region?: string;
    /**
    * action block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lb_listener_rule#action DataAwsLbListenerRule#action}
    */
    readonly action?: DataAwsLbListenerRule.ActionProperty[] | cdktn.IResolvable;
    /**
    * condition block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lb_listener_rule#condition DataAwsLbListenerRule#condition}
    */
    readonly condition?: DataAwsLbListenerRule.ConditionProperty[] | cdktn.IResolvable;
    /**
    * transform block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lb_listener_rule#transform DataAwsLbListenerRule#transform}
    */
    readonly transform?: DataAwsLbListenerRule.TransformProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lb_listener_rule aws_lb_listener_rule}
*/
export declare class DataAwsLbListenerRule extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_lb_listener_rule";
    /**
    * Generates CDKTN code for importing a DataAwsLbListenerRule resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsLbListenerRule to import
    * @param importFromId The id of the existing DataAwsLbListenerRule that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lb_listener_rule#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsLbListenerRule to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lb_listener_rule aws_lb_listener_rule} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsLbListenerRuleConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataAwsLbListenerRuleConfig);
    private _arn?;
    get arn(): string;
    set arn(value: string);
    resetArn(): void;
    get arnInput(): string | undefined;
    private _listenerArn?;
    get listenerArn(): string;
    set listenerArn(value: string);
    resetListenerArn(): void;
    get listenerArnInput(): string | undefined;
    private _priority?;
    get priority(): number;
    set priority(value: number);
    resetPriority(): void;
    get priorityInput(): number | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags;
    get tags(): cdktn.StringMap;
    private _action;
    get action(): DataAwsLbListenerRule.ActionPropertyList;
    putAction(value: DataAwsLbListenerRule.ActionProperty[] | cdktn.IResolvable): void;
    resetAction(): void;
    get actionInput(): cdktn.IResolvable | DataAwsLbListenerRule.ActionProperty[] | undefined;
    private _condition;
    get condition(): DataAwsLbListenerRule.ConditionPropertyList;
    putCondition(value: DataAwsLbListenerRule.ConditionProperty[] | cdktn.IResolvable): void;
    resetCondition(): void;
    get conditionInput(): cdktn.IResolvable | DataAwsLbListenerRule.ConditionProperty[] | undefined;
    private _transform;
    get transform(): DataAwsLbListenerRule.TransformPropertyList;
    putTransform(value: DataAwsLbListenerRule.TransformProperty[] | cdktn.IResolvable): void;
    resetTransform(): void;
    get transformInput(): cdktn.IResolvable | DataAwsLbListenerRule.TransformProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataAwsLbListenerRuleAuthenticateCognitoPropertyToTerraform(struct?: DataAwsLbListenerRule.AuthenticateCognitoProperty | cdktn.IResolvable): any;
export declare function dataAwsLbListenerRuleAuthenticateCognitoPropertyToHclTerraform(struct?: DataAwsLbListenerRule.AuthenticateCognitoProperty | cdktn.IResolvable): any;
export declare function dataAwsLbListenerRuleAuthenticateOidcPropertyToTerraform(struct?: DataAwsLbListenerRule.AuthenticateOidcProperty | cdktn.IResolvable): any;
export declare function dataAwsLbListenerRuleAuthenticateOidcPropertyToHclTerraform(struct?: DataAwsLbListenerRule.AuthenticateOidcProperty | cdktn.IResolvable): any;
export declare function dataAwsLbListenerRuleFixedResponsePropertyToTerraform(struct?: DataAwsLbListenerRule.FixedResponseProperty | cdktn.IResolvable): any;
export declare function dataAwsLbListenerRuleFixedResponsePropertyToHclTerraform(struct?: DataAwsLbListenerRule.FixedResponseProperty | cdktn.IResolvable): any;
export declare function dataAwsLbListenerRuleStickinessPropertyToTerraform(struct?: DataAwsLbListenerRule.StickinessProperty | cdktn.IResolvable): any;
export declare function dataAwsLbListenerRuleStickinessPropertyToHclTerraform(struct?: DataAwsLbListenerRule.StickinessProperty | cdktn.IResolvable): any;
export declare function dataAwsLbListenerRuleTargetGroupPropertyToTerraform(struct?: DataAwsLbListenerRule.TargetGroupProperty | cdktn.IResolvable): any;
export declare function dataAwsLbListenerRuleTargetGroupPropertyToHclTerraform(struct?: DataAwsLbListenerRule.TargetGroupProperty | cdktn.IResolvable): any;
export declare function dataAwsLbListenerRuleForwardPropertyToTerraform(struct?: DataAwsLbListenerRule.ForwardProperty | cdktn.IResolvable): any;
export declare function dataAwsLbListenerRuleForwardPropertyToHclTerraform(struct?: DataAwsLbListenerRule.ForwardProperty | cdktn.IResolvable): any;
export declare function dataAwsLbListenerRuleAdditionalClaimPropertyToTerraform(struct?: DataAwsLbListenerRule.AdditionalClaimProperty | cdktn.IResolvable): any;
export declare function dataAwsLbListenerRuleAdditionalClaimPropertyToHclTerraform(struct?: DataAwsLbListenerRule.AdditionalClaimProperty | cdktn.IResolvable): any;
export declare function dataAwsLbListenerRuleJwtValidationPropertyToTerraform(struct?: DataAwsLbListenerRule.JwtValidationProperty | cdktn.IResolvable): any;
export declare function dataAwsLbListenerRuleJwtValidationPropertyToHclTerraform(struct?: DataAwsLbListenerRule.JwtValidationProperty | cdktn.IResolvable): any;
export declare function dataAwsLbListenerRuleRedirectPropertyToTerraform(struct?: DataAwsLbListenerRule.RedirectProperty | cdktn.IResolvable): any;
export declare function dataAwsLbListenerRuleRedirectPropertyToHclTerraform(struct?: DataAwsLbListenerRule.RedirectProperty | cdktn.IResolvable): any;
export declare function dataAwsLbListenerRuleActionPropertyToTerraform(struct?: DataAwsLbListenerRule.ActionProperty | cdktn.IResolvable): any;
export declare function dataAwsLbListenerRuleActionPropertyToHclTerraform(struct?: DataAwsLbListenerRule.ActionProperty | cdktn.IResolvable): any;
export declare function dataAwsLbListenerRuleHostHeaderPropertyToTerraform(struct?: DataAwsLbListenerRule.HostHeaderProperty | cdktn.IResolvable): any;
export declare function dataAwsLbListenerRuleHostHeaderPropertyToHclTerraform(struct?: DataAwsLbListenerRule.HostHeaderProperty | cdktn.IResolvable): any;
export declare function dataAwsLbListenerRuleHttpHeaderPropertyToTerraform(struct?: DataAwsLbListenerRule.HttpHeaderProperty | cdktn.IResolvable): any;
export declare function dataAwsLbListenerRuleHttpHeaderPropertyToHclTerraform(struct?: DataAwsLbListenerRule.HttpHeaderProperty | cdktn.IResolvable): any;
export declare function dataAwsLbListenerRuleHttpRequestMethodPropertyToTerraform(struct?: DataAwsLbListenerRule.HttpRequestMethodProperty | cdktn.IResolvable): any;
export declare function dataAwsLbListenerRuleHttpRequestMethodPropertyToHclTerraform(struct?: DataAwsLbListenerRule.HttpRequestMethodProperty | cdktn.IResolvable): any;
export declare function dataAwsLbListenerRulePathPatternPropertyToTerraform(struct?: DataAwsLbListenerRule.PathPatternProperty | cdktn.IResolvable): any;
export declare function dataAwsLbListenerRulePathPatternPropertyToHclTerraform(struct?: DataAwsLbListenerRule.PathPatternProperty | cdktn.IResolvable): any;
export declare function dataAwsLbListenerRuleValuesPropertyToTerraform(struct?: DataAwsLbListenerRule.ValuesProperty | cdktn.IResolvable): any;
export declare function dataAwsLbListenerRuleValuesPropertyToHclTerraform(struct?: DataAwsLbListenerRule.ValuesProperty | cdktn.IResolvable): any;
export declare function dataAwsLbListenerRuleQueryStringPropertyToTerraform(struct?: DataAwsLbListenerRule.QueryStringProperty | cdktn.IResolvable): any;
export declare function dataAwsLbListenerRuleQueryStringPropertyToHclTerraform(struct?: DataAwsLbListenerRule.QueryStringProperty | cdktn.IResolvable): any;
export declare function dataAwsLbListenerRuleSourceIpPropertyToTerraform(struct?: DataAwsLbListenerRule.SourceIpProperty | cdktn.IResolvable): any;
export declare function dataAwsLbListenerRuleSourceIpPropertyToHclTerraform(struct?: DataAwsLbListenerRule.SourceIpProperty | cdktn.IResolvable): any;
export declare function dataAwsLbListenerRuleConditionPropertyToTerraform(struct?: DataAwsLbListenerRule.ConditionProperty | cdktn.IResolvable): any;
export declare function dataAwsLbListenerRuleConditionPropertyToHclTerraform(struct?: DataAwsLbListenerRule.ConditionProperty | cdktn.IResolvable): any;
export declare function dataAwsLbListenerRuleTransformHostHeaderRewriteConfigRewritePropertyToTerraform(struct?: DataAwsLbListenerRule.TransformHostHeaderRewriteConfigRewriteProperty | cdktn.IResolvable): any;
export declare function dataAwsLbListenerRuleTransformHostHeaderRewriteConfigRewritePropertyToHclTerraform(struct?: DataAwsLbListenerRule.TransformHostHeaderRewriteConfigRewriteProperty | cdktn.IResolvable): any;
export declare function dataAwsLbListenerRuleHostHeaderRewriteConfigPropertyToTerraform(struct?: DataAwsLbListenerRule.HostHeaderRewriteConfigProperty | cdktn.IResolvable): any;
export declare function dataAwsLbListenerRuleHostHeaderRewriteConfigPropertyToHclTerraform(struct?: DataAwsLbListenerRule.HostHeaderRewriteConfigProperty | cdktn.IResolvable): any;
export declare function dataAwsLbListenerRuleTransformUrlRewriteConfigRewritePropertyToTerraform(struct?: DataAwsLbListenerRule.TransformUrlRewriteConfigRewriteProperty | cdktn.IResolvable): any;
export declare function dataAwsLbListenerRuleTransformUrlRewriteConfigRewritePropertyToHclTerraform(struct?: DataAwsLbListenerRule.TransformUrlRewriteConfigRewriteProperty | cdktn.IResolvable): any;
export declare function dataAwsLbListenerRuleUrlRewriteConfigPropertyToTerraform(struct?: DataAwsLbListenerRule.UrlRewriteConfigProperty | cdktn.IResolvable): any;
export declare function dataAwsLbListenerRuleUrlRewriteConfigPropertyToHclTerraform(struct?: DataAwsLbListenerRule.UrlRewriteConfigProperty | cdktn.IResolvable): any;
export declare function dataAwsLbListenerRuleTransformPropertyToTerraform(struct?: DataAwsLbListenerRule.TransformProperty | cdktn.IResolvable): any;
export declare function dataAwsLbListenerRuleTransformPropertyToHclTerraform(struct?: DataAwsLbListenerRule.TransformProperty | cdktn.IResolvable): any;
export declare namespace DataAwsLbListenerRule {
    interface AuthenticateCognitoProperty {
    }
    class AuthenticateCognitoPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AuthenticateCognitoProperty | cdktn.IResolvable | undefined;
        set internalValue(value: AuthenticateCognitoProperty | cdktn.IResolvable | undefined);
        private _authenticationRequestExtraParams;
        get authenticationRequestExtraParams(): cdktn.StringMap;
        get onUnauthenticatedRequest(): string;
        get scope(): string;
        get sessionCookieName(): string;
        get sessionTimeout(): number;
        get userPoolArn(): string;
        get userPoolClientId(): string;
        get userPoolDomain(): string;
    }
    class AuthenticateCognitoPropertyList extends cdktn.ComplexList {
        internalValue?: AuthenticateCognitoProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AuthenticateCognitoPropertyOutputReference;
    }
    interface AuthenticateOidcProperty {
    }
    class AuthenticateOidcPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AuthenticateOidcProperty | cdktn.IResolvable | undefined;
        set internalValue(value: AuthenticateOidcProperty | cdktn.IResolvable | undefined);
        private _authenticationRequestExtraParams;
        get authenticationRequestExtraParams(): cdktn.StringMap;
        get authorizationEndpoint(): string;
        get clientId(): string;
        get issuer(): string;
        get onUnauthenticatedRequest(): string;
        get scope(): string;
        get sessionCookieName(): string;
        get sessionTimeout(): number;
        get tokenEndpoint(): string;
        get userInfoEndpoint(): string;
    }
    class AuthenticateOidcPropertyList extends cdktn.ComplexList {
        internalValue?: AuthenticateOidcProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AuthenticateOidcPropertyOutputReference;
    }
    interface FixedResponseProperty {
    }
    class FixedResponsePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): FixedResponseProperty | cdktn.IResolvable | undefined;
        set internalValue(value: FixedResponseProperty | cdktn.IResolvable | undefined);
        get contentType(): string;
        get messageBody(): string;
        get statusCode(): string;
    }
    class FixedResponsePropertyList extends cdktn.ComplexList {
        internalValue?: FixedResponseProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): FixedResponsePropertyOutputReference;
    }
    interface StickinessProperty {
    }
    class StickinessPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): StickinessProperty | cdktn.IResolvable | undefined;
        set internalValue(value: StickinessProperty | cdktn.IResolvable | undefined);
        get duration(): number;
        get enabled(): cdktn.IResolvable;
    }
    class StickinessPropertyList extends cdktn.ComplexList {
        internalValue?: StickinessProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): StickinessPropertyOutputReference;
    }
    interface TargetGroupProperty {
    }
    class TargetGroupPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TargetGroupProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TargetGroupProperty | cdktn.IResolvable | undefined);
        get arn(): string;
        get weight(): number;
    }
    class TargetGroupPropertyList extends cdktn.ComplexList {
        internalValue?: TargetGroupProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TargetGroupPropertyOutputReference;
    }
    interface ForwardProperty {
        /**
        * stickiness block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lb_listener_rule#stickiness DataAwsLbListenerRule#stickiness}
        */
        readonly stickiness?: StickinessProperty[] | cdktn.IResolvable;
        /**
        * target_group block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lb_listener_rule#target_group DataAwsLbListenerRule#target_group}
        */
        readonly targetGroup?: TargetGroupProperty[] | cdktn.IResolvable;
    }
    class ForwardPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ForwardProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ForwardProperty | cdktn.IResolvable | undefined);
        private _stickiness;
        get stickiness(): StickinessPropertyList;
        putStickiness(value: StickinessProperty[] | cdktn.IResolvable): void;
        resetStickiness(): void;
        get stickinessInput(): cdktn.IResolvable | StickinessProperty[] | undefined;
        private _targetGroup;
        get targetGroup(): TargetGroupPropertyList;
        putTargetGroup(value: TargetGroupProperty[] | cdktn.IResolvable): void;
        resetTargetGroup(): void;
        get targetGroupInput(): cdktn.IResolvable | TargetGroupProperty[] | undefined;
    }
    class ForwardPropertyList extends cdktn.ComplexList {
        internalValue?: ForwardProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ForwardPropertyOutputReference;
    }
    interface AdditionalClaimProperty {
    }
    class AdditionalClaimPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AdditionalClaimProperty | cdktn.IResolvable | undefined;
        set internalValue(value: AdditionalClaimProperty | cdktn.IResolvable | undefined);
        get format(): string;
        get name(): string;
        get values(): string[];
    }
    class AdditionalClaimPropertyList extends cdktn.ComplexList {
        internalValue?: AdditionalClaimProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AdditionalClaimPropertyOutputReference;
    }
    interface JwtValidationProperty {
        /**
        * additional_claim block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lb_listener_rule#additional_claim DataAwsLbListenerRule#additional_claim}
        */
        readonly additionalClaim?: AdditionalClaimProperty[] | cdktn.IResolvable;
    }
    class JwtValidationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): JwtValidationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: JwtValidationProperty | cdktn.IResolvable | undefined);
        get issuer(): string;
        get jwksEndpoint(): string;
        private _additionalClaim;
        get additionalClaim(): AdditionalClaimPropertyList;
        putAdditionalClaim(value: AdditionalClaimProperty[] | cdktn.IResolvable): void;
        resetAdditionalClaim(): void;
        get additionalClaimInput(): cdktn.IResolvable | AdditionalClaimProperty[] | undefined;
    }
    class JwtValidationPropertyList extends cdktn.ComplexList {
        internalValue?: JwtValidationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): JwtValidationPropertyOutputReference;
    }
    interface RedirectProperty {
    }
    class RedirectPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RedirectProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RedirectProperty | cdktn.IResolvable | undefined);
        get host(): string;
        get path(): string;
        get port(): string;
        get protocol(): string;
        get query(): string;
        get statusCode(): string;
    }
    class RedirectPropertyList extends cdktn.ComplexList {
        internalValue?: RedirectProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RedirectPropertyOutputReference;
    }
    interface ActionProperty {
        /**
        * authenticate_cognito block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lb_listener_rule#authenticate_cognito DataAwsLbListenerRule#authenticate_cognito}
        */
        readonly authenticateCognito?: AuthenticateCognitoProperty[] | cdktn.IResolvable;
        /**
        * authenticate_oidc block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lb_listener_rule#authenticate_oidc DataAwsLbListenerRule#authenticate_oidc}
        */
        readonly authenticateOidc?: AuthenticateOidcProperty[] | cdktn.IResolvable;
        /**
        * fixed_response block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lb_listener_rule#fixed_response DataAwsLbListenerRule#fixed_response}
        */
        readonly fixedResponse?: FixedResponseProperty[] | cdktn.IResolvable;
        /**
        * forward block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lb_listener_rule#forward DataAwsLbListenerRule#forward}
        */
        readonly forward?: ForwardProperty[] | cdktn.IResolvable;
        /**
        * jwt_validation block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lb_listener_rule#jwt_validation DataAwsLbListenerRule#jwt_validation}
        */
        readonly jwtValidation?: JwtValidationProperty[] | cdktn.IResolvable;
        /**
        * redirect block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lb_listener_rule#redirect DataAwsLbListenerRule#redirect}
        */
        readonly redirect?: RedirectProperty[] | cdktn.IResolvable;
    }
    class ActionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ActionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ActionProperty | cdktn.IResolvable | undefined);
        get order(): number;
        get type(): string;
        private _authenticateCognito;
        get authenticateCognito(): AuthenticateCognitoPropertyList;
        putAuthenticateCognito(value: AuthenticateCognitoProperty[] | cdktn.IResolvable): void;
        resetAuthenticateCognito(): void;
        get authenticateCognitoInput(): cdktn.IResolvable | AuthenticateCognitoProperty[] | undefined;
        private _authenticateOidc;
        get authenticateOidc(): AuthenticateOidcPropertyList;
        putAuthenticateOidc(value: AuthenticateOidcProperty[] | cdktn.IResolvable): void;
        resetAuthenticateOidc(): void;
        get authenticateOidcInput(): cdktn.IResolvable | AuthenticateOidcProperty[] | undefined;
        private _fixedResponse;
        get fixedResponse(): FixedResponsePropertyList;
        putFixedResponse(value: FixedResponseProperty[] | cdktn.IResolvable): void;
        resetFixedResponse(): void;
        get fixedResponseInput(): cdktn.IResolvable | FixedResponseProperty[] | undefined;
        private _forward;
        get forward(): ForwardPropertyList;
        putForward(value: ForwardProperty[] | cdktn.IResolvable): void;
        resetForward(): void;
        get forwardInput(): cdktn.IResolvable | ForwardProperty[] | undefined;
        private _jwtValidation;
        get jwtValidation(): JwtValidationPropertyList;
        putJwtValidation(value: JwtValidationProperty[] | cdktn.IResolvable): void;
        resetJwtValidation(): void;
        get jwtValidationInput(): cdktn.IResolvable | JwtValidationProperty[] | undefined;
        private _redirect;
        get redirect(): RedirectPropertyList;
        putRedirect(value: RedirectProperty[] | cdktn.IResolvable): void;
        resetRedirect(): void;
        get redirectInput(): cdktn.IResolvable | RedirectProperty[] | undefined;
    }
    class ActionPropertyList extends cdktn.ComplexList {
        internalValue?: ActionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ActionPropertyOutputReference;
    }
    interface HostHeaderProperty {
    }
    class HostHeaderPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): HostHeaderProperty | cdktn.IResolvable | undefined;
        set internalValue(value: HostHeaderProperty | cdktn.IResolvable | undefined);
        get regexValues(): string[];
        get values(): string[];
    }
    class HostHeaderPropertyList extends cdktn.ComplexList {
        internalValue?: HostHeaderProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): HostHeaderPropertyOutputReference;
    }
    interface HttpHeaderProperty {
    }
    class HttpHeaderPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): HttpHeaderProperty | cdktn.IResolvable | undefined;
        set internalValue(value: HttpHeaderProperty | cdktn.IResolvable | undefined);
        get httpHeaderName(): string;
        get regexValues(): string[];
        get values(): string[];
    }
    class HttpHeaderPropertyList extends cdktn.ComplexList {
        internalValue?: HttpHeaderProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): HttpHeaderPropertyOutputReference;
    }
    interface HttpRequestMethodProperty {
    }
    class HttpRequestMethodPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): HttpRequestMethodProperty | cdktn.IResolvable | undefined;
        set internalValue(value: HttpRequestMethodProperty | cdktn.IResolvable | undefined);
        get values(): string[];
    }
    class HttpRequestMethodPropertyList extends cdktn.ComplexList {
        internalValue?: HttpRequestMethodProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): HttpRequestMethodPropertyOutputReference;
    }
    interface PathPatternProperty {
    }
    class PathPatternPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): PathPatternProperty | cdktn.IResolvable | undefined;
        set internalValue(value: PathPatternProperty | cdktn.IResolvable | undefined);
        get regexValues(): string[];
        get values(): string[];
    }
    class PathPatternPropertyList extends cdktn.ComplexList {
        internalValue?: PathPatternProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): PathPatternPropertyOutputReference;
    }
    interface ValuesProperty {
    }
    class ValuesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ValuesProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ValuesProperty | cdktn.IResolvable | undefined);
        get key(): string;
        get value(): string;
    }
    class ValuesPropertyList extends cdktn.ComplexList {
        internalValue?: ValuesProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ValuesPropertyOutputReference;
    }
    interface QueryStringProperty {
        /**
        * values block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lb_listener_rule#values DataAwsLbListenerRule#values}
        */
        readonly values?: ValuesProperty[] | cdktn.IResolvable;
    }
    class QueryStringPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): QueryStringProperty | cdktn.IResolvable | undefined;
        set internalValue(value: QueryStringProperty | cdktn.IResolvable | undefined);
        private _values;
        get values(): ValuesPropertyList;
        putValues(value: ValuesProperty[] | cdktn.IResolvable): void;
        resetValues(): void;
        get valuesInput(): cdktn.IResolvable | ValuesProperty[] | undefined;
    }
    class QueryStringPropertyList extends cdktn.ComplexList {
        internalValue?: QueryStringProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): QueryStringPropertyOutputReference;
    }
    interface SourceIpProperty {
    }
    class SourceIpPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SourceIpProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SourceIpProperty | cdktn.IResolvable | undefined);
        get ipAddressType(): string;
        get values(): string[];
    }
    class SourceIpPropertyList extends cdktn.ComplexList {
        internalValue?: SourceIpProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SourceIpPropertyOutputReference;
    }
    interface ConditionProperty {
        /**
        * host_header block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lb_listener_rule#host_header DataAwsLbListenerRule#host_header}
        */
        readonly hostHeader?: HostHeaderProperty[] | cdktn.IResolvable;
        /**
        * http_header block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lb_listener_rule#http_header DataAwsLbListenerRule#http_header}
        */
        readonly httpHeader?: HttpHeaderProperty[] | cdktn.IResolvable;
        /**
        * http_request_method block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lb_listener_rule#http_request_method DataAwsLbListenerRule#http_request_method}
        */
        readonly httpRequestMethod?: HttpRequestMethodProperty[] | cdktn.IResolvable;
        /**
        * path_pattern block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lb_listener_rule#path_pattern DataAwsLbListenerRule#path_pattern}
        */
        readonly pathPattern?: PathPatternProperty[] | cdktn.IResolvable;
        /**
        * query_string block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lb_listener_rule#query_string DataAwsLbListenerRule#query_string}
        */
        readonly queryString?: QueryStringProperty[] | cdktn.IResolvable;
        /**
        * source_ip block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lb_listener_rule#source_ip DataAwsLbListenerRule#source_ip}
        */
        readonly sourceIp?: SourceIpProperty[] | cdktn.IResolvable;
    }
    class ConditionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ConditionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ConditionProperty | cdktn.IResolvable | undefined);
        private _hostHeader;
        get hostHeader(): HostHeaderPropertyList;
        putHostHeader(value: HostHeaderProperty[] | cdktn.IResolvable): void;
        resetHostHeader(): void;
        get hostHeaderInput(): cdktn.IResolvable | HostHeaderProperty[] | undefined;
        private _httpHeader;
        get httpHeader(): HttpHeaderPropertyList;
        putHttpHeader(value: HttpHeaderProperty[] | cdktn.IResolvable): void;
        resetHttpHeader(): void;
        get httpHeaderInput(): cdktn.IResolvable | HttpHeaderProperty[] | undefined;
        private _httpRequestMethod;
        get httpRequestMethod(): HttpRequestMethodPropertyList;
        putHttpRequestMethod(value: HttpRequestMethodProperty[] | cdktn.IResolvable): void;
        resetHttpRequestMethod(): void;
        get httpRequestMethodInput(): cdktn.IResolvable | HttpRequestMethodProperty[] | undefined;
        private _pathPattern;
        get pathPattern(): PathPatternPropertyList;
        putPathPattern(value: PathPatternProperty[] | cdktn.IResolvable): void;
        resetPathPattern(): void;
        get pathPatternInput(): cdktn.IResolvable | PathPatternProperty[] | undefined;
        private _queryString;
        get queryString(): QueryStringPropertyList;
        putQueryString(value: QueryStringProperty[] | cdktn.IResolvable): void;
        resetQueryString(): void;
        get queryStringInput(): cdktn.IResolvable | QueryStringProperty[] | undefined;
        private _sourceIp;
        get sourceIp(): SourceIpPropertyList;
        putSourceIp(value: SourceIpProperty[] | cdktn.IResolvable): void;
        resetSourceIp(): void;
        get sourceIpInput(): cdktn.IResolvable | SourceIpProperty[] | undefined;
    }
    class ConditionPropertyList extends cdktn.ComplexList {
        internalValue?: ConditionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ConditionPropertyOutputReference;
    }
    interface TransformHostHeaderRewriteConfigRewriteProperty {
    }
    class TransformHostHeaderRewriteConfigRewritePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TransformHostHeaderRewriteConfigRewriteProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TransformHostHeaderRewriteConfigRewriteProperty | cdktn.IResolvable | undefined);
        get regex(): string;
        get replace(): string;
    }
    class TransformHostHeaderRewriteConfigRewritePropertyList extends cdktn.ComplexList {
        internalValue?: TransformHostHeaderRewriteConfigRewriteProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TransformHostHeaderRewriteConfigRewritePropertyOutputReference;
    }
    interface HostHeaderRewriteConfigProperty {
        /**
        * rewrite block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lb_listener_rule#rewrite DataAwsLbListenerRule#rewrite}
        */
        readonly rewrite?: TransformHostHeaderRewriteConfigRewriteProperty[] | cdktn.IResolvable;
    }
    class HostHeaderRewriteConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): HostHeaderRewriteConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: HostHeaderRewriteConfigProperty | cdktn.IResolvable | undefined);
        private _rewrite;
        get rewrite(): TransformHostHeaderRewriteConfigRewritePropertyList;
        putRewrite(value: TransformHostHeaderRewriteConfigRewriteProperty[] | cdktn.IResolvable): void;
        resetRewrite(): void;
        get rewriteInput(): cdktn.IResolvable | TransformHostHeaderRewriteConfigRewriteProperty[] | undefined;
    }
    class HostHeaderRewriteConfigPropertyList extends cdktn.ComplexList {
        internalValue?: HostHeaderRewriteConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): HostHeaderRewriteConfigPropertyOutputReference;
    }
    interface TransformUrlRewriteConfigRewriteProperty {
    }
    class TransformUrlRewriteConfigRewritePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TransformUrlRewriteConfigRewriteProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TransformUrlRewriteConfigRewriteProperty | cdktn.IResolvable | undefined);
        get regex(): string;
        get replace(): string;
    }
    class TransformUrlRewriteConfigRewritePropertyList extends cdktn.ComplexList {
        internalValue?: TransformUrlRewriteConfigRewriteProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TransformUrlRewriteConfigRewritePropertyOutputReference;
    }
    interface UrlRewriteConfigProperty {
        /**
        * rewrite block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lb_listener_rule#rewrite DataAwsLbListenerRule#rewrite}
        */
        readonly rewrite?: TransformUrlRewriteConfigRewriteProperty[] | cdktn.IResolvable;
    }
    class UrlRewriteConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): UrlRewriteConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: UrlRewriteConfigProperty | cdktn.IResolvable | undefined);
        private _rewrite;
        get rewrite(): TransformUrlRewriteConfigRewritePropertyList;
        putRewrite(value: TransformUrlRewriteConfigRewriteProperty[] | cdktn.IResolvable): void;
        resetRewrite(): void;
        get rewriteInput(): cdktn.IResolvable | TransformUrlRewriteConfigRewriteProperty[] | undefined;
    }
    class UrlRewriteConfigPropertyList extends cdktn.ComplexList {
        internalValue?: UrlRewriteConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): UrlRewriteConfigPropertyOutputReference;
    }
    interface TransformProperty {
        /**
        * host_header_rewrite_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lb_listener_rule#host_header_rewrite_config DataAwsLbListenerRule#host_header_rewrite_config}
        */
        readonly hostHeaderRewriteConfig?: HostHeaderRewriteConfigProperty[] | cdktn.IResolvable;
        /**
        * url_rewrite_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lb_listener_rule#url_rewrite_config DataAwsLbListenerRule#url_rewrite_config}
        */
        readonly urlRewriteConfig?: UrlRewriteConfigProperty[] | cdktn.IResolvable;
    }
    class TransformPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TransformProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TransformProperty | cdktn.IResolvable | undefined);
        get type(): string;
        private _hostHeaderRewriteConfig;
        get hostHeaderRewriteConfig(): HostHeaderRewriteConfigPropertyList;
        putHostHeaderRewriteConfig(value: HostHeaderRewriteConfigProperty[] | cdktn.IResolvable): void;
        resetHostHeaderRewriteConfig(): void;
        get hostHeaderRewriteConfigInput(): cdktn.IResolvable | HostHeaderRewriteConfigProperty[] | undefined;
        private _urlRewriteConfig;
        get urlRewriteConfig(): UrlRewriteConfigPropertyList;
        putUrlRewriteConfig(value: UrlRewriteConfigProperty[] | cdktn.IResolvable): void;
        resetUrlRewriteConfig(): void;
        get urlRewriteConfigInput(): cdktn.IResolvable | UrlRewriteConfigProperty[] | undefined;
    }
    class TransformPropertyList extends cdktn.ComplexList {
        internalValue?: TransformProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TransformPropertyOutputReference;
    }
}
