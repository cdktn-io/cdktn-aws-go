import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsLbTargetGroupConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_target_group#connection_termination AwsLbTargetGroup#connection_termination}
    */
    readonly connectionTermination?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_target_group#deregistration_delay AwsLbTargetGroup#deregistration_delay}
    */
    readonly deregistrationDelay?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_target_group#id AwsLbTargetGroup#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_target_group#ip_address_type AwsLbTargetGroup#ip_address_type}
    */
    readonly ipAddressType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_target_group#lambda_multi_value_headers_enabled AwsLbTargetGroup#lambda_multi_value_headers_enabled}
    */
    readonly lambdaMultiValueHeadersEnabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_target_group#load_balancing_algorithm_type AwsLbTargetGroup#load_balancing_algorithm_type}
    */
    readonly loadBalancingAlgorithmType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_target_group#load_balancing_anomaly_mitigation AwsLbTargetGroup#load_balancing_anomaly_mitigation}
    */
    readonly loadBalancingAnomalyMitigation?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_target_group#load_balancing_cross_zone_enabled AwsLbTargetGroup#load_balancing_cross_zone_enabled}
    */
    readonly loadBalancingCrossZoneEnabled?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_target_group#name AwsLbTargetGroup#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_target_group#name_prefix AwsLbTargetGroup#name_prefix}
    */
    readonly namePrefix?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_target_group#port AwsLbTargetGroup#port}
    */
    readonly port?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_target_group#preserve_client_ip AwsLbTargetGroup#preserve_client_ip}
    */
    readonly preserveClientIp?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_target_group#protocol AwsLbTargetGroup#protocol}
    */
    readonly protocol?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_target_group#protocol_version AwsLbTargetGroup#protocol_version}
    */
    readonly protocolVersion?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_target_group#proxy_protocol_v2 AwsLbTargetGroup#proxy_protocol_v2}
    */
    readonly proxyProtocolV2?: boolean | cdktn.IResolvable;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_target_group#region AwsLbTargetGroup#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_target_group#slow_start AwsLbTargetGroup#slow_start}
    */
    readonly slowStart?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_target_group#tags AwsLbTargetGroup#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_target_group#tags_all AwsLbTargetGroup#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_target_group#target_control_port AwsLbTargetGroup#target_control_port}
    */
    readonly targetControlPort?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_target_group#target_type AwsLbTargetGroup#target_type}
    */
    readonly targetType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_target_group#vpc_id AwsLbTargetGroup#vpc_id}
    */
    readonly vpcId?: string;
    /**
    * health_check block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_target_group#health_check AwsLbTargetGroup#health_check}
    */
    readonly healthCheck?: AwsLbTargetGroup.HealthCheckProperty;
    /**
    * stickiness block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_target_group#stickiness AwsLbTargetGroup#stickiness}
    */
    readonly stickiness?: AwsLbTargetGroup.StickinessProperty;
    /**
    * target_failover block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_target_group#target_failover AwsLbTargetGroup#target_failover}
    */
    readonly targetFailover?: AwsLbTargetGroup.TargetFailoverProperty[] | cdktn.IResolvable;
    /**
    * target_group_health block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_target_group#target_group_health AwsLbTargetGroup#target_group_health}
    */
    readonly targetGroupHealth?: AwsLbTargetGroup.TargetGroupHealthProperty;
    /**
    * target_health_state block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_target_group#target_health_state AwsLbTargetGroup#target_health_state}
    */
    readonly targetHealthState?: AwsLbTargetGroup.TargetHealthStateProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_target_group aws_lb_target_group}
*/
export declare class AwsLbTargetGroup extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_lb_target_group";
    /**
    * Generates CDKTN code for importing a AwsLbTargetGroup resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsLbTargetGroup to import
    * @param importFromId The id of the existing AwsLbTargetGroup that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_target_group#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsLbTargetGroup to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_target_group aws_lb_target_group} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsLbTargetGroupConfig = {}
    */
    constructor(scope: Construct, id: string, config?: AwsLbTargetGroupConfig);
    get arn(): string;
    get arnSuffix(): string;
    private _connectionTermination?;
    get connectionTermination(): boolean | cdktn.IResolvable;
    set connectionTermination(value: boolean | cdktn.IResolvable);
    resetConnectionTermination(): void;
    get connectionTerminationInput(): boolean | cdktn.IResolvable | undefined;
    private _deregistrationDelay?;
    get deregistrationDelay(): string;
    set deregistrationDelay(value: string);
    resetDeregistrationDelay(): void;
    get deregistrationDelayInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _ipAddressType?;
    get ipAddressType(): string;
    set ipAddressType(value: string);
    resetIpAddressType(): void;
    get ipAddressTypeInput(): string | undefined;
    private _lambdaMultiValueHeadersEnabled?;
    get lambdaMultiValueHeadersEnabled(): boolean | cdktn.IResolvable;
    set lambdaMultiValueHeadersEnabled(value: boolean | cdktn.IResolvable);
    resetLambdaMultiValueHeadersEnabled(): void;
    get lambdaMultiValueHeadersEnabledInput(): boolean | cdktn.IResolvable | undefined;
    get loadBalancerArns(): string[];
    private _loadBalancingAlgorithmType?;
    get loadBalancingAlgorithmType(): string;
    set loadBalancingAlgorithmType(value: string);
    resetLoadBalancingAlgorithmType(): void;
    get loadBalancingAlgorithmTypeInput(): string | undefined;
    private _loadBalancingAnomalyMitigation?;
    get loadBalancingAnomalyMitigation(): string;
    set loadBalancingAnomalyMitigation(value: string);
    resetLoadBalancingAnomalyMitigation(): void;
    get loadBalancingAnomalyMitigationInput(): string | undefined;
    private _loadBalancingCrossZoneEnabled?;
    get loadBalancingCrossZoneEnabled(): string;
    set loadBalancingCrossZoneEnabled(value: string);
    resetLoadBalancingCrossZoneEnabled(): void;
    get loadBalancingCrossZoneEnabledInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _namePrefix?;
    get namePrefix(): string;
    set namePrefix(value: string);
    resetNamePrefix(): void;
    get namePrefixInput(): string | undefined;
    private _port?;
    get port(): number;
    set port(value: number);
    resetPort(): void;
    get portInput(): number | undefined;
    private _preserveClientIp?;
    get preserveClientIp(): string;
    set preserveClientIp(value: string);
    resetPreserveClientIp(): void;
    get preserveClientIpInput(): string | undefined;
    private _protocol?;
    get protocol(): string;
    set protocol(value: string);
    resetProtocol(): void;
    get protocolInput(): string | undefined;
    private _protocolVersion?;
    get protocolVersion(): string;
    set protocolVersion(value: string);
    resetProtocolVersion(): void;
    get protocolVersionInput(): string | undefined;
    private _proxyProtocolV2?;
    get proxyProtocolV2(): boolean | cdktn.IResolvable;
    set proxyProtocolV2(value: boolean | cdktn.IResolvable);
    resetProxyProtocolV2(): void;
    get proxyProtocolV2Input(): boolean | cdktn.IResolvable | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _slowStart?;
    get slowStart(): number;
    set slowStart(value: number);
    resetSlowStart(): void;
    get slowStartInput(): number | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _targetControlPort?;
    get targetControlPort(): number;
    set targetControlPort(value: number);
    resetTargetControlPort(): void;
    get targetControlPortInput(): number | undefined;
    private _targetType?;
    get targetType(): string;
    set targetType(value: string);
    resetTargetType(): void;
    get targetTypeInput(): string | undefined;
    private _vpcId?;
    get vpcId(): string;
    set vpcId(value: string);
    resetVpcId(): void;
    get vpcIdInput(): string | undefined;
    private _healthCheck;
    get healthCheck(): AwsLbTargetGroup.HealthCheckPropertyOutputReference;
    putHealthCheck(value: AwsLbTargetGroup.HealthCheckProperty): void;
    resetHealthCheck(): void;
    get healthCheckInput(): AwsLbTargetGroup.HealthCheckProperty | undefined;
    private _stickiness;
    get stickiness(): AwsLbTargetGroup.StickinessPropertyOutputReference;
    putStickiness(value: AwsLbTargetGroup.StickinessProperty): void;
    resetStickiness(): void;
    get stickinessInput(): AwsLbTargetGroup.StickinessProperty | undefined;
    private _targetFailover;
    get targetFailover(): AwsLbTargetGroup.TargetFailoverPropertyList;
    putTargetFailover(value: AwsLbTargetGroup.TargetFailoverProperty[] | cdktn.IResolvable): void;
    resetTargetFailover(): void;
    get targetFailoverInput(): cdktn.IResolvable | AwsLbTargetGroup.TargetFailoverProperty[] | undefined;
    private _targetGroupHealth;
    get targetGroupHealth(): AwsLbTargetGroup.TargetGroupHealthPropertyOutputReference;
    putTargetGroupHealth(value: AwsLbTargetGroup.TargetGroupHealthProperty): void;
    resetTargetGroupHealth(): void;
    get targetGroupHealthInput(): AwsLbTargetGroup.TargetGroupHealthProperty | undefined;
    private _targetHealthState;
    get targetHealthState(): AwsLbTargetGroup.TargetHealthStatePropertyList;
    putTargetHealthState(value: AwsLbTargetGroup.TargetHealthStateProperty[] | cdktn.IResolvable): void;
    resetTargetHealthState(): void;
    get targetHealthStateInput(): cdktn.IResolvable | AwsLbTargetGroup.TargetHealthStateProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsLbTargetGroupHealthCheckPropertyToTerraform(struct?: AwsLbTargetGroup.HealthCheckPropertyOutputReference | AwsLbTargetGroup.HealthCheckProperty): any;
export declare function awsLbTargetGroupHealthCheckPropertyToHclTerraform(struct?: AwsLbTargetGroup.HealthCheckPropertyOutputReference | AwsLbTargetGroup.HealthCheckProperty): any;
export declare function awsLbTargetGroupStickinessPropertyToTerraform(struct?: AwsLbTargetGroup.StickinessPropertyOutputReference | AwsLbTargetGroup.StickinessProperty): any;
export declare function awsLbTargetGroupStickinessPropertyToHclTerraform(struct?: AwsLbTargetGroup.StickinessPropertyOutputReference | AwsLbTargetGroup.StickinessProperty): any;
export declare function awsLbTargetGroupTargetFailoverPropertyToTerraform(struct?: AwsLbTargetGroup.TargetFailoverProperty | cdktn.IResolvable): any;
export declare function awsLbTargetGroupTargetFailoverPropertyToHclTerraform(struct?: AwsLbTargetGroup.TargetFailoverProperty | cdktn.IResolvable): any;
export declare function awsLbTargetGroupDnsFailoverPropertyToTerraform(struct?: AwsLbTargetGroup.DnsFailoverPropertyOutputReference | AwsLbTargetGroup.DnsFailoverProperty): any;
export declare function awsLbTargetGroupDnsFailoverPropertyToHclTerraform(struct?: AwsLbTargetGroup.DnsFailoverPropertyOutputReference | AwsLbTargetGroup.DnsFailoverProperty): any;
export declare function awsLbTargetGroupUnhealthyStateRoutingPropertyToTerraform(struct?: AwsLbTargetGroup.UnhealthyStateRoutingPropertyOutputReference | AwsLbTargetGroup.UnhealthyStateRoutingProperty): any;
export declare function awsLbTargetGroupUnhealthyStateRoutingPropertyToHclTerraform(struct?: AwsLbTargetGroup.UnhealthyStateRoutingPropertyOutputReference | AwsLbTargetGroup.UnhealthyStateRoutingProperty): any;
export declare function awsLbTargetGroupTargetGroupHealthPropertyToTerraform(struct?: AwsLbTargetGroup.TargetGroupHealthPropertyOutputReference | AwsLbTargetGroup.TargetGroupHealthProperty): any;
export declare function awsLbTargetGroupTargetGroupHealthPropertyToHclTerraform(struct?: AwsLbTargetGroup.TargetGroupHealthPropertyOutputReference | AwsLbTargetGroup.TargetGroupHealthProperty): any;
export declare function awsLbTargetGroupTargetHealthStatePropertyToTerraform(struct?: AwsLbTargetGroup.TargetHealthStateProperty | cdktn.IResolvable): any;
export declare function awsLbTargetGroupTargetHealthStatePropertyToHclTerraform(struct?: AwsLbTargetGroup.TargetHealthStateProperty | cdktn.IResolvable): any;
export declare namespace AwsLbTargetGroup {
    interface HealthCheckProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_target_group#enabled AwsLbTargetGroup#enabled}
        */
        readonly enabled?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_target_group#healthy_threshold AwsLbTargetGroup#healthy_threshold}
        */
        readonly healthyThreshold?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_target_group#interval AwsLbTargetGroup#interval}
        */
        readonly interval?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_target_group#matcher AwsLbTargetGroup#matcher}
        */
        readonly matcher?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_target_group#path AwsLbTargetGroup#path}
        */
        readonly path?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_target_group#port AwsLbTargetGroup#port}
        */
        readonly port?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_target_group#protocol AwsLbTargetGroup#protocol}
        */
        readonly protocol?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_target_group#timeout AwsLbTargetGroup#timeout}
        */
        readonly timeout?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_target_group#unhealthy_threshold AwsLbTargetGroup#unhealthy_threshold}
        */
        readonly unhealthyThreshold?: number;
    }
    class HealthCheckPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): HealthCheckProperty | undefined;
        set internalValue(value: HealthCheckProperty | undefined);
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        resetEnabled(): void;
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
        private _healthyThreshold?;
        get healthyThreshold(): number;
        set healthyThreshold(value: number);
        resetHealthyThreshold(): void;
        get healthyThresholdInput(): number | undefined;
        private _interval?;
        get interval(): number;
        set interval(value: number);
        resetInterval(): void;
        get intervalInput(): number | undefined;
        private _matcher?;
        get matcher(): string;
        set matcher(value: string);
        resetMatcher(): void;
        get matcherInput(): string | undefined;
        private _path?;
        get path(): string;
        set path(value: string);
        resetPath(): void;
        get pathInput(): string | undefined;
        private _port?;
        get port(): string;
        set port(value: string);
        resetPort(): void;
        get portInput(): string | undefined;
        private _protocol?;
        get protocol(): string;
        set protocol(value: string);
        resetProtocol(): void;
        get protocolInput(): string | undefined;
        private _timeout?;
        get timeout(): number;
        set timeout(value: number);
        resetTimeout(): void;
        get timeoutInput(): number | undefined;
        private _unhealthyThreshold?;
        get unhealthyThreshold(): number;
        set unhealthyThreshold(value: number);
        resetUnhealthyThreshold(): void;
        get unhealthyThresholdInput(): number | undefined;
    }
    interface StickinessProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_target_group#cookie_duration AwsLbTargetGroup#cookie_duration}
        */
        readonly cookieDuration?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_target_group#cookie_name AwsLbTargetGroup#cookie_name}
        */
        readonly cookieName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_target_group#enabled AwsLbTargetGroup#enabled}
        */
        readonly enabled?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_target_group#type AwsLbTargetGroup#type}
        */
        readonly type: string;
    }
    class StickinessPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): StickinessProperty | undefined;
        set internalValue(value: StickinessProperty | undefined);
        private _cookieDuration?;
        get cookieDuration(): number;
        set cookieDuration(value: number);
        resetCookieDuration(): void;
        get cookieDurationInput(): number | undefined;
        private _cookieName?;
        get cookieName(): string;
        set cookieName(value: string);
        resetCookieName(): void;
        get cookieNameInput(): string | undefined;
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        resetEnabled(): void;
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
    }
    interface TargetFailoverProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_target_group#on_deregistration AwsLbTargetGroup#on_deregistration}
        */
        readonly onDeregistration: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_target_group#on_unhealthy AwsLbTargetGroup#on_unhealthy}
        */
        readonly onUnhealthy: string;
    }
    class TargetFailoverPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TargetFailoverProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TargetFailoverProperty | cdktn.IResolvable | undefined);
        private _onDeregistration?;
        get onDeregistration(): string;
        set onDeregistration(value: string);
        get onDeregistrationInput(): string | undefined;
        private _onUnhealthy?;
        get onUnhealthy(): string;
        set onUnhealthy(value: string);
        get onUnhealthyInput(): string | undefined;
    }
    class TargetFailoverPropertyList extends cdktn.ComplexList {
        internalValue?: TargetFailoverProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TargetFailoverPropertyOutputReference;
    }
    interface DnsFailoverProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_target_group#minimum_healthy_targets_count AwsLbTargetGroup#minimum_healthy_targets_count}
        */
        readonly minimumHealthyTargetsCount?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_target_group#minimum_healthy_targets_percentage AwsLbTargetGroup#minimum_healthy_targets_percentage}
        */
        readonly minimumHealthyTargetsPercentage?: string;
    }
    class DnsFailoverPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DnsFailoverProperty | undefined;
        set internalValue(value: DnsFailoverProperty | undefined);
        private _minimumHealthyTargetsCount?;
        get minimumHealthyTargetsCount(): string;
        set minimumHealthyTargetsCount(value: string);
        resetMinimumHealthyTargetsCount(): void;
        get minimumHealthyTargetsCountInput(): string | undefined;
        private _minimumHealthyTargetsPercentage?;
        get minimumHealthyTargetsPercentage(): string;
        set minimumHealthyTargetsPercentage(value: string);
        resetMinimumHealthyTargetsPercentage(): void;
        get minimumHealthyTargetsPercentageInput(): string | undefined;
    }
    interface UnhealthyStateRoutingProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_target_group#minimum_healthy_targets_count AwsLbTargetGroup#minimum_healthy_targets_count}
        */
        readonly minimumHealthyTargetsCount?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_target_group#minimum_healthy_targets_percentage AwsLbTargetGroup#minimum_healthy_targets_percentage}
        */
        readonly minimumHealthyTargetsPercentage?: string;
    }
    class UnhealthyStateRoutingPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): UnhealthyStateRoutingProperty | undefined;
        set internalValue(value: UnhealthyStateRoutingProperty | undefined);
        private _minimumHealthyTargetsCount?;
        get minimumHealthyTargetsCount(): number;
        set minimumHealthyTargetsCount(value: number);
        resetMinimumHealthyTargetsCount(): void;
        get minimumHealthyTargetsCountInput(): number | undefined;
        private _minimumHealthyTargetsPercentage?;
        get minimumHealthyTargetsPercentage(): string;
        set minimumHealthyTargetsPercentage(value: string);
        resetMinimumHealthyTargetsPercentage(): void;
        get minimumHealthyTargetsPercentageInput(): string | undefined;
    }
    interface TargetGroupHealthProperty {
        /**
        * dns_failover block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_target_group#dns_failover AwsLbTargetGroup#dns_failover}
        */
        readonly dnsFailover?: DnsFailoverProperty;
        /**
        * unhealthy_state_routing block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_target_group#unhealthy_state_routing AwsLbTargetGroup#unhealthy_state_routing}
        */
        readonly unhealthyStateRouting?: UnhealthyStateRoutingProperty;
    }
    class TargetGroupHealthPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TargetGroupHealthProperty | undefined;
        set internalValue(value: TargetGroupHealthProperty | undefined);
        private _dnsFailover;
        get dnsFailover(): DnsFailoverPropertyOutputReference;
        putDnsFailover(value: DnsFailoverProperty): void;
        resetDnsFailover(): void;
        get dnsFailoverInput(): DnsFailoverProperty | undefined;
        private _unhealthyStateRouting;
        get unhealthyStateRouting(): UnhealthyStateRoutingPropertyOutputReference;
        putUnhealthyStateRouting(value: UnhealthyStateRoutingProperty): void;
        resetUnhealthyStateRouting(): void;
        get unhealthyStateRoutingInput(): UnhealthyStateRoutingProperty | undefined;
    }
    interface TargetHealthStateProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_target_group#enable_unhealthy_connection_termination AwsLbTargetGroup#enable_unhealthy_connection_termination}
        */
        readonly enableUnhealthyConnectionTermination: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_target_group#unhealthy_draining_interval AwsLbTargetGroup#unhealthy_draining_interval}
        */
        readonly unhealthyDrainingInterval?: number;
    }
    class TargetHealthStatePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TargetHealthStateProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TargetHealthStateProperty | cdktn.IResolvable | undefined);
        private _enableUnhealthyConnectionTermination?;
        get enableUnhealthyConnectionTermination(): boolean | cdktn.IResolvable;
        set enableUnhealthyConnectionTermination(value: boolean | cdktn.IResolvable);
        get enableUnhealthyConnectionTerminationInput(): boolean | cdktn.IResolvable | undefined;
        private _unhealthyDrainingInterval?;
        get unhealthyDrainingInterval(): number;
        set unhealthyDrainingInterval(value: number);
        resetUnhealthyDrainingInterval(): void;
        get unhealthyDrainingIntervalInput(): number | undefined;
    }
    class TargetHealthStatePropertyList extends cdktn.ComplexList {
        internalValue?: TargetHealthStateProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TargetHealthStatePropertyOutputReference;
    }
}
