import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsLbTrustStoreRevocationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_trust_store_revocation#id AwsLbTrustStoreRevocation#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_trust_store_revocation#region AwsLbTrustStoreRevocation#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_trust_store_revocation#revocations_s3_bucket AwsLbTrustStoreRevocation#revocations_s3_bucket}
    */
    readonly revocationsS3Bucket: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_trust_store_revocation#revocations_s3_key AwsLbTrustStoreRevocation#revocations_s3_key}
    */
    readonly revocationsS3Key: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_trust_store_revocation#revocations_s3_object_version AwsLbTrustStoreRevocation#revocations_s3_object_version}
    */
    readonly revocationsS3ObjectVersion?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_trust_store_revocation#trust_store_arn AwsLbTrustStoreRevocation#trust_store_arn}
    */
    readonly trustStoreArn: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_trust_store_revocation#timeouts AwsLbTrustStoreRevocation#timeouts}
    */
    readonly timeouts?: AwsLbTrustStoreRevocation.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_trust_store_revocation aws_lb_trust_store_revocation}
*/
export declare class AwsLbTrustStoreRevocation extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_lb_trust_store_revocation";
    /**
    * Generates CDKTN code for importing a AwsLbTrustStoreRevocation resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsLbTrustStoreRevocation to import
    * @param importFromId The id of the existing AwsLbTrustStoreRevocation that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_trust_store_revocation#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsLbTrustStoreRevocation to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_trust_store_revocation aws_lb_trust_store_revocation} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsLbTrustStoreRevocationConfig
    */
    constructor(scope: Construct, id: string, config: AwsLbTrustStoreRevocationConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get revocationId(): number;
    private _revocationsS3Bucket?;
    get revocationsS3Bucket(): string;
    set revocationsS3Bucket(value: string);
    get revocationsS3BucketInput(): string | undefined;
    private _revocationsS3Key?;
    get revocationsS3Key(): string;
    set revocationsS3Key(value: string);
    get revocationsS3KeyInput(): string | undefined;
    private _revocationsS3ObjectVersion?;
    get revocationsS3ObjectVersion(): string;
    set revocationsS3ObjectVersion(value: string);
    resetRevocationsS3ObjectVersion(): void;
    get revocationsS3ObjectVersionInput(): string | undefined;
    private _trustStoreArn?;
    get trustStoreArn(): string;
    set trustStoreArn(value: string);
    get trustStoreArnInput(): string | undefined;
    private _timeouts;
    get timeouts(): AwsLbTrustStoreRevocation.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsLbTrustStoreRevocation.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsLbTrustStoreRevocation.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsLbTrustStoreRevocationTimeoutsPropertyToTerraform(struct?: AwsLbTrustStoreRevocation.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsLbTrustStoreRevocationTimeoutsPropertyToHclTerraform(struct?: AwsLbTrustStoreRevocation.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsLbTrustStoreRevocation {
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_trust_store_revocation#create AwsLbTrustStoreRevocation#create}
        */
        readonly create?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
    }
}
