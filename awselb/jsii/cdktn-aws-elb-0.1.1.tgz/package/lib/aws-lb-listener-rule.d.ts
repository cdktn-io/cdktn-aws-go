import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsLbListenerRuleConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_listener_rule#id AwsLbListenerRule#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_listener_rule#listener_arn AwsLbListenerRule#listener_arn}
    */
    readonly listenerArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_listener_rule#priority AwsLbListenerRule#priority}
    */
    readonly priority?: number;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_listener_rule#region AwsLbListenerRule#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_listener_rule#tags AwsLbListenerRule#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_listener_rule#tags_all AwsLbListenerRule#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * action block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_listener_rule#action AwsLbListenerRule#action}
    */
    readonly action: AwsLbListenerRule.ActionProperty[] | cdktn.IResolvable;
    /**
    * condition block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_listener_rule#condition AwsLbListenerRule#condition}
    */
    readonly condition: AwsLbListenerRule.ConditionProperty[] | cdktn.IResolvable;
    /**
    * transform block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_listener_rule#transform AwsLbListenerRule#transform}
    */
    readonly transform?: AwsLbListenerRule.TransformProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_listener_rule aws_lb_listener_rule}
*/
export declare class AwsLbListenerRule extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_lb_listener_rule";
    /**
    * Generates CDKTN code for importing a AwsLbListenerRule resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsLbListenerRule to import
    * @param importFromId The id of the existing AwsLbListenerRule that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_listener_rule#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsLbListenerRule to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_listener_rule aws_lb_listener_rule} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsLbListenerRuleConfig
    */
    constructor(scope: Construct, id: string, config: AwsLbListenerRuleConfig);
    get arn(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _listenerArn?;
    get listenerArn(): string;
    set listenerArn(value: string);
    get listenerArnInput(): string | undefined;
    private _priority?;
    get priority(): number;
    set priority(value: number);
    resetPriority(): void;
    get priorityInput(): number | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _action;
    get action(): AwsLbListenerRule.ActionPropertyList;
    putAction(value: AwsLbListenerRule.ActionProperty[] | cdktn.IResolvable): void;
    get actionInput(): cdktn.IResolvable | AwsLbListenerRule.ActionProperty[] | undefined;
    private _condition;
    get condition(): AwsLbListenerRule.ConditionPropertyList;
    putCondition(value: AwsLbListenerRule.ConditionProperty[] | cdktn.IResolvable): void;
    get conditionInput(): cdktn.IResolvable | AwsLbListenerRule.ConditionProperty[] | undefined;
    private _transform;
    get transform(): AwsLbListenerRule.TransformPropertyList;
    putTransform(value: AwsLbListenerRule.TransformProperty[] | cdktn.IResolvable): void;
    resetTransform(): void;
    get transformInput(): cdktn.IResolvable | AwsLbListenerRule.TransformProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsLbListenerRuleAuthenticateCognitoPropertyToTerraform(struct?: AwsLbListenerRule.AuthenticateCognitoPropertyOutputReference | AwsLbListenerRule.AuthenticateCognitoProperty): any;
export declare function awsLbListenerRuleAuthenticateCognitoPropertyToHclTerraform(struct?: AwsLbListenerRule.AuthenticateCognitoPropertyOutputReference | AwsLbListenerRule.AuthenticateCognitoProperty): any;
export declare function awsLbListenerRuleAuthenticateOidcPropertyToTerraform(struct?: AwsLbListenerRule.AuthenticateOidcPropertyOutputReference | AwsLbListenerRule.AuthenticateOidcProperty): any;
export declare function awsLbListenerRuleAuthenticateOidcPropertyToHclTerraform(struct?: AwsLbListenerRule.AuthenticateOidcPropertyOutputReference | AwsLbListenerRule.AuthenticateOidcProperty): any;
export declare function awsLbListenerRuleFixedResponsePropertyToTerraform(struct?: AwsLbListenerRule.FixedResponsePropertyOutputReference | AwsLbListenerRule.FixedResponseProperty): any;
export declare function awsLbListenerRuleFixedResponsePropertyToHclTerraform(struct?: AwsLbListenerRule.FixedResponsePropertyOutputReference | AwsLbListenerRule.FixedResponseProperty): any;
export declare function awsLbListenerRuleStickinessPropertyToTerraform(struct?: AwsLbListenerRule.StickinessPropertyOutputReference | AwsLbListenerRule.StickinessProperty): any;
export declare function awsLbListenerRuleStickinessPropertyToHclTerraform(struct?: AwsLbListenerRule.StickinessPropertyOutputReference | AwsLbListenerRule.StickinessProperty): any;
export declare function awsLbListenerRuleTargetGroupPropertyToTerraform(struct?: AwsLbListenerRule.TargetGroupProperty | cdktn.IResolvable): any;
export declare function awsLbListenerRuleTargetGroupPropertyToHclTerraform(struct?: AwsLbListenerRule.TargetGroupProperty | cdktn.IResolvable): any;
export declare function awsLbListenerRuleForwardPropertyToTerraform(struct?: AwsLbListenerRule.ForwardPropertyOutputReference | AwsLbListenerRule.ForwardProperty): any;
export declare function awsLbListenerRuleForwardPropertyToHclTerraform(struct?: AwsLbListenerRule.ForwardPropertyOutputReference | AwsLbListenerRule.ForwardProperty): any;
export declare function awsLbListenerRuleAdditionalClaimPropertyToTerraform(struct?: AwsLbListenerRule.AdditionalClaimProperty | cdktn.IResolvable): any;
export declare function awsLbListenerRuleAdditionalClaimPropertyToHclTerraform(struct?: AwsLbListenerRule.AdditionalClaimProperty | cdktn.IResolvable): any;
export declare function awsLbListenerRuleJwtValidationPropertyToTerraform(struct?: AwsLbListenerRule.JwtValidationPropertyOutputReference | AwsLbListenerRule.JwtValidationProperty): any;
export declare function awsLbListenerRuleJwtValidationPropertyToHclTerraform(struct?: AwsLbListenerRule.JwtValidationPropertyOutputReference | AwsLbListenerRule.JwtValidationProperty): any;
export declare function awsLbListenerRuleRedirectPropertyToTerraform(struct?: AwsLbListenerRule.RedirectPropertyOutputReference | AwsLbListenerRule.RedirectProperty): any;
export declare function awsLbListenerRuleRedirectPropertyToHclTerraform(struct?: AwsLbListenerRule.RedirectPropertyOutputReference | AwsLbListenerRule.RedirectProperty): any;
export declare function awsLbListenerRuleActionPropertyToTerraform(struct?: AwsLbListenerRule.ActionProperty | cdktn.IResolvable): any;
export declare function awsLbListenerRuleActionPropertyToHclTerraform(struct?: AwsLbListenerRule.ActionProperty | cdktn.IResolvable): any;
export declare function awsLbListenerRuleHostHeaderPropertyToTerraform(struct?: AwsLbListenerRule.HostHeaderPropertyOutputReference | AwsLbListenerRule.HostHeaderProperty): any;
export declare function awsLbListenerRuleHostHeaderPropertyToHclTerraform(struct?: AwsLbListenerRule.HostHeaderPropertyOutputReference | AwsLbListenerRule.HostHeaderProperty): any;
export declare function awsLbListenerRuleHttpHeaderPropertyToTerraform(struct?: AwsLbListenerRule.HttpHeaderPropertyOutputReference | AwsLbListenerRule.HttpHeaderProperty): any;
export declare function awsLbListenerRuleHttpHeaderPropertyToHclTerraform(struct?: AwsLbListenerRule.HttpHeaderPropertyOutputReference | AwsLbListenerRule.HttpHeaderProperty): any;
export declare function awsLbListenerRuleHttpRequestMethodPropertyToTerraform(struct?: AwsLbListenerRule.HttpRequestMethodPropertyOutputReference | AwsLbListenerRule.HttpRequestMethodProperty): any;
export declare function awsLbListenerRuleHttpRequestMethodPropertyToHclTerraform(struct?: AwsLbListenerRule.HttpRequestMethodPropertyOutputReference | AwsLbListenerRule.HttpRequestMethodProperty): any;
export declare function awsLbListenerRulePathPatternPropertyToTerraform(struct?: AwsLbListenerRule.PathPatternPropertyOutputReference | AwsLbListenerRule.PathPatternProperty): any;
export declare function awsLbListenerRulePathPatternPropertyToHclTerraform(struct?: AwsLbListenerRule.PathPatternPropertyOutputReference | AwsLbListenerRule.PathPatternProperty): any;
export declare function awsLbListenerRuleQueryStringPropertyToTerraform(struct?: AwsLbListenerRule.QueryStringProperty | cdktn.IResolvable): any;
export declare function awsLbListenerRuleQueryStringPropertyToHclTerraform(struct?: AwsLbListenerRule.QueryStringProperty | cdktn.IResolvable): any;
export declare function awsLbListenerRuleSourceIpPropertyToTerraform(struct?: AwsLbListenerRule.SourceIpPropertyOutputReference | AwsLbListenerRule.SourceIpProperty): any;
export declare function awsLbListenerRuleSourceIpPropertyToHclTerraform(struct?: AwsLbListenerRule.SourceIpPropertyOutputReference | AwsLbListenerRule.SourceIpProperty): any;
export declare function awsLbListenerRuleConditionPropertyToTerraform(struct?: AwsLbListenerRule.ConditionProperty | cdktn.IResolvable): any;
export declare function awsLbListenerRuleConditionPropertyToHclTerraform(struct?: AwsLbListenerRule.ConditionProperty | cdktn.IResolvable): any;
export declare function awsLbListenerRuleTransformHostHeaderRewriteConfigRewritePropertyToTerraform(struct?: AwsLbListenerRule.TransformHostHeaderRewriteConfigRewritePropertyOutputReference | AwsLbListenerRule.TransformHostHeaderRewriteConfigRewriteProperty): any;
export declare function awsLbListenerRuleTransformHostHeaderRewriteConfigRewritePropertyToHclTerraform(struct?: AwsLbListenerRule.TransformHostHeaderRewriteConfigRewritePropertyOutputReference | AwsLbListenerRule.TransformHostHeaderRewriteConfigRewriteProperty): any;
export declare function awsLbListenerRuleHostHeaderRewriteConfigPropertyToTerraform(struct?: AwsLbListenerRule.HostHeaderRewriteConfigPropertyOutputReference | AwsLbListenerRule.HostHeaderRewriteConfigProperty): any;
export declare function awsLbListenerRuleHostHeaderRewriteConfigPropertyToHclTerraform(struct?: AwsLbListenerRule.HostHeaderRewriteConfigPropertyOutputReference | AwsLbListenerRule.HostHeaderRewriteConfigProperty): any;
export declare function awsLbListenerRuleTransformUrlRewriteConfigRewritePropertyToTerraform(struct?: AwsLbListenerRule.TransformUrlRewriteConfigRewritePropertyOutputReference | AwsLbListenerRule.TransformUrlRewriteConfigRewriteProperty): any;
export declare function awsLbListenerRuleTransformUrlRewriteConfigRewritePropertyToHclTerraform(struct?: AwsLbListenerRule.TransformUrlRewriteConfigRewritePropertyOutputReference | AwsLbListenerRule.TransformUrlRewriteConfigRewriteProperty): any;
export declare function awsLbListenerRuleUrlRewriteConfigPropertyToTerraform(struct?: AwsLbListenerRule.UrlRewriteConfigPropertyOutputReference | AwsLbListenerRule.UrlRewriteConfigProperty): any;
export declare function awsLbListenerRuleUrlRewriteConfigPropertyToHclTerraform(struct?: AwsLbListenerRule.UrlRewriteConfigPropertyOutputReference | AwsLbListenerRule.UrlRewriteConfigProperty): any;
export declare function awsLbListenerRuleTransformPropertyToTerraform(struct?: AwsLbListenerRule.TransformProperty | cdktn.IResolvable): any;
export declare function awsLbListenerRuleTransformPropertyToHclTerraform(struct?: AwsLbListenerRule.TransformProperty | cdktn.IResolvable): any;
export declare namespace AwsLbListenerRule {
    interface AuthenticateCognitoProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_listener_rule#authentication_request_extra_params AwsLbListenerRule#authentication_request_extra_params}
        */
        readonly authenticationRequestExtraParams?: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_listener_rule#on_unauthenticated_request AwsLbListenerRule#on_unauthenticated_request}
        */
        readonly onUnauthenticatedRequest?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_listener_rule#scope AwsLbListenerRule#scope}
        */
        readonly scope?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_listener_rule#session_cookie_name AwsLbListenerRule#session_cookie_name}
        */
        readonly sessionCookieName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_listener_rule#session_timeout AwsLbListenerRule#session_timeout}
        */
        readonly sessionTimeout?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_listener_rule#user_pool_arn AwsLbListenerRule#user_pool_arn}
        */
        readonly userPoolArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_listener_rule#user_pool_client_id AwsLbListenerRule#user_pool_client_id}
        */
        readonly userPoolClientId: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_listener_rule#user_pool_domain AwsLbListenerRule#user_pool_domain}
        */
        readonly userPoolDomain: string;
    }
    class AuthenticateCognitoPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AuthenticateCognitoProperty | undefined;
        set internalValue(value: AuthenticateCognitoProperty | undefined);
        private _authenticationRequestExtraParams?;
        get authenticationRequestExtraParams(): {
            [key: string]: string;
        };
        set authenticationRequestExtraParams(value: {
            [key: string]: string;
        });
        resetAuthenticationRequestExtraParams(): void;
        get authenticationRequestExtraParamsInput(): {
            [key: string]: string;
        } | undefined;
        private _onUnauthenticatedRequest?;
        get onUnauthenticatedRequest(): string;
        set onUnauthenticatedRequest(value: string);
        resetOnUnauthenticatedRequest(): void;
        get onUnauthenticatedRequestInput(): string | undefined;
        private _scope?;
        get scope(): string;
        set scope(value: string);
        resetScope(): void;
        get scopeInput(): string | undefined;
        private _sessionCookieName?;
        get sessionCookieName(): string;
        set sessionCookieName(value: string);
        resetSessionCookieName(): void;
        get sessionCookieNameInput(): string | undefined;
        private _sessionTimeout?;
        get sessionTimeout(): number;
        set sessionTimeout(value: number);
        resetSessionTimeout(): void;
        get sessionTimeoutInput(): number | undefined;
        private _userPoolArn?;
        get userPoolArn(): string;
        set userPoolArn(value: string);
        get userPoolArnInput(): string | undefined;
        private _userPoolClientId?;
        get userPoolClientId(): string;
        set userPoolClientId(value: string);
        get userPoolClientIdInput(): string | undefined;
        private _userPoolDomain?;
        get userPoolDomain(): string;
        set userPoolDomain(value: string);
        get userPoolDomainInput(): string | undefined;
    }
    interface AuthenticateOidcProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_listener_rule#authentication_request_extra_params AwsLbListenerRule#authentication_request_extra_params}
        */
        readonly authenticationRequestExtraParams?: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_listener_rule#authorization_endpoint AwsLbListenerRule#authorization_endpoint}
        */
        readonly authorizationEndpoint: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_listener_rule#client_id AwsLbListenerRule#client_id}
        */
        readonly clientId: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_listener_rule#client_secret AwsLbListenerRule#client_secret}
        */
        readonly clientSecret: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_listener_rule#issuer AwsLbListenerRule#issuer}
        */
        readonly issuer: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_listener_rule#on_unauthenticated_request AwsLbListenerRule#on_unauthenticated_request}
        */
        readonly onUnauthenticatedRequest?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_listener_rule#scope AwsLbListenerRule#scope}
        */
        readonly scope?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_listener_rule#session_cookie_name AwsLbListenerRule#session_cookie_name}
        */
        readonly sessionCookieName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_listener_rule#session_timeout AwsLbListenerRule#session_timeout}
        */
        readonly sessionTimeout?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_listener_rule#token_endpoint AwsLbListenerRule#token_endpoint}
        */
        readonly tokenEndpoint: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_listener_rule#user_info_endpoint AwsLbListenerRule#user_info_endpoint}
        */
        readonly userInfoEndpoint: string;
    }
    class AuthenticateOidcPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AuthenticateOidcProperty | undefined;
        set internalValue(value: AuthenticateOidcProperty | undefined);
        private _authenticationRequestExtraParams?;
        get authenticationRequestExtraParams(): {
            [key: string]: string;
        };
        set authenticationRequestExtraParams(value: {
            [key: string]: string;
        });
        resetAuthenticationRequestExtraParams(): void;
        get authenticationRequestExtraParamsInput(): {
            [key: string]: string;
        } | undefined;
        private _authorizationEndpoint?;
        get authorizationEndpoint(): string;
        set authorizationEndpoint(value: string);
        get authorizationEndpointInput(): string | undefined;
        private _clientId?;
        get clientId(): string;
        set clientId(value: string);
        get clientIdInput(): string | undefined;
        private _clientSecret?;
        get clientSecret(): string;
        set clientSecret(value: string);
        get clientSecretInput(): string | undefined;
        private _issuer?;
        get issuer(): string;
        set issuer(value: string);
        get issuerInput(): string | undefined;
        private _onUnauthenticatedRequest?;
        get onUnauthenticatedRequest(): string;
        set onUnauthenticatedRequest(value: string);
        resetOnUnauthenticatedRequest(): void;
        get onUnauthenticatedRequestInput(): string | undefined;
        private _scope?;
        get scope(): string;
        set scope(value: string);
        resetScope(): void;
        get scopeInput(): string | undefined;
        private _sessionCookieName?;
        get sessionCookieName(): string;
        set sessionCookieName(value: string);
        resetSessionCookieName(): void;
        get sessionCookieNameInput(): string | undefined;
        private _sessionTimeout?;
        get sessionTimeout(): number;
        set sessionTimeout(value: number);
        resetSessionTimeout(): void;
        get sessionTimeoutInput(): number | undefined;
        private _tokenEndpoint?;
        get tokenEndpoint(): string;
        set tokenEndpoint(value: string);
        get tokenEndpointInput(): string | undefined;
        private _userInfoEndpoint?;
        get userInfoEndpoint(): string;
        set userInfoEndpoint(value: string);
        get userInfoEndpointInput(): string | undefined;
    }
    interface FixedResponseProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_listener_rule#content_type AwsLbListenerRule#content_type}
        */
        readonly contentType: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_listener_rule#message_body AwsLbListenerRule#message_body}
        */
        readonly messageBody?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_listener_rule#status_code AwsLbListenerRule#status_code}
        */
        readonly statusCode?: string;
    }
    class FixedResponsePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): FixedResponseProperty | undefined;
        set internalValue(value: FixedResponseProperty | undefined);
        private _contentType?;
        get contentType(): string;
        set contentType(value: string);
        get contentTypeInput(): string | undefined;
        private _messageBody?;
        get messageBody(): string;
        set messageBody(value: string);
        resetMessageBody(): void;
        get messageBodyInput(): string | undefined;
        private _statusCode?;
        get statusCode(): string;
        set statusCode(value: string);
        resetStatusCode(): void;
        get statusCodeInput(): string | undefined;
    }
    interface StickinessProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_listener_rule#duration AwsLbListenerRule#duration}
        */
        readonly duration: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_listener_rule#enabled AwsLbListenerRule#enabled}
        */
        readonly enabled?: boolean | cdktn.IResolvable;
    }
    class StickinessPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): StickinessProperty | undefined;
        set internalValue(value: StickinessProperty | undefined);
        private _duration?;
        get duration(): number;
        set duration(value: number);
        get durationInput(): number | undefined;
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        resetEnabled(): void;
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface TargetGroupProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_listener_rule#arn AwsLbListenerRule#arn}
        */
        readonly arn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_listener_rule#weight AwsLbListenerRule#weight}
        */
        readonly weight?: number;
    }
    class TargetGroupPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TargetGroupProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TargetGroupProperty | cdktn.IResolvable | undefined);
        private _arn?;
        get arn(): string;
        set arn(value: string);
        get arnInput(): string | undefined;
        private _weight?;
        get weight(): number;
        set weight(value: number);
        resetWeight(): void;
        get weightInput(): number | undefined;
    }
    class TargetGroupPropertyList extends cdktn.ComplexList {
        internalValue?: TargetGroupProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TargetGroupPropertyOutputReference;
    }
    interface ForwardProperty {
        /**
        * stickiness block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_listener_rule#stickiness AwsLbListenerRule#stickiness}
        */
        readonly stickiness?: StickinessProperty;
        /**
        * target_group block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_listener_rule#target_group AwsLbListenerRule#target_group}
        */
        readonly targetGroup: TargetGroupProperty[] | cdktn.IResolvable;
    }
    class ForwardPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ForwardProperty | undefined;
        set internalValue(value: ForwardProperty | undefined);
        private _stickiness;
        get stickiness(): StickinessPropertyOutputReference;
        putStickiness(value: StickinessProperty): void;
        resetStickiness(): void;
        get stickinessInput(): StickinessProperty | undefined;
        private _targetGroup;
        get targetGroup(): TargetGroupPropertyList;
        putTargetGroup(value: TargetGroupProperty[] | cdktn.IResolvable): void;
        get targetGroupInput(): cdktn.IResolvable | TargetGroupProperty[] | undefined;
    }
    interface AdditionalClaimProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_listener_rule#format AwsLbListenerRule#format}
        */
        readonly format: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_listener_rule#name AwsLbListenerRule#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_listener_rule#values AwsLbListenerRule#values}
        */
        readonly values: string[];
    }
    class AdditionalClaimPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AdditionalClaimProperty | cdktn.IResolvable | undefined;
        set internalValue(value: AdditionalClaimProperty | cdktn.IResolvable | undefined);
        private _format?;
        get format(): string;
        set format(value: string);
        get formatInput(): string | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        get valuesInput(): string[] | undefined;
    }
    class AdditionalClaimPropertyList extends cdktn.ComplexList {
        internalValue?: AdditionalClaimProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AdditionalClaimPropertyOutputReference;
    }
    interface JwtValidationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_listener_rule#issuer AwsLbListenerRule#issuer}
        */
        readonly issuer: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_listener_rule#jwks_endpoint AwsLbListenerRule#jwks_endpoint}
        */
        readonly jwksEndpoint: string;
        /**
        * additional_claim block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_listener_rule#additional_claim AwsLbListenerRule#additional_claim}
        */
        readonly additionalClaim?: AdditionalClaimProperty[] | cdktn.IResolvable;
    }
    class JwtValidationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): JwtValidationProperty | undefined;
        set internalValue(value: JwtValidationProperty | undefined);
        private _issuer?;
        get issuer(): string;
        set issuer(value: string);
        get issuerInput(): string | undefined;
        private _jwksEndpoint?;
        get jwksEndpoint(): string;
        set jwksEndpoint(value: string);
        get jwksEndpointInput(): string | undefined;
        private _additionalClaim;
        get additionalClaim(): AdditionalClaimPropertyList;
        putAdditionalClaim(value: AdditionalClaimProperty[] | cdktn.IResolvable): void;
        resetAdditionalClaim(): void;
        get additionalClaimInput(): cdktn.IResolvable | AdditionalClaimProperty[] | undefined;
    }
    interface RedirectProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_listener_rule#host AwsLbListenerRule#host}
        */
        readonly host?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_listener_rule#path AwsLbListenerRule#path}
        */
        readonly path?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_listener_rule#port AwsLbListenerRule#port}
        */
        readonly port?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_listener_rule#protocol AwsLbListenerRule#protocol}
        */
        readonly protocol?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_listener_rule#query AwsLbListenerRule#query}
        */
        readonly query?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_listener_rule#status_code AwsLbListenerRule#status_code}
        */
        readonly statusCode: string;
    }
    class RedirectPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RedirectProperty | undefined;
        set internalValue(value: RedirectProperty | undefined);
        private _host?;
        get host(): string;
        set host(value: string);
        resetHost(): void;
        get hostInput(): string | undefined;
        private _path?;
        get path(): string;
        set path(value: string);
        resetPath(): void;
        get pathInput(): string | undefined;
        private _port?;
        get port(): string;
        set port(value: string);
        resetPort(): void;
        get portInput(): string | undefined;
        private _protocol?;
        get protocol(): string;
        set protocol(value: string);
        resetProtocol(): void;
        get protocolInput(): string | undefined;
        private _query?;
        get query(): string;
        set query(value: string);
        resetQuery(): void;
        get queryInput(): string | undefined;
        private _statusCode?;
        get statusCode(): string;
        set statusCode(value: string);
        get statusCodeInput(): string | undefined;
    }
    interface ActionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_listener_rule#order AwsLbListenerRule#order}
        */
        readonly order?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_listener_rule#target_group_arn AwsLbListenerRule#target_group_arn}
        */
        readonly targetGroupArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_listener_rule#type AwsLbListenerRule#type}
        */
        readonly type: string;
        /**
        * authenticate_cognito block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_listener_rule#authenticate_cognito AwsLbListenerRule#authenticate_cognito}
        */
        readonly authenticateCognito?: AuthenticateCognitoProperty;
        /**
        * authenticate_oidc block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_listener_rule#authenticate_oidc AwsLbListenerRule#authenticate_oidc}
        */
        readonly authenticateOidc?: AuthenticateOidcProperty;
        /**
        * fixed_response block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_listener_rule#fixed_response AwsLbListenerRule#fixed_response}
        */
        readonly fixedResponse?: FixedResponseProperty;
        /**
        * forward block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_listener_rule#forward AwsLbListenerRule#forward}
        */
        readonly forward?: ForwardProperty;
        /**
        * jwt_validation block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_listener_rule#jwt_validation AwsLbListenerRule#jwt_validation}
        */
        readonly jwtValidation?: JwtValidationProperty;
        /**
        * redirect block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_listener_rule#redirect AwsLbListenerRule#redirect}
        */
        readonly redirect?: RedirectProperty;
    }
    class ActionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ActionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ActionProperty | cdktn.IResolvable | undefined);
        private _order?;
        get order(): number;
        set order(value: number);
        resetOrder(): void;
        get orderInput(): number | undefined;
        private _targetGroupArn?;
        get targetGroupArn(): string;
        set targetGroupArn(value: string);
        resetTargetGroupArn(): void;
        get targetGroupArnInput(): string | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
        private _authenticateCognito;
        get authenticateCognito(): AuthenticateCognitoPropertyOutputReference;
        putAuthenticateCognito(value: AuthenticateCognitoProperty): void;
        resetAuthenticateCognito(): void;
        get authenticateCognitoInput(): AuthenticateCognitoProperty | undefined;
        private _authenticateOidc;
        get authenticateOidc(): AuthenticateOidcPropertyOutputReference;
        putAuthenticateOidc(value: AuthenticateOidcProperty): void;
        resetAuthenticateOidc(): void;
        get authenticateOidcInput(): AuthenticateOidcProperty | undefined;
        private _fixedResponse;
        get fixedResponse(): FixedResponsePropertyOutputReference;
        putFixedResponse(value: FixedResponseProperty): void;
        resetFixedResponse(): void;
        get fixedResponseInput(): FixedResponseProperty | undefined;
        private _forward;
        get forward(): ForwardPropertyOutputReference;
        putForward(value: ForwardProperty): void;
        resetForward(): void;
        get forwardInput(): ForwardProperty | undefined;
        private _jwtValidation;
        get jwtValidation(): JwtValidationPropertyOutputReference;
        putJwtValidation(value: JwtValidationProperty): void;
        resetJwtValidation(): void;
        get jwtValidationInput(): JwtValidationProperty | undefined;
        private _redirect;
        get redirect(): RedirectPropertyOutputReference;
        putRedirect(value: RedirectProperty): void;
        resetRedirect(): void;
        get redirectInput(): RedirectProperty | undefined;
    }
    class ActionPropertyList extends cdktn.ComplexList {
        internalValue?: ActionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ActionPropertyOutputReference;
    }
    interface HostHeaderProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_listener_rule#regex_values AwsLbListenerRule#regex_values}
        */
        readonly regexValues?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_listener_rule#values AwsLbListenerRule#values}
        */
        readonly values?: string[];
    }
    class HostHeaderPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): HostHeaderProperty | undefined;
        set internalValue(value: HostHeaderProperty | undefined);
        private _regexValues?;
        get regexValues(): string[];
        set regexValues(value: string[]);
        resetRegexValues(): void;
        get regexValuesInput(): string[] | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        resetValues(): void;
        get valuesInput(): string[] | undefined;
    }
    interface HttpHeaderProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_listener_rule#http_header_name AwsLbListenerRule#http_header_name}
        */
        readonly httpHeaderName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_listener_rule#regex_values AwsLbListenerRule#regex_values}
        */
        readonly regexValues?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_listener_rule#values AwsLbListenerRule#values}
        */
        readonly values?: string[];
    }
    class HttpHeaderPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): HttpHeaderProperty | undefined;
        set internalValue(value: HttpHeaderProperty | undefined);
        private _httpHeaderName?;
        get httpHeaderName(): string;
        set httpHeaderName(value: string);
        get httpHeaderNameInput(): string | undefined;
        private _regexValues?;
        get regexValues(): string[];
        set regexValues(value: string[]);
        resetRegexValues(): void;
        get regexValuesInput(): string[] | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        resetValues(): void;
        get valuesInput(): string[] | undefined;
    }
    interface HttpRequestMethodProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_listener_rule#values AwsLbListenerRule#values}
        */
        readonly values: string[];
    }
    class HttpRequestMethodPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): HttpRequestMethodProperty | undefined;
        set internalValue(value: HttpRequestMethodProperty | undefined);
        private _values?;
        get values(): string[];
        set values(value: string[]);
        get valuesInput(): string[] | undefined;
    }
    interface PathPatternProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_listener_rule#regex_values AwsLbListenerRule#regex_values}
        */
        readonly regexValues?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_listener_rule#values AwsLbListenerRule#values}
        */
        readonly values?: string[];
    }
    class PathPatternPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): PathPatternProperty | undefined;
        set internalValue(value: PathPatternProperty | undefined);
        private _regexValues?;
        get regexValues(): string[];
        set regexValues(value: string[]);
        resetRegexValues(): void;
        get regexValuesInput(): string[] | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        resetValues(): void;
        get valuesInput(): string[] | undefined;
    }
    interface QueryStringProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_listener_rule#key AwsLbListenerRule#key}
        */
        readonly key?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_listener_rule#value AwsLbListenerRule#value}
        */
        readonly value: string;
    }
    class QueryStringPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): QueryStringProperty | cdktn.IResolvable | undefined;
        set internalValue(value: QueryStringProperty | cdktn.IResolvable | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        resetKey(): void;
        get keyInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class QueryStringPropertyList extends cdktn.ComplexList {
        internalValue?: QueryStringProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): QueryStringPropertyOutputReference;
    }
    interface SourceIpProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_listener_rule#ip_address_type AwsLbListenerRule#ip_address_type}
        */
        readonly ipAddressType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_listener_rule#values AwsLbListenerRule#values}
        */
        readonly values?: string[];
    }
    class SourceIpPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SourceIpProperty | undefined;
        set internalValue(value: SourceIpProperty | undefined);
        private _ipAddressType?;
        get ipAddressType(): string;
        set ipAddressType(value: string);
        resetIpAddressType(): void;
        get ipAddressTypeInput(): string | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        resetValues(): void;
        get valuesInput(): string[] | undefined;
    }
    interface ConditionProperty {
        /**
        * host_header block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_listener_rule#host_header AwsLbListenerRule#host_header}
        */
        readonly hostHeader?: HostHeaderProperty;
        /**
        * http_header block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_listener_rule#http_header AwsLbListenerRule#http_header}
        */
        readonly httpHeader?: HttpHeaderProperty;
        /**
        * http_request_method block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_listener_rule#http_request_method AwsLbListenerRule#http_request_method}
        */
        readonly httpRequestMethod?: HttpRequestMethodProperty;
        /**
        * path_pattern block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_listener_rule#path_pattern AwsLbListenerRule#path_pattern}
        */
        readonly pathPattern?: PathPatternProperty;
        /**
        * query_string block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_listener_rule#query_string AwsLbListenerRule#query_string}
        */
        readonly queryString?: QueryStringProperty[] | cdktn.IResolvable;
        /**
        * source_ip block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_listener_rule#source_ip AwsLbListenerRule#source_ip}
        */
        readonly sourceIp?: SourceIpProperty;
    }
    class ConditionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ConditionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ConditionProperty | cdktn.IResolvable | undefined);
        private _hostHeader;
        get hostHeader(): HostHeaderPropertyOutputReference;
        putHostHeader(value: HostHeaderProperty): void;
        resetHostHeader(): void;
        get hostHeaderInput(): HostHeaderProperty | undefined;
        private _httpHeader;
        get httpHeader(): HttpHeaderPropertyOutputReference;
        putHttpHeader(value: HttpHeaderProperty): void;
        resetHttpHeader(): void;
        get httpHeaderInput(): HttpHeaderProperty | undefined;
        private _httpRequestMethod;
        get httpRequestMethod(): HttpRequestMethodPropertyOutputReference;
        putHttpRequestMethod(value: HttpRequestMethodProperty): void;
        resetHttpRequestMethod(): void;
        get httpRequestMethodInput(): HttpRequestMethodProperty | undefined;
        private _pathPattern;
        get pathPattern(): PathPatternPropertyOutputReference;
        putPathPattern(value: PathPatternProperty): void;
        resetPathPattern(): void;
        get pathPatternInput(): PathPatternProperty | undefined;
        private _queryString;
        get queryString(): QueryStringPropertyList;
        putQueryString(value: QueryStringProperty[] | cdktn.IResolvable): void;
        resetQueryString(): void;
        get queryStringInput(): cdktn.IResolvable | QueryStringProperty[] | undefined;
        private _sourceIp;
        get sourceIp(): SourceIpPropertyOutputReference;
        putSourceIp(value: SourceIpProperty): void;
        resetSourceIp(): void;
        get sourceIpInput(): SourceIpProperty | undefined;
    }
    class ConditionPropertyList extends cdktn.ComplexList {
        internalValue?: ConditionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ConditionPropertyOutputReference;
    }
    interface TransformHostHeaderRewriteConfigRewriteProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_listener_rule#regex AwsLbListenerRule#regex}
        */
        readonly regex: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_listener_rule#replace AwsLbListenerRule#replace}
        */
        readonly replace: string;
    }
    class TransformHostHeaderRewriteConfigRewritePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TransformHostHeaderRewriteConfigRewriteProperty | undefined;
        set internalValue(value: TransformHostHeaderRewriteConfigRewriteProperty | undefined);
        private _regex?;
        get regex(): string;
        set regex(value: string);
        get regexInput(): string | undefined;
        private _replace?;
        get replace(): string;
        set replace(value: string);
        get replaceInput(): string | undefined;
    }
    interface HostHeaderRewriteConfigProperty {
        /**
        * rewrite block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_listener_rule#rewrite AwsLbListenerRule#rewrite}
        */
        readonly rewrite?: TransformHostHeaderRewriteConfigRewriteProperty;
    }
    class HostHeaderRewriteConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): HostHeaderRewriteConfigProperty | undefined;
        set internalValue(value: HostHeaderRewriteConfigProperty | undefined);
        private _rewrite;
        get rewrite(): TransformHostHeaderRewriteConfigRewritePropertyOutputReference;
        putRewrite(value: TransformHostHeaderRewriteConfigRewriteProperty): void;
        resetRewrite(): void;
        get rewriteInput(): TransformHostHeaderRewriteConfigRewriteProperty | undefined;
    }
    interface TransformUrlRewriteConfigRewriteProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_listener_rule#regex AwsLbListenerRule#regex}
        */
        readonly regex: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_listener_rule#replace AwsLbListenerRule#replace}
        */
        readonly replace: string;
    }
    class TransformUrlRewriteConfigRewritePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TransformUrlRewriteConfigRewriteProperty | undefined;
        set internalValue(value: TransformUrlRewriteConfigRewriteProperty | undefined);
        private _regex?;
        get regex(): string;
        set regex(value: string);
        get regexInput(): string | undefined;
        private _replace?;
        get replace(): string;
        set replace(value: string);
        get replaceInput(): string | undefined;
    }
    interface UrlRewriteConfigProperty {
        /**
        * rewrite block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_listener_rule#rewrite AwsLbListenerRule#rewrite}
        */
        readonly rewrite?: TransformUrlRewriteConfigRewriteProperty;
    }
    class UrlRewriteConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): UrlRewriteConfigProperty | undefined;
        set internalValue(value: UrlRewriteConfigProperty | undefined);
        private _rewrite;
        get rewrite(): TransformUrlRewriteConfigRewritePropertyOutputReference;
        putRewrite(value: TransformUrlRewriteConfigRewriteProperty): void;
        resetRewrite(): void;
        get rewriteInput(): TransformUrlRewriteConfigRewriteProperty | undefined;
    }
    interface TransformProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_listener_rule#type AwsLbListenerRule#type}
        */
        readonly type: string;
        /**
        * host_header_rewrite_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_listener_rule#host_header_rewrite_config AwsLbListenerRule#host_header_rewrite_config}
        */
        readonly hostHeaderRewriteConfig?: HostHeaderRewriteConfigProperty;
        /**
        * url_rewrite_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_listener_rule#url_rewrite_config AwsLbListenerRule#url_rewrite_config}
        */
        readonly urlRewriteConfig?: UrlRewriteConfigProperty;
    }
    class TransformPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TransformProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TransformProperty | cdktn.IResolvable | undefined);
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
        private _hostHeaderRewriteConfig;
        get hostHeaderRewriteConfig(): HostHeaderRewriteConfigPropertyOutputReference;
        putHostHeaderRewriteConfig(value: HostHeaderRewriteConfigProperty): void;
        resetHostHeaderRewriteConfig(): void;
        get hostHeaderRewriteConfigInput(): HostHeaderRewriteConfigProperty | undefined;
        private _urlRewriteConfig;
        get urlRewriteConfig(): UrlRewriteConfigPropertyOutputReference;
        putUrlRewriteConfig(value: UrlRewriteConfigProperty): void;
        resetUrlRewriteConfig(): void;
        get urlRewriteConfigInput(): UrlRewriteConfigProperty | undefined;
    }
    class TransformPropertyList extends cdktn.ComplexList {
        internalValue?: TransformProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TransformPropertyOutputReference;
    }
}
