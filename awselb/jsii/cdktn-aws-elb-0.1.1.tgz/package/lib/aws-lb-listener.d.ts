import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsLbListenerConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_listener#alpn_policy AwsLbListener#alpn_policy}
    */
    readonly alpnPolicy?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_listener#certificate_arn AwsLbListener#certificate_arn}
    */
    readonly certificateArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_listener#id AwsLbListener#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_listener#load_balancer_arn AwsLbListener#load_balancer_arn}
    */
    readonly loadBalancerArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_listener#port AwsLbListener#port}
    */
    readonly port?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_listener#protocol AwsLbListener#protocol}
    */
    readonly protocol?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_listener#region AwsLbListener#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_listener#routing_http_request_x_amzn_mtls_clientcert_header_name AwsLbListener#routing_http_request_x_amzn_mtls_clientcert_header_name}
    */
    readonly routingHttpRequestXAmznMtlsClientcertHeaderName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_listener#routing_http_request_x_amzn_mtls_clientcert_issuer_header_name AwsLbListener#routing_http_request_x_amzn_mtls_clientcert_issuer_header_name}
    */
    readonly routingHttpRequestXAmznMtlsClientcertIssuerHeaderName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_listener#routing_http_request_x_amzn_mtls_clientcert_leaf_header_name AwsLbListener#routing_http_request_x_amzn_mtls_clientcert_leaf_header_name}
    */
    readonly routingHttpRequestXAmznMtlsClientcertLeafHeaderName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_listener#routing_http_request_x_amzn_mtls_clientcert_serial_number_header_name AwsLbListener#routing_http_request_x_amzn_mtls_clientcert_serial_number_header_name}
    */
    readonly routingHttpRequestXAmznMtlsClientcertSerialNumberHeaderName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_listener#routing_http_request_x_amzn_mtls_clientcert_subject_header_name AwsLbListener#routing_http_request_x_amzn_mtls_clientcert_subject_header_name}
    */
    readonly routingHttpRequestXAmznMtlsClientcertSubjectHeaderName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_listener#routing_http_request_x_amzn_mtls_clientcert_validity_header_name AwsLbListener#routing_http_request_x_amzn_mtls_clientcert_validity_header_name}
    */
    readonly routingHttpRequestXAmznMtlsClientcertValidityHeaderName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_listener#routing_http_request_x_amzn_tls_cipher_suite_header_name AwsLbListener#routing_http_request_x_amzn_tls_cipher_suite_header_name}
    */
    readonly routingHttpRequestXAmznTlsCipherSuiteHeaderName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_listener#routing_http_request_x_amzn_tls_version_header_name AwsLbListener#routing_http_request_x_amzn_tls_version_header_name}
    */
    readonly routingHttpRequestXAmznTlsVersionHeaderName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_listener#routing_http_response_access_control_allow_credentials_header_value AwsLbListener#routing_http_response_access_control_allow_credentials_header_value}
    */
    readonly routingHttpResponseAccessControlAllowCredentialsHeaderValue?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_listener#routing_http_response_access_control_allow_headers_header_value AwsLbListener#routing_http_response_access_control_allow_headers_header_value}
    */
    readonly routingHttpResponseAccessControlAllowHeadersHeaderValue?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_listener#routing_http_response_access_control_allow_methods_header_value AwsLbListener#routing_http_response_access_control_allow_methods_header_value}
    */
    readonly routingHttpResponseAccessControlAllowMethodsHeaderValue?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_listener#routing_http_response_access_control_allow_origin_header_value AwsLbListener#routing_http_response_access_control_allow_origin_header_value}
    */
    readonly routingHttpResponseAccessControlAllowOriginHeaderValue?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_listener#routing_http_response_access_control_expose_headers_header_value AwsLbListener#routing_http_response_access_control_expose_headers_header_value}
    */
    readonly routingHttpResponseAccessControlExposeHeadersHeaderValue?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_listener#routing_http_response_access_control_max_age_header_value AwsLbListener#routing_http_response_access_control_max_age_header_value}
    */
    readonly routingHttpResponseAccessControlMaxAgeHeaderValue?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_listener#routing_http_response_content_security_policy_header_value AwsLbListener#routing_http_response_content_security_policy_header_value}
    */
    readonly routingHttpResponseContentSecurityPolicyHeaderValue?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_listener#routing_http_response_server_enabled AwsLbListener#routing_http_response_server_enabled}
    */
    readonly routingHttpResponseServerEnabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_listener#routing_http_response_strict_transport_security_header_value AwsLbListener#routing_http_response_strict_transport_security_header_value}
    */
    readonly routingHttpResponseStrictTransportSecurityHeaderValue?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_listener#routing_http_response_x_content_type_options_header_value AwsLbListener#routing_http_response_x_content_type_options_header_value}
    */
    readonly routingHttpResponseXContentTypeOptionsHeaderValue?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_listener#routing_http_response_x_frame_options_header_value AwsLbListener#routing_http_response_x_frame_options_header_value}
    */
    readonly routingHttpResponseXFrameOptionsHeaderValue?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_listener#ssl_policy AwsLbListener#ssl_policy}
    */
    readonly sslPolicy?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_listener#tags AwsLbListener#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_listener#tags_all AwsLbListener#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_listener#tcp_idle_timeout_seconds AwsLbListener#tcp_idle_timeout_seconds}
    */
    readonly tcpIdleTimeoutSeconds?: number;
    /**
    * default_action block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_listener#default_action AwsLbListener#default_action}
    */
    readonly defaultAction: AwsLbListener.DefaultActionProperty[] | cdktn.IResolvable;
    /**
    * mutual_authentication block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_listener#mutual_authentication AwsLbListener#mutual_authentication}
    */
    readonly mutualAuthentication?: AwsLbListener.MutualAuthenticationProperty;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_listener#timeouts AwsLbListener#timeouts}
    */
    readonly timeouts?: AwsLbListener.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_listener aws_lb_listener}
*/
export declare class AwsLbListener extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_lb_listener";
    /**
    * Generates CDKTN code for importing a AwsLbListener resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsLbListener to import
    * @param importFromId The id of the existing AwsLbListener that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_listener#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsLbListener to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_listener aws_lb_listener} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsLbListenerConfig
    */
    constructor(scope: Construct, id: string, config: AwsLbListenerConfig);
    private _alpnPolicy?;
    get alpnPolicy(): string;
    set alpnPolicy(value: string);
    resetAlpnPolicy(): void;
    get alpnPolicyInput(): string | undefined;
    get arn(): string;
    private _certificateArn?;
    get certificateArn(): string;
    set certificateArn(value: string);
    resetCertificateArn(): void;
    get certificateArnInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _loadBalancerArn?;
    get loadBalancerArn(): string;
    set loadBalancerArn(value: string);
    get loadBalancerArnInput(): string | undefined;
    private _port?;
    get port(): number;
    set port(value: number);
    resetPort(): void;
    get portInput(): number | undefined;
    private _protocol?;
    get protocol(): string;
    set protocol(value: string);
    resetProtocol(): void;
    get protocolInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _routingHttpRequestXAmznMtlsClientcertHeaderName?;
    get routingHttpRequestXAmznMtlsClientcertHeaderName(): string;
    set routingHttpRequestXAmznMtlsClientcertHeaderName(value: string);
    resetRoutingHttpRequestXAmznMtlsClientcertHeaderName(): void;
    get routingHttpRequestXAmznMtlsClientcertHeaderNameInput(): string | undefined;
    private _routingHttpRequestXAmznMtlsClientcertIssuerHeaderName?;
    get routingHttpRequestXAmznMtlsClientcertIssuerHeaderName(): string;
    set routingHttpRequestXAmznMtlsClientcertIssuerHeaderName(value: string);
    resetRoutingHttpRequestXAmznMtlsClientcertIssuerHeaderName(): void;
    get routingHttpRequestXAmznMtlsClientcertIssuerHeaderNameInput(): string | undefined;
    private _routingHttpRequestXAmznMtlsClientcertLeafHeaderName?;
    get routingHttpRequestXAmznMtlsClientcertLeafHeaderName(): string;
    set routingHttpRequestXAmznMtlsClientcertLeafHeaderName(value: string);
    resetRoutingHttpRequestXAmznMtlsClientcertLeafHeaderName(): void;
    get routingHttpRequestXAmznMtlsClientcertLeafHeaderNameInput(): string | undefined;
    private _routingHttpRequestXAmznMtlsClientcertSerialNumberHeaderName?;
    get routingHttpRequestXAmznMtlsClientcertSerialNumberHeaderName(): string;
    set routingHttpRequestXAmznMtlsClientcertSerialNumberHeaderName(value: string);
    resetRoutingHttpRequestXAmznMtlsClientcertSerialNumberHeaderName(): void;
    get routingHttpRequestXAmznMtlsClientcertSerialNumberHeaderNameInput(): string | undefined;
    private _routingHttpRequestXAmznMtlsClientcertSubjectHeaderName?;
    get routingHttpRequestXAmznMtlsClientcertSubjectHeaderName(): string;
    set routingHttpRequestXAmznMtlsClientcertSubjectHeaderName(value: string);
    resetRoutingHttpRequestXAmznMtlsClientcertSubjectHeaderName(): void;
    get routingHttpRequestXAmznMtlsClientcertSubjectHeaderNameInput(): string | undefined;
    private _routingHttpRequestXAmznMtlsClientcertValidityHeaderName?;
    get routingHttpRequestXAmznMtlsClientcertValidityHeaderName(): string;
    set routingHttpRequestXAmznMtlsClientcertValidityHeaderName(value: string);
    resetRoutingHttpRequestXAmznMtlsClientcertValidityHeaderName(): void;
    get routingHttpRequestXAmznMtlsClientcertValidityHeaderNameInput(): string | undefined;
    private _routingHttpRequestXAmznTlsCipherSuiteHeaderName?;
    get routingHttpRequestXAmznTlsCipherSuiteHeaderName(): string;
    set routingHttpRequestXAmznTlsCipherSuiteHeaderName(value: string);
    resetRoutingHttpRequestXAmznTlsCipherSuiteHeaderName(): void;
    get routingHttpRequestXAmznTlsCipherSuiteHeaderNameInput(): string | undefined;
    private _routingHttpRequestXAmznTlsVersionHeaderName?;
    get routingHttpRequestXAmznTlsVersionHeaderName(): string;
    set routingHttpRequestXAmznTlsVersionHeaderName(value: string);
    resetRoutingHttpRequestXAmznTlsVersionHeaderName(): void;
    get routingHttpRequestXAmznTlsVersionHeaderNameInput(): string | undefined;
    private _routingHttpResponseAccessControlAllowCredentialsHeaderValue?;
    get routingHttpResponseAccessControlAllowCredentialsHeaderValue(): string;
    set routingHttpResponseAccessControlAllowCredentialsHeaderValue(value: string);
    resetRoutingHttpResponseAccessControlAllowCredentialsHeaderValue(): void;
    get routingHttpResponseAccessControlAllowCredentialsHeaderValueInput(): string | undefined;
    private _routingHttpResponseAccessControlAllowHeadersHeaderValue?;
    get routingHttpResponseAccessControlAllowHeadersHeaderValue(): string;
    set routingHttpResponseAccessControlAllowHeadersHeaderValue(value: string);
    resetRoutingHttpResponseAccessControlAllowHeadersHeaderValue(): void;
    get routingHttpResponseAccessControlAllowHeadersHeaderValueInput(): string | undefined;
    private _routingHttpResponseAccessControlAllowMethodsHeaderValue?;
    get routingHttpResponseAccessControlAllowMethodsHeaderValue(): string;
    set routingHttpResponseAccessControlAllowMethodsHeaderValue(value: string);
    resetRoutingHttpResponseAccessControlAllowMethodsHeaderValue(): void;
    get routingHttpResponseAccessControlAllowMethodsHeaderValueInput(): string | undefined;
    private _routingHttpResponseAccessControlAllowOriginHeaderValue?;
    get routingHttpResponseAccessControlAllowOriginHeaderValue(): string;
    set routingHttpResponseAccessControlAllowOriginHeaderValue(value: string);
    resetRoutingHttpResponseAccessControlAllowOriginHeaderValue(): void;
    get routingHttpResponseAccessControlAllowOriginHeaderValueInput(): string | undefined;
    private _routingHttpResponseAccessControlExposeHeadersHeaderValue?;
    get routingHttpResponseAccessControlExposeHeadersHeaderValue(): string;
    set routingHttpResponseAccessControlExposeHeadersHeaderValue(value: string);
    resetRoutingHttpResponseAccessControlExposeHeadersHeaderValue(): void;
    get routingHttpResponseAccessControlExposeHeadersHeaderValueInput(): string | undefined;
    private _routingHttpResponseAccessControlMaxAgeHeaderValue?;
    get routingHttpResponseAccessControlMaxAgeHeaderValue(): string;
    set routingHttpResponseAccessControlMaxAgeHeaderValue(value: string);
    resetRoutingHttpResponseAccessControlMaxAgeHeaderValue(): void;
    get routingHttpResponseAccessControlMaxAgeHeaderValueInput(): string | undefined;
    private _routingHttpResponseContentSecurityPolicyHeaderValue?;
    get routingHttpResponseContentSecurityPolicyHeaderValue(): string;
    set routingHttpResponseContentSecurityPolicyHeaderValue(value: string);
    resetRoutingHttpResponseContentSecurityPolicyHeaderValue(): void;
    get routingHttpResponseContentSecurityPolicyHeaderValueInput(): string | undefined;
    private _routingHttpResponseServerEnabled?;
    get routingHttpResponseServerEnabled(): boolean | cdktn.IResolvable;
    set routingHttpResponseServerEnabled(value: boolean | cdktn.IResolvable);
    resetRoutingHttpResponseServerEnabled(): void;
    get routingHttpResponseServerEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _routingHttpResponseStrictTransportSecurityHeaderValue?;
    get routingHttpResponseStrictTransportSecurityHeaderValue(): string;
    set routingHttpResponseStrictTransportSecurityHeaderValue(value: string);
    resetRoutingHttpResponseStrictTransportSecurityHeaderValue(): void;
    get routingHttpResponseStrictTransportSecurityHeaderValueInput(): string | undefined;
    private _routingHttpResponseXContentTypeOptionsHeaderValue?;
    get routingHttpResponseXContentTypeOptionsHeaderValue(): string;
    set routingHttpResponseXContentTypeOptionsHeaderValue(value: string);
    resetRoutingHttpResponseXContentTypeOptionsHeaderValue(): void;
    get routingHttpResponseXContentTypeOptionsHeaderValueInput(): string | undefined;
    private _routingHttpResponseXFrameOptionsHeaderValue?;
    get routingHttpResponseXFrameOptionsHeaderValue(): string;
    set routingHttpResponseXFrameOptionsHeaderValue(value: string);
    resetRoutingHttpResponseXFrameOptionsHeaderValue(): void;
    get routingHttpResponseXFrameOptionsHeaderValueInput(): string | undefined;
    private _sslPolicy?;
    get sslPolicy(): string;
    set sslPolicy(value: string);
    resetSslPolicy(): void;
    get sslPolicyInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _tcpIdleTimeoutSeconds?;
    get tcpIdleTimeoutSeconds(): number;
    set tcpIdleTimeoutSeconds(value: number);
    resetTcpIdleTimeoutSeconds(): void;
    get tcpIdleTimeoutSecondsInput(): number | undefined;
    private _defaultAction;
    get defaultAction(): AwsLbListener.DefaultActionPropertyList;
    putDefaultAction(value: AwsLbListener.DefaultActionProperty[] | cdktn.IResolvable): void;
    get defaultActionInput(): cdktn.IResolvable | AwsLbListener.DefaultActionProperty[] | undefined;
    private _mutualAuthentication;
    get mutualAuthentication(): AwsLbListener.MutualAuthenticationPropertyOutputReference;
    putMutualAuthentication(value: AwsLbListener.MutualAuthenticationProperty): void;
    resetMutualAuthentication(): void;
    get mutualAuthenticationInput(): AwsLbListener.MutualAuthenticationProperty | undefined;
    private _timeouts;
    get timeouts(): AwsLbListener.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsLbListener.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsLbListener.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsLbListenerAuthenticateCognitoPropertyToTerraform(struct?: AwsLbListener.AuthenticateCognitoPropertyOutputReference | AwsLbListener.AuthenticateCognitoProperty): any;
export declare function awsLbListenerAuthenticateCognitoPropertyToHclTerraform(struct?: AwsLbListener.AuthenticateCognitoPropertyOutputReference | AwsLbListener.AuthenticateCognitoProperty): any;
export declare function awsLbListenerAuthenticateOidcPropertyToTerraform(struct?: AwsLbListener.AuthenticateOidcPropertyOutputReference | AwsLbListener.AuthenticateOidcProperty): any;
export declare function awsLbListenerAuthenticateOidcPropertyToHclTerraform(struct?: AwsLbListener.AuthenticateOidcPropertyOutputReference | AwsLbListener.AuthenticateOidcProperty): any;
export declare function awsLbListenerFixedResponsePropertyToTerraform(struct?: AwsLbListener.FixedResponsePropertyOutputReference | AwsLbListener.FixedResponseProperty): any;
export declare function awsLbListenerFixedResponsePropertyToHclTerraform(struct?: AwsLbListener.FixedResponsePropertyOutputReference | AwsLbListener.FixedResponseProperty): any;
export declare function awsLbListenerStickinessPropertyToTerraform(struct?: AwsLbListener.StickinessPropertyOutputReference | AwsLbListener.StickinessProperty): any;
export declare function awsLbListenerStickinessPropertyToHclTerraform(struct?: AwsLbListener.StickinessPropertyOutputReference | AwsLbListener.StickinessProperty): any;
export declare function awsLbListenerTargetGroupPropertyToTerraform(struct?: AwsLbListener.TargetGroupProperty | cdktn.IResolvable): any;
export declare function awsLbListenerTargetGroupPropertyToHclTerraform(struct?: AwsLbListener.TargetGroupProperty | cdktn.IResolvable): any;
export declare function awsLbListenerForwardPropertyToTerraform(struct?: AwsLbListener.ForwardPropertyOutputReference | AwsLbListener.ForwardProperty): any;
export declare function awsLbListenerForwardPropertyToHclTerraform(struct?: AwsLbListener.ForwardPropertyOutputReference | AwsLbListener.ForwardProperty): any;
export declare function awsLbListenerAdditionalClaimPropertyToTerraform(struct?: AwsLbListener.AdditionalClaimProperty | cdktn.IResolvable): any;
export declare function awsLbListenerAdditionalClaimPropertyToHclTerraform(struct?: AwsLbListener.AdditionalClaimProperty | cdktn.IResolvable): any;
export declare function awsLbListenerJwtValidationPropertyToTerraform(struct?: AwsLbListener.JwtValidationPropertyOutputReference | AwsLbListener.JwtValidationProperty): any;
export declare function awsLbListenerJwtValidationPropertyToHclTerraform(struct?: AwsLbListener.JwtValidationPropertyOutputReference | AwsLbListener.JwtValidationProperty): any;
export declare function awsLbListenerRedirectPropertyToTerraform(struct?: AwsLbListener.RedirectPropertyOutputReference | AwsLbListener.RedirectProperty): any;
export declare function awsLbListenerRedirectPropertyToHclTerraform(struct?: AwsLbListener.RedirectPropertyOutputReference | AwsLbListener.RedirectProperty): any;
export declare function awsLbListenerDefaultActionPropertyToTerraform(struct?: AwsLbListener.DefaultActionProperty | cdktn.IResolvable): any;
export declare function awsLbListenerDefaultActionPropertyToHclTerraform(struct?: AwsLbListener.DefaultActionProperty | cdktn.IResolvable): any;
export declare function awsLbListenerMutualAuthenticationPropertyToTerraform(struct?: AwsLbListener.MutualAuthenticationPropertyOutputReference | AwsLbListener.MutualAuthenticationProperty): any;
export declare function awsLbListenerMutualAuthenticationPropertyToHclTerraform(struct?: AwsLbListener.MutualAuthenticationPropertyOutputReference | AwsLbListener.MutualAuthenticationProperty): any;
export declare function awsLbListenerTimeoutsPropertyToTerraform(struct?: AwsLbListener.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsLbListenerTimeoutsPropertyToHclTerraform(struct?: AwsLbListener.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsLbListener {
    interface AuthenticateCognitoProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_listener#authentication_request_extra_params AwsLbListener#authentication_request_extra_params}
        */
        readonly authenticationRequestExtraParams?: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_listener#on_unauthenticated_request AwsLbListener#on_unauthenticated_request}
        */
        readonly onUnauthenticatedRequest?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_listener#scope AwsLbListener#scope}
        */
        readonly scope?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_listener#session_cookie_name AwsLbListener#session_cookie_name}
        */
        readonly sessionCookieName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_listener#session_timeout AwsLbListener#session_timeout}
        */
        readonly sessionTimeout?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_listener#user_pool_arn AwsLbListener#user_pool_arn}
        */
        readonly userPoolArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_listener#user_pool_client_id AwsLbListener#user_pool_client_id}
        */
        readonly userPoolClientId: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_listener#user_pool_domain AwsLbListener#user_pool_domain}
        */
        readonly userPoolDomain: string;
    }
    class AuthenticateCognitoPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AuthenticateCognitoProperty | undefined;
        set internalValue(value: AuthenticateCognitoProperty | undefined);
        private _authenticationRequestExtraParams?;
        get authenticationRequestExtraParams(): {
            [key: string]: string;
        };
        set authenticationRequestExtraParams(value: {
            [key: string]: string;
        });
        resetAuthenticationRequestExtraParams(): void;
        get authenticationRequestExtraParamsInput(): {
            [key: string]: string;
        } | undefined;
        private _onUnauthenticatedRequest?;
        get onUnauthenticatedRequest(): string;
        set onUnauthenticatedRequest(value: string);
        resetOnUnauthenticatedRequest(): void;
        get onUnauthenticatedRequestInput(): string | undefined;
        private _scope?;
        get scope(): string;
        set scope(value: string);
        resetScope(): void;
        get scopeInput(): string | undefined;
        private _sessionCookieName?;
        get sessionCookieName(): string;
        set sessionCookieName(value: string);
        resetSessionCookieName(): void;
        get sessionCookieNameInput(): string | undefined;
        private _sessionTimeout?;
        get sessionTimeout(): number;
        set sessionTimeout(value: number);
        resetSessionTimeout(): void;
        get sessionTimeoutInput(): number | undefined;
        private _userPoolArn?;
        get userPoolArn(): string;
        set userPoolArn(value: string);
        get userPoolArnInput(): string | undefined;
        private _userPoolClientId?;
        get userPoolClientId(): string;
        set userPoolClientId(value: string);
        get userPoolClientIdInput(): string | undefined;
        private _userPoolDomain?;
        get userPoolDomain(): string;
        set userPoolDomain(value: string);
        get userPoolDomainInput(): string | undefined;
    }
    interface AuthenticateOidcProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_listener#authentication_request_extra_params AwsLbListener#authentication_request_extra_params}
        */
        readonly authenticationRequestExtraParams?: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_listener#authorization_endpoint AwsLbListener#authorization_endpoint}
        */
        readonly authorizationEndpoint: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_listener#client_id AwsLbListener#client_id}
        */
        readonly clientId: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_listener#client_secret AwsLbListener#client_secret}
        */
        readonly clientSecret: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_listener#issuer AwsLbListener#issuer}
        */
        readonly issuer: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_listener#on_unauthenticated_request AwsLbListener#on_unauthenticated_request}
        */
        readonly onUnauthenticatedRequest?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_listener#scope AwsLbListener#scope}
        */
        readonly scope?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_listener#session_cookie_name AwsLbListener#session_cookie_name}
        */
        readonly sessionCookieName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_listener#session_timeout AwsLbListener#session_timeout}
        */
        readonly sessionTimeout?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_listener#token_endpoint AwsLbListener#token_endpoint}
        */
        readonly tokenEndpoint: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_listener#user_info_endpoint AwsLbListener#user_info_endpoint}
        */
        readonly userInfoEndpoint: string;
    }
    class AuthenticateOidcPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AuthenticateOidcProperty | undefined;
        set internalValue(value: AuthenticateOidcProperty | undefined);
        private _authenticationRequestExtraParams?;
        get authenticationRequestExtraParams(): {
            [key: string]: string;
        };
        set authenticationRequestExtraParams(value: {
            [key: string]: string;
        });
        resetAuthenticationRequestExtraParams(): void;
        get authenticationRequestExtraParamsInput(): {
            [key: string]: string;
        } | undefined;
        private _authorizationEndpoint?;
        get authorizationEndpoint(): string;
        set authorizationEndpoint(value: string);
        get authorizationEndpointInput(): string | undefined;
        private _clientId?;
        get clientId(): string;
        set clientId(value: string);
        get clientIdInput(): string | undefined;
        private _clientSecret?;
        get clientSecret(): string;
        set clientSecret(value: string);
        get clientSecretInput(): string | undefined;
        private _issuer?;
        get issuer(): string;
        set issuer(value: string);
        get issuerInput(): string | undefined;
        private _onUnauthenticatedRequest?;
        get onUnauthenticatedRequest(): string;
        set onUnauthenticatedRequest(value: string);
        resetOnUnauthenticatedRequest(): void;
        get onUnauthenticatedRequestInput(): string | undefined;
        private _scope?;
        get scope(): string;
        set scope(value: string);
        resetScope(): void;
        get scopeInput(): string | undefined;
        private _sessionCookieName?;
        get sessionCookieName(): string;
        set sessionCookieName(value: string);
        resetSessionCookieName(): void;
        get sessionCookieNameInput(): string | undefined;
        private _sessionTimeout?;
        get sessionTimeout(): number;
        set sessionTimeout(value: number);
        resetSessionTimeout(): void;
        get sessionTimeoutInput(): number | undefined;
        private _tokenEndpoint?;
        get tokenEndpoint(): string;
        set tokenEndpoint(value: string);
        get tokenEndpointInput(): string | undefined;
        private _userInfoEndpoint?;
        get userInfoEndpoint(): string;
        set userInfoEndpoint(value: string);
        get userInfoEndpointInput(): string | undefined;
    }
    interface FixedResponseProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_listener#content_type AwsLbListener#content_type}
        */
        readonly contentType: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_listener#message_body AwsLbListener#message_body}
        */
        readonly messageBody?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_listener#status_code AwsLbListener#status_code}
        */
        readonly statusCode?: string;
    }
    class FixedResponsePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): FixedResponseProperty | undefined;
        set internalValue(value: FixedResponseProperty | undefined);
        private _contentType?;
        get contentType(): string;
        set contentType(value: string);
        get contentTypeInput(): string | undefined;
        private _messageBody?;
        get messageBody(): string;
        set messageBody(value: string);
        resetMessageBody(): void;
        get messageBodyInput(): string | undefined;
        private _statusCode?;
        get statusCode(): string;
        set statusCode(value: string);
        resetStatusCode(): void;
        get statusCodeInput(): string | undefined;
    }
    interface StickinessProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_listener#duration AwsLbListener#duration}
        */
        readonly duration: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_listener#enabled AwsLbListener#enabled}
        */
        readonly enabled?: boolean | cdktn.IResolvable;
    }
    class StickinessPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): StickinessProperty | undefined;
        set internalValue(value: StickinessProperty | undefined);
        private _duration?;
        get duration(): number;
        set duration(value: number);
        get durationInput(): number | undefined;
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        resetEnabled(): void;
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface TargetGroupProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_listener#arn AwsLbListener#arn}
        */
        readonly arn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_listener#weight AwsLbListener#weight}
        */
        readonly weight?: number;
    }
    class TargetGroupPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TargetGroupProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TargetGroupProperty | cdktn.IResolvable | undefined);
        private _arn?;
        get arn(): string;
        set arn(value: string);
        get arnInput(): string | undefined;
        private _weight?;
        get weight(): number;
        set weight(value: number);
        resetWeight(): void;
        get weightInput(): number | undefined;
    }
    class TargetGroupPropertyList extends cdktn.ComplexList {
        internalValue?: TargetGroupProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TargetGroupPropertyOutputReference;
    }
    interface ForwardProperty {
        /**
        * stickiness block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_listener#stickiness AwsLbListener#stickiness}
        */
        readonly stickiness?: StickinessProperty;
        /**
        * target_group block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_listener#target_group AwsLbListener#target_group}
        */
        readonly targetGroup: TargetGroupProperty[] | cdktn.IResolvable;
    }
    class ForwardPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ForwardProperty | undefined;
        set internalValue(value: ForwardProperty | undefined);
        private _stickiness;
        get stickiness(): StickinessPropertyOutputReference;
        putStickiness(value: StickinessProperty): void;
        resetStickiness(): void;
        get stickinessInput(): StickinessProperty | undefined;
        private _targetGroup;
        get targetGroup(): TargetGroupPropertyList;
        putTargetGroup(value: TargetGroupProperty[] | cdktn.IResolvable): void;
        get targetGroupInput(): cdktn.IResolvable | TargetGroupProperty[] | undefined;
    }
    interface AdditionalClaimProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_listener#format AwsLbListener#format}
        */
        readonly format: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_listener#name AwsLbListener#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_listener#values AwsLbListener#values}
        */
        readonly values: string[];
    }
    class AdditionalClaimPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AdditionalClaimProperty | cdktn.IResolvable | undefined;
        set internalValue(value: AdditionalClaimProperty | cdktn.IResolvable | undefined);
        private _format?;
        get format(): string;
        set format(value: string);
        get formatInput(): string | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        get valuesInput(): string[] | undefined;
    }
    class AdditionalClaimPropertyList extends cdktn.ComplexList {
        internalValue?: AdditionalClaimProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AdditionalClaimPropertyOutputReference;
    }
    interface JwtValidationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_listener#issuer AwsLbListener#issuer}
        */
        readonly issuer: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_listener#jwks_endpoint AwsLbListener#jwks_endpoint}
        */
        readonly jwksEndpoint: string;
        /**
        * additional_claim block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_listener#additional_claim AwsLbListener#additional_claim}
        */
        readonly additionalClaim?: AdditionalClaimProperty[] | cdktn.IResolvable;
    }
    class JwtValidationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): JwtValidationProperty | undefined;
        set internalValue(value: JwtValidationProperty | undefined);
        private _issuer?;
        get issuer(): string;
        set issuer(value: string);
        get issuerInput(): string | undefined;
        private _jwksEndpoint?;
        get jwksEndpoint(): string;
        set jwksEndpoint(value: string);
        get jwksEndpointInput(): string | undefined;
        private _additionalClaim;
        get additionalClaim(): AdditionalClaimPropertyList;
        putAdditionalClaim(value: AdditionalClaimProperty[] | cdktn.IResolvable): void;
        resetAdditionalClaim(): void;
        get additionalClaimInput(): cdktn.IResolvable | AdditionalClaimProperty[] | undefined;
    }
    interface RedirectProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_listener#host AwsLbListener#host}
        */
        readonly host?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_listener#path AwsLbListener#path}
        */
        readonly path?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_listener#port AwsLbListener#port}
        */
        readonly port?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_listener#protocol AwsLbListener#protocol}
        */
        readonly protocol?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_listener#query AwsLbListener#query}
        */
        readonly query?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_listener#status_code AwsLbListener#status_code}
        */
        readonly statusCode: string;
    }
    class RedirectPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RedirectProperty | undefined;
        set internalValue(value: RedirectProperty | undefined);
        private _host?;
        get host(): string;
        set host(value: string);
        resetHost(): void;
        get hostInput(): string | undefined;
        private _path?;
        get path(): string;
        set path(value: string);
        resetPath(): void;
        get pathInput(): string | undefined;
        private _port?;
        get port(): string;
        set port(value: string);
        resetPort(): void;
        get portInput(): string | undefined;
        private _protocol?;
        get protocol(): string;
        set protocol(value: string);
        resetProtocol(): void;
        get protocolInput(): string | undefined;
        private _query?;
        get query(): string;
        set query(value: string);
        resetQuery(): void;
        get queryInput(): string | undefined;
        private _statusCode?;
        get statusCode(): string;
        set statusCode(value: string);
        get statusCodeInput(): string | undefined;
    }
    interface DefaultActionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_listener#order AwsLbListener#order}
        */
        readonly order?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_listener#target_group_arn AwsLbListener#target_group_arn}
        */
        readonly targetGroupArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_listener#type AwsLbListener#type}
        */
        readonly type: string;
        /**
        * authenticate_cognito block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_listener#authenticate_cognito AwsLbListener#authenticate_cognito}
        */
        readonly authenticateCognito?: AuthenticateCognitoProperty;
        /**
        * authenticate_oidc block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_listener#authenticate_oidc AwsLbListener#authenticate_oidc}
        */
        readonly authenticateOidc?: AuthenticateOidcProperty;
        /**
        * fixed_response block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_listener#fixed_response AwsLbListener#fixed_response}
        */
        readonly fixedResponse?: FixedResponseProperty;
        /**
        * forward block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_listener#forward AwsLbListener#forward}
        */
        readonly forward?: ForwardProperty;
        /**
        * jwt_validation block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_listener#jwt_validation AwsLbListener#jwt_validation}
        */
        readonly jwtValidation?: JwtValidationProperty;
        /**
        * redirect block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_listener#redirect AwsLbListener#redirect}
        */
        readonly redirect?: RedirectProperty;
    }
    class DefaultActionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DefaultActionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DefaultActionProperty | cdktn.IResolvable | undefined);
        private _order?;
        get order(): number;
        set order(value: number);
        resetOrder(): void;
        get orderInput(): number | undefined;
        private _targetGroupArn?;
        get targetGroupArn(): string;
        set targetGroupArn(value: string);
        resetTargetGroupArn(): void;
        get targetGroupArnInput(): string | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
        private _authenticateCognito;
        get authenticateCognito(): AuthenticateCognitoPropertyOutputReference;
        putAuthenticateCognito(value: AuthenticateCognitoProperty): void;
        resetAuthenticateCognito(): void;
        get authenticateCognitoInput(): AuthenticateCognitoProperty | undefined;
        private _authenticateOidc;
        get authenticateOidc(): AuthenticateOidcPropertyOutputReference;
        putAuthenticateOidc(value: AuthenticateOidcProperty): void;
        resetAuthenticateOidc(): void;
        get authenticateOidcInput(): AuthenticateOidcProperty | undefined;
        private _fixedResponse;
        get fixedResponse(): FixedResponsePropertyOutputReference;
        putFixedResponse(value: FixedResponseProperty): void;
        resetFixedResponse(): void;
        get fixedResponseInput(): FixedResponseProperty | undefined;
        private _forward;
        get forward(): ForwardPropertyOutputReference;
        putForward(value: ForwardProperty): void;
        resetForward(): void;
        get forwardInput(): ForwardProperty | undefined;
        private _jwtValidation;
        get jwtValidation(): JwtValidationPropertyOutputReference;
        putJwtValidation(value: JwtValidationProperty): void;
        resetJwtValidation(): void;
        get jwtValidationInput(): JwtValidationProperty | undefined;
        private _redirect;
        get redirect(): RedirectPropertyOutputReference;
        putRedirect(value: RedirectProperty): void;
        resetRedirect(): void;
        get redirectInput(): RedirectProperty | undefined;
    }
    class DefaultActionPropertyList extends cdktn.ComplexList {
        internalValue?: DefaultActionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DefaultActionPropertyOutputReference;
    }
    interface MutualAuthenticationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_listener#advertise_trust_store_ca_names AwsLbListener#advertise_trust_store_ca_names}
        */
        readonly advertiseTrustStoreCaNames?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_listener#ignore_client_certificate_expiry AwsLbListener#ignore_client_certificate_expiry}
        */
        readonly ignoreClientCertificateExpiry?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_listener#mode AwsLbListener#mode}
        */
        readonly mode: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_listener#trust_store_arn AwsLbListener#trust_store_arn}
        */
        readonly trustStoreArn?: string;
    }
    class MutualAuthenticationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): MutualAuthenticationProperty | undefined;
        set internalValue(value: MutualAuthenticationProperty | undefined);
        private _advertiseTrustStoreCaNames?;
        get advertiseTrustStoreCaNames(): string;
        set advertiseTrustStoreCaNames(value: string);
        resetAdvertiseTrustStoreCaNames(): void;
        get advertiseTrustStoreCaNamesInput(): string | undefined;
        private _ignoreClientCertificateExpiry?;
        get ignoreClientCertificateExpiry(): boolean | cdktn.IResolvable;
        set ignoreClientCertificateExpiry(value: boolean | cdktn.IResolvable);
        resetIgnoreClientCertificateExpiry(): void;
        get ignoreClientCertificateExpiryInput(): boolean | cdktn.IResolvable | undefined;
        private _mode?;
        get mode(): string;
        set mode(value: string);
        get modeInput(): string | undefined;
        private _trustStoreArn?;
        get trustStoreArn(): string;
        set trustStoreArn(value: string);
        resetTrustStoreArn(): void;
        get trustStoreArnInput(): string | undefined;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_listener#create AwsLbListener#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_listener#update AwsLbListener#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
