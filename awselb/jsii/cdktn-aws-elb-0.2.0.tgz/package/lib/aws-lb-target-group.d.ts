import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfTargetGroupConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_target_group#connection_termination TfTargetGroup#connection_termination}
    */
    readonly connectionTermination?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_target_group#deregistration_delay TfTargetGroup#deregistration_delay}
    */
    readonly deregistrationDelay?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_target_group#id TfTargetGroup#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_target_group#ip_address_type TfTargetGroup#ip_address_type}
    */
    readonly ipAddressType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_target_group#lambda_multi_value_headers_enabled TfTargetGroup#lambda_multi_value_headers_enabled}
    */
    readonly lambdaMultiValueHeadersEnabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_target_group#load_balancing_algorithm_type TfTargetGroup#load_balancing_algorithm_type}
    */
    readonly loadBalancingAlgorithmType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_target_group#load_balancing_anomaly_mitigation TfTargetGroup#load_balancing_anomaly_mitigation}
    */
    readonly loadBalancingAnomalyMitigation?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_target_group#load_balancing_cross_zone_enabled TfTargetGroup#load_balancing_cross_zone_enabled}
    */
    readonly loadBalancingCrossZoneEnabled?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_target_group#name TfTargetGroup#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_target_group#name_prefix TfTargetGroup#name_prefix}
    */
    readonly namePrefix?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_target_group#port TfTargetGroup#port}
    */
    readonly port?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_target_group#preserve_client_ip TfTargetGroup#preserve_client_ip}
    */
    readonly preserveClientIp?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_target_group#protocol TfTargetGroup#protocol}
    */
    readonly protocol?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_target_group#protocol_version TfTargetGroup#protocol_version}
    */
    readonly protocolVersion?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_target_group#proxy_protocol_v2 TfTargetGroup#proxy_protocol_v2}
    */
    readonly proxyProtocolV2?: boolean | cdktn.IResolvable;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_target_group#region TfTargetGroup#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_target_group#slow_start TfTargetGroup#slow_start}
    */
    readonly slowStart?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_target_group#tags TfTargetGroup#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_target_group#tags_all TfTargetGroup#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_target_group#target_control_port TfTargetGroup#target_control_port}
    */
    readonly targetControlPort?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_target_group#target_type TfTargetGroup#target_type}
    */
    readonly targetType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_target_group#vpc_id TfTargetGroup#vpc_id}
    */
    readonly vpcId?: string;
    /**
    * health_check block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_target_group#health_check TfTargetGroup#health_check}
    */
    readonly healthCheck?: TfTargetGroup.HealthCheckProperty;
    /**
    * stickiness block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_target_group#stickiness TfTargetGroup#stickiness}
    */
    readonly stickiness?: TfTargetGroup.StickinessProperty;
    /**
    * target_failover block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_target_group#target_failover TfTargetGroup#target_failover}
    */
    readonly targetFailover?: TfTargetGroup.TargetFailoverProperty[] | cdktn.IResolvable;
    /**
    * target_group_health block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_target_group#target_group_health TfTargetGroup#target_group_health}
    */
    readonly targetGroupHealth?: TfTargetGroup.TargetGroupHealthProperty;
    /**
    * target_health_state block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_target_group#target_health_state TfTargetGroup#target_health_state}
    */
    readonly targetHealthState?: TfTargetGroup.TargetHealthStateProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_target_group aws_lb_target_group}
*/
export declare class TfTargetGroup extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_lb_target_group";
    /**
    * Generates CDKTN code for importing a TfTargetGroup resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfTargetGroup to import
    * @param importFromId The id of the existing TfTargetGroup that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_target_group#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfTargetGroup to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_target_group aws_lb_target_group} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfTargetGroupConfig = {}
    */
    constructor(scope: Construct, id: string, config?: TfTargetGroupConfig);
    get arn(): string;
    get arnSuffix(): string;
    private _connectionTermination?;
    get connectionTermination(): boolean | cdktn.IResolvable;
    set connectionTermination(value: boolean | cdktn.IResolvable);
    resetConnectionTermination(): void;
    get connectionTerminationInput(): boolean | cdktn.IResolvable | undefined;
    private _deregistrationDelay?;
    get deregistrationDelay(): string;
    set deregistrationDelay(value: string);
    resetDeregistrationDelay(): void;
    get deregistrationDelayInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _ipAddressType?;
    get ipAddressType(): string;
    set ipAddressType(value: string);
    resetIpAddressType(): void;
    get ipAddressTypeInput(): string | undefined;
    private _lambdaMultiValueHeadersEnabled?;
    get lambdaMultiValueHeadersEnabled(): boolean | cdktn.IResolvable;
    set lambdaMultiValueHeadersEnabled(value: boolean | cdktn.IResolvable);
    resetLambdaMultiValueHeadersEnabled(): void;
    get lambdaMultiValueHeadersEnabledInput(): boolean | cdktn.IResolvable | undefined;
    get loadBalancerArns(): string[];
    private _loadBalancingAlgorithmType?;
    get loadBalancingAlgorithmType(): string;
    set loadBalancingAlgorithmType(value: string);
    resetLoadBalancingAlgorithmType(): void;
    get loadBalancingAlgorithmTypeInput(): string | undefined;
    private _loadBalancingAnomalyMitigation?;
    get loadBalancingAnomalyMitigation(): string;
    set loadBalancingAnomalyMitigation(value: string);
    resetLoadBalancingAnomalyMitigation(): void;
    get loadBalancingAnomalyMitigationInput(): string | undefined;
    private _loadBalancingCrossZoneEnabled?;
    get loadBalancingCrossZoneEnabled(): string;
    set loadBalancingCrossZoneEnabled(value: string);
    resetLoadBalancingCrossZoneEnabled(): void;
    get loadBalancingCrossZoneEnabledInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _namePrefix?;
    get namePrefix(): string;
    set namePrefix(value: string);
    resetNamePrefix(): void;
    get namePrefixInput(): string | undefined;
    private _port?;
    get port(): number;
    set port(value: number);
    resetPort(): void;
    get portInput(): number | undefined;
    private _preserveClientIp?;
    get preserveClientIp(): string;
    set preserveClientIp(value: string);
    resetPreserveClientIp(): void;
    get preserveClientIpInput(): string | undefined;
    private _protocol?;
    get protocol(): string;
    set protocol(value: string);
    resetProtocol(): void;
    get protocolInput(): string | undefined;
    private _protocolVersion?;
    get protocolVersion(): string;
    set protocolVersion(value: string);
    resetProtocolVersion(): void;
    get protocolVersionInput(): string | undefined;
    private _proxyProtocolV2?;
    get proxyProtocolV2(): boolean | cdktn.IResolvable;
    set proxyProtocolV2(value: boolean | cdktn.IResolvable);
    resetProxyProtocolV2(): void;
    get proxyProtocolV2Input(): boolean | cdktn.IResolvable | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _slowStart?;
    get slowStart(): number;
    set slowStart(value: number);
    resetSlowStart(): void;
    get slowStartInput(): number | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _targetControlPort?;
    get targetControlPort(): number;
    set targetControlPort(value: number);
    resetTargetControlPort(): void;
    get targetControlPortInput(): number | undefined;
    private _targetType?;
    get targetType(): string;
    set targetType(value: string);
    resetTargetType(): void;
    get targetTypeInput(): string | undefined;
    private _vpcId?;
    get vpcId(): string;
    set vpcId(value: string);
    resetVpcId(): void;
    get vpcIdInput(): string | undefined;
    private _healthCheck;
    get healthCheck(): TfTargetGroup.HealthCheckPropertyOutputReference;
    putHealthCheck(value: TfTargetGroup.HealthCheckProperty): void;
    resetHealthCheck(): void;
    get healthCheckInput(): TfTargetGroup.HealthCheckProperty | undefined;
    private _stickiness;
    get stickiness(): TfTargetGroup.StickinessPropertyOutputReference;
    putStickiness(value: TfTargetGroup.StickinessProperty): void;
    resetStickiness(): void;
    get stickinessInput(): TfTargetGroup.StickinessProperty | undefined;
    private _targetFailover;
    get targetFailover(): TfTargetGroup.TargetFailoverPropertyList;
    putTargetFailover(value: TfTargetGroup.TargetFailoverProperty[] | cdktn.IResolvable): void;
    resetTargetFailover(): void;
    get targetFailoverInput(): cdktn.IResolvable | TfTargetGroup.TargetFailoverProperty[] | undefined;
    private _targetGroupHealth;
    get targetGroupHealth(): TfTargetGroup.TargetGroupHealthPropertyOutputReference;
    putTargetGroupHealth(value: TfTargetGroup.TargetGroupHealthProperty): void;
    resetTargetGroupHealth(): void;
    get targetGroupHealthInput(): TfTargetGroup.TargetGroupHealthProperty | undefined;
    private _targetHealthState;
    get targetHealthState(): TfTargetGroup.TargetHealthStatePropertyList;
    putTargetHealthState(value: TfTargetGroup.TargetHealthStateProperty[] | cdktn.IResolvable): void;
    resetTargetHealthState(): void;
    get targetHealthStateInput(): cdktn.IResolvable | TfTargetGroup.TargetHealthStateProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfTargetGroupHealthCheckPropertyToTerraform(struct?: TfTargetGroup.HealthCheckPropertyOutputReference | TfTargetGroup.HealthCheckProperty): any;
export declare function tfTargetGroupHealthCheckPropertyToHclTerraform(struct?: TfTargetGroup.HealthCheckPropertyOutputReference | TfTargetGroup.HealthCheckProperty): any;
export declare function tfTargetGroupStickinessPropertyToTerraform(struct?: TfTargetGroup.StickinessPropertyOutputReference | TfTargetGroup.StickinessProperty): any;
export declare function tfTargetGroupStickinessPropertyToHclTerraform(struct?: TfTargetGroup.StickinessPropertyOutputReference | TfTargetGroup.StickinessProperty): any;
export declare function tfTargetGroupTargetFailoverPropertyToTerraform(struct?: TfTargetGroup.TargetFailoverProperty | cdktn.IResolvable): any;
export declare function tfTargetGroupTargetFailoverPropertyToHclTerraform(struct?: TfTargetGroup.TargetFailoverProperty | cdktn.IResolvable): any;
export declare function tfTargetGroupDnsFailoverPropertyToTerraform(struct?: TfTargetGroup.DnsFailoverPropertyOutputReference | TfTargetGroup.DnsFailoverProperty): any;
export declare function tfTargetGroupDnsFailoverPropertyToHclTerraform(struct?: TfTargetGroup.DnsFailoverPropertyOutputReference | TfTargetGroup.DnsFailoverProperty): any;
export declare function tfTargetGroupUnhealthyStateRoutingPropertyToTerraform(struct?: TfTargetGroup.UnhealthyStateRoutingPropertyOutputReference | TfTargetGroup.UnhealthyStateRoutingProperty): any;
export declare function tfTargetGroupUnhealthyStateRoutingPropertyToHclTerraform(struct?: TfTargetGroup.UnhealthyStateRoutingPropertyOutputReference | TfTargetGroup.UnhealthyStateRoutingProperty): any;
export declare function tfTargetGroupTargetGroupHealthPropertyToTerraform(struct?: TfTargetGroup.TargetGroupHealthPropertyOutputReference | TfTargetGroup.TargetGroupHealthProperty): any;
export declare function tfTargetGroupTargetGroupHealthPropertyToHclTerraform(struct?: TfTargetGroup.TargetGroupHealthPropertyOutputReference | TfTargetGroup.TargetGroupHealthProperty): any;
export declare function tfTargetGroupTargetHealthStatePropertyToTerraform(struct?: TfTargetGroup.TargetHealthStateProperty | cdktn.IResolvable): any;
export declare function tfTargetGroupTargetHealthStatePropertyToHclTerraform(struct?: TfTargetGroup.TargetHealthStateProperty | cdktn.IResolvable): any;
export declare namespace TfTargetGroup {
    interface HealthCheckProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_target_group#enabled TfTargetGroup#enabled}
        */
        readonly enabled?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_target_group#healthy_threshold TfTargetGroup#healthy_threshold}
        */
        readonly healthyThreshold?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_target_group#interval TfTargetGroup#interval}
        */
        readonly interval?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_target_group#matcher TfTargetGroup#matcher}
        */
        readonly matcher?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_target_group#path TfTargetGroup#path}
        */
        readonly path?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_target_group#port TfTargetGroup#port}
        */
        readonly port?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_target_group#protocol TfTargetGroup#protocol}
        */
        readonly protocol?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_target_group#timeout TfTargetGroup#timeout}
        */
        readonly timeout?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_target_group#unhealthy_threshold TfTargetGroup#unhealthy_threshold}
        */
        readonly unhealthyThreshold?: number;
    }
    class HealthCheckPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): HealthCheckProperty | undefined;
        set internalValue(value: HealthCheckProperty | undefined);
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        resetEnabled(): void;
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
        private _healthyThreshold?;
        get healthyThreshold(): number;
        set healthyThreshold(value: number);
        resetHealthyThreshold(): void;
        get healthyThresholdInput(): number | undefined;
        private _interval?;
        get interval(): number;
        set interval(value: number);
        resetInterval(): void;
        get intervalInput(): number | undefined;
        private _matcher?;
        get matcher(): string;
        set matcher(value: string);
        resetMatcher(): void;
        get matcherInput(): string | undefined;
        private _path?;
        get path(): string;
        set path(value: string);
        resetPath(): void;
        get pathInput(): string | undefined;
        private _port?;
        get port(): string;
        set port(value: string);
        resetPort(): void;
        get portInput(): string | undefined;
        private _protocol?;
        get protocol(): string;
        set protocol(value: string);
        resetProtocol(): void;
        get protocolInput(): string | undefined;
        private _timeout?;
        get timeout(): number;
        set timeout(value: number);
        resetTimeout(): void;
        get timeoutInput(): number | undefined;
        private _unhealthyThreshold?;
        get unhealthyThreshold(): number;
        set unhealthyThreshold(value: number);
        resetUnhealthyThreshold(): void;
        get unhealthyThresholdInput(): number | undefined;
    }
    interface StickinessProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_target_group#cookie_duration TfTargetGroup#cookie_duration}
        */
        readonly cookieDuration?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_target_group#cookie_name TfTargetGroup#cookie_name}
        */
        readonly cookieName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_target_group#enabled TfTargetGroup#enabled}
        */
        readonly enabled?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_target_group#type TfTargetGroup#type}
        */
        readonly type: string;
    }
    class StickinessPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): StickinessProperty | undefined;
        set internalValue(value: StickinessProperty | undefined);
        private _cookieDuration?;
        get cookieDuration(): number;
        set cookieDuration(value: number);
        resetCookieDuration(): void;
        get cookieDurationInput(): number | undefined;
        private _cookieName?;
        get cookieName(): string;
        set cookieName(value: string);
        resetCookieName(): void;
        get cookieNameInput(): string | undefined;
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        resetEnabled(): void;
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
    }
    interface TargetFailoverProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_target_group#on_deregistration TfTargetGroup#on_deregistration}
        */
        readonly onDeregistration: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_target_group#on_unhealthy TfTargetGroup#on_unhealthy}
        */
        readonly onUnhealthy: string;
    }
    class TargetFailoverPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TargetFailoverProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TargetFailoverProperty | cdktn.IResolvable | undefined);
        private _onDeregistration?;
        get onDeregistration(): string;
        set onDeregistration(value: string);
        get onDeregistrationInput(): string | undefined;
        private _onUnhealthy?;
        get onUnhealthy(): string;
        set onUnhealthy(value: string);
        get onUnhealthyInput(): string | undefined;
    }
    class TargetFailoverPropertyList extends cdktn.ComplexList {
        internalValue?: TargetFailoverProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TargetFailoverPropertyOutputReference;
    }
    interface DnsFailoverProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_target_group#minimum_healthy_targets_count TfTargetGroup#minimum_healthy_targets_count}
        */
        readonly minimumHealthyTargetsCount?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_target_group#minimum_healthy_targets_percentage TfTargetGroup#minimum_healthy_targets_percentage}
        */
        readonly minimumHealthyTargetsPercentage?: string;
    }
    class DnsFailoverPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DnsFailoverProperty | undefined;
        set internalValue(value: DnsFailoverProperty | undefined);
        private _minimumHealthyTargetsCount?;
        get minimumHealthyTargetsCount(): string;
        set minimumHealthyTargetsCount(value: string);
        resetMinimumHealthyTargetsCount(): void;
        get minimumHealthyTargetsCountInput(): string | undefined;
        private _minimumHealthyTargetsPercentage?;
        get minimumHealthyTargetsPercentage(): string;
        set minimumHealthyTargetsPercentage(value: string);
        resetMinimumHealthyTargetsPercentage(): void;
        get minimumHealthyTargetsPercentageInput(): string | undefined;
    }
    interface UnhealthyStateRoutingProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_target_group#minimum_healthy_targets_count TfTargetGroup#minimum_healthy_targets_count}
        */
        readonly minimumHealthyTargetsCount?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_target_group#minimum_healthy_targets_percentage TfTargetGroup#minimum_healthy_targets_percentage}
        */
        readonly minimumHealthyTargetsPercentage?: string;
    }
    class UnhealthyStateRoutingPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): UnhealthyStateRoutingProperty | undefined;
        set internalValue(value: UnhealthyStateRoutingProperty | undefined);
        private _minimumHealthyTargetsCount?;
        get minimumHealthyTargetsCount(): number;
        set minimumHealthyTargetsCount(value: number);
        resetMinimumHealthyTargetsCount(): void;
        get minimumHealthyTargetsCountInput(): number | undefined;
        private _minimumHealthyTargetsPercentage?;
        get minimumHealthyTargetsPercentage(): string;
        set minimumHealthyTargetsPercentage(value: string);
        resetMinimumHealthyTargetsPercentage(): void;
        get minimumHealthyTargetsPercentageInput(): string | undefined;
    }
    interface TargetGroupHealthProperty {
        /**
        * dns_failover block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_target_group#dns_failover TfTargetGroup#dns_failover}
        */
        readonly dnsFailover?: DnsFailoverProperty;
        /**
        * unhealthy_state_routing block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_target_group#unhealthy_state_routing TfTargetGroup#unhealthy_state_routing}
        */
        readonly unhealthyStateRouting?: UnhealthyStateRoutingProperty;
    }
    class TargetGroupHealthPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TargetGroupHealthProperty | undefined;
        set internalValue(value: TargetGroupHealthProperty | undefined);
        private _dnsFailover;
        get dnsFailover(): DnsFailoverPropertyOutputReference;
        putDnsFailover(value: DnsFailoverProperty): void;
        resetDnsFailover(): void;
        get dnsFailoverInput(): DnsFailoverProperty | undefined;
        private _unhealthyStateRouting;
        get unhealthyStateRouting(): UnhealthyStateRoutingPropertyOutputReference;
        putUnhealthyStateRouting(value: UnhealthyStateRoutingProperty): void;
        resetUnhealthyStateRouting(): void;
        get unhealthyStateRoutingInput(): UnhealthyStateRoutingProperty | undefined;
    }
    interface TargetHealthStateProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_target_group#enable_unhealthy_connection_termination TfTargetGroup#enable_unhealthy_connection_termination}
        */
        readonly enableUnhealthyConnectionTermination: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb_target_group#unhealthy_draining_interval TfTargetGroup#unhealthy_draining_interval}
        */
        readonly unhealthyDrainingInterval?: number;
    }
    class TargetHealthStatePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TargetHealthStateProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TargetHealthStateProperty | cdktn.IResolvable | undefined);
        private _enableUnhealthyConnectionTermination?;
        get enableUnhealthyConnectionTermination(): boolean | cdktn.IResolvable;
        set enableUnhealthyConnectionTermination(value: boolean | cdktn.IResolvable);
        get enableUnhealthyConnectionTerminationInput(): boolean | cdktn.IResolvable | undefined;
        private _unhealthyDrainingInterval?;
        get unhealthyDrainingInterval(): number;
        set unhealthyDrainingInterval(value: number);
        resetUnhealthyDrainingInterval(): void;
        get unhealthyDrainingIntervalInput(): number | undefined;
    }
    class TargetHealthStatePropertyList extends cdktn.ComplexList {
        internalValue?: TargetHealthStateProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TargetHealthStatePropertyOutputReference;
    }
}
