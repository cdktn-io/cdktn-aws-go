import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfLbConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb#client_keep_alive TfLb#client_keep_alive}
    */
    readonly clientKeepAlive?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb#customer_owned_ipv4_pool TfLb#customer_owned_ipv4_pool}
    */
    readonly customerOwnedIpv4Pool?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb#desync_mitigation_mode TfLb#desync_mitigation_mode}
    */
    readonly desyncMitigationMode?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb#dns_record_client_routing_policy TfLb#dns_record_client_routing_policy}
    */
    readonly dnsRecordClientRoutingPolicy?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb#drop_invalid_header_fields TfLb#drop_invalid_header_fields}
    */
    readonly dropInvalidHeaderFields?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb#enable_cross_zone_load_balancing TfLb#enable_cross_zone_load_balancing}
    */
    readonly enableCrossZoneLoadBalancing?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb#enable_deletion_protection TfLb#enable_deletion_protection}
    */
    readonly enableDeletionProtection?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb#enable_http2 TfLb#enable_http2}
    */
    readonly enableHttp2?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb#enable_prefix_for_ipv6_source_nat TfLb#enable_prefix_for_ipv6_source_nat}
    */
    readonly enablePrefixForIpv6SourceNat?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb#enable_tls_version_and_cipher_suite_headers TfLb#enable_tls_version_and_cipher_suite_headers}
    */
    readonly enableTlsVersionAndCipherSuiteHeaders?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb#enable_waf_fail_open TfLb#enable_waf_fail_open}
    */
    readonly enableWafFailOpen?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb#enable_xff_client_port TfLb#enable_xff_client_port}
    */
    readonly enableXffClientPort?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb#enable_zonal_shift TfLb#enable_zonal_shift}
    */
    readonly enableZonalShift?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb#enforce_security_group_inbound_rules_on_private_link_traffic TfLb#enforce_security_group_inbound_rules_on_private_link_traffic}
    */
    readonly enforceSecurityGroupInboundRulesOnPrivateLinkTraffic?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb#id TfLb#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb#idle_timeout TfLb#idle_timeout}
    */
    readonly idleTimeout?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb#internal TfLb#internal}
    */
    readonly internal?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb#ip_address_type TfLb#ip_address_type}
    */
    readonly ipAddressType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb#load_balancer_type TfLb#load_balancer_type}
    */
    readonly loadBalancerType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb#name TfLb#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb#name_prefix TfLb#name_prefix}
    */
    readonly namePrefix?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb#preserve_host_header TfLb#preserve_host_header}
    */
    readonly preserveHostHeader?: boolean | cdktn.IResolvable;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb#region TfLb#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb#secondary_ips_auto_assigned_per_subnet TfLb#secondary_ips_auto_assigned_per_subnet}
    */
    readonly secondaryIpsAutoAssignedPerSubnet?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb#security_groups TfLb#security_groups}
    */
    readonly securityGroups?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb#subnets TfLb#subnets}
    */
    readonly subnets?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb#tags TfLb#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb#tags_all TfLb#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb#xff_header_processing_mode TfLb#xff_header_processing_mode}
    */
    readonly xffHeaderProcessingMode?: string;
    /**
    * access_logs block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb#access_logs TfLb#access_logs}
    */
    readonly accessLogs?: TfLb.AccessLogsProperty;
    /**
    * connection_logs block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb#connection_logs TfLb#connection_logs}
    */
    readonly connectionLogs?: TfLb.ConnectionLogsProperty;
    /**
    * health_check_logs block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb#health_check_logs TfLb#health_check_logs}
    */
    readonly healthCheckLogs?: TfLb.HealthCheckLogsProperty;
    /**
    * ipam_pools block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb#ipam_pools TfLb#ipam_pools}
    */
    readonly ipamPools?: TfLb.IpamPoolsProperty;
    /**
    * minimum_load_balancer_capacity block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb#minimum_load_balancer_capacity TfLb#minimum_load_balancer_capacity}
    */
    readonly minimumLoadBalancerCapacity?: TfLb.MinimumLoadBalancerCapacityProperty;
    /**
    * subnet_mapping block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb#subnet_mapping TfLb#subnet_mapping}
    */
    readonly subnetMapping?: TfLb.SubnetMappingProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb#timeouts TfLb#timeouts}
    */
    readonly timeouts?: TfLb.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb aws_lb}
*/
export declare class TfLb extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_lb";
    /**
    * Generates CDKTN code for importing a TfLb resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfLb to import
    * @param importFromId The id of the existing TfLb that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfLb to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb aws_lb} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfLbConfig = {}
    */
    constructor(scope: Construct, id: string, config?: TfLbConfig);
    get arn(): string;
    get arnSuffix(): string;
    private _clientKeepAlive?;
    get clientKeepAlive(): number;
    set clientKeepAlive(value: number);
    resetClientKeepAlive(): void;
    get clientKeepAliveInput(): number | undefined;
    private _customerOwnedIpv4Pool?;
    get customerOwnedIpv4Pool(): string;
    set customerOwnedIpv4Pool(value: string);
    resetCustomerOwnedIpv4Pool(): void;
    get customerOwnedIpv4PoolInput(): string | undefined;
    private _desyncMitigationMode?;
    get desyncMitigationMode(): string;
    set desyncMitigationMode(value: string);
    resetDesyncMitigationMode(): void;
    get desyncMitigationModeInput(): string | undefined;
    get dnsName(): string;
    private _dnsRecordClientRoutingPolicy?;
    get dnsRecordClientRoutingPolicy(): string;
    set dnsRecordClientRoutingPolicy(value: string);
    resetDnsRecordClientRoutingPolicy(): void;
    get dnsRecordClientRoutingPolicyInput(): string | undefined;
    private _dropInvalidHeaderFields?;
    get dropInvalidHeaderFields(): boolean | cdktn.IResolvable;
    set dropInvalidHeaderFields(value: boolean | cdktn.IResolvable);
    resetDropInvalidHeaderFields(): void;
    get dropInvalidHeaderFieldsInput(): boolean | cdktn.IResolvable | undefined;
    private _enableCrossZoneLoadBalancing?;
    get enableCrossZoneLoadBalancing(): boolean | cdktn.IResolvable;
    set enableCrossZoneLoadBalancing(value: boolean | cdktn.IResolvable);
    resetEnableCrossZoneLoadBalancing(): void;
    get enableCrossZoneLoadBalancingInput(): boolean | cdktn.IResolvable | undefined;
    private _enableDeletionProtection?;
    get enableDeletionProtection(): boolean | cdktn.IResolvable;
    set enableDeletionProtection(value: boolean | cdktn.IResolvable);
    resetEnableDeletionProtection(): void;
    get enableDeletionProtectionInput(): boolean | cdktn.IResolvable | undefined;
    private _enableHttp2?;
    get enableHttp2(): boolean | cdktn.IResolvable;
    set enableHttp2(value: boolean | cdktn.IResolvable);
    resetEnableHttp2(): void;
    get enableHttp2Input(): boolean | cdktn.IResolvable | undefined;
    private _enablePrefixForIpv6SourceNat?;
    get enablePrefixForIpv6SourceNat(): string;
    set enablePrefixForIpv6SourceNat(value: string);
    resetEnablePrefixForIpv6SourceNat(): void;
    get enablePrefixForIpv6SourceNatInput(): string | undefined;
    private _enableTlsVersionAndCipherSuiteHeaders?;
    get enableTlsVersionAndCipherSuiteHeaders(): boolean | cdktn.IResolvable;
    set enableTlsVersionAndCipherSuiteHeaders(value: boolean | cdktn.IResolvable);
    resetEnableTlsVersionAndCipherSuiteHeaders(): void;
    get enableTlsVersionAndCipherSuiteHeadersInput(): boolean | cdktn.IResolvable | undefined;
    private _enableWafFailOpen?;
    get enableWafFailOpen(): boolean | cdktn.IResolvable;
    set enableWafFailOpen(value: boolean | cdktn.IResolvable);
    resetEnableWafFailOpen(): void;
    get enableWafFailOpenInput(): boolean | cdktn.IResolvable | undefined;
    private _enableXffClientPort?;
    get enableXffClientPort(): boolean | cdktn.IResolvable;
    set enableXffClientPort(value: boolean | cdktn.IResolvable);
    resetEnableXffClientPort(): void;
    get enableXffClientPortInput(): boolean | cdktn.IResolvable | undefined;
    private _enableZonalShift?;
    get enableZonalShift(): boolean | cdktn.IResolvable;
    set enableZonalShift(value: boolean | cdktn.IResolvable);
    resetEnableZonalShift(): void;
    get enableZonalShiftInput(): boolean | cdktn.IResolvable | undefined;
    private _enforceSecurityGroupInboundRulesOnPrivateLinkTraffic?;
    get enforceSecurityGroupInboundRulesOnPrivateLinkTraffic(): string;
    set enforceSecurityGroupInboundRulesOnPrivateLinkTraffic(value: string);
    resetEnforceSecurityGroupInboundRulesOnPrivateLinkTraffic(): void;
    get enforceSecurityGroupInboundRulesOnPrivateLinkTrafficInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _idleTimeout?;
    get idleTimeout(): number;
    set idleTimeout(value: number);
    resetIdleTimeout(): void;
    get idleTimeoutInput(): number | undefined;
    private _internal?;
    get internal(): boolean | cdktn.IResolvable;
    set internal(value: boolean | cdktn.IResolvable);
    resetInternal(): void;
    get internalInput(): boolean | cdktn.IResolvable | undefined;
    private _ipAddressType?;
    get ipAddressType(): string;
    set ipAddressType(value: string);
    resetIpAddressType(): void;
    get ipAddressTypeInput(): string | undefined;
    private _loadBalancerType?;
    get loadBalancerType(): string;
    set loadBalancerType(value: string);
    resetLoadBalancerType(): void;
    get loadBalancerTypeInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _namePrefix?;
    get namePrefix(): string;
    set namePrefix(value: string);
    resetNamePrefix(): void;
    get namePrefixInput(): string | undefined;
    private _preserveHostHeader?;
    get preserveHostHeader(): boolean | cdktn.IResolvable;
    set preserveHostHeader(value: boolean | cdktn.IResolvable);
    resetPreserveHostHeader(): void;
    get preserveHostHeaderInput(): boolean | cdktn.IResolvable | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _secondaryIpsAutoAssignedPerSubnet?;
    get secondaryIpsAutoAssignedPerSubnet(): number;
    set secondaryIpsAutoAssignedPerSubnet(value: number);
    resetSecondaryIpsAutoAssignedPerSubnet(): void;
    get secondaryIpsAutoAssignedPerSubnetInput(): number | undefined;
    private _securityGroups?;
    get securityGroups(): string[];
    set securityGroups(value: string[]);
    resetSecurityGroups(): void;
    get securityGroupsInput(): string[] | undefined;
    private _subnets?;
    get subnets(): string[];
    set subnets(value: string[]);
    resetSubnets(): void;
    get subnetsInput(): string[] | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    get vpcId(): string;
    private _xffHeaderProcessingMode?;
    get xffHeaderProcessingMode(): string;
    set xffHeaderProcessingMode(value: string);
    resetXffHeaderProcessingMode(): void;
    get xffHeaderProcessingModeInput(): string | undefined;
    get zoneId(): string;
    private _accessLogs;
    get accessLogs(): TfLb.AccessLogsPropertyOutputReference;
    putAccessLogs(value: TfLb.AccessLogsProperty): void;
    resetAccessLogs(): void;
    get accessLogsInput(): TfLb.AccessLogsProperty | undefined;
    private _connectionLogs;
    get connectionLogs(): TfLb.ConnectionLogsPropertyOutputReference;
    putConnectionLogs(value: TfLb.ConnectionLogsProperty): void;
    resetConnectionLogs(): void;
    get connectionLogsInput(): TfLb.ConnectionLogsProperty | undefined;
    private _healthCheckLogs;
    get healthCheckLogs(): TfLb.HealthCheckLogsPropertyOutputReference;
    putHealthCheckLogs(value: TfLb.HealthCheckLogsProperty): void;
    resetHealthCheckLogs(): void;
    get healthCheckLogsInput(): TfLb.HealthCheckLogsProperty | undefined;
    private _ipamPools;
    get ipamPools(): TfLb.IpamPoolsPropertyOutputReference;
    putIpamPools(value: TfLb.IpamPoolsProperty): void;
    resetIpamPools(): void;
    get ipamPoolsInput(): TfLb.IpamPoolsProperty | undefined;
    private _minimumLoadBalancerCapacity;
    get minimumLoadBalancerCapacity(): TfLb.MinimumLoadBalancerCapacityPropertyOutputReference;
    putMinimumLoadBalancerCapacity(value: TfLb.MinimumLoadBalancerCapacityProperty): void;
    resetMinimumLoadBalancerCapacity(): void;
    get minimumLoadBalancerCapacityInput(): TfLb.MinimumLoadBalancerCapacityProperty | undefined;
    private _subnetMapping;
    get subnetMapping(): TfLb.SubnetMappingPropertyList;
    putSubnetMapping(value: TfLb.SubnetMappingProperty[] | cdktn.IResolvable): void;
    resetSubnetMapping(): void;
    get subnetMappingInput(): cdktn.IResolvable | TfLb.SubnetMappingProperty[] | undefined;
    private _timeouts;
    get timeouts(): TfLb.TimeoutsPropertyOutputReference;
    putTimeouts(value: TfLb.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | TfLb.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfLbAccessLogsPropertyToTerraform(struct?: TfLb.AccessLogsPropertyOutputReference | TfLb.AccessLogsProperty): any;
export declare function tfLbAccessLogsPropertyToHclTerraform(struct?: TfLb.AccessLogsPropertyOutputReference | TfLb.AccessLogsProperty): any;
export declare function tfLbConnectionLogsPropertyToTerraform(struct?: TfLb.ConnectionLogsPropertyOutputReference | TfLb.ConnectionLogsProperty): any;
export declare function tfLbConnectionLogsPropertyToHclTerraform(struct?: TfLb.ConnectionLogsPropertyOutputReference | TfLb.ConnectionLogsProperty): any;
export declare function tfLbHealthCheckLogsPropertyToTerraform(struct?: TfLb.HealthCheckLogsPropertyOutputReference | TfLb.HealthCheckLogsProperty): any;
export declare function tfLbHealthCheckLogsPropertyToHclTerraform(struct?: TfLb.HealthCheckLogsPropertyOutputReference | TfLb.HealthCheckLogsProperty): any;
export declare function tfLbIpamPoolsPropertyToTerraform(struct?: TfLb.IpamPoolsPropertyOutputReference | TfLb.IpamPoolsProperty): any;
export declare function tfLbIpamPoolsPropertyToHclTerraform(struct?: TfLb.IpamPoolsPropertyOutputReference | TfLb.IpamPoolsProperty): any;
export declare function tfLbMinimumLoadBalancerCapacityPropertyToTerraform(struct?: TfLb.MinimumLoadBalancerCapacityPropertyOutputReference | TfLb.MinimumLoadBalancerCapacityProperty): any;
export declare function tfLbMinimumLoadBalancerCapacityPropertyToHclTerraform(struct?: TfLb.MinimumLoadBalancerCapacityPropertyOutputReference | TfLb.MinimumLoadBalancerCapacityProperty): any;
export declare function tfLbSubnetMappingPropertyToTerraform(struct?: TfLb.SubnetMappingProperty | cdktn.IResolvable): any;
export declare function tfLbSubnetMappingPropertyToHclTerraform(struct?: TfLb.SubnetMappingProperty | cdktn.IResolvable): any;
export declare function tfLbTimeoutsPropertyToTerraform(struct?: TfLb.TimeoutsProperty | cdktn.IResolvable): any;
export declare function tfLbTimeoutsPropertyToHclTerraform(struct?: TfLb.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace TfLb {
    interface AccessLogsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb#bucket TfLb#bucket}
        */
        readonly bucket: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb#enabled TfLb#enabled}
        */
        readonly enabled?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb#prefix TfLb#prefix}
        */
        readonly prefix?: string;
    }
    class AccessLogsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AccessLogsProperty | undefined;
        set internalValue(value: AccessLogsProperty | undefined);
        private _bucket?;
        get bucket(): string;
        set bucket(value: string);
        get bucketInput(): string | undefined;
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        resetEnabled(): void;
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
        private _prefix?;
        get prefix(): string;
        set prefix(value: string);
        resetPrefix(): void;
        get prefixInput(): string | undefined;
    }
    interface ConnectionLogsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb#bucket TfLb#bucket}
        */
        readonly bucket: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb#enabled TfLb#enabled}
        */
        readonly enabled?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb#prefix TfLb#prefix}
        */
        readonly prefix?: string;
    }
    class ConnectionLogsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ConnectionLogsProperty | undefined;
        set internalValue(value: ConnectionLogsProperty | undefined);
        private _bucket?;
        get bucket(): string;
        set bucket(value: string);
        get bucketInput(): string | undefined;
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        resetEnabled(): void;
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
        private _prefix?;
        get prefix(): string;
        set prefix(value: string);
        resetPrefix(): void;
        get prefixInput(): string | undefined;
    }
    interface HealthCheckLogsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb#bucket TfLb#bucket}
        */
        readonly bucket: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb#enabled TfLb#enabled}
        */
        readonly enabled?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb#prefix TfLb#prefix}
        */
        readonly prefix?: string;
    }
    class HealthCheckLogsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): HealthCheckLogsProperty | undefined;
        set internalValue(value: HealthCheckLogsProperty | undefined);
        private _bucket?;
        get bucket(): string;
        set bucket(value: string);
        get bucketInput(): string | undefined;
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        resetEnabled(): void;
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
        private _prefix?;
        get prefix(): string;
        set prefix(value: string);
        resetPrefix(): void;
        get prefixInput(): string | undefined;
    }
    interface IpamPoolsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb#ipv4_ipam_pool_id TfLb#ipv4_ipam_pool_id}
        */
        readonly ipv4IpamPoolId: string;
    }
    class IpamPoolsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): IpamPoolsProperty | undefined;
        set internalValue(value: IpamPoolsProperty | undefined);
        private _ipv4IpamPoolId?;
        get ipv4IpamPoolId(): string;
        set ipv4IpamPoolId(value: string);
        get ipv4IpamPoolIdInput(): string | undefined;
    }
    interface MinimumLoadBalancerCapacityProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb#capacity_units TfLb#capacity_units}
        */
        readonly capacityUnits: number;
    }
    class MinimumLoadBalancerCapacityPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): MinimumLoadBalancerCapacityProperty | undefined;
        set internalValue(value: MinimumLoadBalancerCapacityProperty | undefined);
        private _capacityUnits?;
        get capacityUnits(): number;
        set capacityUnits(value: number);
        get capacityUnitsInput(): number | undefined;
    }
    interface SubnetMappingProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb#allocation_id TfLb#allocation_id}
        */
        readonly allocationId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb#ipv6_address TfLb#ipv6_address}
        */
        readonly ipv6Address?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb#private_ipv4_address TfLb#private_ipv4_address}
        */
        readonly privateIpv4Address?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb#subnet_id TfLb#subnet_id}
        */
        readonly subnetId: string;
    }
    class SubnetMappingPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SubnetMappingProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SubnetMappingProperty | cdktn.IResolvable | undefined);
        private _allocationId?;
        get allocationId(): string;
        set allocationId(value: string);
        resetAllocationId(): void;
        get allocationIdInput(): string | undefined;
        private _ipv6Address?;
        get ipv6Address(): string;
        set ipv6Address(value: string);
        resetIpv6Address(): void;
        get ipv6AddressInput(): string | undefined;
        get outpostId(): string;
        private _privateIpv4Address?;
        get privateIpv4Address(): string;
        set privateIpv4Address(value: string);
        resetPrivateIpv4Address(): void;
        get privateIpv4AddressInput(): string | undefined;
        private _subnetId?;
        get subnetId(): string;
        set subnetId(value: string);
        get subnetIdInput(): string | undefined;
    }
    class SubnetMappingPropertyList extends cdktn.ComplexList {
        internalValue?: SubnetMappingProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SubnetMappingPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb#create TfLb#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb#delete TfLb#delete}
        */
        readonly delete?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lb#update TfLb#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
