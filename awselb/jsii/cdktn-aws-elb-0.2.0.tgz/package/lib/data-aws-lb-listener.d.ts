import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataTfListenerConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lb_listener#arn DataTfListener#arn}
    */
    readonly arn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lb_listener#id DataTfListener#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lb_listener#load_balancer_arn DataTfListener#load_balancer_arn}
    */
    readonly loadBalancerArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lb_listener#port DataTfListener#port}
    */
    readonly port?: number;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lb_listener#region DataTfListener#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lb_listener#tags DataTfListener#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lb_listener#timeouts DataTfListener#timeouts}
    */
    readonly timeouts?: DataTfListener.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lb_listener aws_lb_listener}
*/
export declare class DataTfListener extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_lb_listener";
    /**
    * Generates CDKTN code for importing a DataTfListener resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataTfListener to import
    * @param importFromId The id of the existing DataTfListener that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lb_listener#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataTfListener to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lb_listener aws_lb_listener} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataTfListenerConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataTfListenerConfig);
    get alpnPolicy(): string;
    private _arn?;
    get arn(): string;
    set arn(value: string);
    resetArn(): void;
    get arnInput(): string | undefined;
    get certificateArn(): string;
    private _defaultAction;
    get defaultAction(): DataTfListener.DefaultActionPropertyList;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _loadBalancerArn?;
    get loadBalancerArn(): string;
    set loadBalancerArn(value: string);
    resetLoadBalancerArn(): void;
    get loadBalancerArnInput(): string | undefined;
    private _mutualAuthentication;
    get mutualAuthentication(): DataTfListener.MutualAuthenticationPropertyList;
    private _port?;
    get port(): number;
    set port(value: number);
    resetPort(): void;
    get portInput(): number | undefined;
    get protocol(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get sslPolicy(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _timeouts;
    get timeouts(): DataTfListener.TimeoutsPropertyOutputReference;
    putTimeouts(value: DataTfListener.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | DataTfListener.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataTfListenerAuthenticateCognitoPropertyToTerraform(struct?: DataTfListener.AuthenticateCognitoProperty): any;
export declare function dataTfListenerAuthenticateCognitoPropertyToHclTerraform(struct?: DataTfListener.AuthenticateCognitoProperty): any;
export declare function dataTfListenerAuthenticateOidcPropertyToTerraform(struct?: DataTfListener.AuthenticateOidcProperty): any;
export declare function dataTfListenerAuthenticateOidcPropertyToHclTerraform(struct?: DataTfListener.AuthenticateOidcProperty): any;
export declare function dataTfListenerFixedResponsePropertyToTerraform(struct?: DataTfListener.FixedResponseProperty): any;
export declare function dataTfListenerFixedResponsePropertyToHclTerraform(struct?: DataTfListener.FixedResponseProperty): any;
export declare function dataTfListenerStickinessPropertyToTerraform(struct?: DataTfListener.StickinessProperty): any;
export declare function dataTfListenerStickinessPropertyToHclTerraform(struct?: DataTfListener.StickinessProperty): any;
export declare function dataTfListenerTargetGroupPropertyToTerraform(struct?: DataTfListener.TargetGroupProperty): any;
export declare function dataTfListenerTargetGroupPropertyToHclTerraform(struct?: DataTfListener.TargetGroupProperty): any;
export declare function dataTfListenerForwardPropertyToTerraform(struct?: DataTfListener.ForwardProperty): any;
export declare function dataTfListenerForwardPropertyToHclTerraform(struct?: DataTfListener.ForwardProperty): any;
export declare function dataTfListenerAdditionalClaimPropertyToTerraform(struct?: DataTfListener.AdditionalClaimProperty): any;
export declare function dataTfListenerAdditionalClaimPropertyToHclTerraform(struct?: DataTfListener.AdditionalClaimProperty): any;
export declare function dataTfListenerJwtValidationPropertyToTerraform(struct?: DataTfListener.JwtValidationProperty): any;
export declare function dataTfListenerJwtValidationPropertyToHclTerraform(struct?: DataTfListener.JwtValidationProperty): any;
export declare function dataTfListenerRedirectPropertyToTerraform(struct?: DataTfListener.RedirectProperty): any;
export declare function dataTfListenerRedirectPropertyToHclTerraform(struct?: DataTfListener.RedirectProperty): any;
export declare function dataTfListenerDefaultActionPropertyToTerraform(struct?: DataTfListener.DefaultActionProperty): any;
export declare function dataTfListenerDefaultActionPropertyToHclTerraform(struct?: DataTfListener.DefaultActionProperty): any;
export declare function dataTfListenerMutualAuthenticationPropertyToTerraform(struct?: DataTfListener.MutualAuthenticationProperty): any;
export declare function dataTfListenerMutualAuthenticationPropertyToHclTerraform(struct?: DataTfListener.MutualAuthenticationProperty): any;
export declare function dataTfListenerTimeoutsPropertyToTerraform(struct?: DataTfListener.TimeoutsProperty | cdktn.IResolvable): any;
export declare function dataTfListenerTimeoutsPropertyToHclTerraform(struct?: DataTfListener.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace DataTfListener {
    interface AuthenticateCognitoProperty {
    }
    class AuthenticateCognitoPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AuthenticateCognitoProperty | undefined;
        set internalValue(value: AuthenticateCognitoProperty | undefined);
        private _authenticationRequestExtraParams;
        get authenticationRequestExtraParams(): cdktn.StringMap;
        get onUnauthenticatedRequest(): string;
        get scope(): string;
        get sessionCookieName(): string;
        get sessionTimeout(): number;
        get userPoolArn(): string;
        get userPoolClientId(): string;
        get userPoolDomain(): string;
    }
    class AuthenticateCognitoPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AuthenticateCognitoPropertyOutputReference;
    }
    interface AuthenticateOidcProperty {
    }
    class AuthenticateOidcPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AuthenticateOidcProperty | undefined;
        set internalValue(value: AuthenticateOidcProperty | undefined);
        private _authenticationRequestExtraParams;
        get authenticationRequestExtraParams(): cdktn.StringMap;
        get authorizationEndpoint(): string;
        get clientId(): string;
        get clientSecret(): string;
        get issuer(): string;
        get onUnauthenticatedRequest(): string;
        get scope(): string;
        get sessionCookieName(): string;
        get sessionTimeout(): number;
        get tokenEndpoint(): string;
        get userInfoEndpoint(): string;
    }
    class AuthenticateOidcPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AuthenticateOidcPropertyOutputReference;
    }
    interface FixedResponseProperty {
    }
    class FixedResponsePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): FixedResponseProperty | undefined;
        set internalValue(value: FixedResponseProperty | undefined);
        get contentType(): string;
        get messageBody(): string;
        get statusCode(): string;
    }
    class FixedResponsePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): FixedResponsePropertyOutputReference;
    }
    interface StickinessProperty {
    }
    class StickinessPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): StickinessProperty | undefined;
        set internalValue(value: StickinessProperty | undefined);
        get duration(): number;
        get enabled(): cdktn.IResolvable;
    }
    class StickinessPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): StickinessPropertyOutputReference;
    }
    interface TargetGroupProperty {
    }
    class TargetGroupPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TargetGroupProperty | undefined;
        set internalValue(value: TargetGroupProperty | undefined);
        get arn(): string;
        get weight(): number;
    }
    class TargetGroupPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TargetGroupPropertyOutputReference;
    }
    interface ForwardProperty {
    }
    class ForwardPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ForwardProperty | undefined;
        set internalValue(value: ForwardProperty | undefined);
        private _stickiness;
        get stickiness(): StickinessPropertyList;
        private _targetGroup;
        get targetGroup(): TargetGroupPropertyList;
    }
    class ForwardPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ForwardPropertyOutputReference;
    }
    interface AdditionalClaimProperty {
    }
    class AdditionalClaimPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AdditionalClaimProperty | undefined;
        set internalValue(value: AdditionalClaimProperty | undefined);
        get format(): string;
        get name(): string;
        get values(): string[];
    }
    class AdditionalClaimPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AdditionalClaimPropertyOutputReference;
    }
    interface JwtValidationProperty {
    }
    class JwtValidationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): JwtValidationProperty | undefined;
        set internalValue(value: JwtValidationProperty | undefined);
        private _additionalClaim;
        get additionalClaim(): AdditionalClaimPropertyList;
        get issuer(): string;
        get jwksEndpoint(): string;
    }
    class JwtValidationPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): JwtValidationPropertyOutputReference;
    }
    interface RedirectProperty {
    }
    class RedirectPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RedirectProperty | undefined;
        set internalValue(value: RedirectProperty | undefined);
        get host(): string;
        get path(): string;
        get port(): string;
        get protocol(): string;
        get query(): string;
        get statusCode(): string;
    }
    class RedirectPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RedirectPropertyOutputReference;
    }
    interface DefaultActionProperty {
    }
    class DefaultActionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DefaultActionProperty | undefined;
        set internalValue(value: DefaultActionProperty | undefined);
        private _authenticateCognito;
        get authenticateCognito(): AuthenticateCognitoPropertyList;
        private _authenticateOidc;
        get authenticateOidc(): AuthenticateOidcPropertyList;
        private _fixedResponse;
        get fixedResponse(): FixedResponsePropertyList;
        private _forward;
        get forward(): ForwardPropertyList;
        private _jwtValidation;
        get jwtValidation(): JwtValidationPropertyList;
        get order(): number;
        private _redirect;
        get redirect(): RedirectPropertyList;
        get targetGroupArn(): string;
        get type(): string;
    }
    class DefaultActionPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DefaultActionPropertyOutputReference;
    }
    interface MutualAuthenticationProperty {
    }
    class MutualAuthenticationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): MutualAuthenticationProperty | undefined;
        set internalValue(value: MutualAuthenticationProperty | undefined);
        get advertiseTrustStoreCaNames(): string;
        get ignoreClientCertificateExpiry(): cdktn.IResolvable;
        get mode(): string;
        get trustStoreArn(): string;
    }
    class MutualAuthenticationPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): MutualAuthenticationPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lb_listener#read DataTfListener#read}
        */
        readonly read?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _read?;
        get read(): string;
        set read(value: string);
        resetRead(): void;
        get readInput(): string | undefined;
    }
}
