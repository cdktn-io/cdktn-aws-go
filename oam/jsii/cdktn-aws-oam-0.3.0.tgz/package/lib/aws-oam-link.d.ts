import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsLinkConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/oam_link#id AwsLink#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/oam_link#label_template AwsLink#label_template}
    */
    readonly labelTemplate: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/oam_link#region AwsLink#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/oam_link#resource_types AwsLink#resource_types}
    */
    readonly resourceTypes: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/oam_link#sink_identifier AwsLink#sink_identifier}
    */
    readonly sinkIdentifier: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/oam_link#tags AwsLink#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/oam_link#tags_all AwsLink#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * link_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/oam_link#link_configuration AwsLink#link_configuration}
    */
    readonly linkConfiguration?: AwsLink.LinkConfigurationProperty;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/oam_link#timeouts AwsLink#timeouts}
    */
    readonly timeouts?: AwsLink.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/oam_link aws_oam_link}
*/
export declare class AwsLink extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_oam_link";
    /**
    * Generates CDKTN code for importing a AwsLink resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsLink to import
    * @param importFromId The id of the existing AwsLink that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/oam_link#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsLink to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/oam_link aws_oam_link} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsLinkConfig
    */
    constructor(scope: Construct, id: string, config: AwsLinkConfig);
    get arn(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get label(): string;
    private _labelTemplate?;
    get labelTemplate(): string;
    set labelTemplate(value: string);
    get labelTemplateInput(): string | undefined;
    get linkId(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _resourceTypes?;
    get resourceTypes(): string[];
    set resourceTypes(value: string[]);
    get resourceTypesInput(): string[] | undefined;
    get sinkArn(): string;
    private _sinkIdentifier?;
    get sinkIdentifier(): string;
    set sinkIdentifier(value: string);
    get sinkIdentifierInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _linkConfiguration;
    get linkConfiguration(): AwsLink.LinkConfigurationPropertyOutputReference;
    putLinkConfiguration(value: AwsLink.LinkConfigurationProperty): void;
    resetLinkConfiguration(): void;
    get linkConfigurationInput(): AwsLink.LinkConfigurationProperty | undefined;
    private _timeouts;
    get timeouts(): AwsLink.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsLink.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): AwsLink.TimeoutsProperty | cdktn.IResolvable | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsLinkLogGroupConfigurationPropertyToTerraform(struct?: AwsLink.LogGroupConfigurationPropertyOutputReference | AwsLink.LogGroupConfigurationProperty): any;
export declare function awsLinkLogGroupConfigurationPropertyToHclTerraform(struct?: AwsLink.LogGroupConfigurationPropertyOutputReference | AwsLink.LogGroupConfigurationProperty): any;
export declare function awsLinkMetricConfigurationPropertyToTerraform(struct?: AwsLink.MetricConfigurationPropertyOutputReference | AwsLink.MetricConfigurationProperty): any;
export declare function awsLinkMetricConfigurationPropertyToHclTerraform(struct?: AwsLink.MetricConfigurationPropertyOutputReference | AwsLink.MetricConfigurationProperty): any;
export declare function awsLinkLinkConfigurationPropertyToTerraform(struct?: AwsLink.LinkConfigurationPropertyOutputReference | AwsLink.LinkConfigurationProperty): any;
export declare function awsLinkLinkConfigurationPropertyToHclTerraform(struct?: AwsLink.LinkConfigurationPropertyOutputReference | AwsLink.LinkConfigurationProperty): any;
export declare function awsLinkTimeoutsPropertyToTerraform(struct?: AwsLink.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsLinkTimeoutsPropertyToHclTerraform(struct?: AwsLink.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsLink {
    interface LogGroupConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/oam_link#filter AwsLink#filter}
        */
        readonly filter: string;
    }
    class LogGroupConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): LogGroupConfigurationProperty | undefined;
        set internalValue(value: LogGroupConfigurationProperty | undefined);
        private _filter?;
        get filter(): string;
        set filter(value: string);
        get filterInput(): string | undefined;
    }
    interface MetricConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/oam_link#filter AwsLink#filter}
        */
        readonly filter: string;
    }
    class MetricConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): MetricConfigurationProperty | undefined;
        set internalValue(value: MetricConfigurationProperty | undefined);
        private _filter?;
        get filter(): string;
        set filter(value: string);
        get filterInput(): string | undefined;
    }
    interface LinkConfigurationProperty {
        /**
        * log_group_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/oam_link#log_group_configuration AwsLink#log_group_configuration}
        */
        readonly logGroupConfiguration?: LogGroupConfigurationProperty;
        /**
        * metric_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/oam_link#metric_configuration AwsLink#metric_configuration}
        */
        readonly metricConfiguration?: MetricConfigurationProperty;
    }
    class LinkConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): LinkConfigurationProperty | undefined;
        set internalValue(value: LinkConfigurationProperty | undefined);
        private _logGroupConfiguration;
        get logGroupConfiguration(): LogGroupConfigurationPropertyOutputReference;
        putLogGroupConfiguration(value: LogGroupConfigurationProperty): void;
        resetLogGroupConfiguration(): void;
        get logGroupConfigurationInput(): LogGroupConfigurationProperty | undefined;
        private _metricConfiguration;
        get metricConfiguration(): MetricConfigurationPropertyOutputReference;
        putMetricConfiguration(value: MetricConfigurationProperty): void;
        resetMetricConfiguration(): void;
        get metricConfigurationInput(): MetricConfigurationProperty | undefined;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/oam_link#create AwsLink#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/oam_link#delete AwsLink#delete}
        */
        readonly delete?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/oam_link#update AwsLink#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
