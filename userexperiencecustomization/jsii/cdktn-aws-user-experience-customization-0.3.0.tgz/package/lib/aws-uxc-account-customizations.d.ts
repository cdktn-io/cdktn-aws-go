import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsAccountCustomizationsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/uxc_account_customizations#account_color AwsAccountCustomizations#account_color}
    */
    readonly accountColor?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/uxc_account_customizations#visible_regions AwsAccountCustomizations#visible_regions}
    */
    readonly visibleRegions?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/uxc_account_customizations#visible_services AwsAccountCustomizations#visible_services}
    */
    readonly visibleServices?: string[];
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/uxc_account_customizations aws_uxc_account_customizations}
*/
export declare class AwsAccountCustomizations extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_uxc_account_customizations";
    /**
    * Generates CDKTN code for importing a AwsAccountCustomizations resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsAccountCustomizations to import
    * @param importFromId The id of the existing AwsAccountCustomizations that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/uxc_account_customizations#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsAccountCustomizations to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/uxc_account_customizations aws_uxc_account_customizations} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsAccountCustomizationsConfig = {}
    */
    constructor(scope: Construct, id: string, config?: AwsAccountCustomizationsConfig);
    private _accountColor?;
    get accountColor(): string;
    set accountColor(value: string);
    resetAccountColor(): void;
    get accountColorInput(): string | undefined;
    private _visibleRegions?;
    get visibleRegions(): string[];
    set visibleRegions(value: string[]);
    resetVisibleRegions(): void;
    get visibleRegionsInput(): string[] | undefined;
    private _visibleServices?;
    get visibleServices(): string[];
    set visibleServices(value: string[]);
    resetVisibleServices(): void;
    get visibleServicesInput(): string[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
