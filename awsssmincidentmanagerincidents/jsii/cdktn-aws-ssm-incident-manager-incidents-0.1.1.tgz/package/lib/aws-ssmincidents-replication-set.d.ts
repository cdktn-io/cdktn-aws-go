import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsSsmincidentsReplicationSetConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssmincidents_replication_set#id AwsSsmincidentsReplicationSet#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssmincidents_replication_set#tags AwsSsmincidentsReplicationSet#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssmincidents_replication_set#tags_all AwsSsmincidentsReplicationSet#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * region block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssmincidents_replication_set#region AwsSsmincidentsReplicationSet#region}
    */
    readonly region?: AwsSsmincidentsReplicationSet.RegionProperty[] | cdktn.IResolvable;
    /**
    * regions block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssmincidents_replication_set#regions AwsSsmincidentsReplicationSet#regions}
    */
    readonly regions?: AwsSsmincidentsReplicationSet.RegionsProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssmincidents_replication_set#timeouts AwsSsmincidentsReplicationSet#timeouts}
    */
    readonly timeouts?: AwsSsmincidentsReplicationSet.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssmincidents_replication_set aws_ssmincidents_replication_set}
*/
export declare class AwsSsmincidentsReplicationSet extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_ssmincidents_replication_set";
    /**
    * Generates CDKTN code for importing a AwsSsmincidentsReplicationSet resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsSsmincidentsReplicationSet to import
    * @param importFromId The id of the existing AwsSsmincidentsReplicationSet that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssmincidents_replication_set#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsSsmincidentsReplicationSet to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssmincidents_replication_set aws_ssmincidents_replication_set} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsSsmincidentsReplicationSetConfig = {}
    */
    constructor(scope: Construct, id: string, config?: AwsSsmincidentsReplicationSetConfig);
    get arn(): string;
    get createdBy(): string;
    get deletionProtected(): cdktn.IResolvable;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get lastModifiedBy(): string;
    get status(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _region;
    get region(): AwsSsmincidentsReplicationSet.RegionPropertyList;
    putRegion(value: AwsSsmincidentsReplicationSet.RegionProperty[] | cdktn.IResolvable): void;
    resetRegion(): void;
    get regionInput(): cdktn.IResolvable | AwsSsmincidentsReplicationSet.RegionProperty[] | undefined;
    private _regions;
    get regions(): AwsSsmincidentsReplicationSet.RegionsPropertyList;
    putRegions(value: AwsSsmincidentsReplicationSet.RegionsProperty[] | cdktn.IResolvable): void;
    resetRegions(): void;
    get regionsInput(): cdktn.IResolvable | AwsSsmincidentsReplicationSet.RegionsProperty[] | undefined;
    private _timeouts;
    get timeouts(): AwsSsmincidentsReplicationSet.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsSsmincidentsReplicationSet.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsSsmincidentsReplicationSet.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsSsmincidentsReplicationSetRegionPropertyToTerraform(struct?: AwsSsmincidentsReplicationSet.RegionProperty | cdktn.IResolvable): any;
export declare function awsSsmincidentsReplicationSetRegionPropertyToHclTerraform(struct?: AwsSsmincidentsReplicationSet.RegionProperty | cdktn.IResolvable): any;
export declare function awsSsmincidentsReplicationSetRegionsPropertyToTerraform(struct?: AwsSsmincidentsReplicationSet.RegionsProperty | cdktn.IResolvable): any;
export declare function awsSsmincidentsReplicationSetRegionsPropertyToHclTerraform(struct?: AwsSsmincidentsReplicationSet.RegionsProperty | cdktn.IResolvable): any;
export declare function awsSsmincidentsReplicationSetTimeoutsPropertyToTerraform(struct?: AwsSsmincidentsReplicationSet.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsSsmincidentsReplicationSetTimeoutsPropertyToHclTerraform(struct?: AwsSsmincidentsReplicationSet.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsSsmincidentsReplicationSet {
    interface RegionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssmincidents_replication_set#kms_key_arn AwsSsmincidentsReplicationSet#kms_key_arn}
        */
        readonly kmsKeyArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssmincidents_replication_set#name AwsSsmincidentsReplicationSet#name}
        */
        readonly name: string;
    }
    class RegionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RegionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RegionProperty | cdktn.IResolvable | undefined);
        private _kmsKeyArn?;
        get kmsKeyArn(): string;
        set kmsKeyArn(value: string);
        resetKmsKeyArn(): void;
        get kmsKeyArnInput(): string | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        get status(): string;
        get statusMessage(): string;
    }
    class RegionPropertyList extends cdktn.ComplexList {
        internalValue?: RegionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RegionPropertyOutputReference;
    }
    interface RegionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssmincidents_replication_set#kms_key_arn AwsSsmincidentsReplicationSet#kms_key_arn}
        */
        readonly kmsKeyArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssmincidents_replication_set#name AwsSsmincidentsReplicationSet#name}
        */
        readonly name: string;
    }
    class RegionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RegionsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RegionsProperty | cdktn.IResolvable | undefined);
        private _kmsKeyArn?;
        get kmsKeyArn(): string;
        set kmsKeyArn(value: string);
        resetKmsKeyArn(): void;
        get kmsKeyArnInput(): string | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        get status(): string;
        get statusMessage(): string;
    }
    class RegionsPropertyList extends cdktn.ComplexList {
        internalValue?: RegionsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RegionsPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssmincidents_replication_set#create AwsSsmincidentsReplicationSet#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssmincidents_replication_set#delete AwsSsmincidentsReplicationSet#delete}
        */
        readonly delete?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssmincidents_replication_set#update AwsSsmincidentsReplicationSet#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
