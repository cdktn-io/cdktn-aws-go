import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsSsmincidentsResponsePlanConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssmincidents_response_plan#chat_channel AwsSsmincidentsResponsePlan#chat_channel}
    */
    readonly chatChannel?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssmincidents_response_plan#display_name AwsSsmincidentsResponsePlan#display_name}
    */
    readonly displayName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssmincidents_response_plan#engagements AwsSsmincidentsResponsePlan#engagements}
    */
    readonly engagements?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssmincidents_response_plan#id AwsSsmincidentsResponsePlan#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssmincidents_response_plan#name AwsSsmincidentsResponsePlan#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssmincidents_response_plan#region AwsSsmincidentsResponsePlan#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssmincidents_response_plan#tags AwsSsmincidentsResponsePlan#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssmincidents_response_plan#tags_all AwsSsmincidentsResponsePlan#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * action block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssmincidents_response_plan#action AwsSsmincidentsResponsePlan#action}
    */
    readonly action?: AwsSsmincidentsResponsePlan.ActionProperty;
    /**
    * incident_template block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssmincidents_response_plan#incident_template AwsSsmincidentsResponsePlan#incident_template}
    */
    readonly incidentTemplate: AwsSsmincidentsResponsePlan.IncidentTemplateProperty;
    /**
    * integration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssmincidents_response_plan#integration AwsSsmincidentsResponsePlan#integration}
    */
    readonly integration?: AwsSsmincidentsResponsePlan.IntegrationProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssmincidents_response_plan aws_ssmincidents_response_plan}
*/
export declare class AwsSsmincidentsResponsePlan extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_ssmincidents_response_plan";
    /**
    * Generates CDKTN code for importing a AwsSsmincidentsResponsePlan resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsSsmincidentsResponsePlan to import
    * @param importFromId The id of the existing AwsSsmincidentsResponsePlan that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssmincidents_response_plan#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsSsmincidentsResponsePlan to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssmincidents_response_plan aws_ssmincidents_response_plan} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsSsmincidentsResponsePlanConfig
    */
    constructor(scope: Construct, id: string, config: AwsSsmincidentsResponsePlanConfig);
    get arn(): string;
    private _chatChannel?;
    get chatChannel(): string[];
    set chatChannel(value: string[]);
    resetChatChannel(): void;
    get chatChannelInput(): string[] | undefined;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    resetDisplayName(): void;
    get displayNameInput(): string | undefined;
    private _engagements?;
    get engagements(): string[];
    set engagements(value: string[]);
    resetEngagements(): void;
    get engagementsInput(): string[] | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _action;
    get action(): AwsSsmincidentsResponsePlan.ActionPropertyOutputReference;
    putAction(value: AwsSsmincidentsResponsePlan.ActionProperty): void;
    resetAction(): void;
    get actionInput(): AwsSsmincidentsResponsePlan.ActionProperty | undefined;
    private _incidentTemplate;
    get incidentTemplate(): AwsSsmincidentsResponsePlan.IncidentTemplatePropertyOutputReference;
    putIncidentTemplate(value: AwsSsmincidentsResponsePlan.IncidentTemplateProperty): void;
    get incidentTemplateInput(): AwsSsmincidentsResponsePlan.IncidentTemplateProperty | undefined;
    private _integration;
    get integration(): AwsSsmincidentsResponsePlan.IntegrationPropertyOutputReference;
    putIntegration(value: AwsSsmincidentsResponsePlan.IntegrationProperty): void;
    resetIntegration(): void;
    get integrationInput(): AwsSsmincidentsResponsePlan.IntegrationProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsSsmincidentsResponsePlanParameterPropertyToTerraform(struct?: AwsSsmincidentsResponsePlan.ParameterProperty | cdktn.IResolvable): any;
export declare function awsSsmincidentsResponsePlanParameterPropertyToHclTerraform(struct?: AwsSsmincidentsResponsePlan.ParameterProperty | cdktn.IResolvable): any;
export declare function awsSsmincidentsResponsePlanSsmAutomationPropertyToTerraform(struct?: AwsSsmincidentsResponsePlan.SsmAutomationProperty | cdktn.IResolvable): any;
export declare function awsSsmincidentsResponsePlanSsmAutomationPropertyToHclTerraform(struct?: AwsSsmincidentsResponsePlan.SsmAutomationProperty | cdktn.IResolvable): any;
export declare function awsSsmincidentsResponsePlanActionPropertyToTerraform(struct?: AwsSsmincidentsResponsePlan.ActionPropertyOutputReference | AwsSsmincidentsResponsePlan.ActionProperty): any;
export declare function awsSsmincidentsResponsePlanActionPropertyToHclTerraform(struct?: AwsSsmincidentsResponsePlan.ActionPropertyOutputReference | AwsSsmincidentsResponsePlan.ActionProperty): any;
export declare function awsSsmincidentsResponsePlanNotificationTargetPropertyToTerraform(struct?: AwsSsmincidentsResponsePlan.NotificationTargetProperty | cdktn.IResolvable): any;
export declare function awsSsmincidentsResponsePlanNotificationTargetPropertyToHclTerraform(struct?: AwsSsmincidentsResponsePlan.NotificationTargetProperty | cdktn.IResolvable): any;
export declare function awsSsmincidentsResponsePlanIncidentTemplatePropertyToTerraform(struct?: AwsSsmincidentsResponsePlan.IncidentTemplatePropertyOutputReference | AwsSsmincidentsResponsePlan.IncidentTemplateProperty): any;
export declare function awsSsmincidentsResponsePlanIncidentTemplatePropertyToHclTerraform(struct?: AwsSsmincidentsResponsePlan.IncidentTemplatePropertyOutputReference | AwsSsmincidentsResponsePlan.IncidentTemplateProperty): any;
export declare function awsSsmincidentsResponsePlanPagerdutyPropertyToTerraform(struct?: AwsSsmincidentsResponsePlan.PagerdutyProperty | cdktn.IResolvable): any;
export declare function awsSsmincidentsResponsePlanPagerdutyPropertyToHclTerraform(struct?: AwsSsmincidentsResponsePlan.PagerdutyProperty | cdktn.IResolvable): any;
export declare function awsSsmincidentsResponsePlanIntegrationPropertyToTerraform(struct?: AwsSsmincidentsResponsePlan.IntegrationPropertyOutputReference | AwsSsmincidentsResponsePlan.IntegrationProperty): any;
export declare function awsSsmincidentsResponsePlanIntegrationPropertyToHclTerraform(struct?: AwsSsmincidentsResponsePlan.IntegrationPropertyOutputReference | AwsSsmincidentsResponsePlan.IntegrationProperty): any;
export declare namespace AwsSsmincidentsResponsePlan {
    interface ParameterProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssmincidents_response_plan#name AwsSsmincidentsResponsePlan#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssmincidents_response_plan#values AwsSsmincidentsResponsePlan#values}
        */
        readonly values: string[];
    }
    class ParameterPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ParameterProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ParameterProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        get valuesInput(): string[] | undefined;
    }
    class ParameterPropertyList extends cdktn.ComplexList {
        internalValue?: ParameterProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ParameterPropertyOutputReference;
    }
    interface SsmAutomationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssmincidents_response_plan#document_name AwsSsmincidentsResponsePlan#document_name}
        */
        readonly documentName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssmincidents_response_plan#document_version AwsSsmincidentsResponsePlan#document_version}
        */
        readonly documentVersion?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssmincidents_response_plan#dynamic_parameters AwsSsmincidentsResponsePlan#dynamic_parameters}
        */
        readonly dynamicParameters?: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssmincidents_response_plan#role_arn AwsSsmincidentsResponsePlan#role_arn}
        */
        readonly roleArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssmincidents_response_plan#target_account AwsSsmincidentsResponsePlan#target_account}
        */
        readonly targetAccount?: string;
        /**
        * parameter block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssmincidents_response_plan#parameter AwsSsmincidentsResponsePlan#parameter}
        */
        readonly parameter?: ParameterProperty[] | cdktn.IResolvable;
    }
    class SsmAutomationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SsmAutomationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SsmAutomationProperty | cdktn.IResolvable | undefined);
        private _documentName?;
        get documentName(): string;
        set documentName(value: string);
        get documentNameInput(): string | undefined;
        private _documentVersion?;
        get documentVersion(): string;
        set documentVersion(value: string);
        resetDocumentVersion(): void;
        get documentVersionInput(): string | undefined;
        private _dynamicParameters?;
        get dynamicParameters(): {
            [key: string]: string;
        };
        set dynamicParameters(value: {
            [key: string]: string;
        });
        resetDynamicParameters(): void;
        get dynamicParametersInput(): {
            [key: string]: string;
        } | undefined;
        private _roleArn?;
        get roleArn(): string;
        set roleArn(value: string);
        get roleArnInput(): string | undefined;
        private _targetAccount?;
        get targetAccount(): string;
        set targetAccount(value: string);
        resetTargetAccount(): void;
        get targetAccountInput(): string | undefined;
        private _parameter;
        get parameter(): ParameterPropertyList;
        putParameter(value: ParameterProperty[] | cdktn.IResolvable): void;
        resetParameter(): void;
        get parameterInput(): cdktn.IResolvable | ParameterProperty[] | undefined;
    }
    class SsmAutomationPropertyList extends cdktn.ComplexList {
        internalValue?: SsmAutomationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SsmAutomationPropertyOutputReference;
    }
    interface ActionProperty {
        /**
        * ssm_automation block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssmincidents_response_plan#ssm_automation AwsSsmincidentsResponsePlan#ssm_automation}
        */
        readonly ssmAutomation?: SsmAutomationProperty[] | cdktn.IResolvable;
    }
    class ActionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ActionProperty | undefined;
        set internalValue(value: ActionProperty | undefined);
        private _ssmAutomation;
        get ssmAutomation(): SsmAutomationPropertyList;
        putSsmAutomation(value: SsmAutomationProperty[] | cdktn.IResolvable): void;
        resetSsmAutomation(): void;
        get ssmAutomationInput(): cdktn.IResolvable | SsmAutomationProperty[] | undefined;
    }
    interface NotificationTargetProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssmincidents_response_plan#sns_topic_arn AwsSsmincidentsResponsePlan#sns_topic_arn}
        */
        readonly snsTopicArn: string;
    }
    class NotificationTargetPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): NotificationTargetProperty | cdktn.IResolvable | undefined;
        set internalValue(value: NotificationTargetProperty | cdktn.IResolvable | undefined);
        private _snsTopicArn?;
        get snsTopicArn(): string;
        set snsTopicArn(value: string);
        get snsTopicArnInput(): string | undefined;
    }
    class NotificationTargetPropertyList extends cdktn.ComplexList {
        internalValue?: NotificationTargetProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): NotificationTargetPropertyOutputReference;
    }
    interface IncidentTemplateProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssmincidents_response_plan#dedupe_string AwsSsmincidentsResponsePlan#dedupe_string}
        */
        readonly dedupeString?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssmincidents_response_plan#impact AwsSsmincidentsResponsePlan#impact}
        */
        readonly impact: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssmincidents_response_plan#incident_tags AwsSsmincidentsResponsePlan#incident_tags}
        */
        readonly incidentTags?: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssmincidents_response_plan#summary AwsSsmincidentsResponsePlan#summary}
        */
        readonly summary?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssmincidents_response_plan#title AwsSsmincidentsResponsePlan#title}
        */
        readonly title: string;
        /**
        * notification_target block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssmincidents_response_plan#notification_target AwsSsmincidentsResponsePlan#notification_target}
        */
        readonly notificationTarget?: NotificationTargetProperty[] | cdktn.IResolvable;
    }
    class IncidentTemplatePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): IncidentTemplateProperty | undefined;
        set internalValue(value: IncidentTemplateProperty | undefined);
        private _dedupeString?;
        get dedupeString(): string;
        set dedupeString(value: string);
        resetDedupeString(): void;
        get dedupeStringInput(): string | undefined;
        private _impact?;
        get impact(): number;
        set impact(value: number);
        get impactInput(): number | undefined;
        private _incidentTags?;
        get incidentTags(): {
            [key: string]: string;
        };
        set incidentTags(value: {
            [key: string]: string;
        });
        resetIncidentTags(): void;
        get incidentTagsInput(): {
            [key: string]: string;
        } | undefined;
        private _summary?;
        get summary(): string;
        set summary(value: string);
        resetSummary(): void;
        get summaryInput(): string | undefined;
        private _title?;
        get title(): string;
        set title(value: string);
        get titleInput(): string | undefined;
        private _notificationTarget;
        get notificationTarget(): NotificationTargetPropertyList;
        putNotificationTarget(value: NotificationTargetProperty[] | cdktn.IResolvable): void;
        resetNotificationTarget(): void;
        get notificationTargetInput(): cdktn.IResolvable | NotificationTargetProperty[] | undefined;
    }
    interface PagerdutyProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssmincidents_response_plan#name AwsSsmincidentsResponsePlan#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssmincidents_response_plan#secret_id AwsSsmincidentsResponsePlan#secret_id}
        */
        readonly secretId: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssmincidents_response_plan#service_id AwsSsmincidentsResponsePlan#service_id}
        */
        readonly serviceId: string;
    }
    class PagerdutyPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): PagerdutyProperty | cdktn.IResolvable | undefined;
        set internalValue(value: PagerdutyProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _secretId?;
        get secretId(): string;
        set secretId(value: string);
        get secretIdInput(): string | undefined;
        private _serviceId?;
        get serviceId(): string;
        set serviceId(value: string);
        get serviceIdInput(): string | undefined;
    }
    class PagerdutyPropertyList extends cdktn.ComplexList {
        internalValue?: PagerdutyProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): PagerdutyPropertyOutputReference;
    }
    interface IntegrationProperty {
        /**
        * pagerduty block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssmincidents_response_plan#pagerduty AwsSsmincidentsResponsePlan#pagerduty}
        */
        readonly pagerduty?: PagerdutyProperty[] | cdktn.IResolvable;
    }
    class IntegrationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): IntegrationProperty | undefined;
        set internalValue(value: IntegrationProperty | undefined);
        private _pagerduty;
        get pagerduty(): PagerdutyPropertyList;
        putPagerduty(value: PagerdutyProperty[] | cdktn.IResolvable): void;
        resetPagerduty(): void;
        get pagerdutyInput(): cdktn.IResolvable | PagerdutyProperty[] | undefined;
    }
}
