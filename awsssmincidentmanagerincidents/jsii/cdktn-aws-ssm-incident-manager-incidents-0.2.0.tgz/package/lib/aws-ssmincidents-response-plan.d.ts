import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfResponsePlanConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssmincidents_response_plan#chat_channel TfResponsePlan#chat_channel}
    */
    readonly chatChannel?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssmincidents_response_plan#display_name TfResponsePlan#display_name}
    */
    readonly displayName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssmincidents_response_plan#engagements TfResponsePlan#engagements}
    */
    readonly engagements?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssmincidents_response_plan#id TfResponsePlan#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssmincidents_response_plan#name TfResponsePlan#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssmincidents_response_plan#region TfResponsePlan#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssmincidents_response_plan#tags TfResponsePlan#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssmincidents_response_plan#tags_all TfResponsePlan#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * action block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssmincidents_response_plan#action TfResponsePlan#action}
    */
    readonly action?: TfResponsePlan.ActionProperty;
    /**
    * incident_template block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssmincidents_response_plan#incident_template TfResponsePlan#incident_template}
    */
    readonly incidentTemplate: TfResponsePlan.IncidentTemplateProperty;
    /**
    * integration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssmincidents_response_plan#integration TfResponsePlan#integration}
    */
    readonly integration?: TfResponsePlan.IntegrationProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssmincidents_response_plan aws_ssmincidents_response_plan}
*/
export declare class TfResponsePlan extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_ssmincidents_response_plan";
    /**
    * Generates CDKTN code for importing a TfResponsePlan resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfResponsePlan to import
    * @param importFromId The id of the existing TfResponsePlan that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssmincidents_response_plan#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfResponsePlan to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssmincidents_response_plan aws_ssmincidents_response_plan} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfResponsePlanConfig
    */
    constructor(scope: Construct, id: string, config: TfResponsePlanConfig);
    get arn(): string;
    private _chatChannel?;
    get chatChannel(): string[];
    set chatChannel(value: string[]);
    resetChatChannel(): void;
    get chatChannelInput(): string[] | undefined;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    resetDisplayName(): void;
    get displayNameInput(): string | undefined;
    private _engagements?;
    get engagements(): string[];
    set engagements(value: string[]);
    resetEngagements(): void;
    get engagementsInput(): string[] | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _action;
    get action(): TfResponsePlan.ActionPropertyOutputReference;
    putAction(value: TfResponsePlan.ActionProperty): void;
    resetAction(): void;
    get actionInput(): TfResponsePlan.ActionProperty | undefined;
    private _incidentTemplate;
    get incidentTemplate(): TfResponsePlan.IncidentTemplatePropertyOutputReference;
    putIncidentTemplate(value: TfResponsePlan.IncidentTemplateProperty): void;
    get incidentTemplateInput(): TfResponsePlan.IncidentTemplateProperty | undefined;
    private _integration;
    get integration(): TfResponsePlan.IntegrationPropertyOutputReference;
    putIntegration(value: TfResponsePlan.IntegrationProperty): void;
    resetIntegration(): void;
    get integrationInput(): TfResponsePlan.IntegrationProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfResponsePlanParameterPropertyToTerraform(struct?: TfResponsePlan.ParameterProperty | cdktn.IResolvable): any;
export declare function tfResponsePlanParameterPropertyToHclTerraform(struct?: TfResponsePlan.ParameterProperty | cdktn.IResolvable): any;
export declare function tfResponsePlanSsmAutomationPropertyToTerraform(struct?: TfResponsePlan.SsmAutomationProperty | cdktn.IResolvable): any;
export declare function tfResponsePlanSsmAutomationPropertyToHclTerraform(struct?: TfResponsePlan.SsmAutomationProperty | cdktn.IResolvable): any;
export declare function tfResponsePlanActionPropertyToTerraform(struct?: TfResponsePlan.ActionPropertyOutputReference | TfResponsePlan.ActionProperty): any;
export declare function tfResponsePlanActionPropertyToHclTerraform(struct?: TfResponsePlan.ActionPropertyOutputReference | TfResponsePlan.ActionProperty): any;
export declare function tfResponsePlanNotificationTargetPropertyToTerraform(struct?: TfResponsePlan.NotificationTargetProperty | cdktn.IResolvable): any;
export declare function tfResponsePlanNotificationTargetPropertyToHclTerraform(struct?: TfResponsePlan.NotificationTargetProperty | cdktn.IResolvable): any;
export declare function tfResponsePlanIncidentTemplatePropertyToTerraform(struct?: TfResponsePlan.IncidentTemplatePropertyOutputReference | TfResponsePlan.IncidentTemplateProperty): any;
export declare function tfResponsePlanIncidentTemplatePropertyToHclTerraform(struct?: TfResponsePlan.IncidentTemplatePropertyOutputReference | TfResponsePlan.IncidentTemplateProperty): any;
export declare function tfResponsePlanPagerdutyPropertyToTerraform(struct?: TfResponsePlan.PagerdutyProperty | cdktn.IResolvable): any;
export declare function tfResponsePlanPagerdutyPropertyToHclTerraform(struct?: TfResponsePlan.PagerdutyProperty | cdktn.IResolvable): any;
export declare function tfResponsePlanIntegrationPropertyToTerraform(struct?: TfResponsePlan.IntegrationPropertyOutputReference | TfResponsePlan.IntegrationProperty): any;
export declare function tfResponsePlanIntegrationPropertyToHclTerraform(struct?: TfResponsePlan.IntegrationPropertyOutputReference | TfResponsePlan.IntegrationProperty): any;
export declare namespace TfResponsePlan {
    interface ParameterProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssmincidents_response_plan#name TfResponsePlan#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssmincidents_response_plan#values TfResponsePlan#values}
        */
        readonly values: string[];
    }
    class ParameterPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ParameterProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ParameterProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        get valuesInput(): string[] | undefined;
    }
    class ParameterPropertyList extends cdktn.ComplexList {
        internalValue?: ParameterProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ParameterPropertyOutputReference;
    }
    interface SsmAutomationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssmincidents_response_plan#document_name TfResponsePlan#document_name}
        */
        readonly documentName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssmincidents_response_plan#document_version TfResponsePlan#document_version}
        */
        readonly documentVersion?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssmincidents_response_plan#dynamic_parameters TfResponsePlan#dynamic_parameters}
        */
        readonly dynamicParameters?: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssmincidents_response_plan#role_arn TfResponsePlan#role_arn}
        */
        readonly roleArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssmincidents_response_plan#target_account TfResponsePlan#target_account}
        */
        readonly targetAccount?: string;
        /**
        * parameter block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssmincidents_response_plan#parameter TfResponsePlan#parameter}
        */
        readonly parameter?: ParameterProperty[] | cdktn.IResolvable;
    }
    class SsmAutomationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SsmAutomationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SsmAutomationProperty | cdktn.IResolvable | undefined);
        private _documentName?;
        get documentName(): string;
        set documentName(value: string);
        get documentNameInput(): string | undefined;
        private _documentVersion?;
        get documentVersion(): string;
        set documentVersion(value: string);
        resetDocumentVersion(): void;
        get documentVersionInput(): string | undefined;
        private _dynamicParameters?;
        get dynamicParameters(): {
            [key: string]: string;
        };
        set dynamicParameters(value: {
            [key: string]: string;
        });
        resetDynamicParameters(): void;
        get dynamicParametersInput(): {
            [key: string]: string;
        } | undefined;
        private _roleArn?;
        get roleArn(): string;
        set roleArn(value: string);
        get roleArnInput(): string | undefined;
        private _targetAccount?;
        get targetAccount(): string;
        set targetAccount(value: string);
        resetTargetAccount(): void;
        get targetAccountInput(): string | undefined;
        private _parameter;
        get parameter(): ParameterPropertyList;
        putParameter(value: ParameterProperty[] | cdktn.IResolvable): void;
        resetParameter(): void;
        get parameterInput(): cdktn.IResolvable | ParameterProperty[] | undefined;
    }
    class SsmAutomationPropertyList extends cdktn.ComplexList {
        internalValue?: SsmAutomationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SsmAutomationPropertyOutputReference;
    }
    interface ActionProperty {
        /**
        * ssm_automation block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssmincidents_response_plan#ssm_automation TfResponsePlan#ssm_automation}
        */
        readonly ssmAutomation?: SsmAutomationProperty[] | cdktn.IResolvable;
    }
    class ActionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ActionProperty | undefined;
        set internalValue(value: ActionProperty | undefined);
        private _ssmAutomation;
        get ssmAutomation(): SsmAutomationPropertyList;
        putSsmAutomation(value: SsmAutomationProperty[] | cdktn.IResolvable): void;
        resetSsmAutomation(): void;
        get ssmAutomationInput(): cdktn.IResolvable | SsmAutomationProperty[] | undefined;
    }
    interface NotificationTargetProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssmincidents_response_plan#sns_topic_arn TfResponsePlan#sns_topic_arn}
        */
        readonly snsTopicArn: string;
    }
    class NotificationTargetPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): NotificationTargetProperty | cdktn.IResolvable | undefined;
        set internalValue(value: NotificationTargetProperty | cdktn.IResolvable | undefined);
        private _snsTopicArn?;
        get snsTopicArn(): string;
        set snsTopicArn(value: string);
        get snsTopicArnInput(): string | undefined;
    }
    class NotificationTargetPropertyList extends cdktn.ComplexList {
        internalValue?: NotificationTargetProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): NotificationTargetPropertyOutputReference;
    }
    interface IncidentTemplateProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssmincidents_response_plan#dedupe_string TfResponsePlan#dedupe_string}
        */
        readonly dedupeString?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssmincidents_response_plan#impact TfResponsePlan#impact}
        */
        readonly impact: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssmincidents_response_plan#incident_tags TfResponsePlan#incident_tags}
        */
        readonly incidentTags?: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssmincidents_response_plan#summary TfResponsePlan#summary}
        */
        readonly summary?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssmincidents_response_plan#title TfResponsePlan#title}
        */
        readonly title: string;
        /**
        * notification_target block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssmincidents_response_plan#notification_target TfResponsePlan#notification_target}
        */
        readonly notificationTarget?: NotificationTargetProperty[] | cdktn.IResolvable;
    }
    class IncidentTemplatePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): IncidentTemplateProperty | undefined;
        set internalValue(value: IncidentTemplateProperty | undefined);
        private _dedupeString?;
        get dedupeString(): string;
        set dedupeString(value: string);
        resetDedupeString(): void;
        get dedupeStringInput(): string | undefined;
        private _impact?;
        get impact(): number;
        set impact(value: number);
        get impactInput(): number | undefined;
        private _incidentTags?;
        get incidentTags(): {
            [key: string]: string;
        };
        set incidentTags(value: {
            [key: string]: string;
        });
        resetIncidentTags(): void;
        get incidentTagsInput(): {
            [key: string]: string;
        } | undefined;
        private _summary?;
        get summary(): string;
        set summary(value: string);
        resetSummary(): void;
        get summaryInput(): string | undefined;
        private _title?;
        get title(): string;
        set title(value: string);
        get titleInput(): string | undefined;
        private _notificationTarget;
        get notificationTarget(): NotificationTargetPropertyList;
        putNotificationTarget(value: NotificationTargetProperty[] | cdktn.IResolvable): void;
        resetNotificationTarget(): void;
        get notificationTargetInput(): cdktn.IResolvable | NotificationTargetProperty[] | undefined;
    }
    interface PagerdutyProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssmincidents_response_plan#name TfResponsePlan#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssmincidents_response_plan#secret_id TfResponsePlan#secret_id}
        */
        readonly secretId: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssmincidents_response_plan#service_id TfResponsePlan#service_id}
        */
        readonly serviceId: string;
    }
    class PagerdutyPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): PagerdutyProperty | cdktn.IResolvable | undefined;
        set internalValue(value: PagerdutyProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _secretId?;
        get secretId(): string;
        set secretId(value: string);
        get secretIdInput(): string | undefined;
        private _serviceId?;
        get serviceId(): string;
        set serviceId(value: string);
        get serviceIdInput(): string | undefined;
    }
    class PagerdutyPropertyList extends cdktn.ComplexList {
        internalValue?: PagerdutyProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): PagerdutyPropertyOutputReference;
    }
    interface IntegrationProperty {
        /**
        * pagerduty block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssmincidents_response_plan#pagerduty TfResponsePlan#pagerduty}
        */
        readonly pagerduty?: PagerdutyProperty[] | cdktn.IResolvable;
    }
    class IntegrationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): IntegrationProperty | undefined;
        set internalValue(value: IntegrationProperty | undefined);
        private _pagerduty;
        get pagerduty(): PagerdutyPropertyList;
        putPagerduty(value: PagerdutyProperty[] | cdktn.IResolvable): void;
        resetPagerduty(): void;
        get pagerdutyInput(): cdktn.IResolvable | PagerdutyProperty[] | undefined;
    }
}
