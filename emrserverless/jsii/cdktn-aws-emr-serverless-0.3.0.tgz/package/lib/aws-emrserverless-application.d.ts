import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsApplicationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrserverless_application#architecture AwsApplication#architecture}
    */
    readonly architecture?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrserverless_application#id AwsApplication#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrserverless_application#name AwsApplication#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrserverless_application#region AwsApplication#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrserverless_application#release_label AwsApplication#release_label}
    */
    readonly releaseLabel: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrserverless_application#tags AwsApplication#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrserverless_application#tags_all AwsApplication#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrserverless_application#type AwsApplication#type}
    */
    readonly type: string;
    /**
    * auto_start_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrserverless_application#auto_start_configuration AwsApplication#auto_start_configuration}
    */
    readonly autoStartConfiguration?: AwsApplication.AutoStartConfigurationProperty;
    /**
    * auto_stop_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrserverless_application#auto_stop_configuration AwsApplication#auto_stop_configuration}
    */
    readonly autoStopConfiguration?: AwsApplication.AutoStopConfigurationProperty;
    /**
    * image_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrserverless_application#image_configuration AwsApplication#image_configuration}
    */
    readonly imageConfiguration?: AwsApplication.ImageConfigurationProperty;
    /**
    * initial_capacity block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrserverless_application#initial_capacity AwsApplication#initial_capacity}
    */
    readonly initialCapacity?: AwsApplication.InitialCapacityProperty[] | cdktn.IResolvable;
    /**
    * interactive_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrserverless_application#interactive_configuration AwsApplication#interactive_configuration}
    */
    readonly interactiveConfiguration?: AwsApplication.InteractiveConfigurationProperty;
    /**
    * job_level_cost_allocation_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrserverless_application#job_level_cost_allocation_configuration AwsApplication#job_level_cost_allocation_configuration}
    */
    readonly jobLevelCostAllocationConfiguration?: AwsApplication.JobLevelCostAllocationConfigurationProperty;
    /**
    * maximum_capacity block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrserverless_application#maximum_capacity AwsApplication#maximum_capacity}
    */
    readonly maximumCapacity?: AwsApplication.MaximumCapacityProperty;
    /**
    * monitoring_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrserverless_application#monitoring_configuration AwsApplication#monitoring_configuration}
    */
    readonly monitoringConfiguration?: AwsApplication.MonitoringConfigurationProperty;
    /**
    * network_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrserverless_application#network_configuration AwsApplication#network_configuration}
    */
    readonly networkConfiguration?: AwsApplication.NetworkConfigurationProperty;
    /**
    * runtime_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrserverless_application#runtime_configuration AwsApplication#runtime_configuration}
    */
    readonly runtimeConfiguration?: AwsApplication.RuntimeConfigurationProperty[] | cdktn.IResolvable;
    /**
    * scheduler_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrserverless_application#scheduler_configuration AwsApplication#scheduler_configuration}
    */
    readonly schedulerConfiguration?: AwsApplication.SchedulerConfigurationProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrserverless_application aws_emrserverless_application}
*/
export declare class AwsApplication extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_emrserverless_application";
    /**
    * Generates CDKTN code for importing a AwsApplication resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsApplication to import
    * @param importFromId The id of the existing AwsApplication that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrserverless_application#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsApplication to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrserverless_application aws_emrserverless_application} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsApplicationConfig
    */
    constructor(scope: Construct, id: string, config: AwsApplicationConfig);
    private _architecture?;
    get architecture(): string;
    set architecture(value: string);
    resetArchitecture(): void;
    get architectureInput(): string | undefined;
    get arn(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _releaseLabel?;
    get releaseLabel(): string;
    set releaseLabel(value: string);
    get releaseLabelInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _autoStartConfiguration;
    get autoStartConfiguration(): AwsApplication.AutoStartConfigurationPropertyOutputReference;
    putAutoStartConfiguration(value: AwsApplication.AutoStartConfigurationProperty): void;
    resetAutoStartConfiguration(): void;
    get autoStartConfigurationInput(): AwsApplication.AutoStartConfigurationProperty | undefined;
    private _autoStopConfiguration;
    get autoStopConfiguration(): AwsApplication.AutoStopConfigurationPropertyOutputReference;
    putAutoStopConfiguration(value: AwsApplication.AutoStopConfigurationProperty): void;
    resetAutoStopConfiguration(): void;
    get autoStopConfigurationInput(): AwsApplication.AutoStopConfigurationProperty | undefined;
    private _imageConfiguration;
    get imageConfiguration(): AwsApplication.ImageConfigurationPropertyOutputReference;
    putImageConfiguration(value: AwsApplication.ImageConfigurationProperty): void;
    resetImageConfiguration(): void;
    get imageConfigurationInput(): AwsApplication.ImageConfigurationProperty | undefined;
    private _initialCapacity;
    get initialCapacity(): AwsApplication.InitialCapacityPropertyList;
    putInitialCapacity(value: AwsApplication.InitialCapacityProperty[] | cdktn.IResolvable): void;
    resetInitialCapacity(): void;
    get initialCapacityInput(): cdktn.IResolvable | AwsApplication.InitialCapacityProperty[] | undefined;
    private _interactiveConfiguration;
    get interactiveConfiguration(): AwsApplication.InteractiveConfigurationPropertyOutputReference;
    putInteractiveConfiguration(value: AwsApplication.InteractiveConfigurationProperty): void;
    resetInteractiveConfiguration(): void;
    get interactiveConfigurationInput(): AwsApplication.InteractiveConfigurationProperty | undefined;
    private _jobLevelCostAllocationConfiguration;
    get jobLevelCostAllocationConfiguration(): AwsApplication.JobLevelCostAllocationConfigurationPropertyOutputReference;
    putJobLevelCostAllocationConfiguration(value: AwsApplication.JobLevelCostAllocationConfigurationProperty): void;
    resetJobLevelCostAllocationConfiguration(): void;
    get jobLevelCostAllocationConfigurationInput(): AwsApplication.JobLevelCostAllocationConfigurationProperty | undefined;
    private _maximumCapacity;
    get maximumCapacity(): AwsApplication.MaximumCapacityPropertyOutputReference;
    putMaximumCapacity(value: AwsApplication.MaximumCapacityProperty): void;
    resetMaximumCapacity(): void;
    get maximumCapacityInput(): AwsApplication.MaximumCapacityProperty | undefined;
    private _monitoringConfiguration;
    get monitoringConfiguration(): AwsApplication.MonitoringConfigurationPropertyOutputReference;
    putMonitoringConfiguration(value: AwsApplication.MonitoringConfigurationProperty): void;
    resetMonitoringConfiguration(): void;
    get monitoringConfigurationInput(): AwsApplication.MonitoringConfigurationProperty | undefined;
    private _networkConfiguration;
    get networkConfiguration(): AwsApplication.NetworkConfigurationPropertyOutputReference;
    putNetworkConfiguration(value: AwsApplication.NetworkConfigurationProperty): void;
    resetNetworkConfiguration(): void;
    get networkConfigurationInput(): AwsApplication.NetworkConfigurationProperty | undefined;
    private _runtimeConfiguration;
    get runtimeConfiguration(): AwsApplication.RuntimeConfigurationPropertyList;
    putRuntimeConfiguration(value: AwsApplication.RuntimeConfigurationProperty[] | cdktn.IResolvable): void;
    resetRuntimeConfiguration(): void;
    get runtimeConfigurationInput(): cdktn.IResolvable | AwsApplication.RuntimeConfigurationProperty[] | undefined;
    private _schedulerConfiguration;
    get schedulerConfiguration(): AwsApplication.SchedulerConfigurationPropertyOutputReference;
    putSchedulerConfiguration(value: AwsApplication.SchedulerConfigurationProperty): void;
    resetSchedulerConfiguration(): void;
    get schedulerConfigurationInput(): AwsApplication.SchedulerConfigurationProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsApplicationAutoStartConfigurationPropertyToTerraform(struct?: AwsApplication.AutoStartConfigurationPropertyOutputReference | AwsApplication.AutoStartConfigurationProperty): any;
export declare function awsApplicationAutoStartConfigurationPropertyToHclTerraform(struct?: AwsApplication.AutoStartConfigurationPropertyOutputReference | AwsApplication.AutoStartConfigurationProperty): any;
export declare function awsApplicationAutoStopConfigurationPropertyToTerraform(struct?: AwsApplication.AutoStopConfigurationPropertyOutputReference | AwsApplication.AutoStopConfigurationProperty): any;
export declare function awsApplicationAutoStopConfigurationPropertyToHclTerraform(struct?: AwsApplication.AutoStopConfigurationPropertyOutputReference | AwsApplication.AutoStopConfigurationProperty): any;
export declare function awsApplicationImageConfigurationPropertyToTerraform(struct?: AwsApplication.ImageConfigurationPropertyOutputReference | AwsApplication.ImageConfigurationProperty): any;
export declare function awsApplicationImageConfigurationPropertyToHclTerraform(struct?: AwsApplication.ImageConfigurationPropertyOutputReference | AwsApplication.ImageConfigurationProperty): any;
export declare function awsApplicationWorkerConfigurationPropertyToTerraform(struct?: AwsApplication.WorkerConfigurationPropertyOutputReference | AwsApplication.WorkerConfigurationProperty): any;
export declare function awsApplicationWorkerConfigurationPropertyToHclTerraform(struct?: AwsApplication.WorkerConfigurationPropertyOutputReference | AwsApplication.WorkerConfigurationProperty): any;
export declare function awsApplicationInitialCapacityConfigPropertyToTerraform(struct?: AwsApplication.InitialCapacityConfigPropertyOutputReference | AwsApplication.InitialCapacityConfigProperty): any;
export declare function awsApplicationInitialCapacityConfigPropertyToHclTerraform(struct?: AwsApplication.InitialCapacityConfigPropertyOutputReference | AwsApplication.InitialCapacityConfigProperty): any;
export declare function awsApplicationInitialCapacityPropertyToTerraform(struct?: AwsApplication.InitialCapacityProperty | cdktn.IResolvable): any;
export declare function awsApplicationInitialCapacityPropertyToHclTerraform(struct?: AwsApplication.InitialCapacityProperty | cdktn.IResolvable): any;
export declare function awsApplicationInteractiveConfigurationPropertyToTerraform(struct?: AwsApplication.InteractiveConfigurationPropertyOutputReference | AwsApplication.InteractiveConfigurationProperty): any;
export declare function awsApplicationInteractiveConfigurationPropertyToHclTerraform(struct?: AwsApplication.InteractiveConfigurationPropertyOutputReference | AwsApplication.InteractiveConfigurationProperty): any;
export declare function awsApplicationJobLevelCostAllocationConfigurationPropertyToTerraform(struct?: AwsApplication.JobLevelCostAllocationConfigurationPropertyOutputReference | AwsApplication.JobLevelCostAllocationConfigurationProperty): any;
export declare function awsApplicationJobLevelCostAllocationConfigurationPropertyToHclTerraform(struct?: AwsApplication.JobLevelCostAllocationConfigurationPropertyOutputReference | AwsApplication.JobLevelCostAllocationConfigurationProperty): any;
export declare function awsApplicationMaximumCapacityPropertyToTerraform(struct?: AwsApplication.MaximumCapacityPropertyOutputReference | AwsApplication.MaximumCapacityProperty): any;
export declare function awsApplicationMaximumCapacityPropertyToHclTerraform(struct?: AwsApplication.MaximumCapacityPropertyOutputReference | AwsApplication.MaximumCapacityProperty): any;
export declare function awsApplicationLogTypesPropertyToTerraform(struct?: AwsApplication.LogTypesProperty | cdktn.IResolvable): any;
export declare function awsApplicationLogTypesPropertyToHclTerraform(struct?: AwsApplication.LogTypesProperty | cdktn.IResolvable): any;
export declare function awsApplicationCloudwatchLoggingConfigurationPropertyToTerraform(struct?: AwsApplication.CloudwatchLoggingConfigurationPropertyOutputReference | AwsApplication.CloudwatchLoggingConfigurationProperty): any;
export declare function awsApplicationCloudwatchLoggingConfigurationPropertyToHclTerraform(struct?: AwsApplication.CloudwatchLoggingConfigurationPropertyOutputReference | AwsApplication.CloudwatchLoggingConfigurationProperty): any;
export declare function awsApplicationManagedPersistenceMonitoringConfigurationPropertyToTerraform(struct?: AwsApplication.ManagedPersistenceMonitoringConfigurationPropertyOutputReference | AwsApplication.ManagedPersistenceMonitoringConfigurationProperty): any;
export declare function awsApplicationManagedPersistenceMonitoringConfigurationPropertyToHclTerraform(struct?: AwsApplication.ManagedPersistenceMonitoringConfigurationPropertyOutputReference | AwsApplication.ManagedPersistenceMonitoringConfigurationProperty): any;
export declare function awsApplicationPrometheusMonitoringConfigurationPropertyToTerraform(struct?: AwsApplication.PrometheusMonitoringConfigurationPropertyOutputReference | AwsApplication.PrometheusMonitoringConfigurationProperty): any;
export declare function awsApplicationPrometheusMonitoringConfigurationPropertyToHclTerraform(struct?: AwsApplication.PrometheusMonitoringConfigurationPropertyOutputReference | AwsApplication.PrometheusMonitoringConfigurationProperty): any;
export declare function awsApplicationS3MonitoringConfigurationPropertyToTerraform(struct?: AwsApplication.S3MonitoringConfigurationPropertyOutputReference | AwsApplication.S3MonitoringConfigurationProperty): any;
export declare function awsApplicationS3MonitoringConfigurationPropertyToHclTerraform(struct?: AwsApplication.S3MonitoringConfigurationPropertyOutputReference | AwsApplication.S3MonitoringConfigurationProperty): any;
export declare function awsApplicationMonitoringConfigurationPropertyToTerraform(struct?: AwsApplication.MonitoringConfigurationPropertyOutputReference | AwsApplication.MonitoringConfigurationProperty): any;
export declare function awsApplicationMonitoringConfigurationPropertyToHclTerraform(struct?: AwsApplication.MonitoringConfigurationPropertyOutputReference | AwsApplication.MonitoringConfigurationProperty): any;
export declare function awsApplicationNetworkConfigurationPropertyToTerraform(struct?: AwsApplication.NetworkConfigurationPropertyOutputReference | AwsApplication.NetworkConfigurationProperty): any;
export declare function awsApplicationNetworkConfigurationPropertyToHclTerraform(struct?: AwsApplication.NetworkConfigurationPropertyOutputReference | AwsApplication.NetworkConfigurationProperty): any;
export declare function awsApplicationRuntimeConfigurationPropertyToTerraform(struct?: AwsApplication.RuntimeConfigurationProperty | cdktn.IResolvable): any;
export declare function awsApplicationRuntimeConfigurationPropertyToHclTerraform(struct?: AwsApplication.RuntimeConfigurationProperty | cdktn.IResolvable): any;
export declare function awsApplicationSchedulerConfigurationPropertyToTerraform(struct?: AwsApplication.SchedulerConfigurationPropertyOutputReference | AwsApplication.SchedulerConfigurationProperty): any;
export declare function awsApplicationSchedulerConfigurationPropertyToHclTerraform(struct?: AwsApplication.SchedulerConfigurationPropertyOutputReference | AwsApplication.SchedulerConfigurationProperty): any;
export declare namespace AwsApplication {
    interface AutoStartConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrserverless_application#enabled AwsApplication#enabled}
        */
        readonly enabled?: boolean | cdktn.IResolvable;
    }
    class AutoStartConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AutoStartConfigurationProperty | undefined;
        set internalValue(value: AutoStartConfigurationProperty | undefined);
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        resetEnabled(): void;
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface AutoStopConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrserverless_application#enabled AwsApplication#enabled}
        */
        readonly enabled?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrserverless_application#idle_timeout_minutes AwsApplication#idle_timeout_minutes}
        */
        readonly idleTimeoutMinutes?: number;
    }
    class AutoStopConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AutoStopConfigurationProperty | undefined;
        set internalValue(value: AutoStopConfigurationProperty | undefined);
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        resetEnabled(): void;
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
        private _idleTimeoutMinutes?;
        get idleTimeoutMinutes(): number;
        set idleTimeoutMinutes(value: number);
        resetIdleTimeoutMinutes(): void;
        get idleTimeoutMinutesInput(): number | undefined;
    }
    interface ImageConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrserverless_application#image_uri AwsApplication#image_uri}
        */
        readonly imageUri: string;
    }
    class ImageConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ImageConfigurationProperty | undefined;
        set internalValue(value: ImageConfigurationProperty | undefined);
        private _imageUri?;
        get imageUri(): string;
        set imageUri(value: string);
        get imageUriInput(): string | undefined;
    }
    interface WorkerConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrserverless_application#cpu AwsApplication#cpu}
        */
        readonly cpu: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrserverless_application#disk AwsApplication#disk}
        */
        readonly disk?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrserverless_application#memory AwsApplication#memory}
        */
        readonly memory: string;
    }
    class WorkerConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): WorkerConfigurationProperty | undefined;
        set internalValue(value: WorkerConfigurationProperty | undefined);
        private _cpu?;
        get cpu(): string;
        set cpu(value: string);
        get cpuInput(): string | undefined;
        private _disk?;
        get disk(): string;
        set disk(value: string);
        resetDisk(): void;
        get diskInput(): string | undefined;
        private _memory?;
        get memory(): string;
        set memory(value: string);
        get memoryInput(): string | undefined;
    }
    interface InitialCapacityConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrserverless_application#worker_count AwsApplication#worker_count}
        */
        readonly workerCount: number;
        /**
        * worker_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrserverless_application#worker_configuration AwsApplication#worker_configuration}
        */
        readonly workerConfiguration?: WorkerConfigurationProperty;
    }
    class InitialCapacityConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): InitialCapacityConfigProperty | undefined;
        set internalValue(value: InitialCapacityConfigProperty | undefined);
        private _workerCount?;
        get workerCount(): number;
        set workerCount(value: number);
        get workerCountInput(): number | undefined;
        private _workerConfiguration;
        get workerConfiguration(): WorkerConfigurationPropertyOutputReference;
        putWorkerConfiguration(value: WorkerConfigurationProperty): void;
        resetWorkerConfiguration(): void;
        get workerConfigurationInput(): WorkerConfigurationProperty | undefined;
    }
    interface InitialCapacityProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrserverless_application#initial_capacity_type AwsApplication#initial_capacity_type}
        */
        readonly initialCapacityType: string;
        /**
        * initial_capacity_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrserverless_application#initial_capacity_config AwsApplication#initial_capacity_config}
        */
        readonly initialCapacityConfig?: InitialCapacityConfigProperty;
    }
    class InitialCapacityPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): InitialCapacityProperty | cdktn.IResolvable | undefined;
        set internalValue(value: InitialCapacityProperty | cdktn.IResolvable | undefined);
        private _initialCapacityType?;
        get initialCapacityType(): string;
        set initialCapacityType(value: string);
        get initialCapacityTypeInput(): string | undefined;
        private _initialCapacityConfig;
        get initialCapacityConfig(): InitialCapacityConfigPropertyOutputReference;
        putInitialCapacityConfig(value: InitialCapacityConfigProperty): void;
        resetInitialCapacityConfig(): void;
        get initialCapacityConfigInput(): InitialCapacityConfigProperty | undefined;
    }
    class InitialCapacityPropertyList extends cdktn.ComplexList {
        internalValue?: InitialCapacityProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): InitialCapacityPropertyOutputReference;
    }
    interface InteractiveConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrserverless_application#livy_endpoint_enabled AwsApplication#livy_endpoint_enabled}
        */
        readonly livyEndpointEnabled?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrserverless_application#studio_enabled AwsApplication#studio_enabled}
        */
        readonly studioEnabled?: boolean | cdktn.IResolvable;
    }
    class InteractiveConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): InteractiveConfigurationProperty | undefined;
        set internalValue(value: InteractiveConfigurationProperty | undefined);
        private _livyEndpointEnabled?;
        get livyEndpointEnabled(): boolean | cdktn.IResolvable;
        set livyEndpointEnabled(value: boolean | cdktn.IResolvable);
        resetLivyEndpointEnabled(): void;
        get livyEndpointEnabledInput(): boolean | cdktn.IResolvable | undefined;
        private _studioEnabled?;
        get studioEnabled(): boolean | cdktn.IResolvable;
        set studioEnabled(value: boolean | cdktn.IResolvable);
        resetStudioEnabled(): void;
        get studioEnabledInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface JobLevelCostAllocationConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrserverless_application#enabled AwsApplication#enabled}
        */
        readonly enabled?: boolean | cdktn.IResolvable;
    }
    class JobLevelCostAllocationConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): JobLevelCostAllocationConfigurationProperty | undefined;
        set internalValue(value: JobLevelCostAllocationConfigurationProperty | undefined);
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        resetEnabled(): void;
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface MaximumCapacityProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrserverless_application#cpu AwsApplication#cpu}
        */
        readonly cpu: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrserverless_application#disk AwsApplication#disk}
        */
        readonly disk?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrserverless_application#memory AwsApplication#memory}
        */
        readonly memory: string;
    }
    class MaximumCapacityPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): MaximumCapacityProperty | undefined;
        set internalValue(value: MaximumCapacityProperty | undefined);
        private _cpu?;
        get cpu(): string;
        set cpu(value: string);
        get cpuInput(): string | undefined;
        private _disk?;
        get disk(): string;
        set disk(value: string);
        resetDisk(): void;
        get diskInput(): string | undefined;
        private _memory?;
        get memory(): string;
        set memory(value: string);
        get memoryInput(): string | undefined;
    }
    interface LogTypesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrserverless_application#name AwsApplication#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrserverless_application#values AwsApplication#values}
        */
        readonly values: string[];
    }
    class LogTypesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): LogTypesProperty | cdktn.IResolvable | undefined;
        set internalValue(value: LogTypesProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        get valuesInput(): string[] | undefined;
    }
    class LogTypesPropertyList extends cdktn.ComplexList {
        internalValue?: LogTypesProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): LogTypesPropertyOutputReference;
    }
    interface CloudwatchLoggingConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrserverless_application#enabled AwsApplication#enabled}
        */
        readonly enabled: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrserverless_application#encryption_key_arn AwsApplication#encryption_key_arn}
        */
        readonly encryptionKeyArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrserverless_application#log_group_name AwsApplication#log_group_name}
        */
        readonly logGroupName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrserverless_application#log_stream_name_prefix AwsApplication#log_stream_name_prefix}
        */
        readonly logStreamNamePrefix?: string;
        /**
        * log_types block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrserverless_application#log_types AwsApplication#log_types}
        */
        readonly logTypes?: LogTypesProperty[] | cdktn.IResolvable;
    }
    class CloudwatchLoggingConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CloudwatchLoggingConfigurationProperty | undefined;
        set internalValue(value: CloudwatchLoggingConfigurationProperty | undefined);
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
        private _encryptionKeyArn?;
        get encryptionKeyArn(): string;
        set encryptionKeyArn(value: string);
        resetEncryptionKeyArn(): void;
        get encryptionKeyArnInput(): string | undefined;
        private _logGroupName?;
        get logGroupName(): string;
        set logGroupName(value: string);
        resetLogGroupName(): void;
        get logGroupNameInput(): string | undefined;
        private _logStreamNamePrefix?;
        get logStreamNamePrefix(): string;
        set logStreamNamePrefix(value: string);
        resetLogStreamNamePrefix(): void;
        get logStreamNamePrefixInput(): string | undefined;
        private _logTypes;
        get logTypes(): LogTypesPropertyList;
        putLogTypes(value: LogTypesProperty[] | cdktn.IResolvable): void;
        resetLogTypes(): void;
        get logTypesInput(): cdktn.IResolvable | LogTypesProperty[] | undefined;
    }
    interface ManagedPersistenceMonitoringConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrserverless_application#enabled AwsApplication#enabled}
        */
        readonly enabled?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrserverless_application#encryption_key_arn AwsApplication#encryption_key_arn}
        */
        readonly encryptionKeyArn?: string;
    }
    class ManagedPersistenceMonitoringConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ManagedPersistenceMonitoringConfigurationProperty | undefined;
        set internalValue(value: ManagedPersistenceMonitoringConfigurationProperty | undefined);
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        resetEnabled(): void;
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
        private _encryptionKeyArn?;
        get encryptionKeyArn(): string;
        set encryptionKeyArn(value: string);
        resetEncryptionKeyArn(): void;
        get encryptionKeyArnInput(): string | undefined;
    }
    interface PrometheusMonitoringConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrserverless_application#remote_write_url AwsApplication#remote_write_url}
        */
        readonly remoteWriteUrl?: string;
    }
    class PrometheusMonitoringConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): PrometheusMonitoringConfigurationProperty | undefined;
        set internalValue(value: PrometheusMonitoringConfigurationProperty | undefined);
        private _remoteWriteUrl?;
        get remoteWriteUrl(): string;
        set remoteWriteUrl(value: string);
        resetRemoteWriteUrl(): void;
        get remoteWriteUrlInput(): string | undefined;
    }
    interface S3MonitoringConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrserverless_application#encryption_key_arn AwsApplication#encryption_key_arn}
        */
        readonly encryptionKeyArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrserverless_application#log_uri AwsApplication#log_uri}
        */
        readonly logUri?: string;
    }
    class S3MonitoringConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): S3MonitoringConfigurationProperty | undefined;
        set internalValue(value: S3MonitoringConfigurationProperty | undefined);
        private _encryptionKeyArn?;
        get encryptionKeyArn(): string;
        set encryptionKeyArn(value: string);
        resetEncryptionKeyArn(): void;
        get encryptionKeyArnInput(): string | undefined;
        private _logUri?;
        get logUri(): string;
        set logUri(value: string);
        resetLogUri(): void;
        get logUriInput(): string | undefined;
    }
    interface MonitoringConfigurationProperty {
        /**
        * cloudwatch_logging_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrserverless_application#cloudwatch_logging_configuration AwsApplication#cloudwatch_logging_configuration}
        */
        readonly cloudwatchLoggingConfiguration?: CloudwatchLoggingConfigurationProperty;
        /**
        * managed_persistence_monitoring_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrserverless_application#managed_persistence_monitoring_configuration AwsApplication#managed_persistence_monitoring_configuration}
        */
        readonly managedPersistenceMonitoringConfiguration?: ManagedPersistenceMonitoringConfigurationProperty;
        /**
        * prometheus_monitoring_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrserverless_application#prometheus_monitoring_configuration AwsApplication#prometheus_monitoring_configuration}
        */
        readonly prometheusMonitoringConfiguration?: PrometheusMonitoringConfigurationProperty;
        /**
        * s3_monitoring_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrserverless_application#s3_monitoring_configuration AwsApplication#s3_monitoring_configuration}
        */
        readonly s3MonitoringConfiguration?: S3MonitoringConfigurationProperty;
    }
    class MonitoringConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): MonitoringConfigurationProperty | undefined;
        set internalValue(value: MonitoringConfigurationProperty | undefined);
        private _cloudwatchLoggingConfiguration;
        get cloudwatchLoggingConfiguration(): CloudwatchLoggingConfigurationPropertyOutputReference;
        putCloudwatchLoggingConfiguration(value: CloudwatchLoggingConfigurationProperty): void;
        resetCloudwatchLoggingConfiguration(): void;
        get cloudwatchLoggingConfigurationInput(): CloudwatchLoggingConfigurationProperty | undefined;
        private _managedPersistenceMonitoringConfiguration;
        get managedPersistenceMonitoringConfiguration(): ManagedPersistenceMonitoringConfigurationPropertyOutputReference;
        putManagedPersistenceMonitoringConfiguration(value: ManagedPersistenceMonitoringConfigurationProperty): void;
        resetManagedPersistenceMonitoringConfiguration(): void;
        get managedPersistenceMonitoringConfigurationInput(): ManagedPersistenceMonitoringConfigurationProperty | undefined;
        private _prometheusMonitoringConfiguration;
        get prometheusMonitoringConfiguration(): PrometheusMonitoringConfigurationPropertyOutputReference;
        putPrometheusMonitoringConfiguration(value: PrometheusMonitoringConfigurationProperty): void;
        resetPrometheusMonitoringConfiguration(): void;
        get prometheusMonitoringConfigurationInput(): PrometheusMonitoringConfigurationProperty | undefined;
        private _s3MonitoringConfiguration;
        get s3MonitoringConfiguration(): S3MonitoringConfigurationPropertyOutputReference;
        putS3MonitoringConfiguration(value: S3MonitoringConfigurationProperty): void;
        resetS3MonitoringConfiguration(): void;
        get s3MonitoringConfigurationInput(): S3MonitoringConfigurationProperty | undefined;
    }
    interface NetworkConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrserverless_application#security_group_ids AwsApplication#security_group_ids}
        */
        readonly securityGroupIds?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrserverless_application#subnet_ids AwsApplication#subnet_ids}
        */
        readonly subnetIds?: string[];
    }
    class NetworkConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): NetworkConfigurationProperty | undefined;
        set internalValue(value: NetworkConfigurationProperty | undefined);
        private _securityGroupIds?;
        get securityGroupIds(): string[];
        set securityGroupIds(value: string[]);
        resetSecurityGroupIds(): void;
        get securityGroupIdsInput(): string[] | undefined;
        private _subnetIds?;
        get subnetIds(): string[];
        set subnetIds(value: string[]);
        resetSubnetIds(): void;
        get subnetIdsInput(): string[] | undefined;
    }
    interface RuntimeConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrserverless_application#classification AwsApplication#classification}
        */
        readonly classification: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrserverless_application#properties AwsApplication#properties}
        */
        readonly properties?: {
            [key: string]: string;
        };
    }
    class RuntimeConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuntimeConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RuntimeConfigurationProperty | cdktn.IResolvable | undefined);
        private _classification?;
        get classification(): string;
        set classification(value: string);
        get classificationInput(): string | undefined;
        private _properties?;
        get properties(): {
            [key: string]: string;
        };
        set properties(value: {
            [key: string]: string;
        });
        resetProperties(): void;
        get propertiesInput(): {
            [key: string]: string;
        } | undefined;
    }
    class RuntimeConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: RuntimeConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuntimeConfigurationPropertyOutputReference;
    }
    interface SchedulerConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrserverless_application#max_concurrent_runs AwsApplication#max_concurrent_runs}
        */
        readonly maxConcurrentRuns?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrserverless_application#queue_timeout_minutes AwsApplication#queue_timeout_minutes}
        */
        readonly queueTimeoutMinutes?: number;
    }
    class SchedulerConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SchedulerConfigurationProperty | undefined;
        set internalValue(value: SchedulerConfigurationProperty | undefined);
        private _maxConcurrentRuns?;
        get maxConcurrentRuns(): number;
        set maxConcurrentRuns(value: number);
        resetMaxConcurrentRuns(): void;
        get maxConcurrentRunsInput(): number | undefined;
        private _queueTimeoutMinutes?;
        get queueTimeoutMinutes(): number;
        set queueTimeoutMinutes(value: number);
        resetQueueTimeoutMinutes(): void;
        get queueTimeoutMinutesInput(): number | undefined;
    }
}
