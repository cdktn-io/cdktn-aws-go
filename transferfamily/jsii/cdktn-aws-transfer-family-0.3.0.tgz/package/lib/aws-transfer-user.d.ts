import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsUserConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_user#home_directory AwsUser#home_directory}
    */
    readonly homeDirectory?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_user#home_directory_type AwsUser#home_directory_type}
    */
    readonly homeDirectoryType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_user#id AwsUser#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_user#policy AwsUser#policy}
    */
    readonly policy?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_user#region AwsUser#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_user#role AwsUser#role}
    */
    readonly role: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_user#server_id AwsUser#server_id}
    */
    readonly serverId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_user#tags AwsUser#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_user#tags_all AwsUser#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_user#user_name AwsUser#user_name}
    */
    readonly userName: string;
    /**
    * home_directory_mappings block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_user#home_directory_mappings AwsUser#home_directory_mappings}
    */
    readonly homeDirectoryMappings?: AwsUser.HomeDirectoryMappingsProperty[] | cdktn.IResolvable;
    /**
    * posix_profile block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_user#posix_profile AwsUser#posix_profile}
    */
    readonly posixProfile?: AwsUser.PosixProfileProperty;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_user#timeouts AwsUser#timeouts}
    */
    readonly timeouts?: AwsUser.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_user aws_transfer_user}
*/
export declare class AwsUser extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_transfer_user";
    /**
    * Generates CDKTN code for importing a AwsUser resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsUser to import
    * @param importFromId The id of the existing AwsUser that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_user#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsUser to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_user aws_transfer_user} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsUserConfig
    */
    constructor(scope: Construct, id: string, config: AwsUserConfig);
    get arn(): string;
    private _homeDirectory?;
    get homeDirectory(): string;
    set homeDirectory(value: string);
    resetHomeDirectory(): void;
    get homeDirectoryInput(): string | undefined;
    private _homeDirectoryType?;
    get homeDirectoryType(): string;
    set homeDirectoryType(value: string);
    resetHomeDirectoryType(): void;
    get homeDirectoryTypeInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _policy?;
    get policy(): string;
    set policy(value: string);
    resetPolicy(): void;
    get policyInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _role?;
    get role(): string;
    set role(value: string);
    get roleInput(): string | undefined;
    private _serverId?;
    get serverId(): string;
    set serverId(value: string);
    get serverIdInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _userName?;
    get userName(): string;
    set userName(value: string);
    get userNameInput(): string | undefined;
    private _homeDirectoryMappings;
    get homeDirectoryMappings(): AwsUser.HomeDirectoryMappingsPropertyList;
    putHomeDirectoryMappings(value: AwsUser.HomeDirectoryMappingsProperty[] | cdktn.IResolvable): void;
    resetHomeDirectoryMappings(): void;
    get homeDirectoryMappingsInput(): cdktn.IResolvable | AwsUser.HomeDirectoryMappingsProperty[] | undefined;
    private _posixProfile;
    get posixProfile(): AwsUser.PosixProfilePropertyOutputReference;
    putPosixProfile(value: AwsUser.PosixProfileProperty): void;
    resetPosixProfile(): void;
    get posixProfileInput(): AwsUser.PosixProfileProperty | undefined;
    private _timeouts;
    get timeouts(): AwsUser.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsUser.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsUser.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsUserHomeDirectoryMappingsPropertyToTerraform(struct?: AwsUser.HomeDirectoryMappingsProperty | cdktn.IResolvable): any;
export declare function awsUserHomeDirectoryMappingsPropertyToHclTerraform(struct?: AwsUser.HomeDirectoryMappingsProperty | cdktn.IResolvable): any;
export declare function awsUserPosixProfilePropertyToTerraform(struct?: AwsUser.PosixProfilePropertyOutputReference | AwsUser.PosixProfileProperty): any;
export declare function awsUserPosixProfilePropertyToHclTerraform(struct?: AwsUser.PosixProfilePropertyOutputReference | AwsUser.PosixProfileProperty): any;
export declare function awsUserTimeoutsPropertyToTerraform(struct?: AwsUser.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsUserTimeoutsPropertyToHclTerraform(struct?: AwsUser.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsUser {
    interface HomeDirectoryMappingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_user#entry AwsUser#entry}
        */
        readonly entry: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_user#target AwsUser#target}
        */
        readonly target: string;
    }
    class HomeDirectoryMappingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): HomeDirectoryMappingsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: HomeDirectoryMappingsProperty | cdktn.IResolvable | undefined);
        private _entry?;
        get entry(): string;
        set entry(value: string);
        get entryInput(): string | undefined;
        private _target?;
        get target(): string;
        set target(value: string);
        get targetInput(): string | undefined;
    }
    class HomeDirectoryMappingsPropertyList extends cdktn.ComplexList {
        internalValue?: HomeDirectoryMappingsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): HomeDirectoryMappingsPropertyOutputReference;
    }
    interface PosixProfileProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_user#gid AwsUser#gid}
        */
        readonly gid: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_user#secondary_gids AwsUser#secondary_gids}
        */
        readonly secondaryGids?: number[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_user#uid AwsUser#uid}
        */
        readonly uid: number;
    }
    class PosixProfilePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): PosixProfileProperty | undefined;
        set internalValue(value: PosixProfileProperty | undefined);
        private _gid?;
        get gid(): number;
        set gid(value: number);
        get gidInput(): number | undefined;
        private _secondaryGids?;
        get secondaryGids(): number[];
        set secondaryGids(value: number[]);
        resetSecondaryGids(): void;
        get secondaryGidsInput(): number[] | undefined;
        private _uid?;
        get uid(): number;
        set uid(value: number);
        get uidInput(): number | undefined;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_user#delete AwsUser#delete}
        */
        readonly delete?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
    }
}
