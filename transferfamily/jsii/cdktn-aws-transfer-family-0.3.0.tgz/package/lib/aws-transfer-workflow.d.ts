import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsWorkflowConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_workflow#description AwsWorkflow#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_workflow#id AwsWorkflow#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_workflow#region AwsWorkflow#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_workflow#tags AwsWorkflow#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_workflow#tags_all AwsWorkflow#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * on_exception_steps block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_workflow#on_exception_steps AwsWorkflow#on_exception_steps}
    */
    readonly onExceptionSteps?: AwsWorkflow.OnExceptionStepsProperty[] | cdktn.IResolvable;
    /**
    * steps block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_workflow#steps AwsWorkflow#steps}
    */
    readonly steps: AwsWorkflow.StepsProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_workflow aws_transfer_workflow}
*/
export declare class AwsWorkflow extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_transfer_workflow";
    /**
    * Generates CDKTN code for importing a AwsWorkflow resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsWorkflow to import
    * @param importFromId The id of the existing AwsWorkflow that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_workflow#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsWorkflow to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_workflow aws_transfer_workflow} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsWorkflowConfig
    */
    constructor(scope: Construct, id: string, config: AwsWorkflowConfig);
    get arn(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _onExceptionSteps;
    get onExceptionSteps(): AwsWorkflow.OnExceptionStepsPropertyList;
    putOnExceptionSteps(value: AwsWorkflow.OnExceptionStepsProperty[] | cdktn.IResolvable): void;
    resetOnExceptionSteps(): void;
    get onExceptionStepsInput(): cdktn.IResolvable | AwsWorkflow.OnExceptionStepsProperty[] | undefined;
    private _steps;
    get steps(): AwsWorkflow.StepsPropertyList;
    putSteps(value: AwsWorkflow.StepsProperty[] | cdktn.IResolvable): void;
    get stepsInput(): cdktn.IResolvable | AwsWorkflow.StepsProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsWorkflowOnExceptionStepsCopyStepDetailsDestinationFileLocationEfsFileLocationPropertyToTerraform(struct?: AwsWorkflow.OnExceptionStepsCopyStepDetailsDestinationFileLocationEfsFileLocationPropertyOutputReference | AwsWorkflow.OnExceptionStepsCopyStepDetailsDestinationFileLocationEfsFileLocationProperty): any;
export declare function awsWorkflowOnExceptionStepsCopyStepDetailsDestinationFileLocationEfsFileLocationPropertyToHclTerraform(struct?: AwsWorkflow.OnExceptionStepsCopyStepDetailsDestinationFileLocationEfsFileLocationPropertyOutputReference | AwsWorkflow.OnExceptionStepsCopyStepDetailsDestinationFileLocationEfsFileLocationProperty): any;
export declare function awsWorkflowOnExceptionStepsCopyStepDetailsDestinationFileLocationS3FileLocationPropertyToTerraform(struct?: AwsWorkflow.OnExceptionStepsCopyStepDetailsDestinationFileLocationS3FileLocationPropertyOutputReference | AwsWorkflow.OnExceptionStepsCopyStepDetailsDestinationFileLocationS3FileLocationProperty): any;
export declare function awsWorkflowOnExceptionStepsCopyStepDetailsDestinationFileLocationS3FileLocationPropertyToHclTerraform(struct?: AwsWorkflow.OnExceptionStepsCopyStepDetailsDestinationFileLocationS3FileLocationPropertyOutputReference | AwsWorkflow.OnExceptionStepsCopyStepDetailsDestinationFileLocationS3FileLocationProperty): any;
export declare function awsWorkflowOnExceptionStepsCopyStepDetailsDestinationFileLocationPropertyToTerraform(struct?: AwsWorkflow.OnExceptionStepsCopyStepDetailsDestinationFileLocationPropertyOutputReference | AwsWorkflow.OnExceptionStepsCopyStepDetailsDestinationFileLocationProperty): any;
export declare function awsWorkflowOnExceptionStepsCopyStepDetailsDestinationFileLocationPropertyToHclTerraform(struct?: AwsWorkflow.OnExceptionStepsCopyStepDetailsDestinationFileLocationPropertyOutputReference | AwsWorkflow.OnExceptionStepsCopyStepDetailsDestinationFileLocationProperty): any;
export declare function awsWorkflowOnExceptionStepsCopyStepDetailsPropertyToTerraform(struct?: AwsWorkflow.OnExceptionStepsCopyStepDetailsPropertyOutputReference | AwsWorkflow.OnExceptionStepsCopyStepDetailsProperty): any;
export declare function awsWorkflowOnExceptionStepsCopyStepDetailsPropertyToHclTerraform(struct?: AwsWorkflow.OnExceptionStepsCopyStepDetailsPropertyOutputReference | AwsWorkflow.OnExceptionStepsCopyStepDetailsProperty): any;
export declare function awsWorkflowOnExceptionStepsCustomStepDetailsPropertyToTerraform(struct?: AwsWorkflow.OnExceptionStepsCustomStepDetailsPropertyOutputReference | AwsWorkflow.OnExceptionStepsCustomStepDetailsProperty): any;
export declare function awsWorkflowOnExceptionStepsCustomStepDetailsPropertyToHclTerraform(struct?: AwsWorkflow.OnExceptionStepsCustomStepDetailsPropertyOutputReference | AwsWorkflow.OnExceptionStepsCustomStepDetailsProperty): any;
export declare function awsWorkflowOnExceptionStepsDecryptStepDetailsDestinationFileLocationEfsFileLocationPropertyToTerraform(struct?: AwsWorkflow.OnExceptionStepsDecryptStepDetailsDestinationFileLocationEfsFileLocationPropertyOutputReference | AwsWorkflow.OnExceptionStepsDecryptStepDetailsDestinationFileLocationEfsFileLocationProperty): any;
export declare function awsWorkflowOnExceptionStepsDecryptStepDetailsDestinationFileLocationEfsFileLocationPropertyToHclTerraform(struct?: AwsWorkflow.OnExceptionStepsDecryptStepDetailsDestinationFileLocationEfsFileLocationPropertyOutputReference | AwsWorkflow.OnExceptionStepsDecryptStepDetailsDestinationFileLocationEfsFileLocationProperty): any;
export declare function awsWorkflowOnExceptionStepsDecryptStepDetailsDestinationFileLocationS3FileLocationPropertyToTerraform(struct?: AwsWorkflow.OnExceptionStepsDecryptStepDetailsDestinationFileLocationS3FileLocationPropertyOutputReference | AwsWorkflow.OnExceptionStepsDecryptStepDetailsDestinationFileLocationS3FileLocationProperty): any;
export declare function awsWorkflowOnExceptionStepsDecryptStepDetailsDestinationFileLocationS3FileLocationPropertyToHclTerraform(struct?: AwsWorkflow.OnExceptionStepsDecryptStepDetailsDestinationFileLocationS3FileLocationPropertyOutputReference | AwsWorkflow.OnExceptionStepsDecryptStepDetailsDestinationFileLocationS3FileLocationProperty): any;
export declare function awsWorkflowOnExceptionStepsDecryptStepDetailsDestinationFileLocationPropertyToTerraform(struct?: AwsWorkflow.OnExceptionStepsDecryptStepDetailsDestinationFileLocationPropertyOutputReference | AwsWorkflow.OnExceptionStepsDecryptStepDetailsDestinationFileLocationProperty): any;
export declare function awsWorkflowOnExceptionStepsDecryptStepDetailsDestinationFileLocationPropertyToHclTerraform(struct?: AwsWorkflow.OnExceptionStepsDecryptStepDetailsDestinationFileLocationPropertyOutputReference | AwsWorkflow.OnExceptionStepsDecryptStepDetailsDestinationFileLocationProperty): any;
export declare function awsWorkflowOnExceptionStepsDecryptStepDetailsPropertyToTerraform(struct?: AwsWorkflow.OnExceptionStepsDecryptStepDetailsPropertyOutputReference | AwsWorkflow.OnExceptionStepsDecryptStepDetailsProperty): any;
export declare function awsWorkflowOnExceptionStepsDecryptStepDetailsPropertyToHclTerraform(struct?: AwsWorkflow.OnExceptionStepsDecryptStepDetailsPropertyOutputReference | AwsWorkflow.OnExceptionStepsDecryptStepDetailsProperty): any;
export declare function awsWorkflowOnExceptionStepsDeleteStepDetailsPropertyToTerraform(struct?: AwsWorkflow.OnExceptionStepsDeleteStepDetailsPropertyOutputReference | AwsWorkflow.OnExceptionStepsDeleteStepDetailsProperty): any;
export declare function awsWorkflowOnExceptionStepsDeleteStepDetailsPropertyToHclTerraform(struct?: AwsWorkflow.OnExceptionStepsDeleteStepDetailsPropertyOutputReference | AwsWorkflow.OnExceptionStepsDeleteStepDetailsProperty): any;
export declare function awsWorkflowOnExceptionStepsTagStepDetailsTagsPropertyToTerraform(struct?: AwsWorkflow.OnExceptionStepsTagStepDetailsTagsProperty | cdktn.IResolvable): any;
export declare function awsWorkflowOnExceptionStepsTagStepDetailsTagsPropertyToHclTerraform(struct?: AwsWorkflow.OnExceptionStepsTagStepDetailsTagsProperty | cdktn.IResolvable): any;
export declare function awsWorkflowOnExceptionStepsTagStepDetailsPropertyToTerraform(struct?: AwsWorkflow.OnExceptionStepsTagStepDetailsPropertyOutputReference | AwsWorkflow.OnExceptionStepsTagStepDetailsProperty): any;
export declare function awsWorkflowOnExceptionStepsTagStepDetailsPropertyToHclTerraform(struct?: AwsWorkflow.OnExceptionStepsTagStepDetailsPropertyOutputReference | AwsWorkflow.OnExceptionStepsTagStepDetailsProperty): any;
export declare function awsWorkflowOnExceptionStepsPropertyToTerraform(struct?: AwsWorkflow.OnExceptionStepsProperty | cdktn.IResolvable): any;
export declare function awsWorkflowOnExceptionStepsPropertyToHclTerraform(struct?: AwsWorkflow.OnExceptionStepsProperty | cdktn.IResolvable): any;
export declare function awsWorkflowStepsCopyStepDetailsDestinationFileLocationEfsFileLocationPropertyToTerraform(struct?: AwsWorkflow.StepsCopyStepDetailsDestinationFileLocationEfsFileLocationPropertyOutputReference | AwsWorkflow.StepsCopyStepDetailsDestinationFileLocationEfsFileLocationProperty): any;
export declare function awsWorkflowStepsCopyStepDetailsDestinationFileLocationEfsFileLocationPropertyToHclTerraform(struct?: AwsWorkflow.StepsCopyStepDetailsDestinationFileLocationEfsFileLocationPropertyOutputReference | AwsWorkflow.StepsCopyStepDetailsDestinationFileLocationEfsFileLocationProperty): any;
export declare function awsWorkflowStepsCopyStepDetailsDestinationFileLocationS3FileLocationPropertyToTerraform(struct?: AwsWorkflow.StepsCopyStepDetailsDestinationFileLocationS3FileLocationPropertyOutputReference | AwsWorkflow.StepsCopyStepDetailsDestinationFileLocationS3FileLocationProperty): any;
export declare function awsWorkflowStepsCopyStepDetailsDestinationFileLocationS3FileLocationPropertyToHclTerraform(struct?: AwsWorkflow.StepsCopyStepDetailsDestinationFileLocationS3FileLocationPropertyOutputReference | AwsWorkflow.StepsCopyStepDetailsDestinationFileLocationS3FileLocationProperty): any;
export declare function awsWorkflowStepsCopyStepDetailsDestinationFileLocationPropertyToTerraform(struct?: AwsWorkflow.StepsCopyStepDetailsDestinationFileLocationPropertyOutputReference | AwsWorkflow.StepsCopyStepDetailsDestinationFileLocationProperty): any;
export declare function awsWorkflowStepsCopyStepDetailsDestinationFileLocationPropertyToHclTerraform(struct?: AwsWorkflow.StepsCopyStepDetailsDestinationFileLocationPropertyOutputReference | AwsWorkflow.StepsCopyStepDetailsDestinationFileLocationProperty): any;
export declare function awsWorkflowStepsCopyStepDetailsPropertyToTerraform(struct?: AwsWorkflow.StepsCopyStepDetailsPropertyOutputReference | AwsWorkflow.StepsCopyStepDetailsProperty): any;
export declare function awsWorkflowStepsCopyStepDetailsPropertyToHclTerraform(struct?: AwsWorkflow.StepsCopyStepDetailsPropertyOutputReference | AwsWorkflow.StepsCopyStepDetailsProperty): any;
export declare function awsWorkflowStepsCustomStepDetailsPropertyToTerraform(struct?: AwsWorkflow.StepsCustomStepDetailsPropertyOutputReference | AwsWorkflow.StepsCustomStepDetailsProperty): any;
export declare function awsWorkflowStepsCustomStepDetailsPropertyToHclTerraform(struct?: AwsWorkflow.StepsCustomStepDetailsPropertyOutputReference | AwsWorkflow.StepsCustomStepDetailsProperty): any;
export declare function awsWorkflowStepsDecryptStepDetailsDestinationFileLocationEfsFileLocationPropertyToTerraform(struct?: AwsWorkflow.StepsDecryptStepDetailsDestinationFileLocationEfsFileLocationPropertyOutputReference | AwsWorkflow.StepsDecryptStepDetailsDestinationFileLocationEfsFileLocationProperty): any;
export declare function awsWorkflowStepsDecryptStepDetailsDestinationFileLocationEfsFileLocationPropertyToHclTerraform(struct?: AwsWorkflow.StepsDecryptStepDetailsDestinationFileLocationEfsFileLocationPropertyOutputReference | AwsWorkflow.StepsDecryptStepDetailsDestinationFileLocationEfsFileLocationProperty): any;
export declare function awsWorkflowStepsDecryptStepDetailsDestinationFileLocationS3FileLocationPropertyToTerraform(struct?: AwsWorkflow.StepsDecryptStepDetailsDestinationFileLocationS3FileLocationPropertyOutputReference | AwsWorkflow.StepsDecryptStepDetailsDestinationFileLocationS3FileLocationProperty): any;
export declare function awsWorkflowStepsDecryptStepDetailsDestinationFileLocationS3FileLocationPropertyToHclTerraform(struct?: AwsWorkflow.StepsDecryptStepDetailsDestinationFileLocationS3FileLocationPropertyOutputReference | AwsWorkflow.StepsDecryptStepDetailsDestinationFileLocationS3FileLocationProperty): any;
export declare function awsWorkflowStepsDecryptStepDetailsDestinationFileLocationPropertyToTerraform(struct?: AwsWorkflow.StepsDecryptStepDetailsDestinationFileLocationPropertyOutputReference | AwsWorkflow.StepsDecryptStepDetailsDestinationFileLocationProperty): any;
export declare function awsWorkflowStepsDecryptStepDetailsDestinationFileLocationPropertyToHclTerraform(struct?: AwsWorkflow.StepsDecryptStepDetailsDestinationFileLocationPropertyOutputReference | AwsWorkflow.StepsDecryptStepDetailsDestinationFileLocationProperty): any;
export declare function awsWorkflowStepsDecryptStepDetailsPropertyToTerraform(struct?: AwsWorkflow.StepsDecryptStepDetailsPropertyOutputReference | AwsWorkflow.StepsDecryptStepDetailsProperty): any;
export declare function awsWorkflowStepsDecryptStepDetailsPropertyToHclTerraform(struct?: AwsWorkflow.StepsDecryptStepDetailsPropertyOutputReference | AwsWorkflow.StepsDecryptStepDetailsProperty): any;
export declare function awsWorkflowStepsDeleteStepDetailsPropertyToTerraform(struct?: AwsWorkflow.StepsDeleteStepDetailsPropertyOutputReference | AwsWorkflow.StepsDeleteStepDetailsProperty): any;
export declare function awsWorkflowStepsDeleteStepDetailsPropertyToHclTerraform(struct?: AwsWorkflow.StepsDeleteStepDetailsPropertyOutputReference | AwsWorkflow.StepsDeleteStepDetailsProperty): any;
export declare function awsWorkflowStepsTagStepDetailsTagsPropertyToTerraform(struct?: AwsWorkflow.StepsTagStepDetailsTagsProperty | cdktn.IResolvable): any;
export declare function awsWorkflowStepsTagStepDetailsTagsPropertyToHclTerraform(struct?: AwsWorkflow.StepsTagStepDetailsTagsProperty | cdktn.IResolvable): any;
export declare function awsWorkflowStepsTagStepDetailsPropertyToTerraform(struct?: AwsWorkflow.StepsTagStepDetailsPropertyOutputReference | AwsWorkflow.StepsTagStepDetailsProperty): any;
export declare function awsWorkflowStepsTagStepDetailsPropertyToHclTerraform(struct?: AwsWorkflow.StepsTagStepDetailsPropertyOutputReference | AwsWorkflow.StepsTagStepDetailsProperty): any;
export declare function awsWorkflowStepsPropertyToTerraform(struct?: AwsWorkflow.StepsProperty | cdktn.IResolvable): any;
export declare function awsWorkflowStepsPropertyToHclTerraform(struct?: AwsWorkflow.StepsProperty | cdktn.IResolvable): any;
export declare namespace AwsWorkflow {
    interface OnExceptionStepsCopyStepDetailsDestinationFileLocationEfsFileLocationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_workflow#file_system_id AwsWorkflow#file_system_id}
        */
        readonly fileSystemId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_workflow#path AwsWorkflow#path}
        */
        readonly path?: string;
    }
    class OnExceptionStepsCopyStepDetailsDestinationFileLocationEfsFileLocationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): OnExceptionStepsCopyStepDetailsDestinationFileLocationEfsFileLocationProperty | undefined;
        set internalValue(value: OnExceptionStepsCopyStepDetailsDestinationFileLocationEfsFileLocationProperty | undefined);
        private _fileSystemId?;
        get fileSystemId(): string;
        set fileSystemId(value: string);
        resetFileSystemId(): void;
        get fileSystemIdInput(): string | undefined;
        private _path?;
        get path(): string;
        set path(value: string);
        resetPath(): void;
        get pathInput(): string | undefined;
    }
    interface OnExceptionStepsCopyStepDetailsDestinationFileLocationS3FileLocationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_workflow#bucket AwsWorkflow#bucket}
        */
        readonly bucket?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_workflow#key AwsWorkflow#key}
        */
        readonly key?: string;
    }
    class OnExceptionStepsCopyStepDetailsDestinationFileLocationS3FileLocationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): OnExceptionStepsCopyStepDetailsDestinationFileLocationS3FileLocationProperty | undefined;
        set internalValue(value: OnExceptionStepsCopyStepDetailsDestinationFileLocationS3FileLocationProperty | undefined);
        private _bucket?;
        get bucket(): string;
        set bucket(value: string);
        resetBucket(): void;
        get bucketInput(): string | undefined;
        private _key?;
        get key(): string;
        set key(value: string);
        resetKey(): void;
        get keyInput(): string | undefined;
    }
    interface OnExceptionStepsCopyStepDetailsDestinationFileLocationProperty {
        /**
        * efs_file_location block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_workflow#efs_file_location AwsWorkflow#efs_file_location}
        */
        readonly efsFileLocation?: OnExceptionStepsCopyStepDetailsDestinationFileLocationEfsFileLocationProperty;
        /**
        * s3_file_location block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_workflow#s3_file_location AwsWorkflow#s3_file_location}
        */
        readonly s3FileLocation?: OnExceptionStepsCopyStepDetailsDestinationFileLocationS3FileLocationProperty;
    }
    class OnExceptionStepsCopyStepDetailsDestinationFileLocationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): OnExceptionStepsCopyStepDetailsDestinationFileLocationProperty | undefined;
        set internalValue(value: OnExceptionStepsCopyStepDetailsDestinationFileLocationProperty | undefined);
        private _efsFileLocation;
        get efsFileLocation(): OnExceptionStepsCopyStepDetailsDestinationFileLocationEfsFileLocationPropertyOutputReference;
        putEfsFileLocation(value: OnExceptionStepsCopyStepDetailsDestinationFileLocationEfsFileLocationProperty): void;
        resetEfsFileLocation(): void;
        get efsFileLocationInput(): OnExceptionStepsCopyStepDetailsDestinationFileLocationEfsFileLocationProperty | undefined;
        private _s3FileLocation;
        get s3FileLocation(): OnExceptionStepsCopyStepDetailsDestinationFileLocationS3FileLocationPropertyOutputReference;
        putS3FileLocation(value: OnExceptionStepsCopyStepDetailsDestinationFileLocationS3FileLocationProperty): void;
        resetS3FileLocation(): void;
        get s3FileLocationInput(): OnExceptionStepsCopyStepDetailsDestinationFileLocationS3FileLocationProperty | undefined;
    }
    interface OnExceptionStepsCopyStepDetailsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_workflow#name AwsWorkflow#name}
        */
        readonly name?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_workflow#overwrite_existing AwsWorkflow#overwrite_existing}
        */
        readonly overwriteExisting?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_workflow#source_file_location AwsWorkflow#source_file_location}
        */
        readonly sourceFileLocation?: string;
        /**
        * destination_file_location block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_workflow#destination_file_location AwsWorkflow#destination_file_location}
        */
        readonly destinationFileLocation?: OnExceptionStepsCopyStepDetailsDestinationFileLocationProperty;
    }
    class OnExceptionStepsCopyStepDetailsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): OnExceptionStepsCopyStepDetailsProperty | undefined;
        set internalValue(value: OnExceptionStepsCopyStepDetailsProperty | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        resetName(): void;
        get nameInput(): string | undefined;
        private _overwriteExisting?;
        get overwriteExisting(): string;
        set overwriteExisting(value: string);
        resetOverwriteExisting(): void;
        get overwriteExistingInput(): string | undefined;
        private _sourceFileLocation?;
        get sourceFileLocation(): string;
        set sourceFileLocation(value: string);
        resetSourceFileLocation(): void;
        get sourceFileLocationInput(): string | undefined;
        private _destinationFileLocation;
        get destinationFileLocation(): OnExceptionStepsCopyStepDetailsDestinationFileLocationPropertyOutputReference;
        putDestinationFileLocation(value: OnExceptionStepsCopyStepDetailsDestinationFileLocationProperty): void;
        resetDestinationFileLocation(): void;
        get destinationFileLocationInput(): OnExceptionStepsCopyStepDetailsDestinationFileLocationProperty | undefined;
    }
    interface OnExceptionStepsCustomStepDetailsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_workflow#name AwsWorkflow#name}
        */
        readonly name?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_workflow#source_file_location AwsWorkflow#source_file_location}
        */
        readonly sourceFileLocation?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_workflow#target AwsWorkflow#target}
        */
        readonly target?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_workflow#timeout_seconds AwsWorkflow#timeout_seconds}
        */
        readonly timeoutSeconds?: number;
    }
    class OnExceptionStepsCustomStepDetailsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): OnExceptionStepsCustomStepDetailsProperty | undefined;
        set internalValue(value: OnExceptionStepsCustomStepDetailsProperty | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        resetName(): void;
        get nameInput(): string | undefined;
        private _sourceFileLocation?;
        get sourceFileLocation(): string;
        set sourceFileLocation(value: string);
        resetSourceFileLocation(): void;
        get sourceFileLocationInput(): string | undefined;
        private _target?;
        get target(): string;
        set target(value: string);
        resetTarget(): void;
        get targetInput(): string | undefined;
        private _timeoutSeconds?;
        get timeoutSeconds(): number;
        set timeoutSeconds(value: number);
        resetTimeoutSeconds(): void;
        get timeoutSecondsInput(): number | undefined;
    }
    interface OnExceptionStepsDecryptStepDetailsDestinationFileLocationEfsFileLocationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_workflow#file_system_id AwsWorkflow#file_system_id}
        */
        readonly fileSystemId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_workflow#path AwsWorkflow#path}
        */
        readonly path?: string;
    }
    class OnExceptionStepsDecryptStepDetailsDestinationFileLocationEfsFileLocationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): OnExceptionStepsDecryptStepDetailsDestinationFileLocationEfsFileLocationProperty | undefined;
        set internalValue(value: OnExceptionStepsDecryptStepDetailsDestinationFileLocationEfsFileLocationProperty | undefined);
        private _fileSystemId?;
        get fileSystemId(): string;
        set fileSystemId(value: string);
        resetFileSystemId(): void;
        get fileSystemIdInput(): string | undefined;
        private _path?;
        get path(): string;
        set path(value: string);
        resetPath(): void;
        get pathInput(): string | undefined;
    }
    interface OnExceptionStepsDecryptStepDetailsDestinationFileLocationS3FileLocationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_workflow#bucket AwsWorkflow#bucket}
        */
        readonly bucket?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_workflow#key AwsWorkflow#key}
        */
        readonly key?: string;
    }
    class OnExceptionStepsDecryptStepDetailsDestinationFileLocationS3FileLocationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): OnExceptionStepsDecryptStepDetailsDestinationFileLocationS3FileLocationProperty | undefined;
        set internalValue(value: OnExceptionStepsDecryptStepDetailsDestinationFileLocationS3FileLocationProperty | undefined);
        private _bucket?;
        get bucket(): string;
        set bucket(value: string);
        resetBucket(): void;
        get bucketInput(): string | undefined;
        private _key?;
        get key(): string;
        set key(value: string);
        resetKey(): void;
        get keyInput(): string | undefined;
    }
    interface OnExceptionStepsDecryptStepDetailsDestinationFileLocationProperty {
        /**
        * efs_file_location block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_workflow#efs_file_location AwsWorkflow#efs_file_location}
        */
        readonly efsFileLocation?: OnExceptionStepsDecryptStepDetailsDestinationFileLocationEfsFileLocationProperty;
        /**
        * s3_file_location block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_workflow#s3_file_location AwsWorkflow#s3_file_location}
        */
        readonly s3FileLocation?: OnExceptionStepsDecryptStepDetailsDestinationFileLocationS3FileLocationProperty;
    }
    class OnExceptionStepsDecryptStepDetailsDestinationFileLocationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): OnExceptionStepsDecryptStepDetailsDestinationFileLocationProperty | undefined;
        set internalValue(value: OnExceptionStepsDecryptStepDetailsDestinationFileLocationProperty | undefined);
        private _efsFileLocation;
        get efsFileLocation(): OnExceptionStepsDecryptStepDetailsDestinationFileLocationEfsFileLocationPropertyOutputReference;
        putEfsFileLocation(value: OnExceptionStepsDecryptStepDetailsDestinationFileLocationEfsFileLocationProperty): void;
        resetEfsFileLocation(): void;
        get efsFileLocationInput(): OnExceptionStepsDecryptStepDetailsDestinationFileLocationEfsFileLocationProperty | undefined;
        private _s3FileLocation;
        get s3FileLocation(): OnExceptionStepsDecryptStepDetailsDestinationFileLocationS3FileLocationPropertyOutputReference;
        putS3FileLocation(value: OnExceptionStepsDecryptStepDetailsDestinationFileLocationS3FileLocationProperty): void;
        resetS3FileLocation(): void;
        get s3FileLocationInput(): OnExceptionStepsDecryptStepDetailsDestinationFileLocationS3FileLocationProperty | undefined;
    }
    interface OnExceptionStepsDecryptStepDetailsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_workflow#name AwsWorkflow#name}
        */
        readonly name?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_workflow#overwrite_existing AwsWorkflow#overwrite_existing}
        */
        readonly overwriteExisting?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_workflow#source_file_location AwsWorkflow#source_file_location}
        */
        readonly sourceFileLocation?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_workflow#type AwsWorkflow#type}
        */
        readonly type: string;
        /**
        * destination_file_location block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_workflow#destination_file_location AwsWorkflow#destination_file_location}
        */
        readonly destinationFileLocation?: OnExceptionStepsDecryptStepDetailsDestinationFileLocationProperty;
    }
    class OnExceptionStepsDecryptStepDetailsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): OnExceptionStepsDecryptStepDetailsProperty | undefined;
        set internalValue(value: OnExceptionStepsDecryptStepDetailsProperty | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        resetName(): void;
        get nameInput(): string | undefined;
        private _overwriteExisting?;
        get overwriteExisting(): string;
        set overwriteExisting(value: string);
        resetOverwriteExisting(): void;
        get overwriteExistingInput(): string | undefined;
        private _sourceFileLocation?;
        get sourceFileLocation(): string;
        set sourceFileLocation(value: string);
        resetSourceFileLocation(): void;
        get sourceFileLocationInput(): string | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
        private _destinationFileLocation;
        get destinationFileLocation(): OnExceptionStepsDecryptStepDetailsDestinationFileLocationPropertyOutputReference;
        putDestinationFileLocation(value: OnExceptionStepsDecryptStepDetailsDestinationFileLocationProperty): void;
        resetDestinationFileLocation(): void;
        get destinationFileLocationInput(): OnExceptionStepsDecryptStepDetailsDestinationFileLocationProperty | undefined;
    }
    interface OnExceptionStepsDeleteStepDetailsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_workflow#name AwsWorkflow#name}
        */
        readonly name?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_workflow#source_file_location AwsWorkflow#source_file_location}
        */
        readonly sourceFileLocation?: string;
    }
    class OnExceptionStepsDeleteStepDetailsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): OnExceptionStepsDeleteStepDetailsProperty | undefined;
        set internalValue(value: OnExceptionStepsDeleteStepDetailsProperty | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        resetName(): void;
        get nameInput(): string | undefined;
        private _sourceFileLocation?;
        get sourceFileLocation(): string;
        set sourceFileLocation(value: string);
        resetSourceFileLocation(): void;
        get sourceFileLocationInput(): string | undefined;
    }
    interface OnExceptionStepsTagStepDetailsTagsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_workflow#key AwsWorkflow#key}
        */
        readonly key: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_workflow#value AwsWorkflow#value}
        */
        readonly value: string;
    }
    class OnExceptionStepsTagStepDetailsTagsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): OnExceptionStepsTagStepDetailsTagsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: OnExceptionStepsTagStepDetailsTagsProperty | cdktn.IResolvable | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        get keyInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class OnExceptionStepsTagStepDetailsTagsPropertyList extends cdktn.ComplexList {
        internalValue?: OnExceptionStepsTagStepDetailsTagsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): OnExceptionStepsTagStepDetailsTagsPropertyOutputReference;
    }
    interface OnExceptionStepsTagStepDetailsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_workflow#name AwsWorkflow#name}
        */
        readonly name?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_workflow#source_file_location AwsWorkflow#source_file_location}
        */
        readonly sourceFileLocation?: string;
        /**
        * tags block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_workflow#tags AwsWorkflow#tags}
        */
        readonly tags?: OnExceptionStepsTagStepDetailsTagsProperty[] | cdktn.IResolvable;
    }
    class OnExceptionStepsTagStepDetailsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): OnExceptionStepsTagStepDetailsProperty | undefined;
        set internalValue(value: OnExceptionStepsTagStepDetailsProperty | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        resetName(): void;
        get nameInput(): string | undefined;
        private _sourceFileLocation?;
        get sourceFileLocation(): string;
        set sourceFileLocation(value: string);
        resetSourceFileLocation(): void;
        get sourceFileLocationInput(): string | undefined;
        private _tags;
        get tags(): OnExceptionStepsTagStepDetailsTagsPropertyList;
        putTags(value: OnExceptionStepsTagStepDetailsTagsProperty[] | cdktn.IResolvable): void;
        resetTags(): void;
        get tagsInput(): cdktn.IResolvable | OnExceptionStepsTagStepDetailsTagsProperty[] | undefined;
    }
    interface OnExceptionStepsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_workflow#type AwsWorkflow#type}
        */
        readonly type: string;
        /**
        * copy_step_details block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_workflow#copy_step_details AwsWorkflow#copy_step_details}
        */
        readonly copyStepDetails?: OnExceptionStepsCopyStepDetailsProperty;
        /**
        * custom_step_details block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_workflow#custom_step_details AwsWorkflow#custom_step_details}
        */
        readonly customStepDetails?: OnExceptionStepsCustomStepDetailsProperty;
        /**
        * decrypt_step_details block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_workflow#decrypt_step_details AwsWorkflow#decrypt_step_details}
        */
        readonly decryptStepDetails?: OnExceptionStepsDecryptStepDetailsProperty;
        /**
        * delete_step_details block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_workflow#delete_step_details AwsWorkflow#delete_step_details}
        */
        readonly deleteStepDetails?: OnExceptionStepsDeleteStepDetailsProperty;
        /**
        * tag_step_details block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_workflow#tag_step_details AwsWorkflow#tag_step_details}
        */
        readonly tagStepDetails?: OnExceptionStepsTagStepDetailsProperty;
    }
    class OnExceptionStepsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): OnExceptionStepsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: OnExceptionStepsProperty | cdktn.IResolvable | undefined);
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
        private _copyStepDetails;
        get copyStepDetails(): OnExceptionStepsCopyStepDetailsPropertyOutputReference;
        putCopyStepDetails(value: OnExceptionStepsCopyStepDetailsProperty): void;
        resetCopyStepDetails(): void;
        get copyStepDetailsInput(): OnExceptionStepsCopyStepDetailsProperty | undefined;
        private _customStepDetails;
        get customStepDetails(): OnExceptionStepsCustomStepDetailsPropertyOutputReference;
        putCustomStepDetails(value: OnExceptionStepsCustomStepDetailsProperty): void;
        resetCustomStepDetails(): void;
        get customStepDetailsInput(): OnExceptionStepsCustomStepDetailsProperty | undefined;
        private _decryptStepDetails;
        get decryptStepDetails(): OnExceptionStepsDecryptStepDetailsPropertyOutputReference;
        putDecryptStepDetails(value: OnExceptionStepsDecryptStepDetailsProperty): void;
        resetDecryptStepDetails(): void;
        get decryptStepDetailsInput(): OnExceptionStepsDecryptStepDetailsProperty | undefined;
        private _deleteStepDetails;
        get deleteStepDetails(): OnExceptionStepsDeleteStepDetailsPropertyOutputReference;
        putDeleteStepDetails(value: OnExceptionStepsDeleteStepDetailsProperty): void;
        resetDeleteStepDetails(): void;
        get deleteStepDetailsInput(): OnExceptionStepsDeleteStepDetailsProperty | undefined;
        private _tagStepDetails;
        get tagStepDetails(): OnExceptionStepsTagStepDetailsPropertyOutputReference;
        putTagStepDetails(value: OnExceptionStepsTagStepDetailsProperty): void;
        resetTagStepDetails(): void;
        get tagStepDetailsInput(): OnExceptionStepsTagStepDetailsProperty | undefined;
    }
    class OnExceptionStepsPropertyList extends cdktn.ComplexList {
        internalValue?: OnExceptionStepsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): OnExceptionStepsPropertyOutputReference;
    }
    interface StepsCopyStepDetailsDestinationFileLocationEfsFileLocationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_workflow#file_system_id AwsWorkflow#file_system_id}
        */
        readonly fileSystemId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_workflow#path AwsWorkflow#path}
        */
        readonly path?: string;
    }
    class StepsCopyStepDetailsDestinationFileLocationEfsFileLocationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): StepsCopyStepDetailsDestinationFileLocationEfsFileLocationProperty | undefined;
        set internalValue(value: StepsCopyStepDetailsDestinationFileLocationEfsFileLocationProperty | undefined);
        private _fileSystemId?;
        get fileSystemId(): string;
        set fileSystemId(value: string);
        resetFileSystemId(): void;
        get fileSystemIdInput(): string | undefined;
        private _path?;
        get path(): string;
        set path(value: string);
        resetPath(): void;
        get pathInput(): string | undefined;
    }
    interface StepsCopyStepDetailsDestinationFileLocationS3FileLocationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_workflow#bucket AwsWorkflow#bucket}
        */
        readonly bucket?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_workflow#key AwsWorkflow#key}
        */
        readonly key?: string;
    }
    class StepsCopyStepDetailsDestinationFileLocationS3FileLocationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): StepsCopyStepDetailsDestinationFileLocationS3FileLocationProperty | undefined;
        set internalValue(value: StepsCopyStepDetailsDestinationFileLocationS3FileLocationProperty | undefined);
        private _bucket?;
        get bucket(): string;
        set bucket(value: string);
        resetBucket(): void;
        get bucketInput(): string | undefined;
        private _key?;
        get key(): string;
        set key(value: string);
        resetKey(): void;
        get keyInput(): string | undefined;
    }
    interface StepsCopyStepDetailsDestinationFileLocationProperty {
        /**
        * efs_file_location block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_workflow#efs_file_location AwsWorkflow#efs_file_location}
        */
        readonly efsFileLocation?: StepsCopyStepDetailsDestinationFileLocationEfsFileLocationProperty;
        /**
        * s3_file_location block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_workflow#s3_file_location AwsWorkflow#s3_file_location}
        */
        readonly s3FileLocation?: StepsCopyStepDetailsDestinationFileLocationS3FileLocationProperty;
    }
    class StepsCopyStepDetailsDestinationFileLocationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): StepsCopyStepDetailsDestinationFileLocationProperty | undefined;
        set internalValue(value: StepsCopyStepDetailsDestinationFileLocationProperty | undefined);
        private _efsFileLocation;
        get efsFileLocation(): StepsCopyStepDetailsDestinationFileLocationEfsFileLocationPropertyOutputReference;
        putEfsFileLocation(value: StepsCopyStepDetailsDestinationFileLocationEfsFileLocationProperty): void;
        resetEfsFileLocation(): void;
        get efsFileLocationInput(): StepsCopyStepDetailsDestinationFileLocationEfsFileLocationProperty | undefined;
        private _s3FileLocation;
        get s3FileLocation(): StepsCopyStepDetailsDestinationFileLocationS3FileLocationPropertyOutputReference;
        putS3FileLocation(value: StepsCopyStepDetailsDestinationFileLocationS3FileLocationProperty): void;
        resetS3FileLocation(): void;
        get s3FileLocationInput(): StepsCopyStepDetailsDestinationFileLocationS3FileLocationProperty | undefined;
    }
    interface StepsCopyStepDetailsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_workflow#name AwsWorkflow#name}
        */
        readonly name?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_workflow#overwrite_existing AwsWorkflow#overwrite_existing}
        */
        readonly overwriteExisting?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_workflow#source_file_location AwsWorkflow#source_file_location}
        */
        readonly sourceFileLocation?: string;
        /**
        * destination_file_location block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_workflow#destination_file_location AwsWorkflow#destination_file_location}
        */
        readonly destinationFileLocation?: StepsCopyStepDetailsDestinationFileLocationProperty;
    }
    class StepsCopyStepDetailsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): StepsCopyStepDetailsProperty | undefined;
        set internalValue(value: StepsCopyStepDetailsProperty | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        resetName(): void;
        get nameInput(): string | undefined;
        private _overwriteExisting?;
        get overwriteExisting(): string;
        set overwriteExisting(value: string);
        resetOverwriteExisting(): void;
        get overwriteExistingInput(): string | undefined;
        private _sourceFileLocation?;
        get sourceFileLocation(): string;
        set sourceFileLocation(value: string);
        resetSourceFileLocation(): void;
        get sourceFileLocationInput(): string | undefined;
        private _destinationFileLocation;
        get destinationFileLocation(): StepsCopyStepDetailsDestinationFileLocationPropertyOutputReference;
        putDestinationFileLocation(value: StepsCopyStepDetailsDestinationFileLocationProperty): void;
        resetDestinationFileLocation(): void;
        get destinationFileLocationInput(): StepsCopyStepDetailsDestinationFileLocationProperty | undefined;
    }
    interface StepsCustomStepDetailsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_workflow#name AwsWorkflow#name}
        */
        readonly name?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_workflow#source_file_location AwsWorkflow#source_file_location}
        */
        readonly sourceFileLocation?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_workflow#target AwsWorkflow#target}
        */
        readonly target?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_workflow#timeout_seconds AwsWorkflow#timeout_seconds}
        */
        readonly timeoutSeconds?: number;
    }
    class StepsCustomStepDetailsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): StepsCustomStepDetailsProperty | undefined;
        set internalValue(value: StepsCustomStepDetailsProperty | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        resetName(): void;
        get nameInput(): string | undefined;
        private _sourceFileLocation?;
        get sourceFileLocation(): string;
        set sourceFileLocation(value: string);
        resetSourceFileLocation(): void;
        get sourceFileLocationInput(): string | undefined;
        private _target?;
        get target(): string;
        set target(value: string);
        resetTarget(): void;
        get targetInput(): string | undefined;
        private _timeoutSeconds?;
        get timeoutSeconds(): number;
        set timeoutSeconds(value: number);
        resetTimeoutSeconds(): void;
        get timeoutSecondsInput(): number | undefined;
    }
    interface StepsDecryptStepDetailsDestinationFileLocationEfsFileLocationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_workflow#file_system_id AwsWorkflow#file_system_id}
        */
        readonly fileSystemId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_workflow#path AwsWorkflow#path}
        */
        readonly path?: string;
    }
    class StepsDecryptStepDetailsDestinationFileLocationEfsFileLocationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): StepsDecryptStepDetailsDestinationFileLocationEfsFileLocationProperty | undefined;
        set internalValue(value: StepsDecryptStepDetailsDestinationFileLocationEfsFileLocationProperty | undefined);
        private _fileSystemId?;
        get fileSystemId(): string;
        set fileSystemId(value: string);
        resetFileSystemId(): void;
        get fileSystemIdInput(): string | undefined;
        private _path?;
        get path(): string;
        set path(value: string);
        resetPath(): void;
        get pathInput(): string | undefined;
    }
    interface StepsDecryptStepDetailsDestinationFileLocationS3FileLocationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_workflow#bucket AwsWorkflow#bucket}
        */
        readonly bucket?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_workflow#key AwsWorkflow#key}
        */
        readonly key?: string;
    }
    class StepsDecryptStepDetailsDestinationFileLocationS3FileLocationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): StepsDecryptStepDetailsDestinationFileLocationS3FileLocationProperty | undefined;
        set internalValue(value: StepsDecryptStepDetailsDestinationFileLocationS3FileLocationProperty | undefined);
        private _bucket?;
        get bucket(): string;
        set bucket(value: string);
        resetBucket(): void;
        get bucketInput(): string | undefined;
        private _key?;
        get key(): string;
        set key(value: string);
        resetKey(): void;
        get keyInput(): string | undefined;
    }
    interface StepsDecryptStepDetailsDestinationFileLocationProperty {
        /**
        * efs_file_location block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_workflow#efs_file_location AwsWorkflow#efs_file_location}
        */
        readonly efsFileLocation?: StepsDecryptStepDetailsDestinationFileLocationEfsFileLocationProperty;
        /**
        * s3_file_location block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_workflow#s3_file_location AwsWorkflow#s3_file_location}
        */
        readonly s3FileLocation?: StepsDecryptStepDetailsDestinationFileLocationS3FileLocationProperty;
    }
    class StepsDecryptStepDetailsDestinationFileLocationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): StepsDecryptStepDetailsDestinationFileLocationProperty | undefined;
        set internalValue(value: StepsDecryptStepDetailsDestinationFileLocationProperty | undefined);
        private _efsFileLocation;
        get efsFileLocation(): StepsDecryptStepDetailsDestinationFileLocationEfsFileLocationPropertyOutputReference;
        putEfsFileLocation(value: StepsDecryptStepDetailsDestinationFileLocationEfsFileLocationProperty): void;
        resetEfsFileLocation(): void;
        get efsFileLocationInput(): StepsDecryptStepDetailsDestinationFileLocationEfsFileLocationProperty | undefined;
        private _s3FileLocation;
        get s3FileLocation(): StepsDecryptStepDetailsDestinationFileLocationS3FileLocationPropertyOutputReference;
        putS3FileLocation(value: StepsDecryptStepDetailsDestinationFileLocationS3FileLocationProperty): void;
        resetS3FileLocation(): void;
        get s3FileLocationInput(): StepsDecryptStepDetailsDestinationFileLocationS3FileLocationProperty | undefined;
    }
    interface StepsDecryptStepDetailsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_workflow#name AwsWorkflow#name}
        */
        readonly name?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_workflow#overwrite_existing AwsWorkflow#overwrite_existing}
        */
        readonly overwriteExisting?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_workflow#source_file_location AwsWorkflow#source_file_location}
        */
        readonly sourceFileLocation?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_workflow#type AwsWorkflow#type}
        */
        readonly type: string;
        /**
        * destination_file_location block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_workflow#destination_file_location AwsWorkflow#destination_file_location}
        */
        readonly destinationFileLocation?: StepsDecryptStepDetailsDestinationFileLocationProperty;
    }
    class StepsDecryptStepDetailsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): StepsDecryptStepDetailsProperty | undefined;
        set internalValue(value: StepsDecryptStepDetailsProperty | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        resetName(): void;
        get nameInput(): string | undefined;
        private _overwriteExisting?;
        get overwriteExisting(): string;
        set overwriteExisting(value: string);
        resetOverwriteExisting(): void;
        get overwriteExistingInput(): string | undefined;
        private _sourceFileLocation?;
        get sourceFileLocation(): string;
        set sourceFileLocation(value: string);
        resetSourceFileLocation(): void;
        get sourceFileLocationInput(): string | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
        private _destinationFileLocation;
        get destinationFileLocation(): StepsDecryptStepDetailsDestinationFileLocationPropertyOutputReference;
        putDestinationFileLocation(value: StepsDecryptStepDetailsDestinationFileLocationProperty): void;
        resetDestinationFileLocation(): void;
        get destinationFileLocationInput(): StepsDecryptStepDetailsDestinationFileLocationProperty | undefined;
    }
    interface StepsDeleteStepDetailsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_workflow#name AwsWorkflow#name}
        */
        readonly name?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_workflow#source_file_location AwsWorkflow#source_file_location}
        */
        readonly sourceFileLocation?: string;
    }
    class StepsDeleteStepDetailsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): StepsDeleteStepDetailsProperty | undefined;
        set internalValue(value: StepsDeleteStepDetailsProperty | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        resetName(): void;
        get nameInput(): string | undefined;
        private _sourceFileLocation?;
        get sourceFileLocation(): string;
        set sourceFileLocation(value: string);
        resetSourceFileLocation(): void;
        get sourceFileLocationInput(): string | undefined;
    }
    interface StepsTagStepDetailsTagsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_workflow#key AwsWorkflow#key}
        */
        readonly key: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_workflow#value AwsWorkflow#value}
        */
        readonly value: string;
    }
    class StepsTagStepDetailsTagsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): StepsTagStepDetailsTagsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: StepsTagStepDetailsTagsProperty | cdktn.IResolvable | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        get keyInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class StepsTagStepDetailsTagsPropertyList extends cdktn.ComplexList {
        internalValue?: StepsTagStepDetailsTagsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): StepsTagStepDetailsTagsPropertyOutputReference;
    }
    interface StepsTagStepDetailsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_workflow#name AwsWorkflow#name}
        */
        readonly name?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_workflow#source_file_location AwsWorkflow#source_file_location}
        */
        readonly sourceFileLocation?: string;
        /**
        * tags block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_workflow#tags AwsWorkflow#tags}
        */
        readonly tags?: StepsTagStepDetailsTagsProperty[] | cdktn.IResolvable;
    }
    class StepsTagStepDetailsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): StepsTagStepDetailsProperty | undefined;
        set internalValue(value: StepsTagStepDetailsProperty | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        resetName(): void;
        get nameInput(): string | undefined;
        private _sourceFileLocation?;
        get sourceFileLocation(): string;
        set sourceFileLocation(value: string);
        resetSourceFileLocation(): void;
        get sourceFileLocationInput(): string | undefined;
        private _tags;
        get tags(): StepsTagStepDetailsTagsPropertyList;
        putTags(value: StepsTagStepDetailsTagsProperty[] | cdktn.IResolvable): void;
        resetTags(): void;
        get tagsInput(): cdktn.IResolvable | StepsTagStepDetailsTagsProperty[] | undefined;
    }
    interface StepsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_workflow#type AwsWorkflow#type}
        */
        readonly type: string;
        /**
        * copy_step_details block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_workflow#copy_step_details AwsWorkflow#copy_step_details}
        */
        readonly copyStepDetails?: StepsCopyStepDetailsProperty;
        /**
        * custom_step_details block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_workflow#custom_step_details AwsWorkflow#custom_step_details}
        */
        readonly customStepDetails?: StepsCustomStepDetailsProperty;
        /**
        * decrypt_step_details block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_workflow#decrypt_step_details AwsWorkflow#decrypt_step_details}
        */
        readonly decryptStepDetails?: StepsDecryptStepDetailsProperty;
        /**
        * delete_step_details block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_workflow#delete_step_details AwsWorkflow#delete_step_details}
        */
        readonly deleteStepDetails?: StepsDeleteStepDetailsProperty;
        /**
        * tag_step_details block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_workflow#tag_step_details AwsWorkflow#tag_step_details}
        */
        readonly tagStepDetails?: StepsTagStepDetailsProperty;
    }
    class StepsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): StepsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: StepsProperty | cdktn.IResolvable | undefined);
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
        private _copyStepDetails;
        get copyStepDetails(): StepsCopyStepDetailsPropertyOutputReference;
        putCopyStepDetails(value: StepsCopyStepDetailsProperty): void;
        resetCopyStepDetails(): void;
        get copyStepDetailsInput(): StepsCopyStepDetailsProperty | undefined;
        private _customStepDetails;
        get customStepDetails(): StepsCustomStepDetailsPropertyOutputReference;
        putCustomStepDetails(value: StepsCustomStepDetailsProperty): void;
        resetCustomStepDetails(): void;
        get customStepDetailsInput(): StepsCustomStepDetailsProperty | undefined;
        private _decryptStepDetails;
        get decryptStepDetails(): StepsDecryptStepDetailsPropertyOutputReference;
        putDecryptStepDetails(value: StepsDecryptStepDetailsProperty): void;
        resetDecryptStepDetails(): void;
        get decryptStepDetailsInput(): StepsDecryptStepDetailsProperty | undefined;
        private _deleteStepDetails;
        get deleteStepDetails(): StepsDeleteStepDetailsPropertyOutputReference;
        putDeleteStepDetails(value: StepsDeleteStepDetailsProperty): void;
        resetDeleteStepDetails(): void;
        get deleteStepDetailsInput(): StepsDeleteStepDetailsProperty | undefined;
        private _tagStepDetails;
        get tagStepDetails(): StepsTagStepDetailsPropertyOutputReference;
        putTagStepDetails(value: StepsTagStepDetailsProperty): void;
        resetTagStepDetails(): void;
        get tagStepDetailsInput(): StepsTagStepDetailsProperty | undefined;
    }
    class StepsPropertyList extends cdktn.ComplexList {
        internalValue?: StepsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): StepsPropertyOutputReference;
    }
}
