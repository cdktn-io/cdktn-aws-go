import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsAccessConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_access#external_id AwsAccess#external_id}
    */
    readonly externalId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_access#home_directory AwsAccess#home_directory}
    */
    readonly homeDirectory?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_access#home_directory_type AwsAccess#home_directory_type}
    */
    readonly homeDirectoryType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_access#id AwsAccess#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_access#policy AwsAccess#policy}
    */
    readonly policy?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_access#region AwsAccess#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_access#role AwsAccess#role}
    */
    readonly role?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_access#server_id AwsAccess#server_id}
    */
    readonly serverId: string;
    /**
    * home_directory_mappings block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_access#home_directory_mappings AwsAccess#home_directory_mappings}
    */
    readonly homeDirectoryMappings?: AwsAccess.HomeDirectoryMappingsProperty[] | cdktn.IResolvable;
    /**
    * posix_profile block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_access#posix_profile AwsAccess#posix_profile}
    */
    readonly posixProfile?: AwsAccess.PosixProfileProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_access aws_transfer_access}
*/
export declare class AwsAccess extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_transfer_access";
    /**
    * Generates CDKTN code for importing a AwsAccess resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsAccess to import
    * @param importFromId The id of the existing AwsAccess that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_access#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsAccess to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_access aws_transfer_access} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsAccessConfig
    */
    constructor(scope: Construct, id: string, config: AwsAccessConfig);
    private _externalId?;
    get externalId(): string;
    set externalId(value: string);
    get externalIdInput(): string | undefined;
    private _homeDirectory?;
    get homeDirectory(): string;
    set homeDirectory(value: string);
    resetHomeDirectory(): void;
    get homeDirectoryInput(): string | undefined;
    private _homeDirectoryType?;
    get homeDirectoryType(): string;
    set homeDirectoryType(value: string);
    resetHomeDirectoryType(): void;
    get homeDirectoryTypeInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _policy?;
    get policy(): string;
    set policy(value: string);
    resetPolicy(): void;
    get policyInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _role?;
    get role(): string;
    set role(value: string);
    resetRole(): void;
    get roleInput(): string | undefined;
    private _serverId?;
    get serverId(): string;
    set serverId(value: string);
    get serverIdInput(): string | undefined;
    private _homeDirectoryMappings;
    get homeDirectoryMappings(): AwsAccess.HomeDirectoryMappingsPropertyList;
    putHomeDirectoryMappings(value: AwsAccess.HomeDirectoryMappingsProperty[] | cdktn.IResolvable): void;
    resetHomeDirectoryMappings(): void;
    get homeDirectoryMappingsInput(): cdktn.IResolvable | AwsAccess.HomeDirectoryMappingsProperty[] | undefined;
    private _posixProfile;
    get posixProfile(): AwsAccess.PosixProfilePropertyOutputReference;
    putPosixProfile(value: AwsAccess.PosixProfileProperty): void;
    resetPosixProfile(): void;
    get posixProfileInput(): AwsAccess.PosixProfileProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsAccessHomeDirectoryMappingsPropertyToTerraform(struct?: AwsAccess.HomeDirectoryMappingsProperty | cdktn.IResolvable): any;
export declare function awsAccessHomeDirectoryMappingsPropertyToHclTerraform(struct?: AwsAccess.HomeDirectoryMappingsProperty | cdktn.IResolvable): any;
export declare function awsAccessPosixProfilePropertyToTerraform(struct?: AwsAccess.PosixProfilePropertyOutputReference | AwsAccess.PosixProfileProperty): any;
export declare function awsAccessPosixProfilePropertyToHclTerraform(struct?: AwsAccess.PosixProfilePropertyOutputReference | AwsAccess.PosixProfileProperty): any;
export declare namespace AwsAccess {
    interface HomeDirectoryMappingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_access#entry AwsAccess#entry}
        */
        readonly entry: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_access#target AwsAccess#target}
        */
        readonly target: string;
    }
    class HomeDirectoryMappingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): HomeDirectoryMappingsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: HomeDirectoryMappingsProperty | cdktn.IResolvable | undefined);
        private _entry?;
        get entry(): string;
        set entry(value: string);
        get entryInput(): string | undefined;
        private _target?;
        get target(): string;
        set target(value: string);
        get targetInput(): string | undefined;
    }
    class HomeDirectoryMappingsPropertyList extends cdktn.ComplexList {
        internalValue?: HomeDirectoryMappingsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): HomeDirectoryMappingsPropertyOutputReference;
    }
    interface PosixProfileProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_access#gid AwsAccess#gid}
        */
        readonly gid: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_access#secondary_gids AwsAccess#secondary_gids}
        */
        readonly secondaryGids?: number[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_access#uid AwsAccess#uid}
        */
        readonly uid: number;
    }
    class PosixProfilePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): PosixProfileProperty | undefined;
        set internalValue(value: PosixProfileProperty | undefined);
        private _gid?;
        get gid(): number;
        set gid(value: number);
        get gidInput(): number | undefined;
        private _secondaryGids?;
        get secondaryGids(): number[];
        set secondaryGids(value: number[]);
        resetSecondaryGids(): void;
        get secondaryGidsInput(): number[] | undefined;
        private _uid?;
        get uid(): number;
        set uid(value: number);
        get uidInput(): number | undefined;
    }
}
