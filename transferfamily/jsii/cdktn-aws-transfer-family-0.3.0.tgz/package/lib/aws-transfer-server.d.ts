import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsServerConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_server#certificate AwsServer#certificate}
    */
    readonly certificate?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_server#directory_id AwsServer#directory_id}
    */
    readonly directoryId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_server#domain AwsServer#domain}
    */
    readonly domain?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_server#endpoint_type AwsServer#endpoint_type}
    */
    readonly endpointType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_server#force_destroy AwsServer#force_destroy}
    */
    readonly forceDestroy?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_server#function AwsServer#function}
    */
    readonly function?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_server#host_key AwsServer#host_key}
    */
    readonly hostKey?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_server#id AwsServer#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_server#identity_provider_type AwsServer#identity_provider_type}
    */
    readonly identityProviderType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_server#invocation_role AwsServer#invocation_role}
    */
    readonly invocationRole?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_server#ip_address_type AwsServer#ip_address_type}
    */
    readonly ipAddressType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_server#logging_role AwsServer#logging_role}
    */
    readonly loggingRole?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_server#post_authentication_login_banner AwsServer#post_authentication_login_banner}
    */
    readonly postAuthenticationLoginBanner?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_server#pre_authentication_login_banner AwsServer#pre_authentication_login_banner}
    */
    readonly preAuthenticationLoginBanner?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_server#protocols AwsServer#protocols}
    */
    readonly protocols?: string[];
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_server#region AwsServer#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_server#security_policy_name AwsServer#security_policy_name}
    */
    readonly securityPolicyName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_server#sftp_authentication_methods AwsServer#sftp_authentication_methods}
    */
    readonly sftpAuthenticationMethods?: string;
    /**
    * This is a set of arns of destinations that will receive structured logs from the transfer server
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_server#structured_log_destinations AwsServer#structured_log_destinations}
    */
    readonly structuredLogDestinations?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_server#tags AwsServer#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_server#tags_all AwsServer#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_server#url AwsServer#url}
    */
    readonly url?: string;
    /**
    * endpoint_details block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_server#endpoint_details AwsServer#endpoint_details}
    */
    readonly endpointDetails?: AwsServer.EndpointDetailsProperty;
    /**
    * protocol_details block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_server#protocol_details AwsServer#protocol_details}
    */
    readonly protocolDetails?: AwsServer.ProtocolDetailsProperty;
    /**
    * s3_storage_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_server#s3_storage_options AwsServer#s3_storage_options}
    */
    readonly s3StorageOptions?: AwsServer.S3StorageOptionsProperty;
    /**
    * workflow_details block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_server#workflow_details AwsServer#workflow_details}
    */
    readonly workflowDetails?: AwsServer.WorkflowDetailsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_server aws_transfer_server}
*/
export declare class AwsServer extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_transfer_server";
    /**
    * Generates CDKTN code for importing a AwsServer resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsServer to import
    * @param importFromId The id of the existing AwsServer that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_server#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsServer to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_server aws_transfer_server} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsServerConfig = {}
    */
    constructor(scope: Construct, id: string, config?: AwsServerConfig);
    get arn(): string;
    private _certificate?;
    get certificate(): string;
    set certificate(value: string);
    resetCertificate(): void;
    get certificateInput(): string | undefined;
    private _directoryId?;
    get directoryId(): string;
    set directoryId(value: string);
    resetDirectoryId(): void;
    get directoryIdInput(): string | undefined;
    private _domain?;
    get domain(): string;
    set domain(value: string);
    resetDomain(): void;
    get domainInput(): string | undefined;
    get endpoint(): string;
    private _endpointType?;
    get endpointType(): string;
    set endpointType(value: string);
    resetEndpointType(): void;
    get endpointTypeInput(): string | undefined;
    private _forceDestroy?;
    get forceDestroy(): boolean | cdktn.IResolvable;
    set forceDestroy(value: boolean | cdktn.IResolvable);
    resetForceDestroy(): void;
    get forceDestroyInput(): boolean | cdktn.IResolvable | undefined;
    private _function?;
    get function(): string;
    set function(value: string);
    resetFunction(): void;
    get functionInput(): string | undefined;
    private _hostKey?;
    get hostKey(): string;
    set hostKey(value: string);
    resetHostKey(): void;
    get hostKeyInput(): string | undefined;
    get hostKeyFingerprint(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _identityProviderType?;
    get identityProviderType(): string;
    set identityProviderType(value: string);
    resetIdentityProviderType(): void;
    get identityProviderTypeInput(): string | undefined;
    private _invocationRole?;
    get invocationRole(): string;
    set invocationRole(value: string);
    resetInvocationRole(): void;
    get invocationRoleInput(): string | undefined;
    private _ipAddressType?;
    get ipAddressType(): string;
    set ipAddressType(value: string);
    resetIpAddressType(): void;
    get ipAddressTypeInput(): string | undefined;
    private _loggingRole?;
    get loggingRole(): string;
    set loggingRole(value: string);
    resetLoggingRole(): void;
    get loggingRoleInput(): string | undefined;
    private _postAuthenticationLoginBanner?;
    get postAuthenticationLoginBanner(): string;
    set postAuthenticationLoginBanner(value: string);
    resetPostAuthenticationLoginBanner(): void;
    get postAuthenticationLoginBannerInput(): string | undefined;
    private _preAuthenticationLoginBanner?;
    get preAuthenticationLoginBanner(): string;
    set preAuthenticationLoginBanner(value: string);
    resetPreAuthenticationLoginBanner(): void;
    get preAuthenticationLoginBannerInput(): string | undefined;
    private _protocols?;
    get protocols(): string[];
    set protocols(value: string[]);
    resetProtocols(): void;
    get protocolsInput(): string[] | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _securityPolicyName?;
    get securityPolicyName(): string;
    set securityPolicyName(value: string);
    resetSecurityPolicyName(): void;
    get securityPolicyNameInput(): string | undefined;
    private _sftpAuthenticationMethods?;
    get sftpAuthenticationMethods(): string;
    set sftpAuthenticationMethods(value: string);
    resetSftpAuthenticationMethods(): void;
    get sftpAuthenticationMethodsInput(): string | undefined;
    private _structuredLogDestinations?;
    get structuredLogDestinations(): string[];
    set structuredLogDestinations(value: string[]);
    resetStructuredLogDestinations(): void;
    get structuredLogDestinationsInput(): string[] | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _url?;
    get url(): string;
    set url(value: string);
    resetUrl(): void;
    get urlInput(): string | undefined;
    private _endpointDetails;
    get endpointDetails(): AwsServer.EndpointDetailsPropertyOutputReference;
    putEndpointDetails(value: AwsServer.EndpointDetailsProperty): void;
    resetEndpointDetails(): void;
    get endpointDetailsInput(): AwsServer.EndpointDetailsProperty | undefined;
    private _protocolDetails;
    get protocolDetails(): AwsServer.ProtocolDetailsPropertyOutputReference;
    putProtocolDetails(value: AwsServer.ProtocolDetailsProperty): void;
    resetProtocolDetails(): void;
    get protocolDetailsInput(): AwsServer.ProtocolDetailsProperty | undefined;
    private _s3StorageOptions;
    get s3StorageOptions(): AwsServer.S3StorageOptionsPropertyOutputReference;
    putS3StorageOptions(value: AwsServer.S3StorageOptionsProperty): void;
    resetS3StorageOptions(): void;
    get s3StorageOptionsInput(): AwsServer.S3StorageOptionsProperty | undefined;
    private _workflowDetails;
    get workflowDetails(): AwsServer.WorkflowDetailsPropertyOutputReference;
    putWorkflowDetails(value: AwsServer.WorkflowDetailsProperty): void;
    resetWorkflowDetails(): void;
    get workflowDetailsInput(): AwsServer.WorkflowDetailsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsServerEndpointDetailsPropertyToTerraform(struct?: AwsServer.EndpointDetailsPropertyOutputReference | AwsServer.EndpointDetailsProperty): any;
export declare function awsServerEndpointDetailsPropertyToHclTerraform(struct?: AwsServer.EndpointDetailsPropertyOutputReference | AwsServer.EndpointDetailsProperty): any;
export declare function awsServerProtocolDetailsPropertyToTerraform(struct?: AwsServer.ProtocolDetailsPropertyOutputReference | AwsServer.ProtocolDetailsProperty): any;
export declare function awsServerProtocolDetailsPropertyToHclTerraform(struct?: AwsServer.ProtocolDetailsPropertyOutputReference | AwsServer.ProtocolDetailsProperty): any;
export declare function awsServerS3StorageOptionsPropertyToTerraform(struct?: AwsServer.S3StorageOptionsPropertyOutputReference | AwsServer.S3StorageOptionsProperty): any;
export declare function awsServerS3StorageOptionsPropertyToHclTerraform(struct?: AwsServer.S3StorageOptionsPropertyOutputReference | AwsServer.S3StorageOptionsProperty): any;
export declare function awsServerOnPartialUploadPropertyToTerraform(struct?: AwsServer.OnPartialUploadPropertyOutputReference | AwsServer.OnPartialUploadProperty): any;
export declare function awsServerOnPartialUploadPropertyToHclTerraform(struct?: AwsServer.OnPartialUploadPropertyOutputReference | AwsServer.OnPartialUploadProperty): any;
export declare function awsServerOnUploadPropertyToTerraform(struct?: AwsServer.OnUploadPropertyOutputReference | AwsServer.OnUploadProperty): any;
export declare function awsServerOnUploadPropertyToHclTerraform(struct?: AwsServer.OnUploadPropertyOutputReference | AwsServer.OnUploadProperty): any;
export declare function awsServerWorkflowDetailsPropertyToTerraform(struct?: AwsServer.WorkflowDetailsPropertyOutputReference | AwsServer.WorkflowDetailsProperty): any;
export declare function awsServerWorkflowDetailsPropertyToHclTerraform(struct?: AwsServer.WorkflowDetailsPropertyOutputReference | AwsServer.WorkflowDetailsProperty): any;
export declare namespace AwsServer {
    interface EndpointDetailsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_server#address_allocation_ids AwsServer#address_allocation_ids}
        */
        readonly addressAllocationIds?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_server#security_group_ids AwsServer#security_group_ids}
        */
        readonly securityGroupIds?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_server#subnet_ids AwsServer#subnet_ids}
        */
        readonly subnetIds?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_server#vpc_endpoint_id AwsServer#vpc_endpoint_id}
        */
        readonly vpcEndpointId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_server#vpc_id AwsServer#vpc_id}
        */
        readonly vpcId?: string;
    }
    class EndpointDetailsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): EndpointDetailsProperty | undefined;
        set internalValue(value: EndpointDetailsProperty | undefined);
        private _addressAllocationIds?;
        get addressAllocationIds(): string[];
        set addressAllocationIds(value: string[]);
        resetAddressAllocationIds(): void;
        get addressAllocationIdsInput(): string[] | undefined;
        private _securityGroupIds?;
        get securityGroupIds(): string[];
        set securityGroupIds(value: string[]);
        resetSecurityGroupIds(): void;
        get securityGroupIdsInput(): string[] | undefined;
        private _subnetIds?;
        get subnetIds(): string[];
        set subnetIds(value: string[]);
        resetSubnetIds(): void;
        get subnetIdsInput(): string[] | undefined;
        private _vpcEndpointId?;
        get vpcEndpointId(): string;
        set vpcEndpointId(value: string);
        resetVpcEndpointId(): void;
        get vpcEndpointIdInput(): string | undefined;
        private _vpcId?;
        get vpcId(): string;
        set vpcId(value: string);
        resetVpcId(): void;
        get vpcIdInput(): string | undefined;
    }
    interface ProtocolDetailsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_server#as2_transports AwsServer#as2_transports}
        */
        readonly as2Transports?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_server#passive_ip AwsServer#passive_ip}
        */
        readonly passiveIp?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_server#set_stat_option AwsServer#set_stat_option}
        */
        readonly setStatOption?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_server#tls_session_resumption_mode AwsServer#tls_session_resumption_mode}
        */
        readonly tlsSessionResumptionMode?: string;
    }
    class ProtocolDetailsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ProtocolDetailsProperty | undefined;
        set internalValue(value: ProtocolDetailsProperty | undefined);
        private _as2Transports?;
        get as2Transports(): string[];
        set as2Transports(value: string[]);
        resetAs2Transports(): void;
        get as2TransportsInput(): string[] | undefined;
        private _passiveIp?;
        get passiveIp(): string;
        set passiveIp(value: string);
        resetPassiveIp(): void;
        get passiveIpInput(): string | undefined;
        private _setStatOption?;
        get setStatOption(): string;
        set setStatOption(value: string);
        resetSetStatOption(): void;
        get setStatOptionInput(): string | undefined;
        private _tlsSessionResumptionMode?;
        get tlsSessionResumptionMode(): string;
        set tlsSessionResumptionMode(value: string);
        resetTlsSessionResumptionMode(): void;
        get tlsSessionResumptionModeInput(): string | undefined;
    }
    interface S3StorageOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_server#directory_listing_optimization AwsServer#directory_listing_optimization}
        */
        readonly directoryListingOptimization?: string;
    }
    class S3StorageOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): S3StorageOptionsProperty | undefined;
        set internalValue(value: S3StorageOptionsProperty | undefined);
        private _directoryListingOptimization?;
        get directoryListingOptimization(): string;
        set directoryListingOptimization(value: string);
        resetDirectoryListingOptimization(): void;
        get directoryListingOptimizationInput(): string | undefined;
    }
    interface OnPartialUploadProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_server#execution_role AwsServer#execution_role}
        */
        readonly executionRole: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_server#workflow_id AwsServer#workflow_id}
        */
        readonly workflowId: string;
    }
    class OnPartialUploadPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): OnPartialUploadProperty | undefined;
        set internalValue(value: OnPartialUploadProperty | undefined);
        private _executionRole?;
        get executionRole(): string;
        set executionRole(value: string);
        get executionRoleInput(): string | undefined;
        private _workflowId?;
        get workflowId(): string;
        set workflowId(value: string);
        get workflowIdInput(): string | undefined;
    }
    interface OnUploadProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_server#execution_role AwsServer#execution_role}
        */
        readonly executionRole: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_server#workflow_id AwsServer#workflow_id}
        */
        readonly workflowId: string;
    }
    class OnUploadPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): OnUploadProperty | undefined;
        set internalValue(value: OnUploadProperty | undefined);
        private _executionRole?;
        get executionRole(): string;
        set executionRole(value: string);
        get executionRoleInput(): string | undefined;
        private _workflowId?;
        get workflowId(): string;
        set workflowId(value: string);
        get workflowIdInput(): string | undefined;
    }
    interface WorkflowDetailsProperty {
        /**
        * on_partial_upload block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_server#on_partial_upload AwsServer#on_partial_upload}
        */
        readonly onPartialUpload?: OnPartialUploadProperty;
        /**
        * on_upload block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_server#on_upload AwsServer#on_upload}
        */
        readonly onUpload?: OnUploadProperty;
    }
    class WorkflowDetailsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): WorkflowDetailsProperty | undefined;
        set internalValue(value: WorkflowDetailsProperty | undefined);
        private _onPartialUpload;
        get onPartialUpload(): OnPartialUploadPropertyOutputReference;
        putOnPartialUpload(value: OnPartialUploadProperty): void;
        resetOnPartialUpload(): void;
        get onPartialUploadInput(): OnPartialUploadProperty | undefined;
        private _onUpload;
        get onUpload(): OnUploadPropertyOutputReference;
        putOnUpload(value: OnUploadProperty): void;
        resetOnUpload(): void;
        get onUploadInput(): OnUploadProperty | undefined;
    }
}
