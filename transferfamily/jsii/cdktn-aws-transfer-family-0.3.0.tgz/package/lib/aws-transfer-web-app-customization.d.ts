import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsWebAppCustomizationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_web_app_customization#favicon_file AwsWebAppCustomization#favicon_file}
    */
    readonly faviconFile?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_web_app_customization#logo_file AwsWebAppCustomization#logo_file}
    */
    readonly logoFile?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_web_app_customization#region AwsWebAppCustomization#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_web_app_customization#title AwsWebAppCustomization#title}
    */
    readonly title?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_web_app_customization#web_app_id AwsWebAppCustomization#web_app_id}
    */
    readonly webAppId: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_web_app_customization aws_transfer_web_app_customization}
*/
export declare class AwsWebAppCustomization extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_transfer_web_app_customization";
    /**
    * Generates CDKTN code for importing a AwsWebAppCustomization resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsWebAppCustomization to import
    * @param importFromId The id of the existing AwsWebAppCustomization that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_web_app_customization#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsWebAppCustomization to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_web_app_customization aws_transfer_web_app_customization} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsWebAppCustomizationConfig
    */
    constructor(scope: Construct, id: string, config: AwsWebAppCustomizationConfig);
    private _faviconFile?;
    get faviconFile(): string;
    set faviconFile(value: string);
    resetFaviconFile(): void;
    get faviconFileInput(): string | undefined;
    private _logoFile?;
    get logoFile(): string;
    set logoFile(value: string);
    resetLogoFile(): void;
    get logoFileInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _title?;
    get title(): string;
    set title(value: string);
    resetTitle(): void;
    get titleInput(): string | undefined;
    private _webAppId?;
    get webAppId(): string;
    set webAppId(value: string);
    get webAppIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
