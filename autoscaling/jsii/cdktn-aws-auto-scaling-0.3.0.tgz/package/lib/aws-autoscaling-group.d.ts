import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsGroupConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#availability_zones AwsGroup#availability_zones}
    */
    readonly availabilityZones?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#capacity_rebalance AwsGroup#capacity_rebalance}
    */
    readonly capacityRebalance?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#context AwsGroup#context}
    */
    readonly context?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#default_cooldown AwsGroup#default_cooldown}
    */
    readonly defaultCooldown?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#default_instance_warmup AwsGroup#default_instance_warmup}
    */
    readonly defaultInstanceWarmup?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#desired_capacity AwsGroup#desired_capacity}
    */
    readonly desiredCapacity?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#desired_capacity_type AwsGroup#desired_capacity_type}
    */
    readonly desiredCapacityType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#enabled_metrics AwsGroup#enabled_metrics}
    */
    readonly enabledMetrics?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#force_delete AwsGroup#force_delete}
    */
    readonly forceDelete?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#force_delete_warm_pool AwsGroup#force_delete_warm_pool}
    */
    readonly forceDeleteWarmPool?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#health_check_grace_period AwsGroup#health_check_grace_period}
    */
    readonly healthCheckGracePeriod?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#health_check_type AwsGroup#health_check_type}
    */
    readonly healthCheckType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#id AwsGroup#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#ignore_failed_scaling_activities AwsGroup#ignore_failed_scaling_activities}
    */
    readonly ignoreFailedScalingActivities?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#launch_configuration AwsGroup#launch_configuration}
    */
    readonly launchConfiguration?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#load_balancers AwsGroup#load_balancers}
    */
    readonly loadBalancers?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#max_instance_lifetime AwsGroup#max_instance_lifetime}
    */
    readonly maxInstanceLifetime?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#max_size AwsGroup#max_size}
    */
    readonly maxSize: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#metrics_granularity AwsGroup#metrics_granularity}
    */
    readonly metricsGranularity?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#min_elb_capacity AwsGroup#min_elb_capacity}
    */
    readonly minElbCapacity?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#min_size AwsGroup#min_size}
    */
    readonly minSize: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#name AwsGroup#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#name_prefix AwsGroup#name_prefix}
    */
    readonly namePrefix?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#placement_group AwsGroup#placement_group}
    */
    readonly placementGroup?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#protect_from_scale_in AwsGroup#protect_from_scale_in}
    */
    readonly protectFromScaleIn?: boolean | cdktn.IResolvable;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#region AwsGroup#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#service_linked_role_arn AwsGroup#service_linked_role_arn}
    */
    readonly serviceLinkedRoleArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#suspended_processes AwsGroup#suspended_processes}
    */
    readonly suspendedProcesses?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#target_group_arns AwsGroup#target_group_arns}
    */
    readonly targetGroupArns?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#termination_policies AwsGroup#termination_policies}
    */
    readonly terminationPolicies?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#vpc_zone_identifier AwsGroup#vpc_zone_identifier}
    */
    readonly vpcZoneIdentifier?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#wait_for_capacity_timeout AwsGroup#wait_for_capacity_timeout}
    */
    readonly waitForCapacityTimeout?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#wait_for_elb_capacity AwsGroup#wait_for_elb_capacity}
    */
    readonly waitForElbCapacity?: number;
    /**
    * availability_zone_distribution block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#availability_zone_distribution AwsGroup#availability_zone_distribution}
    */
    readonly availabilityZoneDistribution?: AwsGroup.AvailabilityZoneDistributionProperty;
    /**
    * capacity_reservation_specification block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#capacity_reservation_specification AwsGroup#capacity_reservation_specification}
    */
    readonly capacityReservationSpecification?: AwsGroup.CapacityReservationSpecificationProperty;
    /**
    * initial_lifecycle_hook block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#initial_lifecycle_hook AwsGroup#initial_lifecycle_hook}
    */
    readonly initialLifecycleHook?: AwsGroup.InitialLifecycleHookProperty[] | cdktn.IResolvable;
    /**
    * instance_lifecycle_policy block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#instance_lifecycle_policy AwsGroup#instance_lifecycle_policy}
    */
    readonly instanceLifecyclePolicy?: AwsGroup.InstanceLifecyclePolicyProperty;
    /**
    * instance_maintenance_policy block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#instance_maintenance_policy AwsGroup#instance_maintenance_policy}
    */
    readonly instanceMaintenancePolicy?: AwsGroup.InstanceMaintenancePolicyProperty;
    /**
    * instance_refresh block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#instance_refresh AwsGroup#instance_refresh}
    */
    readonly instanceRefresh?: AwsGroup.InstanceRefreshProperty;
    /**
    * launch_template block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#launch_template AwsGroup#launch_template}
    */
    readonly launchTemplate?: AwsGroup.LaunchTemplateProperty;
    /**
    * mixed_instances_policy block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#mixed_instances_policy AwsGroup#mixed_instances_policy}
    */
    readonly mixedInstancesPolicy?: AwsGroup.MixedInstancesPolicyProperty;
    /**
    * tag block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#tag AwsGroup#tag}
    */
    readonly tag?: AwsGroup.TagProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#timeouts AwsGroup#timeouts}
    */
    readonly timeouts?: AwsGroup.TimeoutsProperty;
    /**
    * traffic_source block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#traffic_source AwsGroup#traffic_source}
    */
    readonly trafficSource?: AwsGroup.TrafficSourceProperty[] | cdktn.IResolvable;
    /**
    * warm_pool block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#warm_pool AwsGroup#warm_pool}
    */
    readonly warmPool?: AwsGroup.WarmPoolProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group aws_autoscaling_group}
*/
export declare class AwsGroup extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_autoscaling_group";
    /**
    * Generates CDKTN code for importing a AwsGroup resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsGroup to import
    * @param importFromId The id of the existing AwsGroup that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsGroup to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group aws_autoscaling_group} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsGroupConfig
    */
    constructor(scope: Construct, id: string, config: AwsGroupConfig);
    get arn(): string;
    private _availabilityZones?;
    get availabilityZones(): string[];
    set availabilityZones(value: string[]);
    resetAvailabilityZones(): void;
    get availabilityZonesInput(): string[] | undefined;
    private _capacityRebalance?;
    get capacityRebalance(): boolean | cdktn.IResolvable;
    set capacityRebalance(value: boolean | cdktn.IResolvable);
    resetCapacityRebalance(): void;
    get capacityRebalanceInput(): boolean | cdktn.IResolvable | undefined;
    private _context?;
    get context(): string;
    set context(value: string);
    resetContext(): void;
    get contextInput(): string | undefined;
    private _defaultCooldown?;
    get defaultCooldown(): number;
    set defaultCooldown(value: number);
    resetDefaultCooldown(): void;
    get defaultCooldownInput(): number | undefined;
    private _defaultInstanceWarmup?;
    get defaultInstanceWarmup(): number;
    set defaultInstanceWarmup(value: number);
    resetDefaultInstanceWarmup(): void;
    get defaultInstanceWarmupInput(): number | undefined;
    private _desiredCapacity?;
    get desiredCapacity(): number;
    set desiredCapacity(value: number);
    resetDesiredCapacity(): void;
    get desiredCapacityInput(): number | undefined;
    private _desiredCapacityType?;
    get desiredCapacityType(): string;
    set desiredCapacityType(value: string);
    resetDesiredCapacityType(): void;
    get desiredCapacityTypeInput(): string | undefined;
    private _enabledMetrics?;
    get enabledMetrics(): string[];
    set enabledMetrics(value: string[]);
    resetEnabledMetrics(): void;
    get enabledMetricsInput(): string[] | undefined;
    private _forceDelete?;
    get forceDelete(): boolean | cdktn.IResolvable;
    set forceDelete(value: boolean | cdktn.IResolvable);
    resetForceDelete(): void;
    get forceDeleteInput(): boolean | cdktn.IResolvable | undefined;
    private _forceDeleteWarmPool?;
    get forceDeleteWarmPool(): boolean | cdktn.IResolvable;
    set forceDeleteWarmPool(value: boolean | cdktn.IResolvable);
    resetForceDeleteWarmPool(): void;
    get forceDeleteWarmPoolInput(): boolean | cdktn.IResolvable | undefined;
    private _healthCheckGracePeriod?;
    get healthCheckGracePeriod(): number;
    set healthCheckGracePeriod(value: number);
    resetHealthCheckGracePeriod(): void;
    get healthCheckGracePeriodInput(): number | undefined;
    private _healthCheckType?;
    get healthCheckType(): string;
    set healthCheckType(value: string);
    resetHealthCheckType(): void;
    get healthCheckTypeInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _ignoreFailedScalingActivities?;
    get ignoreFailedScalingActivities(): boolean | cdktn.IResolvable;
    set ignoreFailedScalingActivities(value: boolean | cdktn.IResolvable);
    resetIgnoreFailedScalingActivities(): void;
    get ignoreFailedScalingActivitiesInput(): boolean | cdktn.IResolvable | undefined;
    private _launchConfiguration?;
    get launchConfiguration(): string;
    set launchConfiguration(value: string);
    resetLaunchConfiguration(): void;
    get launchConfigurationInput(): string | undefined;
    private _loadBalancers?;
    get loadBalancers(): string[];
    set loadBalancers(value: string[]);
    resetLoadBalancers(): void;
    get loadBalancersInput(): string[] | undefined;
    private _maxInstanceLifetime?;
    get maxInstanceLifetime(): number;
    set maxInstanceLifetime(value: number);
    resetMaxInstanceLifetime(): void;
    get maxInstanceLifetimeInput(): number | undefined;
    private _maxSize?;
    get maxSize(): number;
    set maxSize(value: number);
    get maxSizeInput(): number | undefined;
    private _metricsGranularity?;
    get metricsGranularity(): string;
    set metricsGranularity(value: string);
    resetMetricsGranularity(): void;
    get metricsGranularityInput(): string | undefined;
    private _minElbCapacity?;
    get minElbCapacity(): number;
    set minElbCapacity(value: number);
    resetMinElbCapacity(): void;
    get minElbCapacityInput(): number | undefined;
    private _minSize?;
    get minSize(): number;
    set minSize(value: number);
    get minSizeInput(): number | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _namePrefix?;
    get namePrefix(): string;
    set namePrefix(value: string);
    resetNamePrefix(): void;
    get namePrefixInput(): string | undefined;
    private _placementGroup?;
    get placementGroup(): string;
    set placementGroup(value: string);
    resetPlacementGroup(): void;
    get placementGroupInput(): string | undefined;
    get predictedCapacity(): number;
    private _protectFromScaleIn?;
    get protectFromScaleIn(): boolean | cdktn.IResolvable;
    set protectFromScaleIn(value: boolean | cdktn.IResolvable);
    resetProtectFromScaleIn(): void;
    get protectFromScaleInInput(): boolean | cdktn.IResolvable | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _serviceLinkedRoleArn?;
    get serviceLinkedRoleArn(): string;
    set serviceLinkedRoleArn(value: string);
    resetServiceLinkedRoleArn(): void;
    get serviceLinkedRoleArnInput(): string | undefined;
    private _suspendedProcesses?;
    get suspendedProcesses(): string[];
    set suspendedProcesses(value: string[]);
    resetSuspendedProcesses(): void;
    get suspendedProcessesInput(): string[] | undefined;
    private _targetGroupArns?;
    get targetGroupArns(): string[];
    set targetGroupArns(value: string[]);
    resetTargetGroupArns(): void;
    get targetGroupArnsInput(): string[] | undefined;
    private _terminationPolicies?;
    get terminationPolicies(): string[];
    set terminationPolicies(value: string[]);
    resetTerminationPolicies(): void;
    get terminationPoliciesInput(): string[] | undefined;
    private _vpcZoneIdentifier?;
    get vpcZoneIdentifier(): string[];
    set vpcZoneIdentifier(value: string[]);
    resetVpcZoneIdentifier(): void;
    get vpcZoneIdentifierInput(): string[] | undefined;
    private _waitForCapacityTimeout?;
    get waitForCapacityTimeout(): string;
    set waitForCapacityTimeout(value: string);
    resetWaitForCapacityTimeout(): void;
    get waitForCapacityTimeoutInput(): string | undefined;
    private _waitForElbCapacity?;
    get waitForElbCapacity(): number;
    set waitForElbCapacity(value: number);
    resetWaitForElbCapacity(): void;
    get waitForElbCapacityInput(): number | undefined;
    get warmPoolSize(): number;
    private _availabilityZoneDistribution;
    get availabilityZoneDistribution(): AwsGroup.AvailabilityZoneDistributionPropertyOutputReference;
    putAvailabilityZoneDistribution(value: AwsGroup.AvailabilityZoneDistributionProperty): void;
    resetAvailabilityZoneDistribution(): void;
    get availabilityZoneDistributionInput(): AwsGroup.AvailabilityZoneDistributionProperty | undefined;
    private _capacityReservationSpecification;
    get capacityReservationSpecification(): AwsGroup.CapacityReservationSpecificationPropertyOutputReference;
    putCapacityReservationSpecification(value: AwsGroup.CapacityReservationSpecificationProperty): void;
    resetCapacityReservationSpecification(): void;
    get capacityReservationSpecificationInput(): AwsGroup.CapacityReservationSpecificationProperty | undefined;
    private _initialLifecycleHook;
    get initialLifecycleHook(): AwsGroup.InitialLifecycleHookPropertyList;
    putInitialLifecycleHook(value: AwsGroup.InitialLifecycleHookProperty[] | cdktn.IResolvable): void;
    resetInitialLifecycleHook(): void;
    get initialLifecycleHookInput(): cdktn.IResolvable | AwsGroup.InitialLifecycleHookProperty[] | undefined;
    private _instanceLifecyclePolicy;
    get instanceLifecyclePolicy(): AwsGroup.InstanceLifecyclePolicyPropertyOutputReference;
    putInstanceLifecyclePolicy(value: AwsGroup.InstanceLifecyclePolicyProperty): void;
    resetInstanceLifecyclePolicy(): void;
    get instanceLifecyclePolicyInput(): AwsGroup.InstanceLifecyclePolicyProperty | undefined;
    private _instanceMaintenancePolicy;
    get instanceMaintenancePolicy(): AwsGroup.InstanceMaintenancePolicyPropertyOutputReference;
    putInstanceMaintenancePolicy(value: AwsGroup.InstanceMaintenancePolicyProperty): void;
    resetInstanceMaintenancePolicy(): void;
    get instanceMaintenancePolicyInput(): AwsGroup.InstanceMaintenancePolicyProperty | undefined;
    private _instanceRefresh;
    get instanceRefresh(): AwsGroup.InstanceRefreshPropertyOutputReference;
    putInstanceRefresh(value: AwsGroup.InstanceRefreshProperty): void;
    resetInstanceRefresh(): void;
    get instanceRefreshInput(): AwsGroup.InstanceRefreshProperty | undefined;
    private _launchTemplate;
    get launchTemplate(): AwsGroup.LaunchTemplatePropertyOutputReference;
    putLaunchTemplate(value: AwsGroup.LaunchTemplateProperty): void;
    resetLaunchTemplate(): void;
    get launchTemplateInput(): AwsGroup.LaunchTemplateProperty | undefined;
    private _mixedInstancesPolicy;
    get mixedInstancesPolicy(): AwsGroup.MixedInstancesPolicyPropertyOutputReference;
    putMixedInstancesPolicy(value: AwsGroup.MixedInstancesPolicyProperty): void;
    resetMixedInstancesPolicy(): void;
    get mixedInstancesPolicyInput(): AwsGroup.MixedInstancesPolicyProperty | undefined;
    private _tag;
    get tag(): AwsGroup.TagPropertyList;
    putTag(value: AwsGroup.TagProperty[] | cdktn.IResolvable): void;
    resetTag(): void;
    get tagInput(): cdktn.IResolvable | AwsGroup.TagProperty[] | undefined;
    private _timeouts;
    get timeouts(): AwsGroup.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsGroup.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsGroup.TimeoutsProperty | undefined;
    private _trafficSource;
    get trafficSource(): AwsGroup.TrafficSourcePropertyList;
    putTrafficSource(value: AwsGroup.TrafficSourceProperty[] | cdktn.IResolvable): void;
    resetTrafficSource(): void;
    get trafficSourceInput(): cdktn.IResolvable | AwsGroup.TrafficSourceProperty[] | undefined;
    private _warmPool;
    get warmPool(): AwsGroup.WarmPoolPropertyOutputReference;
    putWarmPool(value: AwsGroup.WarmPoolProperty): void;
    resetWarmPool(): void;
    get warmPoolInput(): AwsGroup.WarmPoolProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsGroupAvailabilityZoneDistributionPropertyToTerraform(struct?: AwsGroup.AvailabilityZoneDistributionPropertyOutputReference | AwsGroup.AvailabilityZoneDistributionProperty): any;
export declare function awsGroupAvailabilityZoneDistributionPropertyToHclTerraform(struct?: AwsGroup.AvailabilityZoneDistributionPropertyOutputReference | AwsGroup.AvailabilityZoneDistributionProperty): any;
export declare function awsGroupCapacityReservationTargetPropertyToTerraform(struct?: AwsGroup.CapacityReservationTargetPropertyOutputReference | AwsGroup.CapacityReservationTargetProperty): any;
export declare function awsGroupCapacityReservationTargetPropertyToHclTerraform(struct?: AwsGroup.CapacityReservationTargetPropertyOutputReference | AwsGroup.CapacityReservationTargetProperty): any;
export declare function awsGroupCapacityReservationSpecificationPropertyToTerraform(struct?: AwsGroup.CapacityReservationSpecificationPropertyOutputReference | AwsGroup.CapacityReservationSpecificationProperty): any;
export declare function awsGroupCapacityReservationSpecificationPropertyToHclTerraform(struct?: AwsGroup.CapacityReservationSpecificationPropertyOutputReference | AwsGroup.CapacityReservationSpecificationProperty): any;
export declare function awsGroupInitialLifecycleHookPropertyToTerraform(struct?: AwsGroup.InitialLifecycleHookProperty | cdktn.IResolvable): any;
export declare function awsGroupInitialLifecycleHookPropertyToHclTerraform(struct?: AwsGroup.InitialLifecycleHookProperty | cdktn.IResolvable): any;
export declare function awsGroupRetentionTriggersPropertyToTerraform(struct?: AwsGroup.RetentionTriggersPropertyOutputReference | AwsGroup.RetentionTriggersProperty): any;
export declare function awsGroupRetentionTriggersPropertyToHclTerraform(struct?: AwsGroup.RetentionTriggersPropertyOutputReference | AwsGroup.RetentionTriggersProperty): any;
export declare function awsGroupInstanceLifecyclePolicyPropertyToTerraform(struct?: AwsGroup.InstanceLifecyclePolicyPropertyOutputReference | AwsGroup.InstanceLifecyclePolicyProperty): any;
export declare function awsGroupInstanceLifecyclePolicyPropertyToHclTerraform(struct?: AwsGroup.InstanceLifecyclePolicyPropertyOutputReference | AwsGroup.InstanceLifecyclePolicyProperty): any;
export declare function awsGroupInstanceMaintenancePolicyPropertyToTerraform(struct?: AwsGroup.InstanceMaintenancePolicyPropertyOutputReference | AwsGroup.InstanceMaintenancePolicyProperty): any;
export declare function awsGroupInstanceMaintenancePolicyPropertyToHclTerraform(struct?: AwsGroup.InstanceMaintenancePolicyPropertyOutputReference | AwsGroup.InstanceMaintenancePolicyProperty): any;
export declare function awsGroupAlarmSpecificationPropertyToTerraform(struct?: AwsGroup.AlarmSpecificationPropertyOutputReference | AwsGroup.AlarmSpecificationProperty): any;
export declare function awsGroupAlarmSpecificationPropertyToHclTerraform(struct?: AwsGroup.AlarmSpecificationPropertyOutputReference | AwsGroup.AlarmSpecificationProperty): any;
export declare function awsGroupPreferencesPropertyToTerraform(struct?: AwsGroup.PreferencesPropertyOutputReference | AwsGroup.PreferencesProperty): any;
export declare function awsGroupPreferencesPropertyToHclTerraform(struct?: AwsGroup.PreferencesPropertyOutputReference | AwsGroup.PreferencesProperty): any;
export declare function awsGroupInstanceRefreshPropertyToTerraform(struct?: AwsGroup.InstanceRefreshPropertyOutputReference | AwsGroup.InstanceRefreshProperty): any;
export declare function awsGroupInstanceRefreshPropertyToHclTerraform(struct?: AwsGroup.InstanceRefreshPropertyOutputReference | AwsGroup.InstanceRefreshProperty): any;
export declare function awsGroupLaunchTemplatePropertyToTerraform(struct?: AwsGroup.LaunchTemplatePropertyOutputReference | AwsGroup.LaunchTemplateProperty): any;
export declare function awsGroupLaunchTemplatePropertyToHclTerraform(struct?: AwsGroup.LaunchTemplatePropertyOutputReference | AwsGroup.LaunchTemplateProperty): any;
export declare function awsGroupInstancesDistributionPropertyToTerraform(struct?: AwsGroup.InstancesDistributionPropertyOutputReference | AwsGroup.InstancesDistributionProperty): any;
export declare function awsGroupInstancesDistributionPropertyToHclTerraform(struct?: AwsGroup.InstancesDistributionPropertyOutputReference | AwsGroup.InstancesDistributionProperty): any;
export declare function awsGroupMixedInstancesPolicyLaunchTemplateLaunchTemplateSpecificationPropertyToTerraform(struct?: AwsGroup.MixedInstancesPolicyLaunchTemplateLaunchTemplateSpecificationPropertyOutputReference | AwsGroup.MixedInstancesPolicyLaunchTemplateLaunchTemplateSpecificationProperty): any;
export declare function awsGroupMixedInstancesPolicyLaunchTemplateLaunchTemplateSpecificationPropertyToHclTerraform(struct?: AwsGroup.MixedInstancesPolicyLaunchTemplateLaunchTemplateSpecificationPropertyOutputReference | AwsGroup.MixedInstancesPolicyLaunchTemplateLaunchTemplateSpecificationProperty): any;
export declare function awsGroupAcceleratorCountPropertyToTerraform(struct?: AwsGroup.AcceleratorCountPropertyOutputReference | AwsGroup.AcceleratorCountProperty): any;
export declare function awsGroupAcceleratorCountPropertyToHclTerraform(struct?: AwsGroup.AcceleratorCountPropertyOutputReference | AwsGroup.AcceleratorCountProperty): any;
export declare function awsGroupAcceleratorTotalMemoryMibPropertyToTerraform(struct?: AwsGroup.AcceleratorTotalMemoryMibPropertyOutputReference | AwsGroup.AcceleratorTotalMemoryMibProperty): any;
export declare function awsGroupAcceleratorTotalMemoryMibPropertyToHclTerraform(struct?: AwsGroup.AcceleratorTotalMemoryMibPropertyOutputReference | AwsGroup.AcceleratorTotalMemoryMibProperty): any;
export declare function awsGroupBaselineEbsBandwidthMbpsPropertyToTerraform(struct?: AwsGroup.BaselineEbsBandwidthMbpsPropertyOutputReference | AwsGroup.BaselineEbsBandwidthMbpsProperty): any;
export declare function awsGroupBaselineEbsBandwidthMbpsPropertyToHclTerraform(struct?: AwsGroup.BaselineEbsBandwidthMbpsPropertyOutputReference | AwsGroup.BaselineEbsBandwidthMbpsProperty): any;
export declare function awsGroupMemoryGibPerVcpuPropertyToTerraform(struct?: AwsGroup.MemoryGibPerVcpuPropertyOutputReference | AwsGroup.MemoryGibPerVcpuProperty): any;
export declare function awsGroupMemoryGibPerVcpuPropertyToHclTerraform(struct?: AwsGroup.MemoryGibPerVcpuPropertyOutputReference | AwsGroup.MemoryGibPerVcpuProperty): any;
export declare function awsGroupMemoryMibPropertyToTerraform(struct?: AwsGroup.MemoryMibPropertyOutputReference | AwsGroup.MemoryMibProperty): any;
export declare function awsGroupMemoryMibPropertyToHclTerraform(struct?: AwsGroup.MemoryMibPropertyOutputReference | AwsGroup.MemoryMibProperty): any;
export declare function awsGroupNetworkBandwidthGbpsPropertyToTerraform(struct?: AwsGroup.NetworkBandwidthGbpsPropertyOutputReference | AwsGroup.NetworkBandwidthGbpsProperty): any;
export declare function awsGroupNetworkBandwidthGbpsPropertyToHclTerraform(struct?: AwsGroup.NetworkBandwidthGbpsPropertyOutputReference | AwsGroup.NetworkBandwidthGbpsProperty): any;
export declare function awsGroupNetworkInterfaceCountPropertyToTerraform(struct?: AwsGroup.NetworkInterfaceCountPropertyOutputReference | AwsGroup.NetworkInterfaceCountProperty): any;
export declare function awsGroupNetworkInterfaceCountPropertyToHclTerraform(struct?: AwsGroup.NetworkInterfaceCountPropertyOutputReference | AwsGroup.NetworkInterfaceCountProperty): any;
export declare function awsGroupTotalLocalStorageGbPropertyToTerraform(struct?: AwsGroup.TotalLocalStorageGbPropertyOutputReference | AwsGroup.TotalLocalStorageGbProperty): any;
export declare function awsGroupTotalLocalStorageGbPropertyToHclTerraform(struct?: AwsGroup.TotalLocalStorageGbPropertyOutputReference | AwsGroup.TotalLocalStorageGbProperty): any;
export declare function awsGroupVcpuCountPropertyToTerraform(struct?: AwsGroup.VcpuCountPropertyOutputReference | AwsGroup.VcpuCountProperty): any;
export declare function awsGroupVcpuCountPropertyToHclTerraform(struct?: AwsGroup.VcpuCountPropertyOutputReference | AwsGroup.VcpuCountProperty): any;
export declare function awsGroupInstanceRequirementsPropertyToTerraform(struct?: AwsGroup.InstanceRequirementsPropertyOutputReference | AwsGroup.InstanceRequirementsProperty): any;
export declare function awsGroupInstanceRequirementsPropertyToHclTerraform(struct?: AwsGroup.InstanceRequirementsPropertyOutputReference | AwsGroup.InstanceRequirementsProperty): any;
export declare function awsGroupMixedInstancesPolicyLaunchTemplateOverrideLaunchTemplateSpecificationPropertyToTerraform(struct?: AwsGroup.MixedInstancesPolicyLaunchTemplateOverrideLaunchTemplateSpecificationPropertyOutputReference | AwsGroup.MixedInstancesPolicyLaunchTemplateOverrideLaunchTemplateSpecificationProperty): any;
export declare function awsGroupMixedInstancesPolicyLaunchTemplateOverrideLaunchTemplateSpecificationPropertyToHclTerraform(struct?: AwsGroup.MixedInstancesPolicyLaunchTemplateOverrideLaunchTemplateSpecificationPropertyOutputReference | AwsGroup.MixedInstancesPolicyLaunchTemplateOverrideLaunchTemplateSpecificationProperty): any;
export declare function awsGroupOverridePropertyToTerraform(struct?: AwsGroup.OverrideProperty | cdktn.IResolvable): any;
export declare function awsGroupOverridePropertyToHclTerraform(struct?: AwsGroup.OverrideProperty | cdktn.IResolvable): any;
export declare function awsGroupMixedInstancesPolicyLaunchTemplatePropertyToTerraform(struct?: AwsGroup.MixedInstancesPolicyLaunchTemplatePropertyOutputReference | AwsGroup.MixedInstancesPolicyLaunchTemplateProperty): any;
export declare function awsGroupMixedInstancesPolicyLaunchTemplatePropertyToHclTerraform(struct?: AwsGroup.MixedInstancesPolicyLaunchTemplatePropertyOutputReference | AwsGroup.MixedInstancesPolicyLaunchTemplateProperty): any;
export declare function awsGroupMixedInstancesPolicyPropertyToTerraform(struct?: AwsGroup.MixedInstancesPolicyPropertyOutputReference | AwsGroup.MixedInstancesPolicyProperty): any;
export declare function awsGroupMixedInstancesPolicyPropertyToHclTerraform(struct?: AwsGroup.MixedInstancesPolicyPropertyOutputReference | AwsGroup.MixedInstancesPolicyProperty): any;
export declare function awsGroupTagPropertyToTerraform(struct?: AwsGroup.TagProperty | cdktn.IResolvable): any;
export declare function awsGroupTagPropertyToHclTerraform(struct?: AwsGroup.TagProperty | cdktn.IResolvable): any;
export declare function awsGroupTimeoutsPropertyToTerraform(struct?: AwsGroup.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsGroupTimeoutsPropertyToHclTerraform(struct?: AwsGroup.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsGroupTrafficSourcePropertyToTerraform(struct?: AwsGroup.TrafficSourceProperty | cdktn.IResolvable): any;
export declare function awsGroupTrafficSourcePropertyToHclTerraform(struct?: AwsGroup.TrafficSourceProperty | cdktn.IResolvable): any;
export declare function awsGroupInstanceReusePolicyPropertyToTerraform(struct?: AwsGroup.InstanceReusePolicyPropertyOutputReference | AwsGroup.InstanceReusePolicyProperty): any;
export declare function awsGroupInstanceReusePolicyPropertyToHclTerraform(struct?: AwsGroup.InstanceReusePolicyPropertyOutputReference | AwsGroup.InstanceReusePolicyProperty): any;
export declare function awsGroupWarmPoolPropertyToTerraform(struct?: AwsGroup.WarmPoolPropertyOutputReference | AwsGroup.WarmPoolProperty): any;
export declare function awsGroupWarmPoolPropertyToHclTerraform(struct?: AwsGroup.WarmPoolPropertyOutputReference | AwsGroup.WarmPoolProperty): any;
export declare namespace AwsGroup {
    interface AvailabilityZoneDistributionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#capacity_distribution_strategy AwsGroup#capacity_distribution_strategy}
        */
        readonly capacityDistributionStrategy?: string;
    }
    class AvailabilityZoneDistributionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AvailabilityZoneDistributionProperty | undefined;
        set internalValue(value: AvailabilityZoneDistributionProperty | undefined);
        private _capacityDistributionStrategy?;
        get capacityDistributionStrategy(): string;
        set capacityDistributionStrategy(value: string);
        resetCapacityDistributionStrategy(): void;
        get capacityDistributionStrategyInput(): string | undefined;
    }
    interface CapacityReservationTargetProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#capacity_reservation_ids AwsGroup#capacity_reservation_ids}
        */
        readonly capacityReservationIds?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#capacity_reservation_resource_group_arns AwsGroup#capacity_reservation_resource_group_arns}
        */
        readonly capacityReservationResourceGroupArns?: string[];
    }
    class CapacityReservationTargetPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CapacityReservationTargetProperty | undefined;
        set internalValue(value: CapacityReservationTargetProperty | undefined);
        private _capacityReservationIds?;
        get capacityReservationIds(): string[];
        set capacityReservationIds(value: string[]);
        resetCapacityReservationIds(): void;
        get capacityReservationIdsInput(): string[] | undefined;
        private _capacityReservationResourceGroupArns?;
        get capacityReservationResourceGroupArns(): string[];
        set capacityReservationResourceGroupArns(value: string[]);
        resetCapacityReservationResourceGroupArns(): void;
        get capacityReservationResourceGroupArnsInput(): string[] | undefined;
    }
    interface CapacityReservationSpecificationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#capacity_reservation_preference AwsGroup#capacity_reservation_preference}
        */
        readonly capacityReservationPreference?: string;
        /**
        * capacity_reservation_target block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#capacity_reservation_target AwsGroup#capacity_reservation_target}
        */
        readonly capacityReservationTarget?: CapacityReservationTargetProperty;
    }
    class CapacityReservationSpecificationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CapacityReservationSpecificationProperty | undefined;
        set internalValue(value: CapacityReservationSpecificationProperty | undefined);
        private _capacityReservationPreference?;
        get capacityReservationPreference(): string;
        set capacityReservationPreference(value: string);
        resetCapacityReservationPreference(): void;
        get capacityReservationPreferenceInput(): string | undefined;
        private _capacityReservationTarget;
        get capacityReservationTarget(): CapacityReservationTargetPropertyOutputReference;
        putCapacityReservationTarget(value: CapacityReservationTargetProperty): void;
        resetCapacityReservationTarget(): void;
        get capacityReservationTargetInput(): CapacityReservationTargetProperty | undefined;
    }
    interface InitialLifecycleHookProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#default_result AwsGroup#default_result}
        */
        readonly defaultResult?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#heartbeat_timeout AwsGroup#heartbeat_timeout}
        */
        readonly heartbeatTimeout?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#lifecycle_transition AwsGroup#lifecycle_transition}
        */
        readonly lifecycleTransition: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#name AwsGroup#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#notification_metadata AwsGroup#notification_metadata}
        */
        readonly notificationMetadata?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#notification_target_arn AwsGroup#notification_target_arn}
        */
        readonly notificationTargetArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#role_arn AwsGroup#role_arn}
        */
        readonly roleArn?: string;
    }
    class InitialLifecycleHookPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): InitialLifecycleHookProperty | cdktn.IResolvable | undefined;
        set internalValue(value: InitialLifecycleHookProperty | cdktn.IResolvable | undefined);
        private _defaultResult?;
        get defaultResult(): string;
        set defaultResult(value: string);
        resetDefaultResult(): void;
        get defaultResultInput(): string | undefined;
        private _heartbeatTimeout?;
        get heartbeatTimeout(): number;
        set heartbeatTimeout(value: number);
        resetHeartbeatTimeout(): void;
        get heartbeatTimeoutInput(): number | undefined;
        private _lifecycleTransition?;
        get lifecycleTransition(): string;
        set lifecycleTransition(value: string);
        get lifecycleTransitionInput(): string | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _notificationMetadata?;
        get notificationMetadata(): string;
        set notificationMetadata(value: string);
        resetNotificationMetadata(): void;
        get notificationMetadataInput(): string | undefined;
        private _notificationTargetArn?;
        get notificationTargetArn(): string;
        set notificationTargetArn(value: string);
        resetNotificationTargetArn(): void;
        get notificationTargetArnInput(): string | undefined;
        private _roleArn?;
        get roleArn(): string;
        set roleArn(value: string);
        resetRoleArn(): void;
        get roleArnInput(): string | undefined;
    }
    class InitialLifecycleHookPropertyList extends cdktn.ComplexList {
        internalValue?: InitialLifecycleHookProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): InitialLifecycleHookPropertyOutputReference;
    }
    interface RetentionTriggersProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#terminate_hook_abandon AwsGroup#terminate_hook_abandon}
        */
        readonly terminateHookAbandon?: string;
    }
    class RetentionTriggersPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RetentionTriggersProperty | undefined;
        set internalValue(value: RetentionTriggersProperty | undefined);
        private _terminateHookAbandon?;
        get terminateHookAbandon(): string;
        set terminateHookAbandon(value: string);
        resetTerminateHookAbandon(): void;
        get terminateHookAbandonInput(): string | undefined;
    }
    interface InstanceLifecyclePolicyProperty {
        /**
        * retention_triggers block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#retention_triggers AwsGroup#retention_triggers}
        */
        readonly retentionTriggers?: RetentionTriggersProperty;
    }
    class InstanceLifecyclePolicyPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): InstanceLifecyclePolicyProperty | undefined;
        set internalValue(value: InstanceLifecyclePolicyProperty | undefined);
        private _retentionTriggers;
        get retentionTriggers(): RetentionTriggersPropertyOutputReference;
        putRetentionTriggers(value: RetentionTriggersProperty): void;
        resetRetentionTriggers(): void;
        get retentionTriggersInput(): RetentionTriggersProperty | undefined;
    }
    interface InstanceMaintenancePolicyProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#max_healthy_percentage AwsGroup#max_healthy_percentage}
        */
        readonly maxHealthyPercentage: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#min_healthy_percentage AwsGroup#min_healthy_percentage}
        */
        readonly minHealthyPercentage: number;
    }
    class InstanceMaintenancePolicyPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): InstanceMaintenancePolicyProperty | undefined;
        set internalValue(value: InstanceMaintenancePolicyProperty | undefined);
        private _maxHealthyPercentage?;
        get maxHealthyPercentage(): number;
        set maxHealthyPercentage(value: number);
        get maxHealthyPercentageInput(): number | undefined;
        private _minHealthyPercentage?;
        get minHealthyPercentage(): number;
        set minHealthyPercentage(value: number);
        get minHealthyPercentageInput(): number | undefined;
    }
    interface AlarmSpecificationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#alarms AwsGroup#alarms}
        */
        readonly alarms?: string[];
    }
    class AlarmSpecificationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AlarmSpecificationProperty | undefined;
        set internalValue(value: AlarmSpecificationProperty | undefined);
        private _alarms?;
        get alarms(): string[];
        set alarms(value: string[]);
        resetAlarms(): void;
        get alarmsInput(): string[] | undefined;
    }
    interface PreferencesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#auto_rollback AwsGroup#auto_rollback}
        */
        readonly autoRollback?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#checkpoint_delay AwsGroup#checkpoint_delay}
        */
        readonly checkpointDelay?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#checkpoint_percentages AwsGroup#checkpoint_percentages}
        */
        readonly checkpointPercentages?: number[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#instance_warmup AwsGroup#instance_warmup}
        */
        readonly instanceWarmup?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#max_healthy_percentage AwsGroup#max_healthy_percentage}
        */
        readonly maxHealthyPercentage?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#min_healthy_percentage AwsGroup#min_healthy_percentage}
        */
        readonly minHealthyPercentage?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#scale_in_protected_instances AwsGroup#scale_in_protected_instances}
        */
        readonly scaleInProtectedInstances?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#skip_matching AwsGroup#skip_matching}
        */
        readonly skipMatching?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#standby_instances AwsGroup#standby_instances}
        */
        readonly standbyInstances?: string;
        /**
        * alarm_specification block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#alarm_specification AwsGroup#alarm_specification}
        */
        readonly alarmSpecification?: AlarmSpecificationProperty;
    }
    class PreferencesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): PreferencesProperty | undefined;
        set internalValue(value: PreferencesProperty | undefined);
        private _autoRollback?;
        get autoRollback(): boolean | cdktn.IResolvable;
        set autoRollback(value: boolean | cdktn.IResolvable);
        resetAutoRollback(): void;
        get autoRollbackInput(): boolean | cdktn.IResolvable | undefined;
        private _checkpointDelay?;
        get checkpointDelay(): string;
        set checkpointDelay(value: string);
        resetCheckpointDelay(): void;
        get checkpointDelayInput(): string | undefined;
        private _checkpointPercentages?;
        get checkpointPercentages(): number[];
        set checkpointPercentages(value: number[]);
        resetCheckpointPercentages(): void;
        get checkpointPercentagesInput(): number[] | undefined;
        private _instanceWarmup?;
        get instanceWarmup(): string;
        set instanceWarmup(value: string);
        resetInstanceWarmup(): void;
        get instanceWarmupInput(): string | undefined;
        private _maxHealthyPercentage?;
        get maxHealthyPercentage(): number;
        set maxHealthyPercentage(value: number);
        resetMaxHealthyPercentage(): void;
        get maxHealthyPercentageInput(): number | undefined;
        private _minHealthyPercentage?;
        get minHealthyPercentage(): number;
        set minHealthyPercentage(value: number);
        resetMinHealthyPercentage(): void;
        get minHealthyPercentageInput(): number | undefined;
        private _scaleInProtectedInstances?;
        get scaleInProtectedInstances(): string;
        set scaleInProtectedInstances(value: string);
        resetScaleInProtectedInstances(): void;
        get scaleInProtectedInstancesInput(): string | undefined;
        private _skipMatching?;
        get skipMatching(): boolean | cdktn.IResolvable;
        set skipMatching(value: boolean | cdktn.IResolvable);
        resetSkipMatching(): void;
        get skipMatchingInput(): boolean | cdktn.IResolvable | undefined;
        private _standbyInstances?;
        get standbyInstances(): string;
        set standbyInstances(value: string);
        resetStandbyInstances(): void;
        get standbyInstancesInput(): string | undefined;
        private _alarmSpecification;
        get alarmSpecification(): AlarmSpecificationPropertyOutputReference;
        putAlarmSpecification(value: AlarmSpecificationProperty): void;
        resetAlarmSpecification(): void;
        get alarmSpecificationInput(): AlarmSpecificationProperty | undefined;
    }
    interface InstanceRefreshProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#strategy AwsGroup#strategy}
        */
        readonly strategy: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#triggers AwsGroup#triggers}
        */
        readonly triggers?: string[];
        /**
        * preferences block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#preferences AwsGroup#preferences}
        */
        readonly preferences?: PreferencesProperty;
    }
    class InstanceRefreshPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): InstanceRefreshProperty | undefined;
        set internalValue(value: InstanceRefreshProperty | undefined);
        private _strategy?;
        get strategy(): string;
        set strategy(value: string);
        get strategyInput(): string | undefined;
        private _triggers?;
        get triggers(): string[];
        set triggers(value: string[]);
        resetTriggers(): void;
        get triggersInput(): string[] | undefined;
        private _preferences;
        get preferences(): PreferencesPropertyOutputReference;
        putPreferences(value: PreferencesProperty): void;
        resetPreferences(): void;
        get preferencesInput(): PreferencesProperty | undefined;
    }
    interface LaunchTemplateProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#id AwsGroup#id}
        *
        * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
        * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
        */
        readonly id?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#name AwsGroup#name}
        */
        readonly name?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#version AwsGroup#version}
        */
        readonly version?: string;
    }
    class LaunchTemplatePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): LaunchTemplateProperty | undefined;
        set internalValue(value: LaunchTemplateProperty | undefined);
        private _id?;
        get id(): string;
        set id(value: string);
        resetId(): void;
        get idInput(): string | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        resetName(): void;
        get nameInput(): string | undefined;
        private _version?;
        get version(): string;
        set version(value: string);
        resetVersion(): void;
        get versionInput(): string | undefined;
    }
    interface InstancesDistributionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#on_demand_allocation_strategy AwsGroup#on_demand_allocation_strategy}
        */
        readonly onDemandAllocationStrategy?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#on_demand_base_capacity AwsGroup#on_demand_base_capacity}
        */
        readonly onDemandBaseCapacity?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#on_demand_percentage_above_base_capacity AwsGroup#on_demand_percentage_above_base_capacity}
        */
        readonly onDemandPercentageAboveBaseCapacity?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#spot_allocation_strategy AwsGroup#spot_allocation_strategy}
        */
        readonly spotAllocationStrategy?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#spot_instance_pools AwsGroup#spot_instance_pools}
        */
        readonly spotInstancePools?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#spot_max_price AwsGroup#spot_max_price}
        */
        readonly spotMaxPrice?: string;
    }
    class InstancesDistributionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): InstancesDistributionProperty | undefined;
        set internalValue(value: InstancesDistributionProperty | undefined);
        private _onDemandAllocationStrategy?;
        get onDemandAllocationStrategy(): string;
        set onDemandAllocationStrategy(value: string);
        resetOnDemandAllocationStrategy(): void;
        get onDemandAllocationStrategyInput(): string | undefined;
        private _onDemandBaseCapacity?;
        get onDemandBaseCapacity(): number;
        set onDemandBaseCapacity(value: number);
        resetOnDemandBaseCapacity(): void;
        get onDemandBaseCapacityInput(): number | undefined;
        private _onDemandPercentageAboveBaseCapacity?;
        get onDemandPercentageAboveBaseCapacity(): number;
        set onDemandPercentageAboveBaseCapacity(value: number);
        resetOnDemandPercentageAboveBaseCapacity(): void;
        get onDemandPercentageAboveBaseCapacityInput(): number | undefined;
        private _spotAllocationStrategy?;
        get spotAllocationStrategy(): string;
        set spotAllocationStrategy(value: string);
        resetSpotAllocationStrategy(): void;
        get spotAllocationStrategyInput(): string | undefined;
        private _spotInstancePools?;
        get spotInstancePools(): number;
        set spotInstancePools(value: number);
        resetSpotInstancePools(): void;
        get spotInstancePoolsInput(): number | undefined;
        private _spotMaxPrice?;
        get spotMaxPrice(): string;
        set spotMaxPrice(value: string);
        resetSpotMaxPrice(): void;
        get spotMaxPriceInput(): string | undefined;
    }
    interface MixedInstancesPolicyLaunchTemplateLaunchTemplateSpecificationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#launch_template_id AwsGroup#launch_template_id}
        */
        readonly launchTemplateId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#launch_template_name AwsGroup#launch_template_name}
        */
        readonly launchTemplateName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#version AwsGroup#version}
        */
        readonly version?: string;
    }
    class MixedInstancesPolicyLaunchTemplateLaunchTemplateSpecificationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): MixedInstancesPolicyLaunchTemplateLaunchTemplateSpecificationProperty | undefined;
        set internalValue(value: MixedInstancesPolicyLaunchTemplateLaunchTemplateSpecificationProperty | undefined);
        private _launchTemplateId?;
        get launchTemplateId(): string;
        set launchTemplateId(value: string);
        resetLaunchTemplateId(): void;
        get launchTemplateIdInput(): string | undefined;
        private _launchTemplateName?;
        get launchTemplateName(): string;
        set launchTemplateName(value: string);
        resetLaunchTemplateName(): void;
        get launchTemplateNameInput(): string | undefined;
        private _version?;
        get version(): string;
        set version(value: string);
        resetVersion(): void;
        get versionInput(): string | undefined;
    }
    interface AcceleratorCountProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#max AwsGroup#max}
        */
        readonly max?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#min AwsGroup#min}
        */
        readonly min?: number;
    }
    class AcceleratorCountPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AcceleratorCountProperty | undefined;
        set internalValue(value: AcceleratorCountProperty | undefined);
        private _max?;
        get max(): number;
        set max(value: number);
        resetMax(): void;
        get maxInput(): number | undefined;
        private _min?;
        get min(): number;
        set min(value: number);
        resetMin(): void;
        get minInput(): number | undefined;
    }
    interface AcceleratorTotalMemoryMibProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#max AwsGroup#max}
        */
        readonly max?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#min AwsGroup#min}
        */
        readonly min?: number;
    }
    class AcceleratorTotalMemoryMibPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AcceleratorTotalMemoryMibProperty | undefined;
        set internalValue(value: AcceleratorTotalMemoryMibProperty | undefined);
        private _max?;
        get max(): number;
        set max(value: number);
        resetMax(): void;
        get maxInput(): number | undefined;
        private _min?;
        get min(): number;
        set min(value: number);
        resetMin(): void;
        get minInput(): number | undefined;
    }
    interface BaselineEbsBandwidthMbpsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#max AwsGroup#max}
        */
        readonly max?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#min AwsGroup#min}
        */
        readonly min?: number;
    }
    class BaselineEbsBandwidthMbpsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): BaselineEbsBandwidthMbpsProperty | undefined;
        set internalValue(value: BaselineEbsBandwidthMbpsProperty | undefined);
        private _max?;
        get max(): number;
        set max(value: number);
        resetMax(): void;
        get maxInput(): number | undefined;
        private _min?;
        get min(): number;
        set min(value: number);
        resetMin(): void;
        get minInput(): number | undefined;
    }
    interface MemoryGibPerVcpuProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#max AwsGroup#max}
        */
        readonly max?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#min AwsGroup#min}
        */
        readonly min?: number;
    }
    class MemoryGibPerVcpuPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): MemoryGibPerVcpuProperty | undefined;
        set internalValue(value: MemoryGibPerVcpuProperty | undefined);
        private _max?;
        get max(): number;
        set max(value: number);
        resetMax(): void;
        get maxInput(): number | undefined;
        private _min?;
        get min(): number;
        set min(value: number);
        resetMin(): void;
        get minInput(): number | undefined;
    }
    interface MemoryMibProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#max AwsGroup#max}
        */
        readonly max?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#min AwsGroup#min}
        */
        readonly min?: number;
    }
    class MemoryMibPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): MemoryMibProperty | undefined;
        set internalValue(value: MemoryMibProperty | undefined);
        private _max?;
        get max(): number;
        set max(value: number);
        resetMax(): void;
        get maxInput(): number | undefined;
        private _min?;
        get min(): number;
        set min(value: number);
        resetMin(): void;
        get minInput(): number | undefined;
    }
    interface NetworkBandwidthGbpsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#max AwsGroup#max}
        */
        readonly max?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#min AwsGroup#min}
        */
        readonly min?: number;
    }
    class NetworkBandwidthGbpsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): NetworkBandwidthGbpsProperty | undefined;
        set internalValue(value: NetworkBandwidthGbpsProperty | undefined);
        private _max?;
        get max(): number;
        set max(value: number);
        resetMax(): void;
        get maxInput(): number | undefined;
        private _min?;
        get min(): number;
        set min(value: number);
        resetMin(): void;
        get minInput(): number | undefined;
    }
    interface NetworkInterfaceCountProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#max AwsGroup#max}
        */
        readonly max?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#min AwsGroup#min}
        */
        readonly min?: number;
    }
    class NetworkInterfaceCountPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): NetworkInterfaceCountProperty | undefined;
        set internalValue(value: NetworkInterfaceCountProperty | undefined);
        private _max?;
        get max(): number;
        set max(value: number);
        resetMax(): void;
        get maxInput(): number | undefined;
        private _min?;
        get min(): number;
        set min(value: number);
        resetMin(): void;
        get minInput(): number | undefined;
    }
    interface TotalLocalStorageGbProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#max AwsGroup#max}
        */
        readonly max?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#min AwsGroup#min}
        */
        readonly min?: number;
    }
    class TotalLocalStorageGbPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TotalLocalStorageGbProperty | undefined;
        set internalValue(value: TotalLocalStorageGbProperty | undefined);
        private _max?;
        get max(): number;
        set max(value: number);
        resetMax(): void;
        get maxInput(): number | undefined;
        private _min?;
        get min(): number;
        set min(value: number);
        resetMin(): void;
        get minInput(): number | undefined;
    }
    interface VcpuCountProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#max AwsGroup#max}
        */
        readonly max?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#min AwsGroup#min}
        */
        readonly min?: number;
    }
    class VcpuCountPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): VcpuCountProperty | undefined;
        set internalValue(value: VcpuCountProperty | undefined);
        private _max?;
        get max(): number;
        set max(value: number);
        resetMax(): void;
        get maxInput(): number | undefined;
        private _min?;
        get min(): number;
        set min(value: number);
        resetMin(): void;
        get minInput(): number | undefined;
    }
    interface InstanceRequirementsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#accelerator_manufacturers AwsGroup#accelerator_manufacturers}
        */
        readonly acceleratorManufacturers?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#accelerator_names AwsGroup#accelerator_names}
        */
        readonly acceleratorNames?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#accelerator_types AwsGroup#accelerator_types}
        */
        readonly acceleratorTypes?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#allowed_instance_types AwsGroup#allowed_instance_types}
        */
        readonly allowedInstanceTypes?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#bare_metal AwsGroup#bare_metal}
        */
        readonly bareMetal?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#burstable_performance AwsGroup#burstable_performance}
        */
        readonly burstablePerformance?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#cpu_manufacturers AwsGroup#cpu_manufacturers}
        */
        readonly cpuManufacturers?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#excluded_instance_types AwsGroup#excluded_instance_types}
        */
        readonly excludedInstanceTypes?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#instance_generations AwsGroup#instance_generations}
        */
        readonly instanceGenerations?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#local_storage AwsGroup#local_storage}
        */
        readonly localStorage?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#local_storage_types AwsGroup#local_storage_types}
        */
        readonly localStorageTypes?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#max_spot_price_as_percentage_of_optimal_on_demand_price AwsGroup#max_spot_price_as_percentage_of_optimal_on_demand_price}
        */
        readonly maxSpotPriceAsPercentageOfOptimalOnDemandPrice?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#on_demand_max_price_percentage_over_lowest_price AwsGroup#on_demand_max_price_percentage_over_lowest_price}
        */
        readonly onDemandMaxPricePercentageOverLowestPrice?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#require_hibernate_support AwsGroup#require_hibernate_support}
        */
        readonly requireHibernateSupport?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#spot_max_price_percentage_over_lowest_price AwsGroup#spot_max_price_percentage_over_lowest_price}
        */
        readonly spotMaxPricePercentageOverLowestPrice?: number;
        /**
        * accelerator_count block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#accelerator_count AwsGroup#accelerator_count}
        */
        readonly acceleratorCount?: AcceleratorCountProperty;
        /**
        * accelerator_total_memory_mib block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#accelerator_total_memory_mib AwsGroup#accelerator_total_memory_mib}
        */
        readonly acceleratorTotalMemoryMib?: AcceleratorTotalMemoryMibProperty;
        /**
        * baseline_ebs_bandwidth_mbps block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#baseline_ebs_bandwidth_mbps AwsGroup#baseline_ebs_bandwidth_mbps}
        */
        readonly baselineEbsBandwidthMbps?: BaselineEbsBandwidthMbpsProperty;
        /**
        * memory_gib_per_vcpu block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#memory_gib_per_vcpu AwsGroup#memory_gib_per_vcpu}
        */
        readonly memoryGibPerVcpu?: MemoryGibPerVcpuProperty;
        /**
        * memory_mib block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#memory_mib AwsGroup#memory_mib}
        */
        readonly memoryMib?: MemoryMibProperty;
        /**
        * network_bandwidth_gbps block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#network_bandwidth_gbps AwsGroup#network_bandwidth_gbps}
        */
        readonly networkBandwidthGbps?: NetworkBandwidthGbpsProperty;
        /**
        * network_interface_count block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#network_interface_count AwsGroup#network_interface_count}
        */
        readonly networkInterfaceCount?: NetworkInterfaceCountProperty;
        /**
        * total_local_storage_gb block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#total_local_storage_gb AwsGroup#total_local_storage_gb}
        */
        readonly totalLocalStorageGb?: TotalLocalStorageGbProperty;
        /**
        * vcpu_count block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#vcpu_count AwsGroup#vcpu_count}
        */
        readonly vcpuCount?: VcpuCountProperty;
    }
    class InstanceRequirementsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): InstanceRequirementsProperty | undefined;
        set internalValue(value: InstanceRequirementsProperty | undefined);
        private _acceleratorManufacturers?;
        get acceleratorManufacturers(): string[];
        set acceleratorManufacturers(value: string[]);
        resetAcceleratorManufacturers(): void;
        get acceleratorManufacturersInput(): string[] | undefined;
        private _acceleratorNames?;
        get acceleratorNames(): string[];
        set acceleratorNames(value: string[]);
        resetAcceleratorNames(): void;
        get acceleratorNamesInput(): string[] | undefined;
        private _acceleratorTypes?;
        get acceleratorTypes(): string[];
        set acceleratorTypes(value: string[]);
        resetAcceleratorTypes(): void;
        get acceleratorTypesInput(): string[] | undefined;
        private _allowedInstanceTypes?;
        get allowedInstanceTypes(): string[];
        set allowedInstanceTypes(value: string[]);
        resetAllowedInstanceTypes(): void;
        get allowedInstanceTypesInput(): string[] | undefined;
        private _bareMetal?;
        get bareMetal(): string;
        set bareMetal(value: string);
        resetBareMetal(): void;
        get bareMetalInput(): string | undefined;
        private _burstablePerformance?;
        get burstablePerformance(): string;
        set burstablePerformance(value: string);
        resetBurstablePerformance(): void;
        get burstablePerformanceInput(): string | undefined;
        private _cpuManufacturers?;
        get cpuManufacturers(): string[];
        set cpuManufacturers(value: string[]);
        resetCpuManufacturers(): void;
        get cpuManufacturersInput(): string[] | undefined;
        private _excludedInstanceTypes?;
        get excludedInstanceTypes(): string[];
        set excludedInstanceTypes(value: string[]);
        resetExcludedInstanceTypes(): void;
        get excludedInstanceTypesInput(): string[] | undefined;
        private _instanceGenerations?;
        get instanceGenerations(): string[];
        set instanceGenerations(value: string[]);
        resetInstanceGenerations(): void;
        get instanceGenerationsInput(): string[] | undefined;
        private _localStorage?;
        get localStorage(): string;
        set localStorage(value: string);
        resetLocalStorage(): void;
        get localStorageInput(): string | undefined;
        private _localStorageTypes?;
        get localStorageTypes(): string[];
        set localStorageTypes(value: string[]);
        resetLocalStorageTypes(): void;
        get localStorageTypesInput(): string[] | undefined;
        private _maxSpotPriceAsPercentageOfOptimalOnDemandPrice?;
        get maxSpotPriceAsPercentageOfOptimalOnDemandPrice(): number;
        set maxSpotPriceAsPercentageOfOptimalOnDemandPrice(value: number);
        resetMaxSpotPriceAsPercentageOfOptimalOnDemandPrice(): void;
        get maxSpotPriceAsPercentageOfOptimalOnDemandPriceInput(): number | undefined;
        private _onDemandMaxPricePercentageOverLowestPrice?;
        get onDemandMaxPricePercentageOverLowestPrice(): number;
        set onDemandMaxPricePercentageOverLowestPrice(value: number);
        resetOnDemandMaxPricePercentageOverLowestPrice(): void;
        get onDemandMaxPricePercentageOverLowestPriceInput(): number | undefined;
        private _requireHibernateSupport?;
        get requireHibernateSupport(): boolean | cdktn.IResolvable;
        set requireHibernateSupport(value: boolean | cdktn.IResolvable);
        resetRequireHibernateSupport(): void;
        get requireHibernateSupportInput(): boolean | cdktn.IResolvable | undefined;
        private _spotMaxPricePercentageOverLowestPrice?;
        get spotMaxPricePercentageOverLowestPrice(): number;
        set spotMaxPricePercentageOverLowestPrice(value: number);
        resetSpotMaxPricePercentageOverLowestPrice(): void;
        get spotMaxPricePercentageOverLowestPriceInput(): number | undefined;
        private _acceleratorCount;
        get acceleratorCount(): AcceleratorCountPropertyOutputReference;
        putAcceleratorCount(value: AcceleratorCountProperty): void;
        resetAcceleratorCount(): void;
        get acceleratorCountInput(): AcceleratorCountProperty | undefined;
        private _acceleratorTotalMemoryMib;
        get acceleratorTotalMemoryMib(): AcceleratorTotalMemoryMibPropertyOutputReference;
        putAcceleratorTotalMemoryMib(value: AcceleratorTotalMemoryMibProperty): void;
        resetAcceleratorTotalMemoryMib(): void;
        get acceleratorTotalMemoryMibInput(): AcceleratorTotalMemoryMibProperty | undefined;
        private _baselineEbsBandwidthMbps;
        get baselineEbsBandwidthMbps(): BaselineEbsBandwidthMbpsPropertyOutputReference;
        putBaselineEbsBandwidthMbps(value: BaselineEbsBandwidthMbpsProperty): void;
        resetBaselineEbsBandwidthMbps(): void;
        get baselineEbsBandwidthMbpsInput(): BaselineEbsBandwidthMbpsProperty | undefined;
        private _memoryGibPerVcpu;
        get memoryGibPerVcpu(): MemoryGibPerVcpuPropertyOutputReference;
        putMemoryGibPerVcpu(value: MemoryGibPerVcpuProperty): void;
        resetMemoryGibPerVcpu(): void;
        get memoryGibPerVcpuInput(): MemoryGibPerVcpuProperty | undefined;
        private _memoryMib;
        get memoryMib(): MemoryMibPropertyOutputReference;
        putMemoryMib(value: MemoryMibProperty): void;
        resetMemoryMib(): void;
        get memoryMibInput(): MemoryMibProperty | undefined;
        private _networkBandwidthGbps;
        get networkBandwidthGbps(): NetworkBandwidthGbpsPropertyOutputReference;
        putNetworkBandwidthGbps(value: NetworkBandwidthGbpsProperty): void;
        resetNetworkBandwidthGbps(): void;
        get networkBandwidthGbpsInput(): NetworkBandwidthGbpsProperty | undefined;
        private _networkInterfaceCount;
        get networkInterfaceCount(): NetworkInterfaceCountPropertyOutputReference;
        putNetworkInterfaceCount(value: NetworkInterfaceCountProperty): void;
        resetNetworkInterfaceCount(): void;
        get networkInterfaceCountInput(): NetworkInterfaceCountProperty | undefined;
        private _totalLocalStorageGb;
        get totalLocalStorageGb(): TotalLocalStorageGbPropertyOutputReference;
        putTotalLocalStorageGb(value: TotalLocalStorageGbProperty): void;
        resetTotalLocalStorageGb(): void;
        get totalLocalStorageGbInput(): TotalLocalStorageGbProperty | undefined;
        private _vcpuCount;
        get vcpuCount(): VcpuCountPropertyOutputReference;
        putVcpuCount(value: VcpuCountProperty): void;
        resetVcpuCount(): void;
        get vcpuCountInput(): VcpuCountProperty | undefined;
    }
    interface MixedInstancesPolicyLaunchTemplateOverrideLaunchTemplateSpecificationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#launch_template_id AwsGroup#launch_template_id}
        */
        readonly launchTemplateId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#launch_template_name AwsGroup#launch_template_name}
        */
        readonly launchTemplateName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#version AwsGroup#version}
        */
        readonly version?: string;
    }
    class MixedInstancesPolicyLaunchTemplateOverrideLaunchTemplateSpecificationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): MixedInstancesPolicyLaunchTemplateOverrideLaunchTemplateSpecificationProperty | undefined;
        set internalValue(value: MixedInstancesPolicyLaunchTemplateOverrideLaunchTemplateSpecificationProperty | undefined);
        private _launchTemplateId?;
        get launchTemplateId(): string;
        set launchTemplateId(value: string);
        resetLaunchTemplateId(): void;
        get launchTemplateIdInput(): string | undefined;
        private _launchTemplateName?;
        get launchTemplateName(): string;
        set launchTemplateName(value: string);
        resetLaunchTemplateName(): void;
        get launchTemplateNameInput(): string | undefined;
        private _version?;
        get version(): string;
        set version(value: string);
        resetVersion(): void;
        get versionInput(): string | undefined;
    }
    interface OverrideProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#instance_type AwsGroup#instance_type}
        */
        readonly instanceType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#weighted_capacity AwsGroup#weighted_capacity}
        */
        readonly weightedCapacity?: string;
        /**
        * instance_requirements block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#instance_requirements AwsGroup#instance_requirements}
        */
        readonly instanceRequirements?: InstanceRequirementsProperty;
        /**
        * launch_template_specification block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#launch_template_specification AwsGroup#launch_template_specification}
        */
        readonly launchTemplateSpecification?: MixedInstancesPolicyLaunchTemplateOverrideLaunchTemplateSpecificationProperty;
    }
    class OverridePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): OverrideProperty | cdktn.IResolvable | undefined;
        set internalValue(value: OverrideProperty | cdktn.IResolvable | undefined);
        private _instanceType?;
        get instanceType(): string;
        set instanceType(value: string);
        resetInstanceType(): void;
        get instanceTypeInput(): string | undefined;
        private _weightedCapacity?;
        get weightedCapacity(): string;
        set weightedCapacity(value: string);
        resetWeightedCapacity(): void;
        get weightedCapacityInput(): string | undefined;
        private _instanceRequirements;
        get instanceRequirements(): InstanceRequirementsPropertyOutputReference;
        putInstanceRequirements(value: InstanceRequirementsProperty): void;
        resetInstanceRequirements(): void;
        get instanceRequirementsInput(): InstanceRequirementsProperty | undefined;
        private _launchTemplateSpecification;
        get launchTemplateSpecification(): MixedInstancesPolicyLaunchTemplateOverrideLaunchTemplateSpecificationPropertyOutputReference;
        putLaunchTemplateSpecification(value: MixedInstancesPolicyLaunchTemplateOverrideLaunchTemplateSpecificationProperty): void;
        resetLaunchTemplateSpecification(): void;
        get launchTemplateSpecificationInput(): MixedInstancesPolicyLaunchTemplateOverrideLaunchTemplateSpecificationProperty | undefined;
    }
    class OverridePropertyList extends cdktn.ComplexList {
        internalValue?: OverrideProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): OverridePropertyOutputReference;
    }
    interface MixedInstancesPolicyLaunchTemplateProperty {
        /**
        * launch_template_specification block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#launch_template_specification AwsGroup#launch_template_specification}
        */
        readonly launchTemplateSpecification: MixedInstancesPolicyLaunchTemplateLaunchTemplateSpecificationProperty;
        /**
        * override block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#override AwsGroup#override}
        */
        readonly override?: OverrideProperty[] | cdktn.IResolvable;
    }
    class MixedInstancesPolicyLaunchTemplatePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): MixedInstancesPolicyLaunchTemplateProperty | undefined;
        set internalValue(value: MixedInstancesPolicyLaunchTemplateProperty | undefined);
        private _launchTemplateSpecification;
        get launchTemplateSpecification(): MixedInstancesPolicyLaunchTemplateLaunchTemplateSpecificationPropertyOutputReference;
        putLaunchTemplateSpecification(value: MixedInstancesPolicyLaunchTemplateLaunchTemplateSpecificationProperty): void;
        get launchTemplateSpecificationInput(): MixedInstancesPolicyLaunchTemplateLaunchTemplateSpecificationProperty | undefined;
        private _override;
        get override(): OverridePropertyList;
        putOverride(value: OverrideProperty[] | cdktn.IResolvable): void;
        resetOverride(): void;
        get overrideInput(): cdktn.IResolvable | OverrideProperty[] | undefined;
    }
    interface MixedInstancesPolicyProperty {
        /**
        * instances_distribution block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#instances_distribution AwsGroup#instances_distribution}
        */
        readonly instancesDistribution?: InstancesDistributionProperty;
        /**
        * launch_template block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#launch_template AwsGroup#launch_template}
        */
        readonly launchTemplate: MixedInstancesPolicyLaunchTemplateProperty;
    }
    class MixedInstancesPolicyPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): MixedInstancesPolicyProperty | undefined;
        set internalValue(value: MixedInstancesPolicyProperty | undefined);
        private _instancesDistribution;
        get instancesDistribution(): InstancesDistributionPropertyOutputReference;
        putInstancesDistribution(value: InstancesDistributionProperty): void;
        resetInstancesDistribution(): void;
        get instancesDistributionInput(): InstancesDistributionProperty | undefined;
        private _launchTemplate;
        get launchTemplate(): MixedInstancesPolicyLaunchTemplatePropertyOutputReference;
        putLaunchTemplate(value: MixedInstancesPolicyLaunchTemplateProperty): void;
        get launchTemplateInput(): MixedInstancesPolicyLaunchTemplateProperty | undefined;
    }
    interface TagProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#key AwsGroup#key}
        */
        readonly key: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#propagate_at_launch AwsGroup#propagate_at_launch}
        */
        readonly propagateAtLaunch: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#value AwsGroup#value}
        */
        readonly value: string;
    }
    class TagPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TagProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TagProperty | cdktn.IResolvable | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        get keyInput(): string | undefined;
        private _propagateAtLaunch?;
        get propagateAtLaunch(): boolean | cdktn.IResolvable;
        set propagateAtLaunch(value: boolean | cdktn.IResolvable);
        get propagateAtLaunchInput(): boolean | cdktn.IResolvable | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class TagPropertyList extends cdktn.ComplexList {
        internalValue?: TagProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TagPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#delete AwsGroup#delete}
        */
        readonly delete?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#update AwsGroup#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
    interface TrafficSourceProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#identifier AwsGroup#identifier}
        */
        readonly identifier: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#type AwsGroup#type}
        */
        readonly type?: string;
    }
    class TrafficSourcePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TrafficSourceProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TrafficSourceProperty | cdktn.IResolvable | undefined);
        private _identifier?;
        get identifier(): string;
        set identifier(value: string);
        get identifierInput(): string | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        resetType(): void;
        get typeInput(): string | undefined;
    }
    class TrafficSourcePropertyList extends cdktn.ComplexList {
        internalValue?: TrafficSourceProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TrafficSourcePropertyOutputReference;
    }
    interface InstanceReusePolicyProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#reuse_on_scale_in AwsGroup#reuse_on_scale_in}
        */
        readonly reuseOnScaleIn?: boolean | cdktn.IResolvable;
    }
    class InstanceReusePolicyPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): InstanceReusePolicyProperty | undefined;
        set internalValue(value: InstanceReusePolicyProperty | undefined);
        private _reuseOnScaleIn?;
        get reuseOnScaleIn(): boolean | cdktn.IResolvable;
        set reuseOnScaleIn(value: boolean | cdktn.IResolvable);
        resetReuseOnScaleIn(): void;
        get reuseOnScaleInInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface WarmPoolProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#max_group_prepared_capacity AwsGroup#max_group_prepared_capacity}
        */
        readonly maxGroupPreparedCapacity?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#min_size AwsGroup#min_size}
        */
        readonly minSize?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#pool_state AwsGroup#pool_state}
        */
        readonly poolState?: string;
        /**
        * instance_reuse_policy block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#instance_reuse_policy AwsGroup#instance_reuse_policy}
        */
        readonly instanceReusePolicy?: InstanceReusePolicyProperty;
    }
    class WarmPoolPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): WarmPoolProperty | undefined;
        set internalValue(value: WarmPoolProperty | undefined);
        private _maxGroupPreparedCapacity?;
        get maxGroupPreparedCapacity(): number;
        set maxGroupPreparedCapacity(value: number);
        resetMaxGroupPreparedCapacity(): void;
        get maxGroupPreparedCapacityInput(): number | undefined;
        private _minSize?;
        get minSize(): number;
        set minSize(value: number);
        resetMinSize(): void;
        get minSizeInput(): number | undefined;
        private _poolState?;
        get poolState(): string;
        set poolState(value: string);
        resetPoolState(): void;
        get poolStateInput(): string | undefined;
        private _instanceReusePolicy;
        get instanceReusePolicy(): InstanceReusePolicyPropertyOutputReference;
        putInstanceReusePolicy(value: InstanceReusePolicyProperty): void;
        resetInstanceReusePolicy(): void;
        get instanceReusePolicyInput(): InstanceReusePolicyProperty | undefined;
    }
}
