import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsPolicyConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#adjustment_type AwsPolicy#adjustment_type}
    */
    readonly adjustmentType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#autoscaling_group_name AwsPolicy#autoscaling_group_name}
    */
    readonly autoscalingGroupName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#cooldown AwsPolicy#cooldown}
    */
    readonly cooldown?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#enabled AwsPolicy#enabled}
    */
    readonly enabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#estimated_instance_warmup AwsPolicy#estimated_instance_warmup}
    */
    readonly estimatedInstanceWarmup?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#id AwsPolicy#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#metric_aggregation_type AwsPolicy#metric_aggregation_type}
    */
    readonly metricAggregationType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#min_adjustment_magnitude AwsPolicy#min_adjustment_magnitude}
    */
    readonly minAdjustmentMagnitude?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#name AwsPolicy#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#policy_type AwsPolicy#policy_type}
    */
    readonly policyType?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#region AwsPolicy#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#scaling_adjustment AwsPolicy#scaling_adjustment}
    */
    readonly scalingAdjustment?: number;
    /**
    * predictive_scaling_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#predictive_scaling_configuration AwsPolicy#predictive_scaling_configuration}
    */
    readonly predictiveScalingConfiguration?: AwsPolicy.PredictiveScalingConfigurationProperty;
    /**
    * step_adjustment block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#step_adjustment AwsPolicy#step_adjustment}
    */
    readonly stepAdjustment?: AwsPolicy.StepAdjustmentProperty[] | cdktn.IResolvable;
    /**
    * target_tracking_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#target_tracking_configuration AwsPolicy#target_tracking_configuration}
    */
    readonly targetTrackingConfiguration?: AwsPolicy.TargetTrackingConfigurationProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy aws_autoscaling_policy}
*/
export declare class AwsPolicy extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_autoscaling_policy";
    /**
    * Generates CDKTN code for importing a AwsPolicy resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsPolicy to import
    * @param importFromId The id of the existing AwsPolicy that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsPolicy to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy aws_autoscaling_policy} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsPolicyConfig
    */
    constructor(scope: Construct, id: string, config: AwsPolicyConfig);
    private _adjustmentType?;
    get adjustmentType(): string;
    set adjustmentType(value: string);
    resetAdjustmentType(): void;
    get adjustmentTypeInput(): string | undefined;
    get arn(): string;
    private _autoscalingGroupName?;
    get autoscalingGroupName(): string;
    set autoscalingGroupName(value: string);
    get autoscalingGroupNameInput(): string | undefined;
    private _cooldown?;
    get cooldown(): number;
    set cooldown(value: number);
    resetCooldown(): void;
    get cooldownInput(): number | undefined;
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    private _estimatedInstanceWarmup?;
    get estimatedInstanceWarmup(): number;
    set estimatedInstanceWarmup(value: number);
    resetEstimatedInstanceWarmup(): void;
    get estimatedInstanceWarmupInput(): number | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _metricAggregationType?;
    get metricAggregationType(): string;
    set metricAggregationType(value: string);
    resetMetricAggregationType(): void;
    get metricAggregationTypeInput(): string | undefined;
    private _minAdjustmentMagnitude?;
    get minAdjustmentMagnitude(): number;
    set minAdjustmentMagnitude(value: number);
    resetMinAdjustmentMagnitude(): void;
    get minAdjustmentMagnitudeInput(): number | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _policyType?;
    get policyType(): string;
    set policyType(value: string);
    resetPolicyType(): void;
    get policyTypeInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _scalingAdjustment?;
    get scalingAdjustment(): number;
    set scalingAdjustment(value: number);
    resetScalingAdjustment(): void;
    get scalingAdjustmentInput(): number | undefined;
    private _predictiveScalingConfiguration;
    get predictiveScalingConfiguration(): AwsPolicy.PredictiveScalingConfigurationPropertyOutputReference;
    putPredictiveScalingConfiguration(value: AwsPolicy.PredictiveScalingConfigurationProperty): void;
    resetPredictiveScalingConfiguration(): void;
    get predictiveScalingConfigurationInput(): AwsPolicy.PredictiveScalingConfigurationProperty | undefined;
    private _stepAdjustment;
    get stepAdjustment(): AwsPolicy.StepAdjustmentPropertyList;
    putStepAdjustment(value: AwsPolicy.StepAdjustmentProperty[] | cdktn.IResolvable): void;
    resetStepAdjustment(): void;
    get stepAdjustmentInput(): cdktn.IResolvable | AwsPolicy.StepAdjustmentProperty[] | undefined;
    private _targetTrackingConfiguration;
    get targetTrackingConfiguration(): AwsPolicy.TargetTrackingConfigurationPropertyOutputReference;
    putTargetTrackingConfiguration(value: AwsPolicy.TargetTrackingConfigurationProperty): void;
    resetTargetTrackingConfiguration(): void;
    get targetTrackingConfigurationInput(): AwsPolicy.TargetTrackingConfigurationProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsPolicyPredictiveScalingConfigurationMetricSpecificationCustomizedCapacityMetricSpecificationMetricDataQueriesMetricStatMetricDimensionsPropertyToTerraform(struct?: AwsPolicy.PredictiveScalingConfigurationMetricSpecificationCustomizedCapacityMetricSpecificationMetricDataQueriesMetricStatMetricDimensionsProperty | cdktn.IResolvable): any;
export declare function awsPolicyPredictiveScalingConfigurationMetricSpecificationCustomizedCapacityMetricSpecificationMetricDataQueriesMetricStatMetricDimensionsPropertyToHclTerraform(struct?: AwsPolicy.PredictiveScalingConfigurationMetricSpecificationCustomizedCapacityMetricSpecificationMetricDataQueriesMetricStatMetricDimensionsProperty | cdktn.IResolvable): any;
export declare function awsPolicyPredictiveScalingConfigurationMetricSpecificationCustomizedCapacityMetricSpecificationMetricDataQueriesMetricStatMetricPropertyToTerraform(struct?: AwsPolicy.PredictiveScalingConfigurationMetricSpecificationCustomizedCapacityMetricSpecificationMetricDataQueriesMetricStatMetricPropertyOutputReference | AwsPolicy.PredictiveScalingConfigurationMetricSpecificationCustomizedCapacityMetricSpecificationMetricDataQueriesMetricStatMetricProperty): any;
export declare function awsPolicyPredictiveScalingConfigurationMetricSpecificationCustomizedCapacityMetricSpecificationMetricDataQueriesMetricStatMetricPropertyToHclTerraform(struct?: AwsPolicy.PredictiveScalingConfigurationMetricSpecificationCustomizedCapacityMetricSpecificationMetricDataQueriesMetricStatMetricPropertyOutputReference | AwsPolicy.PredictiveScalingConfigurationMetricSpecificationCustomizedCapacityMetricSpecificationMetricDataQueriesMetricStatMetricProperty): any;
export declare function awsPolicyPredictiveScalingConfigurationMetricSpecificationCustomizedCapacityMetricSpecificationMetricDataQueriesMetricStatPropertyToTerraform(struct?: AwsPolicy.PredictiveScalingConfigurationMetricSpecificationCustomizedCapacityMetricSpecificationMetricDataQueriesMetricStatPropertyOutputReference | AwsPolicy.PredictiveScalingConfigurationMetricSpecificationCustomizedCapacityMetricSpecificationMetricDataQueriesMetricStatProperty): any;
export declare function awsPolicyPredictiveScalingConfigurationMetricSpecificationCustomizedCapacityMetricSpecificationMetricDataQueriesMetricStatPropertyToHclTerraform(struct?: AwsPolicy.PredictiveScalingConfigurationMetricSpecificationCustomizedCapacityMetricSpecificationMetricDataQueriesMetricStatPropertyOutputReference | AwsPolicy.PredictiveScalingConfigurationMetricSpecificationCustomizedCapacityMetricSpecificationMetricDataQueriesMetricStatProperty): any;
export declare function awsPolicyPredictiveScalingConfigurationMetricSpecificationCustomizedCapacityMetricSpecificationMetricDataQueriesPropertyToTerraform(struct?: AwsPolicy.PredictiveScalingConfigurationMetricSpecificationCustomizedCapacityMetricSpecificationMetricDataQueriesProperty | cdktn.IResolvable): any;
export declare function awsPolicyPredictiveScalingConfigurationMetricSpecificationCustomizedCapacityMetricSpecificationMetricDataQueriesPropertyToHclTerraform(struct?: AwsPolicy.PredictiveScalingConfigurationMetricSpecificationCustomizedCapacityMetricSpecificationMetricDataQueriesProperty | cdktn.IResolvable): any;
export declare function awsPolicyCustomizedCapacityMetricSpecificationPropertyToTerraform(struct?: AwsPolicy.CustomizedCapacityMetricSpecificationPropertyOutputReference | AwsPolicy.CustomizedCapacityMetricSpecificationProperty): any;
export declare function awsPolicyCustomizedCapacityMetricSpecificationPropertyToHclTerraform(struct?: AwsPolicy.CustomizedCapacityMetricSpecificationPropertyOutputReference | AwsPolicy.CustomizedCapacityMetricSpecificationProperty): any;
export declare function awsPolicyPredictiveScalingConfigurationMetricSpecificationCustomizedLoadMetricSpecificationMetricDataQueriesMetricStatMetricDimensionsPropertyToTerraform(struct?: AwsPolicy.PredictiveScalingConfigurationMetricSpecificationCustomizedLoadMetricSpecificationMetricDataQueriesMetricStatMetricDimensionsProperty | cdktn.IResolvable): any;
export declare function awsPolicyPredictiveScalingConfigurationMetricSpecificationCustomizedLoadMetricSpecificationMetricDataQueriesMetricStatMetricDimensionsPropertyToHclTerraform(struct?: AwsPolicy.PredictiveScalingConfigurationMetricSpecificationCustomizedLoadMetricSpecificationMetricDataQueriesMetricStatMetricDimensionsProperty | cdktn.IResolvable): any;
export declare function awsPolicyPredictiveScalingConfigurationMetricSpecificationCustomizedLoadMetricSpecificationMetricDataQueriesMetricStatMetricPropertyToTerraform(struct?: AwsPolicy.PredictiveScalingConfigurationMetricSpecificationCustomizedLoadMetricSpecificationMetricDataQueriesMetricStatMetricPropertyOutputReference | AwsPolicy.PredictiveScalingConfigurationMetricSpecificationCustomizedLoadMetricSpecificationMetricDataQueriesMetricStatMetricProperty): any;
export declare function awsPolicyPredictiveScalingConfigurationMetricSpecificationCustomizedLoadMetricSpecificationMetricDataQueriesMetricStatMetricPropertyToHclTerraform(struct?: AwsPolicy.PredictiveScalingConfigurationMetricSpecificationCustomizedLoadMetricSpecificationMetricDataQueriesMetricStatMetricPropertyOutputReference | AwsPolicy.PredictiveScalingConfigurationMetricSpecificationCustomizedLoadMetricSpecificationMetricDataQueriesMetricStatMetricProperty): any;
export declare function awsPolicyPredictiveScalingConfigurationMetricSpecificationCustomizedLoadMetricSpecificationMetricDataQueriesMetricStatPropertyToTerraform(struct?: AwsPolicy.PredictiveScalingConfigurationMetricSpecificationCustomizedLoadMetricSpecificationMetricDataQueriesMetricStatPropertyOutputReference | AwsPolicy.PredictiveScalingConfigurationMetricSpecificationCustomizedLoadMetricSpecificationMetricDataQueriesMetricStatProperty): any;
export declare function awsPolicyPredictiveScalingConfigurationMetricSpecificationCustomizedLoadMetricSpecificationMetricDataQueriesMetricStatPropertyToHclTerraform(struct?: AwsPolicy.PredictiveScalingConfigurationMetricSpecificationCustomizedLoadMetricSpecificationMetricDataQueriesMetricStatPropertyOutputReference | AwsPolicy.PredictiveScalingConfigurationMetricSpecificationCustomizedLoadMetricSpecificationMetricDataQueriesMetricStatProperty): any;
export declare function awsPolicyPredictiveScalingConfigurationMetricSpecificationCustomizedLoadMetricSpecificationMetricDataQueriesPropertyToTerraform(struct?: AwsPolicy.PredictiveScalingConfigurationMetricSpecificationCustomizedLoadMetricSpecificationMetricDataQueriesProperty | cdktn.IResolvable): any;
export declare function awsPolicyPredictiveScalingConfigurationMetricSpecificationCustomizedLoadMetricSpecificationMetricDataQueriesPropertyToHclTerraform(struct?: AwsPolicy.PredictiveScalingConfigurationMetricSpecificationCustomizedLoadMetricSpecificationMetricDataQueriesProperty | cdktn.IResolvable): any;
export declare function awsPolicyCustomizedLoadMetricSpecificationPropertyToTerraform(struct?: AwsPolicy.CustomizedLoadMetricSpecificationPropertyOutputReference | AwsPolicy.CustomizedLoadMetricSpecificationProperty): any;
export declare function awsPolicyCustomizedLoadMetricSpecificationPropertyToHclTerraform(struct?: AwsPolicy.CustomizedLoadMetricSpecificationPropertyOutputReference | AwsPolicy.CustomizedLoadMetricSpecificationProperty): any;
export declare function awsPolicyPredictiveScalingConfigurationMetricSpecificationCustomizedScalingMetricSpecificationMetricDataQueriesMetricStatMetricDimensionsPropertyToTerraform(struct?: AwsPolicy.PredictiveScalingConfigurationMetricSpecificationCustomizedScalingMetricSpecificationMetricDataQueriesMetricStatMetricDimensionsProperty | cdktn.IResolvable): any;
export declare function awsPolicyPredictiveScalingConfigurationMetricSpecificationCustomizedScalingMetricSpecificationMetricDataQueriesMetricStatMetricDimensionsPropertyToHclTerraform(struct?: AwsPolicy.PredictiveScalingConfigurationMetricSpecificationCustomizedScalingMetricSpecificationMetricDataQueriesMetricStatMetricDimensionsProperty | cdktn.IResolvable): any;
export declare function awsPolicyPredictiveScalingConfigurationMetricSpecificationCustomizedScalingMetricSpecificationMetricDataQueriesMetricStatMetricPropertyToTerraform(struct?: AwsPolicy.PredictiveScalingConfigurationMetricSpecificationCustomizedScalingMetricSpecificationMetricDataQueriesMetricStatMetricPropertyOutputReference | AwsPolicy.PredictiveScalingConfigurationMetricSpecificationCustomizedScalingMetricSpecificationMetricDataQueriesMetricStatMetricProperty): any;
export declare function awsPolicyPredictiveScalingConfigurationMetricSpecificationCustomizedScalingMetricSpecificationMetricDataQueriesMetricStatMetricPropertyToHclTerraform(struct?: AwsPolicy.PredictiveScalingConfigurationMetricSpecificationCustomizedScalingMetricSpecificationMetricDataQueriesMetricStatMetricPropertyOutputReference | AwsPolicy.PredictiveScalingConfigurationMetricSpecificationCustomizedScalingMetricSpecificationMetricDataQueriesMetricStatMetricProperty): any;
export declare function awsPolicyPredictiveScalingConfigurationMetricSpecificationCustomizedScalingMetricSpecificationMetricDataQueriesMetricStatPropertyToTerraform(struct?: AwsPolicy.PredictiveScalingConfigurationMetricSpecificationCustomizedScalingMetricSpecificationMetricDataQueriesMetricStatPropertyOutputReference | AwsPolicy.PredictiveScalingConfigurationMetricSpecificationCustomizedScalingMetricSpecificationMetricDataQueriesMetricStatProperty): any;
export declare function awsPolicyPredictiveScalingConfigurationMetricSpecificationCustomizedScalingMetricSpecificationMetricDataQueriesMetricStatPropertyToHclTerraform(struct?: AwsPolicy.PredictiveScalingConfigurationMetricSpecificationCustomizedScalingMetricSpecificationMetricDataQueriesMetricStatPropertyOutputReference | AwsPolicy.PredictiveScalingConfigurationMetricSpecificationCustomizedScalingMetricSpecificationMetricDataQueriesMetricStatProperty): any;
export declare function awsPolicyPredictiveScalingConfigurationMetricSpecificationCustomizedScalingMetricSpecificationMetricDataQueriesPropertyToTerraform(struct?: AwsPolicy.PredictiveScalingConfigurationMetricSpecificationCustomizedScalingMetricSpecificationMetricDataQueriesProperty | cdktn.IResolvable): any;
export declare function awsPolicyPredictiveScalingConfigurationMetricSpecificationCustomizedScalingMetricSpecificationMetricDataQueriesPropertyToHclTerraform(struct?: AwsPolicy.PredictiveScalingConfigurationMetricSpecificationCustomizedScalingMetricSpecificationMetricDataQueriesProperty | cdktn.IResolvable): any;
export declare function awsPolicyCustomizedScalingMetricSpecificationPropertyToTerraform(struct?: AwsPolicy.CustomizedScalingMetricSpecificationPropertyOutputReference | AwsPolicy.CustomizedScalingMetricSpecificationProperty): any;
export declare function awsPolicyCustomizedScalingMetricSpecificationPropertyToHclTerraform(struct?: AwsPolicy.CustomizedScalingMetricSpecificationPropertyOutputReference | AwsPolicy.CustomizedScalingMetricSpecificationProperty): any;
export declare function awsPolicyPredefinedLoadMetricSpecificationPropertyToTerraform(struct?: AwsPolicy.PredefinedLoadMetricSpecificationPropertyOutputReference | AwsPolicy.PredefinedLoadMetricSpecificationProperty): any;
export declare function awsPolicyPredefinedLoadMetricSpecificationPropertyToHclTerraform(struct?: AwsPolicy.PredefinedLoadMetricSpecificationPropertyOutputReference | AwsPolicy.PredefinedLoadMetricSpecificationProperty): any;
export declare function awsPolicyPredefinedMetricPairSpecificationPropertyToTerraform(struct?: AwsPolicy.PredefinedMetricPairSpecificationPropertyOutputReference | AwsPolicy.PredefinedMetricPairSpecificationProperty): any;
export declare function awsPolicyPredefinedMetricPairSpecificationPropertyToHclTerraform(struct?: AwsPolicy.PredefinedMetricPairSpecificationPropertyOutputReference | AwsPolicy.PredefinedMetricPairSpecificationProperty): any;
export declare function awsPolicyPredefinedScalingMetricSpecificationPropertyToTerraform(struct?: AwsPolicy.PredefinedScalingMetricSpecificationPropertyOutputReference | AwsPolicy.PredefinedScalingMetricSpecificationProperty): any;
export declare function awsPolicyPredefinedScalingMetricSpecificationPropertyToHclTerraform(struct?: AwsPolicy.PredefinedScalingMetricSpecificationPropertyOutputReference | AwsPolicy.PredefinedScalingMetricSpecificationProperty): any;
export declare function awsPolicyMetricSpecificationPropertyToTerraform(struct?: AwsPolicy.MetricSpecificationPropertyOutputReference | AwsPolicy.MetricSpecificationProperty): any;
export declare function awsPolicyMetricSpecificationPropertyToHclTerraform(struct?: AwsPolicy.MetricSpecificationPropertyOutputReference | AwsPolicy.MetricSpecificationProperty): any;
export declare function awsPolicyPredictiveScalingConfigurationPropertyToTerraform(struct?: AwsPolicy.PredictiveScalingConfigurationPropertyOutputReference | AwsPolicy.PredictiveScalingConfigurationProperty): any;
export declare function awsPolicyPredictiveScalingConfigurationPropertyToHclTerraform(struct?: AwsPolicy.PredictiveScalingConfigurationPropertyOutputReference | AwsPolicy.PredictiveScalingConfigurationProperty): any;
export declare function awsPolicyStepAdjustmentPropertyToTerraform(struct?: AwsPolicy.StepAdjustmentProperty | cdktn.IResolvable): any;
export declare function awsPolicyStepAdjustmentPropertyToHclTerraform(struct?: AwsPolicy.StepAdjustmentProperty | cdktn.IResolvable): any;
export declare function awsPolicyMetricDimensionPropertyToTerraform(struct?: AwsPolicy.MetricDimensionProperty | cdktn.IResolvable): any;
export declare function awsPolicyMetricDimensionPropertyToHclTerraform(struct?: AwsPolicy.MetricDimensionProperty | cdktn.IResolvable): any;
export declare function awsPolicyTargetTrackingConfigurationCustomizedMetricSpecificationMetricsMetricStatMetricDimensionsPropertyToTerraform(struct?: AwsPolicy.TargetTrackingConfigurationCustomizedMetricSpecificationMetricsMetricStatMetricDimensionsProperty | cdktn.IResolvable): any;
export declare function awsPolicyTargetTrackingConfigurationCustomizedMetricSpecificationMetricsMetricStatMetricDimensionsPropertyToHclTerraform(struct?: AwsPolicy.TargetTrackingConfigurationCustomizedMetricSpecificationMetricsMetricStatMetricDimensionsProperty | cdktn.IResolvable): any;
export declare function awsPolicyTargetTrackingConfigurationCustomizedMetricSpecificationMetricsMetricStatMetricPropertyToTerraform(struct?: AwsPolicy.TargetTrackingConfigurationCustomizedMetricSpecificationMetricsMetricStatMetricPropertyOutputReference | AwsPolicy.TargetTrackingConfigurationCustomizedMetricSpecificationMetricsMetricStatMetricProperty): any;
export declare function awsPolicyTargetTrackingConfigurationCustomizedMetricSpecificationMetricsMetricStatMetricPropertyToHclTerraform(struct?: AwsPolicy.TargetTrackingConfigurationCustomizedMetricSpecificationMetricsMetricStatMetricPropertyOutputReference | AwsPolicy.TargetTrackingConfigurationCustomizedMetricSpecificationMetricsMetricStatMetricProperty): any;
export declare function awsPolicyTargetTrackingConfigurationCustomizedMetricSpecificationMetricsMetricStatPropertyToTerraform(struct?: AwsPolicy.TargetTrackingConfigurationCustomizedMetricSpecificationMetricsMetricStatPropertyOutputReference | AwsPolicy.TargetTrackingConfigurationCustomizedMetricSpecificationMetricsMetricStatProperty): any;
export declare function awsPolicyTargetTrackingConfigurationCustomizedMetricSpecificationMetricsMetricStatPropertyToHclTerraform(struct?: AwsPolicy.TargetTrackingConfigurationCustomizedMetricSpecificationMetricsMetricStatPropertyOutputReference | AwsPolicy.TargetTrackingConfigurationCustomizedMetricSpecificationMetricsMetricStatProperty): any;
export declare function awsPolicyMetricsPropertyToTerraform(struct?: AwsPolicy.MetricsProperty | cdktn.IResolvable): any;
export declare function awsPolicyMetricsPropertyToHclTerraform(struct?: AwsPolicy.MetricsProperty | cdktn.IResolvable): any;
export declare function awsPolicyCustomizedMetricSpecificationPropertyToTerraform(struct?: AwsPolicy.CustomizedMetricSpecificationPropertyOutputReference | AwsPolicy.CustomizedMetricSpecificationProperty): any;
export declare function awsPolicyCustomizedMetricSpecificationPropertyToHclTerraform(struct?: AwsPolicy.CustomizedMetricSpecificationPropertyOutputReference | AwsPolicy.CustomizedMetricSpecificationProperty): any;
export declare function awsPolicyPredefinedMetricSpecificationPropertyToTerraform(struct?: AwsPolicy.PredefinedMetricSpecificationPropertyOutputReference | AwsPolicy.PredefinedMetricSpecificationProperty): any;
export declare function awsPolicyPredefinedMetricSpecificationPropertyToHclTerraform(struct?: AwsPolicy.PredefinedMetricSpecificationPropertyOutputReference | AwsPolicy.PredefinedMetricSpecificationProperty): any;
export declare function awsPolicyTargetTrackingConfigurationPropertyToTerraform(struct?: AwsPolicy.TargetTrackingConfigurationPropertyOutputReference | AwsPolicy.TargetTrackingConfigurationProperty): any;
export declare function awsPolicyTargetTrackingConfigurationPropertyToHclTerraform(struct?: AwsPolicy.TargetTrackingConfigurationPropertyOutputReference | AwsPolicy.TargetTrackingConfigurationProperty): any;
export declare namespace AwsPolicy {
    interface PredictiveScalingConfigurationMetricSpecificationCustomizedCapacityMetricSpecificationMetricDataQueriesMetricStatMetricDimensionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#name AwsPolicy#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#value AwsPolicy#value}
        */
        readonly value: string;
    }
    class PredictiveScalingConfigurationMetricSpecificationCustomizedCapacityMetricSpecificationMetricDataQueriesMetricStatMetricDimensionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): PredictiveScalingConfigurationMetricSpecificationCustomizedCapacityMetricSpecificationMetricDataQueriesMetricStatMetricDimensionsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: PredictiveScalingConfigurationMetricSpecificationCustomizedCapacityMetricSpecificationMetricDataQueriesMetricStatMetricDimensionsProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class PredictiveScalingConfigurationMetricSpecificationCustomizedCapacityMetricSpecificationMetricDataQueriesMetricStatMetricDimensionsPropertyList extends cdktn.ComplexList {
        internalValue?: PredictiveScalingConfigurationMetricSpecificationCustomizedCapacityMetricSpecificationMetricDataQueriesMetricStatMetricDimensionsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): PredictiveScalingConfigurationMetricSpecificationCustomizedCapacityMetricSpecificationMetricDataQueriesMetricStatMetricDimensionsPropertyOutputReference;
    }
    interface PredictiveScalingConfigurationMetricSpecificationCustomizedCapacityMetricSpecificationMetricDataQueriesMetricStatMetricProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#metric_name AwsPolicy#metric_name}
        */
        readonly metricName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#namespace AwsPolicy#namespace}
        */
        readonly namespace: string;
        /**
        * dimensions block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#dimensions AwsPolicy#dimensions}
        */
        readonly dimensions?: PredictiveScalingConfigurationMetricSpecificationCustomizedCapacityMetricSpecificationMetricDataQueriesMetricStatMetricDimensionsProperty[] | cdktn.IResolvable;
    }
    class PredictiveScalingConfigurationMetricSpecificationCustomizedCapacityMetricSpecificationMetricDataQueriesMetricStatMetricPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): PredictiveScalingConfigurationMetricSpecificationCustomizedCapacityMetricSpecificationMetricDataQueriesMetricStatMetricProperty | undefined;
        set internalValue(value: PredictiveScalingConfigurationMetricSpecificationCustomizedCapacityMetricSpecificationMetricDataQueriesMetricStatMetricProperty | undefined);
        private _metricName?;
        get metricName(): string;
        set metricName(value: string);
        get metricNameInput(): string | undefined;
        private _namespace?;
        get namespace(): string;
        set namespace(value: string);
        get namespaceInput(): string | undefined;
        private _dimensions;
        get dimensions(): PredictiveScalingConfigurationMetricSpecificationCustomizedCapacityMetricSpecificationMetricDataQueriesMetricStatMetricDimensionsPropertyList;
        putDimensions(value: PredictiveScalingConfigurationMetricSpecificationCustomizedCapacityMetricSpecificationMetricDataQueriesMetricStatMetricDimensionsProperty[] | cdktn.IResolvable): void;
        resetDimensions(): void;
        get dimensionsInput(): cdktn.IResolvable | PredictiveScalingConfigurationMetricSpecificationCustomizedCapacityMetricSpecificationMetricDataQueriesMetricStatMetricDimensionsProperty[] | undefined;
    }
    interface PredictiveScalingConfigurationMetricSpecificationCustomizedCapacityMetricSpecificationMetricDataQueriesMetricStatProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#stat AwsPolicy#stat}
        */
        readonly stat: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#unit AwsPolicy#unit}
        */
        readonly unit?: string;
        /**
        * metric block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#metric AwsPolicy#metric}
        */
        readonly metric: PredictiveScalingConfigurationMetricSpecificationCustomizedCapacityMetricSpecificationMetricDataQueriesMetricStatMetricProperty;
    }
    class PredictiveScalingConfigurationMetricSpecificationCustomizedCapacityMetricSpecificationMetricDataQueriesMetricStatPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): PredictiveScalingConfigurationMetricSpecificationCustomizedCapacityMetricSpecificationMetricDataQueriesMetricStatProperty | undefined;
        set internalValue(value: PredictiveScalingConfigurationMetricSpecificationCustomizedCapacityMetricSpecificationMetricDataQueriesMetricStatProperty | undefined);
        private _stat?;
        get stat(): string;
        set stat(value: string);
        get statInput(): string | undefined;
        private _unit?;
        get unit(): string;
        set unit(value: string);
        resetUnit(): void;
        get unitInput(): string | undefined;
        private _metric;
        get metric(): PredictiveScalingConfigurationMetricSpecificationCustomizedCapacityMetricSpecificationMetricDataQueriesMetricStatMetricPropertyOutputReference;
        putMetric(value: PredictiveScalingConfigurationMetricSpecificationCustomizedCapacityMetricSpecificationMetricDataQueriesMetricStatMetricProperty): void;
        get metricInput(): PredictiveScalingConfigurationMetricSpecificationCustomizedCapacityMetricSpecificationMetricDataQueriesMetricStatMetricProperty | undefined;
    }
    interface PredictiveScalingConfigurationMetricSpecificationCustomizedCapacityMetricSpecificationMetricDataQueriesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#expression AwsPolicy#expression}
        */
        readonly expression?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#id AwsPolicy#id}
        *
        * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
        * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
        */
        readonly id: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#label AwsPolicy#label}
        */
        readonly label?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#return_data AwsPolicy#return_data}
        */
        readonly returnData?: boolean | cdktn.IResolvable;
        /**
        * metric_stat block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#metric_stat AwsPolicy#metric_stat}
        */
        readonly metricStat?: PredictiveScalingConfigurationMetricSpecificationCustomizedCapacityMetricSpecificationMetricDataQueriesMetricStatProperty;
    }
    class PredictiveScalingConfigurationMetricSpecificationCustomizedCapacityMetricSpecificationMetricDataQueriesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): PredictiveScalingConfigurationMetricSpecificationCustomizedCapacityMetricSpecificationMetricDataQueriesProperty | cdktn.IResolvable | undefined;
        set internalValue(value: PredictiveScalingConfigurationMetricSpecificationCustomizedCapacityMetricSpecificationMetricDataQueriesProperty | cdktn.IResolvable | undefined);
        private _expression?;
        get expression(): string;
        set expression(value: string);
        resetExpression(): void;
        get expressionInput(): string | undefined;
        private _id?;
        get id(): string;
        set id(value: string);
        get idInput(): string | undefined;
        private _label?;
        get label(): string;
        set label(value: string);
        resetLabel(): void;
        get labelInput(): string | undefined;
        private _returnData?;
        get returnData(): boolean | cdktn.IResolvable;
        set returnData(value: boolean | cdktn.IResolvable);
        resetReturnData(): void;
        get returnDataInput(): boolean | cdktn.IResolvable | undefined;
        private _metricStat;
        get metricStat(): PredictiveScalingConfigurationMetricSpecificationCustomizedCapacityMetricSpecificationMetricDataQueriesMetricStatPropertyOutputReference;
        putMetricStat(value: PredictiveScalingConfigurationMetricSpecificationCustomizedCapacityMetricSpecificationMetricDataQueriesMetricStatProperty): void;
        resetMetricStat(): void;
        get metricStatInput(): PredictiveScalingConfigurationMetricSpecificationCustomizedCapacityMetricSpecificationMetricDataQueriesMetricStatProperty | undefined;
    }
    class PredictiveScalingConfigurationMetricSpecificationCustomizedCapacityMetricSpecificationMetricDataQueriesPropertyList extends cdktn.ComplexList {
        internalValue?: PredictiveScalingConfigurationMetricSpecificationCustomizedCapacityMetricSpecificationMetricDataQueriesProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): PredictiveScalingConfigurationMetricSpecificationCustomizedCapacityMetricSpecificationMetricDataQueriesPropertyOutputReference;
    }
    interface CustomizedCapacityMetricSpecificationProperty {
        /**
        * metric_data_queries block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#metric_data_queries AwsPolicy#metric_data_queries}
        */
        readonly metricDataQueries: PredictiveScalingConfigurationMetricSpecificationCustomizedCapacityMetricSpecificationMetricDataQueriesProperty[] | cdktn.IResolvable;
    }
    class CustomizedCapacityMetricSpecificationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CustomizedCapacityMetricSpecificationProperty | undefined;
        set internalValue(value: CustomizedCapacityMetricSpecificationProperty | undefined);
        private _metricDataQueries;
        get metricDataQueries(): PredictiveScalingConfigurationMetricSpecificationCustomizedCapacityMetricSpecificationMetricDataQueriesPropertyList;
        putMetricDataQueries(value: PredictiveScalingConfigurationMetricSpecificationCustomizedCapacityMetricSpecificationMetricDataQueriesProperty[] | cdktn.IResolvable): void;
        get metricDataQueriesInput(): cdktn.IResolvable | PredictiveScalingConfigurationMetricSpecificationCustomizedCapacityMetricSpecificationMetricDataQueriesProperty[] | undefined;
    }
    interface PredictiveScalingConfigurationMetricSpecificationCustomizedLoadMetricSpecificationMetricDataQueriesMetricStatMetricDimensionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#name AwsPolicy#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#value AwsPolicy#value}
        */
        readonly value: string;
    }
    class PredictiveScalingConfigurationMetricSpecificationCustomizedLoadMetricSpecificationMetricDataQueriesMetricStatMetricDimensionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): PredictiveScalingConfigurationMetricSpecificationCustomizedLoadMetricSpecificationMetricDataQueriesMetricStatMetricDimensionsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: PredictiveScalingConfigurationMetricSpecificationCustomizedLoadMetricSpecificationMetricDataQueriesMetricStatMetricDimensionsProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class PredictiveScalingConfigurationMetricSpecificationCustomizedLoadMetricSpecificationMetricDataQueriesMetricStatMetricDimensionsPropertyList extends cdktn.ComplexList {
        internalValue?: PredictiveScalingConfigurationMetricSpecificationCustomizedLoadMetricSpecificationMetricDataQueriesMetricStatMetricDimensionsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): PredictiveScalingConfigurationMetricSpecificationCustomizedLoadMetricSpecificationMetricDataQueriesMetricStatMetricDimensionsPropertyOutputReference;
    }
    interface PredictiveScalingConfigurationMetricSpecificationCustomizedLoadMetricSpecificationMetricDataQueriesMetricStatMetricProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#metric_name AwsPolicy#metric_name}
        */
        readonly metricName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#namespace AwsPolicy#namespace}
        */
        readonly namespace: string;
        /**
        * dimensions block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#dimensions AwsPolicy#dimensions}
        */
        readonly dimensions?: PredictiveScalingConfigurationMetricSpecificationCustomizedLoadMetricSpecificationMetricDataQueriesMetricStatMetricDimensionsProperty[] | cdktn.IResolvable;
    }
    class PredictiveScalingConfigurationMetricSpecificationCustomizedLoadMetricSpecificationMetricDataQueriesMetricStatMetricPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): PredictiveScalingConfigurationMetricSpecificationCustomizedLoadMetricSpecificationMetricDataQueriesMetricStatMetricProperty | undefined;
        set internalValue(value: PredictiveScalingConfigurationMetricSpecificationCustomizedLoadMetricSpecificationMetricDataQueriesMetricStatMetricProperty | undefined);
        private _metricName?;
        get metricName(): string;
        set metricName(value: string);
        get metricNameInput(): string | undefined;
        private _namespace?;
        get namespace(): string;
        set namespace(value: string);
        get namespaceInput(): string | undefined;
        private _dimensions;
        get dimensions(): PredictiveScalingConfigurationMetricSpecificationCustomizedLoadMetricSpecificationMetricDataQueriesMetricStatMetricDimensionsPropertyList;
        putDimensions(value: PredictiveScalingConfigurationMetricSpecificationCustomizedLoadMetricSpecificationMetricDataQueriesMetricStatMetricDimensionsProperty[] | cdktn.IResolvable): void;
        resetDimensions(): void;
        get dimensionsInput(): cdktn.IResolvable | PredictiveScalingConfigurationMetricSpecificationCustomizedLoadMetricSpecificationMetricDataQueriesMetricStatMetricDimensionsProperty[] | undefined;
    }
    interface PredictiveScalingConfigurationMetricSpecificationCustomizedLoadMetricSpecificationMetricDataQueriesMetricStatProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#stat AwsPolicy#stat}
        */
        readonly stat: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#unit AwsPolicy#unit}
        */
        readonly unit?: string;
        /**
        * metric block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#metric AwsPolicy#metric}
        */
        readonly metric: PredictiveScalingConfigurationMetricSpecificationCustomizedLoadMetricSpecificationMetricDataQueriesMetricStatMetricProperty;
    }
    class PredictiveScalingConfigurationMetricSpecificationCustomizedLoadMetricSpecificationMetricDataQueriesMetricStatPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): PredictiveScalingConfigurationMetricSpecificationCustomizedLoadMetricSpecificationMetricDataQueriesMetricStatProperty | undefined;
        set internalValue(value: PredictiveScalingConfigurationMetricSpecificationCustomizedLoadMetricSpecificationMetricDataQueriesMetricStatProperty | undefined);
        private _stat?;
        get stat(): string;
        set stat(value: string);
        get statInput(): string | undefined;
        private _unit?;
        get unit(): string;
        set unit(value: string);
        resetUnit(): void;
        get unitInput(): string | undefined;
        private _metric;
        get metric(): PredictiveScalingConfigurationMetricSpecificationCustomizedLoadMetricSpecificationMetricDataQueriesMetricStatMetricPropertyOutputReference;
        putMetric(value: PredictiveScalingConfigurationMetricSpecificationCustomizedLoadMetricSpecificationMetricDataQueriesMetricStatMetricProperty): void;
        get metricInput(): PredictiveScalingConfigurationMetricSpecificationCustomizedLoadMetricSpecificationMetricDataQueriesMetricStatMetricProperty | undefined;
    }
    interface PredictiveScalingConfigurationMetricSpecificationCustomizedLoadMetricSpecificationMetricDataQueriesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#expression AwsPolicy#expression}
        */
        readonly expression?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#id AwsPolicy#id}
        *
        * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
        * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
        */
        readonly id: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#label AwsPolicy#label}
        */
        readonly label?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#return_data AwsPolicy#return_data}
        */
        readonly returnData?: boolean | cdktn.IResolvable;
        /**
        * metric_stat block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#metric_stat AwsPolicy#metric_stat}
        */
        readonly metricStat?: PredictiveScalingConfigurationMetricSpecificationCustomizedLoadMetricSpecificationMetricDataQueriesMetricStatProperty;
    }
    class PredictiveScalingConfigurationMetricSpecificationCustomizedLoadMetricSpecificationMetricDataQueriesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): PredictiveScalingConfigurationMetricSpecificationCustomizedLoadMetricSpecificationMetricDataQueriesProperty | cdktn.IResolvable | undefined;
        set internalValue(value: PredictiveScalingConfigurationMetricSpecificationCustomizedLoadMetricSpecificationMetricDataQueriesProperty | cdktn.IResolvable | undefined);
        private _expression?;
        get expression(): string;
        set expression(value: string);
        resetExpression(): void;
        get expressionInput(): string | undefined;
        private _id?;
        get id(): string;
        set id(value: string);
        get idInput(): string | undefined;
        private _label?;
        get label(): string;
        set label(value: string);
        resetLabel(): void;
        get labelInput(): string | undefined;
        private _returnData?;
        get returnData(): boolean | cdktn.IResolvable;
        set returnData(value: boolean | cdktn.IResolvable);
        resetReturnData(): void;
        get returnDataInput(): boolean | cdktn.IResolvable | undefined;
        private _metricStat;
        get metricStat(): PredictiveScalingConfigurationMetricSpecificationCustomizedLoadMetricSpecificationMetricDataQueriesMetricStatPropertyOutputReference;
        putMetricStat(value: PredictiveScalingConfigurationMetricSpecificationCustomizedLoadMetricSpecificationMetricDataQueriesMetricStatProperty): void;
        resetMetricStat(): void;
        get metricStatInput(): PredictiveScalingConfigurationMetricSpecificationCustomizedLoadMetricSpecificationMetricDataQueriesMetricStatProperty | undefined;
    }
    class PredictiveScalingConfigurationMetricSpecificationCustomizedLoadMetricSpecificationMetricDataQueriesPropertyList extends cdktn.ComplexList {
        internalValue?: PredictiveScalingConfigurationMetricSpecificationCustomizedLoadMetricSpecificationMetricDataQueriesProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): PredictiveScalingConfigurationMetricSpecificationCustomizedLoadMetricSpecificationMetricDataQueriesPropertyOutputReference;
    }
    interface CustomizedLoadMetricSpecificationProperty {
        /**
        * metric_data_queries block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#metric_data_queries AwsPolicy#metric_data_queries}
        */
        readonly metricDataQueries: PredictiveScalingConfigurationMetricSpecificationCustomizedLoadMetricSpecificationMetricDataQueriesProperty[] | cdktn.IResolvable;
    }
    class CustomizedLoadMetricSpecificationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CustomizedLoadMetricSpecificationProperty | undefined;
        set internalValue(value: CustomizedLoadMetricSpecificationProperty | undefined);
        private _metricDataQueries;
        get metricDataQueries(): PredictiveScalingConfigurationMetricSpecificationCustomizedLoadMetricSpecificationMetricDataQueriesPropertyList;
        putMetricDataQueries(value: PredictiveScalingConfigurationMetricSpecificationCustomizedLoadMetricSpecificationMetricDataQueriesProperty[] | cdktn.IResolvable): void;
        get metricDataQueriesInput(): cdktn.IResolvable | PredictiveScalingConfigurationMetricSpecificationCustomizedLoadMetricSpecificationMetricDataQueriesProperty[] | undefined;
    }
    interface PredictiveScalingConfigurationMetricSpecificationCustomizedScalingMetricSpecificationMetricDataQueriesMetricStatMetricDimensionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#name AwsPolicy#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#value AwsPolicy#value}
        */
        readonly value: string;
    }
    class PredictiveScalingConfigurationMetricSpecificationCustomizedScalingMetricSpecificationMetricDataQueriesMetricStatMetricDimensionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): PredictiveScalingConfigurationMetricSpecificationCustomizedScalingMetricSpecificationMetricDataQueriesMetricStatMetricDimensionsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: PredictiveScalingConfigurationMetricSpecificationCustomizedScalingMetricSpecificationMetricDataQueriesMetricStatMetricDimensionsProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class PredictiveScalingConfigurationMetricSpecificationCustomizedScalingMetricSpecificationMetricDataQueriesMetricStatMetricDimensionsPropertyList extends cdktn.ComplexList {
        internalValue?: PredictiveScalingConfigurationMetricSpecificationCustomizedScalingMetricSpecificationMetricDataQueriesMetricStatMetricDimensionsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): PredictiveScalingConfigurationMetricSpecificationCustomizedScalingMetricSpecificationMetricDataQueriesMetricStatMetricDimensionsPropertyOutputReference;
    }
    interface PredictiveScalingConfigurationMetricSpecificationCustomizedScalingMetricSpecificationMetricDataQueriesMetricStatMetricProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#metric_name AwsPolicy#metric_name}
        */
        readonly metricName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#namespace AwsPolicy#namespace}
        */
        readonly namespace: string;
        /**
        * dimensions block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#dimensions AwsPolicy#dimensions}
        */
        readonly dimensions?: PredictiveScalingConfigurationMetricSpecificationCustomizedScalingMetricSpecificationMetricDataQueriesMetricStatMetricDimensionsProperty[] | cdktn.IResolvable;
    }
    class PredictiveScalingConfigurationMetricSpecificationCustomizedScalingMetricSpecificationMetricDataQueriesMetricStatMetricPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): PredictiveScalingConfigurationMetricSpecificationCustomizedScalingMetricSpecificationMetricDataQueriesMetricStatMetricProperty | undefined;
        set internalValue(value: PredictiveScalingConfigurationMetricSpecificationCustomizedScalingMetricSpecificationMetricDataQueriesMetricStatMetricProperty | undefined);
        private _metricName?;
        get metricName(): string;
        set metricName(value: string);
        get metricNameInput(): string | undefined;
        private _namespace?;
        get namespace(): string;
        set namespace(value: string);
        get namespaceInput(): string | undefined;
        private _dimensions;
        get dimensions(): PredictiveScalingConfigurationMetricSpecificationCustomizedScalingMetricSpecificationMetricDataQueriesMetricStatMetricDimensionsPropertyList;
        putDimensions(value: PredictiveScalingConfigurationMetricSpecificationCustomizedScalingMetricSpecificationMetricDataQueriesMetricStatMetricDimensionsProperty[] | cdktn.IResolvable): void;
        resetDimensions(): void;
        get dimensionsInput(): cdktn.IResolvable | PredictiveScalingConfigurationMetricSpecificationCustomizedScalingMetricSpecificationMetricDataQueriesMetricStatMetricDimensionsProperty[] | undefined;
    }
    interface PredictiveScalingConfigurationMetricSpecificationCustomizedScalingMetricSpecificationMetricDataQueriesMetricStatProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#stat AwsPolicy#stat}
        */
        readonly stat: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#unit AwsPolicy#unit}
        */
        readonly unit?: string;
        /**
        * metric block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#metric AwsPolicy#metric}
        */
        readonly metric: PredictiveScalingConfigurationMetricSpecificationCustomizedScalingMetricSpecificationMetricDataQueriesMetricStatMetricProperty;
    }
    class PredictiveScalingConfigurationMetricSpecificationCustomizedScalingMetricSpecificationMetricDataQueriesMetricStatPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): PredictiveScalingConfigurationMetricSpecificationCustomizedScalingMetricSpecificationMetricDataQueriesMetricStatProperty | undefined;
        set internalValue(value: PredictiveScalingConfigurationMetricSpecificationCustomizedScalingMetricSpecificationMetricDataQueriesMetricStatProperty | undefined);
        private _stat?;
        get stat(): string;
        set stat(value: string);
        get statInput(): string | undefined;
        private _unit?;
        get unit(): string;
        set unit(value: string);
        resetUnit(): void;
        get unitInput(): string | undefined;
        private _metric;
        get metric(): PredictiveScalingConfigurationMetricSpecificationCustomizedScalingMetricSpecificationMetricDataQueriesMetricStatMetricPropertyOutputReference;
        putMetric(value: PredictiveScalingConfigurationMetricSpecificationCustomizedScalingMetricSpecificationMetricDataQueriesMetricStatMetricProperty): void;
        get metricInput(): PredictiveScalingConfigurationMetricSpecificationCustomizedScalingMetricSpecificationMetricDataQueriesMetricStatMetricProperty | undefined;
    }
    interface PredictiveScalingConfigurationMetricSpecificationCustomizedScalingMetricSpecificationMetricDataQueriesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#expression AwsPolicy#expression}
        */
        readonly expression?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#id AwsPolicy#id}
        *
        * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
        * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
        */
        readonly id: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#label AwsPolicy#label}
        */
        readonly label?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#return_data AwsPolicy#return_data}
        */
        readonly returnData?: boolean | cdktn.IResolvable;
        /**
        * metric_stat block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#metric_stat AwsPolicy#metric_stat}
        */
        readonly metricStat?: PredictiveScalingConfigurationMetricSpecificationCustomizedScalingMetricSpecificationMetricDataQueriesMetricStatProperty;
    }
    class PredictiveScalingConfigurationMetricSpecificationCustomizedScalingMetricSpecificationMetricDataQueriesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): PredictiveScalingConfigurationMetricSpecificationCustomizedScalingMetricSpecificationMetricDataQueriesProperty | cdktn.IResolvable | undefined;
        set internalValue(value: PredictiveScalingConfigurationMetricSpecificationCustomizedScalingMetricSpecificationMetricDataQueriesProperty | cdktn.IResolvable | undefined);
        private _expression?;
        get expression(): string;
        set expression(value: string);
        resetExpression(): void;
        get expressionInput(): string | undefined;
        private _id?;
        get id(): string;
        set id(value: string);
        get idInput(): string | undefined;
        private _label?;
        get label(): string;
        set label(value: string);
        resetLabel(): void;
        get labelInput(): string | undefined;
        private _returnData?;
        get returnData(): boolean | cdktn.IResolvable;
        set returnData(value: boolean | cdktn.IResolvable);
        resetReturnData(): void;
        get returnDataInput(): boolean | cdktn.IResolvable | undefined;
        private _metricStat;
        get metricStat(): PredictiveScalingConfigurationMetricSpecificationCustomizedScalingMetricSpecificationMetricDataQueriesMetricStatPropertyOutputReference;
        putMetricStat(value: PredictiveScalingConfigurationMetricSpecificationCustomizedScalingMetricSpecificationMetricDataQueriesMetricStatProperty): void;
        resetMetricStat(): void;
        get metricStatInput(): PredictiveScalingConfigurationMetricSpecificationCustomizedScalingMetricSpecificationMetricDataQueriesMetricStatProperty | undefined;
    }
    class PredictiveScalingConfigurationMetricSpecificationCustomizedScalingMetricSpecificationMetricDataQueriesPropertyList extends cdktn.ComplexList {
        internalValue?: PredictiveScalingConfigurationMetricSpecificationCustomizedScalingMetricSpecificationMetricDataQueriesProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): PredictiveScalingConfigurationMetricSpecificationCustomizedScalingMetricSpecificationMetricDataQueriesPropertyOutputReference;
    }
    interface CustomizedScalingMetricSpecificationProperty {
        /**
        * metric_data_queries block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#metric_data_queries AwsPolicy#metric_data_queries}
        */
        readonly metricDataQueries: PredictiveScalingConfigurationMetricSpecificationCustomizedScalingMetricSpecificationMetricDataQueriesProperty[] | cdktn.IResolvable;
    }
    class CustomizedScalingMetricSpecificationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CustomizedScalingMetricSpecificationProperty | undefined;
        set internalValue(value: CustomizedScalingMetricSpecificationProperty | undefined);
        private _metricDataQueries;
        get metricDataQueries(): PredictiveScalingConfigurationMetricSpecificationCustomizedScalingMetricSpecificationMetricDataQueriesPropertyList;
        putMetricDataQueries(value: PredictiveScalingConfigurationMetricSpecificationCustomizedScalingMetricSpecificationMetricDataQueriesProperty[] | cdktn.IResolvable): void;
        get metricDataQueriesInput(): cdktn.IResolvable | PredictiveScalingConfigurationMetricSpecificationCustomizedScalingMetricSpecificationMetricDataQueriesProperty[] | undefined;
    }
    interface PredefinedLoadMetricSpecificationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#predefined_metric_type AwsPolicy#predefined_metric_type}
        */
        readonly predefinedMetricType: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#resource_label AwsPolicy#resource_label}
        */
        readonly resourceLabel?: string;
    }
    class PredefinedLoadMetricSpecificationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): PredefinedLoadMetricSpecificationProperty | undefined;
        set internalValue(value: PredefinedLoadMetricSpecificationProperty | undefined);
        private _predefinedMetricType?;
        get predefinedMetricType(): string;
        set predefinedMetricType(value: string);
        get predefinedMetricTypeInput(): string | undefined;
        private _resourceLabel?;
        get resourceLabel(): string;
        set resourceLabel(value: string);
        resetResourceLabel(): void;
        get resourceLabelInput(): string | undefined;
    }
    interface PredefinedMetricPairSpecificationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#predefined_metric_type AwsPolicy#predefined_metric_type}
        */
        readonly predefinedMetricType: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#resource_label AwsPolicy#resource_label}
        */
        readonly resourceLabel?: string;
    }
    class PredefinedMetricPairSpecificationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): PredefinedMetricPairSpecificationProperty | undefined;
        set internalValue(value: PredefinedMetricPairSpecificationProperty | undefined);
        private _predefinedMetricType?;
        get predefinedMetricType(): string;
        set predefinedMetricType(value: string);
        get predefinedMetricTypeInput(): string | undefined;
        private _resourceLabel?;
        get resourceLabel(): string;
        set resourceLabel(value: string);
        resetResourceLabel(): void;
        get resourceLabelInput(): string | undefined;
    }
    interface PredefinedScalingMetricSpecificationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#predefined_metric_type AwsPolicy#predefined_metric_type}
        */
        readonly predefinedMetricType: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#resource_label AwsPolicy#resource_label}
        */
        readonly resourceLabel?: string;
    }
    class PredefinedScalingMetricSpecificationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): PredefinedScalingMetricSpecificationProperty | undefined;
        set internalValue(value: PredefinedScalingMetricSpecificationProperty | undefined);
        private _predefinedMetricType?;
        get predefinedMetricType(): string;
        set predefinedMetricType(value: string);
        get predefinedMetricTypeInput(): string | undefined;
        private _resourceLabel?;
        get resourceLabel(): string;
        set resourceLabel(value: string);
        resetResourceLabel(): void;
        get resourceLabelInput(): string | undefined;
    }
    interface MetricSpecificationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#target_value AwsPolicy#target_value}
        */
        readonly targetValue: number;
        /**
        * customized_capacity_metric_specification block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#customized_capacity_metric_specification AwsPolicy#customized_capacity_metric_specification}
        */
        readonly customizedCapacityMetricSpecification?: CustomizedCapacityMetricSpecificationProperty;
        /**
        * customized_load_metric_specification block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#customized_load_metric_specification AwsPolicy#customized_load_metric_specification}
        */
        readonly customizedLoadMetricSpecification?: CustomizedLoadMetricSpecificationProperty;
        /**
        * customized_scaling_metric_specification block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#customized_scaling_metric_specification AwsPolicy#customized_scaling_metric_specification}
        */
        readonly customizedScalingMetricSpecification?: CustomizedScalingMetricSpecificationProperty;
        /**
        * predefined_load_metric_specification block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#predefined_load_metric_specification AwsPolicy#predefined_load_metric_specification}
        */
        readonly predefinedLoadMetricSpecification?: PredefinedLoadMetricSpecificationProperty;
        /**
        * predefined_metric_pair_specification block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#predefined_metric_pair_specification AwsPolicy#predefined_metric_pair_specification}
        */
        readonly predefinedMetricPairSpecification?: PredefinedMetricPairSpecificationProperty;
        /**
        * predefined_scaling_metric_specification block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#predefined_scaling_metric_specification AwsPolicy#predefined_scaling_metric_specification}
        */
        readonly predefinedScalingMetricSpecification?: PredefinedScalingMetricSpecificationProperty;
    }
    class MetricSpecificationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): MetricSpecificationProperty | undefined;
        set internalValue(value: MetricSpecificationProperty | undefined);
        private _targetValue?;
        get targetValue(): number;
        set targetValue(value: number);
        get targetValueInput(): number | undefined;
        private _customizedCapacityMetricSpecification;
        get customizedCapacityMetricSpecification(): CustomizedCapacityMetricSpecificationPropertyOutputReference;
        putCustomizedCapacityMetricSpecification(value: CustomizedCapacityMetricSpecificationProperty): void;
        resetCustomizedCapacityMetricSpecification(): void;
        get customizedCapacityMetricSpecificationInput(): CustomizedCapacityMetricSpecificationProperty | undefined;
        private _customizedLoadMetricSpecification;
        get customizedLoadMetricSpecification(): CustomizedLoadMetricSpecificationPropertyOutputReference;
        putCustomizedLoadMetricSpecification(value: CustomizedLoadMetricSpecificationProperty): void;
        resetCustomizedLoadMetricSpecification(): void;
        get customizedLoadMetricSpecificationInput(): CustomizedLoadMetricSpecificationProperty | undefined;
        private _customizedScalingMetricSpecification;
        get customizedScalingMetricSpecification(): CustomizedScalingMetricSpecificationPropertyOutputReference;
        putCustomizedScalingMetricSpecification(value: CustomizedScalingMetricSpecificationProperty): void;
        resetCustomizedScalingMetricSpecification(): void;
        get customizedScalingMetricSpecificationInput(): CustomizedScalingMetricSpecificationProperty | undefined;
        private _predefinedLoadMetricSpecification;
        get predefinedLoadMetricSpecification(): PredefinedLoadMetricSpecificationPropertyOutputReference;
        putPredefinedLoadMetricSpecification(value: PredefinedLoadMetricSpecificationProperty): void;
        resetPredefinedLoadMetricSpecification(): void;
        get predefinedLoadMetricSpecificationInput(): PredefinedLoadMetricSpecificationProperty | undefined;
        private _predefinedMetricPairSpecification;
        get predefinedMetricPairSpecification(): PredefinedMetricPairSpecificationPropertyOutputReference;
        putPredefinedMetricPairSpecification(value: PredefinedMetricPairSpecificationProperty): void;
        resetPredefinedMetricPairSpecification(): void;
        get predefinedMetricPairSpecificationInput(): PredefinedMetricPairSpecificationProperty | undefined;
        private _predefinedScalingMetricSpecification;
        get predefinedScalingMetricSpecification(): PredefinedScalingMetricSpecificationPropertyOutputReference;
        putPredefinedScalingMetricSpecification(value: PredefinedScalingMetricSpecificationProperty): void;
        resetPredefinedScalingMetricSpecification(): void;
        get predefinedScalingMetricSpecificationInput(): PredefinedScalingMetricSpecificationProperty | undefined;
    }
    interface PredictiveScalingConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#max_capacity_breach_behavior AwsPolicy#max_capacity_breach_behavior}
        */
        readonly maxCapacityBreachBehavior?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#max_capacity_buffer AwsPolicy#max_capacity_buffer}
        */
        readonly maxCapacityBuffer?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#mode AwsPolicy#mode}
        */
        readonly mode?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#scheduling_buffer_time AwsPolicy#scheduling_buffer_time}
        */
        readonly schedulingBufferTime?: string;
        /**
        * metric_specification block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#metric_specification AwsPolicy#metric_specification}
        */
        readonly metricSpecification: MetricSpecificationProperty;
    }
    class PredictiveScalingConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): PredictiveScalingConfigurationProperty | undefined;
        set internalValue(value: PredictiveScalingConfigurationProperty | undefined);
        private _maxCapacityBreachBehavior?;
        get maxCapacityBreachBehavior(): string;
        set maxCapacityBreachBehavior(value: string);
        resetMaxCapacityBreachBehavior(): void;
        get maxCapacityBreachBehaviorInput(): string | undefined;
        private _maxCapacityBuffer?;
        get maxCapacityBuffer(): string;
        set maxCapacityBuffer(value: string);
        resetMaxCapacityBuffer(): void;
        get maxCapacityBufferInput(): string | undefined;
        private _mode?;
        get mode(): string;
        set mode(value: string);
        resetMode(): void;
        get modeInput(): string | undefined;
        private _schedulingBufferTime?;
        get schedulingBufferTime(): string;
        set schedulingBufferTime(value: string);
        resetSchedulingBufferTime(): void;
        get schedulingBufferTimeInput(): string | undefined;
        private _metricSpecification;
        get metricSpecification(): MetricSpecificationPropertyOutputReference;
        putMetricSpecification(value: MetricSpecificationProperty): void;
        get metricSpecificationInput(): MetricSpecificationProperty | undefined;
    }
    interface StepAdjustmentProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#metric_interval_lower_bound AwsPolicy#metric_interval_lower_bound}
        */
        readonly metricIntervalLowerBound?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#metric_interval_upper_bound AwsPolicy#metric_interval_upper_bound}
        */
        readonly metricIntervalUpperBound?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#scaling_adjustment AwsPolicy#scaling_adjustment}
        */
        readonly scalingAdjustment: number;
    }
    class StepAdjustmentPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): StepAdjustmentProperty | cdktn.IResolvable | undefined;
        set internalValue(value: StepAdjustmentProperty | cdktn.IResolvable | undefined);
        private _metricIntervalLowerBound?;
        get metricIntervalLowerBound(): string;
        set metricIntervalLowerBound(value: string);
        resetMetricIntervalLowerBound(): void;
        get metricIntervalLowerBoundInput(): string | undefined;
        private _metricIntervalUpperBound?;
        get metricIntervalUpperBound(): string;
        set metricIntervalUpperBound(value: string);
        resetMetricIntervalUpperBound(): void;
        get metricIntervalUpperBoundInput(): string | undefined;
        private _scalingAdjustment?;
        get scalingAdjustment(): number;
        set scalingAdjustment(value: number);
        get scalingAdjustmentInput(): number | undefined;
    }
    class StepAdjustmentPropertyList extends cdktn.ComplexList {
        internalValue?: StepAdjustmentProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): StepAdjustmentPropertyOutputReference;
    }
    interface MetricDimensionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#name AwsPolicy#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#value AwsPolicy#value}
        */
        readonly value: string;
    }
    class MetricDimensionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): MetricDimensionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: MetricDimensionProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class MetricDimensionPropertyList extends cdktn.ComplexList {
        internalValue?: MetricDimensionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): MetricDimensionPropertyOutputReference;
    }
    interface TargetTrackingConfigurationCustomizedMetricSpecificationMetricsMetricStatMetricDimensionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#name AwsPolicy#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#value AwsPolicy#value}
        */
        readonly value: string;
    }
    class TargetTrackingConfigurationCustomizedMetricSpecificationMetricsMetricStatMetricDimensionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TargetTrackingConfigurationCustomizedMetricSpecificationMetricsMetricStatMetricDimensionsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TargetTrackingConfigurationCustomizedMetricSpecificationMetricsMetricStatMetricDimensionsProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class TargetTrackingConfigurationCustomizedMetricSpecificationMetricsMetricStatMetricDimensionsPropertyList extends cdktn.ComplexList {
        internalValue?: TargetTrackingConfigurationCustomizedMetricSpecificationMetricsMetricStatMetricDimensionsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TargetTrackingConfigurationCustomizedMetricSpecificationMetricsMetricStatMetricDimensionsPropertyOutputReference;
    }
    interface TargetTrackingConfigurationCustomizedMetricSpecificationMetricsMetricStatMetricProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#metric_name AwsPolicy#metric_name}
        */
        readonly metricName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#namespace AwsPolicy#namespace}
        */
        readonly namespace: string;
        /**
        * dimensions block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#dimensions AwsPolicy#dimensions}
        */
        readonly dimensions?: TargetTrackingConfigurationCustomizedMetricSpecificationMetricsMetricStatMetricDimensionsProperty[] | cdktn.IResolvable;
    }
    class TargetTrackingConfigurationCustomizedMetricSpecificationMetricsMetricStatMetricPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TargetTrackingConfigurationCustomizedMetricSpecificationMetricsMetricStatMetricProperty | undefined;
        set internalValue(value: TargetTrackingConfigurationCustomizedMetricSpecificationMetricsMetricStatMetricProperty | undefined);
        private _metricName?;
        get metricName(): string;
        set metricName(value: string);
        get metricNameInput(): string | undefined;
        private _namespace?;
        get namespace(): string;
        set namespace(value: string);
        get namespaceInput(): string | undefined;
        private _dimensions;
        get dimensions(): TargetTrackingConfigurationCustomizedMetricSpecificationMetricsMetricStatMetricDimensionsPropertyList;
        putDimensions(value: TargetTrackingConfigurationCustomizedMetricSpecificationMetricsMetricStatMetricDimensionsProperty[] | cdktn.IResolvable): void;
        resetDimensions(): void;
        get dimensionsInput(): cdktn.IResolvable | TargetTrackingConfigurationCustomizedMetricSpecificationMetricsMetricStatMetricDimensionsProperty[] | undefined;
    }
    interface TargetTrackingConfigurationCustomizedMetricSpecificationMetricsMetricStatProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#period AwsPolicy#period}
        */
        readonly period?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#stat AwsPolicy#stat}
        */
        readonly stat: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#unit AwsPolicy#unit}
        */
        readonly unit?: string;
        /**
        * metric block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#metric AwsPolicy#metric}
        */
        readonly metric: TargetTrackingConfigurationCustomizedMetricSpecificationMetricsMetricStatMetricProperty;
    }
    class TargetTrackingConfigurationCustomizedMetricSpecificationMetricsMetricStatPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TargetTrackingConfigurationCustomizedMetricSpecificationMetricsMetricStatProperty | undefined;
        set internalValue(value: TargetTrackingConfigurationCustomizedMetricSpecificationMetricsMetricStatProperty | undefined);
        private _period?;
        get period(): number;
        set period(value: number);
        resetPeriod(): void;
        get periodInput(): number | undefined;
        private _stat?;
        get stat(): string;
        set stat(value: string);
        get statInput(): string | undefined;
        private _unit?;
        get unit(): string;
        set unit(value: string);
        resetUnit(): void;
        get unitInput(): string | undefined;
        private _metric;
        get metric(): TargetTrackingConfigurationCustomizedMetricSpecificationMetricsMetricStatMetricPropertyOutputReference;
        putMetric(value: TargetTrackingConfigurationCustomizedMetricSpecificationMetricsMetricStatMetricProperty): void;
        get metricInput(): TargetTrackingConfigurationCustomizedMetricSpecificationMetricsMetricStatMetricProperty | undefined;
    }
    interface MetricsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#expression AwsPolicy#expression}
        */
        readonly expression?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#id AwsPolicy#id}
        *
        * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
        * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
        */
        readonly id: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#label AwsPolicy#label}
        */
        readonly label?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#return_data AwsPolicy#return_data}
        */
        readonly returnData?: boolean | cdktn.IResolvable;
        /**
        * metric_stat block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#metric_stat AwsPolicy#metric_stat}
        */
        readonly metricStat?: TargetTrackingConfigurationCustomizedMetricSpecificationMetricsMetricStatProperty;
    }
    class MetricsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): MetricsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: MetricsProperty | cdktn.IResolvable | undefined);
        private _expression?;
        get expression(): string;
        set expression(value: string);
        resetExpression(): void;
        get expressionInput(): string | undefined;
        private _id?;
        get id(): string;
        set id(value: string);
        get idInput(): string | undefined;
        private _label?;
        get label(): string;
        set label(value: string);
        resetLabel(): void;
        get labelInput(): string | undefined;
        private _returnData?;
        get returnData(): boolean | cdktn.IResolvable;
        set returnData(value: boolean | cdktn.IResolvable);
        resetReturnData(): void;
        get returnDataInput(): boolean | cdktn.IResolvable | undefined;
        private _metricStat;
        get metricStat(): TargetTrackingConfigurationCustomizedMetricSpecificationMetricsMetricStatPropertyOutputReference;
        putMetricStat(value: TargetTrackingConfigurationCustomizedMetricSpecificationMetricsMetricStatProperty): void;
        resetMetricStat(): void;
        get metricStatInput(): TargetTrackingConfigurationCustomizedMetricSpecificationMetricsMetricStatProperty | undefined;
    }
    class MetricsPropertyList extends cdktn.ComplexList {
        internalValue?: MetricsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): MetricsPropertyOutputReference;
    }
    interface CustomizedMetricSpecificationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#metric_name AwsPolicy#metric_name}
        */
        readonly metricName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#namespace AwsPolicy#namespace}
        */
        readonly namespace?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#period AwsPolicy#period}
        */
        readonly period?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#statistic AwsPolicy#statistic}
        */
        readonly statistic?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#unit AwsPolicy#unit}
        */
        readonly unit?: string;
        /**
        * metric_dimension block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#metric_dimension AwsPolicy#metric_dimension}
        */
        readonly metricDimension?: MetricDimensionProperty[] | cdktn.IResolvable;
        /**
        * metrics block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#metrics AwsPolicy#metrics}
        */
        readonly metrics?: MetricsProperty[] | cdktn.IResolvable;
    }
    class CustomizedMetricSpecificationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CustomizedMetricSpecificationProperty | undefined;
        set internalValue(value: CustomizedMetricSpecificationProperty | undefined);
        private _metricName?;
        get metricName(): string;
        set metricName(value: string);
        resetMetricName(): void;
        get metricNameInput(): string | undefined;
        private _namespace?;
        get namespace(): string;
        set namespace(value: string);
        resetNamespace(): void;
        get namespaceInput(): string | undefined;
        private _period?;
        get period(): number;
        set period(value: number);
        resetPeriod(): void;
        get periodInput(): number | undefined;
        private _statistic?;
        get statistic(): string;
        set statistic(value: string);
        resetStatistic(): void;
        get statisticInput(): string | undefined;
        private _unit?;
        get unit(): string;
        set unit(value: string);
        resetUnit(): void;
        get unitInput(): string | undefined;
        private _metricDimension;
        get metricDimension(): MetricDimensionPropertyList;
        putMetricDimension(value: MetricDimensionProperty[] | cdktn.IResolvable): void;
        resetMetricDimension(): void;
        get metricDimensionInput(): cdktn.IResolvable | MetricDimensionProperty[] | undefined;
        private _metrics;
        get metrics(): MetricsPropertyList;
        putMetrics(value: MetricsProperty[] | cdktn.IResolvable): void;
        resetMetrics(): void;
        get metricsInput(): cdktn.IResolvable | MetricsProperty[] | undefined;
    }
    interface PredefinedMetricSpecificationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#predefined_metric_type AwsPolicy#predefined_metric_type}
        */
        readonly predefinedMetricType: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#resource_label AwsPolicy#resource_label}
        */
        readonly resourceLabel?: string;
    }
    class PredefinedMetricSpecificationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): PredefinedMetricSpecificationProperty | undefined;
        set internalValue(value: PredefinedMetricSpecificationProperty | undefined);
        private _predefinedMetricType?;
        get predefinedMetricType(): string;
        set predefinedMetricType(value: string);
        get predefinedMetricTypeInput(): string | undefined;
        private _resourceLabel?;
        get resourceLabel(): string;
        set resourceLabel(value: string);
        resetResourceLabel(): void;
        get resourceLabelInput(): string | undefined;
    }
    interface TargetTrackingConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#disable_scale_in AwsPolicy#disable_scale_in}
        */
        readonly disableScaleIn?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#target_value AwsPolicy#target_value}
        */
        readonly targetValue: number;
        /**
        * customized_metric_specification block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#customized_metric_specification AwsPolicy#customized_metric_specification}
        */
        readonly customizedMetricSpecification?: CustomizedMetricSpecificationProperty;
        /**
        * predefined_metric_specification block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#predefined_metric_specification AwsPolicy#predefined_metric_specification}
        */
        readonly predefinedMetricSpecification?: PredefinedMetricSpecificationProperty;
    }
    class TargetTrackingConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TargetTrackingConfigurationProperty | undefined;
        set internalValue(value: TargetTrackingConfigurationProperty | undefined);
        private _disableScaleIn?;
        get disableScaleIn(): boolean | cdktn.IResolvable;
        set disableScaleIn(value: boolean | cdktn.IResolvable);
        resetDisableScaleIn(): void;
        get disableScaleInInput(): boolean | cdktn.IResolvable | undefined;
        private _targetValue?;
        get targetValue(): number;
        set targetValue(value: number);
        get targetValueInput(): number | undefined;
        private _customizedMetricSpecification;
        get customizedMetricSpecification(): CustomizedMetricSpecificationPropertyOutputReference;
        putCustomizedMetricSpecification(value: CustomizedMetricSpecificationProperty): void;
        resetCustomizedMetricSpecification(): void;
        get customizedMetricSpecificationInput(): CustomizedMetricSpecificationProperty | undefined;
        private _predefinedMetricSpecification;
        get predefinedMetricSpecification(): PredefinedMetricSpecificationPropertyOutputReference;
        putPredefinedMetricSpecification(value: PredefinedMetricSpecificationProperty): void;
        resetPredefinedMetricSpecification(): void;
        get predefinedMetricSpecificationInput(): PredefinedMetricSpecificationProperty | undefined;
    }
}
