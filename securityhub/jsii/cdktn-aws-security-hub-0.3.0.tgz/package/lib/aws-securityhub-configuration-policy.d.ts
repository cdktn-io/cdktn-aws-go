import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsConfigurationPolicyConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_configuration_policy#description AwsConfigurationPolicy#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_configuration_policy#id AwsConfigurationPolicy#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_configuration_policy#name AwsConfigurationPolicy#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_configuration_policy#region AwsConfigurationPolicy#region}
    */
    readonly region?: string;
    /**
    * configuration_policy block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_configuration_policy#configuration_policy AwsConfigurationPolicy#configuration_policy}
    */
    readonly configurationPolicy: AwsConfigurationPolicy.ConfigurationPolicyProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_configuration_policy aws_securityhub_configuration_policy}
*/
export declare class AwsConfigurationPolicy extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_securityhub_configuration_policy";
    /**
    * Generates CDKTN code for importing a AwsConfigurationPolicy resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsConfigurationPolicy to import
    * @param importFromId The id of the existing AwsConfigurationPolicy that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_configuration_policy#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsConfigurationPolicy to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_configuration_policy aws_securityhub_configuration_policy} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsConfigurationPolicyConfig
    */
    constructor(scope: Construct, id: string, config: AwsConfigurationPolicyConfig);
    get arn(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _configurationPolicy;
    get configurationPolicy(): AwsConfigurationPolicy.ConfigurationPolicyPropertyOutputReference;
    putConfigurationPolicy(value: AwsConfigurationPolicy.ConfigurationPolicyProperty): void;
    get configurationPolicyInput(): AwsConfigurationPolicy.ConfigurationPolicyProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsConfigurationPolicyBoolPropertyToTerraform(struct?: AwsConfigurationPolicy.BoolPropertyOutputReference | AwsConfigurationPolicy.BoolProperty): any;
export declare function awsConfigurationPolicyBoolPropertyToHclTerraform(struct?: AwsConfigurationPolicy.BoolPropertyOutputReference | AwsConfigurationPolicy.BoolProperty): any;
export declare function awsConfigurationPolicyDoublePropertyToTerraform(struct?: AwsConfigurationPolicy.DoublePropertyOutputReference | AwsConfigurationPolicy.DoubleProperty): any;
export declare function awsConfigurationPolicyDoublePropertyToHclTerraform(struct?: AwsConfigurationPolicy.DoublePropertyOutputReference | AwsConfigurationPolicy.DoubleProperty): any;
export declare function awsConfigurationPolicyEnumPropertyToTerraform(struct?: AwsConfigurationPolicy.EnumPropertyOutputReference | AwsConfigurationPolicy.EnumProperty): any;
export declare function awsConfigurationPolicyEnumPropertyToHclTerraform(struct?: AwsConfigurationPolicy.EnumPropertyOutputReference | AwsConfigurationPolicy.EnumProperty): any;
export declare function awsConfigurationPolicyEnumListPropertyToTerraform(struct?: AwsConfigurationPolicy.EnumListPropertyOutputReference | AwsConfigurationPolicy.EnumListProperty): any;
export declare function awsConfigurationPolicyEnumListPropertyToHclTerraform(struct?: AwsConfigurationPolicy.EnumListPropertyOutputReference | AwsConfigurationPolicy.EnumListProperty): any;
export declare function awsConfigurationPolicyIntPropertyToTerraform(struct?: AwsConfigurationPolicy.IntPropertyOutputReference | AwsConfigurationPolicy.IntProperty): any;
export declare function awsConfigurationPolicyIntPropertyToHclTerraform(struct?: AwsConfigurationPolicy.IntPropertyOutputReference | AwsConfigurationPolicy.IntProperty): any;
export declare function awsConfigurationPolicyIntListPropertyToTerraform(struct?: AwsConfigurationPolicy.IntListPropertyOutputReference | AwsConfigurationPolicy.IntListProperty): any;
export declare function awsConfigurationPolicyIntListPropertyToHclTerraform(struct?: AwsConfigurationPolicy.IntListPropertyOutputReference | AwsConfigurationPolicy.IntListProperty): any;
export declare function awsConfigurationPolicyStringPropertyToTerraform(struct?: AwsConfigurationPolicy.StringPropertyOutputReference | AwsConfigurationPolicy.StringProperty): any;
export declare function awsConfigurationPolicyStringPropertyToHclTerraform(struct?: AwsConfigurationPolicy.StringPropertyOutputReference | AwsConfigurationPolicy.StringProperty): any;
export declare function awsConfigurationPolicyStringListPropertyToTerraform(struct?: AwsConfigurationPolicy.StringListPropertyOutputReference | AwsConfigurationPolicy.StringListProperty): any;
export declare function awsConfigurationPolicyStringListPropertyToHclTerraform(struct?: AwsConfigurationPolicy.StringListPropertyOutputReference | AwsConfigurationPolicy.StringListProperty): any;
export declare function awsConfigurationPolicyParameterPropertyToTerraform(struct?: AwsConfigurationPolicy.ParameterProperty | cdktn.IResolvable): any;
export declare function awsConfigurationPolicyParameterPropertyToHclTerraform(struct?: AwsConfigurationPolicy.ParameterProperty | cdktn.IResolvable): any;
export declare function awsConfigurationPolicySecurityControlCustomParameterPropertyToTerraform(struct?: AwsConfigurationPolicy.SecurityControlCustomParameterProperty | cdktn.IResolvable): any;
export declare function awsConfigurationPolicySecurityControlCustomParameterPropertyToHclTerraform(struct?: AwsConfigurationPolicy.SecurityControlCustomParameterProperty | cdktn.IResolvable): any;
export declare function awsConfigurationPolicySecurityControlsConfigurationPropertyToTerraform(struct?: AwsConfigurationPolicy.SecurityControlsConfigurationPropertyOutputReference | AwsConfigurationPolicy.SecurityControlsConfigurationProperty): any;
export declare function awsConfigurationPolicySecurityControlsConfigurationPropertyToHclTerraform(struct?: AwsConfigurationPolicy.SecurityControlsConfigurationPropertyOutputReference | AwsConfigurationPolicy.SecurityControlsConfigurationProperty): any;
export declare function awsConfigurationPolicyConfigurationPolicyPropertyToTerraform(struct?: AwsConfigurationPolicy.ConfigurationPolicyPropertyOutputReference | AwsConfigurationPolicy.ConfigurationPolicyProperty): any;
export declare function awsConfigurationPolicyConfigurationPolicyPropertyToHclTerraform(struct?: AwsConfigurationPolicy.ConfigurationPolicyPropertyOutputReference | AwsConfigurationPolicy.ConfigurationPolicyProperty): any;
export declare namespace AwsConfigurationPolicy {
    interface BoolProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_configuration_policy#value AwsConfigurationPolicy#value}
        */
        readonly value: boolean | cdktn.IResolvable;
    }
    class BoolPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): BoolProperty | undefined;
        set internalValue(value: BoolProperty | undefined);
        private _value?;
        get value(): boolean | cdktn.IResolvable;
        set value(value: boolean | cdktn.IResolvable);
        get valueInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface DoubleProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_configuration_policy#value AwsConfigurationPolicy#value}
        */
        readonly value: number;
    }
    class DoublePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DoubleProperty | undefined;
        set internalValue(value: DoubleProperty | undefined);
        private _value?;
        get value(): number;
        set value(value: number);
        get valueInput(): number | undefined;
    }
    interface EnumProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_configuration_policy#value AwsConfigurationPolicy#value}
        */
        readonly value: string;
    }
    class EnumPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): EnumProperty | undefined;
        set internalValue(value: EnumProperty | undefined);
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    interface EnumListProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_configuration_policy#value AwsConfigurationPolicy#value}
        */
        readonly value: string[];
    }
    class EnumListPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): EnumListProperty | undefined;
        set internalValue(value: EnumListProperty | undefined);
        private _value?;
        get value(): string[];
        set value(value: string[]);
        get valueInput(): string[] | undefined;
    }
    interface IntProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_configuration_policy#value AwsConfigurationPolicy#value}
        */
        readonly value: number;
    }
    class IntPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): IntProperty | undefined;
        set internalValue(value: IntProperty | undefined);
        private _value?;
        get value(): number;
        set value(value: number);
        get valueInput(): number | undefined;
    }
    interface IntListProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_configuration_policy#value AwsConfigurationPolicy#value}
        */
        readonly value: number[];
    }
    class IntListPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): IntListProperty | undefined;
        set internalValue(value: IntListProperty | undefined);
        private _value?;
        get value(): number[];
        set value(value: number[]);
        get valueInput(): number[] | undefined;
    }
    interface StringProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_configuration_policy#value AwsConfigurationPolicy#value}
        */
        readonly value: string;
    }
    class StringPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): StringProperty | undefined;
        set internalValue(value: StringProperty | undefined);
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    interface StringListProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_configuration_policy#value AwsConfigurationPolicy#value}
        */
        readonly value: string[];
    }
    class StringListPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): StringListProperty | undefined;
        set internalValue(value: StringListProperty | undefined);
        private _value?;
        get value(): string[];
        set value(value: string[]);
        get valueInput(): string[] | undefined;
    }
    interface ParameterProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_configuration_policy#name AwsConfigurationPolicy#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_configuration_policy#value_type AwsConfigurationPolicy#value_type}
        */
        readonly valueType: string;
        /**
        * bool block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_configuration_policy#bool AwsConfigurationPolicy#bool}
        */
        readonly bool?: BoolProperty;
        /**
        * double block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_configuration_policy#double AwsConfigurationPolicy#double}
        */
        readonly double?: DoubleProperty;
        /**
        * enum block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_configuration_policy#enum AwsConfigurationPolicy#enum}
        */
        readonly enum?: EnumProperty;
        /**
        * enum_list block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_configuration_policy#enum_list AwsConfigurationPolicy#enum_list}
        */
        readonly enumList?: EnumListProperty;
        /**
        * int block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_configuration_policy#int AwsConfigurationPolicy#int}
        */
        readonly int?: IntProperty;
        /**
        * int_list block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_configuration_policy#int_list AwsConfigurationPolicy#int_list}
        */
        readonly intList?: IntListProperty;
        /**
        * string block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_configuration_policy#string AwsConfigurationPolicy#string}
        */
        readonly string?: StringProperty;
        /**
        * string_list block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_configuration_policy#string_list AwsConfigurationPolicy#string_list}
        */
        readonly stringList?: StringListProperty;
    }
    class ParameterPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ParameterProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ParameterProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _valueType?;
        get valueType(): string;
        set valueType(value: string);
        get valueTypeInput(): string | undefined;
        private _bool;
        get bool(): BoolPropertyOutputReference;
        putBool(value: BoolProperty): void;
        resetBool(): void;
        get boolInput(): BoolProperty | undefined;
        private _double;
        get double(): DoublePropertyOutputReference;
        putDouble(value: DoubleProperty): void;
        resetDouble(): void;
        get doubleInput(): DoubleProperty | undefined;
        private _enum;
        get enum(): EnumPropertyOutputReference;
        putEnum(value: EnumProperty): void;
        resetEnum(): void;
        get enumInput(): EnumProperty | undefined;
        private _enumList;
        get enumList(): EnumListPropertyOutputReference;
        putEnumList(value: EnumListProperty): void;
        resetEnumList(): void;
        get enumListInput(): EnumListProperty | undefined;
        private _int;
        get int(): IntPropertyOutputReference;
        putInt(value: IntProperty): void;
        resetInt(): void;
        get intInput(): IntProperty | undefined;
        private _intList;
        get intList(): IntListPropertyOutputReference;
        putIntList(value: IntListProperty): void;
        resetIntList(): void;
        get intListInput(): IntListProperty | undefined;
        private _string;
        get string(): StringPropertyOutputReference;
        putString(value: StringProperty): void;
        resetString(): void;
        get stringInput(): StringProperty | undefined;
        private _stringList;
        get stringList(): StringListPropertyOutputReference;
        putStringList(value: StringListProperty): void;
        resetStringList(): void;
        get stringListInput(): StringListProperty | undefined;
    }
    class ParameterPropertyList extends cdktn.ComplexList {
        internalValue?: ParameterProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ParameterPropertyOutputReference;
    }
    interface SecurityControlCustomParameterProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_configuration_policy#security_control_id AwsConfigurationPolicy#security_control_id}
        */
        readonly securityControlId: string;
        /**
        * parameter block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_configuration_policy#parameter AwsConfigurationPolicy#parameter}
        */
        readonly parameter: ParameterProperty[] | cdktn.IResolvable;
    }
    class SecurityControlCustomParameterPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SecurityControlCustomParameterProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SecurityControlCustomParameterProperty | cdktn.IResolvable | undefined);
        private _securityControlId?;
        get securityControlId(): string;
        set securityControlId(value: string);
        get securityControlIdInput(): string | undefined;
        private _parameter;
        get parameter(): ParameterPropertyList;
        putParameter(value: ParameterProperty[] | cdktn.IResolvable): void;
        get parameterInput(): cdktn.IResolvable | ParameterProperty[] | undefined;
    }
    class SecurityControlCustomParameterPropertyList extends cdktn.ComplexList {
        internalValue?: SecurityControlCustomParameterProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SecurityControlCustomParameterPropertyOutputReference;
    }
    interface SecurityControlsConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_configuration_policy#disabled_control_identifiers AwsConfigurationPolicy#disabled_control_identifiers}
        */
        readonly disabledControlIdentifiers?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_configuration_policy#enabled_control_identifiers AwsConfigurationPolicy#enabled_control_identifiers}
        */
        readonly enabledControlIdentifiers?: string[];
        /**
        * security_control_custom_parameter block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_configuration_policy#security_control_custom_parameter AwsConfigurationPolicy#security_control_custom_parameter}
        */
        readonly securityControlCustomParameter?: SecurityControlCustomParameterProperty[] | cdktn.IResolvable;
    }
    class SecurityControlsConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SecurityControlsConfigurationProperty | undefined;
        set internalValue(value: SecurityControlsConfigurationProperty | undefined);
        private _disabledControlIdentifiers?;
        get disabledControlIdentifiers(): string[];
        set disabledControlIdentifiers(value: string[]);
        resetDisabledControlIdentifiers(): void;
        get disabledControlIdentifiersInput(): string[] | undefined;
        private _enabledControlIdentifiers?;
        get enabledControlIdentifiers(): string[];
        set enabledControlIdentifiers(value: string[]);
        resetEnabledControlIdentifiers(): void;
        get enabledControlIdentifiersInput(): string[] | undefined;
        private _securityControlCustomParameter;
        get securityControlCustomParameter(): SecurityControlCustomParameterPropertyList;
        putSecurityControlCustomParameter(value: SecurityControlCustomParameterProperty[] | cdktn.IResolvable): void;
        resetSecurityControlCustomParameter(): void;
        get securityControlCustomParameterInput(): cdktn.IResolvable | SecurityControlCustomParameterProperty[] | undefined;
    }
    interface ConfigurationPolicyProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_configuration_policy#enabled_standard_arns AwsConfigurationPolicy#enabled_standard_arns}
        */
        readonly enabledStandardArns?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_configuration_policy#service_enabled AwsConfigurationPolicy#service_enabled}
        */
        readonly serviceEnabled: boolean | cdktn.IResolvable;
        /**
        * security_controls_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_configuration_policy#security_controls_configuration AwsConfigurationPolicy#security_controls_configuration}
        */
        readonly securityControlsConfiguration?: SecurityControlsConfigurationProperty;
    }
    class ConfigurationPolicyPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ConfigurationPolicyProperty | undefined;
        set internalValue(value: ConfigurationPolicyProperty | undefined);
        private _enabledStandardArns?;
        get enabledStandardArns(): string[];
        set enabledStandardArns(value: string[]);
        resetEnabledStandardArns(): void;
        get enabledStandardArnsInput(): string[] | undefined;
        private _serviceEnabled?;
        get serviceEnabled(): boolean | cdktn.IResolvable;
        set serviceEnabled(value: boolean | cdktn.IResolvable);
        get serviceEnabledInput(): boolean | cdktn.IResolvable | undefined;
        private _securityControlsConfiguration;
        get securityControlsConfiguration(): SecurityControlsConfigurationPropertyOutputReference;
        putSecurityControlsConfiguration(value: SecurityControlsConfigurationProperty): void;
        resetSecurityControlsConfiguration(): void;
        get securityControlsConfigurationInput(): SecurityControlsConfigurationProperty | undefined;
    }
}
