import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsOrganizationConfigurationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_organization_configuration#auto_enable AwsOrganizationConfiguration#auto_enable}
    */
    readonly autoEnable: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_organization_configuration#auto_enable_standards AwsOrganizationConfiguration#auto_enable_standards}
    */
    readonly autoEnableStandards?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_organization_configuration#id AwsOrganizationConfiguration#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_organization_configuration#region AwsOrganizationConfiguration#region}
    */
    readonly region?: string;
    /**
    * organization_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_organization_configuration#organization_configuration AwsOrganizationConfiguration#organization_configuration}
    */
    readonly organizationConfiguration?: AwsOrganizationConfiguration.OrganizationConfigurationProperty;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_organization_configuration#timeouts AwsOrganizationConfiguration#timeouts}
    */
    readonly timeouts?: AwsOrganizationConfiguration.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_organization_configuration aws_securityhub_organization_configuration}
*/
export declare class AwsOrganizationConfiguration extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_securityhub_organization_configuration";
    /**
    * Generates CDKTN code for importing a AwsOrganizationConfiguration resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsOrganizationConfiguration to import
    * @param importFromId The id of the existing AwsOrganizationConfiguration that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_organization_configuration#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsOrganizationConfiguration to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_organization_configuration aws_securityhub_organization_configuration} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsOrganizationConfigurationConfig
    */
    constructor(scope: Construct, id: string, config: AwsOrganizationConfigurationConfig);
    private _autoEnable?;
    get autoEnable(): boolean | cdktn.IResolvable;
    set autoEnable(value: boolean | cdktn.IResolvable);
    get autoEnableInput(): boolean | cdktn.IResolvable | undefined;
    private _autoEnableStandards?;
    get autoEnableStandards(): string;
    set autoEnableStandards(value: string);
    resetAutoEnableStandards(): void;
    get autoEnableStandardsInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _organizationConfiguration;
    get organizationConfiguration(): AwsOrganizationConfiguration.OrganizationConfigurationPropertyOutputReference;
    putOrganizationConfiguration(value: AwsOrganizationConfiguration.OrganizationConfigurationProperty): void;
    resetOrganizationConfiguration(): void;
    get organizationConfigurationInput(): AwsOrganizationConfiguration.OrganizationConfigurationProperty | undefined;
    private _timeouts;
    get timeouts(): AwsOrganizationConfiguration.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsOrganizationConfiguration.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsOrganizationConfiguration.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsOrganizationConfigurationOrganizationConfigurationPropertyToTerraform(struct?: AwsOrganizationConfiguration.OrganizationConfigurationPropertyOutputReference | AwsOrganizationConfiguration.OrganizationConfigurationProperty): any;
export declare function awsOrganizationConfigurationOrganizationConfigurationPropertyToHclTerraform(struct?: AwsOrganizationConfiguration.OrganizationConfigurationPropertyOutputReference | AwsOrganizationConfiguration.OrganizationConfigurationProperty): any;
export declare function awsOrganizationConfigurationTimeoutsPropertyToTerraform(struct?: AwsOrganizationConfiguration.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsOrganizationConfigurationTimeoutsPropertyToHclTerraform(struct?: AwsOrganizationConfiguration.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsOrganizationConfiguration {
    interface OrganizationConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_organization_configuration#configuration_type AwsOrganizationConfiguration#configuration_type}
        */
        readonly configurationType: string;
    }
    class OrganizationConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): OrganizationConfigurationProperty | undefined;
        set internalValue(value: OrganizationConfigurationProperty | undefined);
        private _configurationType?;
        get configurationType(): string;
        set configurationType(value: string);
        get configurationTypeInput(): string | undefined;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_organization_configuration#create AwsOrganizationConfiguration#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_organization_configuration#delete AwsOrganizationConfiguration#delete}
        */
        readonly delete?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_organization_configuration#update AwsOrganizationConfiguration#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
