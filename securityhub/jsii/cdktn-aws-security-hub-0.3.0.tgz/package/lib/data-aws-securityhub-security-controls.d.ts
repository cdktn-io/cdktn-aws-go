import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsSecurityControlsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/securityhub_security_controls#region DataAwsSecurityControls#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/securityhub_security_controls#standards_arn DataAwsSecurityControls#standards_arn}
    */
    readonly standardsArn?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/securityhub_security_controls aws_securityhub_security_controls}
*/
export declare class DataAwsSecurityControls extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_securityhub_security_controls";
    /**
    * Generates CDKTN code for importing a DataAwsSecurityControls resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsSecurityControls to import
    * @param importFromId The id of the existing DataAwsSecurityControls that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/securityhub_security_controls#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsSecurityControls to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/securityhub_security_controls aws_securityhub_security_controls} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsSecurityControlsConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataAwsSecurityControlsConfig);
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _securityControlDefinitions;
    get securityControlDefinitions(): DataAwsSecurityControls.SecurityControlDefinitionsPropertyList;
    private _standardsArn?;
    get standardsArn(): string;
    set standardsArn(value: string);
    resetStandardsArn(): void;
    get standardsArnInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataAwsSecurityControlsSecurityControlDefinitionsPropertyToTerraform(struct?: DataAwsSecurityControls.SecurityControlDefinitionsProperty): any;
export declare function dataAwsSecurityControlsSecurityControlDefinitionsPropertyToHclTerraform(struct?: DataAwsSecurityControls.SecurityControlDefinitionsProperty): any;
export declare namespace DataAwsSecurityControls {
    interface SecurityControlDefinitionsProperty {
    }
    class SecurityControlDefinitionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SecurityControlDefinitionsProperty | undefined;
        set internalValue(value: SecurityControlDefinitionsProperty | undefined);
        get currentRegionAvailability(): string;
        get customizableProperties(): string[];
        get description(): string;
        get remediationUrl(): string;
        get securityControlId(): string;
        get severityRating(): string;
        get title(): string;
    }
    class SecurityControlDefinitionsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SecurityControlDefinitionsPropertyOutputReference;
    }
}
