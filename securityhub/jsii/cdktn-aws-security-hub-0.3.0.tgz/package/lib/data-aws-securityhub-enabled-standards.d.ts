import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsEnabledStandardsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/securityhub_enabled_standards#region DataAwsEnabledStandards#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/securityhub_enabled_standards#standards_subscription_arns DataAwsEnabledStandards#standards_subscription_arns}
    */
    readonly standardsSubscriptionArns?: string[];
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/securityhub_enabled_standards aws_securityhub_enabled_standards}
*/
export declare class DataAwsEnabledStandards extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_securityhub_enabled_standards";
    /**
    * Generates CDKTN code for importing a DataAwsEnabledStandards resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsEnabledStandards to import
    * @param importFromId The id of the existing DataAwsEnabledStandards that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/securityhub_enabled_standards#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsEnabledStandards to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/securityhub_enabled_standards aws_securityhub_enabled_standards} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsEnabledStandardsConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataAwsEnabledStandardsConfig);
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _standardsSubscriptionArns?;
    get standardsSubscriptionArns(): string[];
    set standardsSubscriptionArns(value: string[]);
    resetStandardsSubscriptionArns(): void;
    get standardsSubscriptionArnsInput(): string[] | undefined;
    private _standardsSubscriptions;
    get standardsSubscriptions(): DataAwsEnabledStandards.StandardsSubscriptionsPropertyList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataAwsEnabledStandardsStandardsStatusReasonPropertyToTerraform(struct?: DataAwsEnabledStandards.StandardsStatusReasonProperty): any;
export declare function dataAwsEnabledStandardsStandardsStatusReasonPropertyToHclTerraform(struct?: DataAwsEnabledStandards.StandardsStatusReasonProperty): any;
export declare function dataAwsEnabledStandardsStandardsSubscriptionsPropertyToTerraform(struct?: DataAwsEnabledStandards.StandardsSubscriptionsProperty): any;
export declare function dataAwsEnabledStandardsStandardsSubscriptionsPropertyToHclTerraform(struct?: DataAwsEnabledStandards.StandardsSubscriptionsProperty): any;
export declare namespace DataAwsEnabledStandards {
    interface StandardsStatusReasonProperty {
    }
    class StandardsStatusReasonPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): StandardsStatusReasonProperty | undefined;
        set internalValue(value: StandardsStatusReasonProperty | undefined);
        get statusReasonCode(): string;
    }
    class StandardsStatusReasonPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): StandardsStatusReasonPropertyOutputReference;
    }
    interface StandardsSubscriptionsProperty {
    }
    class StandardsSubscriptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): StandardsSubscriptionsProperty | undefined;
        set internalValue(value: StandardsSubscriptionsProperty | undefined);
        get standardsArn(): string;
        get standardsControlsUpdatable(): string;
        private _standardsInputs;
        get standardsInputs(): cdktn.StringMap;
        get standardsStatus(): string;
        private _standardsStatusReason;
        get standardsStatusReason(): StandardsStatusReasonPropertyList;
        get standardsSubscriptionArn(): string;
    }
    class StandardsSubscriptionsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): StandardsSubscriptionsPropertyOutputReference;
    }
}
