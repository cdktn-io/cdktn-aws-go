import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfManagedScalingPolicyConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_managed_scaling_policy#cluster_id TfManagedScalingPolicy#cluster_id}
    */
    readonly clusterId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_managed_scaling_policy#id TfManagedScalingPolicy#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_managed_scaling_policy#region TfManagedScalingPolicy#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_managed_scaling_policy#scaling_strategy TfManagedScalingPolicy#scaling_strategy}
    */
    readonly scalingStrategy?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_managed_scaling_policy#utilization_performance_index TfManagedScalingPolicy#utilization_performance_index}
    */
    readonly utilizationPerformanceIndex?: number;
    /**
    * compute_limits block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_managed_scaling_policy#compute_limits TfManagedScalingPolicy#compute_limits}
    */
    readonly computeLimits: TfManagedScalingPolicy.ComputeLimitsProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_managed_scaling_policy aws_emr_managed_scaling_policy}
*/
export declare class TfManagedScalingPolicy extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_emr_managed_scaling_policy";
    /**
    * Generates CDKTN code for importing a TfManagedScalingPolicy resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfManagedScalingPolicy to import
    * @param importFromId The id of the existing TfManagedScalingPolicy that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_managed_scaling_policy#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfManagedScalingPolicy to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_managed_scaling_policy aws_emr_managed_scaling_policy} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfManagedScalingPolicyConfig
    */
    constructor(scope: Construct, id: string, config: TfManagedScalingPolicyConfig);
    private _clusterId?;
    get clusterId(): string;
    set clusterId(value: string);
    get clusterIdInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _scalingStrategy?;
    get scalingStrategy(): string;
    set scalingStrategy(value: string);
    resetScalingStrategy(): void;
    get scalingStrategyInput(): string | undefined;
    private _utilizationPerformanceIndex?;
    get utilizationPerformanceIndex(): number;
    set utilizationPerformanceIndex(value: number);
    resetUtilizationPerformanceIndex(): void;
    get utilizationPerformanceIndexInput(): number | undefined;
    private _computeLimits;
    get computeLimits(): TfManagedScalingPolicy.ComputeLimitsPropertyList;
    putComputeLimits(value: TfManagedScalingPolicy.ComputeLimitsProperty[] | cdktn.IResolvable): void;
    get computeLimitsInput(): cdktn.IResolvable | TfManagedScalingPolicy.ComputeLimitsProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfManagedScalingPolicyComputeLimitsPropertyToTerraform(struct?: TfManagedScalingPolicy.ComputeLimitsProperty | cdktn.IResolvable): any;
export declare function tfManagedScalingPolicyComputeLimitsPropertyToHclTerraform(struct?: TfManagedScalingPolicy.ComputeLimitsProperty | cdktn.IResolvable): any;
export declare namespace TfManagedScalingPolicy {
    interface ComputeLimitsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_managed_scaling_policy#maximum_capacity_units TfManagedScalingPolicy#maximum_capacity_units}
        */
        readonly maximumCapacityUnits: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_managed_scaling_policy#maximum_core_capacity_units TfManagedScalingPolicy#maximum_core_capacity_units}
        */
        readonly maximumCoreCapacityUnits?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_managed_scaling_policy#maximum_ondemand_capacity_units TfManagedScalingPolicy#maximum_ondemand_capacity_units}
        */
        readonly maximumOndemandCapacityUnits?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_managed_scaling_policy#minimum_capacity_units TfManagedScalingPolicy#minimum_capacity_units}
        */
        readonly minimumCapacityUnits: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_managed_scaling_policy#unit_type TfManagedScalingPolicy#unit_type}
        */
        readonly unitType: string;
    }
    class ComputeLimitsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ComputeLimitsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ComputeLimitsProperty | cdktn.IResolvable | undefined);
        private _maximumCapacityUnits?;
        get maximumCapacityUnits(): number;
        set maximumCapacityUnits(value: number);
        get maximumCapacityUnitsInput(): number | undefined;
        private _maximumCoreCapacityUnits?;
        get maximumCoreCapacityUnits(): number;
        set maximumCoreCapacityUnits(value: number);
        resetMaximumCoreCapacityUnits(): void;
        get maximumCoreCapacityUnitsInput(): number | undefined;
        private _maximumOndemandCapacityUnits?;
        get maximumOndemandCapacityUnits(): number;
        set maximumOndemandCapacityUnits(value: number);
        resetMaximumOndemandCapacityUnits(): void;
        get maximumOndemandCapacityUnitsInput(): number | undefined;
        private _minimumCapacityUnits?;
        get minimumCapacityUnits(): number;
        set minimumCapacityUnits(value: number);
        get minimumCapacityUnitsInput(): number | undefined;
        private _unitType?;
        get unitType(): string;
        set unitType(value: string);
        get unitTypeInput(): string | undefined;
    }
    class ComputeLimitsPropertyList extends cdktn.ComplexList {
        internalValue?: ComputeLimitsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ComputeLimitsPropertyOutputReference;
    }
}
