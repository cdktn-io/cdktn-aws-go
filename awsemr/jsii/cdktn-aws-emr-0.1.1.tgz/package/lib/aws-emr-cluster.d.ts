import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsEmrClusterConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#additional_info AwsEmrCluster#additional_info}
    */
    readonly additionalInfo?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#applications AwsEmrCluster#applications}
    */
    readonly applications?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#autoscaling_role AwsEmrCluster#autoscaling_role}
    */
    readonly autoscalingRole?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#configurations AwsEmrCluster#configurations}
    */
    readonly configurations?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#configurations_json AwsEmrCluster#configurations_json}
    */
    readonly configurationsJson?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#custom_ami_id AwsEmrCluster#custom_ami_id}
    */
    readonly customAmiId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#ebs_root_volume_size AwsEmrCluster#ebs_root_volume_size}
    */
    readonly ebsRootVolumeSize?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#id AwsEmrCluster#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#keep_job_flow_alive_when_no_steps AwsEmrCluster#keep_job_flow_alive_when_no_steps}
    */
    readonly keepJobFlowAliveWhenNoSteps?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#list_steps_states AwsEmrCluster#list_steps_states}
    */
    readonly listStepsStates?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#log_encryption_kms_key_id AwsEmrCluster#log_encryption_kms_key_id}
    */
    readonly logEncryptionKmsKeyId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#log_uri AwsEmrCluster#log_uri}
    */
    readonly logUri?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#name AwsEmrCluster#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#os_release_label AwsEmrCluster#os_release_label}
    */
    readonly osReleaseLabel?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#placement_group_config AwsEmrCluster#placement_group_config}
    */
    readonly placementGroupConfig?: AwsEmrCluster.PlacementGroupConfigProperty[] | cdktn.IResolvable;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#region AwsEmrCluster#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#release_label AwsEmrCluster#release_label}
    */
    readonly releaseLabel: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#scale_down_behavior AwsEmrCluster#scale_down_behavior}
    */
    readonly scaleDownBehavior?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#security_configuration AwsEmrCluster#security_configuration}
    */
    readonly securityConfiguration?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#service_role AwsEmrCluster#service_role}
    */
    readonly serviceRole: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#step AwsEmrCluster#step}
    */
    readonly step?: AwsEmrCluster.StepProperty[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#step_concurrency_level AwsEmrCluster#step_concurrency_level}
    */
    readonly stepConcurrencyLevel?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#tags AwsEmrCluster#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#tags_all AwsEmrCluster#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#termination_protection AwsEmrCluster#termination_protection}
    */
    readonly terminationProtection?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#unhealthy_node_replacement AwsEmrCluster#unhealthy_node_replacement}
    */
    readonly unhealthyNodeReplacement?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#visible_to_all_users AwsEmrCluster#visible_to_all_users}
    */
    readonly visibleToAllUsers?: boolean | cdktn.IResolvable;
    /**
    * auto_termination_policy block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#auto_termination_policy AwsEmrCluster#auto_termination_policy}
    */
    readonly autoTerminationPolicy?: AwsEmrCluster.AutoTerminationPolicyProperty;
    /**
    * bootstrap_action block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#bootstrap_action AwsEmrCluster#bootstrap_action}
    */
    readonly bootstrapAction?: AwsEmrCluster.BootstrapActionProperty[] | cdktn.IResolvable;
    /**
    * core_instance_fleet block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#core_instance_fleet AwsEmrCluster#core_instance_fleet}
    */
    readonly coreInstanceFleet?: AwsEmrCluster.CoreInstanceFleetProperty;
    /**
    * core_instance_group block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#core_instance_group AwsEmrCluster#core_instance_group}
    */
    readonly coreInstanceGroup?: AwsEmrCluster.CoreInstanceGroupProperty;
    /**
    * ec2_attributes block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#ec2_attributes AwsEmrCluster#ec2_attributes}
    */
    readonly ec2Attributes?: AwsEmrCluster.Ec2AttributesProperty;
    /**
    * kerberos_attributes block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#kerberos_attributes AwsEmrCluster#kerberos_attributes}
    */
    readonly kerberosAttributes?: AwsEmrCluster.KerberosAttributesProperty;
    /**
    * master_instance_fleet block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#master_instance_fleet AwsEmrCluster#master_instance_fleet}
    */
    readonly masterInstanceFleet?: AwsEmrCluster.MasterInstanceFleetProperty;
    /**
    * master_instance_group block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#master_instance_group AwsEmrCluster#master_instance_group}
    */
    readonly masterInstanceGroup?: AwsEmrCluster.MasterInstanceGroupProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster aws_emr_cluster}
*/
export declare class AwsEmrCluster extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_emr_cluster";
    /**
    * Generates CDKTN code for importing a AwsEmrCluster resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsEmrCluster to import
    * @param importFromId The id of the existing AwsEmrCluster that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsEmrCluster to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster aws_emr_cluster} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsEmrClusterConfig
    */
    constructor(scope: Construct, id: string, config: AwsEmrClusterConfig);
    private _additionalInfo?;
    get additionalInfo(): string;
    set additionalInfo(value: string);
    resetAdditionalInfo(): void;
    get additionalInfoInput(): string | undefined;
    private _applications?;
    get applications(): string[];
    set applications(value: string[]);
    resetApplications(): void;
    get applicationsInput(): string[] | undefined;
    get arn(): string;
    private _autoscalingRole?;
    get autoscalingRole(): string;
    set autoscalingRole(value: string);
    resetAutoscalingRole(): void;
    get autoscalingRoleInput(): string | undefined;
    get clusterState(): string;
    private _configurations?;
    get configurations(): string;
    set configurations(value: string);
    resetConfigurations(): void;
    get configurationsInput(): string | undefined;
    private _configurationsJson?;
    get configurationsJson(): string;
    set configurationsJson(value: string);
    resetConfigurationsJson(): void;
    get configurationsJsonInput(): string | undefined;
    private _customAmiId?;
    get customAmiId(): string;
    set customAmiId(value: string);
    resetCustomAmiId(): void;
    get customAmiIdInput(): string | undefined;
    private _ebsRootVolumeSize?;
    get ebsRootVolumeSize(): number;
    set ebsRootVolumeSize(value: number);
    resetEbsRootVolumeSize(): void;
    get ebsRootVolumeSizeInput(): number | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _keepJobFlowAliveWhenNoSteps?;
    get keepJobFlowAliveWhenNoSteps(): boolean | cdktn.IResolvable;
    set keepJobFlowAliveWhenNoSteps(value: boolean | cdktn.IResolvable);
    resetKeepJobFlowAliveWhenNoSteps(): void;
    get keepJobFlowAliveWhenNoStepsInput(): boolean | cdktn.IResolvable | undefined;
    private _listStepsStates?;
    get listStepsStates(): string[];
    set listStepsStates(value: string[]);
    resetListStepsStates(): void;
    get listStepsStatesInput(): string[] | undefined;
    private _logEncryptionKmsKeyId?;
    get logEncryptionKmsKeyId(): string;
    set logEncryptionKmsKeyId(value: string);
    resetLogEncryptionKmsKeyId(): void;
    get logEncryptionKmsKeyIdInput(): string | undefined;
    private _logUri?;
    get logUri(): string;
    set logUri(value: string);
    resetLogUri(): void;
    get logUriInput(): string | undefined;
    get masterPublicDns(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _osReleaseLabel?;
    get osReleaseLabel(): string;
    set osReleaseLabel(value: string);
    resetOsReleaseLabel(): void;
    get osReleaseLabelInput(): string | undefined;
    private _placementGroupConfig;
    get placementGroupConfig(): AwsEmrCluster.PlacementGroupConfigPropertyList;
    putPlacementGroupConfig(value: AwsEmrCluster.PlacementGroupConfigProperty[] | cdktn.IResolvable): void;
    resetPlacementGroupConfig(): void;
    get placementGroupConfigInput(): cdktn.IResolvable | AwsEmrCluster.PlacementGroupConfigProperty[] | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _releaseLabel?;
    get releaseLabel(): string;
    set releaseLabel(value: string);
    get releaseLabelInput(): string | undefined;
    private _scaleDownBehavior?;
    get scaleDownBehavior(): string;
    set scaleDownBehavior(value: string);
    resetScaleDownBehavior(): void;
    get scaleDownBehaviorInput(): string | undefined;
    private _securityConfiguration?;
    get securityConfiguration(): string;
    set securityConfiguration(value: string);
    resetSecurityConfiguration(): void;
    get securityConfigurationInput(): string | undefined;
    private _serviceRole?;
    get serviceRole(): string;
    set serviceRole(value: string);
    get serviceRoleInput(): string | undefined;
    private _step;
    get step(): AwsEmrCluster.StepPropertyList;
    putStep(value: AwsEmrCluster.StepProperty[] | cdktn.IResolvable): void;
    resetStep(): void;
    get stepInput(): cdktn.IResolvable | AwsEmrCluster.StepProperty[] | undefined;
    private _stepConcurrencyLevel?;
    get stepConcurrencyLevel(): number;
    set stepConcurrencyLevel(value: number);
    resetStepConcurrencyLevel(): void;
    get stepConcurrencyLevelInput(): number | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _terminationProtection?;
    get terminationProtection(): boolean | cdktn.IResolvable;
    set terminationProtection(value: boolean | cdktn.IResolvable);
    resetTerminationProtection(): void;
    get terminationProtectionInput(): boolean | cdktn.IResolvable | undefined;
    private _unhealthyNodeReplacement?;
    get unhealthyNodeReplacement(): boolean | cdktn.IResolvable;
    set unhealthyNodeReplacement(value: boolean | cdktn.IResolvable);
    resetUnhealthyNodeReplacement(): void;
    get unhealthyNodeReplacementInput(): boolean | cdktn.IResolvable | undefined;
    private _visibleToAllUsers?;
    get visibleToAllUsers(): boolean | cdktn.IResolvable;
    set visibleToAllUsers(value: boolean | cdktn.IResolvable);
    resetVisibleToAllUsers(): void;
    get visibleToAllUsersInput(): boolean | cdktn.IResolvable | undefined;
    private _autoTerminationPolicy;
    get autoTerminationPolicy(): AwsEmrCluster.AutoTerminationPolicyPropertyOutputReference;
    putAutoTerminationPolicy(value: AwsEmrCluster.AutoTerminationPolicyProperty): void;
    resetAutoTerminationPolicy(): void;
    get autoTerminationPolicyInput(): AwsEmrCluster.AutoTerminationPolicyProperty | undefined;
    private _bootstrapAction;
    get bootstrapAction(): AwsEmrCluster.BootstrapActionPropertyList;
    putBootstrapAction(value: AwsEmrCluster.BootstrapActionProperty[] | cdktn.IResolvable): void;
    resetBootstrapAction(): void;
    get bootstrapActionInput(): cdktn.IResolvable | AwsEmrCluster.BootstrapActionProperty[] | undefined;
    private _coreInstanceFleet;
    get coreInstanceFleet(): AwsEmrCluster.CoreInstanceFleetPropertyOutputReference;
    putCoreInstanceFleet(value: AwsEmrCluster.CoreInstanceFleetProperty): void;
    resetCoreInstanceFleet(): void;
    get coreInstanceFleetInput(): AwsEmrCluster.CoreInstanceFleetProperty | undefined;
    private _coreInstanceGroup;
    get coreInstanceGroup(): AwsEmrCluster.CoreInstanceGroupPropertyOutputReference;
    putCoreInstanceGroup(value: AwsEmrCluster.CoreInstanceGroupProperty): void;
    resetCoreInstanceGroup(): void;
    get coreInstanceGroupInput(): AwsEmrCluster.CoreInstanceGroupProperty | undefined;
    private _ec2Attributes;
    get ec2Attributes(): AwsEmrCluster.Ec2AttributesPropertyOutputReference;
    putEc2Attributes(value: AwsEmrCluster.Ec2AttributesProperty): void;
    resetEc2Attributes(): void;
    get ec2AttributesInput(): AwsEmrCluster.Ec2AttributesProperty | undefined;
    private _kerberosAttributes;
    get kerberosAttributes(): AwsEmrCluster.KerberosAttributesPropertyOutputReference;
    putKerberosAttributes(value: AwsEmrCluster.KerberosAttributesProperty): void;
    resetKerberosAttributes(): void;
    get kerberosAttributesInput(): AwsEmrCluster.KerberosAttributesProperty | undefined;
    private _masterInstanceFleet;
    get masterInstanceFleet(): AwsEmrCluster.MasterInstanceFleetPropertyOutputReference;
    putMasterInstanceFleet(value: AwsEmrCluster.MasterInstanceFleetProperty): void;
    resetMasterInstanceFleet(): void;
    get masterInstanceFleetInput(): AwsEmrCluster.MasterInstanceFleetProperty | undefined;
    private _masterInstanceGroup;
    get masterInstanceGroup(): AwsEmrCluster.MasterInstanceGroupPropertyOutputReference;
    putMasterInstanceGroup(value: AwsEmrCluster.MasterInstanceGroupProperty): void;
    resetMasterInstanceGroup(): void;
    get masterInstanceGroupInput(): AwsEmrCluster.MasterInstanceGroupProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsEmrClusterPlacementGroupConfigPropertyToTerraform(struct?: AwsEmrCluster.PlacementGroupConfigProperty | cdktn.IResolvable): any;
export declare function awsEmrClusterPlacementGroupConfigPropertyToHclTerraform(struct?: AwsEmrCluster.PlacementGroupConfigProperty | cdktn.IResolvable): any;
export declare function awsEmrClusterHadoopJarStepPropertyToTerraform(struct?: AwsEmrCluster.HadoopJarStepProperty | cdktn.IResolvable): any;
export declare function awsEmrClusterHadoopJarStepPropertyToHclTerraform(struct?: AwsEmrCluster.HadoopJarStepProperty | cdktn.IResolvable): any;
export declare function awsEmrClusterStepPropertyToTerraform(struct?: AwsEmrCluster.StepProperty | cdktn.IResolvable): any;
export declare function awsEmrClusterStepPropertyToHclTerraform(struct?: AwsEmrCluster.StepProperty | cdktn.IResolvable): any;
export declare function awsEmrClusterAutoTerminationPolicyPropertyToTerraform(struct?: AwsEmrCluster.AutoTerminationPolicyPropertyOutputReference | AwsEmrCluster.AutoTerminationPolicyProperty): any;
export declare function awsEmrClusterAutoTerminationPolicyPropertyToHclTerraform(struct?: AwsEmrCluster.AutoTerminationPolicyPropertyOutputReference | AwsEmrCluster.AutoTerminationPolicyProperty): any;
export declare function awsEmrClusterBootstrapActionPropertyToTerraform(struct?: AwsEmrCluster.BootstrapActionProperty | cdktn.IResolvable): any;
export declare function awsEmrClusterBootstrapActionPropertyToHclTerraform(struct?: AwsEmrCluster.BootstrapActionProperty | cdktn.IResolvable): any;
export declare function awsEmrClusterCoreInstanceFleetInstanceTypeConfigsConfigurationsPropertyToTerraform(struct?: AwsEmrCluster.CoreInstanceFleetInstanceTypeConfigsConfigurationsProperty | cdktn.IResolvable): any;
export declare function awsEmrClusterCoreInstanceFleetInstanceTypeConfigsConfigurationsPropertyToHclTerraform(struct?: AwsEmrCluster.CoreInstanceFleetInstanceTypeConfigsConfigurationsProperty | cdktn.IResolvable): any;
export declare function awsEmrClusterCoreInstanceFleetInstanceTypeConfigsEbsConfigPropertyToTerraform(struct?: AwsEmrCluster.CoreInstanceFleetInstanceTypeConfigsEbsConfigProperty | cdktn.IResolvable): any;
export declare function awsEmrClusterCoreInstanceFleetInstanceTypeConfigsEbsConfigPropertyToHclTerraform(struct?: AwsEmrCluster.CoreInstanceFleetInstanceTypeConfigsEbsConfigProperty | cdktn.IResolvable): any;
export declare function awsEmrClusterCoreInstanceFleetInstanceTypeConfigsPropertyToTerraform(struct?: AwsEmrCluster.CoreInstanceFleetInstanceTypeConfigsProperty | cdktn.IResolvable): any;
export declare function awsEmrClusterCoreInstanceFleetInstanceTypeConfigsPropertyToHclTerraform(struct?: AwsEmrCluster.CoreInstanceFleetInstanceTypeConfigsProperty | cdktn.IResolvable): any;
export declare function awsEmrClusterCoreInstanceFleetLaunchSpecificationsOnDemandSpecificationPropertyToTerraform(struct?: AwsEmrCluster.CoreInstanceFleetLaunchSpecificationsOnDemandSpecificationProperty | cdktn.IResolvable): any;
export declare function awsEmrClusterCoreInstanceFleetLaunchSpecificationsOnDemandSpecificationPropertyToHclTerraform(struct?: AwsEmrCluster.CoreInstanceFleetLaunchSpecificationsOnDemandSpecificationProperty | cdktn.IResolvable): any;
export declare function awsEmrClusterCoreInstanceFleetLaunchSpecificationsSpotSpecificationPropertyToTerraform(struct?: AwsEmrCluster.CoreInstanceFleetLaunchSpecificationsSpotSpecificationProperty | cdktn.IResolvable): any;
export declare function awsEmrClusterCoreInstanceFleetLaunchSpecificationsSpotSpecificationPropertyToHclTerraform(struct?: AwsEmrCluster.CoreInstanceFleetLaunchSpecificationsSpotSpecificationProperty | cdktn.IResolvable): any;
export declare function awsEmrClusterCoreInstanceFleetLaunchSpecificationsPropertyToTerraform(struct?: AwsEmrCluster.CoreInstanceFleetLaunchSpecificationsPropertyOutputReference | AwsEmrCluster.CoreInstanceFleetLaunchSpecificationsProperty): any;
export declare function awsEmrClusterCoreInstanceFleetLaunchSpecificationsPropertyToHclTerraform(struct?: AwsEmrCluster.CoreInstanceFleetLaunchSpecificationsPropertyOutputReference | AwsEmrCluster.CoreInstanceFleetLaunchSpecificationsProperty): any;
export declare function awsEmrClusterCoreInstanceFleetPropertyToTerraform(struct?: AwsEmrCluster.CoreInstanceFleetPropertyOutputReference | AwsEmrCluster.CoreInstanceFleetProperty): any;
export declare function awsEmrClusterCoreInstanceFleetPropertyToHclTerraform(struct?: AwsEmrCluster.CoreInstanceFleetPropertyOutputReference | AwsEmrCluster.CoreInstanceFleetProperty): any;
export declare function awsEmrClusterCoreInstanceGroupEbsConfigPropertyToTerraform(struct?: AwsEmrCluster.CoreInstanceGroupEbsConfigProperty | cdktn.IResolvable): any;
export declare function awsEmrClusterCoreInstanceGroupEbsConfigPropertyToHclTerraform(struct?: AwsEmrCluster.CoreInstanceGroupEbsConfigProperty | cdktn.IResolvable): any;
export declare function awsEmrClusterCoreInstanceGroupPropertyToTerraform(struct?: AwsEmrCluster.CoreInstanceGroupPropertyOutputReference | AwsEmrCluster.CoreInstanceGroupProperty): any;
export declare function awsEmrClusterCoreInstanceGroupPropertyToHclTerraform(struct?: AwsEmrCluster.CoreInstanceGroupPropertyOutputReference | AwsEmrCluster.CoreInstanceGroupProperty): any;
export declare function awsEmrClusterEc2AttributesPropertyToTerraform(struct?: AwsEmrCluster.Ec2AttributesPropertyOutputReference | AwsEmrCluster.Ec2AttributesProperty): any;
export declare function awsEmrClusterEc2AttributesPropertyToHclTerraform(struct?: AwsEmrCluster.Ec2AttributesPropertyOutputReference | AwsEmrCluster.Ec2AttributesProperty): any;
export declare function awsEmrClusterKerberosAttributesPropertyToTerraform(struct?: AwsEmrCluster.KerberosAttributesPropertyOutputReference | AwsEmrCluster.KerberosAttributesProperty): any;
export declare function awsEmrClusterKerberosAttributesPropertyToHclTerraform(struct?: AwsEmrCluster.KerberosAttributesPropertyOutputReference | AwsEmrCluster.KerberosAttributesProperty): any;
export declare function awsEmrClusterMasterInstanceFleetInstanceTypeConfigsConfigurationsPropertyToTerraform(struct?: AwsEmrCluster.MasterInstanceFleetInstanceTypeConfigsConfigurationsProperty | cdktn.IResolvable): any;
export declare function awsEmrClusterMasterInstanceFleetInstanceTypeConfigsConfigurationsPropertyToHclTerraform(struct?: AwsEmrCluster.MasterInstanceFleetInstanceTypeConfigsConfigurationsProperty | cdktn.IResolvable): any;
export declare function awsEmrClusterMasterInstanceFleetInstanceTypeConfigsEbsConfigPropertyToTerraform(struct?: AwsEmrCluster.MasterInstanceFleetInstanceTypeConfigsEbsConfigProperty | cdktn.IResolvable): any;
export declare function awsEmrClusterMasterInstanceFleetInstanceTypeConfigsEbsConfigPropertyToHclTerraform(struct?: AwsEmrCluster.MasterInstanceFleetInstanceTypeConfigsEbsConfigProperty | cdktn.IResolvable): any;
export declare function awsEmrClusterMasterInstanceFleetInstanceTypeConfigsPropertyToTerraform(struct?: AwsEmrCluster.MasterInstanceFleetInstanceTypeConfigsProperty | cdktn.IResolvable): any;
export declare function awsEmrClusterMasterInstanceFleetInstanceTypeConfigsPropertyToHclTerraform(struct?: AwsEmrCluster.MasterInstanceFleetInstanceTypeConfigsProperty | cdktn.IResolvable): any;
export declare function awsEmrClusterMasterInstanceFleetLaunchSpecificationsOnDemandSpecificationPropertyToTerraform(struct?: AwsEmrCluster.MasterInstanceFleetLaunchSpecificationsOnDemandSpecificationProperty | cdktn.IResolvable): any;
export declare function awsEmrClusterMasterInstanceFleetLaunchSpecificationsOnDemandSpecificationPropertyToHclTerraform(struct?: AwsEmrCluster.MasterInstanceFleetLaunchSpecificationsOnDemandSpecificationProperty | cdktn.IResolvable): any;
export declare function awsEmrClusterMasterInstanceFleetLaunchSpecificationsSpotSpecificationPropertyToTerraform(struct?: AwsEmrCluster.MasterInstanceFleetLaunchSpecificationsSpotSpecificationProperty | cdktn.IResolvable): any;
export declare function awsEmrClusterMasterInstanceFleetLaunchSpecificationsSpotSpecificationPropertyToHclTerraform(struct?: AwsEmrCluster.MasterInstanceFleetLaunchSpecificationsSpotSpecificationProperty | cdktn.IResolvable): any;
export declare function awsEmrClusterMasterInstanceFleetLaunchSpecificationsPropertyToTerraform(struct?: AwsEmrCluster.MasterInstanceFleetLaunchSpecificationsPropertyOutputReference | AwsEmrCluster.MasterInstanceFleetLaunchSpecificationsProperty): any;
export declare function awsEmrClusterMasterInstanceFleetLaunchSpecificationsPropertyToHclTerraform(struct?: AwsEmrCluster.MasterInstanceFleetLaunchSpecificationsPropertyOutputReference | AwsEmrCluster.MasterInstanceFleetLaunchSpecificationsProperty): any;
export declare function awsEmrClusterMasterInstanceFleetPropertyToTerraform(struct?: AwsEmrCluster.MasterInstanceFleetPropertyOutputReference | AwsEmrCluster.MasterInstanceFleetProperty): any;
export declare function awsEmrClusterMasterInstanceFleetPropertyToHclTerraform(struct?: AwsEmrCluster.MasterInstanceFleetPropertyOutputReference | AwsEmrCluster.MasterInstanceFleetProperty): any;
export declare function awsEmrClusterMasterInstanceGroupEbsConfigPropertyToTerraform(struct?: AwsEmrCluster.MasterInstanceGroupEbsConfigProperty | cdktn.IResolvable): any;
export declare function awsEmrClusterMasterInstanceGroupEbsConfigPropertyToHclTerraform(struct?: AwsEmrCluster.MasterInstanceGroupEbsConfigProperty | cdktn.IResolvable): any;
export declare function awsEmrClusterMasterInstanceGroupPropertyToTerraform(struct?: AwsEmrCluster.MasterInstanceGroupPropertyOutputReference | AwsEmrCluster.MasterInstanceGroupProperty): any;
export declare function awsEmrClusterMasterInstanceGroupPropertyToHclTerraform(struct?: AwsEmrCluster.MasterInstanceGroupPropertyOutputReference | AwsEmrCluster.MasterInstanceGroupProperty): any;
export declare namespace AwsEmrCluster {
    interface PlacementGroupConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#instance_role AwsEmrCluster#instance_role}
        */
        readonly instanceRole?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#placement_strategy AwsEmrCluster#placement_strategy}
        */
        readonly placementStrategy?: string;
    }
    class PlacementGroupConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): PlacementGroupConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: PlacementGroupConfigProperty | cdktn.IResolvable | undefined);
        private _instanceRole?;
        get instanceRole(): string;
        set instanceRole(value: string);
        resetInstanceRole(): void;
        get instanceRoleInput(): string | undefined;
        private _placementStrategy?;
        get placementStrategy(): string;
        set placementStrategy(value: string);
        resetPlacementStrategy(): void;
        get placementStrategyInput(): string | undefined;
    }
    class PlacementGroupConfigPropertyList extends cdktn.ComplexList {
        internalValue?: PlacementGroupConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): PlacementGroupConfigPropertyOutputReference;
    }
    interface HadoopJarStepProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#args AwsEmrCluster#args}
        */
        readonly args?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#jar AwsEmrCluster#jar}
        */
        readonly jar?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#main_class AwsEmrCluster#main_class}
        */
        readonly mainClass?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#properties AwsEmrCluster#properties}
        */
        readonly properties?: {
            [key: string]: string;
        };
    }
    class HadoopJarStepPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): HadoopJarStepProperty | cdktn.IResolvable | undefined;
        set internalValue(value: HadoopJarStepProperty | cdktn.IResolvable | undefined);
        private _args?;
        get args(): string[];
        set args(value: string[]);
        resetArgs(): void;
        get argsInput(): string[] | undefined;
        private _jar?;
        get jar(): string;
        set jar(value: string);
        resetJar(): void;
        get jarInput(): string | undefined;
        private _mainClass?;
        get mainClass(): string;
        set mainClass(value: string);
        resetMainClass(): void;
        get mainClassInput(): string | undefined;
        private _properties?;
        get properties(): {
            [key: string]: string;
        };
        set properties(value: {
            [key: string]: string;
        });
        resetProperties(): void;
        get propertiesInput(): {
            [key: string]: string;
        } | undefined;
    }
    class HadoopJarStepPropertyList extends cdktn.ComplexList {
        internalValue?: HadoopJarStepProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): HadoopJarStepPropertyOutputReference;
    }
    interface StepProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#action_on_failure AwsEmrCluster#action_on_failure}
        */
        readonly actionOnFailure?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#hadoop_jar_step AwsEmrCluster#hadoop_jar_step}
        */
        readonly hadoopJarStep?: HadoopJarStepProperty[] | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#name AwsEmrCluster#name}
        */
        readonly name?: string;
    }
    class StepPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): StepProperty | cdktn.IResolvable | undefined;
        set internalValue(value: StepProperty | cdktn.IResolvable | undefined);
        private _actionOnFailure?;
        get actionOnFailure(): string;
        set actionOnFailure(value: string);
        resetActionOnFailure(): void;
        get actionOnFailureInput(): string | undefined;
        private _hadoopJarStep;
        get hadoopJarStep(): HadoopJarStepPropertyList;
        putHadoopJarStep(value: HadoopJarStepProperty[] | cdktn.IResolvable): void;
        resetHadoopJarStep(): void;
        get hadoopJarStepInput(): cdktn.IResolvable | HadoopJarStepProperty[] | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        resetName(): void;
        get nameInput(): string | undefined;
    }
    class StepPropertyList extends cdktn.ComplexList {
        internalValue?: StepProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): StepPropertyOutputReference;
    }
    interface AutoTerminationPolicyProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#idle_timeout AwsEmrCluster#idle_timeout}
        */
        readonly idleTimeout?: number;
    }
    class AutoTerminationPolicyPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AutoTerminationPolicyProperty | undefined;
        set internalValue(value: AutoTerminationPolicyProperty | undefined);
        private _idleTimeout?;
        get idleTimeout(): number;
        set idleTimeout(value: number);
        resetIdleTimeout(): void;
        get idleTimeoutInput(): number | undefined;
    }
    interface BootstrapActionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#args AwsEmrCluster#args}
        */
        readonly args?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#name AwsEmrCluster#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#path AwsEmrCluster#path}
        */
        readonly path: string;
    }
    class BootstrapActionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): BootstrapActionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: BootstrapActionProperty | cdktn.IResolvable | undefined);
        private _args?;
        get args(): string[];
        set args(value: string[]);
        resetArgs(): void;
        get argsInput(): string[] | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _path?;
        get path(): string;
        set path(value: string);
        get pathInput(): string | undefined;
    }
    class BootstrapActionPropertyList extends cdktn.ComplexList {
        internalValue?: BootstrapActionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): BootstrapActionPropertyOutputReference;
    }
    interface CoreInstanceFleetInstanceTypeConfigsConfigurationsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#classification AwsEmrCluster#classification}
        */
        readonly classification?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#properties AwsEmrCluster#properties}
        */
        readonly properties?: {
            [key: string]: string;
        };
    }
    class CoreInstanceFleetInstanceTypeConfigsConfigurationsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CoreInstanceFleetInstanceTypeConfigsConfigurationsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CoreInstanceFleetInstanceTypeConfigsConfigurationsProperty | cdktn.IResolvable | undefined);
        private _classification?;
        get classification(): string;
        set classification(value: string);
        resetClassification(): void;
        get classificationInput(): string | undefined;
        private _properties?;
        get properties(): {
            [key: string]: string;
        };
        set properties(value: {
            [key: string]: string;
        });
        resetProperties(): void;
        get propertiesInput(): {
            [key: string]: string;
        } | undefined;
    }
    class CoreInstanceFleetInstanceTypeConfigsConfigurationsPropertyList extends cdktn.ComplexList {
        internalValue?: CoreInstanceFleetInstanceTypeConfigsConfigurationsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CoreInstanceFleetInstanceTypeConfigsConfigurationsPropertyOutputReference;
    }
    interface CoreInstanceFleetInstanceTypeConfigsEbsConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#iops AwsEmrCluster#iops}
        */
        readonly iops?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#size AwsEmrCluster#size}
        */
        readonly size: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#type AwsEmrCluster#type}
        */
        readonly type: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#volumes_per_instance AwsEmrCluster#volumes_per_instance}
        */
        readonly volumesPerInstance?: number;
    }
    class CoreInstanceFleetInstanceTypeConfigsEbsConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CoreInstanceFleetInstanceTypeConfigsEbsConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CoreInstanceFleetInstanceTypeConfigsEbsConfigProperty | cdktn.IResolvable | undefined);
        private _iops?;
        get iops(): number;
        set iops(value: number);
        resetIops(): void;
        get iopsInput(): number | undefined;
        private _size?;
        get size(): number;
        set size(value: number);
        get sizeInput(): number | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
        private _volumesPerInstance?;
        get volumesPerInstance(): number;
        set volumesPerInstance(value: number);
        resetVolumesPerInstance(): void;
        get volumesPerInstanceInput(): number | undefined;
    }
    class CoreInstanceFleetInstanceTypeConfigsEbsConfigPropertyList extends cdktn.ComplexList {
        internalValue?: CoreInstanceFleetInstanceTypeConfigsEbsConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CoreInstanceFleetInstanceTypeConfigsEbsConfigPropertyOutputReference;
    }
    interface CoreInstanceFleetInstanceTypeConfigsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#bid_price AwsEmrCluster#bid_price}
        */
        readonly bidPrice?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#bid_price_as_percentage_of_on_demand_price AwsEmrCluster#bid_price_as_percentage_of_on_demand_price}
        */
        readonly bidPriceAsPercentageOfOnDemandPrice?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#instance_type AwsEmrCluster#instance_type}
        */
        readonly instanceType: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#weighted_capacity AwsEmrCluster#weighted_capacity}
        */
        readonly weightedCapacity?: number;
        /**
        * configurations block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#configurations AwsEmrCluster#configurations}
        */
        readonly configurations?: CoreInstanceFleetInstanceTypeConfigsConfigurationsProperty[] | cdktn.IResolvable;
        /**
        * ebs_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#ebs_config AwsEmrCluster#ebs_config}
        */
        readonly ebsConfig?: CoreInstanceFleetInstanceTypeConfigsEbsConfigProperty[] | cdktn.IResolvable;
    }
    class CoreInstanceFleetInstanceTypeConfigsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CoreInstanceFleetInstanceTypeConfigsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CoreInstanceFleetInstanceTypeConfigsProperty | cdktn.IResolvable | undefined);
        private _bidPrice?;
        get bidPrice(): string;
        set bidPrice(value: string);
        resetBidPrice(): void;
        get bidPriceInput(): string | undefined;
        private _bidPriceAsPercentageOfOnDemandPrice?;
        get bidPriceAsPercentageOfOnDemandPrice(): number;
        set bidPriceAsPercentageOfOnDemandPrice(value: number);
        resetBidPriceAsPercentageOfOnDemandPrice(): void;
        get bidPriceAsPercentageOfOnDemandPriceInput(): number | undefined;
        private _instanceType?;
        get instanceType(): string;
        set instanceType(value: string);
        get instanceTypeInput(): string | undefined;
        private _weightedCapacity?;
        get weightedCapacity(): number;
        set weightedCapacity(value: number);
        resetWeightedCapacity(): void;
        get weightedCapacityInput(): number | undefined;
        private _configurations;
        get configurations(): CoreInstanceFleetInstanceTypeConfigsConfigurationsPropertyList;
        putConfigurations(value: CoreInstanceFleetInstanceTypeConfigsConfigurationsProperty[] | cdktn.IResolvable): void;
        resetConfigurations(): void;
        get configurationsInput(): cdktn.IResolvable | CoreInstanceFleetInstanceTypeConfigsConfigurationsProperty[] | undefined;
        private _ebsConfig;
        get ebsConfig(): CoreInstanceFleetInstanceTypeConfigsEbsConfigPropertyList;
        putEbsConfig(value: CoreInstanceFleetInstanceTypeConfigsEbsConfigProperty[] | cdktn.IResolvable): void;
        resetEbsConfig(): void;
        get ebsConfigInput(): cdktn.IResolvable | CoreInstanceFleetInstanceTypeConfigsEbsConfigProperty[] | undefined;
    }
    class CoreInstanceFleetInstanceTypeConfigsPropertyList extends cdktn.ComplexList {
        internalValue?: CoreInstanceFleetInstanceTypeConfigsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CoreInstanceFleetInstanceTypeConfigsPropertyOutputReference;
    }
    interface CoreInstanceFleetLaunchSpecificationsOnDemandSpecificationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#allocation_strategy AwsEmrCluster#allocation_strategy}
        */
        readonly allocationStrategy: string;
    }
    class CoreInstanceFleetLaunchSpecificationsOnDemandSpecificationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CoreInstanceFleetLaunchSpecificationsOnDemandSpecificationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CoreInstanceFleetLaunchSpecificationsOnDemandSpecificationProperty | cdktn.IResolvable | undefined);
        private _allocationStrategy?;
        get allocationStrategy(): string;
        set allocationStrategy(value: string);
        get allocationStrategyInput(): string | undefined;
    }
    class CoreInstanceFleetLaunchSpecificationsOnDemandSpecificationPropertyList extends cdktn.ComplexList {
        internalValue?: CoreInstanceFleetLaunchSpecificationsOnDemandSpecificationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CoreInstanceFleetLaunchSpecificationsOnDemandSpecificationPropertyOutputReference;
    }
    interface CoreInstanceFleetLaunchSpecificationsSpotSpecificationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#allocation_strategy AwsEmrCluster#allocation_strategy}
        */
        readonly allocationStrategy: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#block_duration_minutes AwsEmrCluster#block_duration_minutes}
        */
        readonly blockDurationMinutes?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#timeout_action AwsEmrCluster#timeout_action}
        */
        readonly timeoutAction: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#timeout_duration_minutes AwsEmrCluster#timeout_duration_minutes}
        */
        readonly timeoutDurationMinutes: number;
    }
    class CoreInstanceFleetLaunchSpecificationsSpotSpecificationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CoreInstanceFleetLaunchSpecificationsSpotSpecificationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CoreInstanceFleetLaunchSpecificationsSpotSpecificationProperty | cdktn.IResolvable | undefined);
        private _allocationStrategy?;
        get allocationStrategy(): string;
        set allocationStrategy(value: string);
        get allocationStrategyInput(): string | undefined;
        private _blockDurationMinutes?;
        get blockDurationMinutes(): number;
        set blockDurationMinutes(value: number);
        resetBlockDurationMinutes(): void;
        get blockDurationMinutesInput(): number | undefined;
        private _timeoutAction?;
        get timeoutAction(): string;
        set timeoutAction(value: string);
        get timeoutActionInput(): string | undefined;
        private _timeoutDurationMinutes?;
        get timeoutDurationMinutes(): number;
        set timeoutDurationMinutes(value: number);
        get timeoutDurationMinutesInput(): number | undefined;
    }
    class CoreInstanceFleetLaunchSpecificationsSpotSpecificationPropertyList extends cdktn.ComplexList {
        internalValue?: CoreInstanceFleetLaunchSpecificationsSpotSpecificationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CoreInstanceFleetLaunchSpecificationsSpotSpecificationPropertyOutputReference;
    }
    interface CoreInstanceFleetLaunchSpecificationsProperty {
        /**
        * on_demand_specification block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#on_demand_specification AwsEmrCluster#on_demand_specification}
        */
        readonly onDemandSpecification?: CoreInstanceFleetLaunchSpecificationsOnDemandSpecificationProperty[] | cdktn.IResolvable;
        /**
        * spot_specification block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#spot_specification AwsEmrCluster#spot_specification}
        */
        readonly spotSpecification?: CoreInstanceFleetLaunchSpecificationsSpotSpecificationProperty[] | cdktn.IResolvable;
    }
    class CoreInstanceFleetLaunchSpecificationsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CoreInstanceFleetLaunchSpecificationsProperty | undefined;
        set internalValue(value: CoreInstanceFleetLaunchSpecificationsProperty | undefined);
        private _onDemandSpecification;
        get onDemandSpecification(): CoreInstanceFleetLaunchSpecificationsOnDemandSpecificationPropertyList;
        putOnDemandSpecification(value: CoreInstanceFleetLaunchSpecificationsOnDemandSpecificationProperty[] | cdktn.IResolvable): void;
        resetOnDemandSpecification(): void;
        get onDemandSpecificationInput(): cdktn.IResolvable | CoreInstanceFleetLaunchSpecificationsOnDemandSpecificationProperty[] | undefined;
        private _spotSpecification;
        get spotSpecification(): CoreInstanceFleetLaunchSpecificationsSpotSpecificationPropertyList;
        putSpotSpecification(value: CoreInstanceFleetLaunchSpecificationsSpotSpecificationProperty[] | cdktn.IResolvable): void;
        resetSpotSpecification(): void;
        get spotSpecificationInput(): cdktn.IResolvable | CoreInstanceFleetLaunchSpecificationsSpotSpecificationProperty[] | undefined;
    }
    interface CoreInstanceFleetProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#name AwsEmrCluster#name}
        */
        readonly name?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#target_on_demand_capacity AwsEmrCluster#target_on_demand_capacity}
        */
        readonly targetOnDemandCapacity?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#target_spot_capacity AwsEmrCluster#target_spot_capacity}
        */
        readonly targetSpotCapacity?: number;
        /**
        * instance_type_configs block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#instance_type_configs AwsEmrCluster#instance_type_configs}
        */
        readonly instanceTypeConfigs?: CoreInstanceFleetInstanceTypeConfigsProperty[] | cdktn.IResolvable;
        /**
        * launch_specifications block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#launch_specifications AwsEmrCluster#launch_specifications}
        */
        readonly launchSpecifications?: CoreInstanceFleetLaunchSpecificationsProperty;
    }
    class CoreInstanceFleetPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CoreInstanceFleetProperty | undefined;
        set internalValue(value: CoreInstanceFleetProperty | undefined);
        get id(): string;
        private _name?;
        get name(): string;
        set name(value: string);
        resetName(): void;
        get nameInput(): string | undefined;
        get provisionedOnDemandCapacity(): number;
        get provisionedSpotCapacity(): number;
        private _targetOnDemandCapacity?;
        get targetOnDemandCapacity(): number;
        set targetOnDemandCapacity(value: number);
        resetTargetOnDemandCapacity(): void;
        get targetOnDemandCapacityInput(): number | undefined;
        private _targetSpotCapacity?;
        get targetSpotCapacity(): number;
        set targetSpotCapacity(value: number);
        resetTargetSpotCapacity(): void;
        get targetSpotCapacityInput(): number | undefined;
        private _instanceTypeConfigs;
        get instanceTypeConfigs(): CoreInstanceFleetInstanceTypeConfigsPropertyList;
        putInstanceTypeConfigs(value: CoreInstanceFleetInstanceTypeConfigsProperty[] | cdktn.IResolvable): void;
        resetInstanceTypeConfigs(): void;
        get instanceTypeConfigsInput(): cdktn.IResolvable | CoreInstanceFleetInstanceTypeConfigsProperty[] | undefined;
        private _launchSpecifications;
        get launchSpecifications(): CoreInstanceFleetLaunchSpecificationsPropertyOutputReference;
        putLaunchSpecifications(value: CoreInstanceFleetLaunchSpecificationsProperty): void;
        resetLaunchSpecifications(): void;
        get launchSpecificationsInput(): CoreInstanceFleetLaunchSpecificationsProperty | undefined;
    }
    interface CoreInstanceGroupEbsConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#iops AwsEmrCluster#iops}
        */
        readonly iops?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#size AwsEmrCluster#size}
        */
        readonly size: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#throughput AwsEmrCluster#throughput}
        */
        readonly throughput?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#type AwsEmrCluster#type}
        */
        readonly type: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#volumes_per_instance AwsEmrCluster#volumes_per_instance}
        */
        readonly volumesPerInstance?: number;
    }
    class CoreInstanceGroupEbsConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CoreInstanceGroupEbsConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CoreInstanceGroupEbsConfigProperty | cdktn.IResolvable | undefined);
        private _iops?;
        get iops(): number;
        set iops(value: number);
        resetIops(): void;
        get iopsInput(): number | undefined;
        private _size?;
        get size(): number;
        set size(value: number);
        get sizeInput(): number | undefined;
        private _throughput?;
        get throughput(): number;
        set throughput(value: number);
        resetThroughput(): void;
        get throughputInput(): number | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
        private _volumesPerInstance?;
        get volumesPerInstance(): number;
        set volumesPerInstance(value: number);
        resetVolumesPerInstance(): void;
        get volumesPerInstanceInput(): number | undefined;
    }
    class CoreInstanceGroupEbsConfigPropertyList extends cdktn.ComplexList {
        internalValue?: CoreInstanceGroupEbsConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CoreInstanceGroupEbsConfigPropertyOutputReference;
    }
    interface CoreInstanceGroupProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#autoscaling_policy AwsEmrCluster#autoscaling_policy}
        */
        readonly autoscalingPolicy?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#bid_price AwsEmrCluster#bid_price}
        */
        readonly bidPrice?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#instance_count AwsEmrCluster#instance_count}
        */
        readonly instanceCount?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#instance_type AwsEmrCluster#instance_type}
        */
        readonly instanceType: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#name AwsEmrCluster#name}
        */
        readonly name?: string;
        /**
        * ebs_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#ebs_config AwsEmrCluster#ebs_config}
        */
        readonly ebsConfig?: CoreInstanceGroupEbsConfigProperty[] | cdktn.IResolvable;
    }
    class CoreInstanceGroupPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CoreInstanceGroupProperty | undefined;
        set internalValue(value: CoreInstanceGroupProperty | undefined);
        private _autoscalingPolicy?;
        get autoscalingPolicy(): string;
        set autoscalingPolicy(value: string);
        resetAutoscalingPolicy(): void;
        get autoscalingPolicyInput(): string | undefined;
        private _bidPrice?;
        get bidPrice(): string;
        set bidPrice(value: string);
        resetBidPrice(): void;
        get bidPriceInput(): string | undefined;
        get id(): string;
        private _instanceCount?;
        get instanceCount(): number;
        set instanceCount(value: number);
        resetInstanceCount(): void;
        get instanceCountInput(): number | undefined;
        private _instanceType?;
        get instanceType(): string;
        set instanceType(value: string);
        get instanceTypeInput(): string | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        resetName(): void;
        get nameInput(): string | undefined;
        private _ebsConfig;
        get ebsConfig(): CoreInstanceGroupEbsConfigPropertyList;
        putEbsConfig(value: CoreInstanceGroupEbsConfigProperty[] | cdktn.IResolvable): void;
        resetEbsConfig(): void;
        get ebsConfigInput(): cdktn.IResolvable | CoreInstanceGroupEbsConfigProperty[] | undefined;
    }
    interface Ec2AttributesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#additional_master_security_groups AwsEmrCluster#additional_master_security_groups}
        */
        readonly additionalMasterSecurityGroups?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#additional_slave_security_groups AwsEmrCluster#additional_slave_security_groups}
        */
        readonly additionalSlaveSecurityGroups?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#emr_managed_master_security_group AwsEmrCluster#emr_managed_master_security_group}
        */
        readonly emrManagedMasterSecurityGroup?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#emr_managed_slave_security_group AwsEmrCluster#emr_managed_slave_security_group}
        */
        readonly emrManagedSlaveSecurityGroup?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#instance_profile AwsEmrCluster#instance_profile}
        */
        readonly instanceProfile: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#key_name AwsEmrCluster#key_name}
        */
        readonly keyName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#service_access_security_group AwsEmrCluster#service_access_security_group}
        */
        readonly serviceAccessSecurityGroup?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#subnet_id AwsEmrCluster#subnet_id}
        */
        readonly subnetId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#subnet_ids AwsEmrCluster#subnet_ids}
        */
        readonly subnetIds?: string[];
    }
    class Ec2AttributesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): Ec2AttributesProperty | undefined;
        set internalValue(value: Ec2AttributesProperty | undefined);
        private _additionalMasterSecurityGroups?;
        get additionalMasterSecurityGroups(): string;
        set additionalMasterSecurityGroups(value: string);
        resetAdditionalMasterSecurityGroups(): void;
        get additionalMasterSecurityGroupsInput(): string | undefined;
        private _additionalSlaveSecurityGroups?;
        get additionalSlaveSecurityGroups(): string;
        set additionalSlaveSecurityGroups(value: string);
        resetAdditionalSlaveSecurityGroups(): void;
        get additionalSlaveSecurityGroupsInput(): string | undefined;
        private _emrManagedMasterSecurityGroup?;
        get emrManagedMasterSecurityGroup(): string;
        set emrManagedMasterSecurityGroup(value: string);
        resetEmrManagedMasterSecurityGroup(): void;
        get emrManagedMasterSecurityGroupInput(): string | undefined;
        private _emrManagedSlaveSecurityGroup?;
        get emrManagedSlaveSecurityGroup(): string;
        set emrManagedSlaveSecurityGroup(value: string);
        resetEmrManagedSlaveSecurityGroup(): void;
        get emrManagedSlaveSecurityGroupInput(): string | undefined;
        private _instanceProfile?;
        get instanceProfile(): string;
        set instanceProfile(value: string);
        get instanceProfileInput(): string | undefined;
        private _keyName?;
        get keyName(): string;
        set keyName(value: string);
        resetKeyName(): void;
        get keyNameInput(): string | undefined;
        private _serviceAccessSecurityGroup?;
        get serviceAccessSecurityGroup(): string;
        set serviceAccessSecurityGroup(value: string);
        resetServiceAccessSecurityGroup(): void;
        get serviceAccessSecurityGroupInput(): string | undefined;
        private _subnetId?;
        get subnetId(): string;
        set subnetId(value: string);
        resetSubnetId(): void;
        get subnetIdInput(): string | undefined;
        private _subnetIds?;
        get subnetIds(): string[];
        set subnetIds(value: string[]);
        resetSubnetIds(): void;
        get subnetIdsInput(): string[] | undefined;
    }
    interface KerberosAttributesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#ad_domain_join_password AwsEmrCluster#ad_domain_join_password}
        */
        readonly adDomainJoinPassword?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#ad_domain_join_user AwsEmrCluster#ad_domain_join_user}
        */
        readonly adDomainJoinUser?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#cross_realm_trust_principal_password AwsEmrCluster#cross_realm_trust_principal_password}
        */
        readonly crossRealmTrustPrincipalPassword?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#kdc_admin_password AwsEmrCluster#kdc_admin_password}
        */
        readonly kdcAdminPassword: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#realm AwsEmrCluster#realm}
        */
        readonly realm: string;
    }
    class KerberosAttributesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): KerberosAttributesProperty | undefined;
        set internalValue(value: KerberosAttributesProperty | undefined);
        private _adDomainJoinPassword?;
        get adDomainJoinPassword(): string;
        set adDomainJoinPassword(value: string);
        resetAdDomainJoinPassword(): void;
        get adDomainJoinPasswordInput(): string | undefined;
        private _adDomainJoinUser?;
        get adDomainJoinUser(): string;
        set adDomainJoinUser(value: string);
        resetAdDomainJoinUser(): void;
        get adDomainJoinUserInput(): string | undefined;
        private _crossRealmTrustPrincipalPassword?;
        get crossRealmTrustPrincipalPassword(): string;
        set crossRealmTrustPrincipalPassword(value: string);
        resetCrossRealmTrustPrincipalPassword(): void;
        get crossRealmTrustPrincipalPasswordInput(): string | undefined;
        private _kdcAdminPassword?;
        get kdcAdminPassword(): string;
        set kdcAdminPassword(value: string);
        get kdcAdminPasswordInput(): string | undefined;
        private _realm?;
        get realm(): string;
        set realm(value: string);
        get realmInput(): string | undefined;
    }
    interface MasterInstanceFleetInstanceTypeConfigsConfigurationsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#classification AwsEmrCluster#classification}
        */
        readonly classification?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#properties AwsEmrCluster#properties}
        */
        readonly properties?: {
            [key: string]: string;
        };
    }
    class MasterInstanceFleetInstanceTypeConfigsConfigurationsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): MasterInstanceFleetInstanceTypeConfigsConfigurationsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: MasterInstanceFleetInstanceTypeConfigsConfigurationsProperty | cdktn.IResolvable | undefined);
        private _classification?;
        get classification(): string;
        set classification(value: string);
        resetClassification(): void;
        get classificationInput(): string | undefined;
        private _properties?;
        get properties(): {
            [key: string]: string;
        };
        set properties(value: {
            [key: string]: string;
        });
        resetProperties(): void;
        get propertiesInput(): {
            [key: string]: string;
        } | undefined;
    }
    class MasterInstanceFleetInstanceTypeConfigsConfigurationsPropertyList extends cdktn.ComplexList {
        internalValue?: MasterInstanceFleetInstanceTypeConfigsConfigurationsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): MasterInstanceFleetInstanceTypeConfigsConfigurationsPropertyOutputReference;
    }
    interface MasterInstanceFleetInstanceTypeConfigsEbsConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#iops AwsEmrCluster#iops}
        */
        readonly iops?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#size AwsEmrCluster#size}
        */
        readonly size: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#type AwsEmrCluster#type}
        */
        readonly type: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#volumes_per_instance AwsEmrCluster#volumes_per_instance}
        */
        readonly volumesPerInstance?: number;
    }
    class MasterInstanceFleetInstanceTypeConfigsEbsConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): MasterInstanceFleetInstanceTypeConfigsEbsConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: MasterInstanceFleetInstanceTypeConfigsEbsConfigProperty | cdktn.IResolvable | undefined);
        private _iops?;
        get iops(): number;
        set iops(value: number);
        resetIops(): void;
        get iopsInput(): number | undefined;
        private _size?;
        get size(): number;
        set size(value: number);
        get sizeInput(): number | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
        private _volumesPerInstance?;
        get volumesPerInstance(): number;
        set volumesPerInstance(value: number);
        resetVolumesPerInstance(): void;
        get volumesPerInstanceInput(): number | undefined;
    }
    class MasterInstanceFleetInstanceTypeConfigsEbsConfigPropertyList extends cdktn.ComplexList {
        internalValue?: MasterInstanceFleetInstanceTypeConfigsEbsConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): MasterInstanceFleetInstanceTypeConfigsEbsConfigPropertyOutputReference;
    }
    interface MasterInstanceFleetInstanceTypeConfigsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#bid_price AwsEmrCluster#bid_price}
        */
        readonly bidPrice?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#bid_price_as_percentage_of_on_demand_price AwsEmrCluster#bid_price_as_percentage_of_on_demand_price}
        */
        readonly bidPriceAsPercentageOfOnDemandPrice?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#instance_type AwsEmrCluster#instance_type}
        */
        readonly instanceType: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#weighted_capacity AwsEmrCluster#weighted_capacity}
        */
        readonly weightedCapacity?: number;
        /**
        * configurations block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#configurations AwsEmrCluster#configurations}
        */
        readonly configurations?: MasterInstanceFleetInstanceTypeConfigsConfigurationsProperty[] | cdktn.IResolvable;
        /**
        * ebs_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#ebs_config AwsEmrCluster#ebs_config}
        */
        readonly ebsConfig?: MasterInstanceFleetInstanceTypeConfigsEbsConfigProperty[] | cdktn.IResolvable;
    }
    class MasterInstanceFleetInstanceTypeConfigsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): MasterInstanceFleetInstanceTypeConfigsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: MasterInstanceFleetInstanceTypeConfigsProperty | cdktn.IResolvable | undefined);
        private _bidPrice?;
        get bidPrice(): string;
        set bidPrice(value: string);
        resetBidPrice(): void;
        get bidPriceInput(): string | undefined;
        private _bidPriceAsPercentageOfOnDemandPrice?;
        get bidPriceAsPercentageOfOnDemandPrice(): number;
        set bidPriceAsPercentageOfOnDemandPrice(value: number);
        resetBidPriceAsPercentageOfOnDemandPrice(): void;
        get bidPriceAsPercentageOfOnDemandPriceInput(): number | undefined;
        private _instanceType?;
        get instanceType(): string;
        set instanceType(value: string);
        get instanceTypeInput(): string | undefined;
        private _weightedCapacity?;
        get weightedCapacity(): number;
        set weightedCapacity(value: number);
        resetWeightedCapacity(): void;
        get weightedCapacityInput(): number | undefined;
        private _configurations;
        get configurations(): MasterInstanceFleetInstanceTypeConfigsConfigurationsPropertyList;
        putConfigurations(value: MasterInstanceFleetInstanceTypeConfigsConfigurationsProperty[] | cdktn.IResolvable): void;
        resetConfigurations(): void;
        get configurationsInput(): cdktn.IResolvable | MasterInstanceFleetInstanceTypeConfigsConfigurationsProperty[] | undefined;
        private _ebsConfig;
        get ebsConfig(): MasterInstanceFleetInstanceTypeConfigsEbsConfigPropertyList;
        putEbsConfig(value: MasterInstanceFleetInstanceTypeConfigsEbsConfigProperty[] | cdktn.IResolvable): void;
        resetEbsConfig(): void;
        get ebsConfigInput(): cdktn.IResolvable | MasterInstanceFleetInstanceTypeConfigsEbsConfigProperty[] | undefined;
    }
    class MasterInstanceFleetInstanceTypeConfigsPropertyList extends cdktn.ComplexList {
        internalValue?: MasterInstanceFleetInstanceTypeConfigsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): MasterInstanceFleetInstanceTypeConfigsPropertyOutputReference;
    }
    interface MasterInstanceFleetLaunchSpecificationsOnDemandSpecificationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#allocation_strategy AwsEmrCluster#allocation_strategy}
        */
        readonly allocationStrategy: string;
    }
    class MasterInstanceFleetLaunchSpecificationsOnDemandSpecificationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): MasterInstanceFleetLaunchSpecificationsOnDemandSpecificationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: MasterInstanceFleetLaunchSpecificationsOnDemandSpecificationProperty | cdktn.IResolvable | undefined);
        private _allocationStrategy?;
        get allocationStrategy(): string;
        set allocationStrategy(value: string);
        get allocationStrategyInput(): string | undefined;
    }
    class MasterInstanceFleetLaunchSpecificationsOnDemandSpecificationPropertyList extends cdktn.ComplexList {
        internalValue?: MasterInstanceFleetLaunchSpecificationsOnDemandSpecificationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): MasterInstanceFleetLaunchSpecificationsOnDemandSpecificationPropertyOutputReference;
    }
    interface MasterInstanceFleetLaunchSpecificationsSpotSpecificationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#allocation_strategy AwsEmrCluster#allocation_strategy}
        */
        readonly allocationStrategy: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#block_duration_minutes AwsEmrCluster#block_duration_minutes}
        */
        readonly blockDurationMinutes?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#timeout_action AwsEmrCluster#timeout_action}
        */
        readonly timeoutAction: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#timeout_duration_minutes AwsEmrCluster#timeout_duration_minutes}
        */
        readonly timeoutDurationMinutes: number;
    }
    class MasterInstanceFleetLaunchSpecificationsSpotSpecificationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): MasterInstanceFleetLaunchSpecificationsSpotSpecificationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: MasterInstanceFleetLaunchSpecificationsSpotSpecificationProperty | cdktn.IResolvable | undefined);
        private _allocationStrategy?;
        get allocationStrategy(): string;
        set allocationStrategy(value: string);
        get allocationStrategyInput(): string | undefined;
        private _blockDurationMinutes?;
        get blockDurationMinutes(): number;
        set blockDurationMinutes(value: number);
        resetBlockDurationMinutes(): void;
        get blockDurationMinutesInput(): number | undefined;
        private _timeoutAction?;
        get timeoutAction(): string;
        set timeoutAction(value: string);
        get timeoutActionInput(): string | undefined;
        private _timeoutDurationMinutes?;
        get timeoutDurationMinutes(): number;
        set timeoutDurationMinutes(value: number);
        get timeoutDurationMinutesInput(): number | undefined;
    }
    class MasterInstanceFleetLaunchSpecificationsSpotSpecificationPropertyList extends cdktn.ComplexList {
        internalValue?: MasterInstanceFleetLaunchSpecificationsSpotSpecificationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): MasterInstanceFleetLaunchSpecificationsSpotSpecificationPropertyOutputReference;
    }
    interface MasterInstanceFleetLaunchSpecificationsProperty {
        /**
        * on_demand_specification block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#on_demand_specification AwsEmrCluster#on_demand_specification}
        */
        readonly onDemandSpecification?: MasterInstanceFleetLaunchSpecificationsOnDemandSpecificationProperty[] | cdktn.IResolvable;
        /**
        * spot_specification block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#spot_specification AwsEmrCluster#spot_specification}
        */
        readonly spotSpecification?: MasterInstanceFleetLaunchSpecificationsSpotSpecificationProperty[] | cdktn.IResolvable;
    }
    class MasterInstanceFleetLaunchSpecificationsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): MasterInstanceFleetLaunchSpecificationsProperty | undefined;
        set internalValue(value: MasterInstanceFleetLaunchSpecificationsProperty | undefined);
        private _onDemandSpecification;
        get onDemandSpecification(): MasterInstanceFleetLaunchSpecificationsOnDemandSpecificationPropertyList;
        putOnDemandSpecification(value: MasterInstanceFleetLaunchSpecificationsOnDemandSpecificationProperty[] | cdktn.IResolvable): void;
        resetOnDemandSpecification(): void;
        get onDemandSpecificationInput(): cdktn.IResolvable | MasterInstanceFleetLaunchSpecificationsOnDemandSpecificationProperty[] | undefined;
        private _spotSpecification;
        get spotSpecification(): MasterInstanceFleetLaunchSpecificationsSpotSpecificationPropertyList;
        putSpotSpecification(value: MasterInstanceFleetLaunchSpecificationsSpotSpecificationProperty[] | cdktn.IResolvable): void;
        resetSpotSpecification(): void;
        get spotSpecificationInput(): cdktn.IResolvable | MasterInstanceFleetLaunchSpecificationsSpotSpecificationProperty[] | undefined;
    }
    interface MasterInstanceFleetProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#name AwsEmrCluster#name}
        */
        readonly name?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#target_on_demand_capacity AwsEmrCluster#target_on_demand_capacity}
        */
        readonly targetOnDemandCapacity?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#target_spot_capacity AwsEmrCluster#target_spot_capacity}
        */
        readonly targetSpotCapacity?: number;
        /**
        * instance_type_configs block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#instance_type_configs AwsEmrCluster#instance_type_configs}
        */
        readonly instanceTypeConfigs?: MasterInstanceFleetInstanceTypeConfigsProperty[] | cdktn.IResolvable;
        /**
        * launch_specifications block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#launch_specifications AwsEmrCluster#launch_specifications}
        */
        readonly launchSpecifications?: MasterInstanceFleetLaunchSpecificationsProperty;
    }
    class MasterInstanceFleetPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): MasterInstanceFleetProperty | undefined;
        set internalValue(value: MasterInstanceFleetProperty | undefined);
        get id(): string;
        private _name?;
        get name(): string;
        set name(value: string);
        resetName(): void;
        get nameInput(): string | undefined;
        get provisionedOnDemandCapacity(): number;
        get provisionedSpotCapacity(): number;
        private _targetOnDemandCapacity?;
        get targetOnDemandCapacity(): number;
        set targetOnDemandCapacity(value: number);
        resetTargetOnDemandCapacity(): void;
        get targetOnDemandCapacityInput(): number | undefined;
        private _targetSpotCapacity?;
        get targetSpotCapacity(): number;
        set targetSpotCapacity(value: number);
        resetTargetSpotCapacity(): void;
        get targetSpotCapacityInput(): number | undefined;
        private _instanceTypeConfigs;
        get instanceTypeConfigs(): MasterInstanceFleetInstanceTypeConfigsPropertyList;
        putInstanceTypeConfigs(value: MasterInstanceFleetInstanceTypeConfigsProperty[] | cdktn.IResolvable): void;
        resetInstanceTypeConfigs(): void;
        get instanceTypeConfigsInput(): cdktn.IResolvable | MasterInstanceFleetInstanceTypeConfigsProperty[] | undefined;
        private _launchSpecifications;
        get launchSpecifications(): MasterInstanceFleetLaunchSpecificationsPropertyOutputReference;
        putLaunchSpecifications(value: MasterInstanceFleetLaunchSpecificationsProperty): void;
        resetLaunchSpecifications(): void;
        get launchSpecificationsInput(): MasterInstanceFleetLaunchSpecificationsProperty | undefined;
    }
    interface MasterInstanceGroupEbsConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#iops AwsEmrCluster#iops}
        */
        readonly iops?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#size AwsEmrCluster#size}
        */
        readonly size: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#throughput AwsEmrCluster#throughput}
        */
        readonly throughput?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#type AwsEmrCluster#type}
        */
        readonly type: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#volumes_per_instance AwsEmrCluster#volumes_per_instance}
        */
        readonly volumesPerInstance?: number;
    }
    class MasterInstanceGroupEbsConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): MasterInstanceGroupEbsConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: MasterInstanceGroupEbsConfigProperty | cdktn.IResolvable | undefined);
        private _iops?;
        get iops(): number;
        set iops(value: number);
        resetIops(): void;
        get iopsInput(): number | undefined;
        private _size?;
        get size(): number;
        set size(value: number);
        get sizeInput(): number | undefined;
        private _throughput?;
        get throughput(): number;
        set throughput(value: number);
        resetThroughput(): void;
        get throughputInput(): number | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
        private _volumesPerInstance?;
        get volumesPerInstance(): number;
        set volumesPerInstance(value: number);
        resetVolumesPerInstance(): void;
        get volumesPerInstanceInput(): number | undefined;
    }
    class MasterInstanceGroupEbsConfigPropertyList extends cdktn.ComplexList {
        internalValue?: MasterInstanceGroupEbsConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): MasterInstanceGroupEbsConfigPropertyOutputReference;
    }
    interface MasterInstanceGroupProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#bid_price AwsEmrCluster#bid_price}
        */
        readonly bidPrice?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#instance_count AwsEmrCluster#instance_count}
        */
        readonly instanceCount?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#instance_type AwsEmrCluster#instance_type}
        */
        readonly instanceType: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#name AwsEmrCluster#name}
        */
        readonly name?: string;
        /**
        * ebs_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_cluster#ebs_config AwsEmrCluster#ebs_config}
        */
        readonly ebsConfig?: MasterInstanceGroupEbsConfigProperty[] | cdktn.IResolvable;
    }
    class MasterInstanceGroupPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): MasterInstanceGroupProperty | undefined;
        set internalValue(value: MasterInstanceGroupProperty | undefined);
        private _bidPrice?;
        get bidPrice(): string;
        set bidPrice(value: string);
        resetBidPrice(): void;
        get bidPriceInput(): string | undefined;
        get id(): string;
        private _instanceCount?;
        get instanceCount(): number;
        set instanceCount(value: number);
        resetInstanceCount(): void;
        get instanceCountInput(): number | undefined;
        private _instanceType?;
        get instanceType(): string;
        set instanceType(value: string);
        get instanceTypeInput(): string | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        resetName(): void;
        get nameInput(): string | undefined;
        private _ebsConfig;
        get ebsConfig(): MasterInstanceGroupEbsConfigPropertyList;
        putEbsConfig(value: MasterInstanceGroupEbsConfigProperty[] | cdktn.IResolvable): void;
        resetEbsConfig(): void;
        get ebsConfigInput(): cdktn.IResolvable | MasterInstanceGroupEbsConfigProperty[] | undefined;
    }
}
