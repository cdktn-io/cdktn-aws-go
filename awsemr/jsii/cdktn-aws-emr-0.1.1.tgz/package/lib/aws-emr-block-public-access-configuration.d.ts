import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsEmrBlockPublicAccessConfigurationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_block_public_access_configuration#block_public_security_group_rules AwsEmrBlockPublicAccessConfiguration#block_public_security_group_rules}
    */
    readonly blockPublicSecurityGroupRules: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_block_public_access_configuration#id AwsEmrBlockPublicAccessConfiguration#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_block_public_access_configuration#region AwsEmrBlockPublicAccessConfiguration#region}
    */
    readonly region?: string;
    /**
    * permitted_public_security_group_rule_range block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_block_public_access_configuration#permitted_public_security_group_rule_range AwsEmrBlockPublicAccessConfiguration#permitted_public_security_group_rule_range}
    */
    readonly permittedPublicSecurityGroupRuleRange?: AwsEmrBlockPublicAccessConfiguration.PermittedPublicSecurityGroupRuleRangeProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_block_public_access_configuration aws_emr_block_public_access_configuration}
*/
export declare class AwsEmrBlockPublicAccessConfiguration extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_emr_block_public_access_configuration";
    /**
    * Generates CDKTN code for importing a AwsEmrBlockPublicAccessConfiguration resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsEmrBlockPublicAccessConfiguration to import
    * @param importFromId The id of the existing AwsEmrBlockPublicAccessConfiguration that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_block_public_access_configuration#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsEmrBlockPublicAccessConfiguration to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_block_public_access_configuration aws_emr_block_public_access_configuration} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsEmrBlockPublicAccessConfigurationConfig
    */
    constructor(scope: Construct, id: string, config: AwsEmrBlockPublicAccessConfigurationConfig);
    private _blockPublicSecurityGroupRules?;
    get blockPublicSecurityGroupRules(): boolean | cdktn.IResolvable;
    set blockPublicSecurityGroupRules(value: boolean | cdktn.IResolvable);
    get blockPublicSecurityGroupRulesInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _permittedPublicSecurityGroupRuleRange;
    get permittedPublicSecurityGroupRuleRange(): AwsEmrBlockPublicAccessConfiguration.PermittedPublicSecurityGroupRuleRangePropertyList;
    putPermittedPublicSecurityGroupRuleRange(value: AwsEmrBlockPublicAccessConfiguration.PermittedPublicSecurityGroupRuleRangeProperty[] | cdktn.IResolvable): void;
    resetPermittedPublicSecurityGroupRuleRange(): void;
    get permittedPublicSecurityGroupRuleRangeInput(): cdktn.IResolvable | AwsEmrBlockPublicAccessConfiguration.PermittedPublicSecurityGroupRuleRangeProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsEmrBlockPublicAccessConfigurationPermittedPublicSecurityGroupRuleRangePropertyToTerraform(struct?: AwsEmrBlockPublicAccessConfiguration.PermittedPublicSecurityGroupRuleRangeProperty | cdktn.IResolvable): any;
export declare function awsEmrBlockPublicAccessConfigurationPermittedPublicSecurityGroupRuleRangePropertyToHclTerraform(struct?: AwsEmrBlockPublicAccessConfiguration.PermittedPublicSecurityGroupRuleRangeProperty | cdktn.IResolvable): any;
export declare namespace AwsEmrBlockPublicAccessConfiguration {
    interface PermittedPublicSecurityGroupRuleRangeProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_block_public_access_configuration#max_range AwsEmrBlockPublicAccessConfiguration#max_range}
        */
        readonly maxRange: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emr_block_public_access_configuration#min_range AwsEmrBlockPublicAccessConfiguration#min_range}
        */
        readonly minRange: number;
    }
    class PermittedPublicSecurityGroupRuleRangePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): PermittedPublicSecurityGroupRuleRangeProperty | cdktn.IResolvable | undefined;
        set internalValue(value: PermittedPublicSecurityGroupRuleRangeProperty | cdktn.IResolvable | undefined);
        private _maxRange?;
        get maxRange(): number;
        set maxRange(value: number);
        get maxRangeInput(): number | undefined;
        private _minRange?;
        get minRange(): number;
        set minRange(value: number);
        get minRangeInput(): number | undefined;
    }
    class PermittedPublicSecurityGroupRuleRangePropertyList extends cdktn.ComplexList {
        internalValue?: PermittedPublicSecurityGroupRuleRangeProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): PermittedPublicSecurityGroupRuleRangePropertyOutputReference;
    }
}
