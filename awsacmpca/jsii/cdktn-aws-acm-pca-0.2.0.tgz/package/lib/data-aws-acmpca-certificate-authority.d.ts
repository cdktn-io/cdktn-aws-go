import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataTfCertificateAuthorityConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/acmpca_certificate_authority#arn DataTfCertificateAuthority#arn}
    */
    readonly arn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/acmpca_certificate_authority#id DataTfCertificateAuthority#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/acmpca_certificate_authority#region DataTfCertificateAuthority#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/acmpca_certificate_authority#tags DataTfCertificateAuthority#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/acmpca_certificate_authority aws_acmpca_certificate_authority}
*/
export declare class DataTfCertificateAuthority extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_acmpca_certificate_authority";
    /**
    * Generates CDKTN code for importing a DataTfCertificateAuthority resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataTfCertificateAuthority to import
    * @param importFromId The id of the existing DataTfCertificateAuthority that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/acmpca_certificate_authority#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataTfCertificateAuthority to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/acmpca_certificate_authority aws_acmpca_certificate_authority} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataTfCertificateAuthorityConfig
    */
    constructor(scope: Construct, id: string, config: DataTfCertificateAuthorityConfig);
    private _arn?;
    get arn(): string;
    set arn(value: string);
    get arnInput(): string | undefined;
    get certificate(): string;
    get certificateChain(): string;
    get certificateSigningRequest(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get keyStorageSecurityStandard(): string;
    get notAfter(): string;
    get notBefore(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _revocationConfiguration;
    get revocationConfiguration(): DataTfCertificateAuthority.RevocationConfigurationPropertyList;
    get serial(): string;
    get status(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    get type(): string;
    get usageMode(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataTfCertificateAuthorityCrlConfigurationPropertyToTerraform(struct?: DataTfCertificateAuthority.CrlConfigurationProperty): any;
export declare function dataTfCertificateAuthorityCrlConfigurationPropertyToHclTerraform(struct?: DataTfCertificateAuthority.CrlConfigurationProperty): any;
export declare function dataTfCertificateAuthorityOcspConfigurationPropertyToTerraform(struct?: DataTfCertificateAuthority.OcspConfigurationProperty): any;
export declare function dataTfCertificateAuthorityOcspConfigurationPropertyToHclTerraform(struct?: DataTfCertificateAuthority.OcspConfigurationProperty): any;
export declare function dataTfCertificateAuthorityRevocationConfigurationPropertyToTerraform(struct?: DataTfCertificateAuthority.RevocationConfigurationProperty): any;
export declare function dataTfCertificateAuthorityRevocationConfigurationPropertyToHclTerraform(struct?: DataTfCertificateAuthority.RevocationConfigurationProperty): any;
export declare namespace DataTfCertificateAuthority {
    interface CrlConfigurationProperty {
    }
    class CrlConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CrlConfigurationProperty | undefined;
        set internalValue(value: CrlConfigurationProperty | undefined);
        get customCname(): string;
        get customPath(): string;
        get enabled(): cdktn.IResolvable;
        get expirationInDays(): number;
        get s3BucketName(): string;
        get s3ObjectAcl(): string;
    }
    class CrlConfigurationPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CrlConfigurationPropertyOutputReference;
    }
    interface OcspConfigurationProperty {
    }
    class OcspConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): OcspConfigurationProperty | undefined;
        set internalValue(value: OcspConfigurationProperty | undefined);
        get enabled(): cdktn.IResolvable;
        get ocspCustomCname(): string;
    }
    class OcspConfigurationPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): OcspConfigurationPropertyOutputReference;
    }
    interface RevocationConfigurationProperty {
    }
    class RevocationConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RevocationConfigurationProperty | undefined;
        set internalValue(value: RevocationConfigurationProperty | undefined);
        private _crlConfiguration;
        get crlConfiguration(): CrlConfigurationPropertyList;
        private _ocspConfiguration;
        get ocspConfiguration(): OcspConfigurationPropertyList;
    }
    class RevocationConfigurationPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RevocationConfigurationPropertyOutputReference;
    }
}
