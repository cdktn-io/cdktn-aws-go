import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfCertificateAuthorityConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/acmpca_certificate_authority#enabled TfCertificateAuthority#enabled}
    */
    readonly enabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/acmpca_certificate_authority#id TfCertificateAuthority#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/acmpca_certificate_authority#key_storage_security_standard TfCertificateAuthority#key_storage_security_standard}
    */
    readonly keyStorageSecurityStandard?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/acmpca_certificate_authority#permanent_deletion_time_in_days TfCertificateAuthority#permanent_deletion_time_in_days}
    */
    readonly permanentDeletionTimeInDays?: number;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/acmpca_certificate_authority#region TfCertificateAuthority#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/acmpca_certificate_authority#tags TfCertificateAuthority#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/acmpca_certificate_authority#tags_all TfCertificateAuthority#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/acmpca_certificate_authority#type TfCertificateAuthority#type}
    */
    readonly type?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/acmpca_certificate_authority#usage_mode TfCertificateAuthority#usage_mode}
    */
    readonly usageMode?: string;
    /**
    * certificate_authority_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/acmpca_certificate_authority#certificate_authority_configuration TfCertificateAuthority#certificate_authority_configuration}
    */
    readonly certificateAuthorityConfiguration: TfCertificateAuthority.CertificateAuthorityConfigurationProperty;
    /**
    * revocation_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/acmpca_certificate_authority#revocation_configuration TfCertificateAuthority#revocation_configuration}
    */
    readonly revocationConfiguration?: TfCertificateAuthority.RevocationConfigurationProperty;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/acmpca_certificate_authority#timeouts TfCertificateAuthority#timeouts}
    */
    readonly timeouts?: TfCertificateAuthority.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/acmpca_certificate_authority aws_acmpca_certificate_authority}
*/
export declare class TfCertificateAuthority extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_acmpca_certificate_authority";
    /**
    * Generates CDKTN code for importing a TfCertificateAuthority resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfCertificateAuthority to import
    * @param importFromId The id of the existing TfCertificateAuthority that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/acmpca_certificate_authority#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfCertificateAuthority to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/acmpca_certificate_authority aws_acmpca_certificate_authority} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfCertificateAuthorityConfig
    */
    constructor(scope: Construct, id: string, config: TfCertificateAuthorityConfig);
    get arn(): string;
    get certificate(): string;
    get certificateChain(): string;
    get certificateSigningRequest(): string;
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _keyStorageSecurityStandard?;
    get keyStorageSecurityStandard(): string;
    set keyStorageSecurityStandard(value: string);
    resetKeyStorageSecurityStandard(): void;
    get keyStorageSecurityStandardInput(): string | undefined;
    get notAfter(): string;
    get notBefore(): string;
    private _permanentDeletionTimeInDays?;
    get permanentDeletionTimeInDays(): number;
    set permanentDeletionTimeInDays(value: number);
    resetPermanentDeletionTimeInDays(): void;
    get permanentDeletionTimeInDaysInput(): number | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get serial(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
    private _usageMode?;
    get usageMode(): string;
    set usageMode(value: string);
    resetUsageMode(): void;
    get usageModeInput(): string | undefined;
    private _certificateAuthorityConfiguration;
    get certificateAuthorityConfiguration(): TfCertificateAuthority.CertificateAuthorityConfigurationPropertyOutputReference;
    putCertificateAuthorityConfiguration(value: TfCertificateAuthority.CertificateAuthorityConfigurationProperty): void;
    get certificateAuthorityConfigurationInput(): TfCertificateAuthority.CertificateAuthorityConfigurationProperty | undefined;
    private _revocationConfiguration;
    get revocationConfiguration(): TfCertificateAuthority.RevocationConfigurationPropertyOutputReference;
    putRevocationConfiguration(value: TfCertificateAuthority.RevocationConfigurationProperty): void;
    resetRevocationConfiguration(): void;
    get revocationConfigurationInput(): TfCertificateAuthority.RevocationConfigurationProperty | undefined;
    private _timeouts;
    get timeouts(): TfCertificateAuthority.TimeoutsPropertyOutputReference;
    putTimeouts(value: TfCertificateAuthority.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | TfCertificateAuthority.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfCertificateAuthoritySubjectPropertyToTerraform(struct?: TfCertificateAuthority.SubjectPropertyOutputReference | TfCertificateAuthority.SubjectProperty): any;
export declare function tfCertificateAuthoritySubjectPropertyToHclTerraform(struct?: TfCertificateAuthority.SubjectPropertyOutputReference | TfCertificateAuthority.SubjectProperty): any;
export declare function tfCertificateAuthorityCertificateAuthorityConfigurationPropertyToTerraform(struct?: TfCertificateAuthority.CertificateAuthorityConfigurationPropertyOutputReference | TfCertificateAuthority.CertificateAuthorityConfigurationProperty): any;
export declare function tfCertificateAuthorityCertificateAuthorityConfigurationPropertyToHclTerraform(struct?: TfCertificateAuthority.CertificateAuthorityConfigurationPropertyOutputReference | TfCertificateAuthority.CertificateAuthorityConfigurationProperty): any;
export declare function tfCertificateAuthorityCrlConfigurationPropertyToTerraform(struct?: TfCertificateAuthority.CrlConfigurationPropertyOutputReference | TfCertificateAuthority.CrlConfigurationProperty): any;
export declare function tfCertificateAuthorityCrlConfigurationPropertyToHclTerraform(struct?: TfCertificateAuthority.CrlConfigurationPropertyOutputReference | TfCertificateAuthority.CrlConfigurationProperty): any;
export declare function tfCertificateAuthorityOcspConfigurationPropertyToTerraform(struct?: TfCertificateAuthority.OcspConfigurationPropertyOutputReference | TfCertificateAuthority.OcspConfigurationProperty): any;
export declare function tfCertificateAuthorityOcspConfigurationPropertyToHclTerraform(struct?: TfCertificateAuthority.OcspConfigurationPropertyOutputReference | TfCertificateAuthority.OcspConfigurationProperty): any;
export declare function tfCertificateAuthorityRevocationConfigurationPropertyToTerraform(struct?: TfCertificateAuthority.RevocationConfigurationPropertyOutputReference | TfCertificateAuthority.RevocationConfigurationProperty): any;
export declare function tfCertificateAuthorityRevocationConfigurationPropertyToHclTerraform(struct?: TfCertificateAuthority.RevocationConfigurationPropertyOutputReference | TfCertificateAuthority.RevocationConfigurationProperty): any;
export declare function tfCertificateAuthorityTimeoutsPropertyToTerraform(struct?: TfCertificateAuthority.TimeoutsProperty | cdktn.IResolvable): any;
export declare function tfCertificateAuthorityTimeoutsPropertyToHclTerraform(struct?: TfCertificateAuthority.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace TfCertificateAuthority {
    interface SubjectProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/acmpca_certificate_authority#common_name TfCertificateAuthority#common_name}
        */
        readonly commonName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/acmpca_certificate_authority#country TfCertificateAuthority#country}
        */
        readonly country?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/acmpca_certificate_authority#distinguished_name_qualifier TfCertificateAuthority#distinguished_name_qualifier}
        */
        readonly distinguishedNameQualifier?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/acmpca_certificate_authority#generation_qualifier TfCertificateAuthority#generation_qualifier}
        */
        readonly generationQualifier?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/acmpca_certificate_authority#given_name TfCertificateAuthority#given_name}
        */
        readonly givenName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/acmpca_certificate_authority#initials TfCertificateAuthority#initials}
        */
        readonly initials?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/acmpca_certificate_authority#locality TfCertificateAuthority#locality}
        */
        readonly locality?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/acmpca_certificate_authority#organization TfCertificateAuthority#organization}
        */
        readonly organization?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/acmpca_certificate_authority#organizational_unit TfCertificateAuthority#organizational_unit}
        */
        readonly organizationalUnit?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/acmpca_certificate_authority#pseudonym TfCertificateAuthority#pseudonym}
        */
        readonly pseudonym?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/acmpca_certificate_authority#state TfCertificateAuthority#state}
        */
        readonly state?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/acmpca_certificate_authority#surname TfCertificateAuthority#surname}
        */
        readonly surname?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/acmpca_certificate_authority#title TfCertificateAuthority#title}
        */
        readonly title?: string;
    }
    class SubjectPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SubjectProperty | undefined;
        set internalValue(value: SubjectProperty | undefined);
        private _commonName?;
        get commonName(): string;
        set commonName(value: string);
        resetCommonName(): void;
        get commonNameInput(): string | undefined;
        private _country?;
        get country(): string;
        set country(value: string);
        resetCountry(): void;
        get countryInput(): string | undefined;
        private _distinguishedNameQualifier?;
        get distinguishedNameQualifier(): string;
        set distinguishedNameQualifier(value: string);
        resetDistinguishedNameQualifier(): void;
        get distinguishedNameQualifierInput(): string | undefined;
        private _generationQualifier?;
        get generationQualifier(): string;
        set generationQualifier(value: string);
        resetGenerationQualifier(): void;
        get generationQualifierInput(): string | undefined;
        private _givenName?;
        get givenName(): string;
        set givenName(value: string);
        resetGivenName(): void;
        get givenNameInput(): string | undefined;
        private _initials?;
        get initials(): string;
        set initials(value: string);
        resetInitials(): void;
        get initialsInput(): string | undefined;
        private _locality?;
        get locality(): string;
        set locality(value: string);
        resetLocality(): void;
        get localityInput(): string | undefined;
        private _organization?;
        get organization(): string;
        set organization(value: string);
        resetOrganization(): void;
        get organizationInput(): string | undefined;
        private _organizationalUnit?;
        get organizationalUnit(): string;
        set organizationalUnit(value: string);
        resetOrganizationalUnit(): void;
        get organizationalUnitInput(): string | undefined;
        private _pseudonym?;
        get pseudonym(): string;
        set pseudonym(value: string);
        resetPseudonym(): void;
        get pseudonymInput(): string | undefined;
        private _state?;
        get state(): string;
        set state(value: string);
        resetState(): void;
        get stateInput(): string | undefined;
        private _surname?;
        get surname(): string;
        set surname(value: string);
        resetSurname(): void;
        get surnameInput(): string | undefined;
        private _title?;
        get title(): string;
        set title(value: string);
        resetTitle(): void;
        get titleInput(): string | undefined;
    }
    interface CertificateAuthorityConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/acmpca_certificate_authority#key_algorithm TfCertificateAuthority#key_algorithm}
        */
        readonly keyAlgorithm: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/acmpca_certificate_authority#signing_algorithm TfCertificateAuthority#signing_algorithm}
        */
        readonly signingAlgorithm: string;
        /**
        * subject block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/acmpca_certificate_authority#subject TfCertificateAuthority#subject}
        */
        readonly subject: SubjectProperty;
    }
    class CertificateAuthorityConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CertificateAuthorityConfigurationProperty | undefined;
        set internalValue(value: CertificateAuthorityConfigurationProperty | undefined);
        private _keyAlgorithm?;
        get keyAlgorithm(): string;
        set keyAlgorithm(value: string);
        get keyAlgorithmInput(): string | undefined;
        private _signingAlgorithm?;
        get signingAlgorithm(): string;
        set signingAlgorithm(value: string);
        get signingAlgorithmInput(): string | undefined;
        private _subject;
        get subject(): SubjectPropertyOutputReference;
        putSubject(value: SubjectProperty): void;
        get subjectInput(): SubjectProperty | undefined;
    }
    interface CrlConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/acmpca_certificate_authority#custom_cname TfCertificateAuthority#custom_cname}
        */
        readonly customCname?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/acmpca_certificate_authority#custom_path TfCertificateAuthority#custom_path}
        */
        readonly customPath?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/acmpca_certificate_authority#enabled TfCertificateAuthority#enabled}
        */
        readonly enabled?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/acmpca_certificate_authority#expiration_in_days TfCertificateAuthority#expiration_in_days}
        */
        readonly expirationInDays?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/acmpca_certificate_authority#s3_bucket_name TfCertificateAuthority#s3_bucket_name}
        */
        readonly s3BucketName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/acmpca_certificate_authority#s3_object_acl TfCertificateAuthority#s3_object_acl}
        */
        readonly s3ObjectAcl?: string;
    }
    class CrlConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CrlConfigurationProperty | undefined;
        set internalValue(value: CrlConfigurationProperty | undefined);
        private _customCname?;
        get customCname(): string;
        set customCname(value: string);
        resetCustomCname(): void;
        get customCnameInput(): string | undefined;
        private _customPath?;
        get customPath(): string;
        set customPath(value: string);
        resetCustomPath(): void;
        get customPathInput(): string | undefined;
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        resetEnabled(): void;
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
        private _expirationInDays?;
        get expirationInDays(): number;
        set expirationInDays(value: number);
        resetExpirationInDays(): void;
        get expirationInDaysInput(): number | undefined;
        private _s3BucketName?;
        get s3BucketName(): string;
        set s3BucketName(value: string);
        resetS3BucketName(): void;
        get s3BucketNameInput(): string | undefined;
        private _s3ObjectAcl?;
        get s3ObjectAcl(): string;
        set s3ObjectAcl(value: string);
        resetS3ObjectAcl(): void;
        get s3ObjectAclInput(): string | undefined;
    }
    interface OcspConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/acmpca_certificate_authority#enabled TfCertificateAuthority#enabled}
        */
        readonly enabled: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/acmpca_certificate_authority#ocsp_custom_cname TfCertificateAuthority#ocsp_custom_cname}
        */
        readonly ocspCustomCname?: string;
    }
    class OcspConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): OcspConfigurationProperty | undefined;
        set internalValue(value: OcspConfigurationProperty | undefined);
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
        private _ocspCustomCname?;
        get ocspCustomCname(): string;
        set ocspCustomCname(value: string);
        resetOcspCustomCname(): void;
        get ocspCustomCnameInput(): string | undefined;
    }
    interface RevocationConfigurationProperty {
        /**
        * crl_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/acmpca_certificate_authority#crl_configuration TfCertificateAuthority#crl_configuration}
        */
        readonly crlConfiguration?: CrlConfigurationProperty;
        /**
        * ocsp_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/acmpca_certificate_authority#ocsp_configuration TfCertificateAuthority#ocsp_configuration}
        */
        readonly ocspConfiguration?: OcspConfigurationProperty;
    }
    class RevocationConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RevocationConfigurationProperty | undefined;
        set internalValue(value: RevocationConfigurationProperty | undefined);
        private _crlConfiguration;
        get crlConfiguration(): CrlConfigurationPropertyOutputReference;
        putCrlConfiguration(value: CrlConfigurationProperty): void;
        resetCrlConfiguration(): void;
        get crlConfigurationInput(): CrlConfigurationProperty | undefined;
        private _ocspConfiguration;
        get ocspConfiguration(): OcspConfigurationPropertyOutputReference;
        putOcspConfiguration(value: OcspConfigurationProperty): void;
        resetOcspConfiguration(): void;
        get ocspConfigurationInput(): OcspConfigurationProperty | undefined;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/acmpca_certificate_authority#create TfCertificateAuthority#create}
        */
        readonly create?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
    }
}
