import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfMultiRegionEndpointConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sesv2_multi_region_endpoint#endpoint_name TfMultiRegionEndpoint#endpoint_name}
    */
    readonly endpointName: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sesv2_multi_region_endpoint#region TfMultiRegionEndpoint#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sesv2_multi_region_endpoint#tags TfMultiRegionEndpoint#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * details block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sesv2_multi_region_endpoint#details TfMultiRegionEndpoint#details}
    */
    readonly details?: TfMultiRegionEndpoint.DetailsProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sesv2_multi_region_endpoint#timeouts TfMultiRegionEndpoint#timeouts}
    */
    readonly timeouts?: TfMultiRegionEndpoint.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sesv2_multi_region_endpoint aws_sesv2_multi_region_endpoint}
*/
export declare class TfMultiRegionEndpoint extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_sesv2_multi_region_endpoint";
    /**
    * Generates CDKTN code for importing a TfMultiRegionEndpoint resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfMultiRegionEndpoint to import
    * @param importFromId The id of the existing TfMultiRegionEndpoint that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sesv2_multi_region_endpoint#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfMultiRegionEndpoint to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sesv2_multi_region_endpoint aws_sesv2_multi_region_endpoint} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfMultiRegionEndpointConfig
    */
    constructor(scope: Construct, id: string, config: TfMultiRegionEndpointConfig);
    get arn(): string;
    get endpointId(): string;
    private _endpointName?;
    get endpointName(): string;
    set endpointName(value: string);
    get endpointNameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _routes;
    get routes(): TfMultiRegionEndpoint.RoutesPropertyList;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    private _details;
    get details(): TfMultiRegionEndpoint.DetailsPropertyList;
    putDetails(value: TfMultiRegionEndpoint.DetailsProperty[] | cdktn.IResolvable): void;
    resetDetails(): void;
    get detailsInput(): cdktn.IResolvable | TfMultiRegionEndpoint.DetailsProperty[] | undefined;
    private _timeouts;
    get timeouts(): TfMultiRegionEndpoint.TimeoutsPropertyOutputReference;
    putTimeouts(value: TfMultiRegionEndpoint.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | TfMultiRegionEndpoint.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfMultiRegionEndpointRoutesPropertyToTerraform(struct?: TfMultiRegionEndpoint.RoutesProperty): any;
export declare function tfMultiRegionEndpointRoutesPropertyToHclTerraform(struct?: TfMultiRegionEndpoint.RoutesProperty): any;
export declare function tfMultiRegionEndpointRoutesDetailsPropertyToTerraform(struct?: TfMultiRegionEndpoint.RoutesDetailsProperty | cdktn.IResolvable): any;
export declare function tfMultiRegionEndpointRoutesDetailsPropertyToHclTerraform(struct?: TfMultiRegionEndpoint.RoutesDetailsProperty | cdktn.IResolvable): any;
export declare function tfMultiRegionEndpointDetailsPropertyToTerraform(struct?: TfMultiRegionEndpoint.DetailsProperty | cdktn.IResolvable): any;
export declare function tfMultiRegionEndpointDetailsPropertyToHclTerraform(struct?: TfMultiRegionEndpoint.DetailsProperty | cdktn.IResolvable): any;
export declare function tfMultiRegionEndpointTimeoutsPropertyToTerraform(struct?: TfMultiRegionEndpoint.TimeoutsProperty | cdktn.IResolvable): any;
export declare function tfMultiRegionEndpointTimeoutsPropertyToHclTerraform(struct?: TfMultiRegionEndpoint.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace TfMultiRegionEndpoint {
    interface RoutesProperty {
    }
    class RoutesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RoutesProperty | undefined;
        set internalValue(value: RoutesProperty | undefined);
        get region(): string;
    }
    class RoutesPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RoutesPropertyOutputReference;
    }
    interface RoutesDetailsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sesv2_multi_region_endpoint#region TfMultiRegionEndpoint#region}
        */
        readonly region: string;
    }
    class RoutesDetailsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RoutesDetailsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RoutesDetailsProperty | cdktn.IResolvable | undefined);
        private _region?;
        get region(): string;
        set region(value: string);
        get regionInput(): string | undefined;
    }
    class RoutesDetailsPropertyList extends cdktn.ComplexList {
        internalValue?: RoutesDetailsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RoutesDetailsPropertyOutputReference;
    }
    interface DetailsProperty {
        /**
        * routes_details block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sesv2_multi_region_endpoint#routes_details TfMultiRegionEndpoint#routes_details}
        */
        readonly routesDetails?: RoutesDetailsProperty[] | cdktn.IResolvable;
    }
    class DetailsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DetailsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DetailsProperty | cdktn.IResolvable | undefined);
        private _routesDetails;
        get routesDetails(): RoutesDetailsPropertyList;
        putRoutesDetails(value: RoutesDetailsProperty[] | cdktn.IResolvable): void;
        resetRoutesDetails(): void;
        get routesDetailsInput(): cdktn.IResolvable | RoutesDetailsProperty[] | undefined;
    }
    class DetailsPropertyList extends cdktn.ComplexList {
        internalValue?: DetailsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DetailsPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sesv2_multi_region_endpoint#create TfMultiRegionEndpoint#create}
        */
        readonly create?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Setting a timeout for a Delete operation is only applicable if changes are saved into state before the destroy operation occurs.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sesv2_multi_region_endpoint#delete TfMultiRegionEndpoint#delete}
        */
        readonly delete?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
    }
}
