import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfEmailIdentityFeedbackAttributesConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sesv2_email_identity_feedback_attributes#email_forwarding_enabled TfEmailIdentityFeedbackAttributes#email_forwarding_enabled}
    */
    readonly emailForwardingEnabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sesv2_email_identity_feedback_attributes#email_identity TfEmailIdentityFeedbackAttributes#email_identity}
    */
    readonly emailIdentity: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sesv2_email_identity_feedback_attributes#id TfEmailIdentityFeedbackAttributes#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sesv2_email_identity_feedback_attributes#region TfEmailIdentityFeedbackAttributes#region}
    */
    readonly region?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sesv2_email_identity_feedback_attributes aws_sesv2_email_identity_feedback_attributes}
*/
export declare class TfEmailIdentityFeedbackAttributes extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_sesv2_email_identity_feedback_attributes";
    /**
    * Generates CDKTN code for importing a TfEmailIdentityFeedbackAttributes resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfEmailIdentityFeedbackAttributes to import
    * @param importFromId The id of the existing TfEmailIdentityFeedbackAttributes that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sesv2_email_identity_feedback_attributes#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfEmailIdentityFeedbackAttributes to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sesv2_email_identity_feedback_attributes aws_sesv2_email_identity_feedback_attributes} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfEmailIdentityFeedbackAttributesConfig
    */
    constructor(scope: Construct, id: string, config: TfEmailIdentityFeedbackAttributesConfig);
    private _emailForwardingEnabled?;
    get emailForwardingEnabled(): boolean | cdktn.IResolvable;
    set emailForwardingEnabled(value: boolean | cdktn.IResolvable);
    resetEmailForwardingEnabled(): void;
    get emailForwardingEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _emailIdentity?;
    get emailIdentity(): string;
    set emailIdentity(value: string);
    get emailIdentityInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
