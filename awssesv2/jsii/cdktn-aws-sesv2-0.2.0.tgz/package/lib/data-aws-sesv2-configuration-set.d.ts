import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataTfConfigurationSetConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/sesv2_configuration_set#configuration_set_name DataTfConfigurationSet#configuration_set_name}
    */
    readonly configurationSetName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/sesv2_configuration_set#id DataTfConfigurationSet#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/sesv2_configuration_set#region DataTfConfigurationSet#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/sesv2_configuration_set#tags DataTfConfigurationSet#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/sesv2_configuration_set aws_sesv2_configuration_set}
*/
export declare class DataTfConfigurationSet extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_sesv2_configuration_set";
    /**
    * Generates CDKTN code for importing a DataTfConfigurationSet resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataTfConfigurationSet to import
    * @param importFromId The id of the existing DataTfConfigurationSet that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/sesv2_configuration_set#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataTfConfigurationSet to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/sesv2_configuration_set aws_sesv2_configuration_set} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataTfConfigurationSetConfig
    */
    constructor(scope: Construct, id: string, config: DataTfConfigurationSetConfig);
    get arn(): string;
    private _configurationSetName?;
    get configurationSetName(): string;
    set configurationSetName(value: string);
    get configurationSetNameInput(): string | undefined;
    private _deliveryOptions;
    get deliveryOptions(): DataTfConfigurationSet.DeliveryOptionsPropertyList;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _reputationOptions;
    get reputationOptions(): DataTfConfigurationSet.ReputationOptionsPropertyList;
    private _sendingOptions;
    get sendingOptions(): DataTfConfigurationSet.SendingOptionsPropertyList;
    private _suppressionOptions;
    get suppressionOptions(): DataTfConfigurationSet.SuppressionOptionsPropertyList;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _trackingOptions;
    get trackingOptions(): DataTfConfigurationSet.TrackingOptionsPropertyList;
    private _vdmOptions;
    get vdmOptions(): DataTfConfigurationSet.VdmOptionsPropertyList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataTfConfigurationSetDeliveryOptionsPropertyToTerraform(struct?: DataTfConfigurationSet.DeliveryOptionsProperty): any;
export declare function dataTfConfigurationSetDeliveryOptionsPropertyToHclTerraform(struct?: DataTfConfigurationSet.DeliveryOptionsProperty): any;
export declare function dataTfConfigurationSetReputationOptionsPropertyToTerraform(struct?: DataTfConfigurationSet.ReputationOptionsProperty): any;
export declare function dataTfConfigurationSetReputationOptionsPropertyToHclTerraform(struct?: DataTfConfigurationSet.ReputationOptionsProperty): any;
export declare function dataTfConfigurationSetSendingOptionsPropertyToTerraform(struct?: DataTfConfigurationSet.SendingOptionsProperty): any;
export declare function dataTfConfigurationSetSendingOptionsPropertyToHclTerraform(struct?: DataTfConfigurationSet.SendingOptionsProperty): any;
export declare function dataTfConfigurationSetSuppressionOptionsPropertyToTerraform(struct?: DataTfConfigurationSet.SuppressionOptionsProperty): any;
export declare function dataTfConfigurationSetSuppressionOptionsPropertyToHclTerraform(struct?: DataTfConfigurationSet.SuppressionOptionsProperty): any;
export declare function dataTfConfigurationSetTrackingOptionsPropertyToTerraform(struct?: DataTfConfigurationSet.TrackingOptionsProperty): any;
export declare function dataTfConfigurationSetTrackingOptionsPropertyToHclTerraform(struct?: DataTfConfigurationSet.TrackingOptionsProperty): any;
export declare function dataTfConfigurationSetDashboardOptionsPropertyToTerraform(struct?: DataTfConfigurationSet.DashboardOptionsProperty): any;
export declare function dataTfConfigurationSetDashboardOptionsPropertyToHclTerraform(struct?: DataTfConfigurationSet.DashboardOptionsProperty): any;
export declare function dataTfConfigurationSetGuardianOptionsPropertyToTerraform(struct?: DataTfConfigurationSet.GuardianOptionsProperty): any;
export declare function dataTfConfigurationSetGuardianOptionsPropertyToHclTerraform(struct?: DataTfConfigurationSet.GuardianOptionsProperty): any;
export declare function dataTfConfigurationSetVdmOptionsPropertyToTerraform(struct?: DataTfConfigurationSet.VdmOptionsProperty): any;
export declare function dataTfConfigurationSetVdmOptionsPropertyToHclTerraform(struct?: DataTfConfigurationSet.VdmOptionsProperty): any;
export declare namespace DataTfConfigurationSet {
    interface DeliveryOptionsProperty {
    }
    class DeliveryOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DeliveryOptionsProperty | undefined;
        set internalValue(value: DeliveryOptionsProperty | undefined);
        get maxDeliverySeconds(): number;
        get sendingPoolName(): string;
        get tlsPolicy(): string;
    }
    class DeliveryOptionsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DeliveryOptionsPropertyOutputReference;
    }
    interface ReputationOptionsProperty {
    }
    class ReputationOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ReputationOptionsProperty | undefined;
        set internalValue(value: ReputationOptionsProperty | undefined);
        get lastFreshStart(): string;
        get reputationMetricsEnabled(): cdktn.IResolvable;
    }
    class ReputationOptionsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ReputationOptionsPropertyOutputReference;
    }
    interface SendingOptionsProperty {
    }
    class SendingOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SendingOptionsProperty | undefined;
        set internalValue(value: SendingOptionsProperty | undefined);
        get sendingEnabled(): cdktn.IResolvable;
    }
    class SendingOptionsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SendingOptionsPropertyOutputReference;
    }
    interface SuppressionOptionsProperty {
    }
    class SuppressionOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SuppressionOptionsProperty | undefined;
        set internalValue(value: SuppressionOptionsProperty | undefined);
        get suppressedReasons(): string[];
    }
    class SuppressionOptionsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SuppressionOptionsPropertyOutputReference;
    }
    interface TrackingOptionsProperty {
    }
    class TrackingOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TrackingOptionsProperty | undefined;
        set internalValue(value: TrackingOptionsProperty | undefined);
        get customRedirectDomain(): string;
        get httpsPolicy(): string;
    }
    class TrackingOptionsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TrackingOptionsPropertyOutputReference;
    }
    interface DashboardOptionsProperty {
    }
    class DashboardOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DashboardOptionsProperty | undefined;
        set internalValue(value: DashboardOptionsProperty | undefined);
        get engagementMetrics(): string;
    }
    class DashboardOptionsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DashboardOptionsPropertyOutputReference;
    }
    interface GuardianOptionsProperty {
    }
    class GuardianOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): GuardianOptionsProperty | undefined;
        set internalValue(value: GuardianOptionsProperty | undefined);
        get optimizedSharedDelivery(): string;
    }
    class GuardianOptionsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): GuardianOptionsPropertyOutputReference;
    }
    interface VdmOptionsProperty {
    }
    class VdmOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): VdmOptionsProperty | undefined;
        set internalValue(value: VdmOptionsProperty | undefined);
        private _dashboardOptions;
        get dashboardOptions(): DashboardOptionsPropertyList;
        private _guardianOptions;
        get guardianOptions(): GuardianOptionsPropertyList;
    }
    class VdmOptionsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): VdmOptionsPropertyOutputReference;
    }
}
