import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsSesv2EmailIdentityConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/sesv2_email_identity#email_identity DataAwsSesv2EmailIdentity#email_identity}
    */
    readonly emailIdentity: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/sesv2_email_identity#id DataAwsSesv2EmailIdentity#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/sesv2_email_identity#region DataAwsSesv2EmailIdentity#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/sesv2_email_identity#tags DataAwsSesv2EmailIdentity#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/sesv2_email_identity aws_sesv2_email_identity}
*/
export declare class DataAwsSesv2EmailIdentity extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_sesv2_email_identity";
    /**
    * Generates CDKTN code for importing a DataAwsSesv2EmailIdentity resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsSesv2EmailIdentity to import
    * @param importFromId The id of the existing DataAwsSesv2EmailIdentity that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/sesv2_email_identity#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsSesv2EmailIdentity to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/sesv2_email_identity aws_sesv2_email_identity} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsSesv2EmailIdentityConfig
    */
    constructor(scope: Construct, id: string, config: DataAwsSesv2EmailIdentityConfig);
    get arn(): string;
    get configurationSetName(): string;
    private _dkimSigningAttributes;
    get dkimSigningAttributes(): DataAwsSesv2EmailIdentity.DkimSigningAttributesPropertyList;
    private _emailIdentity?;
    get emailIdentity(): string;
    set emailIdentity(value: string);
    get emailIdentityInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get identityType(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    get verificationStatus(): string;
    get verifiedForSendingStatus(): cdktn.IResolvable;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataAwsSesv2EmailIdentityDkimSigningAttributesPropertyToTerraform(struct?: DataAwsSesv2EmailIdentity.DkimSigningAttributesProperty): any;
export declare function dataAwsSesv2EmailIdentityDkimSigningAttributesPropertyToHclTerraform(struct?: DataAwsSesv2EmailIdentity.DkimSigningAttributesProperty): any;
export declare namespace DataAwsSesv2EmailIdentity {
    interface DkimSigningAttributesProperty {
    }
    class DkimSigningAttributesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DkimSigningAttributesProperty | undefined;
        set internalValue(value: DkimSigningAttributesProperty | undefined);
        get currentSigningKeyLength(): string;
        get domainSigningPrivateKey(): string;
        get domainSigningSelector(): string;
        get lastKeyGenerationTimestamp(): string;
        get nextSigningKeyLength(): string;
        get signingAttributesOrigin(): string;
        get status(): string;
        get tokens(): string[];
    }
    class DkimSigningAttributesPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DkimSigningAttributesPropertyOutputReference;
    }
}
