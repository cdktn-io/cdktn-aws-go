import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsSesv2ConfigurationSetEventDestinationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sesv2_configuration_set_event_destination#configuration_set_name AwsSesv2ConfigurationSetEventDestination#configuration_set_name}
    */
    readonly configurationSetName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sesv2_configuration_set_event_destination#event_destination_name AwsSesv2ConfigurationSetEventDestination#event_destination_name}
    */
    readonly eventDestinationName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sesv2_configuration_set_event_destination#id AwsSesv2ConfigurationSetEventDestination#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sesv2_configuration_set_event_destination#region AwsSesv2ConfigurationSetEventDestination#region}
    */
    readonly region?: string;
    /**
    * event_destination block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sesv2_configuration_set_event_destination#event_destination AwsSesv2ConfigurationSetEventDestination#event_destination}
    */
    readonly eventDestination: AwsSesv2ConfigurationSetEventDestination.EventDestinationProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sesv2_configuration_set_event_destination aws_sesv2_configuration_set_event_destination}
*/
export declare class AwsSesv2ConfigurationSetEventDestination extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_sesv2_configuration_set_event_destination";
    /**
    * Generates CDKTN code for importing a AwsSesv2ConfigurationSetEventDestination resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsSesv2ConfigurationSetEventDestination to import
    * @param importFromId The id of the existing AwsSesv2ConfigurationSetEventDestination that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sesv2_configuration_set_event_destination#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsSesv2ConfigurationSetEventDestination to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sesv2_configuration_set_event_destination aws_sesv2_configuration_set_event_destination} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsSesv2ConfigurationSetEventDestinationConfig
    */
    constructor(scope: Construct, id: string, config: AwsSesv2ConfigurationSetEventDestinationConfig);
    private _configurationSetName?;
    get configurationSetName(): string;
    set configurationSetName(value: string);
    get configurationSetNameInput(): string | undefined;
    private _eventDestinationName?;
    get eventDestinationName(): string;
    set eventDestinationName(value: string);
    get eventDestinationNameInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _eventDestination;
    get eventDestination(): AwsSesv2ConfigurationSetEventDestination.EventDestinationPropertyOutputReference;
    putEventDestination(value: AwsSesv2ConfigurationSetEventDestination.EventDestinationProperty): void;
    get eventDestinationInput(): AwsSesv2ConfigurationSetEventDestination.EventDestinationProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsSesv2ConfigurationSetEventDestinationDimensionConfigurationPropertyToTerraform(struct?: AwsSesv2ConfigurationSetEventDestination.DimensionConfigurationProperty | cdktn.IResolvable): any;
export declare function awsSesv2ConfigurationSetEventDestinationDimensionConfigurationPropertyToHclTerraform(struct?: AwsSesv2ConfigurationSetEventDestination.DimensionConfigurationProperty | cdktn.IResolvable): any;
export declare function awsSesv2ConfigurationSetEventDestinationCloudWatchDestinationPropertyToTerraform(struct?: AwsSesv2ConfigurationSetEventDestination.CloudWatchDestinationPropertyOutputReference | AwsSesv2ConfigurationSetEventDestination.CloudWatchDestinationProperty): any;
export declare function awsSesv2ConfigurationSetEventDestinationCloudWatchDestinationPropertyToHclTerraform(struct?: AwsSesv2ConfigurationSetEventDestination.CloudWatchDestinationPropertyOutputReference | AwsSesv2ConfigurationSetEventDestination.CloudWatchDestinationProperty): any;
export declare function awsSesv2ConfigurationSetEventDestinationEventBridgeDestinationPropertyToTerraform(struct?: AwsSesv2ConfigurationSetEventDestination.EventBridgeDestinationPropertyOutputReference | AwsSesv2ConfigurationSetEventDestination.EventBridgeDestinationProperty): any;
export declare function awsSesv2ConfigurationSetEventDestinationEventBridgeDestinationPropertyToHclTerraform(struct?: AwsSesv2ConfigurationSetEventDestination.EventBridgeDestinationPropertyOutputReference | AwsSesv2ConfigurationSetEventDestination.EventBridgeDestinationProperty): any;
export declare function awsSesv2ConfigurationSetEventDestinationKinesisFirehoseDestinationPropertyToTerraform(struct?: AwsSesv2ConfigurationSetEventDestination.KinesisFirehoseDestinationPropertyOutputReference | AwsSesv2ConfigurationSetEventDestination.KinesisFirehoseDestinationProperty): any;
export declare function awsSesv2ConfigurationSetEventDestinationKinesisFirehoseDestinationPropertyToHclTerraform(struct?: AwsSesv2ConfigurationSetEventDestination.KinesisFirehoseDestinationPropertyOutputReference | AwsSesv2ConfigurationSetEventDestination.KinesisFirehoseDestinationProperty): any;
export declare function awsSesv2ConfigurationSetEventDestinationPinpointDestinationPropertyToTerraform(struct?: AwsSesv2ConfigurationSetEventDestination.PinpointDestinationPropertyOutputReference | AwsSesv2ConfigurationSetEventDestination.PinpointDestinationProperty): any;
export declare function awsSesv2ConfigurationSetEventDestinationPinpointDestinationPropertyToHclTerraform(struct?: AwsSesv2ConfigurationSetEventDestination.PinpointDestinationPropertyOutputReference | AwsSesv2ConfigurationSetEventDestination.PinpointDestinationProperty): any;
export declare function awsSesv2ConfigurationSetEventDestinationSnsDestinationPropertyToTerraform(struct?: AwsSesv2ConfigurationSetEventDestination.SnsDestinationPropertyOutputReference | AwsSesv2ConfigurationSetEventDestination.SnsDestinationProperty): any;
export declare function awsSesv2ConfigurationSetEventDestinationSnsDestinationPropertyToHclTerraform(struct?: AwsSesv2ConfigurationSetEventDestination.SnsDestinationPropertyOutputReference | AwsSesv2ConfigurationSetEventDestination.SnsDestinationProperty): any;
export declare function awsSesv2ConfigurationSetEventDestinationEventDestinationPropertyToTerraform(struct?: AwsSesv2ConfigurationSetEventDestination.EventDestinationPropertyOutputReference | AwsSesv2ConfigurationSetEventDestination.EventDestinationProperty): any;
export declare function awsSesv2ConfigurationSetEventDestinationEventDestinationPropertyToHclTerraform(struct?: AwsSesv2ConfigurationSetEventDestination.EventDestinationPropertyOutputReference | AwsSesv2ConfigurationSetEventDestination.EventDestinationProperty): any;
export declare namespace AwsSesv2ConfigurationSetEventDestination {
    interface DimensionConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sesv2_configuration_set_event_destination#default_dimension_value AwsSesv2ConfigurationSetEventDestination#default_dimension_value}
        */
        readonly defaultDimensionValue: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sesv2_configuration_set_event_destination#dimension_name AwsSesv2ConfigurationSetEventDestination#dimension_name}
        */
        readonly dimensionName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sesv2_configuration_set_event_destination#dimension_value_source AwsSesv2ConfigurationSetEventDestination#dimension_value_source}
        */
        readonly dimensionValueSource: string;
    }
    class DimensionConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DimensionConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DimensionConfigurationProperty | cdktn.IResolvable | undefined);
        private _defaultDimensionValue?;
        get defaultDimensionValue(): string;
        set defaultDimensionValue(value: string);
        get defaultDimensionValueInput(): string | undefined;
        private _dimensionName?;
        get dimensionName(): string;
        set dimensionName(value: string);
        get dimensionNameInput(): string | undefined;
        private _dimensionValueSource?;
        get dimensionValueSource(): string;
        set dimensionValueSource(value: string);
        get dimensionValueSourceInput(): string | undefined;
    }
    class DimensionConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: DimensionConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DimensionConfigurationPropertyOutputReference;
    }
    interface CloudWatchDestinationProperty {
        /**
        * dimension_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sesv2_configuration_set_event_destination#dimension_configuration AwsSesv2ConfigurationSetEventDestination#dimension_configuration}
        */
        readonly dimensionConfiguration: DimensionConfigurationProperty[] | cdktn.IResolvable;
    }
    class CloudWatchDestinationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CloudWatchDestinationProperty | undefined;
        set internalValue(value: CloudWatchDestinationProperty | undefined);
        private _dimensionConfiguration;
        get dimensionConfiguration(): DimensionConfigurationPropertyList;
        putDimensionConfiguration(value: DimensionConfigurationProperty[] | cdktn.IResolvable): void;
        get dimensionConfigurationInput(): cdktn.IResolvable | DimensionConfigurationProperty[] | undefined;
    }
    interface EventBridgeDestinationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sesv2_configuration_set_event_destination#event_bus_arn AwsSesv2ConfigurationSetEventDestination#event_bus_arn}
        */
        readonly eventBusArn: string;
    }
    class EventBridgeDestinationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): EventBridgeDestinationProperty | undefined;
        set internalValue(value: EventBridgeDestinationProperty | undefined);
        private _eventBusArn?;
        get eventBusArn(): string;
        set eventBusArn(value: string);
        get eventBusArnInput(): string | undefined;
    }
    interface KinesisFirehoseDestinationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sesv2_configuration_set_event_destination#delivery_stream_arn AwsSesv2ConfigurationSetEventDestination#delivery_stream_arn}
        */
        readonly deliveryStreamArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sesv2_configuration_set_event_destination#iam_role_arn AwsSesv2ConfigurationSetEventDestination#iam_role_arn}
        */
        readonly iamRoleArn: string;
    }
    class KinesisFirehoseDestinationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): KinesisFirehoseDestinationProperty | undefined;
        set internalValue(value: KinesisFirehoseDestinationProperty | undefined);
        private _deliveryStreamArn?;
        get deliveryStreamArn(): string;
        set deliveryStreamArn(value: string);
        get deliveryStreamArnInput(): string | undefined;
        private _iamRoleArn?;
        get iamRoleArn(): string;
        set iamRoleArn(value: string);
        get iamRoleArnInput(): string | undefined;
    }
    interface PinpointDestinationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sesv2_configuration_set_event_destination#application_arn AwsSesv2ConfigurationSetEventDestination#application_arn}
        */
        readonly applicationArn: string;
    }
    class PinpointDestinationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): PinpointDestinationProperty | undefined;
        set internalValue(value: PinpointDestinationProperty | undefined);
        private _applicationArn?;
        get applicationArn(): string;
        set applicationArn(value: string);
        get applicationArnInput(): string | undefined;
    }
    interface SnsDestinationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sesv2_configuration_set_event_destination#topic_arn AwsSesv2ConfigurationSetEventDestination#topic_arn}
        */
        readonly topicArn: string;
    }
    class SnsDestinationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SnsDestinationProperty | undefined;
        set internalValue(value: SnsDestinationProperty | undefined);
        private _topicArn?;
        get topicArn(): string;
        set topicArn(value: string);
        get topicArnInput(): string | undefined;
    }
    interface EventDestinationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sesv2_configuration_set_event_destination#enabled AwsSesv2ConfigurationSetEventDestination#enabled}
        */
        readonly enabled?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sesv2_configuration_set_event_destination#matching_event_types AwsSesv2ConfigurationSetEventDestination#matching_event_types}
        */
        readonly matchingEventTypes: string[];
        /**
        * cloud_watch_destination block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sesv2_configuration_set_event_destination#cloud_watch_destination AwsSesv2ConfigurationSetEventDestination#cloud_watch_destination}
        */
        readonly cloudWatchDestination?: CloudWatchDestinationProperty;
        /**
        * event_bridge_destination block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sesv2_configuration_set_event_destination#event_bridge_destination AwsSesv2ConfigurationSetEventDestination#event_bridge_destination}
        */
        readonly eventBridgeDestination?: EventBridgeDestinationProperty;
        /**
        * kinesis_firehose_destination block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sesv2_configuration_set_event_destination#kinesis_firehose_destination AwsSesv2ConfigurationSetEventDestination#kinesis_firehose_destination}
        */
        readonly kinesisFirehoseDestination?: KinesisFirehoseDestinationProperty;
        /**
        * pinpoint_destination block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sesv2_configuration_set_event_destination#pinpoint_destination AwsSesv2ConfigurationSetEventDestination#pinpoint_destination}
        */
        readonly pinpointDestination?: PinpointDestinationProperty;
        /**
        * sns_destination block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sesv2_configuration_set_event_destination#sns_destination AwsSesv2ConfigurationSetEventDestination#sns_destination}
        */
        readonly snsDestination?: SnsDestinationProperty;
    }
    class EventDestinationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): EventDestinationProperty | undefined;
        set internalValue(value: EventDestinationProperty | undefined);
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        resetEnabled(): void;
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
        private _matchingEventTypes?;
        get matchingEventTypes(): string[];
        set matchingEventTypes(value: string[]);
        get matchingEventTypesInput(): string[] | undefined;
        private _cloudWatchDestination;
        get cloudWatchDestination(): CloudWatchDestinationPropertyOutputReference;
        putCloudWatchDestination(value: CloudWatchDestinationProperty): void;
        resetCloudWatchDestination(): void;
        get cloudWatchDestinationInput(): CloudWatchDestinationProperty | undefined;
        private _eventBridgeDestination;
        get eventBridgeDestination(): EventBridgeDestinationPropertyOutputReference;
        putEventBridgeDestination(value: EventBridgeDestinationProperty): void;
        resetEventBridgeDestination(): void;
        get eventBridgeDestinationInput(): EventBridgeDestinationProperty | undefined;
        private _kinesisFirehoseDestination;
        get kinesisFirehoseDestination(): KinesisFirehoseDestinationPropertyOutputReference;
        putKinesisFirehoseDestination(value: KinesisFirehoseDestinationProperty): void;
        resetKinesisFirehoseDestination(): void;
        get kinesisFirehoseDestinationInput(): KinesisFirehoseDestinationProperty | undefined;
        private _pinpointDestination;
        get pinpointDestination(): PinpointDestinationPropertyOutputReference;
        putPinpointDestination(value: PinpointDestinationProperty): void;
        resetPinpointDestination(): void;
        get pinpointDestinationInput(): PinpointDestinationProperty | undefined;
        private _snsDestination;
        get snsDestination(): SnsDestinationPropertyOutputReference;
        putSnsDestination(value: SnsDestinationProperty): void;
        resetSnsDestination(): void;
        get snsDestinationInput(): SnsDestinationProperty | undefined;
    }
}
