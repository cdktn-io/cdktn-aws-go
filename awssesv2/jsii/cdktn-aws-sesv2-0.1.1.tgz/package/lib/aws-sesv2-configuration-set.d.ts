import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsSesv2ConfigurationSetConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sesv2_configuration_set#configuration_set_name AwsSesv2ConfigurationSet#configuration_set_name}
    */
    readonly configurationSetName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sesv2_configuration_set#id AwsSesv2ConfigurationSet#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sesv2_configuration_set#region AwsSesv2ConfigurationSet#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sesv2_configuration_set#tags AwsSesv2ConfigurationSet#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sesv2_configuration_set#tags_all AwsSesv2ConfigurationSet#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * delivery_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sesv2_configuration_set#delivery_options AwsSesv2ConfigurationSet#delivery_options}
    */
    readonly deliveryOptions?: AwsSesv2ConfigurationSet.DeliveryOptionsProperty;
    /**
    * reputation_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sesv2_configuration_set#reputation_options AwsSesv2ConfigurationSet#reputation_options}
    */
    readonly reputationOptions?: AwsSesv2ConfigurationSet.ReputationOptionsProperty;
    /**
    * sending_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sesv2_configuration_set#sending_options AwsSesv2ConfigurationSet#sending_options}
    */
    readonly sendingOptions?: AwsSesv2ConfigurationSet.SendingOptionsProperty;
    /**
    * suppression_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sesv2_configuration_set#suppression_options AwsSesv2ConfigurationSet#suppression_options}
    */
    readonly suppressionOptions?: AwsSesv2ConfigurationSet.SuppressionOptionsProperty;
    /**
    * tracking_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sesv2_configuration_set#tracking_options AwsSesv2ConfigurationSet#tracking_options}
    */
    readonly trackingOptions?: AwsSesv2ConfigurationSet.TrackingOptionsProperty;
    /**
    * vdm_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sesv2_configuration_set#vdm_options AwsSesv2ConfigurationSet#vdm_options}
    */
    readonly vdmOptions?: AwsSesv2ConfigurationSet.VdmOptionsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sesv2_configuration_set aws_sesv2_configuration_set}
*/
export declare class AwsSesv2ConfigurationSet extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_sesv2_configuration_set";
    /**
    * Generates CDKTN code for importing a AwsSesv2ConfigurationSet resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsSesv2ConfigurationSet to import
    * @param importFromId The id of the existing AwsSesv2ConfigurationSet that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sesv2_configuration_set#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsSesv2ConfigurationSet to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sesv2_configuration_set aws_sesv2_configuration_set} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsSesv2ConfigurationSetConfig
    */
    constructor(scope: Construct, id: string, config: AwsSesv2ConfigurationSetConfig);
    get arn(): string;
    private _configurationSetName?;
    get configurationSetName(): string;
    set configurationSetName(value: string);
    get configurationSetNameInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _deliveryOptions;
    get deliveryOptions(): AwsSesv2ConfigurationSet.DeliveryOptionsPropertyOutputReference;
    putDeliveryOptions(value: AwsSesv2ConfigurationSet.DeliveryOptionsProperty): void;
    resetDeliveryOptions(): void;
    get deliveryOptionsInput(): AwsSesv2ConfigurationSet.DeliveryOptionsProperty | undefined;
    private _reputationOptions;
    get reputationOptions(): AwsSesv2ConfigurationSet.ReputationOptionsPropertyOutputReference;
    putReputationOptions(value: AwsSesv2ConfigurationSet.ReputationOptionsProperty): void;
    resetReputationOptions(): void;
    get reputationOptionsInput(): AwsSesv2ConfigurationSet.ReputationOptionsProperty | undefined;
    private _sendingOptions;
    get sendingOptions(): AwsSesv2ConfigurationSet.SendingOptionsPropertyOutputReference;
    putSendingOptions(value: AwsSesv2ConfigurationSet.SendingOptionsProperty): void;
    resetSendingOptions(): void;
    get sendingOptionsInput(): AwsSesv2ConfigurationSet.SendingOptionsProperty | undefined;
    private _suppressionOptions;
    get suppressionOptions(): AwsSesv2ConfigurationSet.SuppressionOptionsPropertyOutputReference;
    putSuppressionOptions(value: AwsSesv2ConfigurationSet.SuppressionOptionsProperty): void;
    resetSuppressionOptions(): void;
    get suppressionOptionsInput(): AwsSesv2ConfigurationSet.SuppressionOptionsProperty | undefined;
    private _trackingOptions;
    get trackingOptions(): AwsSesv2ConfigurationSet.TrackingOptionsPropertyOutputReference;
    putTrackingOptions(value: AwsSesv2ConfigurationSet.TrackingOptionsProperty): void;
    resetTrackingOptions(): void;
    get trackingOptionsInput(): AwsSesv2ConfigurationSet.TrackingOptionsProperty | undefined;
    private _vdmOptions;
    get vdmOptions(): AwsSesv2ConfigurationSet.VdmOptionsPropertyOutputReference;
    putVdmOptions(value: AwsSesv2ConfigurationSet.VdmOptionsProperty): void;
    resetVdmOptions(): void;
    get vdmOptionsInput(): AwsSesv2ConfigurationSet.VdmOptionsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsSesv2ConfigurationSetDeliveryOptionsPropertyToTerraform(struct?: AwsSesv2ConfigurationSet.DeliveryOptionsPropertyOutputReference | AwsSesv2ConfigurationSet.DeliveryOptionsProperty): any;
export declare function awsSesv2ConfigurationSetDeliveryOptionsPropertyToHclTerraform(struct?: AwsSesv2ConfigurationSet.DeliveryOptionsPropertyOutputReference | AwsSesv2ConfigurationSet.DeliveryOptionsProperty): any;
export declare function awsSesv2ConfigurationSetReputationOptionsPropertyToTerraform(struct?: AwsSesv2ConfigurationSet.ReputationOptionsPropertyOutputReference | AwsSesv2ConfigurationSet.ReputationOptionsProperty): any;
export declare function awsSesv2ConfigurationSetReputationOptionsPropertyToHclTerraform(struct?: AwsSesv2ConfigurationSet.ReputationOptionsPropertyOutputReference | AwsSesv2ConfigurationSet.ReputationOptionsProperty): any;
export declare function awsSesv2ConfigurationSetSendingOptionsPropertyToTerraform(struct?: AwsSesv2ConfigurationSet.SendingOptionsPropertyOutputReference | AwsSesv2ConfigurationSet.SendingOptionsProperty): any;
export declare function awsSesv2ConfigurationSetSendingOptionsPropertyToHclTerraform(struct?: AwsSesv2ConfigurationSet.SendingOptionsPropertyOutputReference | AwsSesv2ConfigurationSet.SendingOptionsProperty): any;
export declare function awsSesv2ConfigurationSetSuppressionOptionsPropertyToTerraform(struct?: AwsSesv2ConfigurationSet.SuppressionOptionsPropertyOutputReference | AwsSesv2ConfigurationSet.SuppressionOptionsProperty): any;
export declare function awsSesv2ConfigurationSetSuppressionOptionsPropertyToHclTerraform(struct?: AwsSesv2ConfigurationSet.SuppressionOptionsPropertyOutputReference | AwsSesv2ConfigurationSet.SuppressionOptionsProperty): any;
export declare function awsSesv2ConfigurationSetTrackingOptionsPropertyToTerraform(struct?: AwsSesv2ConfigurationSet.TrackingOptionsPropertyOutputReference | AwsSesv2ConfigurationSet.TrackingOptionsProperty): any;
export declare function awsSesv2ConfigurationSetTrackingOptionsPropertyToHclTerraform(struct?: AwsSesv2ConfigurationSet.TrackingOptionsPropertyOutputReference | AwsSesv2ConfigurationSet.TrackingOptionsProperty): any;
export declare function awsSesv2ConfigurationSetDashboardOptionsPropertyToTerraform(struct?: AwsSesv2ConfigurationSet.DashboardOptionsPropertyOutputReference | AwsSesv2ConfigurationSet.DashboardOptionsProperty): any;
export declare function awsSesv2ConfigurationSetDashboardOptionsPropertyToHclTerraform(struct?: AwsSesv2ConfigurationSet.DashboardOptionsPropertyOutputReference | AwsSesv2ConfigurationSet.DashboardOptionsProperty): any;
export declare function awsSesv2ConfigurationSetGuardianOptionsPropertyToTerraform(struct?: AwsSesv2ConfigurationSet.GuardianOptionsPropertyOutputReference | AwsSesv2ConfigurationSet.GuardianOptionsProperty): any;
export declare function awsSesv2ConfigurationSetGuardianOptionsPropertyToHclTerraform(struct?: AwsSesv2ConfigurationSet.GuardianOptionsPropertyOutputReference | AwsSesv2ConfigurationSet.GuardianOptionsProperty): any;
export declare function awsSesv2ConfigurationSetVdmOptionsPropertyToTerraform(struct?: AwsSesv2ConfigurationSet.VdmOptionsPropertyOutputReference | AwsSesv2ConfigurationSet.VdmOptionsProperty): any;
export declare function awsSesv2ConfigurationSetVdmOptionsPropertyToHclTerraform(struct?: AwsSesv2ConfigurationSet.VdmOptionsPropertyOutputReference | AwsSesv2ConfigurationSet.VdmOptionsProperty): any;
export declare namespace AwsSesv2ConfigurationSet {
    interface DeliveryOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sesv2_configuration_set#max_delivery_seconds AwsSesv2ConfigurationSet#max_delivery_seconds}
        */
        readonly maxDeliverySeconds?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sesv2_configuration_set#sending_pool_name AwsSesv2ConfigurationSet#sending_pool_name}
        */
        readonly sendingPoolName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sesv2_configuration_set#tls_policy AwsSesv2ConfigurationSet#tls_policy}
        */
        readonly tlsPolicy?: string;
    }
    class DeliveryOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DeliveryOptionsProperty | undefined;
        set internalValue(value: DeliveryOptionsProperty | undefined);
        private _maxDeliverySeconds?;
        get maxDeliverySeconds(): number;
        set maxDeliverySeconds(value: number);
        resetMaxDeliverySeconds(): void;
        get maxDeliverySecondsInput(): number | undefined;
        private _sendingPoolName?;
        get sendingPoolName(): string;
        set sendingPoolName(value: string);
        resetSendingPoolName(): void;
        get sendingPoolNameInput(): string | undefined;
        private _tlsPolicy?;
        get tlsPolicy(): string;
        set tlsPolicy(value: string);
        resetTlsPolicy(): void;
        get tlsPolicyInput(): string | undefined;
    }
    interface ReputationOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sesv2_configuration_set#reputation_metrics_enabled AwsSesv2ConfigurationSet#reputation_metrics_enabled}
        */
        readonly reputationMetricsEnabled?: boolean | cdktn.IResolvable;
    }
    class ReputationOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ReputationOptionsProperty | undefined;
        set internalValue(value: ReputationOptionsProperty | undefined);
        get lastFreshStart(): string;
        private _reputationMetricsEnabled?;
        get reputationMetricsEnabled(): boolean | cdktn.IResolvable;
        set reputationMetricsEnabled(value: boolean | cdktn.IResolvable);
        resetReputationMetricsEnabled(): void;
        get reputationMetricsEnabledInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface SendingOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sesv2_configuration_set#sending_enabled AwsSesv2ConfigurationSet#sending_enabled}
        */
        readonly sendingEnabled?: boolean | cdktn.IResolvable;
    }
    class SendingOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SendingOptionsProperty | undefined;
        set internalValue(value: SendingOptionsProperty | undefined);
        private _sendingEnabled?;
        get sendingEnabled(): boolean | cdktn.IResolvable;
        set sendingEnabled(value: boolean | cdktn.IResolvable);
        resetSendingEnabled(): void;
        get sendingEnabledInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface SuppressionOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sesv2_configuration_set#suppressed_reasons AwsSesv2ConfigurationSet#suppressed_reasons}
        */
        readonly suppressedReasons?: string[];
    }
    class SuppressionOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SuppressionOptionsProperty | undefined;
        set internalValue(value: SuppressionOptionsProperty | undefined);
        private _suppressedReasons?;
        get suppressedReasons(): string[];
        set suppressedReasons(value: string[]);
        resetSuppressedReasons(): void;
        get suppressedReasonsInput(): string[] | undefined;
    }
    interface TrackingOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sesv2_configuration_set#custom_redirect_domain AwsSesv2ConfigurationSet#custom_redirect_domain}
        */
        readonly customRedirectDomain: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sesv2_configuration_set#https_policy AwsSesv2ConfigurationSet#https_policy}
        */
        readonly httpsPolicy?: string;
    }
    class TrackingOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TrackingOptionsProperty | undefined;
        set internalValue(value: TrackingOptionsProperty | undefined);
        private _customRedirectDomain?;
        get customRedirectDomain(): string;
        set customRedirectDomain(value: string);
        get customRedirectDomainInput(): string | undefined;
        private _httpsPolicy?;
        get httpsPolicy(): string;
        set httpsPolicy(value: string);
        resetHttpsPolicy(): void;
        get httpsPolicyInput(): string | undefined;
    }
    interface DashboardOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sesv2_configuration_set#engagement_metrics AwsSesv2ConfigurationSet#engagement_metrics}
        */
        readonly engagementMetrics?: string;
    }
    class DashboardOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DashboardOptionsProperty | undefined;
        set internalValue(value: DashboardOptionsProperty | undefined);
        private _engagementMetrics?;
        get engagementMetrics(): string;
        set engagementMetrics(value: string);
        resetEngagementMetrics(): void;
        get engagementMetricsInput(): string | undefined;
    }
    interface GuardianOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sesv2_configuration_set#optimized_shared_delivery AwsSesv2ConfigurationSet#optimized_shared_delivery}
        */
        readonly optimizedSharedDelivery?: string;
    }
    class GuardianOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): GuardianOptionsProperty | undefined;
        set internalValue(value: GuardianOptionsProperty | undefined);
        private _optimizedSharedDelivery?;
        get optimizedSharedDelivery(): string;
        set optimizedSharedDelivery(value: string);
        resetOptimizedSharedDelivery(): void;
        get optimizedSharedDeliveryInput(): string | undefined;
    }
    interface VdmOptionsProperty {
        /**
        * dashboard_options block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sesv2_configuration_set#dashboard_options AwsSesv2ConfigurationSet#dashboard_options}
        */
        readonly dashboardOptions?: DashboardOptionsProperty;
        /**
        * guardian_options block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sesv2_configuration_set#guardian_options AwsSesv2ConfigurationSet#guardian_options}
        */
        readonly guardianOptions?: GuardianOptionsProperty;
    }
    class VdmOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): VdmOptionsProperty | undefined;
        set internalValue(value: VdmOptionsProperty | undefined);
        private _dashboardOptions;
        get dashboardOptions(): DashboardOptionsPropertyOutputReference;
        putDashboardOptions(value: DashboardOptionsProperty): void;
        resetDashboardOptions(): void;
        get dashboardOptionsInput(): DashboardOptionsProperty | undefined;
        private _guardianOptions;
        get guardianOptions(): GuardianOptionsPropertyOutputReference;
        putGuardianOptions(value: GuardianOptionsProperty): void;
        resetGuardianOptions(): void;
        get guardianOptionsInput(): GuardianOptionsProperty | undefined;
    }
}
