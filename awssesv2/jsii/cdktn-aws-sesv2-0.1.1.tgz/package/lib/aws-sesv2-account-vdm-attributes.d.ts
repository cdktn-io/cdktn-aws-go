import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsSesv2AccountVdmAttributesConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sesv2_account_vdm_attributes#id AwsSesv2AccountVdmAttributes#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sesv2_account_vdm_attributes#region AwsSesv2AccountVdmAttributes#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sesv2_account_vdm_attributes#vdm_enabled AwsSesv2AccountVdmAttributes#vdm_enabled}
    */
    readonly vdmEnabled: string;
    /**
    * dashboard_attributes block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sesv2_account_vdm_attributes#dashboard_attributes AwsSesv2AccountVdmAttributes#dashboard_attributes}
    */
    readonly dashboardAttributes?: AwsSesv2AccountVdmAttributes.DashboardAttributesProperty;
    /**
    * guardian_attributes block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sesv2_account_vdm_attributes#guardian_attributes AwsSesv2AccountVdmAttributes#guardian_attributes}
    */
    readonly guardianAttributes?: AwsSesv2AccountVdmAttributes.GuardianAttributesProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sesv2_account_vdm_attributes aws_sesv2_account_vdm_attributes}
*/
export declare class AwsSesv2AccountVdmAttributes extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_sesv2_account_vdm_attributes";
    /**
    * Generates CDKTN code for importing a AwsSesv2AccountVdmAttributes resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsSesv2AccountVdmAttributes to import
    * @param importFromId The id of the existing AwsSesv2AccountVdmAttributes that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sesv2_account_vdm_attributes#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsSesv2AccountVdmAttributes to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sesv2_account_vdm_attributes aws_sesv2_account_vdm_attributes} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsSesv2AccountVdmAttributesConfig
    */
    constructor(scope: Construct, id: string, config: AwsSesv2AccountVdmAttributesConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _vdmEnabled?;
    get vdmEnabled(): string;
    set vdmEnabled(value: string);
    get vdmEnabledInput(): string | undefined;
    private _dashboardAttributes;
    get dashboardAttributes(): AwsSesv2AccountVdmAttributes.DashboardAttributesPropertyOutputReference;
    putDashboardAttributes(value: AwsSesv2AccountVdmAttributes.DashboardAttributesProperty): void;
    resetDashboardAttributes(): void;
    get dashboardAttributesInput(): AwsSesv2AccountVdmAttributes.DashboardAttributesProperty | undefined;
    private _guardianAttributes;
    get guardianAttributes(): AwsSesv2AccountVdmAttributes.GuardianAttributesPropertyOutputReference;
    putGuardianAttributes(value: AwsSesv2AccountVdmAttributes.GuardianAttributesProperty): void;
    resetGuardianAttributes(): void;
    get guardianAttributesInput(): AwsSesv2AccountVdmAttributes.GuardianAttributesProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsSesv2AccountVdmAttributesDashboardAttributesPropertyToTerraform(struct?: AwsSesv2AccountVdmAttributes.DashboardAttributesPropertyOutputReference | AwsSesv2AccountVdmAttributes.DashboardAttributesProperty): any;
export declare function awsSesv2AccountVdmAttributesDashboardAttributesPropertyToHclTerraform(struct?: AwsSesv2AccountVdmAttributes.DashboardAttributesPropertyOutputReference | AwsSesv2AccountVdmAttributes.DashboardAttributesProperty): any;
export declare function awsSesv2AccountVdmAttributesGuardianAttributesPropertyToTerraform(struct?: AwsSesv2AccountVdmAttributes.GuardianAttributesPropertyOutputReference | AwsSesv2AccountVdmAttributes.GuardianAttributesProperty): any;
export declare function awsSesv2AccountVdmAttributesGuardianAttributesPropertyToHclTerraform(struct?: AwsSesv2AccountVdmAttributes.GuardianAttributesPropertyOutputReference | AwsSesv2AccountVdmAttributes.GuardianAttributesProperty): any;
export declare namespace AwsSesv2AccountVdmAttributes {
    interface DashboardAttributesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sesv2_account_vdm_attributes#engagement_metrics AwsSesv2AccountVdmAttributes#engagement_metrics}
        */
        readonly engagementMetrics?: string;
    }
    class DashboardAttributesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DashboardAttributesProperty | undefined;
        set internalValue(value: DashboardAttributesProperty | undefined);
        private _engagementMetrics?;
        get engagementMetrics(): string;
        set engagementMetrics(value: string);
        resetEngagementMetrics(): void;
        get engagementMetricsInput(): string | undefined;
    }
    interface GuardianAttributesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sesv2_account_vdm_attributes#optimized_shared_delivery AwsSesv2AccountVdmAttributes#optimized_shared_delivery}
        */
        readonly optimizedSharedDelivery?: string;
    }
    class GuardianAttributesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): GuardianAttributesProperty | undefined;
        set internalValue(value: GuardianAttributesProperty | undefined);
        private _optimizedSharedDelivery?;
        get optimizedSharedDelivery(): string;
        set optimizedSharedDelivery(value: string);
        resetOptimizedSharedDelivery(): void;
        get optimizedSharedDeliveryInput(): string | undefined;
    }
}
