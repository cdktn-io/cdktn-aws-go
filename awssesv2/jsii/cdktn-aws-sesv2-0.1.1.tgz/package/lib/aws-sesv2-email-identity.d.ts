import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsSesv2EmailIdentityConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sesv2_email_identity#configuration_set_name AwsSesv2EmailIdentity#configuration_set_name}
    */
    readonly configurationSetName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sesv2_email_identity#email_identity AwsSesv2EmailIdentity#email_identity}
    */
    readonly emailIdentity: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sesv2_email_identity#id AwsSesv2EmailIdentity#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sesv2_email_identity#region AwsSesv2EmailIdentity#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sesv2_email_identity#tags AwsSesv2EmailIdentity#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sesv2_email_identity#tags_all AwsSesv2EmailIdentity#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * dkim_signing_attributes block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sesv2_email_identity#dkim_signing_attributes AwsSesv2EmailIdentity#dkim_signing_attributes}
    */
    readonly dkimSigningAttributes?: AwsSesv2EmailIdentity.DkimSigningAttributesProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sesv2_email_identity aws_sesv2_email_identity}
*/
export declare class AwsSesv2EmailIdentity extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_sesv2_email_identity";
    /**
    * Generates CDKTN code for importing a AwsSesv2EmailIdentity resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsSesv2EmailIdentity to import
    * @param importFromId The id of the existing AwsSesv2EmailIdentity that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sesv2_email_identity#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsSesv2EmailIdentity to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sesv2_email_identity aws_sesv2_email_identity} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsSesv2EmailIdentityConfig
    */
    constructor(scope: Construct, id: string, config: AwsSesv2EmailIdentityConfig);
    get arn(): string;
    private _configurationSetName?;
    get configurationSetName(): string;
    set configurationSetName(value: string);
    resetConfigurationSetName(): void;
    get configurationSetNameInput(): string | undefined;
    private _emailIdentity?;
    get emailIdentity(): string;
    set emailIdentity(value: string);
    get emailIdentityInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get identityType(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    get verificationStatus(): string;
    get verifiedForSendingStatus(): cdktn.IResolvable;
    private _dkimSigningAttributes;
    get dkimSigningAttributes(): AwsSesv2EmailIdentity.DkimSigningAttributesPropertyOutputReference;
    putDkimSigningAttributes(value: AwsSesv2EmailIdentity.DkimSigningAttributesProperty): void;
    resetDkimSigningAttributes(): void;
    get dkimSigningAttributesInput(): AwsSesv2EmailIdentity.DkimSigningAttributesProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsSesv2EmailIdentityDkimSigningAttributesPropertyToTerraform(struct?: AwsSesv2EmailIdentity.DkimSigningAttributesPropertyOutputReference | AwsSesv2EmailIdentity.DkimSigningAttributesProperty): any;
export declare function awsSesv2EmailIdentityDkimSigningAttributesPropertyToHclTerraform(struct?: AwsSesv2EmailIdentity.DkimSigningAttributesPropertyOutputReference | AwsSesv2EmailIdentity.DkimSigningAttributesProperty): any;
export declare namespace AwsSesv2EmailIdentity {
    interface DkimSigningAttributesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sesv2_email_identity#domain_signing_private_key AwsSesv2EmailIdentity#domain_signing_private_key}
        */
        readonly domainSigningPrivateKey?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sesv2_email_identity#domain_signing_selector AwsSesv2EmailIdentity#domain_signing_selector}
        */
        readonly domainSigningSelector?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sesv2_email_identity#next_signing_key_length AwsSesv2EmailIdentity#next_signing_key_length}
        */
        readonly nextSigningKeyLength?: string;
    }
    class DkimSigningAttributesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DkimSigningAttributesProperty | undefined;
        set internalValue(value: DkimSigningAttributesProperty | undefined);
        get currentSigningKeyLength(): string;
        private _domainSigningPrivateKey?;
        get domainSigningPrivateKey(): string;
        set domainSigningPrivateKey(value: string);
        resetDomainSigningPrivateKey(): void;
        get domainSigningPrivateKeyInput(): string | undefined;
        private _domainSigningSelector?;
        get domainSigningSelector(): string;
        set domainSigningSelector(value: string);
        resetDomainSigningSelector(): void;
        get domainSigningSelectorInput(): string | undefined;
        get lastKeyGenerationTimestamp(): string;
        private _nextSigningKeyLength?;
        get nextSigningKeyLength(): string;
        set nextSigningKeyLength(value: string);
        resetNextSigningKeyLength(): void;
        get nextSigningKeyLengthInput(): string | undefined;
        get signingAttributesOrigin(): string;
        get status(): string;
        get tokens(): string[];
    }
}
