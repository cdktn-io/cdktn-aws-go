import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsSesv2AccountSuppressionAttributesConfig extends cdktn.TerraformMetaArguments {
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sesv2_account_suppression_attributes#region AwsSesv2AccountSuppressionAttributes#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sesv2_account_suppression_attributes#suppressed_reasons AwsSesv2AccountSuppressionAttributes#suppressed_reasons}
    */
    readonly suppressedReasons: string[];
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sesv2_account_suppression_attributes aws_sesv2_account_suppression_attributes}
*/
export declare class AwsSesv2AccountSuppressionAttributes extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_sesv2_account_suppression_attributes";
    /**
    * Generates CDKTN code for importing a AwsSesv2AccountSuppressionAttributes resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsSesv2AccountSuppressionAttributes to import
    * @param importFromId The id of the existing AwsSesv2AccountSuppressionAttributes that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sesv2_account_suppression_attributes#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsSesv2AccountSuppressionAttributes to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sesv2_account_suppression_attributes aws_sesv2_account_suppression_attributes} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsSesv2AccountSuppressionAttributesConfig
    */
    constructor(scope: Construct, id: string, config: AwsSesv2AccountSuppressionAttributesConfig);
    get id(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _suppressedReasons?;
    get suppressedReasons(): string[];
    set suppressedReasons(value: string[]);
    get suppressedReasonsInput(): string[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
