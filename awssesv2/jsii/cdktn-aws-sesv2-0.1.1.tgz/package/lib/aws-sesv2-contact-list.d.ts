import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsSesv2ContactListConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sesv2_contact_list#contact_list_name AwsSesv2ContactList#contact_list_name}
    */
    readonly contactListName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sesv2_contact_list#description AwsSesv2ContactList#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sesv2_contact_list#id AwsSesv2ContactList#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sesv2_contact_list#region AwsSesv2ContactList#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sesv2_contact_list#tags AwsSesv2ContactList#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sesv2_contact_list#tags_all AwsSesv2ContactList#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * topic block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sesv2_contact_list#topic AwsSesv2ContactList#topic}
    */
    readonly topic?: AwsSesv2ContactList.TopicProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sesv2_contact_list aws_sesv2_contact_list}
*/
export declare class AwsSesv2ContactList extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_sesv2_contact_list";
    /**
    * Generates CDKTN code for importing a AwsSesv2ContactList resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsSesv2ContactList to import
    * @param importFromId The id of the existing AwsSesv2ContactList that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sesv2_contact_list#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsSesv2ContactList to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sesv2_contact_list aws_sesv2_contact_list} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsSesv2ContactListConfig
    */
    constructor(scope: Construct, id: string, config: AwsSesv2ContactListConfig);
    get arn(): string;
    private _contactListName?;
    get contactListName(): string;
    set contactListName(value: string);
    get contactListNameInput(): string | undefined;
    get createdTimestamp(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get lastUpdatedTimestamp(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _topic;
    get topic(): AwsSesv2ContactList.TopicPropertyList;
    putTopic(value: AwsSesv2ContactList.TopicProperty[] | cdktn.IResolvable): void;
    resetTopic(): void;
    get topicInput(): cdktn.IResolvable | AwsSesv2ContactList.TopicProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsSesv2ContactListTopicPropertyToTerraform(struct?: AwsSesv2ContactList.TopicProperty | cdktn.IResolvable): any;
export declare function awsSesv2ContactListTopicPropertyToHclTerraform(struct?: AwsSesv2ContactList.TopicProperty | cdktn.IResolvable): any;
export declare namespace AwsSesv2ContactList {
    interface TopicProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sesv2_contact_list#default_subscription_status AwsSesv2ContactList#default_subscription_status}
        */
        readonly defaultSubscriptionStatus: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sesv2_contact_list#description AwsSesv2ContactList#description}
        */
        readonly description?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sesv2_contact_list#display_name AwsSesv2ContactList#display_name}
        */
        readonly displayName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sesv2_contact_list#topic_name AwsSesv2ContactList#topic_name}
        */
        readonly topicName: string;
    }
    class TopicPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TopicProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TopicProperty | cdktn.IResolvable | undefined);
        private _defaultSubscriptionStatus?;
        get defaultSubscriptionStatus(): string;
        set defaultSubscriptionStatus(value: string);
        get defaultSubscriptionStatusInput(): string | undefined;
        private _description?;
        get description(): string;
        set description(value: string);
        resetDescription(): void;
        get descriptionInput(): string | undefined;
        private _displayName?;
        get displayName(): string;
        set displayName(value: string);
        get displayNameInput(): string | undefined;
        private _topicName?;
        get topicName(): string;
        set topicName(value: string);
        get topicNameInput(): string | undefined;
    }
    class TopicPropertyList extends cdktn.ComplexList {
        internalValue?: TopicProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TopicPropertyOutputReference;
    }
}
