import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsSnapshotsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/rds_snapshots#db_instance_identifier DataAwsSnapshots#db_instance_identifier}
    */
    readonly dbInstanceIdentifier?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/rds_snapshots#db_snapshot_identifier DataAwsSnapshots#db_snapshot_identifier}
    */
    readonly dbSnapshotIdentifier?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/rds_snapshots#include_public DataAwsSnapshots#include_public}
    */
    readonly includePublic?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/rds_snapshots#include_shared DataAwsSnapshots#include_shared}
    */
    readonly includeShared?: boolean | cdktn.IResolvable;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/rds_snapshots#region DataAwsSnapshots#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/rds_snapshots#snapshot_type DataAwsSnapshots#snapshot_type}
    */
    readonly snapshotType?: string;
    /**
    * filter block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/rds_snapshots#filter DataAwsSnapshots#filter}
    */
    readonly filter?: DataAwsSnapshots.FilterProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/rds_snapshots aws_rds_snapshots}
*/
export declare class DataAwsSnapshots extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_rds_snapshots";
    /**
    * Generates CDKTN code for importing a DataAwsSnapshots resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsSnapshots to import
    * @param importFromId The id of the existing DataAwsSnapshots that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/rds_snapshots#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsSnapshots to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/rds_snapshots aws_rds_snapshots} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsSnapshotsConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataAwsSnapshotsConfig);
    private _dbInstanceIdentifier?;
    get dbInstanceIdentifier(): string;
    set dbInstanceIdentifier(value: string);
    resetDbInstanceIdentifier(): void;
    get dbInstanceIdentifierInput(): string | undefined;
    private _dbSnapshotIdentifier?;
    get dbSnapshotIdentifier(): string;
    set dbSnapshotIdentifier(value: string);
    resetDbSnapshotIdentifier(): void;
    get dbSnapshotIdentifierInput(): string | undefined;
    private _includePublic?;
    get includePublic(): boolean | cdktn.IResolvable;
    set includePublic(value: boolean | cdktn.IResolvable);
    resetIncludePublic(): void;
    get includePublicInput(): boolean | cdktn.IResolvable | undefined;
    private _includeShared?;
    get includeShared(): boolean | cdktn.IResolvable;
    set includeShared(value: boolean | cdktn.IResolvable);
    resetIncludeShared(): void;
    get includeSharedInput(): boolean | cdktn.IResolvable | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _snapshotType?;
    get snapshotType(): string;
    set snapshotType(value: string);
    resetSnapshotType(): void;
    get snapshotTypeInput(): string | undefined;
    private _snapshots;
    get snapshots(): DataAwsSnapshots.SnapshotsPropertyList;
    private _filter;
    get filter(): DataAwsSnapshots.FilterPropertyList;
    putFilter(value: DataAwsSnapshots.FilterProperty[] | cdktn.IResolvable): void;
    resetFilter(): void;
    get filterInput(): cdktn.IResolvable | DataAwsSnapshots.FilterProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataAwsSnapshotsTagListPropertyToTerraform(struct?: DataAwsSnapshots.TagListProperty): any;
export declare function dataAwsSnapshotsTagListPropertyToHclTerraform(struct?: DataAwsSnapshots.TagListProperty): any;
export declare function dataAwsSnapshotsSnapshotsPropertyToTerraform(struct?: DataAwsSnapshots.SnapshotsProperty): any;
export declare function dataAwsSnapshotsSnapshotsPropertyToHclTerraform(struct?: DataAwsSnapshots.SnapshotsProperty): any;
export declare function dataAwsSnapshotsFilterPropertyToTerraform(struct?: DataAwsSnapshots.FilterProperty | cdktn.IResolvable): any;
export declare function dataAwsSnapshotsFilterPropertyToHclTerraform(struct?: DataAwsSnapshots.FilterProperty | cdktn.IResolvable): any;
export declare namespace DataAwsSnapshots {
    interface TagListProperty {
    }
    class TagListPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TagListProperty | undefined;
        set internalValue(value: TagListProperty | undefined);
        get key(): string;
        get value(): string;
    }
    class TagListPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TagListPropertyOutputReference;
    }
    interface SnapshotsProperty {
    }
    class SnapshotsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SnapshotsProperty | undefined;
        set internalValue(value: SnapshotsProperty | undefined);
        get allocatedStorage(): number;
        get availabilityZone(): string;
        get dbInstanceIdentifier(): string;
        get dbSnapshotArn(): string;
        get dbSnapshotIdentifier(): string;
        get encrypted(): cdktn.IResolvable;
        get engine(): string;
        get engineVersion(): string;
        get iops(): number;
        get kmsKeyId(): string;
        get licenseModel(): string;
        get optionGroupName(): string;
        get originalSnapshotCreateTime(): string;
        get port(): number;
        get snapshotCreateTime(): string;
        get snapshotType(): string;
        get sourceDbSnapshotIdentifier(): string;
        get sourceRegion(): string;
        get status(): string;
        get storageType(): string;
        private _tagList;
        get tagList(): TagListPropertyList;
        get vpcId(): string;
    }
    class SnapshotsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SnapshotsPropertyOutputReference;
    }
    interface FilterProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/rds_snapshots#name DataAwsSnapshots#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/rds_snapshots#values DataAwsSnapshots#values}
        */
        readonly values: string[];
    }
    class FilterPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): FilterProperty | cdktn.IResolvable | undefined;
        set internalValue(value: FilterProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        get valuesInput(): string[] | undefined;
    }
    class FilterPropertyList extends cdktn.ComplexList {
        internalValue?: FilterProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): FilterPropertyOutputReference;
    }
}
