import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsClusterSnapshotCopyConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rds_cluster_snapshot_copy#copy_tags AwsClusterSnapshotCopy#copy_tags}
    */
    readonly copyTags?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rds_cluster_snapshot_copy#destination_region AwsClusterSnapshotCopy#destination_region}
    */
    readonly destinationRegion?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rds_cluster_snapshot_copy#kms_key_id AwsClusterSnapshotCopy#kms_key_id}
    */
    readonly kmsKeyId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rds_cluster_snapshot_copy#presigned_url AwsClusterSnapshotCopy#presigned_url}
    */
    readonly presignedUrl?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rds_cluster_snapshot_copy#region AwsClusterSnapshotCopy#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rds_cluster_snapshot_copy#shared_accounts AwsClusterSnapshotCopy#shared_accounts}
    */
    readonly sharedAccounts?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rds_cluster_snapshot_copy#source_db_cluster_snapshot_identifier AwsClusterSnapshotCopy#source_db_cluster_snapshot_identifier}
    */
    readonly sourceDbClusterSnapshotIdentifier: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rds_cluster_snapshot_copy#tags AwsClusterSnapshotCopy#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rds_cluster_snapshot_copy#target_db_cluster_snapshot_identifier AwsClusterSnapshotCopy#target_db_cluster_snapshot_identifier}
    */
    readonly targetDbClusterSnapshotIdentifier: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rds_cluster_snapshot_copy#timeouts AwsClusterSnapshotCopy#timeouts}
    */
    readonly timeouts?: AwsClusterSnapshotCopy.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rds_cluster_snapshot_copy aws_rds_cluster_snapshot_copy}
*/
export declare class AwsClusterSnapshotCopy extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_rds_cluster_snapshot_copy";
    /**
    * Generates CDKTN code for importing a AwsClusterSnapshotCopy resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsClusterSnapshotCopy to import
    * @param importFromId The id of the existing AwsClusterSnapshotCopy that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rds_cluster_snapshot_copy#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsClusterSnapshotCopy to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rds_cluster_snapshot_copy aws_rds_cluster_snapshot_copy} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsClusterSnapshotCopyConfig
    */
    constructor(scope: Construct, id: string, config: AwsClusterSnapshotCopyConfig);
    get allocatedStorage(): number;
    private _copyTags?;
    get copyTags(): boolean | cdktn.IResolvable;
    set copyTags(value: boolean | cdktn.IResolvable);
    resetCopyTags(): void;
    get copyTagsInput(): boolean | cdktn.IResolvable | undefined;
    get dbClusterSnapshotArn(): string;
    private _destinationRegion?;
    get destinationRegion(): string;
    set destinationRegion(value: string);
    resetDestinationRegion(): void;
    get destinationRegionInput(): string | undefined;
    get engine(): string;
    get engineVersion(): string;
    get id(): string;
    private _kmsKeyId?;
    get kmsKeyId(): string;
    set kmsKeyId(value: string);
    resetKmsKeyId(): void;
    get kmsKeyIdInput(): string | undefined;
    get licenseModel(): string;
    private _presignedUrl?;
    get presignedUrl(): string;
    set presignedUrl(value: string);
    resetPresignedUrl(): void;
    get presignedUrlInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _sharedAccounts?;
    get sharedAccounts(): string[];
    set sharedAccounts(value: string[]);
    resetSharedAccounts(): void;
    get sharedAccountsInput(): string[] | undefined;
    get snapshotType(): string;
    private _sourceDbClusterSnapshotIdentifier?;
    get sourceDbClusterSnapshotIdentifier(): string;
    set sourceDbClusterSnapshotIdentifier(value: string);
    get sourceDbClusterSnapshotIdentifierInput(): string | undefined;
    get storageEncrypted(): cdktn.IResolvable;
    get storageType(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    private _targetDbClusterSnapshotIdentifier?;
    get targetDbClusterSnapshotIdentifier(): string;
    set targetDbClusterSnapshotIdentifier(value: string);
    get targetDbClusterSnapshotIdentifierInput(): string | undefined;
    get vpcId(): string;
    private _timeouts;
    get timeouts(): AwsClusterSnapshotCopy.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsClusterSnapshotCopy.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsClusterSnapshotCopy.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsClusterSnapshotCopyTimeoutsPropertyToTerraform(struct?: AwsClusterSnapshotCopy.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsClusterSnapshotCopyTimeoutsPropertyToHclTerraform(struct?: AwsClusterSnapshotCopy.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsClusterSnapshotCopy {
    interface TimeoutsProperty {
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rds_cluster_snapshot_copy#create AwsClusterSnapshotCopy#create}
        */
        readonly create?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
    }
}
