import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsReservedInstanceOfferingConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/rds_reserved_instance_offering#db_instance_class DataAwsReservedInstanceOffering#db_instance_class}
    */
    readonly dbInstanceClass: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/rds_reserved_instance_offering#duration DataAwsReservedInstanceOffering#duration}
    */
    readonly duration: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/rds_reserved_instance_offering#id DataAwsReservedInstanceOffering#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/rds_reserved_instance_offering#multi_az DataAwsReservedInstanceOffering#multi_az}
    */
    readonly multiAz: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/rds_reserved_instance_offering#offering_type DataAwsReservedInstanceOffering#offering_type}
    */
    readonly offeringType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/rds_reserved_instance_offering#product_description DataAwsReservedInstanceOffering#product_description}
    */
    readonly productDescription: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/rds_reserved_instance_offering#region DataAwsReservedInstanceOffering#region}
    */
    readonly region?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/rds_reserved_instance_offering aws_rds_reserved_instance_offering}
*/
export declare class DataAwsReservedInstanceOffering extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_rds_reserved_instance_offering";
    /**
    * Generates CDKTN code for importing a DataAwsReservedInstanceOffering resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsReservedInstanceOffering to import
    * @param importFromId The id of the existing DataAwsReservedInstanceOffering that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/rds_reserved_instance_offering#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsReservedInstanceOffering to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/rds_reserved_instance_offering aws_rds_reserved_instance_offering} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsReservedInstanceOfferingConfig
    */
    constructor(scope: Construct, id: string, config: DataAwsReservedInstanceOfferingConfig);
    get currencyCode(): string;
    private _dbInstanceClass?;
    get dbInstanceClass(): string;
    set dbInstanceClass(value: string);
    get dbInstanceClassInput(): string | undefined;
    private _duration?;
    get duration(): number;
    set duration(value: number);
    get durationInput(): number | undefined;
    get fixedPrice(): number;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _multiAz?;
    get multiAz(): boolean | cdktn.IResolvable;
    set multiAz(value: boolean | cdktn.IResolvable);
    get multiAzInput(): boolean | cdktn.IResolvable | undefined;
    get offeringId(): string;
    private _offeringType?;
    get offeringType(): string;
    set offeringType(value: string);
    get offeringTypeInput(): string | undefined;
    private _productDescription?;
    get productDescription(): string;
    set productDescription(value: string);
    get productDescriptionInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
