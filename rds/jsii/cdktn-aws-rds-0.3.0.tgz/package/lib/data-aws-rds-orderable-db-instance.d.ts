import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsOrderableDbInstanceConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/rds_orderable_db_instance#availability_zone_group DataAwsOrderableDbInstance#availability_zone_group}
    */
    readonly availabilityZoneGroup?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/rds_orderable_db_instance#engine DataAwsOrderableDbInstance#engine}
    */
    readonly engine: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/rds_orderable_db_instance#engine_latest_version DataAwsOrderableDbInstance#engine_latest_version}
    */
    readonly engineLatestVersion?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/rds_orderable_db_instance#engine_version DataAwsOrderableDbInstance#engine_version}
    */
    readonly engineVersion?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/rds_orderable_db_instance#id DataAwsOrderableDbInstance#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/rds_orderable_db_instance#instance_class DataAwsOrderableDbInstance#instance_class}
    */
    readonly instanceClass?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/rds_orderable_db_instance#license_model DataAwsOrderableDbInstance#license_model}
    */
    readonly licenseModel?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/rds_orderable_db_instance#preferred_engine_versions DataAwsOrderableDbInstance#preferred_engine_versions}
    */
    readonly preferredEngineVersions?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/rds_orderable_db_instance#preferred_instance_classes DataAwsOrderableDbInstance#preferred_instance_classes}
    */
    readonly preferredInstanceClasses?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/rds_orderable_db_instance#read_replica_capable DataAwsOrderableDbInstance#read_replica_capable}
    */
    readonly readReplicaCapable?: boolean | cdktn.IResolvable;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/rds_orderable_db_instance#region DataAwsOrderableDbInstance#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/rds_orderable_db_instance#storage_type DataAwsOrderableDbInstance#storage_type}
    */
    readonly storageType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/rds_orderable_db_instance#supported_engine_modes DataAwsOrderableDbInstance#supported_engine_modes}
    */
    readonly supportedEngineModes?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/rds_orderable_db_instance#supported_network_types DataAwsOrderableDbInstance#supported_network_types}
    */
    readonly supportedNetworkTypes?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/rds_orderable_db_instance#supports_clusters DataAwsOrderableDbInstance#supports_clusters}
    */
    readonly supportsClusters?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/rds_orderable_db_instance#supports_enhanced_monitoring DataAwsOrderableDbInstance#supports_enhanced_monitoring}
    */
    readonly supportsEnhancedMonitoring?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/rds_orderable_db_instance#supports_global_databases DataAwsOrderableDbInstance#supports_global_databases}
    */
    readonly supportsGlobalDatabases?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/rds_orderable_db_instance#supports_iam_database_authentication DataAwsOrderableDbInstance#supports_iam_database_authentication}
    */
    readonly supportsIamDatabaseAuthentication?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/rds_orderable_db_instance#supports_iops DataAwsOrderableDbInstance#supports_iops}
    */
    readonly supportsIops?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/rds_orderable_db_instance#supports_kerberos_authentication DataAwsOrderableDbInstance#supports_kerberos_authentication}
    */
    readonly supportsKerberosAuthentication?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/rds_orderable_db_instance#supports_multi_az DataAwsOrderableDbInstance#supports_multi_az}
    */
    readonly supportsMultiAz?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/rds_orderable_db_instance#supports_performance_insights DataAwsOrderableDbInstance#supports_performance_insights}
    */
    readonly supportsPerformanceInsights?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/rds_orderable_db_instance#supports_storage_autoscaling DataAwsOrderableDbInstance#supports_storage_autoscaling}
    */
    readonly supportsStorageAutoscaling?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/rds_orderable_db_instance#supports_storage_encryption DataAwsOrderableDbInstance#supports_storage_encryption}
    */
    readonly supportsStorageEncryption?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/rds_orderable_db_instance#vpc DataAwsOrderableDbInstance#vpc}
    */
    readonly vpc?: boolean | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/rds_orderable_db_instance aws_rds_orderable_db_instance}
*/
export declare class DataAwsOrderableDbInstance extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_rds_orderable_db_instance";
    /**
    * Generates CDKTN code for importing a DataAwsOrderableDbInstance resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsOrderableDbInstance to import
    * @param importFromId The id of the existing DataAwsOrderableDbInstance that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/rds_orderable_db_instance#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsOrderableDbInstance to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/rds_orderable_db_instance aws_rds_orderable_db_instance} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsOrderableDbInstanceConfig
    */
    constructor(scope: Construct, id: string, config: DataAwsOrderableDbInstanceConfig);
    private _availabilityZoneGroup?;
    get availabilityZoneGroup(): string;
    set availabilityZoneGroup(value: string);
    resetAvailabilityZoneGroup(): void;
    get availabilityZoneGroupInput(): string | undefined;
    get availabilityZones(): string[];
    private _engine?;
    get engine(): string;
    set engine(value: string);
    get engineInput(): string | undefined;
    private _engineLatestVersion?;
    get engineLatestVersion(): boolean | cdktn.IResolvable;
    set engineLatestVersion(value: boolean | cdktn.IResolvable);
    resetEngineLatestVersion(): void;
    get engineLatestVersionInput(): boolean | cdktn.IResolvable | undefined;
    private _engineVersion?;
    get engineVersion(): string;
    set engineVersion(value: string);
    resetEngineVersion(): void;
    get engineVersionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _instanceClass?;
    get instanceClass(): string;
    set instanceClass(value: string);
    resetInstanceClass(): void;
    get instanceClassInput(): string | undefined;
    private _licenseModel?;
    get licenseModel(): string;
    set licenseModel(value: string);
    resetLicenseModel(): void;
    get licenseModelInput(): string | undefined;
    get maxIopsPerDbInstance(): number;
    get maxIopsPerGib(): number;
    get maxStorageSize(): number;
    get minIopsPerDbInstance(): number;
    get minIopsPerGib(): number;
    get minStorageSize(): number;
    get multiAzCapable(): cdktn.IResolvable;
    get outpostCapable(): cdktn.IResolvable;
    private _preferredEngineVersions?;
    get preferredEngineVersions(): string[];
    set preferredEngineVersions(value: string[]);
    resetPreferredEngineVersions(): void;
    get preferredEngineVersionsInput(): string[] | undefined;
    private _preferredInstanceClasses?;
    get preferredInstanceClasses(): string[];
    set preferredInstanceClasses(value: string[]);
    resetPreferredInstanceClasses(): void;
    get preferredInstanceClassesInput(): string[] | undefined;
    private _readReplicaCapable?;
    get readReplicaCapable(): boolean | cdktn.IResolvable;
    set readReplicaCapable(value: boolean | cdktn.IResolvable);
    resetReadReplicaCapable(): void;
    get readReplicaCapableInput(): boolean | cdktn.IResolvable | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _storageType?;
    get storageType(): string;
    set storageType(value: string);
    resetStorageType(): void;
    get storageTypeInput(): string | undefined;
    private _supportedEngineModes?;
    get supportedEngineModes(): string[];
    set supportedEngineModes(value: string[]);
    resetSupportedEngineModes(): void;
    get supportedEngineModesInput(): string[] | undefined;
    private _supportedNetworkTypes?;
    get supportedNetworkTypes(): string[];
    set supportedNetworkTypes(value: string[]);
    resetSupportedNetworkTypes(): void;
    get supportedNetworkTypesInput(): string[] | undefined;
    private _supportsClusters?;
    get supportsClusters(): boolean | cdktn.IResolvable;
    set supportsClusters(value: boolean | cdktn.IResolvable);
    resetSupportsClusters(): void;
    get supportsClustersInput(): boolean | cdktn.IResolvable | undefined;
    private _supportsEnhancedMonitoring?;
    get supportsEnhancedMonitoring(): boolean | cdktn.IResolvable;
    set supportsEnhancedMonitoring(value: boolean | cdktn.IResolvable);
    resetSupportsEnhancedMonitoring(): void;
    get supportsEnhancedMonitoringInput(): boolean | cdktn.IResolvable | undefined;
    private _supportsGlobalDatabases?;
    get supportsGlobalDatabases(): boolean | cdktn.IResolvable;
    set supportsGlobalDatabases(value: boolean | cdktn.IResolvable);
    resetSupportsGlobalDatabases(): void;
    get supportsGlobalDatabasesInput(): boolean | cdktn.IResolvable | undefined;
    private _supportsIamDatabaseAuthentication?;
    get supportsIamDatabaseAuthentication(): boolean | cdktn.IResolvable;
    set supportsIamDatabaseAuthentication(value: boolean | cdktn.IResolvable);
    resetSupportsIamDatabaseAuthentication(): void;
    get supportsIamDatabaseAuthenticationInput(): boolean | cdktn.IResolvable | undefined;
    private _supportsIops?;
    get supportsIops(): boolean | cdktn.IResolvable;
    set supportsIops(value: boolean | cdktn.IResolvable);
    resetSupportsIops(): void;
    get supportsIopsInput(): boolean | cdktn.IResolvable | undefined;
    private _supportsKerberosAuthentication?;
    get supportsKerberosAuthentication(): boolean | cdktn.IResolvable;
    set supportsKerberosAuthentication(value: boolean | cdktn.IResolvable);
    resetSupportsKerberosAuthentication(): void;
    get supportsKerberosAuthenticationInput(): boolean | cdktn.IResolvable | undefined;
    private _supportsMultiAz?;
    get supportsMultiAz(): boolean | cdktn.IResolvable;
    set supportsMultiAz(value: boolean | cdktn.IResolvable);
    resetSupportsMultiAz(): void;
    get supportsMultiAzInput(): boolean | cdktn.IResolvable | undefined;
    private _supportsPerformanceInsights?;
    get supportsPerformanceInsights(): boolean | cdktn.IResolvable;
    set supportsPerformanceInsights(value: boolean | cdktn.IResolvable);
    resetSupportsPerformanceInsights(): void;
    get supportsPerformanceInsightsInput(): boolean | cdktn.IResolvable | undefined;
    private _supportsStorageAutoscaling?;
    get supportsStorageAutoscaling(): boolean | cdktn.IResolvable;
    set supportsStorageAutoscaling(value: boolean | cdktn.IResolvable);
    resetSupportsStorageAutoscaling(): void;
    get supportsStorageAutoscalingInput(): boolean | cdktn.IResolvable | undefined;
    private _supportsStorageEncryption?;
    get supportsStorageEncryption(): boolean | cdktn.IResolvable;
    set supportsStorageEncryption(value: boolean | cdktn.IResolvable);
    resetSupportsStorageEncryption(): void;
    get supportsStorageEncryptionInput(): boolean | cdktn.IResolvable | undefined;
    private _vpc?;
    get vpc(): boolean | cdktn.IResolvable;
    set vpc(value: boolean | cdktn.IResolvable);
    resetVpc(): void;
    get vpcInput(): boolean | cdktn.IResolvable | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
