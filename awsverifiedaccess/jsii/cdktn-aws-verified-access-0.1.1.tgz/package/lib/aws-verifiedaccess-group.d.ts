import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsVerifiedaccessGroupConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedaccess_group#description AwsVerifiedaccessGroup#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedaccess_group#id AwsVerifiedaccessGroup#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedaccess_group#policy_document AwsVerifiedaccessGroup#policy_document}
    */
    readonly policyDocument?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedaccess_group#region AwsVerifiedaccessGroup#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedaccess_group#tags AwsVerifiedaccessGroup#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedaccess_group#tags_all AwsVerifiedaccessGroup#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedaccess_group#verifiedaccess_instance_id AwsVerifiedaccessGroup#verifiedaccess_instance_id}
    */
    readonly verifiedaccessInstanceId: string;
    /**
    * sse_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedaccess_group#sse_configuration AwsVerifiedaccessGroup#sse_configuration}
    */
    readonly sseConfiguration?: AwsVerifiedaccessGroup.SseConfigurationProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedaccess_group aws_verifiedaccess_group}
*/
export declare class AwsVerifiedaccessGroup extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_verifiedaccess_group";
    /**
    * Generates CDKTN code for importing a AwsVerifiedaccessGroup resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsVerifiedaccessGroup to import
    * @param importFromId The id of the existing AwsVerifiedaccessGroup that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedaccess_group#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsVerifiedaccessGroup to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedaccess_group aws_verifiedaccess_group} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsVerifiedaccessGroupConfig
    */
    constructor(scope: Construct, id: string, config: AwsVerifiedaccessGroupConfig);
    get creationTime(): string;
    get deletionTime(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get lastUpdatedTime(): string;
    get owner(): string;
    private _policyDocument?;
    get policyDocument(): string;
    set policyDocument(value: string);
    resetPolicyDocument(): void;
    get policyDocumentInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    get verifiedaccessGroupArn(): string;
    get verifiedaccessGroupId(): string;
    private _verifiedaccessInstanceId?;
    get verifiedaccessInstanceId(): string;
    set verifiedaccessInstanceId(value: string);
    get verifiedaccessInstanceIdInput(): string | undefined;
    private _sseConfiguration;
    get sseConfiguration(): AwsVerifiedaccessGroup.SseConfigurationPropertyOutputReference;
    putSseConfiguration(value: AwsVerifiedaccessGroup.SseConfigurationProperty): void;
    resetSseConfiguration(): void;
    get sseConfigurationInput(): AwsVerifiedaccessGroup.SseConfigurationProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsVerifiedaccessGroupSseConfigurationPropertyToTerraform(struct?: AwsVerifiedaccessGroup.SseConfigurationPropertyOutputReference | AwsVerifiedaccessGroup.SseConfigurationProperty): any;
export declare function awsVerifiedaccessGroupSseConfigurationPropertyToHclTerraform(struct?: AwsVerifiedaccessGroup.SseConfigurationPropertyOutputReference | AwsVerifiedaccessGroup.SseConfigurationProperty): any;
export declare namespace AwsVerifiedaccessGroup {
    interface SseConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedaccess_group#customer_managed_key_enabled AwsVerifiedaccessGroup#customer_managed_key_enabled}
        */
        readonly customerManagedKeyEnabled?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedaccess_group#kms_key_arn AwsVerifiedaccessGroup#kms_key_arn}
        */
        readonly kmsKeyArn?: string;
    }
    class SseConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SseConfigurationProperty | undefined;
        set internalValue(value: SseConfigurationProperty | undefined);
        private _customerManagedKeyEnabled?;
        get customerManagedKeyEnabled(): boolean | cdktn.IResolvable;
        set customerManagedKeyEnabled(value: boolean | cdktn.IResolvable);
        resetCustomerManagedKeyEnabled(): void;
        get customerManagedKeyEnabledInput(): boolean | cdktn.IResolvable | undefined;
        private _kmsKeyArn?;
        get kmsKeyArn(): string;
        set kmsKeyArn(value: string);
        resetKmsKeyArn(): void;
        get kmsKeyArnInput(): string | undefined;
    }
}
