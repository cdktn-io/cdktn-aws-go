import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsVerifiedaccessInstanceTrustProviderAttachmentConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedaccess_instance_trust_provider_attachment#id AwsVerifiedaccessInstanceTrustProviderAttachment#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedaccess_instance_trust_provider_attachment#region AwsVerifiedaccessInstanceTrustProviderAttachment#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedaccess_instance_trust_provider_attachment#verifiedaccess_instance_id AwsVerifiedaccessInstanceTrustProviderAttachment#verifiedaccess_instance_id}
    */
    readonly verifiedaccessInstanceId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedaccess_instance_trust_provider_attachment#verifiedaccess_trust_provider_id AwsVerifiedaccessInstanceTrustProviderAttachment#verifiedaccess_trust_provider_id}
    */
    readonly verifiedaccessTrustProviderId: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedaccess_instance_trust_provider_attachment aws_verifiedaccess_instance_trust_provider_attachment}
*/
export declare class AwsVerifiedaccessInstanceTrustProviderAttachment extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_verifiedaccess_instance_trust_provider_attachment";
    /**
    * Generates CDKTN code for importing a AwsVerifiedaccessInstanceTrustProviderAttachment resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsVerifiedaccessInstanceTrustProviderAttachment to import
    * @param importFromId The id of the existing AwsVerifiedaccessInstanceTrustProviderAttachment that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedaccess_instance_trust_provider_attachment#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsVerifiedaccessInstanceTrustProviderAttachment to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedaccess_instance_trust_provider_attachment aws_verifiedaccess_instance_trust_provider_attachment} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsVerifiedaccessInstanceTrustProviderAttachmentConfig
    */
    constructor(scope: Construct, id: string, config: AwsVerifiedaccessInstanceTrustProviderAttachmentConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _verifiedaccessInstanceId?;
    get verifiedaccessInstanceId(): string;
    set verifiedaccessInstanceId(value: string);
    get verifiedaccessInstanceIdInput(): string | undefined;
    private _verifiedaccessTrustProviderId?;
    get verifiedaccessTrustProviderId(): string;
    set verifiedaccessTrustProviderId(value: string);
    get verifiedaccessTrustProviderIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
