import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsVerifiedaccessTrustProviderConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedaccess_trust_provider#description AwsVerifiedaccessTrustProvider#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedaccess_trust_provider#device_trust_provider_type AwsVerifiedaccessTrustProvider#device_trust_provider_type}
    */
    readonly deviceTrustProviderType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedaccess_trust_provider#id AwsVerifiedaccessTrustProvider#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedaccess_trust_provider#policy_reference_name AwsVerifiedaccessTrustProvider#policy_reference_name}
    */
    readonly policyReferenceName: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedaccess_trust_provider#region AwsVerifiedaccessTrustProvider#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedaccess_trust_provider#tags AwsVerifiedaccessTrustProvider#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedaccess_trust_provider#tags_all AwsVerifiedaccessTrustProvider#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedaccess_trust_provider#trust_provider_type AwsVerifiedaccessTrustProvider#trust_provider_type}
    */
    readonly trustProviderType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedaccess_trust_provider#user_trust_provider_type AwsVerifiedaccessTrustProvider#user_trust_provider_type}
    */
    readonly userTrustProviderType?: string;
    /**
    * device_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedaccess_trust_provider#device_options AwsVerifiedaccessTrustProvider#device_options}
    */
    readonly deviceOptions?: AwsVerifiedaccessTrustProvider.DeviceOptionsProperty;
    /**
    * native_application_oidc_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedaccess_trust_provider#native_application_oidc_options AwsVerifiedaccessTrustProvider#native_application_oidc_options}
    */
    readonly nativeApplicationOidcOptions?: AwsVerifiedaccessTrustProvider.NativeApplicationOidcOptionsProperty;
    /**
    * oidc_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedaccess_trust_provider#oidc_options AwsVerifiedaccessTrustProvider#oidc_options}
    */
    readonly oidcOptions?: AwsVerifiedaccessTrustProvider.OidcOptionsProperty;
    /**
    * sse_specification block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedaccess_trust_provider#sse_specification AwsVerifiedaccessTrustProvider#sse_specification}
    */
    readonly sseSpecification?: AwsVerifiedaccessTrustProvider.SseSpecificationProperty;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedaccess_trust_provider#timeouts AwsVerifiedaccessTrustProvider#timeouts}
    */
    readonly timeouts?: AwsVerifiedaccessTrustProvider.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedaccess_trust_provider aws_verifiedaccess_trust_provider}
*/
export declare class AwsVerifiedaccessTrustProvider extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_verifiedaccess_trust_provider";
    /**
    * Generates CDKTN code for importing a AwsVerifiedaccessTrustProvider resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsVerifiedaccessTrustProvider to import
    * @param importFromId The id of the existing AwsVerifiedaccessTrustProvider that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedaccess_trust_provider#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsVerifiedaccessTrustProvider to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedaccess_trust_provider aws_verifiedaccess_trust_provider} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsVerifiedaccessTrustProviderConfig
    */
    constructor(scope: Construct, id: string, config: AwsVerifiedaccessTrustProviderConfig);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _deviceTrustProviderType?;
    get deviceTrustProviderType(): string;
    set deviceTrustProviderType(value: string);
    resetDeviceTrustProviderType(): void;
    get deviceTrustProviderTypeInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _policyReferenceName?;
    get policyReferenceName(): string;
    set policyReferenceName(value: string);
    get policyReferenceNameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _trustProviderType?;
    get trustProviderType(): string;
    set trustProviderType(value: string);
    get trustProviderTypeInput(): string | undefined;
    private _userTrustProviderType?;
    get userTrustProviderType(): string;
    set userTrustProviderType(value: string);
    resetUserTrustProviderType(): void;
    get userTrustProviderTypeInput(): string | undefined;
    private _deviceOptions;
    get deviceOptions(): AwsVerifiedaccessTrustProvider.DeviceOptionsPropertyOutputReference;
    putDeviceOptions(value: AwsVerifiedaccessTrustProvider.DeviceOptionsProperty): void;
    resetDeviceOptions(): void;
    get deviceOptionsInput(): AwsVerifiedaccessTrustProvider.DeviceOptionsProperty | undefined;
    private _nativeApplicationOidcOptions;
    get nativeApplicationOidcOptions(): AwsVerifiedaccessTrustProvider.NativeApplicationOidcOptionsPropertyOutputReference;
    putNativeApplicationOidcOptions(value: AwsVerifiedaccessTrustProvider.NativeApplicationOidcOptionsProperty): void;
    resetNativeApplicationOidcOptions(): void;
    get nativeApplicationOidcOptionsInput(): AwsVerifiedaccessTrustProvider.NativeApplicationOidcOptionsProperty | undefined;
    private _oidcOptions;
    get oidcOptions(): AwsVerifiedaccessTrustProvider.OidcOptionsPropertyOutputReference;
    putOidcOptions(value: AwsVerifiedaccessTrustProvider.OidcOptionsProperty): void;
    resetOidcOptions(): void;
    get oidcOptionsInput(): AwsVerifiedaccessTrustProvider.OidcOptionsProperty | undefined;
    private _sseSpecification;
    get sseSpecification(): AwsVerifiedaccessTrustProvider.SseSpecificationPropertyOutputReference;
    putSseSpecification(value: AwsVerifiedaccessTrustProvider.SseSpecificationProperty): void;
    resetSseSpecification(): void;
    get sseSpecificationInput(): AwsVerifiedaccessTrustProvider.SseSpecificationProperty | undefined;
    private _timeouts;
    get timeouts(): AwsVerifiedaccessTrustProvider.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsVerifiedaccessTrustProvider.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsVerifiedaccessTrustProvider.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsVerifiedaccessTrustProviderDeviceOptionsPropertyToTerraform(struct?: AwsVerifiedaccessTrustProvider.DeviceOptionsPropertyOutputReference | AwsVerifiedaccessTrustProvider.DeviceOptionsProperty): any;
export declare function awsVerifiedaccessTrustProviderDeviceOptionsPropertyToHclTerraform(struct?: AwsVerifiedaccessTrustProvider.DeviceOptionsPropertyOutputReference | AwsVerifiedaccessTrustProvider.DeviceOptionsProperty): any;
export declare function awsVerifiedaccessTrustProviderNativeApplicationOidcOptionsPropertyToTerraform(struct?: AwsVerifiedaccessTrustProvider.NativeApplicationOidcOptionsPropertyOutputReference | AwsVerifiedaccessTrustProvider.NativeApplicationOidcOptionsProperty): any;
export declare function awsVerifiedaccessTrustProviderNativeApplicationOidcOptionsPropertyToHclTerraform(struct?: AwsVerifiedaccessTrustProvider.NativeApplicationOidcOptionsPropertyOutputReference | AwsVerifiedaccessTrustProvider.NativeApplicationOidcOptionsProperty): any;
export declare function awsVerifiedaccessTrustProviderOidcOptionsPropertyToTerraform(struct?: AwsVerifiedaccessTrustProvider.OidcOptionsPropertyOutputReference | AwsVerifiedaccessTrustProvider.OidcOptionsProperty): any;
export declare function awsVerifiedaccessTrustProviderOidcOptionsPropertyToHclTerraform(struct?: AwsVerifiedaccessTrustProvider.OidcOptionsPropertyOutputReference | AwsVerifiedaccessTrustProvider.OidcOptionsProperty): any;
export declare function awsVerifiedaccessTrustProviderSseSpecificationPropertyToTerraform(struct?: AwsVerifiedaccessTrustProvider.SseSpecificationPropertyOutputReference | AwsVerifiedaccessTrustProvider.SseSpecificationProperty): any;
export declare function awsVerifiedaccessTrustProviderSseSpecificationPropertyToHclTerraform(struct?: AwsVerifiedaccessTrustProvider.SseSpecificationPropertyOutputReference | AwsVerifiedaccessTrustProvider.SseSpecificationProperty): any;
export declare function awsVerifiedaccessTrustProviderTimeoutsPropertyToTerraform(struct?: AwsVerifiedaccessTrustProvider.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsVerifiedaccessTrustProviderTimeoutsPropertyToHclTerraform(struct?: AwsVerifiedaccessTrustProvider.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsVerifiedaccessTrustProvider {
    interface DeviceOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedaccess_trust_provider#tenant_id AwsVerifiedaccessTrustProvider#tenant_id}
        */
        readonly tenantId?: string;
    }
    class DeviceOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DeviceOptionsProperty | undefined;
        set internalValue(value: DeviceOptionsProperty | undefined);
        private _tenantId?;
        get tenantId(): string;
        set tenantId(value: string);
        resetTenantId(): void;
        get tenantIdInput(): string | undefined;
    }
    interface NativeApplicationOidcOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedaccess_trust_provider#authorization_endpoint AwsVerifiedaccessTrustProvider#authorization_endpoint}
        */
        readonly authorizationEndpoint?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedaccess_trust_provider#client_id AwsVerifiedaccessTrustProvider#client_id}
        */
        readonly clientId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedaccess_trust_provider#client_secret AwsVerifiedaccessTrustProvider#client_secret}
        */
        readonly clientSecret: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedaccess_trust_provider#issuer AwsVerifiedaccessTrustProvider#issuer}
        */
        readonly issuer?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedaccess_trust_provider#public_signing_key_endpoint AwsVerifiedaccessTrustProvider#public_signing_key_endpoint}
        */
        readonly publicSigningKeyEndpoint?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedaccess_trust_provider#scope AwsVerifiedaccessTrustProvider#scope}
        */
        readonly scope?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedaccess_trust_provider#token_endpoint AwsVerifiedaccessTrustProvider#token_endpoint}
        */
        readonly tokenEndpoint?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedaccess_trust_provider#user_info_endpoint AwsVerifiedaccessTrustProvider#user_info_endpoint}
        */
        readonly userInfoEndpoint?: string;
    }
    class NativeApplicationOidcOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): NativeApplicationOidcOptionsProperty | undefined;
        set internalValue(value: NativeApplicationOidcOptionsProperty | undefined);
        private _authorizationEndpoint?;
        get authorizationEndpoint(): string;
        set authorizationEndpoint(value: string);
        resetAuthorizationEndpoint(): void;
        get authorizationEndpointInput(): string | undefined;
        private _clientId?;
        get clientId(): string;
        set clientId(value: string);
        resetClientId(): void;
        get clientIdInput(): string | undefined;
        private _clientSecret?;
        get clientSecret(): string;
        set clientSecret(value: string);
        get clientSecretInput(): string | undefined;
        private _issuer?;
        get issuer(): string;
        set issuer(value: string);
        resetIssuer(): void;
        get issuerInput(): string | undefined;
        private _publicSigningKeyEndpoint?;
        get publicSigningKeyEndpoint(): string;
        set publicSigningKeyEndpoint(value: string);
        resetPublicSigningKeyEndpoint(): void;
        get publicSigningKeyEndpointInput(): string | undefined;
        private _scope?;
        get scope(): string;
        set scope(value: string);
        resetScope(): void;
        get scopeInput(): string | undefined;
        private _tokenEndpoint?;
        get tokenEndpoint(): string;
        set tokenEndpoint(value: string);
        resetTokenEndpoint(): void;
        get tokenEndpointInput(): string | undefined;
        private _userInfoEndpoint?;
        get userInfoEndpoint(): string;
        set userInfoEndpoint(value: string);
        resetUserInfoEndpoint(): void;
        get userInfoEndpointInput(): string | undefined;
    }
    interface OidcOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedaccess_trust_provider#authorization_endpoint AwsVerifiedaccessTrustProvider#authorization_endpoint}
        */
        readonly authorizationEndpoint?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedaccess_trust_provider#client_id AwsVerifiedaccessTrustProvider#client_id}
        */
        readonly clientId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedaccess_trust_provider#client_secret AwsVerifiedaccessTrustProvider#client_secret}
        */
        readonly clientSecret: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedaccess_trust_provider#issuer AwsVerifiedaccessTrustProvider#issuer}
        */
        readonly issuer?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedaccess_trust_provider#scope AwsVerifiedaccessTrustProvider#scope}
        */
        readonly scope?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedaccess_trust_provider#token_endpoint AwsVerifiedaccessTrustProvider#token_endpoint}
        */
        readonly tokenEndpoint?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedaccess_trust_provider#user_info_endpoint AwsVerifiedaccessTrustProvider#user_info_endpoint}
        */
        readonly userInfoEndpoint?: string;
    }
    class OidcOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): OidcOptionsProperty | undefined;
        set internalValue(value: OidcOptionsProperty | undefined);
        private _authorizationEndpoint?;
        get authorizationEndpoint(): string;
        set authorizationEndpoint(value: string);
        resetAuthorizationEndpoint(): void;
        get authorizationEndpointInput(): string | undefined;
        private _clientId?;
        get clientId(): string;
        set clientId(value: string);
        resetClientId(): void;
        get clientIdInput(): string | undefined;
        private _clientSecret?;
        get clientSecret(): string;
        set clientSecret(value: string);
        get clientSecretInput(): string | undefined;
        private _issuer?;
        get issuer(): string;
        set issuer(value: string);
        resetIssuer(): void;
        get issuerInput(): string | undefined;
        private _scope?;
        get scope(): string;
        set scope(value: string);
        resetScope(): void;
        get scopeInput(): string | undefined;
        private _tokenEndpoint?;
        get tokenEndpoint(): string;
        set tokenEndpoint(value: string);
        resetTokenEndpoint(): void;
        get tokenEndpointInput(): string | undefined;
        private _userInfoEndpoint?;
        get userInfoEndpoint(): string;
        set userInfoEndpoint(value: string);
        resetUserInfoEndpoint(): void;
        get userInfoEndpointInput(): string | undefined;
    }
    interface SseSpecificationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedaccess_trust_provider#customer_managed_key_enabled AwsVerifiedaccessTrustProvider#customer_managed_key_enabled}
        */
        readonly customerManagedKeyEnabled?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedaccess_trust_provider#kms_key_arn AwsVerifiedaccessTrustProvider#kms_key_arn}
        */
        readonly kmsKeyArn?: string;
    }
    class SseSpecificationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SseSpecificationProperty | undefined;
        set internalValue(value: SseSpecificationProperty | undefined);
        private _customerManagedKeyEnabled?;
        get customerManagedKeyEnabled(): boolean | cdktn.IResolvable;
        set customerManagedKeyEnabled(value: boolean | cdktn.IResolvable);
        resetCustomerManagedKeyEnabled(): void;
        get customerManagedKeyEnabledInput(): boolean | cdktn.IResolvable | undefined;
        private _kmsKeyArn?;
        get kmsKeyArn(): string;
        set kmsKeyArn(value: string);
        resetKmsKeyArn(): void;
        get kmsKeyArnInput(): string | undefined;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedaccess_trust_provider#create AwsVerifiedaccessTrustProvider#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedaccess_trust_provider#delete AwsVerifiedaccessTrustProvider#delete}
        */
        readonly delete?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedaccess_trust_provider#update AwsVerifiedaccessTrustProvider#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
