import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfInstanceConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedaccess_instance#cidr_endpoints_custom_subdomain TfInstance#cidr_endpoints_custom_subdomain}
    */
    readonly cidrEndpointsCustomSubdomain?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedaccess_instance#description TfInstance#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedaccess_instance#fips_enabled TfInstance#fips_enabled}
    */
    readonly fipsEnabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedaccess_instance#id TfInstance#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedaccess_instance#region TfInstance#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedaccess_instance#tags TfInstance#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedaccess_instance#tags_all TfInstance#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedaccess_instance aws_verifiedaccess_instance}
*/
export declare class TfInstance extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_verifiedaccess_instance";
    /**
    * Generates CDKTN code for importing a TfInstance resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfInstance to import
    * @param importFromId The id of the existing TfInstance that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedaccess_instance#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfInstance to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedaccess_instance aws_verifiedaccess_instance} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfInstanceConfig = {}
    */
    constructor(scope: Construct, id: string, config?: TfInstanceConfig);
    private _cidrEndpointsCustomSubdomain?;
    get cidrEndpointsCustomSubdomain(): string;
    set cidrEndpointsCustomSubdomain(value: string);
    resetCidrEndpointsCustomSubdomain(): void;
    get cidrEndpointsCustomSubdomainInput(): string | undefined;
    get creationTime(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _fipsEnabled?;
    get fipsEnabled(): boolean | cdktn.IResolvable;
    set fipsEnabled(value: boolean | cdktn.IResolvable);
    resetFipsEnabled(): void;
    get fipsEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get lastUpdatedTime(): string;
    get nameServers(): string[];
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _verifiedAccessTrustProviders;
    get verifiedAccessTrustProviders(): TfInstance.VerifiedAccessTrustProvidersPropertyList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfInstanceVerifiedAccessTrustProvidersPropertyToTerraform(struct?: TfInstance.VerifiedAccessTrustProvidersProperty): any;
export declare function tfInstanceVerifiedAccessTrustProvidersPropertyToHclTerraform(struct?: TfInstance.VerifiedAccessTrustProvidersProperty): any;
export declare namespace TfInstance {
    interface VerifiedAccessTrustProvidersProperty {
    }
    class VerifiedAccessTrustProvidersPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): VerifiedAccessTrustProvidersProperty | undefined;
        set internalValue(value: VerifiedAccessTrustProvidersProperty | undefined);
        get description(): string;
        get deviceTrustProviderType(): string;
        get trustProviderType(): string;
        get userTrustProviderType(): string;
        get verifiedAccessTrustProviderId(): string;
    }
    class VerifiedAccessTrustProvidersPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): VerifiedAccessTrustProvidersPropertyOutputReference;
    }
}
