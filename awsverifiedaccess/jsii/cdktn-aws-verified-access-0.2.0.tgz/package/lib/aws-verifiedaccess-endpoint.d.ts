import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfEndpointConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedaccess_endpoint#application_domain TfEndpoint#application_domain}
    */
    readonly applicationDomain?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedaccess_endpoint#attachment_type TfEndpoint#attachment_type}
    */
    readonly attachmentType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedaccess_endpoint#description TfEndpoint#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedaccess_endpoint#domain_certificate_arn TfEndpoint#domain_certificate_arn}
    */
    readonly domainCertificateArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedaccess_endpoint#endpoint_domain_prefix TfEndpoint#endpoint_domain_prefix}
    */
    readonly endpointDomainPrefix?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedaccess_endpoint#endpoint_type TfEndpoint#endpoint_type}
    */
    readonly endpointType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedaccess_endpoint#id TfEndpoint#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedaccess_endpoint#policy_document TfEndpoint#policy_document}
    */
    readonly policyDocument?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedaccess_endpoint#region TfEndpoint#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedaccess_endpoint#security_group_ids TfEndpoint#security_group_ids}
    */
    readonly securityGroupIds?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedaccess_endpoint#tags TfEndpoint#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedaccess_endpoint#tags_all TfEndpoint#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedaccess_endpoint#verified_access_group_id TfEndpoint#verified_access_group_id}
    */
    readonly verifiedAccessGroupId: string;
    /**
    * cidr_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedaccess_endpoint#cidr_options TfEndpoint#cidr_options}
    */
    readonly cidrOptions?: TfEndpoint.CidrOptionsProperty;
    /**
    * load_balancer_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedaccess_endpoint#load_balancer_options TfEndpoint#load_balancer_options}
    */
    readonly loadBalancerOptions?: TfEndpoint.LoadBalancerOptionsProperty;
    /**
    * network_interface_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedaccess_endpoint#network_interface_options TfEndpoint#network_interface_options}
    */
    readonly networkInterfaceOptions?: TfEndpoint.NetworkInterfaceOptionsProperty;
    /**
    * rds_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedaccess_endpoint#rds_options TfEndpoint#rds_options}
    */
    readonly rdsOptions?: TfEndpoint.RdsOptionsProperty;
    /**
    * sse_specification block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedaccess_endpoint#sse_specification TfEndpoint#sse_specification}
    */
    readonly sseSpecification?: TfEndpoint.SseSpecificationProperty;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedaccess_endpoint#timeouts TfEndpoint#timeouts}
    */
    readonly timeouts?: TfEndpoint.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedaccess_endpoint aws_verifiedaccess_endpoint}
*/
export declare class TfEndpoint extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_verifiedaccess_endpoint";
    /**
    * Generates CDKTN code for importing a TfEndpoint resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfEndpoint to import
    * @param importFromId The id of the existing TfEndpoint that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedaccess_endpoint#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfEndpoint to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedaccess_endpoint aws_verifiedaccess_endpoint} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfEndpointConfig
    */
    constructor(scope: Construct, id: string, config: TfEndpointConfig);
    private _applicationDomain?;
    get applicationDomain(): string;
    set applicationDomain(value: string);
    resetApplicationDomain(): void;
    get applicationDomainInput(): string | undefined;
    private _attachmentType?;
    get attachmentType(): string;
    set attachmentType(value: string);
    get attachmentTypeInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get deviceValidationDomain(): string;
    private _domainCertificateArn?;
    get domainCertificateArn(): string;
    set domainCertificateArn(value: string);
    resetDomainCertificateArn(): void;
    get domainCertificateArnInput(): string | undefined;
    get endpointDomain(): string;
    private _endpointDomainPrefix?;
    get endpointDomainPrefix(): string;
    set endpointDomainPrefix(value: string);
    resetEndpointDomainPrefix(): void;
    get endpointDomainPrefixInput(): string | undefined;
    private _endpointType?;
    get endpointType(): string;
    set endpointType(value: string);
    get endpointTypeInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _policyDocument?;
    get policyDocument(): string;
    set policyDocument(value: string);
    resetPolicyDocument(): void;
    get policyDocumentInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _securityGroupIds?;
    get securityGroupIds(): string[];
    set securityGroupIds(value: string[]);
    resetSecurityGroupIds(): void;
    get securityGroupIdsInput(): string[] | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _verifiedAccessGroupId?;
    get verifiedAccessGroupId(): string;
    set verifiedAccessGroupId(value: string);
    get verifiedAccessGroupIdInput(): string | undefined;
    get verifiedAccessInstanceId(): string;
    private _cidrOptions;
    get cidrOptions(): TfEndpoint.CidrOptionsPropertyOutputReference;
    putCidrOptions(value: TfEndpoint.CidrOptionsProperty): void;
    resetCidrOptions(): void;
    get cidrOptionsInput(): TfEndpoint.CidrOptionsProperty | undefined;
    private _loadBalancerOptions;
    get loadBalancerOptions(): TfEndpoint.LoadBalancerOptionsPropertyOutputReference;
    putLoadBalancerOptions(value: TfEndpoint.LoadBalancerOptionsProperty): void;
    resetLoadBalancerOptions(): void;
    get loadBalancerOptionsInput(): TfEndpoint.LoadBalancerOptionsProperty | undefined;
    private _networkInterfaceOptions;
    get networkInterfaceOptions(): TfEndpoint.NetworkInterfaceOptionsPropertyOutputReference;
    putNetworkInterfaceOptions(value: TfEndpoint.NetworkInterfaceOptionsProperty): void;
    resetNetworkInterfaceOptions(): void;
    get networkInterfaceOptionsInput(): TfEndpoint.NetworkInterfaceOptionsProperty | undefined;
    private _rdsOptions;
    get rdsOptions(): TfEndpoint.RdsOptionsPropertyOutputReference;
    putRdsOptions(value: TfEndpoint.RdsOptionsProperty): void;
    resetRdsOptions(): void;
    get rdsOptionsInput(): TfEndpoint.RdsOptionsProperty | undefined;
    private _sseSpecification;
    get sseSpecification(): TfEndpoint.SseSpecificationPropertyOutputReference;
    putSseSpecification(value: TfEndpoint.SseSpecificationProperty): void;
    resetSseSpecification(): void;
    get sseSpecificationInput(): TfEndpoint.SseSpecificationProperty | undefined;
    private _timeouts;
    get timeouts(): TfEndpoint.TimeoutsPropertyOutputReference;
    putTimeouts(value: TfEndpoint.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): TfEndpoint.TimeoutsProperty | cdktn.IResolvable | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfEndpointCidrOptionsPortRangePropertyToTerraform(struct?: TfEndpoint.CidrOptionsPortRangeProperty | cdktn.IResolvable): any;
export declare function tfEndpointCidrOptionsPortRangePropertyToHclTerraform(struct?: TfEndpoint.CidrOptionsPortRangeProperty | cdktn.IResolvable): any;
export declare function tfEndpointCidrOptionsPropertyToTerraform(struct?: TfEndpoint.CidrOptionsPropertyOutputReference | TfEndpoint.CidrOptionsProperty): any;
export declare function tfEndpointCidrOptionsPropertyToHclTerraform(struct?: TfEndpoint.CidrOptionsPropertyOutputReference | TfEndpoint.CidrOptionsProperty): any;
export declare function tfEndpointLoadBalancerOptionsPortRangePropertyToTerraform(struct?: TfEndpoint.LoadBalancerOptionsPortRangeProperty | cdktn.IResolvable): any;
export declare function tfEndpointLoadBalancerOptionsPortRangePropertyToHclTerraform(struct?: TfEndpoint.LoadBalancerOptionsPortRangeProperty | cdktn.IResolvable): any;
export declare function tfEndpointLoadBalancerOptionsPropertyToTerraform(struct?: TfEndpoint.LoadBalancerOptionsPropertyOutputReference | TfEndpoint.LoadBalancerOptionsProperty): any;
export declare function tfEndpointLoadBalancerOptionsPropertyToHclTerraform(struct?: TfEndpoint.LoadBalancerOptionsPropertyOutputReference | TfEndpoint.LoadBalancerOptionsProperty): any;
export declare function tfEndpointNetworkInterfaceOptionsPortRangePropertyToTerraform(struct?: TfEndpoint.NetworkInterfaceOptionsPortRangeProperty | cdktn.IResolvable): any;
export declare function tfEndpointNetworkInterfaceOptionsPortRangePropertyToHclTerraform(struct?: TfEndpoint.NetworkInterfaceOptionsPortRangeProperty | cdktn.IResolvable): any;
export declare function tfEndpointNetworkInterfaceOptionsPropertyToTerraform(struct?: TfEndpoint.NetworkInterfaceOptionsPropertyOutputReference | TfEndpoint.NetworkInterfaceOptionsProperty): any;
export declare function tfEndpointNetworkInterfaceOptionsPropertyToHclTerraform(struct?: TfEndpoint.NetworkInterfaceOptionsPropertyOutputReference | TfEndpoint.NetworkInterfaceOptionsProperty): any;
export declare function tfEndpointRdsOptionsPropertyToTerraform(struct?: TfEndpoint.RdsOptionsPropertyOutputReference | TfEndpoint.RdsOptionsProperty): any;
export declare function tfEndpointRdsOptionsPropertyToHclTerraform(struct?: TfEndpoint.RdsOptionsPropertyOutputReference | TfEndpoint.RdsOptionsProperty): any;
export declare function tfEndpointSseSpecificationPropertyToTerraform(struct?: TfEndpoint.SseSpecificationPropertyOutputReference | TfEndpoint.SseSpecificationProperty): any;
export declare function tfEndpointSseSpecificationPropertyToHclTerraform(struct?: TfEndpoint.SseSpecificationPropertyOutputReference | TfEndpoint.SseSpecificationProperty): any;
export declare function tfEndpointTimeoutsPropertyToTerraform(struct?: TfEndpoint.TimeoutsProperty | cdktn.IResolvable): any;
export declare function tfEndpointTimeoutsPropertyToHclTerraform(struct?: TfEndpoint.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace TfEndpoint {
    interface CidrOptionsPortRangeProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedaccess_endpoint#from_port TfEndpoint#from_port}
        */
        readonly fromPort: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedaccess_endpoint#to_port TfEndpoint#to_port}
        */
        readonly toPort: number;
    }
    class CidrOptionsPortRangePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CidrOptionsPortRangeProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CidrOptionsPortRangeProperty | cdktn.IResolvable | undefined);
        private _fromPort?;
        get fromPort(): number;
        set fromPort(value: number);
        get fromPortInput(): number | undefined;
        private _toPort?;
        get toPort(): number;
        set toPort(value: number);
        get toPortInput(): number | undefined;
    }
    class CidrOptionsPortRangePropertyList extends cdktn.ComplexList {
        internalValue?: CidrOptionsPortRangeProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CidrOptionsPortRangePropertyOutputReference;
    }
    interface CidrOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedaccess_endpoint#cidr TfEndpoint#cidr}
        */
        readonly cidr: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedaccess_endpoint#protocol TfEndpoint#protocol}
        */
        readonly protocol?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedaccess_endpoint#subnet_ids TfEndpoint#subnet_ids}
        */
        readonly subnetIds?: string[];
        /**
        * port_range block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedaccess_endpoint#port_range TfEndpoint#port_range}
        */
        readonly portRange: CidrOptionsPortRangeProperty[] | cdktn.IResolvable;
    }
    class CidrOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CidrOptionsProperty | undefined;
        set internalValue(value: CidrOptionsProperty | undefined);
        private _cidr?;
        get cidr(): string;
        set cidr(value: string);
        get cidrInput(): string | undefined;
        private _protocol?;
        get protocol(): string;
        set protocol(value: string);
        resetProtocol(): void;
        get protocolInput(): string | undefined;
        private _subnetIds?;
        get subnetIds(): string[];
        set subnetIds(value: string[]);
        resetSubnetIds(): void;
        get subnetIdsInput(): string[] | undefined;
        private _portRange;
        get portRange(): CidrOptionsPortRangePropertyList;
        putPortRange(value: CidrOptionsPortRangeProperty[] | cdktn.IResolvable): void;
        get portRangeInput(): cdktn.IResolvable | CidrOptionsPortRangeProperty[] | undefined;
    }
    interface LoadBalancerOptionsPortRangeProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedaccess_endpoint#from_port TfEndpoint#from_port}
        */
        readonly fromPort: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedaccess_endpoint#to_port TfEndpoint#to_port}
        */
        readonly toPort: number;
    }
    class LoadBalancerOptionsPortRangePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): LoadBalancerOptionsPortRangeProperty | cdktn.IResolvable | undefined;
        set internalValue(value: LoadBalancerOptionsPortRangeProperty | cdktn.IResolvable | undefined);
        private _fromPort?;
        get fromPort(): number;
        set fromPort(value: number);
        get fromPortInput(): number | undefined;
        private _toPort?;
        get toPort(): number;
        set toPort(value: number);
        get toPortInput(): number | undefined;
    }
    class LoadBalancerOptionsPortRangePropertyList extends cdktn.ComplexList {
        internalValue?: LoadBalancerOptionsPortRangeProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): LoadBalancerOptionsPortRangePropertyOutputReference;
    }
    interface LoadBalancerOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedaccess_endpoint#load_balancer_arn TfEndpoint#load_balancer_arn}
        */
        readonly loadBalancerArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedaccess_endpoint#port TfEndpoint#port}
        */
        readonly port?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedaccess_endpoint#protocol TfEndpoint#protocol}
        */
        readonly protocol?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedaccess_endpoint#subnet_ids TfEndpoint#subnet_ids}
        */
        readonly subnetIds?: string[];
        /**
        * port_range block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedaccess_endpoint#port_range TfEndpoint#port_range}
        */
        readonly portRange?: LoadBalancerOptionsPortRangeProperty[] | cdktn.IResolvable;
    }
    class LoadBalancerOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): LoadBalancerOptionsProperty | undefined;
        set internalValue(value: LoadBalancerOptionsProperty | undefined);
        private _loadBalancerArn?;
        get loadBalancerArn(): string;
        set loadBalancerArn(value: string);
        resetLoadBalancerArn(): void;
        get loadBalancerArnInput(): string | undefined;
        private _port?;
        get port(): number;
        set port(value: number);
        resetPort(): void;
        get portInput(): number | undefined;
        private _protocol?;
        get protocol(): string;
        set protocol(value: string);
        resetProtocol(): void;
        get protocolInput(): string | undefined;
        private _subnetIds?;
        get subnetIds(): string[];
        set subnetIds(value: string[]);
        resetSubnetIds(): void;
        get subnetIdsInput(): string[] | undefined;
        private _portRange;
        get portRange(): LoadBalancerOptionsPortRangePropertyList;
        putPortRange(value: LoadBalancerOptionsPortRangeProperty[] | cdktn.IResolvable): void;
        resetPortRange(): void;
        get portRangeInput(): cdktn.IResolvable | LoadBalancerOptionsPortRangeProperty[] | undefined;
    }
    interface NetworkInterfaceOptionsPortRangeProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedaccess_endpoint#from_port TfEndpoint#from_port}
        */
        readonly fromPort: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedaccess_endpoint#to_port TfEndpoint#to_port}
        */
        readonly toPort: number;
    }
    class NetworkInterfaceOptionsPortRangePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): NetworkInterfaceOptionsPortRangeProperty | cdktn.IResolvable | undefined;
        set internalValue(value: NetworkInterfaceOptionsPortRangeProperty | cdktn.IResolvable | undefined);
        private _fromPort?;
        get fromPort(): number;
        set fromPort(value: number);
        get fromPortInput(): number | undefined;
        private _toPort?;
        get toPort(): number;
        set toPort(value: number);
        get toPortInput(): number | undefined;
    }
    class NetworkInterfaceOptionsPortRangePropertyList extends cdktn.ComplexList {
        internalValue?: NetworkInterfaceOptionsPortRangeProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): NetworkInterfaceOptionsPortRangePropertyOutputReference;
    }
    interface NetworkInterfaceOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedaccess_endpoint#network_interface_id TfEndpoint#network_interface_id}
        */
        readonly networkInterfaceId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedaccess_endpoint#port TfEndpoint#port}
        */
        readonly port?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedaccess_endpoint#protocol TfEndpoint#protocol}
        */
        readonly protocol?: string;
        /**
        * port_range block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedaccess_endpoint#port_range TfEndpoint#port_range}
        */
        readonly portRange?: NetworkInterfaceOptionsPortRangeProperty[] | cdktn.IResolvable;
    }
    class NetworkInterfaceOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): NetworkInterfaceOptionsProperty | undefined;
        set internalValue(value: NetworkInterfaceOptionsProperty | undefined);
        private _networkInterfaceId?;
        get networkInterfaceId(): string;
        set networkInterfaceId(value: string);
        resetNetworkInterfaceId(): void;
        get networkInterfaceIdInput(): string | undefined;
        private _port?;
        get port(): number;
        set port(value: number);
        resetPort(): void;
        get portInput(): number | undefined;
        private _protocol?;
        get protocol(): string;
        set protocol(value: string);
        resetProtocol(): void;
        get protocolInput(): string | undefined;
        private _portRange;
        get portRange(): NetworkInterfaceOptionsPortRangePropertyList;
        putPortRange(value: NetworkInterfaceOptionsPortRangeProperty[] | cdktn.IResolvable): void;
        resetPortRange(): void;
        get portRangeInput(): cdktn.IResolvable | NetworkInterfaceOptionsPortRangeProperty[] | undefined;
    }
    interface RdsOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedaccess_endpoint#port TfEndpoint#port}
        */
        readonly port?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedaccess_endpoint#protocol TfEndpoint#protocol}
        */
        readonly protocol?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedaccess_endpoint#rds_db_cluster_arn TfEndpoint#rds_db_cluster_arn}
        */
        readonly rdsDbClusterArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedaccess_endpoint#rds_db_instance_arn TfEndpoint#rds_db_instance_arn}
        */
        readonly rdsDbInstanceArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedaccess_endpoint#rds_db_proxy_arn TfEndpoint#rds_db_proxy_arn}
        */
        readonly rdsDbProxyArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedaccess_endpoint#rds_endpoint TfEndpoint#rds_endpoint}
        */
        readonly rdsEndpoint?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedaccess_endpoint#subnet_ids TfEndpoint#subnet_ids}
        */
        readonly subnetIds?: string[];
    }
    class RdsOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RdsOptionsProperty | undefined;
        set internalValue(value: RdsOptionsProperty | undefined);
        private _port?;
        get port(): number;
        set port(value: number);
        resetPort(): void;
        get portInput(): number | undefined;
        private _protocol?;
        get protocol(): string;
        set protocol(value: string);
        resetProtocol(): void;
        get protocolInput(): string | undefined;
        private _rdsDbClusterArn?;
        get rdsDbClusterArn(): string;
        set rdsDbClusterArn(value: string);
        resetRdsDbClusterArn(): void;
        get rdsDbClusterArnInput(): string | undefined;
        private _rdsDbInstanceArn?;
        get rdsDbInstanceArn(): string;
        set rdsDbInstanceArn(value: string);
        resetRdsDbInstanceArn(): void;
        get rdsDbInstanceArnInput(): string | undefined;
        private _rdsDbProxyArn?;
        get rdsDbProxyArn(): string;
        set rdsDbProxyArn(value: string);
        resetRdsDbProxyArn(): void;
        get rdsDbProxyArnInput(): string | undefined;
        private _rdsEndpoint?;
        get rdsEndpoint(): string;
        set rdsEndpoint(value: string);
        resetRdsEndpoint(): void;
        get rdsEndpointInput(): string | undefined;
        private _subnetIds?;
        get subnetIds(): string[];
        set subnetIds(value: string[]);
        resetSubnetIds(): void;
        get subnetIdsInput(): string[] | undefined;
    }
    interface SseSpecificationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedaccess_endpoint#customer_managed_key_enabled TfEndpoint#customer_managed_key_enabled}
        */
        readonly customerManagedKeyEnabled?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedaccess_endpoint#kms_key_arn TfEndpoint#kms_key_arn}
        */
        readonly kmsKeyArn?: string;
    }
    class SseSpecificationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SseSpecificationProperty | undefined;
        set internalValue(value: SseSpecificationProperty | undefined);
        private _customerManagedKeyEnabled?;
        get customerManagedKeyEnabled(): boolean | cdktn.IResolvable;
        set customerManagedKeyEnabled(value: boolean | cdktn.IResolvable);
        resetCustomerManagedKeyEnabled(): void;
        get customerManagedKeyEnabledInput(): boolean | cdktn.IResolvable | undefined;
        private _kmsKeyArn?;
        get kmsKeyArn(): string;
        set kmsKeyArn(value: string);
        resetKmsKeyArn(): void;
        get kmsKeyArnInput(): string | undefined;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedaccess_endpoint#create TfEndpoint#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedaccess_endpoint#delete TfEndpoint#delete}
        */
        readonly delete?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedaccess_endpoint#update TfEndpoint#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
