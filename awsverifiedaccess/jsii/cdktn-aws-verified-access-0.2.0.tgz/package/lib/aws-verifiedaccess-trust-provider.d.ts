import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfTrustProviderConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedaccess_trust_provider#description TfTrustProvider#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedaccess_trust_provider#device_trust_provider_type TfTrustProvider#device_trust_provider_type}
    */
    readonly deviceTrustProviderType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedaccess_trust_provider#id TfTrustProvider#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedaccess_trust_provider#policy_reference_name TfTrustProvider#policy_reference_name}
    */
    readonly policyReferenceName: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedaccess_trust_provider#region TfTrustProvider#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedaccess_trust_provider#tags TfTrustProvider#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedaccess_trust_provider#tags_all TfTrustProvider#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedaccess_trust_provider#trust_provider_type TfTrustProvider#trust_provider_type}
    */
    readonly trustProviderType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedaccess_trust_provider#user_trust_provider_type TfTrustProvider#user_trust_provider_type}
    */
    readonly userTrustProviderType?: string;
    /**
    * device_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedaccess_trust_provider#device_options TfTrustProvider#device_options}
    */
    readonly deviceOptions?: TfTrustProvider.DeviceOptionsProperty;
    /**
    * native_application_oidc_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedaccess_trust_provider#native_application_oidc_options TfTrustProvider#native_application_oidc_options}
    */
    readonly nativeApplicationOidcOptions?: TfTrustProvider.NativeApplicationOidcOptionsProperty;
    /**
    * oidc_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedaccess_trust_provider#oidc_options TfTrustProvider#oidc_options}
    */
    readonly oidcOptions?: TfTrustProvider.OidcOptionsProperty;
    /**
    * sse_specification block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedaccess_trust_provider#sse_specification TfTrustProvider#sse_specification}
    */
    readonly sseSpecification?: TfTrustProvider.SseSpecificationProperty;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedaccess_trust_provider#timeouts TfTrustProvider#timeouts}
    */
    readonly timeouts?: TfTrustProvider.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedaccess_trust_provider aws_verifiedaccess_trust_provider}
*/
export declare class TfTrustProvider extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_verifiedaccess_trust_provider";
    /**
    * Generates CDKTN code for importing a TfTrustProvider resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfTrustProvider to import
    * @param importFromId The id of the existing TfTrustProvider that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedaccess_trust_provider#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfTrustProvider to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedaccess_trust_provider aws_verifiedaccess_trust_provider} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfTrustProviderConfig
    */
    constructor(scope: Construct, id: string, config: TfTrustProviderConfig);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _deviceTrustProviderType?;
    get deviceTrustProviderType(): string;
    set deviceTrustProviderType(value: string);
    resetDeviceTrustProviderType(): void;
    get deviceTrustProviderTypeInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _policyReferenceName?;
    get policyReferenceName(): string;
    set policyReferenceName(value: string);
    get policyReferenceNameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _trustProviderType?;
    get trustProviderType(): string;
    set trustProviderType(value: string);
    get trustProviderTypeInput(): string | undefined;
    private _userTrustProviderType?;
    get userTrustProviderType(): string;
    set userTrustProviderType(value: string);
    resetUserTrustProviderType(): void;
    get userTrustProviderTypeInput(): string | undefined;
    private _deviceOptions;
    get deviceOptions(): TfTrustProvider.DeviceOptionsPropertyOutputReference;
    putDeviceOptions(value: TfTrustProvider.DeviceOptionsProperty): void;
    resetDeviceOptions(): void;
    get deviceOptionsInput(): TfTrustProvider.DeviceOptionsProperty | undefined;
    private _nativeApplicationOidcOptions;
    get nativeApplicationOidcOptions(): TfTrustProvider.NativeApplicationOidcOptionsPropertyOutputReference;
    putNativeApplicationOidcOptions(value: TfTrustProvider.NativeApplicationOidcOptionsProperty): void;
    resetNativeApplicationOidcOptions(): void;
    get nativeApplicationOidcOptionsInput(): TfTrustProvider.NativeApplicationOidcOptionsProperty | undefined;
    private _oidcOptions;
    get oidcOptions(): TfTrustProvider.OidcOptionsPropertyOutputReference;
    putOidcOptions(value: TfTrustProvider.OidcOptionsProperty): void;
    resetOidcOptions(): void;
    get oidcOptionsInput(): TfTrustProvider.OidcOptionsProperty | undefined;
    private _sseSpecification;
    get sseSpecification(): TfTrustProvider.SseSpecificationPropertyOutputReference;
    putSseSpecification(value: TfTrustProvider.SseSpecificationProperty): void;
    resetSseSpecification(): void;
    get sseSpecificationInput(): TfTrustProvider.SseSpecificationProperty | undefined;
    private _timeouts;
    get timeouts(): TfTrustProvider.TimeoutsPropertyOutputReference;
    putTimeouts(value: TfTrustProvider.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | TfTrustProvider.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfTrustProviderDeviceOptionsPropertyToTerraform(struct?: TfTrustProvider.DeviceOptionsPropertyOutputReference | TfTrustProvider.DeviceOptionsProperty): any;
export declare function tfTrustProviderDeviceOptionsPropertyToHclTerraform(struct?: TfTrustProvider.DeviceOptionsPropertyOutputReference | TfTrustProvider.DeviceOptionsProperty): any;
export declare function tfTrustProviderNativeApplicationOidcOptionsPropertyToTerraform(struct?: TfTrustProvider.NativeApplicationOidcOptionsPropertyOutputReference | TfTrustProvider.NativeApplicationOidcOptionsProperty): any;
export declare function tfTrustProviderNativeApplicationOidcOptionsPropertyToHclTerraform(struct?: TfTrustProvider.NativeApplicationOidcOptionsPropertyOutputReference | TfTrustProvider.NativeApplicationOidcOptionsProperty): any;
export declare function tfTrustProviderOidcOptionsPropertyToTerraform(struct?: TfTrustProvider.OidcOptionsPropertyOutputReference | TfTrustProvider.OidcOptionsProperty): any;
export declare function tfTrustProviderOidcOptionsPropertyToHclTerraform(struct?: TfTrustProvider.OidcOptionsPropertyOutputReference | TfTrustProvider.OidcOptionsProperty): any;
export declare function tfTrustProviderSseSpecificationPropertyToTerraform(struct?: TfTrustProvider.SseSpecificationPropertyOutputReference | TfTrustProvider.SseSpecificationProperty): any;
export declare function tfTrustProviderSseSpecificationPropertyToHclTerraform(struct?: TfTrustProvider.SseSpecificationPropertyOutputReference | TfTrustProvider.SseSpecificationProperty): any;
export declare function tfTrustProviderTimeoutsPropertyToTerraform(struct?: TfTrustProvider.TimeoutsProperty | cdktn.IResolvable): any;
export declare function tfTrustProviderTimeoutsPropertyToHclTerraform(struct?: TfTrustProvider.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace TfTrustProvider {
    interface DeviceOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedaccess_trust_provider#tenant_id TfTrustProvider#tenant_id}
        */
        readonly tenantId?: string;
    }
    class DeviceOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DeviceOptionsProperty | undefined;
        set internalValue(value: DeviceOptionsProperty | undefined);
        private _tenantId?;
        get tenantId(): string;
        set tenantId(value: string);
        resetTenantId(): void;
        get tenantIdInput(): string | undefined;
    }
    interface NativeApplicationOidcOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedaccess_trust_provider#authorization_endpoint TfTrustProvider#authorization_endpoint}
        */
        readonly authorizationEndpoint?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedaccess_trust_provider#client_id TfTrustProvider#client_id}
        */
        readonly clientId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedaccess_trust_provider#client_secret TfTrustProvider#client_secret}
        */
        readonly clientSecret: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedaccess_trust_provider#issuer TfTrustProvider#issuer}
        */
        readonly issuer?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedaccess_trust_provider#public_signing_key_endpoint TfTrustProvider#public_signing_key_endpoint}
        */
        readonly publicSigningKeyEndpoint?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedaccess_trust_provider#scope TfTrustProvider#scope}
        */
        readonly scope?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedaccess_trust_provider#token_endpoint TfTrustProvider#token_endpoint}
        */
        readonly tokenEndpoint?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedaccess_trust_provider#user_info_endpoint TfTrustProvider#user_info_endpoint}
        */
        readonly userInfoEndpoint?: string;
    }
    class NativeApplicationOidcOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): NativeApplicationOidcOptionsProperty | undefined;
        set internalValue(value: NativeApplicationOidcOptionsProperty | undefined);
        private _authorizationEndpoint?;
        get authorizationEndpoint(): string;
        set authorizationEndpoint(value: string);
        resetAuthorizationEndpoint(): void;
        get authorizationEndpointInput(): string | undefined;
        private _clientId?;
        get clientId(): string;
        set clientId(value: string);
        resetClientId(): void;
        get clientIdInput(): string | undefined;
        private _clientSecret?;
        get clientSecret(): string;
        set clientSecret(value: string);
        get clientSecretInput(): string | undefined;
        private _issuer?;
        get issuer(): string;
        set issuer(value: string);
        resetIssuer(): void;
        get issuerInput(): string | undefined;
        private _publicSigningKeyEndpoint?;
        get publicSigningKeyEndpoint(): string;
        set publicSigningKeyEndpoint(value: string);
        resetPublicSigningKeyEndpoint(): void;
        get publicSigningKeyEndpointInput(): string | undefined;
        private _scope?;
        get scope(): string;
        set scope(value: string);
        resetScope(): void;
        get scopeInput(): string | undefined;
        private _tokenEndpoint?;
        get tokenEndpoint(): string;
        set tokenEndpoint(value: string);
        resetTokenEndpoint(): void;
        get tokenEndpointInput(): string | undefined;
        private _userInfoEndpoint?;
        get userInfoEndpoint(): string;
        set userInfoEndpoint(value: string);
        resetUserInfoEndpoint(): void;
        get userInfoEndpointInput(): string | undefined;
    }
    interface OidcOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedaccess_trust_provider#authorization_endpoint TfTrustProvider#authorization_endpoint}
        */
        readonly authorizationEndpoint?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedaccess_trust_provider#client_id TfTrustProvider#client_id}
        */
        readonly clientId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedaccess_trust_provider#client_secret TfTrustProvider#client_secret}
        */
        readonly clientSecret: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedaccess_trust_provider#issuer TfTrustProvider#issuer}
        */
        readonly issuer?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedaccess_trust_provider#scope TfTrustProvider#scope}
        */
        readonly scope?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedaccess_trust_provider#token_endpoint TfTrustProvider#token_endpoint}
        */
        readonly tokenEndpoint?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedaccess_trust_provider#user_info_endpoint TfTrustProvider#user_info_endpoint}
        */
        readonly userInfoEndpoint?: string;
    }
    class OidcOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): OidcOptionsProperty | undefined;
        set internalValue(value: OidcOptionsProperty | undefined);
        private _authorizationEndpoint?;
        get authorizationEndpoint(): string;
        set authorizationEndpoint(value: string);
        resetAuthorizationEndpoint(): void;
        get authorizationEndpointInput(): string | undefined;
        private _clientId?;
        get clientId(): string;
        set clientId(value: string);
        resetClientId(): void;
        get clientIdInput(): string | undefined;
        private _clientSecret?;
        get clientSecret(): string;
        set clientSecret(value: string);
        get clientSecretInput(): string | undefined;
        private _issuer?;
        get issuer(): string;
        set issuer(value: string);
        resetIssuer(): void;
        get issuerInput(): string | undefined;
        private _scope?;
        get scope(): string;
        set scope(value: string);
        resetScope(): void;
        get scopeInput(): string | undefined;
        private _tokenEndpoint?;
        get tokenEndpoint(): string;
        set tokenEndpoint(value: string);
        resetTokenEndpoint(): void;
        get tokenEndpointInput(): string | undefined;
        private _userInfoEndpoint?;
        get userInfoEndpoint(): string;
        set userInfoEndpoint(value: string);
        resetUserInfoEndpoint(): void;
        get userInfoEndpointInput(): string | undefined;
    }
    interface SseSpecificationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedaccess_trust_provider#customer_managed_key_enabled TfTrustProvider#customer_managed_key_enabled}
        */
        readonly customerManagedKeyEnabled?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedaccess_trust_provider#kms_key_arn TfTrustProvider#kms_key_arn}
        */
        readonly kmsKeyArn?: string;
    }
    class SseSpecificationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SseSpecificationProperty | undefined;
        set internalValue(value: SseSpecificationProperty | undefined);
        private _customerManagedKeyEnabled?;
        get customerManagedKeyEnabled(): boolean | cdktn.IResolvable;
        set customerManagedKeyEnabled(value: boolean | cdktn.IResolvable);
        resetCustomerManagedKeyEnabled(): void;
        get customerManagedKeyEnabledInput(): boolean | cdktn.IResolvable | undefined;
        private _kmsKeyArn?;
        get kmsKeyArn(): string;
        set kmsKeyArn(value: string);
        resetKmsKeyArn(): void;
        get kmsKeyArnInput(): string | undefined;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedaccess_trust_provider#create TfTrustProvider#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedaccess_trust_provider#delete TfTrustProvider#delete}
        */
        readonly delete?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedaccess_trust_provider#update TfTrustProvider#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
