import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsDbServerConfig extends cdktn.TerraformMetaArguments {
    /**
    * The identifier of the database server to retrieve information about.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/odb_db_server#cloud_exadata_infrastructure_id DataAwsDbServer#cloud_exadata_infrastructure_id}
    */
    readonly cloudExadataInfrastructureId: string;
    /**
    * The identifier of the the database server.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/odb_db_server#id DataAwsDbServer#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/odb_db_server#region DataAwsDbServer#region}
    */
    readonly region?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/odb_db_server aws_odb_db_server}
*/
export declare class DataAwsDbServer extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_odb_db_server";
    /**
    * Generates CDKTN code for importing a DataAwsDbServer resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsDbServer to import
    * @param importFromId The id of the existing DataAwsDbServer that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/odb_db_server#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsDbServer to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/odb_db_server aws_odb_db_server} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsDbServerConfig
    */
    constructor(scope: Construct, id: string, config: DataAwsDbServerConfig);
    get autonomousVirtualMachineIds(): string[];
    get autonomousVmClusterIds(): string[];
    private _cloudExadataInfrastructureId?;
    get cloudExadataInfrastructureId(): string;
    set cloudExadataInfrastructureId(value: string);
    get cloudExadataInfrastructureIdInput(): string | undefined;
    get computeModel(): string;
    get cpuCoreCount(): number;
    get createdAt(): string;
    get dbNodeStorageSizeInGbs(): number;
    private _dbServerPatchingDetails;
    get dbServerPatchingDetails(): DataAwsDbServer.DbServerPatchingDetailsPropertyList;
    get displayName(): string;
    get exadataInfrastructureId(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    get maxCpuCount(): number;
    get maxDbNodeStorageInGbs(): number;
    get maxMemoryInGbs(): number;
    get memorySizeInGbs(): number;
    get ociResourceAnchorName(): string;
    get ocid(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get shape(): string;
    get status(): string;
    get statusReason(): string;
    get vmClusterIds(): string[];
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataAwsDbServerDbServerPatchingDetailsPropertyToTerraform(struct?: DataAwsDbServer.DbServerPatchingDetailsProperty): any;
export declare function dataAwsDbServerDbServerPatchingDetailsPropertyToHclTerraform(struct?: DataAwsDbServer.DbServerPatchingDetailsProperty): any;
export declare namespace DataAwsDbServer {
    interface DbServerPatchingDetailsProperty {
    }
    class DbServerPatchingDetailsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DbServerPatchingDetailsProperty | undefined;
        set internalValue(value: DbServerPatchingDetailsProperty | undefined);
        get estimatedPatchDuration(): number;
        get patchingStatus(): string;
        get timePatchingEnded(): string;
        get timePatchingStarted(): string;
    }
    class DbServerPatchingDetailsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DbServerPatchingDetailsPropertyOutputReference;
    }
}
