import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsDbNodesConfig extends cdktn.TerraformMetaArguments {
    /**
    * Id of the cloud VM cluster. The unique identifier of the VM cluster.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/odb_db_nodes#cloud_vm_cluster_id DataAwsDbNodes#cloud_vm_cluster_id}
    */
    readonly cloudVmClusterId: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/odb_db_nodes#region DataAwsDbNodes#region}
    */
    readonly region?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/odb_db_nodes aws_odb_db_nodes}
*/
export declare class DataAwsDbNodes extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_odb_db_nodes";
    /**
    * Generates CDKTN code for importing a DataAwsDbNodes resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsDbNodes to import
    * @param importFromId The id of the existing DataAwsDbNodes that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/odb_db_nodes#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsDbNodes to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/odb_db_nodes aws_odb_db_nodes} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsDbNodesConfig
    */
    constructor(scope: Construct, id: string, config: DataAwsDbNodesConfig);
    private _cloudVmClusterId?;
    get cloudVmClusterId(): string;
    set cloudVmClusterId(value: string);
    get cloudVmClusterIdInput(): string | undefined;
    private _dbNodes;
    get dbNodes(): DataAwsDbNodes.DbNodesPropertyList;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataAwsDbNodesDbNodesPropertyToTerraform(struct?: DataAwsDbNodes.DbNodesProperty): any;
export declare function dataAwsDbNodesDbNodesPropertyToHclTerraform(struct?: DataAwsDbNodes.DbNodesProperty): any;
export declare namespace DataAwsDbNodes {
    interface DbNodesProperty {
    }
    class DbNodesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DbNodesProperty | undefined;
        set internalValue(value: DbNodesProperty | undefined);
        get additionalDetails(): string;
        get arn(): string;
        get backupIpId(): string;
        get backupVnic2Id(): string;
        get backupVnicId(): string;
        get cpuCoreCount(): number;
        get createdAt(): string;
        get dbNodeStorageSize(): number;
        get dbServerId(): string;
        get dbSystemId(): string;
        get faultDomain(): string;
        get hostIpId(): string;
        get hostname(): string;
        get id(): string;
        get maintenanceType(): string;
        get memorySize(): number;
        get ociResourceAnchorName(): string;
        get ocid(): string;
        get softwareStorageSize(): number;
        get status(): string;
        get statusReason(): string;
        get timeMaintenanceWindowEnd(): string;
        get timeMaintenanceWindowStart(): string;
        get totalCpuCoreCount(): number;
        get vnic2Id(): string;
        get vnicId(): string;
    }
    class DbNodesPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DbNodesPropertyOutputReference;
    }
}
