import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsDbNodeConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/odb_db_node#cloud_vm_cluster_id DataAwsDbNode#cloud_vm_cluster_id}
    */
    readonly cloudVmClusterId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/odb_db_node#id DataAwsDbNode#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/odb_db_node#region DataAwsDbNode#region}
    */
    readonly region?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/odb_db_node aws_odb_db_node}
*/
export declare class DataAwsDbNode extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_odb_db_node";
    /**
    * Generates CDKTN code for importing a DataAwsDbNode resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsDbNode to import
    * @param importFromId The id of the existing DataAwsDbNode that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/odb_db_node#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsDbNode to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/odb_db_node aws_odb_db_node} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsDbNodeConfig
    */
    constructor(scope: Construct, id: string, config: DataAwsDbNodeConfig);
    get additionalDetails(): string;
    get arn(): string;
    get backupIpId(): string;
    get backupVnic2Id(): string;
    get backupVnicId(): string;
    private _cloudVmClusterId?;
    get cloudVmClusterId(): string;
    set cloudVmClusterId(value: string);
    get cloudVmClusterIdInput(): string | undefined;
    get cpuCoreCount(): number;
    get createdAt(): string;
    get dbServerId(): string;
    get dbStorageSizeInGbs(): number;
    get dbSystemId(): string;
    get faultDomain(): string;
    get floatingIpAddress(): string;
    get hostIpId(): string;
    get hostname(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    get maintenanceType(): string;
    get memorySizeInGbs(): number;
    get ociResourceAnchorName(): string;
    get ocid(): string;
    get privateIpAddress(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get softwareStorageSizeInGbs(): number;
    get status(): string;
    get statusReason(): string;
    get timeMaintenanceWindowEnd(): string;
    get timeMaintenanceWindowStart(): string;
    get totalCpuCoreCount(): number;
    get vnic2Id(): string;
    get vnicId(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
