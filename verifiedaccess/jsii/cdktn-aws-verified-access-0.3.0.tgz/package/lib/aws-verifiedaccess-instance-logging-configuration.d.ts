import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsInstanceLoggingConfigurationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedaccess_instance_logging_configuration#id AwsInstanceLoggingConfiguration#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedaccess_instance_logging_configuration#region AwsInstanceLoggingConfiguration#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedaccess_instance_logging_configuration#verifiedaccess_instance_id AwsInstanceLoggingConfiguration#verifiedaccess_instance_id}
    */
    readonly verifiedaccessInstanceId: string;
    /**
    * access_logs block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedaccess_instance_logging_configuration#access_logs AwsInstanceLoggingConfiguration#access_logs}
    */
    readonly accessLogs: AwsInstanceLoggingConfiguration.AccessLogsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedaccess_instance_logging_configuration aws_verifiedaccess_instance_logging_configuration}
*/
export declare class AwsInstanceLoggingConfiguration extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_verifiedaccess_instance_logging_configuration";
    /**
    * Generates CDKTN code for importing a AwsInstanceLoggingConfiguration resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsInstanceLoggingConfiguration to import
    * @param importFromId The id of the existing AwsInstanceLoggingConfiguration that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedaccess_instance_logging_configuration#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsInstanceLoggingConfiguration to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedaccess_instance_logging_configuration aws_verifiedaccess_instance_logging_configuration} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsInstanceLoggingConfigurationConfig
    */
    constructor(scope: Construct, id: string, config: AwsInstanceLoggingConfigurationConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _verifiedaccessInstanceId?;
    get verifiedaccessInstanceId(): string;
    set verifiedaccessInstanceId(value: string);
    get verifiedaccessInstanceIdInput(): string | undefined;
    private _accessLogs;
    get accessLogs(): AwsInstanceLoggingConfiguration.AccessLogsPropertyOutputReference;
    putAccessLogs(value: AwsInstanceLoggingConfiguration.AccessLogsProperty): void;
    get accessLogsInput(): AwsInstanceLoggingConfiguration.AccessLogsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsInstanceLoggingConfigurationCloudwatchLogsPropertyToTerraform(struct?: AwsInstanceLoggingConfiguration.CloudwatchLogsPropertyOutputReference | AwsInstanceLoggingConfiguration.CloudwatchLogsProperty): any;
export declare function awsInstanceLoggingConfigurationCloudwatchLogsPropertyToHclTerraform(struct?: AwsInstanceLoggingConfiguration.CloudwatchLogsPropertyOutputReference | AwsInstanceLoggingConfiguration.CloudwatchLogsProperty): any;
export declare function awsInstanceLoggingConfigurationKinesisDataFirehosePropertyToTerraform(struct?: AwsInstanceLoggingConfiguration.KinesisDataFirehosePropertyOutputReference | AwsInstanceLoggingConfiguration.KinesisDataFirehoseProperty): any;
export declare function awsInstanceLoggingConfigurationKinesisDataFirehosePropertyToHclTerraform(struct?: AwsInstanceLoggingConfiguration.KinesisDataFirehosePropertyOutputReference | AwsInstanceLoggingConfiguration.KinesisDataFirehoseProperty): any;
export declare function awsInstanceLoggingConfigurationS3PropertyToTerraform(struct?: AwsInstanceLoggingConfiguration.S3PropertyOutputReference | AwsInstanceLoggingConfiguration.S3Property): any;
export declare function awsInstanceLoggingConfigurationS3PropertyToHclTerraform(struct?: AwsInstanceLoggingConfiguration.S3PropertyOutputReference | AwsInstanceLoggingConfiguration.S3Property): any;
export declare function awsInstanceLoggingConfigurationAccessLogsPropertyToTerraform(struct?: AwsInstanceLoggingConfiguration.AccessLogsPropertyOutputReference | AwsInstanceLoggingConfiguration.AccessLogsProperty): any;
export declare function awsInstanceLoggingConfigurationAccessLogsPropertyToHclTerraform(struct?: AwsInstanceLoggingConfiguration.AccessLogsPropertyOutputReference | AwsInstanceLoggingConfiguration.AccessLogsProperty): any;
export declare namespace AwsInstanceLoggingConfiguration {
    interface CloudwatchLogsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedaccess_instance_logging_configuration#enabled AwsInstanceLoggingConfiguration#enabled}
        */
        readonly enabled: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedaccess_instance_logging_configuration#log_group AwsInstanceLoggingConfiguration#log_group}
        */
        readonly logGroup?: string;
    }
    class CloudwatchLogsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CloudwatchLogsProperty | undefined;
        set internalValue(value: CloudwatchLogsProperty | undefined);
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
        private _logGroup?;
        get logGroup(): string;
        set logGroup(value: string);
        resetLogGroup(): void;
        get logGroupInput(): string | undefined;
    }
    interface KinesisDataFirehoseProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedaccess_instance_logging_configuration#delivery_stream AwsInstanceLoggingConfiguration#delivery_stream}
        */
        readonly deliveryStream?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedaccess_instance_logging_configuration#enabled AwsInstanceLoggingConfiguration#enabled}
        */
        readonly enabled: boolean | cdktn.IResolvable;
    }
    class KinesisDataFirehosePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): KinesisDataFirehoseProperty | undefined;
        set internalValue(value: KinesisDataFirehoseProperty | undefined);
        private _deliveryStream?;
        get deliveryStream(): string;
        set deliveryStream(value: string);
        resetDeliveryStream(): void;
        get deliveryStreamInput(): string | undefined;
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface S3Property {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedaccess_instance_logging_configuration#bucket_name AwsInstanceLoggingConfiguration#bucket_name}
        */
        readonly bucketName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedaccess_instance_logging_configuration#bucket_owner AwsInstanceLoggingConfiguration#bucket_owner}
        */
        readonly bucketOwner?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedaccess_instance_logging_configuration#enabled AwsInstanceLoggingConfiguration#enabled}
        */
        readonly enabled: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedaccess_instance_logging_configuration#prefix AwsInstanceLoggingConfiguration#prefix}
        */
        readonly prefix?: string;
    }
    class S3PropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): S3Property | undefined;
        set internalValue(value: S3Property | undefined);
        private _bucketName?;
        get bucketName(): string;
        set bucketName(value: string);
        resetBucketName(): void;
        get bucketNameInput(): string | undefined;
        private _bucketOwner?;
        get bucketOwner(): string;
        set bucketOwner(value: string);
        resetBucketOwner(): void;
        get bucketOwnerInput(): string | undefined;
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
        private _prefix?;
        get prefix(): string;
        set prefix(value: string);
        resetPrefix(): void;
        get prefixInput(): string | undefined;
    }
    interface AccessLogsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedaccess_instance_logging_configuration#include_trust_context AwsInstanceLoggingConfiguration#include_trust_context}
        */
        readonly includeTrustContext?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedaccess_instance_logging_configuration#log_version AwsInstanceLoggingConfiguration#log_version}
        */
        readonly logVersion?: string;
        /**
        * cloudwatch_logs block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedaccess_instance_logging_configuration#cloudwatch_logs AwsInstanceLoggingConfiguration#cloudwatch_logs}
        */
        readonly cloudwatchLogs?: CloudwatchLogsProperty;
        /**
        * kinesis_data_firehose block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedaccess_instance_logging_configuration#kinesis_data_firehose AwsInstanceLoggingConfiguration#kinesis_data_firehose}
        */
        readonly kinesisDataFirehose?: KinesisDataFirehoseProperty;
        /**
        * s3 block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedaccess_instance_logging_configuration#s3 AwsInstanceLoggingConfiguration#s3}
        */
        readonly s3?: S3Property;
    }
    class AccessLogsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AccessLogsProperty | undefined;
        set internalValue(value: AccessLogsProperty | undefined);
        private _includeTrustContext?;
        get includeTrustContext(): boolean | cdktn.IResolvable;
        set includeTrustContext(value: boolean | cdktn.IResolvable);
        resetIncludeTrustContext(): void;
        get includeTrustContextInput(): boolean | cdktn.IResolvable | undefined;
        private _logVersion?;
        get logVersion(): string;
        set logVersion(value: string);
        resetLogVersion(): void;
        get logVersionInput(): string | undefined;
        private _cloudwatchLogs;
        get cloudwatchLogs(): CloudwatchLogsPropertyOutputReference;
        putCloudwatchLogs(value: CloudwatchLogsProperty): void;
        resetCloudwatchLogs(): void;
        get cloudwatchLogsInput(): CloudwatchLogsProperty | undefined;
        private _kinesisDataFirehose;
        get kinesisDataFirehose(): KinesisDataFirehosePropertyOutputReference;
        putKinesisDataFirehose(value: KinesisDataFirehoseProperty): void;
        resetKinesisDataFirehose(): void;
        get kinesisDataFirehoseInput(): KinesisDataFirehoseProperty | undefined;
        private _s3;
        get s3(): S3PropertyOutputReference;
        putS3(value: S3Property): void;
        resetS3(): void;
        get s3Input(): S3Property | undefined;
    }
}
