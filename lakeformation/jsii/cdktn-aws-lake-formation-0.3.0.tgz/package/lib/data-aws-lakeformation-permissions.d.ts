import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsPermissionsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lakeformation_permissions#catalog_id DataAwsPermissions#catalog_id}
    */
    readonly catalogId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lakeformation_permissions#catalog_resource DataAwsPermissions#catalog_resource}
    */
    readonly catalogResource?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lakeformation_permissions#id DataAwsPermissions#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lakeformation_permissions#principal DataAwsPermissions#principal}
    */
    readonly principal: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lakeformation_permissions#region DataAwsPermissions#region}
    */
    readonly region?: string;
    /**
    * data_cells_filter block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lakeformation_permissions#data_cells_filter DataAwsPermissions#data_cells_filter}
    */
    readonly dataCellsFilter?: DataAwsPermissions.DataCellsFilterProperty;
    /**
    * data_location block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lakeformation_permissions#data_location DataAwsPermissions#data_location}
    */
    readonly dataLocation?: DataAwsPermissions.DataLocationProperty;
    /**
    * database block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lakeformation_permissions#database DataAwsPermissions#database}
    */
    readonly database?: DataAwsPermissions.DatabaseProperty;
    /**
    * lf_tag block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lakeformation_permissions#lf_tag DataAwsPermissions#lf_tag}
    */
    readonly lfTag?: DataAwsPermissions.LfTagProperty;
    /**
    * lf_tag_policy block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lakeformation_permissions#lf_tag_policy DataAwsPermissions#lf_tag_policy}
    */
    readonly lfTagPolicy?: DataAwsPermissions.LfTagPolicyProperty;
    /**
    * table block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lakeformation_permissions#table DataAwsPermissions#table}
    */
    readonly table?: DataAwsPermissions.TableProperty;
    /**
    * table_with_columns block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lakeformation_permissions#table_with_columns DataAwsPermissions#table_with_columns}
    */
    readonly tableWithColumns?: DataAwsPermissions.TableWithColumnsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lakeformation_permissions aws_lakeformation_permissions}
*/
export declare class DataAwsPermissions extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_lakeformation_permissions";
    /**
    * Generates CDKTN code for importing a DataAwsPermissions resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsPermissions to import
    * @param importFromId The id of the existing DataAwsPermissions that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lakeformation_permissions#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsPermissions to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lakeformation_permissions aws_lakeformation_permissions} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsPermissionsConfig
    */
    constructor(scope: Construct, id: string, config: DataAwsPermissionsConfig);
    private _catalogId?;
    get catalogId(): string;
    set catalogId(value: string);
    resetCatalogId(): void;
    get catalogIdInput(): string | undefined;
    private _catalogResource?;
    get catalogResource(): boolean | cdktn.IResolvable;
    set catalogResource(value: boolean | cdktn.IResolvable);
    resetCatalogResource(): void;
    get catalogResourceInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get permissions(): string[];
    get permissionsWithGrantOption(): string[];
    private _principal?;
    get principal(): string;
    set principal(value: string);
    get principalInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _dataCellsFilter;
    get dataCellsFilter(): DataAwsPermissions.DataCellsFilterPropertyOutputReference;
    putDataCellsFilter(value: DataAwsPermissions.DataCellsFilterProperty): void;
    resetDataCellsFilter(): void;
    get dataCellsFilterInput(): DataAwsPermissions.DataCellsFilterProperty | undefined;
    private _dataLocation;
    get dataLocation(): DataAwsPermissions.DataLocationPropertyOutputReference;
    putDataLocation(value: DataAwsPermissions.DataLocationProperty): void;
    resetDataLocation(): void;
    get dataLocationInput(): DataAwsPermissions.DataLocationProperty | undefined;
    private _database;
    get database(): DataAwsPermissions.DatabasePropertyOutputReference;
    putDatabase(value: DataAwsPermissions.DatabaseProperty): void;
    resetDatabase(): void;
    get databaseInput(): DataAwsPermissions.DatabaseProperty | undefined;
    private _lfTag;
    get lfTag(): DataAwsPermissions.LfTagPropertyOutputReference;
    putLfTag(value: DataAwsPermissions.LfTagProperty): void;
    resetLfTag(): void;
    get lfTagInput(): DataAwsPermissions.LfTagProperty | undefined;
    private _lfTagPolicy;
    get lfTagPolicy(): DataAwsPermissions.LfTagPolicyPropertyOutputReference;
    putLfTagPolicy(value: DataAwsPermissions.LfTagPolicyProperty): void;
    resetLfTagPolicy(): void;
    get lfTagPolicyInput(): DataAwsPermissions.LfTagPolicyProperty | undefined;
    private _table;
    get table(): DataAwsPermissions.TablePropertyOutputReference;
    putTable(value: DataAwsPermissions.TableProperty): void;
    resetTable(): void;
    get tableInput(): DataAwsPermissions.TableProperty | undefined;
    private _tableWithColumns;
    get tableWithColumns(): DataAwsPermissions.TableWithColumnsPropertyOutputReference;
    putTableWithColumns(value: DataAwsPermissions.TableWithColumnsProperty): void;
    resetTableWithColumns(): void;
    get tableWithColumnsInput(): DataAwsPermissions.TableWithColumnsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataAwsPermissionsDataCellsFilterPropertyToTerraform(struct?: DataAwsPermissions.DataCellsFilterPropertyOutputReference | DataAwsPermissions.DataCellsFilterProperty): any;
export declare function dataAwsPermissionsDataCellsFilterPropertyToHclTerraform(struct?: DataAwsPermissions.DataCellsFilterPropertyOutputReference | DataAwsPermissions.DataCellsFilterProperty): any;
export declare function dataAwsPermissionsDataLocationPropertyToTerraform(struct?: DataAwsPermissions.DataLocationPropertyOutputReference | DataAwsPermissions.DataLocationProperty): any;
export declare function dataAwsPermissionsDataLocationPropertyToHclTerraform(struct?: DataAwsPermissions.DataLocationPropertyOutputReference | DataAwsPermissions.DataLocationProperty): any;
export declare function dataAwsPermissionsDatabasePropertyToTerraform(struct?: DataAwsPermissions.DatabasePropertyOutputReference | DataAwsPermissions.DatabaseProperty): any;
export declare function dataAwsPermissionsDatabasePropertyToHclTerraform(struct?: DataAwsPermissions.DatabasePropertyOutputReference | DataAwsPermissions.DatabaseProperty): any;
export declare function dataAwsPermissionsLfTagPropertyToTerraform(struct?: DataAwsPermissions.LfTagPropertyOutputReference | DataAwsPermissions.LfTagProperty): any;
export declare function dataAwsPermissionsLfTagPropertyToHclTerraform(struct?: DataAwsPermissions.LfTagPropertyOutputReference | DataAwsPermissions.LfTagProperty): any;
export declare function dataAwsPermissionsExpressionPropertyToTerraform(struct?: DataAwsPermissions.ExpressionProperty | cdktn.IResolvable): any;
export declare function dataAwsPermissionsExpressionPropertyToHclTerraform(struct?: DataAwsPermissions.ExpressionProperty | cdktn.IResolvable): any;
export declare function dataAwsPermissionsLfTagPolicyPropertyToTerraform(struct?: DataAwsPermissions.LfTagPolicyPropertyOutputReference | DataAwsPermissions.LfTagPolicyProperty): any;
export declare function dataAwsPermissionsLfTagPolicyPropertyToHclTerraform(struct?: DataAwsPermissions.LfTagPolicyPropertyOutputReference | DataAwsPermissions.LfTagPolicyProperty): any;
export declare function dataAwsPermissionsTablePropertyToTerraform(struct?: DataAwsPermissions.TablePropertyOutputReference | DataAwsPermissions.TableProperty): any;
export declare function dataAwsPermissionsTablePropertyToHclTerraform(struct?: DataAwsPermissions.TablePropertyOutputReference | DataAwsPermissions.TableProperty): any;
export declare function dataAwsPermissionsTableWithColumnsPropertyToTerraform(struct?: DataAwsPermissions.TableWithColumnsPropertyOutputReference | DataAwsPermissions.TableWithColumnsProperty): any;
export declare function dataAwsPermissionsTableWithColumnsPropertyToHclTerraform(struct?: DataAwsPermissions.TableWithColumnsPropertyOutputReference | DataAwsPermissions.TableWithColumnsProperty): any;
export declare namespace DataAwsPermissions {
    interface DataCellsFilterProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lakeformation_permissions#database_name DataAwsPermissions#database_name}
        */
        readonly databaseName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lakeformation_permissions#name DataAwsPermissions#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lakeformation_permissions#table_catalog_id DataAwsPermissions#table_catalog_id}
        */
        readonly tableCatalogId: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lakeformation_permissions#table_name DataAwsPermissions#table_name}
        */
        readonly tableName: string;
    }
    class DataCellsFilterPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DataCellsFilterProperty | undefined;
        set internalValue(value: DataCellsFilterProperty | undefined);
        private _databaseName?;
        get databaseName(): string;
        set databaseName(value: string);
        get databaseNameInput(): string | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _tableCatalogId?;
        get tableCatalogId(): string;
        set tableCatalogId(value: string);
        get tableCatalogIdInput(): string | undefined;
        private _tableName?;
        get tableName(): string;
        set tableName(value: string);
        get tableNameInput(): string | undefined;
    }
    interface DataLocationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lakeformation_permissions#arn DataAwsPermissions#arn}
        */
        readonly arn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lakeformation_permissions#catalog_id DataAwsPermissions#catalog_id}
        */
        readonly catalogId?: string;
    }
    class DataLocationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DataLocationProperty | undefined;
        set internalValue(value: DataLocationProperty | undefined);
        private _arn?;
        get arn(): string;
        set arn(value: string);
        get arnInput(): string | undefined;
        private _catalogId?;
        get catalogId(): string;
        set catalogId(value: string);
        resetCatalogId(): void;
        get catalogIdInput(): string | undefined;
    }
    interface DatabaseProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lakeformation_permissions#catalog_id DataAwsPermissions#catalog_id}
        */
        readonly catalogId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lakeformation_permissions#name DataAwsPermissions#name}
        */
        readonly name: string;
    }
    class DatabasePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DatabaseProperty | undefined;
        set internalValue(value: DatabaseProperty | undefined);
        private _catalogId?;
        get catalogId(): string;
        set catalogId(value: string);
        resetCatalogId(): void;
        get catalogIdInput(): string | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
    }
    interface LfTagProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lakeformation_permissions#catalog_id DataAwsPermissions#catalog_id}
        */
        readonly catalogId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lakeformation_permissions#key DataAwsPermissions#key}
        */
        readonly key: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lakeformation_permissions#values DataAwsPermissions#values}
        */
        readonly values: string[];
    }
    class LfTagPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): LfTagProperty | undefined;
        set internalValue(value: LfTagProperty | undefined);
        private _catalogId?;
        get catalogId(): string;
        set catalogId(value: string);
        resetCatalogId(): void;
        get catalogIdInput(): string | undefined;
        private _key?;
        get key(): string;
        set key(value: string);
        get keyInput(): string | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        get valuesInput(): string[] | undefined;
    }
    interface ExpressionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lakeformation_permissions#key DataAwsPermissions#key}
        */
        readonly key: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lakeformation_permissions#values DataAwsPermissions#values}
        */
        readonly values: string[];
    }
    class ExpressionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ExpressionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ExpressionProperty | cdktn.IResolvable | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        get keyInput(): string | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        get valuesInput(): string[] | undefined;
    }
    class ExpressionPropertyList extends cdktn.ComplexList {
        internalValue?: ExpressionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ExpressionPropertyOutputReference;
    }
    interface LfTagPolicyProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lakeformation_permissions#catalog_id DataAwsPermissions#catalog_id}
        */
        readonly catalogId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lakeformation_permissions#resource_type DataAwsPermissions#resource_type}
        */
        readonly resourceType: string;
        /**
        * expression block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lakeformation_permissions#expression DataAwsPermissions#expression}
        */
        readonly expression: ExpressionProperty[] | cdktn.IResolvable;
    }
    class LfTagPolicyPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): LfTagPolicyProperty | undefined;
        set internalValue(value: LfTagPolicyProperty | undefined);
        private _catalogId?;
        get catalogId(): string;
        set catalogId(value: string);
        resetCatalogId(): void;
        get catalogIdInput(): string | undefined;
        private _resourceType?;
        get resourceType(): string;
        set resourceType(value: string);
        get resourceTypeInput(): string | undefined;
        private _expression;
        get expression(): ExpressionPropertyList;
        putExpression(value: ExpressionProperty[] | cdktn.IResolvable): void;
        get expressionInput(): cdktn.IResolvable | ExpressionProperty[] | undefined;
    }
    interface TableProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lakeformation_permissions#catalog_id DataAwsPermissions#catalog_id}
        */
        readonly catalogId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lakeformation_permissions#database_name DataAwsPermissions#database_name}
        */
        readonly databaseName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lakeformation_permissions#name DataAwsPermissions#name}
        */
        readonly name?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lakeformation_permissions#wildcard DataAwsPermissions#wildcard}
        */
        readonly wildcard?: boolean | cdktn.IResolvable;
    }
    class TablePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TableProperty | undefined;
        set internalValue(value: TableProperty | undefined);
        private _catalogId?;
        get catalogId(): string;
        set catalogId(value: string);
        resetCatalogId(): void;
        get catalogIdInput(): string | undefined;
        private _databaseName?;
        get databaseName(): string;
        set databaseName(value: string);
        get databaseNameInput(): string | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        resetName(): void;
        get nameInput(): string | undefined;
        private _wildcard?;
        get wildcard(): boolean | cdktn.IResolvable;
        set wildcard(value: boolean | cdktn.IResolvable);
        resetWildcard(): void;
        get wildcardInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface TableWithColumnsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lakeformation_permissions#catalog_id DataAwsPermissions#catalog_id}
        */
        readonly catalogId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lakeformation_permissions#column_names DataAwsPermissions#column_names}
        */
        readonly columnNames?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lakeformation_permissions#database_name DataAwsPermissions#database_name}
        */
        readonly databaseName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lakeformation_permissions#excluded_column_names DataAwsPermissions#excluded_column_names}
        */
        readonly excludedColumnNames?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lakeformation_permissions#name DataAwsPermissions#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lakeformation_permissions#wildcard DataAwsPermissions#wildcard}
        */
        readonly wildcard?: boolean | cdktn.IResolvable;
    }
    class TableWithColumnsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TableWithColumnsProperty | undefined;
        set internalValue(value: TableWithColumnsProperty | undefined);
        private _catalogId?;
        get catalogId(): string;
        set catalogId(value: string);
        resetCatalogId(): void;
        get catalogIdInput(): string | undefined;
        private _columnNames?;
        get columnNames(): string[];
        set columnNames(value: string[]);
        resetColumnNames(): void;
        get columnNamesInput(): string[] | undefined;
        private _databaseName?;
        get databaseName(): string;
        set databaseName(value: string);
        get databaseNameInput(): string | undefined;
        private _excludedColumnNames?;
        get excludedColumnNames(): string[];
        set excludedColumnNames(value: string[]);
        resetExcludedColumnNames(): void;
        get excludedColumnNamesInput(): string[] | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _wildcard?;
        get wildcard(): boolean | cdktn.IResolvable;
        set wildcard(value: boolean | cdktn.IResolvable);
        resetWildcard(): void;
        get wildcardInput(): boolean | cdktn.IResolvable | undefined;
    }
}
