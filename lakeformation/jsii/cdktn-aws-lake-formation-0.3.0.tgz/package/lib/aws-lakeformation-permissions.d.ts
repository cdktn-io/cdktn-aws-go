import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsPermissionsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_permissions#catalog_id AwsPermissions#catalog_id}
    */
    readonly catalogId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_permissions#catalog_resource AwsPermissions#catalog_resource}
    */
    readonly catalogResource?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_permissions#id AwsPermissions#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_permissions#permissions AwsPermissions#permissions}
    */
    readonly permissions: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_permissions#permissions_with_grant_option AwsPermissions#permissions_with_grant_option}
    */
    readonly permissionsWithGrantOption?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_permissions#principal AwsPermissions#principal}
    */
    readonly principal: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_permissions#region AwsPermissions#region}
    */
    readonly region?: string;
    /**
    * data_cells_filter block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_permissions#data_cells_filter AwsPermissions#data_cells_filter}
    */
    readonly dataCellsFilter?: AwsPermissions.DataCellsFilterProperty;
    /**
    * data_location block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_permissions#data_location AwsPermissions#data_location}
    */
    readonly dataLocation?: AwsPermissions.DataLocationProperty;
    /**
    * database block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_permissions#database AwsPermissions#database}
    */
    readonly database?: AwsPermissions.DatabaseProperty;
    /**
    * lf_tag block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_permissions#lf_tag AwsPermissions#lf_tag}
    */
    readonly lfTag?: AwsPermissions.LfTagProperty;
    /**
    * lf_tag_policy block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_permissions#lf_tag_policy AwsPermissions#lf_tag_policy}
    */
    readonly lfTagPolicy?: AwsPermissions.LfTagPolicyProperty;
    /**
    * table block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_permissions#table AwsPermissions#table}
    */
    readonly table?: AwsPermissions.TableProperty;
    /**
    * table_with_columns block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_permissions#table_with_columns AwsPermissions#table_with_columns}
    */
    readonly tableWithColumns?: AwsPermissions.TableWithColumnsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_permissions aws_lakeformation_permissions}
*/
export declare class AwsPermissions extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_lakeformation_permissions";
    /**
    * Generates CDKTN code for importing a AwsPermissions resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsPermissions to import
    * @param importFromId The id of the existing AwsPermissions that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_permissions#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsPermissions to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_permissions aws_lakeformation_permissions} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsPermissionsConfig
    */
    constructor(scope: Construct, id: string, config: AwsPermissionsConfig);
    private _catalogId?;
    get catalogId(): string;
    set catalogId(value: string);
    resetCatalogId(): void;
    get catalogIdInput(): string | undefined;
    private _catalogResource?;
    get catalogResource(): boolean | cdktn.IResolvable;
    set catalogResource(value: boolean | cdktn.IResolvable);
    resetCatalogResource(): void;
    get catalogResourceInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _permissions?;
    get permissions(): string[];
    set permissions(value: string[]);
    get permissionsInput(): string[] | undefined;
    private _permissionsWithGrantOption?;
    get permissionsWithGrantOption(): string[];
    set permissionsWithGrantOption(value: string[]);
    resetPermissionsWithGrantOption(): void;
    get permissionsWithGrantOptionInput(): string[] | undefined;
    private _principal?;
    get principal(): string;
    set principal(value: string);
    get principalInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _dataCellsFilter;
    get dataCellsFilter(): AwsPermissions.DataCellsFilterPropertyOutputReference;
    putDataCellsFilter(value: AwsPermissions.DataCellsFilterProperty): void;
    resetDataCellsFilter(): void;
    get dataCellsFilterInput(): AwsPermissions.DataCellsFilterProperty | undefined;
    private _dataLocation;
    get dataLocation(): AwsPermissions.DataLocationPropertyOutputReference;
    putDataLocation(value: AwsPermissions.DataLocationProperty): void;
    resetDataLocation(): void;
    get dataLocationInput(): AwsPermissions.DataLocationProperty | undefined;
    private _database;
    get database(): AwsPermissions.DatabasePropertyOutputReference;
    putDatabase(value: AwsPermissions.DatabaseProperty): void;
    resetDatabase(): void;
    get databaseInput(): AwsPermissions.DatabaseProperty | undefined;
    private _lfTag;
    get lfTag(): AwsPermissions.LfTagPropertyOutputReference;
    putLfTag(value: AwsPermissions.LfTagProperty): void;
    resetLfTag(): void;
    get lfTagInput(): AwsPermissions.LfTagProperty | undefined;
    private _lfTagPolicy;
    get lfTagPolicy(): AwsPermissions.LfTagPolicyPropertyOutputReference;
    putLfTagPolicy(value: AwsPermissions.LfTagPolicyProperty): void;
    resetLfTagPolicy(): void;
    get lfTagPolicyInput(): AwsPermissions.LfTagPolicyProperty | undefined;
    private _table;
    get table(): AwsPermissions.TablePropertyOutputReference;
    putTable(value: AwsPermissions.TableProperty): void;
    resetTable(): void;
    get tableInput(): AwsPermissions.TableProperty | undefined;
    private _tableWithColumns;
    get tableWithColumns(): AwsPermissions.TableWithColumnsPropertyOutputReference;
    putTableWithColumns(value: AwsPermissions.TableWithColumnsProperty): void;
    resetTableWithColumns(): void;
    get tableWithColumnsInput(): AwsPermissions.TableWithColumnsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsPermissionsDataCellsFilterPropertyToTerraform(struct?: AwsPermissions.DataCellsFilterPropertyOutputReference | AwsPermissions.DataCellsFilterProperty): any;
export declare function awsPermissionsDataCellsFilterPropertyToHclTerraform(struct?: AwsPermissions.DataCellsFilterPropertyOutputReference | AwsPermissions.DataCellsFilterProperty): any;
export declare function awsPermissionsDataLocationPropertyToTerraform(struct?: AwsPermissions.DataLocationPropertyOutputReference | AwsPermissions.DataLocationProperty): any;
export declare function awsPermissionsDataLocationPropertyToHclTerraform(struct?: AwsPermissions.DataLocationPropertyOutputReference | AwsPermissions.DataLocationProperty): any;
export declare function awsPermissionsDatabasePropertyToTerraform(struct?: AwsPermissions.DatabasePropertyOutputReference | AwsPermissions.DatabaseProperty): any;
export declare function awsPermissionsDatabasePropertyToHclTerraform(struct?: AwsPermissions.DatabasePropertyOutputReference | AwsPermissions.DatabaseProperty): any;
export declare function awsPermissionsLfTagPropertyToTerraform(struct?: AwsPermissions.LfTagPropertyOutputReference | AwsPermissions.LfTagProperty): any;
export declare function awsPermissionsLfTagPropertyToHclTerraform(struct?: AwsPermissions.LfTagPropertyOutputReference | AwsPermissions.LfTagProperty): any;
export declare function awsPermissionsExpressionPropertyToTerraform(struct?: AwsPermissions.ExpressionProperty | cdktn.IResolvable): any;
export declare function awsPermissionsExpressionPropertyToHclTerraform(struct?: AwsPermissions.ExpressionProperty | cdktn.IResolvable): any;
export declare function awsPermissionsLfTagPolicyPropertyToTerraform(struct?: AwsPermissions.LfTagPolicyPropertyOutputReference | AwsPermissions.LfTagPolicyProperty): any;
export declare function awsPermissionsLfTagPolicyPropertyToHclTerraform(struct?: AwsPermissions.LfTagPolicyPropertyOutputReference | AwsPermissions.LfTagPolicyProperty): any;
export declare function awsPermissionsTablePropertyToTerraform(struct?: AwsPermissions.TablePropertyOutputReference | AwsPermissions.TableProperty): any;
export declare function awsPermissionsTablePropertyToHclTerraform(struct?: AwsPermissions.TablePropertyOutputReference | AwsPermissions.TableProperty): any;
export declare function awsPermissionsTableWithColumnsPropertyToTerraform(struct?: AwsPermissions.TableWithColumnsPropertyOutputReference | AwsPermissions.TableWithColumnsProperty): any;
export declare function awsPermissionsTableWithColumnsPropertyToHclTerraform(struct?: AwsPermissions.TableWithColumnsPropertyOutputReference | AwsPermissions.TableWithColumnsProperty): any;
export declare namespace AwsPermissions {
    interface DataCellsFilterProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_permissions#database_name AwsPermissions#database_name}
        */
        readonly databaseName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_permissions#name AwsPermissions#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_permissions#table_catalog_id AwsPermissions#table_catalog_id}
        */
        readonly tableCatalogId: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_permissions#table_name AwsPermissions#table_name}
        */
        readonly tableName: string;
    }
    class DataCellsFilterPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DataCellsFilterProperty | undefined;
        set internalValue(value: DataCellsFilterProperty | undefined);
        private _databaseName?;
        get databaseName(): string;
        set databaseName(value: string);
        get databaseNameInput(): string | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _tableCatalogId?;
        get tableCatalogId(): string;
        set tableCatalogId(value: string);
        get tableCatalogIdInput(): string | undefined;
        private _tableName?;
        get tableName(): string;
        set tableName(value: string);
        get tableNameInput(): string | undefined;
    }
    interface DataLocationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_permissions#arn AwsPermissions#arn}
        */
        readonly arn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_permissions#catalog_id AwsPermissions#catalog_id}
        */
        readonly catalogId?: string;
    }
    class DataLocationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DataLocationProperty | undefined;
        set internalValue(value: DataLocationProperty | undefined);
        private _arn?;
        get arn(): string;
        set arn(value: string);
        get arnInput(): string | undefined;
        private _catalogId?;
        get catalogId(): string;
        set catalogId(value: string);
        resetCatalogId(): void;
        get catalogIdInput(): string | undefined;
    }
    interface DatabaseProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_permissions#catalog_id AwsPermissions#catalog_id}
        */
        readonly catalogId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_permissions#name AwsPermissions#name}
        */
        readonly name: string;
    }
    class DatabasePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DatabaseProperty | undefined;
        set internalValue(value: DatabaseProperty | undefined);
        private _catalogId?;
        get catalogId(): string;
        set catalogId(value: string);
        resetCatalogId(): void;
        get catalogIdInput(): string | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
    }
    interface LfTagProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_permissions#catalog_id AwsPermissions#catalog_id}
        */
        readonly catalogId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_permissions#key AwsPermissions#key}
        */
        readonly key: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_permissions#values AwsPermissions#values}
        */
        readonly values: string[];
    }
    class LfTagPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): LfTagProperty | undefined;
        set internalValue(value: LfTagProperty | undefined);
        private _catalogId?;
        get catalogId(): string;
        set catalogId(value: string);
        resetCatalogId(): void;
        get catalogIdInput(): string | undefined;
        private _key?;
        get key(): string;
        set key(value: string);
        get keyInput(): string | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        get valuesInput(): string[] | undefined;
    }
    interface ExpressionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_permissions#key AwsPermissions#key}
        */
        readonly key: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_permissions#values AwsPermissions#values}
        */
        readonly values: string[];
    }
    class ExpressionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ExpressionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ExpressionProperty | cdktn.IResolvable | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        get keyInput(): string | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        get valuesInput(): string[] | undefined;
    }
    class ExpressionPropertyList extends cdktn.ComplexList {
        internalValue?: ExpressionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ExpressionPropertyOutputReference;
    }
    interface LfTagPolicyProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_permissions#catalog_id AwsPermissions#catalog_id}
        */
        readonly catalogId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_permissions#resource_type AwsPermissions#resource_type}
        */
        readonly resourceType: string;
        /**
        * expression block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_permissions#expression AwsPermissions#expression}
        */
        readonly expression: ExpressionProperty[] | cdktn.IResolvable;
    }
    class LfTagPolicyPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): LfTagPolicyProperty | undefined;
        set internalValue(value: LfTagPolicyProperty | undefined);
        private _catalogId?;
        get catalogId(): string;
        set catalogId(value: string);
        resetCatalogId(): void;
        get catalogIdInput(): string | undefined;
        private _resourceType?;
        get resourceType(): string;
        set resourceType(value: string);
        get resourceTypeInput(): string | undefined;
        private _expression;
        get expression(): ExpressionPropertyList;
        putExpression(value: ExpressionProperty[] | cdktn.IResolvable): void;
        get expressionInput(): cdktn.IResolvable | ExpressionProperty[] | undefined;
    }
    interface TableProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_permissions#catalog_id AwsPermissions#catalog_id}
        */
        readonly catalogId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_permissions#database_name AwsPermissions#database_name}
        */
        readonly databaseName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_permissions#name AwsPermissions#name}
        */
        readonly name?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_permissions#wildcard AwsPermissions#wildcard}
        */
        readonly wildcard?: boolean | cdktn.IResolvable;
    }
    class TablePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TableProperty | undefined;
        set internalValue(value: TableProperty | undefined);
        private _catalogId?;
        get catalogId(): string;
        set catalogId(value: string);
        resetCatalogId(): void;
        get catalogIdInput(): string | undefined;
        private _databaseName?;
        get databaseName(): string;
        set databaseName(value: string);
        get databaseNameInput(): string | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        resetName(): void;
        get nameInput(): string | undefined;
        private _wildcard?;
        get wildcard(): boolean | cdktn.IResolvable;
        set wildcard(value: boolean | cdktn.IResolvable);
        resetWildcard(): void;
        get wildcardInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface TableWithColumnsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_permissions#catalog_id AwsPermissions#catalog_id}
        */
        readonly catalogId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_permissions#column_names AwsPermissions#column_names}
        */
        readonly columnNames?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_permissions#database_name AwsPermissions#database_name}
        */
        readonly databaseName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_permissions#excluded_column_names AwsPermissions#excluded_column_names}
        */
        readonly excludedColumnNames?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_permissions#name AwsPermissions#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_permissions#wildcard AwsPermissions#wildcard}
        */
        readonly wildcard?: boolean | cdktn.IResolvable;
    }
    class TableWithColumnsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TableWithColumnsProperty | undefined;
        set internalValue(value: TableWithColumnsProperty | undefined);
        private _catalogId?;
        get catalogId(): string;
        set catalogId(value: string);
        resetCatalogId(): void;
        get catalogIdInput(): string | undefined;
        private _columnNames?;
        get columnNames(): string[];
        set columnNames(value: string[]);
        resetColumnNames(): void;
        get columnNamesInput(): string[] | undefined;
        private _databaseName?;
        get databaseName(): string;
        set databaseName(value: string);
        get databaseNameInput(): string | undefined;
        private _excludedColumnNames?;
        get excludedColumnNames(): string[];
        set excludedColumnNames(value: string[]);
        resetExcludedColumnNames(): void;
        get excludedColumnNamesInput(): string[] | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _wildcard?;
        get wildcard(): boolean | cdktn.IResolvable;
        set wildcard(value: boolean | cdktn.IResolvable);
        resetWildcard(): void;
        get wildcardInput(): boolean | cdktn.IResolvable | undefined;
    }
}
