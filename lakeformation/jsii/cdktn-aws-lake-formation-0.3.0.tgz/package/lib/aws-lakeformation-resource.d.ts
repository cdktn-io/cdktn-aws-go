import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsResourceConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_resource#arn AwsResource#arn}
    */
    readonly arn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_resource#hybrid_access_enabled AwsResource#hybrid_access_enabled}
    */
    readonly hybridAccessEnabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_resource#id AwsResource#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_resource#region AwsResource#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_resource#role_arn AwsResource#role_arn}
    */
    readonly roleArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_resource#use_service_linked_role AwsResource#use_service_linked_role}
    */
    readonly useServiceLinkedRole?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_resource#with_federation AwsResource#with_federation}
    */
    readonly withFederation?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_resource#with_privileged_access AwsResource#with_privileged_access}
    */
    readonly withPrivilegedAccess?: boolean | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_resource aws_lakeformation_resource}
*/
export declare class AwsResource extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_lakeformation_resource";
    /**
    * Generates CDKTN code for importing a AwsResource resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsResource to import
    * @param importFromId The id of the existing AwsResource that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_resource#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsResource to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_resource aws_lakeformation_resource} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsResourceConfig
    */
    constructor(scope: Construct, id: string, config: AwsResourceConfig);
    private _arn?;
    get arn(): string;
    set arn(value: string);
    get arnInput(): string | undefined;
    private _hybridAccessEnabled?;
    get hybridAccessEnabled(): boolean | cdktn.IResolvable;
    set hybridAccessEnabled(value: boolean | cdktn.IResolvable);
    resetHybridAccessEnabled(): void;
    get hybridAccessEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get lastModified(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _roleArn?;
    get roleArn(): string;
    set roleArn(value: string);
    resetRoleArn(): void;
    get roleArnInput(): string | undefined;
    private _useServiceLinkedRole?;
    get useServiceLinkedRole(): boolean | cdktn.IResolvable;
    set useServiceLinkedRole(value: boolean | cdktn.IResolvable);
    resetUseServiceLinkedRole(): void;
    get useServiceLinkedRoleInput(): boolean | cdktn.IResolvable | undefined;
    private _withFederation?;
    get withFederation(): boolean | cdktn.IResolvable;
    set withFederation(value: boolean | cdktn.IResolvable);
    resetWithFederation(): void;
    get withFederationInput(): boolean | cdktn.IResolvable | undefined;
    private _withPrivilegedAccess?;
    get withPrivilegedAccess(): boolean | cdktn.IResolvable;
    set withPrivilegedAccess(value: boolean | cdktn.IResolvable);
    resetWithPrivilegedAccess(): void;
    get withPrivilegedAccessInput(): boolean | cdktn.IResolvable | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
