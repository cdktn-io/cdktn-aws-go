import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsResourceLfTagsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_resource_lf_tags#catalog_id AwsResourceLfTags#catalog_id}
    */
    readonly catalogId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_resource_lf_tags#id AwsResourceLfTags#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_resource_lf_tags#region AwsResourceLfTags#region}
    */
    readonly region?: string;
    /**
    * database block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_resource_lf_tags#database AwsResourceLfTags#database}
    */
    readonly database?: AwsResourceLfTags.DatabaseProperty;
    /**
    * lf_tag block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_resource_lf_tags#lf_tag AwsResourceLfTags#lf_tag}
    */
    readonly lfTag: AwsResourceLfTags.LfTagProperty[] | cdktn.IResolvable;
    /**
    * table block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_resource_lf_tags#table AwsResourceLfTags#table}
    */
    readonly table?: AwsResourceLfTags.TableProperty;
    /**
    * table_with_columns block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_resource_lf_tags#table_with_columns AwsResourceLfTags#table_with_columns}
    */
    readonly tableWithColumns?: AwsResourceLfTags.TableWithColumnsProperty;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_resource_lf_tags#timeouts AwsResourceLfTags#timeouts}
    */
    readonly timeouts?: AwsResourceLfTags.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_resource_lf_tags aws_lakeformation_resource_lf_tags}
*/
export declare class AwsResourceLfTags extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_lakeformation_resource_lf_tags";
    /**
    * Generates CDKTN code for importing a AwsResourceLfTags resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsResourceLfTags to import
    * @param importFromId The id of the existing AwsResourceLfTags that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_resource_lf_tags#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsResourceLfTags to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_resource_lf_tags aws_lakeformation_resource_lf_tags} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsResourceLfTagsConfig
    */
    constructor(scope: Construct, id: string, config: AwsResourceLfTagsConfig);
    private _catalogId?;
    get catalogId(): string;
    set catalogId(value: string);
    resetCatalogId(): void;
    get catalogIdInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _database;
    get database(): AwsResourceLfTags.DatabasePropertyOutputReference;
    putDatabase(value: AwsResourceLfTags.DatabaseProperty): void;
    resetDatabase(): void;
    get databaseInput(): AwsResourceLfTags.DatabaseProperty | undefined;
    private _lfTag;
    get lfTag(): AwsResourceLfTags.LfTagPropertyList;
    putLfTag(value: AwsResourceLfTags.LfTagProperty[] | cdktn.IResolvable): void;
    get lfTagInput(): cdktn.IResolvable | AwsResourceLfTags.LfTagProperty[] | undefined;
    private _table;
    get table(): AwsResourceLfTags.TablePropertyOutputReference;
    putTable(value: AwsResourceLfTags.TableProperty): void;
    resetTable(): void;
    get tableInput(): AwsResourceLfTags.TableProperty | undefined;
    private _tableWithColumns;
    get tableWithColumns(): AwsResourceLfTags.TableWithColumnsPropertyOutputReference;
    putTableWithColumns(value: AwsResourceLfTags.TableWithColumnsProperty): void;
    resetTableWithColumns(): void;
    get tableWithColumnsInput(): AwsResourceLfTags.TableWithColumnsProperty | undefined;
    private _timeouts;
    get timeouts(): AwsResourceLfTags.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsResourceLfTags.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsResourceLfTags.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsResourceLfTagsDatabasePropertyToTerraform(struct?: AwsResourceLfTags.DatabasePropertyOutputReference | AwsResourceLfTags.DatabaseProperty): any;
export declare function awsResourceLfTagsDatabasePropertyToHclTerraform(struct?: AwsResourceLfTags.DatabasePropertyOutputReference | AwsResourceLfTags.DatabaseProperty): any;
export declare function awsResourceLfTagsLfTagPropertyToTerraform(struct?: AwsResourceLfTags.LfTagProperty | cdktn.IResolvable): any;
export declare function awsResourceLfTagsLfTagPropertyToHclTerraform(struct?: AwsResourceLfTags.LfTagProperty | cdktn.IResolvable): any;
export declare function awsResourceLfTagsTablePropertyToTerraform(struct?: AwsResourceLfTags.TablePropertyOutputReference | AwsResourceLfTags.TableProperty): any;
export declare function awsResourceLfTagsTablePropertyToHclTerraform(struct?: AwsResourceLfTags.TablePropertyOutputReference | AwsResourceLfTags.TableProperty): any;
export declare function awsResourceLfTagsTableWithColumnsPropertyToTerraform(struct?: AwsResourceLfTags.TableWithColumnsPropertyOutputReference | AwsResourceLfTags.TableWithColumnsProperty): any;
export declare function awsResourceLfTagsTableWithColumnsPropertyToHclTerraform(struct?: AwsResourceLfTags.TableWithColumnsPropertyOutputReference | AwsResourceLfTags.TableWithColumnsProperty): any;
export declare function awsResourceLfTagsTimeoutsPropertyToTerraform(struct?: AwsResourceLfTags.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsResourceLfTagsTimeoutsPropertyToHclTerraform(struct?: AwsResourceLfTags.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsResourceLfTags {
    interface DatabaseProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_resource_lf_tags#catalog_id AwsResourceLfTags#catalog_id}
        */
        readonly catalogId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_resource_lf_tags#name AwsResourceLfTags#name}
        */
        readonly name: string;
    }
    class DatabasePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DatabaseProperty | undefined;
        set internalValue(value: DatabaseProperty | undefined);
        private _catalogId?;
        get catalogId(): string;
        set catalogId(value: string);
        resetCatalogId(): void;
        get catalogIdInput(): string | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
    }
    interface LfTagProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_resource_lf_tags#catalog_id AwsResourceLfTags#catalog_id}
        */
        readonly catalogId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_resource_lf_tags#key AwsResourceLfTags#key}
        */
        readonly key: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_resource_lf_tags#value AwsResourceLfTags#value}
        */
        readonly value: string;
    }
    class LfTagPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): LfTagProperty | cdktn.IResolvable | undefined;
        set internalValue(value: LfTagProperty | cdktn.IResolvable | undefined);
        private _catalogId?;
        get catalogId(): string;
        set catalogId(value: string);
        resetCatalogId(): void;
        get catalogIdInput(): string | undefined;
        private _key?;
        get key(): string;
        set key(value: string);
        get keyInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class LfTagPropertyList extends cdktn.ComplexList {
        internalValue?: LfTagProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): LfTagPropertyOutputReference;
    }
    interface TableProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_resource_lf_tags#catalog_id AwsResourceLfTags#catalog_id}
        */
        readonly catalogId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_resource_lf_tags#database_name AwsResourceLfTags#database_name}
        */
        readonly databaseName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_resource_lf_tags#name AwsResourceLfTags#name}
        */
        readonly name?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_resource_lf_tags#wildcard AwsResourceLfTags#wildcard}
        */
        readonly wildcard?: boolean | cdktn.IResolvable;
    }
    class TablePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TableProperty | undefined;
        set internalValue(value: TableProperty | undefined);
        private _catalogId?;
        get catalogId(): string;
        set catalogId(value: string);
        resetCatalogId(): void;
        get catalogIdInput(): string | undefined;
        private _databaseName?;
        get databaseName(): string;
        set databaseName(value: string);
        get databaseNameInput(): string | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        resetName(): void;
        get nameInput(): string | undefined;
        private _wildcard?;
        get wildcard(): boolean | cdktn.IResolvable;
        set wildcard(value: boolean | cdktn.IResolvable);
        resetWildcard(): void;
        get wildcardInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface TableWithColumnsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_resource_lf_tags#catalog_id AwsResourceLfTags#catalog_id}
        */
        readonly catalogId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_resource_lf_tags#column_names AwsResourceLfTags#column_names}
        */
        readonly columnNames?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_resource_lf_tags#database_name AwsResourceLfTags#database_name}
        */
        readonly databaseName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_resource_lf_tags#excluded_column_names AwsResourceLfTags#excluded_column_names}
        */
        readonly excludedColumnNames?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_resource_lf_tags#name AwsResourceLfTags#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_resource_lf_tags#wildcard AwsResourceLfTags#wildcard}
        */
        readonly wildcard?: boolean | cdktn.IResolvable;
    }
    class TableWithColumnsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TableWithColumnsProperty | undefined;
        set internalValue(value: TableWithColumnsProperty | undefined);
        private _catalogId?;
        get catalogId(): string;
        set catalogId(value: string);
        resetCatalogId(): void;
        get catalogIdInput(): string | undefined;
        private _columnNames?;
        get columnNames(): string[];
        set columnNames(value: string[]);
        resetColumnNames(): void;
        get columnNamesInput(): string[] | undefined;
        private _databaseName?;
        get databaseName(): string;
        set databaseName(value: string);
        get databaseNameInput(): string | undefined;
        private _excludedColumnNames?;
        get excludedColumnNames(): string[];
        set excludedColumnNames(value: string[]);
        resetExcludedColumnNames(): void;
        get excludedColumnNamesInput(): string[] | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _wildcard?;
        get wildcard(): boolean | cdktn.IResolvable;
        set wildcard(value: boolean | cdktn.IResolvable);
        resetWildcard(): void;
        get wildcardInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_resource_lf_tags#create AwsResourceLfTags#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lakeformation_resource_lf_tags#delete AwsResourceLfTags#delete}
        */
        readonly delete?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
    }
}
