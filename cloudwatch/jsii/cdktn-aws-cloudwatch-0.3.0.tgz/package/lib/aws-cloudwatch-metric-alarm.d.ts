import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsMetricAlarmConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_metric_alarm#actions_enabled AwsMetricAlarm#actions_enabled}
    */
    readonly actionsEnabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_metric_alarm#alarm_actions AwsMetricAlarm#alarm_actions}
    */
    readonly alarmActions?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_metric_alarm#alarm_description AwsMetricAlarm#alarm_description}
    */
    readonly alarmDescription?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_metric_alarm#alarm_name AwsMetricAlarm#alarm_name}
    */
    readonly alarmName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_metric_alarm#comparison_operator AwsMetricAlarm#comparison_operator}
    */
    readonly comparisonOperator?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_metric_alarm#datapoints_to_alarm AwsMetricAlarm#datapoints_to_alarm}
    */
    readonly datapointsToAlarm?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_metric_alarm#dimensions AwsMetricAlarm#dimensions}
    */
    readonly dimensions?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_metric_alarm#evaluate_low_sample_count_percentiles AwsMetricAlarm#evaluate_low_sample_count_percentiles}
    */
    readonly evaluateLowSampleCountPercentiles?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_metric_alarm#evaluation_interval AwsMetricAlarm#evaluation_interval}
    */
    readonly evaluationInterval?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_metric_alarm#evaluation_periods AwsMetricAlarm#evaluation_periods}
    */
    readonly evaluationPeriods?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_metric_alarm#extended_statistic AwsMetricAlarm#extended_statistic}
    */
    readonly extendedStatistic?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_metric_alarm#id AwsMetricAlarm#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_metric_alarm#insufficient_data_actions AwsMetricAlarm#insufficient_data_actions}
    */
    readonly insufficientDataActions?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_metric_alarm#metric_name AwsMetricAlarm#metric_name}
    */
    readonly metricName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_metric_alarm#namespace AwsMetricAlarm#namespace}
    */
    readonly namespace?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_metric_alarm#ok_actions AwsMetricAlarm#ok_actions}
    */
    readonly okActions?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_metric_alarm#period AwsMetricAlarm#period}
    */
    readonly period?: number;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_metric_alarm#region AwsMetricAlarm#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_metric_alarm#statistic AwsMetricAlarm#statistic}
    */
    readonly statistic?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_metric_alarm#tags AwsMetricAlarm#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_metric_alarm#tags_all AwsMetricAlarm#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_metric_alarm#threshold AwsMetricAlarm#threshold}
    */
    readonly threshold?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_metric_alarm#threshold_metric_id AwsMetricAlarm#threshold_metric_id}
    */
    readonly thresholdMetricId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_metric_alarm#treat_missing_data AwsMetricAlarm#treat_missing_data}
    */
    readonly treatMissingData?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_metric_alarm#unit AwsMetricAlarm#unit}
    */
    readonly unit?: string;
    /**
    * evaluation_criteria block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_metric_alarm#evaluation_criteria AwsMetricAlarm#evaluation_criteria}
    */
    readonly evaluationCriteria?: AwsMetricAlarm.EvaluationCriteriaProperty;
    /**
    * metric_query block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_metric_alarm#metric_query AwsMetricAlarm#metric_query}
    */
    readonly metricQuery?: AwsMetricAlarm.MetricQueryProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_metric_alarm aws_cloudwatch_metric_alarm}
*/
export declare class AwsMetricAlarm extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_cloudwatch_metric_alarm";
    /**
    * Generates CDKTN code for importing a AwsMetricAlarm resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsMetricAlarm to import
    * @param importFromId The id of the existing AwsMetricAlarm that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_metric_alarm#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsMetricAlarm to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_metric_alarm aws_cloudwatch_metric_alarm} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsMetricAlarmConfig
    */
    constructor(scope: Construct, id: string, config: AwsMetricAlarmConfig);
    private _actionsEnabled?;
    get actionsEnabled(): boolean | cdktn.IResolvable;
    set actionsEnabled(value: boolean | cdktn.IResolvable);
    resetActionsEnabled(): void;
    get actionsEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _alarmActions?;
    get alarmActions(): string[];
    set alarmActions(value: string[]);
    resetAlarmActions(): void;
    get alarmActionsInput(): string[] | undefined;
    private _alarmDescription?;
    get alarmDescription(): string;
    set alarmDescription(value: string);
    resetAlarmDescription(): void;
    get alarmDescriptionInput(): string | undefined;
    private _alarmName?;
    get alarmName(): string;
    set alarmName(value: string);
    get alarmNameInput(): string | undefined;
    get arn(): string;
    private _comparisonOperator?;
    get comparisonOperator(): string;
    set comparisonOperator(value: string);
    resetComparisonOperator(): void;
    get comparisonOperatorInput(): string | undefined;
    private _datapointsToAlarm?;
    get datapointsToAlarm(): number;
    set datapointsToAlarm(value: number);
    resetDatapointsToAlarm(): void;
    get datapointsToAlarmInput(): number | undefined;
    private _dimensions?;
    get dimensions(): {
        [key: string]: string;
    };
    set dimensions(value: {
        [key: string]: string;
    });
    resetDimensions(): void;
    get dimensionsInput(): {
        [key: string]: string;
    } | undefined;
    private _evaluateLowSampleCountPercentiles?;
    get evaluateLowSampleCountPercentiles(): string;
    set evaluateLowSampleCountPercentiles(value: string);
    resetEvaluateLowSampleCountPercentiles(): void;
    get evaluateLowSampleCountPercentilesInput(): string | undefined;
    private _evaluationInterval?;
    get evaluationInterval(): number;
    set evaluationInterval(value: number);
    resetEvaluationInterval(): void;
    get evaluationIntervalInput(): number | undefined;
    private _evaluationPeriods?;
    get evaluationPeriods(): number;
    set evaluationPeriods(value: number);
    resetEvaluationPeriods(): void;
    get evaluationPeriodsInput(): number | undefined;
    private _extendedStatistic?;
    get extendedStatistic(): string;
    set extendedStatistic(value: string);
    resetExtendedStatistic(): void;
    get extendedStatisticInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _insufficientDataActions?;
    get insufficientDataActions(): string[];
    set insufficientDataActions(value: string[]);
    resetInsufficientDataActions(): void;
    get insufficientDataActionsInput(): string[] | undefined;
    private _metricName?;
    get metricName(): string;
    set metricName(value: string);
    resetMetricName(): void;
    get metricNameInput(): string | undefined;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    resetNamespace(): void;
    get namespaceInput(): string | undefined;
    private _okActions?;
    get okActions(): string[];
    set okActions(value: string[]);
    resetOkActions(): void;
    get okActionsInput(): string[] | undefined;
    private _period?;
    get period(): number;
    set period(value: number);
    resetPeriod(): void;
    get periodInput(): number | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _statistic?;
    get statistic(): string;
    set statistic(value: string);
    resetStatistic(): void;
    get statisticInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _threshold?;
    get threshold(): number;
    set threshold(value: number);
    resetThreshold(): void;
    get thresholdInput(): number | undefined;
    private _thresholdMetricId?;
    get thresholdMetricId(): string;
    set thresholdMetricId(value: string);
    resetThresholdMetricId(): void;
    get thresholdMetricIdInput(): string | undefined;
    private _treatMissingData?;
    get treatMissingData(): string;
    set treatMissingData(value: string);
    resetTreatMissingData(): void;
    get treatMissingDataInput(): string | undefined;
    private _unit?;
    get unit(): string;
    set unit(value: string);
    resetUnit(): void;
    get unitInput(): string | undefined;
    private _evaluationCriteria;
    get evaluationCriteria(): AwsMetricAlarm.EvaluationCriteriaPropertyOutputReference;
    putEvaluationCriteria(value: AwsMetricAlarm.EvaluationCriteriaProperty): void;
    resetEvaluationCriteria(): void;
    get evaluationCriteriaInput(): AwsMetricAlarm.EvaluationCriteriaProperty | undefined;
    private _metricQuery;
    get metricQuery(): AwsMetricAlarm.MetricQueryPropertyList;
    putMetricQuery(value: AwsMetricAlarm.MetricQueryProperty[] | cdktn.IResolvable): void;
    resetMetricQuery(): void;
    get metricQueryInput(): cdktn.IResolvable | AwsMetricAlarm.MetricQueryProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsMetricAlarmPromqlCriteriaPropertyToTerraform(struct?: AwsMetricAlarm.PromqlCriteriaPropertyOutputReference | AwsMetricAlarm.PromqlCriteriaProperty): any;
export declare function awsMetricAlarmPromqlCriteriaPropertyToHclTerraform(struct?: AwsMetricAlarm.PromqlCriteriaPropertyOutputReference | AwsMetricAlarm.PromqlCriteriaProperty): any;
export declare function awsMetricAlarmEvaluationCriteriaPropertyToTerraform(struct?: AwsMetricAlarm.EvaluationCriteriaPropertyOutputReference | AwsMetricAlarm.EvaluationCriteriaProperty): any;
export declare function awsMetricAlarmEvaluationCriteriaPropertyToHclTerraform(struct?: AwsMetricAlarm.EvaluationCriteriaPropertyOutputReference | AwsMetricAlarm.EvaluationCriteriaProperty): any;
export declare function awsMetricAlarmMetricPropertyToTerraform(struct?: AwsMetricAlarm.MetricPropertyOutputReference | AwsMetricAlarm.MetricProperty): any;
export declare function awsMetricAlarmMetricPropertyToHclTerraform(struct?: AwsMetricAlarm.MetricPropertyOutputReference | AwsMetricAlarm.MetricProperty): any;
export declare function awsMetricAlarmMetricQueryPropertyToTerraform(struct?: AwsMetricAlarm.MetricQueryProperty | cdktn.IResolvable): any;
export declare function awsMetricAlarmMetricQueryPropertyToHclTerraform(struct?: AwsMetricAlarm.MetricQueryProperty | cdktn.IResolvable): any;
export declare namespace AwsMetricAlarm {
    interface PromqlCriteriaProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_metric_alarm#pending_period AwsMetricAlarm#pending_period}
        */
        readonly pendingPeriod?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_metric_alarm#query AwsMetricAlarm#query}
        */
        readonly query: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_metric_alarm#recovery_period AwsMetricAlarm#recovery_period}
        */
        readonly recoveryPeriod?: number;
    }
    class PromqlCriteriaPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): PromqlCriteriaProperty | undefined;
        set internalValue(value: PromqlCriteriaProperty | undefined);
        private _pendingPeriod?;
        get pendingPeriod(): number;
        set pendingPeriod(value: number);
        resetPendingPeriod(): void;
        get pendingPeriodInput(): number | undefined;
        private _query?;
        get query(): string;
        set query(value: string);
        get queryInput(): string | undefined;
        private _recoveryPeriod?;
        get recoveryPeriod(): number;
        set recoveryPeriod(value: number);
        resetRecoveryPeriod(): void;
        get recoveryPeriodInput(): number | undefined;
    }
    interface EvaluationCriteriaProperty {
        /**
        * promql_criteria block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_metric_alarm#promql_criteria AwsMetricAlarm#promql_criteria}
        */
        readonly promqlCriteria: PromqlCriteriaProperty;
    }
    class EvaluationCriteriaPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): EvaluationCriteriaProperty | undefined;
        set internalValue(value: EvaluationCriteriaProperty | undefined);
        private _promqlCriteria;
        get promqlCriteria(): PromqlCriteriaPropertyOutputReference;
        putPromqlCriteria(value: PromqlCriteriaProperty): void;
        get promqlCriteriaInput(): PromqlCriteriaProperty | undefined;
    }
    interface MetricProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_metric_alarm#dimensions AwsMetricAlarm#dimensions}
        */
        readonly dimensions?: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_metric_alarm#metric_name AwsMetricAlarm#metric_name}
        */
        readonly metricName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_metric_alarm#namespace AwsMetricAlarm#namespace}
        */
        readonly namespace?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_metric_alarm#period AwsMetricAlarm#period}
        */
        readonly period: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_metric_alarm#stat AwsMetricAlarm#stat}
        */
        readonly stat: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_metric_alarm#unit AwsMetricAlarm#unit}
        */
        readonly unit?: string;
    }
    class MetricPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): MetricProperty | undefined;
        set internalValue(value: MetricProperty | undefined);
        private _dimensions?;
        get dimensions(): {
            [key: string]: string;
        };
        set dimensions(value: {
            [key: string]: string;
        });
        resetDimensions(): void;
        get dimensionsInput(): {
            [key: string]: string;
        } | undefined;
        private _metricName?;
        get metricName(): string;
        set metricName(value: string);
        get metricNameInput(): string | undefined;
        private _namespace?;
        get namespace(): string;
        set namespace(value: string);
        resetNamespace(): void;
        get namespaceInput(): string | undefined;
        private _period?;
        get period(): number;
        set period(value: number);
        get periodInput(): number | undefined;
        private _stat?;
        get stat(): string;
        set stat(value: string);
        get statInput(): string | undefined;
        private _unit?;
        get unit(): string;
        set unit(value: string);
        resetUnit(): void;
        get unitInput(): string | undefined;
    }
    interface MetricQueryProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_metric_alarm#account_id AwsMetricAlarm#account_id}
        */
        readonly accountId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_metric_alarm#expression AwsMetricAlarm#expression}
        */
        readonly expression?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_metric_alarm#id AwsMetricAlarm#id}
        *
        * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
        * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
        */
        readonly id: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_metric_alarm#label AwsMetricAlarm#label}
        */
        readonly label?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_metric_alarm#period AwsMetricAlarm#period}
        */
        readonly period?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_metric_alarm#return_data AwsMetricAlarm#return_data}
        */
        readonly returnData?: boolean | cdktn.IResolvable;
        /**
        * metric block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_metric_alarm#metric AwsMetricAlarm#metric}
        */
        readonly metric?: MetricProperty;
    }
    class MetricQueryPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): MetricQueryProperty | cdktn.IResolvable | undefined;
        set internalValue(value: MetricQueryProperty | cdktn.IResolvable | undefined);
        private _accountId?;
        get accountId(): string;
        set accountId(value: string);
        resetAccountId(): void;
        get accountIdInput(): string | undefined;
        private _expression?;
        get expression(): string;
        set expression(value: string);
        resetExpression(): void;
        get expressionInput(): string | undefined;
        private _id?;
        get id(): string;
        set id(value: string);
        get idInput(): string | undefined;
        private _label?;
        get label(): string;
        set label(value: string);
        resetLabel(): void;
        get labelInput(): string | undefined;
        private _period?;
        get period(): number;
        set period(value: number);
        resetPeriod(): void;
        get periodInput(): number | undefined;
        private _returnData?;
        get returnData(): boolean | cdktn.IResolvable;
        set returnData(value: boolean | cdktn.IResolvable);
        resetReturnData(): void;
        get returnDataInput(): boolean | cdktn.IResolvable | undefined;
        private _metric;
        get metric(): MetricPropertyOutputReference;
        putMetric(value: MetricProperty): void;
        resetMetric(): void;
        get metricInput(): MetricProperty | undefined;
    }
    class MetricQueryPropertyList extends cdktn.ComplexList {
        internalValue?: MetricQueryProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): MetricQueryPropertyOutputReference;
    }
}
