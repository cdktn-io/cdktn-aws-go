import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsRecordingConfigurationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ivs_recording_configuration#id AwsRecordingConfiguration#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ivs_recording_configuration#name AwsRecordingConfiguration#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ivs_recording_configuration#recording_reconnect_window_seconds AwsRecordingConfiguration#recording_reconnect_window_seconds}
    */
    readonly recordingReconnectWindowSeconds?: number;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ivs_recording_configuration#region AwsRecordingConfiguration#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ivs_recording_configuration#tags AwsRecordingConfiguration#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ivs_recording_configuration#tags_all AwsRecordingConfiguration#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * destination_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ivs_recording_configuration#destination_configuration AwsRecordingConfiguration#destination_configuration}
    */
    readonly destinationConfiguration: AwsRecordingConfiguration.DestinationConfigurationProperty;
    /**
    * thumbnail_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ivs_recording_configuration#thumbnail_configuration AwsRecordingConfiguration#thumbnail_configuration}
    */
    readonly thumbnailConfiguration?: AwsRecordingConfiguration.ThumbnailConfigurationProperty;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ivs_recording_configuration#timeouts AwsRecordingConfiguration#timeouts}
    */
    readonly timeouts?: AwsRecordingConfiguration.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ivs_recording_configuration aws_ivs_recording_configuration}
*/
export declare class AwsRecordingConfiguration extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_ivs_recording_configuration";
    /**
    * Generates CDKTN code for importing a AwsRecordingConfiguration resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsRecordingConfiguration to import
    * @param importFromId The id of the existing AwsRecordingConfiguration that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ivs_recording_configuration#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsRecordingConfiguration to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ivs_recording_configuration aws_ivs_recording_configuration} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsRecordingConfigurationConfig
    */
    constructor(scope: Construct, id: string, config: AwsRecordingConfigurationConfig);
    get arn(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _recordingReconnectWindowSeconds?;
    get recordingReconnectWindowSeconds(): number;
    set recordingReconnectWindowSeconds(value: number);
    resetRecordingReconnectWindowSeconds(): void;
    get recordingReconnectWindowSecondsInput(): number | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get state(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _destinationConfiguration;
    get destinationConfiguration(): AwsRecordingConfiguration.DestinationConfigurationPropertyOutputReference;
    putDestinationConfiguration(value: AwsRecordingConfiguration.DestinationConfigurationProperty): void;
    get destinationConfigurationInput(): AwsRecordingConfiguration.DestinationConfigurationProperty | undefined;
    private _thumbnailConfiguration;
    get thumbnailConfiguration(): AwsRecordingConfiguration.ThumbnailConfigurationPropertyOutputReference;
    putThumbnailConfiguration(value: AwsRecordingConfiguration.ThumbnailConfigurationProperty): void;
    resetThumbnailConfiguration(): void;
    get thumbnailConfigurationInput(): AwsRecordingConfiguration.ThumbnailConfigurationProperty | undefined;
    private _timeouts;
    get timeouts(): AwsRecordingConfiguration.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsRecordingConfiguration.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsRecordingConfiguration.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsRecordingConfigurationS3PropertyToTerraform(struct?: AwsRecordingConfiguration.S3PropertyOutputReference | AwsRecordingConfiguration.S3Property): any;
export declare function awsRecordingConfigurationS3PropertyToHclTerraform(struct?: AwsRecordingConfiguration.S3PropertyOutputReference | AwsRecordingConfiguration.S3Property): any;
export declare function awsRecordingConfigurationDestinationConfigurationPropertyToTerraform(struct?: AwsRecordingConfiguration.DestinationConfigurationPropertyOutputReference | AwsRecordingConfiguration.DestinationConfigurationProperty): any;
export declare function awsRecordingConfigurationDestinationConfigurationPropertyToHclTerraform(struct?: AwsRecordingConfiguration.DestinationConfigurationPropertyOutputReference | AwsRecordingConfiguration.DestinationConfigurationProperty): any;
export declare function awsRecordingConfigurationThumbnailConfigurationPropertyToTerraform(struct?: AwsRecordingConfiguration.ThumbnailConfigurationPropertyOutputReference | AwsRecordingConfiguration.ThumbnailConfigurationProperty): any;
export declare function awsRecordingConfigurationThumbnailConfigurationPropertyToHclTerraform(struct?: AwsRecordingConfiguration.ThumbnailConfigurationPropertyOutputReference | AwsRecordingConfiguration.ThumbnailConfigurationProperty): any;
export declare function awsRecordingConfigurationTimeoutsPropertyToTerraform(struct?: AwsRecordingConfiguration.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsRecordingConfigurationTimeoutsPropertyToHclTerraform(struct?: AwsRecordingConfiguration.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsRecordingConfiguration {
    interface S3Property {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ivs_recording_configuration#bucket_name AwsRecordingConfiguration#bucket_name}
        */
        readonly bucketName: string;
    }
    class S3PropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): S3Property | undefined;
        set internalValue(value: S3Property | undefined);
        private _bucketName?;
        get bucketName(): string;
        set bucketName(value: string);
        get bucketNameInput(): string | undefined;
    }
    interface DestinationConfigurationProperty {
        /**
        * s3 block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ivs_recording_configuration#s3 AwsRecordingConfiguration#s3}
        */
        readonly s3: S3Property;
    }
    class DestinationConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DestinationConfigurationProperty | undefined;
        set internalValue(value: DestinationConfigurationProperty | undefined);
        private _s3;
        get s3(): S3PropertyOutputReference;
        putS3(value: S3Property): void;
        get s3Input(): S3Property | undefined;
    }
    interface ThumbnailConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ivs_recording_configuration#recording_mode AwsRecordingConfiguration#recording_mode}
        */
        readonly recordingMode?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ivs_recording_configuration#target_interval_seconds AwsRecordingConfiguration#target_interval_seconds}
        */
        readonly targetIntervalSeconds?: number;
    }
    class ThumbnailConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ThumbnailConfigurationProperty | undefined;
        set internalValue(value: ThumbnailConfigurationProperty | undefined);
        private _recordingMode?;
        get recordingMode(): string;
        set recordingMode(value: string);
        resetRecordingMode(): void;
        get recordingModeInput(): string | undefined;
        private _targetIntervalSeconds?;
        get targetIntervalSeconds(): number;
        set targetIntervalSeconds(value: number);
        resetTargetIntervalSeconds(): void;
        get targetIntervalSecondsInput(): number | undefined;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ivs_recording_configuration#create AwsRecordingConfiguration#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ivs_recording_configuration#delete AwsRecordingConfiguration#delete}
        */
        readonly delete?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
    }
}
