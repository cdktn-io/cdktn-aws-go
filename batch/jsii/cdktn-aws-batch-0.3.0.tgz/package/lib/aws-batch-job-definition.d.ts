import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsJobDefinitionConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_definition#container_properties AwsJobDefinition#container_properties}
    */
    readonly containerProperties?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_definition#deregister_on_new_revision AwsJobDefinition#deregister_on_new_revision}
    */
    readonly deregisterOnNewRevision?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_definition#ecs_properties AwsJobDefinition#ecs_properties}
    */
    readonly ecsProperties?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_definition#id AwsJobDefinition#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_definition#name AwsJobDefinition#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_definition#node_properties AwsJobDefinition#node_properties}
    */
    readonly nodeProperties?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_definition#parameters AwsJobDefinition#parameters}
    */
    readonly parameters?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_definition#platform_capabilities AwsJobDefinition#platform_capabilities}
    */
    readonly platformCapabilities?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_definition#propagate_tags AwsJobDefinition#propagate_tags}
    */
    readonly propagateTags?: boolean | cdktn.IResolvable;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_definition#region AwsJobDefinition#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_definition#scheduling_priority AwsJobDefinition#scheduling_priority}
    */
    readonly schedulingPriority?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_definition#tags AwsJobDefinition#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_definition#tags_all AwsJobDefinition#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_definition#type AwsJobDefinition#type}
    */
    readonly type: string;
    /**
    * eks_properties block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_definition#eks_properties AwsJobDefinition#eks_properties}
    */
    readonly eksProperties?: AwsJobDefinition.EksPropertiesProperty;
    /**
    * retry_strategy block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_definition#retry_strategy AwsJobDefinition#retry_strategy}
    */
    readonly retryStrategy?: AwsJobDefinition.RetryStrategyProperty;
    /**
    * timeout block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_definition#timeout AwsJobDefinition#timeout}
    */
    readonly timeout?: AwsJobDefinition.TimeoutProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_definition aws_batch_job_definition}
*/
export declare class AwsJobDefinition extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_batch_job_definition";
    /**
    * Generates CDKTN code for importing a AwsJobDefinition resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsJobDefinition to import
    * @param importFromId The id of the existing AwsJobDefinition that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_definition#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsJobDefinition to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_definition aws_batch_job_definition} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsJobDefinitionConfig
    */
    constructor(scope: Construct, id: string, config: AwsJobDefinitionConfig);
    get arn(): string;
    get arnPrefix(): string;
    private _containerProperties?;
    get containerProperties(): string;
    set containerProperties(value: string);
    resetContainerProperties(): void;
    get containerPropertiesInput(): string | undefined;
    private _deregisterOnNewRevision?;
    get deregisterOnNewRevision(): boolean | cdktn.IResolvable;
    set deregisterOnNewRevision(value: boolean | cdktn.IResolvable);
    resetDeregisterOnNewRevision(): void;
    get deregisterOnNewRevisionInput(): boolean | cdktn.IResolvable | undefined;
    private _ecsProperties?;
    get ecsProperties(): string;
    set ecsProperties(value: string);
    resetEcsProperties(): void;
    get ecsPropertiesInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _nodeProperties?;
    get nodeProperties(): string;
    set nodeProperties(value: string);
    resetNodeProperties(): void;
    get nodePropertiesInput(): string | undefined;
    private _parameters?;
    get parameters(): {
        [key: string]: string;
    };
    set parameters(value: {
        [key: string]: string;
    });
    resetParameters(): void;
    get parametersInput(): {
        [key: string]: string;
    } | undefined;
    private _platformCapabilities?;
    get platformCapabilities(): string[];
    set platformCapabilities(value: string[]);
    resetPlatformCapabilities(): void;
    get platformCapabilitiesInput(): string[] | undefined;
    private _propagateTags?;
    get propagateTags(): boolean | cdktn.IResolvable;
    set propagateTags(value: boolean | cdktn.IResolvable);
    resetPropagateTags(): void;
    get propagateTagsInput(): boolean | cdktn.IResolvable | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get revision(): number;
    private _schedulingPriority?;
    get schedulingPriority(): number;
    set schedulingPriority(value: number);
    resetSchedulingPriority(): void;
    get schedulingPriorityInput(): number | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _eksProperties;
    get eksProperties(): AwsJobDefinition.EksPropertiesPropertyOutputReference;
    putEksProperties(value: AwsJobDefinition.EksPropertiesProperty): void;
    resetEksProperties(): void;
    get eksPropertiesInput(): AwsJobDefinition.EksPropertiesProperty | undefined;
    private _retryStrategy;
    get retryStrategy(): AwsJobDefinition.RetryStrategyPropertyOutputReference;
    putRetryStrategy(value: AwsJobDefinition.RetryStrategyProperty): void;
    resetRetryStrategy(): void;
    get retryStrategyInput(): AwsJobDefinition.RetryStrategyProperty | undefined;
    private _timeout;
    get timeout(): AwsJobDefinition.TimeoutPropertyOutputReference;
    putTimeout(value: AwsJobDefinition.TimeoutProperty): void;
    resetTimeout(): void;
    get timeoutInput(): AwsJobDefinition.TimeoutProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsJobDefinitionEksPropertiesPodPropertiesContainersEnvPropertyToTerraform(struct?: AwsJobDefinition.EksPropertiesPodPropertiesContainersEnvProperty | cdktn.IResolvable): any;
export declare function awsJobDefinitionEksPropertiesPodPropertiesContainersEnvPropertyToHclTerraform(struct?: AwsJobDefinition.EksPropertiesPodPropertiesContainersEnvProperty | cdktn.IResolvable): any;
export declare function awsJobDefinitionEksPropertiesPodPropertiesContainersResourcesPropertyToTerraform(struct?: AwsJobDefinition.EksPropertiesPodPropertiesContainersResourcesPropertyOutputReference | AwsJobDefinition.EksPropertiesPodPropertiesContainersResourcesProperty): any;
export declare function awsJobDefinitionEksPropertiesPodPropertiesContainersResourcesPropertyToHclTerraform(struct?: AwsJobDefinition.EksPropertiesPodPropertiesContainersResourcesPropertyOutputReference | AwsJobDefinition.EksPropertiesPodPropertiesContainersResourcesProperty): any;
export declare function awsJobDefinitionEksPropertiesPodPropertiesContainersSecurityContextPropertyToTerraform(struct?: AwsJobDefinition.EksPropertiesPodPropertiesContainersSecurityContextPropertyOutputReference | AwsJobDefinition.EksPropertiesPodPropertiesContainersSecurityContextProperty): any;
export declare function awsJobDefinitionEksPropertiesPodPropertiesContainersSecurityContextPropertyToHclTerraform(struct?: AwsJobDefinition.EksPropertiesPodPropertiesContainersSecurityContextPropertyOutputReference | AwsJobDefinition.EksPropertiesPodPropertiesContainersSecurityContextProperty): any;
export declare function awsJobDefinitionEksPropertiesPodPropertiesContainersVolumeMountsPropertyToTerraform(struct?: AwsJobDefinition.EksPropertiesPodPropertiesContainersVolumeMountsProperty | cdktn.IResolvable): any;
export declare function awsJobDefinitionEksPropertiesPodPropertiesContainersVolumeMountsPropertyToHclTerraform(struct?: AwsJobDefinition.EksPropertiesPodPropertiesContainersVolumeMountsProperty | cdktn.IResolvable): any;
export declare function awsJobDefinitionContainersPropertyToTerraform(struct?: AwsJobDefinition.ContainersProperty | cdktn.IResolvable): any;
export declare function awsJobDefinitionContainersPropertyToHclTerraform(struct?: AwsJobDefinition.ContainersProperty | cdktn.IResolvable): any;
export declare function awsJobDefinitionImagePullSecretPropertyToTerraform(struct?: AwsJobDefinition.ImagePullSecretProperty | cdktn.IResolvable): any;
export declare function awsJobDefinitionImagePullSecretPropertyToHclTerraform(struct?: AwsJobDefinition.ImagePullSecretProperty | cdktn.IResolvable): any;
export declare function awsJobDefinitionEksPropertiesPodPropertiesInitContainersEnvPropertyToTerraform(struct?: AwsJobDefinition.EksPropertiesPodPropertiesInitContainersEnvProperty | cdktn.IResolvable): any;
export declare function awsJobDefinitionEksPropertiesPodPropertiesInitContainersEnvPropertyToHclTerraform(struct?: AwsJobDefinition.EksPropertiesPodPropertiesInitContainersEnvProperty | cdktn.IResolvable): any;
export declare function awsJobDefinitionEksPropertiesPodPropertiesInitContainersResourcesPropertyToTerraform(struct?: AwsJobDefinition.EksPropertiesPodPropertiesInitContainersResourcesPropertyOutputReference | AwsJobDefinition.EksPropertiesPodPropertiesInitContainersResourcesProperty): any;
export declare function awsJobDefinitionEksPropertiesPodPropertiesInitContainersResourcesPropertyToHclTerraform(struct?: AwsJobDefinition.EksPropertiesPodPropertiesInitContainersResourcesPropertyOutputReference | AwsJobDefinition.EksPropertiesPodPropertiesInitContainersResourcesProperty): any;
export declare function awsJobDefinitionEksPropertiesPodPropertiesInitContainersSecurityContextPropertyToTerraform(struct?: AwsJobDefinition.EksPropertiesPodPropertiesInitContainersSecurityContextPropertyOutputReference | AwsJobDefinition.EksPropertiesPodPropertiesInitContainersSecurityContextProperty): any;
export declare function awsJobDefinitionEksPropertiesPodPropertiesInitContainersSecurityContextPropertyToHclTerraform(struct?: AwsJobDefinition.EksPropertiesPodPropertiesInitContainersSecurityContextPropertyOutputReference | AwsJobDefinition.EksPropertiesPodPropertiesInitContainersSecurityContextProperty): any;
export declare function awsJobDefinitionEksPropertiesPodPropertiesInitContainersVolumeMountsPropertyToTerraform(struct?: AwsJobDefinition.EksPropertiesPodPropertiesInitContainersVolumeMountsProperty | cdktn.IResolvable): any;
export declare function awsJobDefinitionEksPropertiesPodPropertiesInitContainersVolumeMountsPropertyToHclTerraform(struct?: AwsJobDefinition.EksPropertiesPodPropertiesInitContainersVolumeMountsProperty | cdktn.IResolvable): any;
export declare function awsJobDefinitionInitContainersPropertyToTerraform(struct?: AwsJobDefinition.InitContainersProperty | cdktn.IResolvable): any;
export declare function awsJobDefinitionInitContainersPropertyToHclTerraform(struct?: AwsJobDefinition.InitContainersProperty | cdktn.IResolvable): any;
export declare function awsJobDefinitionMetadataPropertyToTerraform(struct?: AwsJobDefinition.MetadataPropertyOutputReference | AwsJobDefinition.MetadataProperty): any;
export declare function awsJobDefinitionMetadataPropertyToHclTerraform(struct?: AwsJobDefinition.MetadataPropertyOutputReference | AwsJobDefinition.MetadataProperty): any;
export declare function awsJobDefinitionEmptyDirPropertyToTerraform(struct?: AwsJobDefinition.EmptyDirPropertyOutputReference | AwsJobDefinition.EmptyDirProperty): any;
export declare function awsJobDefinitionEmptyDirPropertyToHclTerraform(struct?: AwsJobDefinition.EmptyDirPropertyOutputReference | AwsJobDefinition.EmptyDirProperty): any;
export declare function awsJobDefinitionHostPathPropertyToTerraform(struct?: AwsJobDefinition.HostPathPropertyOutputReference | AwsJobDefinition.HostPathProperty): any;
export declare function awsJobDefinitionHostPathPropertyToHclTerraform(struct?: AwsJobDefinition.HostPathPropertyOutputReference | AwsJobDefinition.HostPathProperty): any;
export declare function awsJobDefinitionSecretPropertyToTerraform(struct?: AwsJobDefinition.SecretPropertyOutputReference | AwsJobDefinition.SecretProperty): any;
export declare function awsJobDefinitionSecretPropertyToHclTerraform(struct?: AwsJobDefinition.SecretPropertyOutputReference | AwsJobDefinition.SecretProperty): any;
export declare function awsJobDefinitionVolumesPropertyToTerraform(struct?: AwsJobDefinition.VolumesProperty | cdktn.IResolvable): any;
export declare function awsJobDefinitionVolumesPropertyToHclTerraform(struct?: AwsJobDefinition.VolumesProperty | cdktn.IResolvable): any;
export declare function awsJobDefinitionPodPropertiesPropertyToTerraform(struct?: AwsJobDefinition.PodPropertiesPropertyOutputReference | AwsJobDefinition.PodPropertiesProperty): any;
export declare function awsJobDefinitionPodPropertiesPropertyToHclTerraform(struct?: AwsJobDefinition.PodPropertiesPropertyOutputReference | AwsJobDefinition.PodPropertiesProperty): any;
export declare function awsJobDefinitionEksPropertiesPropertyToTerraform(struct?: AwsJobDefinition.EksPropertiesPropertyOutputReference | AwsJobDefinition.EksPropertiesProperty): any;
export declare function awsJobDefinitionEksPropertiesPropertyToHclTerraform(struct?: AwsJobDefinition.EksPropertiesPropertyOutputReference | AwsJobDefinition.EksPropertiesProperty): any;
export declare function awsJobDefinitionEvaluateOnExitPropertyToTerraform(struct?: AwsJobDefinition.EvaluateOnExitProperty | cdktn.IResolvable): any;
export declare function awsJobDefinitionEvaluateOnExitPropertyToHclTerraform(struct?: AwsJobDefinition.EvaluateOnExitProperty | cdktn.IResolvable): any;
export declare function awsJobDefinitionRetryStrategyPropertyToTerraform(struct?: AwsJobDefinition.RetryStrategyPropertyOutputReference | AwsJobDefinition.RetryStrategyProperty): any;
export declare function awsJobDefinitionRetryStrategyPropertyToHclTerraform(struct?: AwsJobDefinition.RetryStrategyPropertyOutputReference | AwsJobDefinition.RetryStrategyProperty): any;
export declare function awsJobDefinitionTimeoutPropertyToTerraform(struct?: AwsJobDefinition.TimeoutPropertyOutputReference | AwsJobDefinition.TimeoutProperty): any;
export declare function awsJobDefinitionTimeoutPropertyToHclTerraform(struct?: AwsJobDefinition.TimeoutPropertyOutputReference | AwsJobDefinition.TimeoutProperty): any;
export declare namespace AwsJobDefinition {
    interface EksPropertiesPodPropertiesContainersEnvProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_definition#name AwsJobDefinition#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_definition#value AwsJobDefinition#value}
        */
        readonly value: string;
    }
    class EksPropertiesPodPropertiesContainersEnvPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EksPropertiesPodPropertiesContainersEnvProperty | cdktn.IResolvable | undefined;
        set internalValue(value: EksPropertiesPodPropertiesContainersEnvProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class EksPropertiesPodPropertiesContainersEnvPropertyList extends cdktn.ComplexList {
        internalValue?: EksPropertiesPodPropertiesContainersEnvProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EksPropertiesPodPropertiesContainersEnvPropertyOutputReference;
    }
    interface EksPropertiesPodPropertiesContainersResourcesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_definition#limits AwsJobDefinition#limits}
        */
        readonly limits?: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_definition#requests AwsJobDefinition#requests}
        */
        readonly requests?: {
            [key: string]: string;
        };
    }
    class EksPropertiesPodPropertiesContainersResourcesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): EksPropertiesPodPropertiesContainersResourcesProperty | undefined;
        set internalValue(value: EksPropertiesPodPropertiesContainersResourcesProperty | undefined);
        private _limits?;
        get limits(): {
            [key: string]: string;
        };
        set limits(value: {
            [key: string]: string;
        });
        resetLimits(): void;
        get limitsInput(): {
            [key: string]: string;
        } | undefined;
        private _requests?;
        get requests(): {
            [key: string]: string;
        };
        set requests(value: {
            [key: string]: string;
        });
        resetRequests(): void;
        get requestsInput(): {
            [key: string]: string;
        } | undefined;
    }
    interface EksPropertiesPodPropertiesContainersSecurityContextProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_definition#allow_privilege_escalation AwsJobDefinition#allow_privilege_escalation}
        */
        readonly allowPrivilegeEscalation?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_definition#privileged AwsJobDefinition#privileged}
        */
        readonly privileged?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_definition#read_only_root_file_system AwsJobDefinition#read_only_root_file_system}
        */
        readonly readOnlyRootFileSystem?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_definition#run_as_group AwsJobDefinition#run_as_group}
        */
        readonly runAsGroup?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_definition#run_as_non_root AwsJobDefinition#run_as_non_root}
        */
        readonly runAsNonRoot?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_definition#run_as_user AwsJobDefinition#run_as_user}
        */
        readonly runAsUser?: number;
    }
    class EksPropertiesPodPropertiesContainersSecurityContextPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): EksPropertiesPodPropertiesContainersSecurityContextProperty | undefined;
        set internalValue(value: EksPropertiesPodPropertiesContainersSecurityContextProperty | undefined);
        private _allowPrivilegeEscalation?;
        get allowPrivilegeEscalation(): boolean | cdktn.IResolvable;
        set allowPrivilegeEscalation(value: boolean | cdktn.IResolvable);
        resetAllowPrivilegeEscalation(): void;
        get allowPrivilegeEscalationInput(): boolean | cdktn.IResolvable | undefined;
        private _privileged?;
        get privileged(): boolean | cdktn.IResolvable;
        set privileged(value: boolean | cdktn.IResolvable);
        resetPrivileged(): void;
        get privilegedInput(): boolean | cdktn.IResolvable | undefined;
        private _readOnlyRootFileSystem?;
        get readOnlyRootFileSystem(): boolean | cdktn.IResolvable;
        set readOnlyRootFileSystem(value: boolean | cdktn.IResolvable);
        resetReadOnlyRootFileSystem(): void;
        get readOnlyRootFileSystemInput(): boolean | cdktn.IResolvable | undefined;
        private _runAsGroup?;
        get runAsGroup(): number;
        set runAsGroup(value: number);
        resetRunAsGroup(): void;
        get runAsGroupInput(): number | undefined;
        private _runAsNonRoot?;
        get runAsNonRoot(): boolean | cdktn.IResolvable;
        set runAsNonRoot(value: boolean | cdktn.IResolvable);
        resetRunAsNonRoot(): void;
        get runAsNonRootInput(): boolean | cdktn.IResolvable | undefined;
        private _runAsUser?;
        get runAsUser(): number;
        set runAsUser(value: number);
        resetRunAsUser(): void;
        get runAsUserInput(): number | undefined;
    }
    interface EksPropertiesPodPropertiesContainersVolumeMountsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_definition#mount_path AwsJobDefinition#mount_path}
        */
        readonly mountPath: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_definition#name AwsJobDefinition#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_definition#read_only AwsJobDefinition#read_only}
        */
        readonly readOnly?: boolean | cdktn.IResolvable;
    }
    class EksPropertiesPodPropertiesContainersVolumeMountsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EksPropertiesPodPropertiesContainersVolumeMountsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: EksPropertiesPodPropertiesContainersVolumeMountsProperty | cdktn.IResolvable | undefined);
        private _mountPath?;
        get mountPath(): string;
        set mountPath(value: string);
        get mountPathInput(): string | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _readOnly?;
        get readOnly(): boolean | cdktn.IResolvable;
        set readOnly(value: boolean | cdktn.IResolvable);
        resetReadOnly(): void;
        get readOnlyInput(): boolean | cdktn.IResolvable | undefined;
    }
    class EksPropertiesPodPropertiesContainersVolumeMountsPropertyList extends cdktn.ComplexList {
        internalValue?: EksPropertiesPodPropertiesContainersVolumeMountsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EksPropertiesPodPropertiesContainersVolumeMountsPropertyOutputReference;
    }
    interface ContainersProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_definition#args AwsJobDefinition#args}
        */
        readonly args?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_definition#command AwsJobDefinition#command}
        */
        readonly command?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_definition#image AwsJobDefinition#image}
        */
        readonly image: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_definition#image_pull_policy AwsJobDefinition#image_pull_policy}
        */
        readonly imagePullPolicy?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_definition#name AwsJobDefinition#name}
        */
        readonly name?: string;
        /**
        * env block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_definition#env AwsJobDefinition#env}
        */
        readonly env?: EksPropertiesPodPropertiesContainersEnvProperty[] | cdktn.IResolvable;
        /**
        * resources block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_definition#resources AwsJobDefinition#resources}
        */
        readonly resources?: EksPropertiesPodPropertiesContainersResourcesProperty;
        /**
        * security_context block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_definition#security_context AwsJobDefinition#security_context}
        */
        readonly securityContext?: EksPropertiesPodPropertiesContainersSecurityContextProperty;
        /**
        * volume_mounts block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_definition#volume_mounts AwsJobDefinition#volume_mounts}
        */
        readonly volumeMounts?: EksPropertiesPodPropertiesContainersVolumeMountsProperty[] | cdktn.IResolvable;
    }
    class ContainersPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ContainersProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ContainersProperty | cdktn.IResolvable | undefined);
        private _args?;
        get args(): string[];
        set args(value: string[]);
        resetArgs(): void;
        get argsInput(): string[] | undefined;
        private _command?;
        get command(): string[];
        set command(value: string[]);
        resetCommand(): void;
        get commandInput(): string[] | undefined;
        private _image?;
        get image(): string;
        set image(value: string);
        get imageInput(): string | undefined;
        private _imagePullPolicy?;
        get imagePullPolicy(): string;
        set imagePullPolicy(value: string);
        resetImagePullPolicy(): void;
        get imagePullPolicyInput(): string | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        resetName(): void;
        get nameInput(): string | undefined;
        private _env;
        get env(): EksPropertiesPodPropertiesContainersEnvPropertyList;
        putEnv(value: EksPropertiesPodPropertiesContainersEnvProperty[] | cdktn.IResolvable): void;
        resetEnv(): void;
        get envInput(): cdktn.IResolvable | EksPropertiesPodPropertiesContainersEnvProperty[] | undefined;
        private _resources;
        get resources(): EksPropertiesPodPropertiesContainersResourcesPropertyOutputReference;
        putResources(value: EksPropertiesPodPropertiesContainersResourcesProperty): void;
        resetResources(): void;
        get resourcesInput(): EksPropertiesPodPropertiesContainersResourcesProperty | undefined;
        private _securityContext;
        get securityContext(): EksPropertiesPodPropertiesContainersSecurityContextPropertyOutputReference;
        putSecurityContext(value: EksPropertiesPodPropertiesContainersSecurityContextProperty): void;
        resetSecurityContext(): void;
        get securityContextInput(): EksPropertiesPodPropertiesContainersSecurityContextProperty | undefined;
        private _volumeMounts;
        get volumeMounts(): EksPropertiesPodPropertiesContainersVolumeMountsPropertyList;
        putVolumeMounts(value: EksPropertiesPodPropertiesContainersVolumeMountsProperty[] | cdktn.IResolvable): void;
        resetVolumeMounts(): void;
        get volumeMountsInput(): cdktn.IResolvable | EksPropertiesPodPropertiesContainersVolumeMountsProperty[] | undefined;
    }
    class ContainersPropertyList extends cdktn.ComplexList {
        internalValue?: ContainersProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ContainersPropertyOutputReference;
    }
    interface ImagePullSecretProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_definition#name AwsJobDefinition#name}
        */
        readonly name: string;
    }
    class ImagePullSecretPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ImagePullSecretProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ImagePullSecretProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
    }
    class ImagePullSecretPropertyList extends cdktn.ComplexList {
        internalValue?: ImagePullSecretProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ImagePullSecretPropertyOutputReference;
    }
    interface EksPropertiesPodPropertiesInitContainersEnvProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_definition#name AwsJobDefinition#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_definition#value AwsJobDefinition#value}
        */
        readonly value: string;
    }
    class EksPropertiesPodPropertiesInitContainersEnvPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EksPropertiesPodPropertiesInitContainersEnvProperty | cdktn.IResolvable | undefined;
        set internalValue(value: EksPropertiesPodPropertiesInitContainersEnvProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class EksPropertiesPodPropertiesInitContainersEnvPropertyList extends cdktn.ComplexList {
        internalValue?: EksPropertiesPodPropertiesInitContainersEnvProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EksPropertiesPodPropertiesInitContainersEnvPropertyOutputReference;
    }
    interface EksPropertiesPodPropertiesInitContainersResourcesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_definition#limits AwsJobDefinition#limits}
        */
        readonly limits?: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_definition#requests AwsJobDefinition#requests}
        */
        readonly requests?: {
            [key: string]: string;
        };
    }
    class EksPropertiesPodPropertiesInitContainersResourcesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): EksPropertiesPodPropertiesInitContainersResourcesProperty | undefined;
        set internalValue(value: EksPropertiesPodPropertiesInitContainersResourcesProperty | undefined);
        private _limits?;
        get limits(): {
            [key: string]: string;
        };
        set limits(value: {
            [key: string]: string;
        });
        resetLimits(): void;
        get limitsInput(): {
            [key: string]: string;
        } | undefined;
        private _requests?;
        get requests(): {
            [key: string]: string;
        };
        set requests(value: {
            [key: string]: string;
        });
        resetRequests(): void;
        get requestsInput(): {
            [key: string]: string;
        } | undefined;
    }
    interface EksPropertiesPodPropertiesInitContainersSecurityContextProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_definition#allow_privilege_escalation AwsJobDefinition#allow_privilege_escalation}
        */
        readonly allowPrivilegeEscalation?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_definition#privileged AwsJobDefinition#privileged}
        */
        readonly privileged?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_definition#read_only_root_file_system AwsJobDefinition#read_only_root_file_system}
        */
        readonly readOnlyRootFileSystem?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_definition#run_as_group AwsJobDefinition#run_as_group}
        */
        readonly runAsGroup?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_definition#run_as_non_root AwsJobDefinition#run_as_non_root}
        */
        readonly runAsNonRoot?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_definition#run_as_user AwsJobDefinition#run_as_user}
        */
        readonly runAsUser?: number;
    }
    class EksPropertiesPodPropertiesInitContainersSecurityContextPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): EksPropertiesPodPropertiesInitContainersSecurityContextProperty | undefined;
        set internalValue(value: EksPropertiesPodPropertiesInitContainersSecurityContextProperty | undefined);
        private _allowPrivilegeEscalation?;
        get allowPrivilegeEscalation(): boolean | cdktn.IResolvable;
        set allowPrivilegeEscalation(value: boolean | cdktn.IResolvable);
        resetAllowPrivilegeEscalation(): void;
        get allowPrivilegeEscalationInput(): boolean | cdktn.IResolvable | undefined;
        private _privileged?;
        get privileged(): boolean | cdktn.IResolvable;
        set privileged(value: boolean | cdktn.IResolvable);
        resetPrivileged(): void;
        get privilegedInput(): boolean | cdktn.IResolvable | undefined;
        private _readOnlyRootFileSystem?;
        get readOnlyRootFileSystem(): boolean | cdktn.IResolvable;
        set readOnlyRootFileSystem(value: boolean | cdktn.IResolvable);
        resetReadOnlyRootFileSystem(): void;
        get readOnlyRootFileSystemInput(): boolean | cdktn.IResolvable | undefined;
        private _runAsGroup?;
        get runAsGroup(): number;
        set runAsGroup(value: number);
        resetRunAsGroup(): void;
        get runAsGroupInput(): number | undefined;
        private _runAsNonRoot?;
        get runAsNonRoot(): boolean | cdktn.IResolvable;
        set runAsNonRoot(value: boolean | cdktn.IResolvable);
        resetRunAsNonRoot(): void;
        get runAsNonRootInput(): boolean | cdktn.IResolvable | undefined;
        private _runAsUser?;
        get runAsUser(): number;
        set runAsUser(value: number);
        resetRunAsUser(): void;
        get runAsUserInput(): number | undefined;
    }
    interface EksPropertiesPodPropertiesInitContainersVolumeMountsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_definition#mount_path AwsJobDefinition#mount_path}
        */
        readonly mountPath: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_definition#name AwsJobDefinition#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_definition#read_only AwsJobDefinition#read_only}
        */
        readonly readOnly?: boolean | cdktn.IResolvable;
    }
    class EksPropertiesPodPropertiesInitContainersVolumeMountsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EksPropertiesPodPropertiesInitContainersVolumeMountsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: EksPropertiesPodPropertiesInitContainersVolumeMountsProperty | cdktn.IResolvable | undefined);
        private _mountPath?;
        get mountPath(): string;
        set mountPath(value: string);
        get mountPathInput(): string | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _readOnly?;
        get readOnly(): boolean | cdktn.IResolvable;
        set readOnly(value: boolean | cdktn.IResolvable);
        resetReadOnly(): void;
        get readOnlyInput(): boolean | cdktn.IResolvable | undefined;
    }
    class EksPropertiesPodPropertiesInitContainersVolumeMountsPropertyList extends cdktn.ComplexList {
        internalValue?: EksPropertiesPodPropertiesInitContainersVolumeMountsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EksPropertiesPodPropertiesInitContainersVolumeMountsPropertyOutputReference;
    }
    interface InitContainersProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_definition#args AwsJobDefinition#args}
        */
        readonly args?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_definition#command AwsJobDefinition#command}
        */
        readonly command?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_definition#image AwsJobDefinition#image}
        */
        readonly image: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_definition#image_pull_policy AwsJobDefinition#image_pull_policy}
        */
        readonly imagePullPolicy?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_definition#name AwsJobDefinition#name}
        */
        readonly name?: string;
        /**
        * env block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_definition#env AwsJobDefinition#env}
        */
        readonly env?: EksPropertiesPodPropertiesInitContainersEnvProperty[] | cdktn.IResolvable;
        /**
        * resources block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_definition#resources AwsJobDefinition#resources}
        */
        readonly resources?: EksPropertiesPodPropertiesInitContainersResourcesProperty;
        /**
        * security_context block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_definition#security_context AwsJobDefinition#security_context}
        */
        readonly securityContext?: EksPropertiesPodPropertiesInitContainersSecurityContextProperty;
        /**
        * volume_mounts block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_definition#volume_mounts AwsJobDefinition#volume_mounts}
        */
        readonly volumeMounts?: EksPropertiesPodPropertiesInitContainersVolumeMountsProperty[] | cdktn.IResolvable;
    }
    class InitContainersPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): InitContainersProperty | cdktn.IResolvable | undefined;
        set internalValue(value: InitContainersProperty | cdktn.IResolvable | undefined);
        private _args?;
        get args(): string[];
        set args(value: string[]);
        resetArgs(): void;
        get argsInput(): string[] | undefined;
        private _command?;
        get command(): string[];
        set command(value: string[]);
        resetCommand(): void;
        get commandInput(): string[] | undefined;
        private _image?;
        get image(): string;
        set image(value: string);
        get imageInput(): string | undefined;
        private _imagePullPolicy?;
        get imagePullPolicy(): string;
        set imagePullPolicy(value: string);
        resetImagePullPolicy(): void;
        get imagePullPolicyInput(): string | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        resetName(): void;
        get nameInput(): string | undefined;
        private _env;
        get env(): EksPropertiesPodPropertiesInitContainersEnvPropertyList;
        putEnv(value: EksPropertiesPodPropertiesInitContainersEnvProperty[] | cdktn.IResolvable): void;
        resetEnv(): void;
        get envInput(): cdktn.IResolvable | EksPropertiesPodPropertiesInitContainersEnvProperty[] | undefined;
        private _resources;
        get resources(): EksPropertiesPodPropertiesInitContainersResourcesPropertyOutputReference;
        putResources(value: EksPropertiesPodPropertiesInitContainersResourcesProperty): void;
        resetResources(): void;
        get resourcesInput(): EksPropertiesPodPropertiesInitContainersResourcesProperty | undefined;
        private _securityContext;
        get securityContext(): EksPropertiesPodPropertiesInitContainersSecurityContextPropertyOutputReference;
        putSecurityContext(value: EksPropertiesPodPropertiesInitContainersSecurityContextProperty): void;
        resetSecurityContext(): void;
        get securityContextInput(): EksPropertiesPodPropertiesInitContainersSecurityContextProperty | undefined;
        private _volumeMounts;
        get volumeMounts(): EksPropertiesPodPropertiesInitContainersVolumeMountsPropertyList;
        putVolumeMounts(value: EksPropertiesPodPropertiesInitContainersVolumeMountsProperty[] | cdktn.IResolvable): void;
        resetVolumeMounts(): void;
        get volumeMountsInput(): cdktn.IResolvable | EksPropertiesPodPropertiesInitContainersVolumeMountsProperty[] | undefined;
    }
    class InitContainersPropertyList extends cdktn.ComplexList {
        internalValue?: InitContainersProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): InitContainersPropertyOutputReference;
    }
    interface MetadataProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_definition#labels AwsJobDefinition#labels}
        */
        readonly labels?: {
            [key: string]: string;
        };
    }
    class MetadataPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): MetadataProperty | undefined;
        set internalValue(value: MetadataProperty | undefined);
        private _labels?;
        get labels(): {
            [key: string]: string;
        };
        set labels(value: {
            [key: string]: string;
        });
        resetLabels(): void;
        get labelsInput(): {
            [key: string]: string;
        } | undefined;
    }
    interface EmptyDirProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_definition#medium AwsJobDefinition#medium}
        */
        readonly medium?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_definition#size_limit AwsJobDefinition#size_limit}
        */
        readonly sizeLimit: string;
    }
    class EmptyDirPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): EmptyDirProperty | undefined;
        set internalValue(value: EmptyDirProperty | undefined);
        private _medium?;
        get medium(): string;
        set medium(value: string);
        resetMedium(): void;
        get mediumInput(): string | undefined;
        private _sizeLimit?;
        get sizeLimit(): string;
        set sizeLimit(value: string);
        get sizeLimitInput(): string | undefined;
    }
    interface HostPathProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_definition#path AwsJobDefinition#path}
        */
        readonly path: string;
    }
    class HostPathPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): HostPathProperty | undefined;
        set internalValue(value: HostPathProperty | undefined);
        private _path?;
        get path(): string;
        set path(value: string);
        get pathInput(): string | undefined;
    }
    interface SecretProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_definition#optional AwsJobDefinition#optional}
        */
        readonly optional?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_definition#secret_name AwsJobDefinition#secret_name}
        */
        readonly secretName: string;
    }
    class SecretPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SecretProperty | undefined;
        set internalValue(value: SecretProperty | undefined);
        private _optional?;
        get optional(): boolean | cdktn.IResolvable;
        set optional(value: boolean | cdktn.IResolvable);
        resetOptional(): void;
        get optionalInput(): boolean | cdktn.IResolvable | undefined;
        private _secretName?;
        get secretName(): string;
        set secretName(value: string);
        get secretNameInput(): string | undefined;
    }
    interface VolumesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_definition#name AwsJobDefinition#name}
        */
        readonly name?: string;
        /**
        * empty_dir block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_definition#empty_dir AwsJobDefinition#empty_dir}
        */
        readonly emptyDir?: EmptyDirProperty;
        /**
        * host_path block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_definition#host_path AwsJobDefinition#host_path}
        */
        readonly hostPath?: HostPathProperty;
        /**
        * secret block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_definition#secret AwsJobDefinition#secret}
        */
        readonly secret?: SecretProperty;
    }
    class VolumesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): VolumesProperty | cdktn.IResolvable | undefined;
        set internalValue(value: VolumesProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        resetName(): void;
        get nameInput(): string | undefined;
        private _emptyDir;
        get emptyDir(): EmptyDirPropertyOutputReference;
        putEmptyDir(value: EmptyDirProperty): void;
        resetEmptyDir(): void;
        get emptyDirInput(): EmptyDirProperty | undefined;
        private _hostPath;
        get hostPath(): HostPathPropertyOutputReference;
        putHostPath(value: HostPathProperty): void;
        resetHostPath(): void;
        get hostPathInput(): HostPathProperty | undefined;
        private _secret;
        get secret(): SecretPropertyOutputReference;
        putSecret(value: SecretProperty): void;
        resetSecret(): void;
        get secretInput(): SecretProperty | undefined;
    }
    class VolumesPropertyList extends cdktn.ComplexList {
        internalValue?: VolumesProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): VolumesPropertyOutputReference;
    }
    interface PodPropertiesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_definition#dns_policy AwsJobDefinition#dns_policy}
        */
        readonly dnsPolicy?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_definition#host_network AwsJobDefinition#host_network}
        */
        readonly hostNetwork?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_definition#service_account_name AwsJobDefinition#service_account_name}
        */
        readonly serviceAccountName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_definition#share_process_namespace AwsJobDefinition#share_process_namespace}
        */
        readonly shareProcessNamespace?: boolean | cdktn.IResolvable;
        /**
        * containers block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_definition#containers AwsJobDefinition#containers}
        */
        readonly containers: ContainersProperty[] | cdktn.IResolvable;
        /**
        * image_pull_secret block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_definition#image_pull_secret AwsJobDefinition#image_pull_secret}
        */
        readonly imagePullSecret?: ImagePullSecretProperty[] | cdktn.IResolvable;
        /**
        * init_containers block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_definition#init_containers AwsJobDefinition#init_containers}
        */
        readonly initContainers?: InitContainersProperty[] | cdktn.IResolvable;
        /**
        * metadata block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_definition#metadata AwsJobDefinition#metadata}
        */
        readonly metadata?: MetadataProperty;
        /**
        * volumes block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_definition#volumes AwsJobDefinition#volumes}
        */
        readonly volumes?: VolumesProperty[] | cdktn.IResolvable;
    }
    class PodPropertiesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): PodPropertiesProperty | undefined;
        set internalValue(value: PodPropertiesProperty | undefined);
        private _dnsPolicy?;
        get dnsPolicy(): string;
        set dnsPolicy(value: string);
        resetDnsPolicy(): void;
        get dnsPolicyInput(): string | undefined;
        private _hostNetwork?;
        get hostNetwork(): boolean | cdktn.IResolvable;
        set hostNetwork(value: boolean | cdktn.IResolvable);
        resetHostNetwork(): void;
        get hostNetworkInput(): boolean | cdktn.IResolvable | undefined;
        private _serviceAccountName?;
        get serviceAccountName(): string;
        set serviceAccountName(value: string);
        resetServiceAccountName(): void;
        get serviceAccountNameInput(): string | undefined;
        private _shareProcessNamespace?;
        get shareProcessNamespace(): boolean | cdktn.IResolvable;
        set shareProcessNamespace(value: boolean | cdktn.IResolvable);
        resetShareProcessNamespace(): void;
        get shareProcessNamespaceInput(): boolean | cdktn.IResolvable | undefined;
        private _containers;
        get containers(): ContainersPropertyList;
        putContainers(value: ContainersProperty[] | cdktn.IResolvable): void;
        get containersInput(): cdktn.IResolvable | ContainersProperty[] | undefined;
        private _imagePullSecret;
        get imagePullSecret(): ImagePullSecretPropertyList;
        putImagePullSecret(value: ImagePullSecretProperty[] | cdktn.IResolvable): void;
        resetImagePullSecret(): void;
        get imagePullSecretInput(): cdktn.IResolvable | ImagePullSecretProperty[] | undefined;
        private _initContainers;
        get initContainers(): InitContainersPropertyList;
        putInitContainers(value: InitContainersProperty[] | cdktn.IResolvable): void;
        resetInitContainers(): void;
        get initContainersInput(): cdktn.IResolvable | InitContainersProperty[] | undefined;
        private _metadata;
        get metadata(): MetadataPropertyOutputReference;
        putMetadata(value: MetadataProperty): void;
        resetMetadata(): void;
        get metadataInput(): MetadataProperty | undefined;
        private _volumes;
        get volumes(): VolumesPropertyList;
        putVolumes(value: VolumesProperty[] | cdktn.IResolvable): void;
        resetVolumes(): void;
        get volumesInput(): cdktn.IResolvable | VolumesProperty[] | undefined;
    }
    interface EksPropertiesProperty {
        /**
        * pod_properties block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_definition#pod_properties AwsJobDefinition#pod_properties}
        */
        readonly podProperties: PodPropertiesProperty;
    }
    class EksPropertiesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): EksPropertiesProperty | undefined;
        set internalValue(value: EksPropertiesProperty | undefined);
        private _podProperties;
        get podProperties(): PodPropertiesPropertyOutputReference;
        putPodProperties(value: PodPropertiesProperty): void;
        get podPropertiesInput(): PodPropertiesProperty | undefined;
    }
    interface EvaluateOnExitProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_definition#action AwsJobDefinition#action}
        */
        readonly action: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_definition#on_exit_code AwsJobDefinition#on_exit_code}
        */
        readonly onExitCode?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_definition#on_reason AwsJobDefinition#on_reason}
        */
        readonly onReason?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_definition#on_status_reason AwsJobDefinition#on_status_reason}
        */
        readonly onStatusReason?: string;
    }
    class EvaluateOnExitPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EvaluateOnExitProperty | cdktn.IResolvable | undefined;
        set internalValue(value: EvaluateOnExitProperty | cdktn.IResolvable | undefined);
        private _action?;
        get action(): string;
        set action(value: string);
        get actionInput(): string | undefined;
        private _onExitCode?;
        get onExitCode(): string;
        set onExitCode(value: string);
        resetOnExitCode(): void;
        get onExitCodeInput(): string | undefined;
        private _onReason?;
        get onReason(): string;
        set onReason(value: string);
        resetOnReason(): void;
        get onReasonInput(): string | undefined;
        private _onStatusReason?;
        get onStatusReason(): string;
        set onStatusReason(value: string);
        resetOnStatusReason(): void;
        get onStatusReasonInput(): string | undefined;
    }
    class EvaluateOnExitPropertyList extends cdktn.ComplexList {
        internalValue?: EvaluateOnExitProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EvaluateOnExitPropertyOutputReference;
    }
    interface RetryStrategyProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_definition#attempts AwsJobDefinition#attempts}
        */
        readonly attempts?: number;
        /**
        * evaluate_on_exit block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_definition#evaluate_on_exit AwsJobDefinition#evaluate_on_exit}
        */
        readonly evaluateOnExit?: EvaluateOnExitProperty[] | cdktn.IResolvable;
    }
    class RetryStrategyPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RetryStrategyProperty | undefined;
        set internalValue(value: RetryStrategyProperty | undefined);
        private _attempts?;
        get attempts(): number;
        set attempts(value: number);
        resetAttempts(): void;
        get attemptsInput(): number | undefined;
        private _evaluateOnExit;
        get evaluateOnExit(): EvaluateOnExitPropertyList;
        putEvaluateOnExit(value: EvaluateOnExitProperty[] | cdktn.IResolvable): void;
        resetEvaluateOnExit(): void;
        get evaluateOnExitInput(): cdktn.IResolvable | EvaluateOnExitProperty[] | undefined;
    }
    interface TimeoutProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_job_definition#attempt_duration_seconds AwsJobDefinition#attempt_duration_seconds}
        */
        readonly attemptDurationSeconds?: number;
    }
    class TimeoutPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutProperty | undefined;
        set internalValue(value: TimeoutProperty | undefined);
        private _attemptDurationSeconds?;
        get attemptDurationSeconds(): number;
        set attemptDurationSeconds(value: number);
        resetAttemptDurationSeconds(): void;
        get attemptDurationSecondsInput(): number | undefined;
    }
}
