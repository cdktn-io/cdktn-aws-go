import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsSchedulingPolicyConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/batch_scheduling_policy#arn DataAwsSchedulingPolicy#arn}
    */
    readonly arn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/batch_scheduling_policy#id DataAwsSchedulingPolicy#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/batch_scheduling_policy#region DataAwsSchedulingPolicy#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/batch_scheduling_policy#tags DataAwsSchedulingPolicy#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/batch_scheduling_policy aws_batch_scheduling_policy}
*/
export declare class DataAwsSchedulingPolicy extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_batch_scheduling_policy";
    /**
    * Generates CDKTN code for importing a DataAwsSchedulingPolicy resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsSchedulingPolicy to import
    * @param importFromId The id of the existing DataAwsSchedulingPolicy that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/batch_scheduling_policy#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsSchedulingPolicy to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/batch_scheduling_policy aws_batch_scheduling_policy} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsSchedulingPolicyConfig
    */
    constructor(scope: Construct, id: string, config: DataAwsSchedulingPolicyConfig);
    private _arn?;
    get arn(): string;
    set arn(value: string);
    get arnInput(): string | undefined;
    private _fairSharePolicy;
    get fairSharePolicy(): DataAwsSchedulingPolicy.FairSharePolicyPropertyList;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get name(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataAwsSchedulingPolicyShareDistributionPropertyToTerraform(struct?: DataAwsSchedulingPolicy.ShareDistributionProperty): any;
export declare function dataAwsSchedulingPolicyShareDistributionPropertyToHclTerraform(struct?: DataAwsSchedulingPolicy.ShareDistributionProperty): any;
export declare function dataAwsSchedulingPolicyFairSharePolicyPropertyToTerraform(struct?: DataAwsSchedulingPolicy.FairSharePolicyProperty): any;
export declare function dataAwsSchedulingPolicyFairSharePolicyPropertyToHclTerraform(struct?: DataAwsSchedulingPolicy.FairSharePolicyProperty): any;
export declare namespace DataAwsSchedulingPolicy {
    interface ShareDistributionProperty {
    }
    class ShareDistributionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ShareDistributionProperty | undefined;
        set internalValue(value: ShareDistributionProperty | undefined);
        get shareIdentifier(): string;
        get weightFactor(): number;
    }
    class ShareDistributionPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ShareDistributionPropertyOutputReference;
    }
    interface FairSharePolicyProperty {
    }
    class FairSharePolicyPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): FairSharePolicyProperty | undefined;
        set internalValue(value: FairSharePolicyProperty | undefined);
        get computeReservation(): number;
        get shareDecaySeconds(): number;
        private _shareDistribution;
        get shareDistribution(): ShareDistributionPropertyList;
    }
    class FairSharePolicyPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): FairSharePolicyPropertyOutputReference;
    }
}
