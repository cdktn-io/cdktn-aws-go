import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsSchedulingPolicyConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_scheduling_policy#id AwsSchedulingPolicy#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_scheduling_policy#name AwsSchedulingPolicy#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_scheduling_policy#region AwsSchedulingPolicy#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_scheduling_policy#tags AwsSchedulingPolicy#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_scheduling_policy#tags_all AwsSchedulingPolicy#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * fair_share_policy block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_scheduling_policy#fair_share_policy AwsSchedulingPolicy#fair_share_policy}
    */
    readonly fairSharePolicy?: AwsSchedulingPolicy.FairSharePolicyProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_scheduling_policy aws_batch_scheduling_policy}
*/
export declare class AwsSchedulingPolicy extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_batch_scheduling_policy";
    /**
    * Generates CDKTN code for importing a AwsSchedulingPolicy resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsSchedulingPolicy to import
    * @param importFromId The id of the existing AwsSchedulingPolicy that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_scheduling_policy#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsSchedulingPolicy to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_scheduling_policy aws_batch_scheduling_policy} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsSchedulingPolicyConfig
    */
    constructor(scope: Construct, id: string, config: AwsSchedulingPolicyConfig);
    get arn(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _fairSharePolicy;
    get fairSharePolicy(): AwsSchedulingPolicy.FairSharePolicyPropertyOutputReference;
    putFairSharePolicy(value: AwsSchedulingPolicy.FairSharePolicyProperty): void;
    resetFairSharePolicy(): void;
    get fairSharePolicyInput(): AwsSchedulingPolicy.FairSharePolicyProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsSchedulingPolicyShareDistributionPropertyToTerraform(struct?: AwsSchedulingPolicy.ShareDistributionProperty | cdktn.IResolvable): any;
export declare function awsSchedulingPolicyShareDistributionPropertyToHclTerraform(struct?: AwsSchedulingPolicy.ShareDistributionProperty | cdktn.IResolvable): any;
export declare function awsSchedulingPolicyFairSharePolicyPropertyToTerraform(struct?: AwsSchedulingPolicy.FairSharePolicyPropertyOutputReference | AwsSchedulingPolicy.FairSharePolicyProperty): any;
export declare function awsSchedulingPolicyFairSharePolicyPropertyToHclTerraform(struct?: AwsSchedulingPolicy.FairSharePolicyPropertyOutputReference | AwsSchedulingPolicy.FairSharePolicyProperty): any;
export declare namespace AwsSchedulingPolicy {
    interface ShareDistributionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_scheduling_policy#share_identifier AwsSchedulingPolicy#share_identifier}
        */
        readonly shareIdentifier: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_scheduling_policy#weight_factor AwsSchedulingPolicy#weight_factor}
        */
        readonly weightFactor?: number;
    }
    class ShareDistributionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ShareDistributionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ShareDistributionProperty | cdktn.IResolvable | undefined);
        private _shareIdentifier?;
        get shareIdentifier(): string;
        set shareIdentifier(value: string);
        get shareIdentifierInput(): string | undefined;
        private _weightFactor?;
        get weightFactor(): number;
        set weightFactor(value: number);
        resetWeightFactor(): void;
        get weightFactorInput(): number | undefined;
    }
    class ShareDistributionPropertyList extends cdktn.ComplexList {
        internalValue?: ShareDistributionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ShareDistributionPropertyOutputReference;
    }
    interface FairSharePolicyProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_scheduling_policy#compute_reservation AwsSchedulingPolicy#compute_reservation}
        */
        readonly computeReservation?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_scheduling_policy#share_decay_seconds AwsSchedulingPolicy#share_decay_seconds}
        */
        readonly shareDecaySeconds?: number;
        /**
        * share_distribution block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/batch_scheduling_policy#share_distribution AwsSchedulingPolicy#share_distribution}
        */
        readonly shareDistribution?: ShareDistributionProperty[] | cdktn.IResolvable;
    }
    class FairSharePolicyPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): FairSharePolicyProperty | undefined;
        set internalValue(value: FairSharePolicyProperty | undefined);
        private _computeReservation?;
        get computeReservation(): number;
        set computeReservation(value: number);
        resetComputeReservation(): void;
        get computeReservationInput(): number | undefined;
        private _shareDecaySeconds?;
        get shareDecaySeconds(): number;
        set shareDecaySeconds(value: number);
        resetShareDecaySeconds(): void;
        get shareDecaySecondsInput(): number | undefined;
        private _shareDistribution;
        get shareDistribution(): ShareDistributionPropertyList;
        putShareDistribution(value: ShareDistributionProperty[] | cdktn.IResolvable): void;
        resetShareDistribution(): void;
        get shareDistributionInput(): cdktn.IResolvable | ShareDistributionProperty[] | undefined;
    }
}
