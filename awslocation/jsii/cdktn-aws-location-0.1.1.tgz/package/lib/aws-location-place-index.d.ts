import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsLocationPlaceIndexConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/location_place_index#data_source AwsLocationPlaceIndex#data_source}
    */
    readonly dataSource: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/location_place_index#description AwsLocationPlaceIndex#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/location_place_index#id AwsLocationPlaceIndex#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/location_place_index#index_name AwsLocationPlaceIndex#index_name}
    */
    readonly indexName: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/location_place_index#region AwsLocationPlaceIndex#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/location_place_index#tags AwsLocationPlaceIndex#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/location_place_index#tags_all AwsLocationPlaceIndex#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * data_source_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/location_place_index#data_source_configuration AwsLocationPlaceIndex#data_source_configuration}
    */
    readonly dataSourceConfiguration?: AwsLocationPlaceIndex.DataSourceConfigurationProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/location_place_index aws_location_place_index}
*/
export declare class AwsLocationPlaceIndex extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_location_place_index";
    /**
    * Generates CDKTN code for importing a AwsLocationPlaceIndex resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsLocationPlaceIndex to import
    * @param importFromId The id of the existing AwsLocationPlaceIndex that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/location_place_index#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsLocationPlaceIndex to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/location_place_index aws_location_place_index} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsLocationPlaceIndexConfig
    */
    constructor(scope: Construct, id: string, config: AwsLocationPlaceIndexConfig);
    get createTime(): string;
    private _dataSource?;
    get dataSource(): string;
    set dataSource(value: string);
    get dataSourceInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get indexArn(): string;
    private _indexName?;
    get indexName(): string;
    set indexName(value: string);
    get indexNameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    get updateTime(): string;
    private _dataSourceConfiguration;
    get dataSourceConfiguration(): AwsLocationPlaceIndex.DataSourceConfigurationPropertyOutputReference;
    putDataSourceConfiguration(value: AwsLocationPlaceIndex.DataSourceConfigurationProperty): void;
    resetDataSourceConfiguration(): void;
    get dataSourceConfigurationInput(): AwsLocationPlaceIndex.DataSourceConfigurationProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsLocationPlaceIndexDataSourceConfigurationPropertyToTerraform(struct?: AwsLocationPlaceIndex.DataSourceConfigurationPropertyOutputReference | AwsLocationPlaceIndex.DataSourceConfigurationProperty): any;
export declare function awsLocationPlaceIndexDataSourceConfigurationPropertyToHclTerraform(struct?: AwsLocationPlaceIndex.DataSourceConfigurationPropertyOutputReference | AwsLocationPlaceIndex.DataSourceConfigurationProperty): any;
export declare namespace AwsLocationPlaceIndex {
    interface DataSourceConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/location_place_index#intended_use AwsLocationPlaceIndex#intended_use}
        */
        readonly intendedUse?: string;
    }
    class DataSourceConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DataSourceConfigurationProperty | undefined;
        set internalValue(value: DataSourceConfigurationProperty | undefined);
        private _intendedUse?;
        get intendedUse(): string;
        set intendedUse(value: string);
        resetIntendedUse(): void;
        get intendedUseInput(): string | undefined;
    }
}
