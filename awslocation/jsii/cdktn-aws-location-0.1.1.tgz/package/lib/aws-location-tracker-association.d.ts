import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsLocationTrackerAssociationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/location_tracker_association#consumer_arn AwsLocationTrackerAssociation#consumer_arn}
    */
    readonly consumerArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/location_tracker_association#id AwsLocationTrackerAssociation#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/location_tracker_association#region AwsLocationTrackerAssociation#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/location_tracker_association#tracker_name AwsLocationTrackerAssociation#tracker_name}
    */
    readonly trackerName: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/location_tracker_association#timeouts AwsLocationTrackerAssociation#timeouts}
    */
    readonly timeouts?: AwsLocationTrackerAssociation.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/location_tracker_association aws_location_tracker_association}
*/
export declare class AwsLocationTrackerAssociation extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_location_tracker_association";
    /**
    * Generates CDKTN code for importing a AwsLocationTrackerAssociation resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsLocationTrackerAssociation to import
    * @param importFromId The id of the existing AwsLocationTrackerAssociation that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/location_tracker_association#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsLocationTrackerAssociation to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/location_tracker_association aws_location_tracker_association} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsLocationTrackerAssociationConfig
    */
    constructor(scope: Construct, id: string, config: AwsLocationTrackerAssociationConfig);
    private _consumerArn?;
    get consumerArn(): string;
    set consumerArn(value: string);
    get consumerArnInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _trackerName?;
    get trackerName(): string;
    set trackerName(value: string);
    get trackerNameInput(): string | undefined;
    private _timeouts;
    get timeouts(): AwsLocationTrackerAssociation.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsLocationTrackerAssociation.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsLocationTrackerAssociation.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsLocationTrackerAssociationTimeoutsPropertyToTerraform(struct?: AwsLocationTrackerAssociation.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsLocationTrackerAssociationTimeoutsPropertyToHclTerraform(struct?: AwsLocationTrackerAssociation.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsLocationTrackerAssociation {
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/location_tracker_association#create AwsLocationTrackerAssociation#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/location_tracker_association#delete AwsLocationTrackerAssociation#delete}
        */
        readonly delete?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
    }
}
