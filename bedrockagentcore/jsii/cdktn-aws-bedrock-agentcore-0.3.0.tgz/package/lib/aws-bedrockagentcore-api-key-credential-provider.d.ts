import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsApiKeyCredentialProviderConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_api_key_credential_provider#api_key AwsApiKeyCredentialProvider#api_key}
    */
    readonly apiKey?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_api_key_credential_provider#api_key_wo AwsApiKeyCredentialProvider#api_key_wo}
    */
    readonly apiKeyWo?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_api_key_credential_provider#api_key_wo_version AwsApiKeyCredentialProvider#api_key_wo_version}
    */
    readonly apiKeyWoVersion?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_api_key_credential_provider#name AwsApiKeyCredentialProvider#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_api_key_credential_provider#region AwsApiKeyCredentialProvider#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_api_key_credential_provider#tags AwsApiKeyCredentialProvider#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_api_key_credential_provider aws_bedrockagentcore_api_key_credential_provider}
*/
export declare class AwsApiKeyCredentialProvider extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_bedrockagentcore_api_key_credential_provider";
    /**
    * Generates CDKTN code for importing a AwsApiKeyCredentialProvider resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsApiKeyCredentialProvider to import
    * @param importFromId The id of the existing AwsApiKeyCredentialProvider that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_api_key_credential_provider#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsApiKeyCredentialProvider to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_api_key_credential_provider aws_bedrockagentcore_api_key_credential_provider} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsApiKeyCredentialProviderConfig
    */
    constructor(scope: Construct, id: string, config: AwsApiKeyCredentialProviderConfig);
    private _apiKey?;
    get apiKey(): string;
    set apiKey(value: string);
    resetApiKey(): void;
    get apiKeyInput(): string | undefined;
    private _apiKeySecretArn;
    get apiKeySecretArn(): AwsApiKeyCredentialProvider.ApiKeySecretArnPropertyList;
    private _apiKeyWo?;
    /**
    * @deprecated Write-only: the provider never returns this value; reading it always yields null by protocol contract. The getter remains for compatibility and will be removed in a future prebuilt-provider major.
    */
    get apiKeyWo(): string;
    set apiKeyWo(value: string);
    resetApiKeyWo(): void;
    get apiKeyWoInput(): string | undefined;
    private _apiKeyWoVersion?;
    get apiKeyWoVersion(): number;
    set apiKeyWoVersion(value: number);
    resetApiKeyWoVersion(): void;
    get apiKeyWoVersionInput(): number | undefined;
    get credentialProviderArn(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsApiKeyCredentialProviderApiKeySecretArnPropertyToTerraform(struct?: AwsApiKeyCredentialProvider.ApiKeySecretArnProperty): any;
export declare function awsApiKeyCredentialProviderApiKeySecretArnPropertyToHclTerraform(struct?: AwsApiKeyCredentialProvider.ApiKeySecretArnProperty): any;
export declare namespace AwsApiKeyCredentialProvider {
    interface ApiKeySecretArnProperty {
    }
    class ApiKeySecretArnPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ApiKeySecretArnProperty | undefined;
        set internalValue(value: ApiKeySecretArnProperty | undefined);
        get secretArn(): string;
    }
    class ApiKeySecretArnPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ApiKeySecretArnPropertyOutputReference;
    }
}
