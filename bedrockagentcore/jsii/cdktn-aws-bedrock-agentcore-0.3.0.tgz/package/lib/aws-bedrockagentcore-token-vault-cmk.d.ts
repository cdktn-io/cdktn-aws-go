import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsTokenVaultCmkConfig extends cdktn.TerraformMetaArguments {
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_token_vault_cmk#region AwsTokenVaultCmk#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_token_vault_cmk#token_vault_id AwsTokenVaultCmk#token_vault_id}
    */
    readonly tokenVaultId?: string;
    /**
    * kms_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_token_vault_cmk#kms_configuration AwsTokenVaultCmk#kms_configuration}
    */
    readonly kmsConfiguration?: AwsTokenVaultCmk.KmsConfigurationProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_token_vault_cmk aws_bedrockagentcore_token_vault_cmk}
*/
export declare class AwsTokenVaultCmk extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_bedrockagentcore_token_vault_cmk";
    /**
    * Generates CDKTN code for importing a AwsTokenVaultCmk resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsTokenVaultCmk to import
    * @param importFromId The id of the existing AwsTokenVaultCmk that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_token_vault_cmk#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsTokenVaultCmk to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_token_vault_cmk aws_bedrockagentcore_token_vault_cmk} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsTokenVaultCmkConfig = {}
    */
    constructor(scope: Construct, id: string, config?: AwsTokenVaultCmkConfig);
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tokenVaultId?;
    get tokenVaultId(): string;
    set tokenVaultId(value: string);
    resetTokenVaultId(): void;
    get tokenVaultIdInput(): string | undefined;
    private _kmsConfiguration;
    get kmsConfiguration(): AwsTokenVaultCmk.KmsConfigurationPropertyList;
    putKmsConfiguration(value: AwsTokenVaultCmk.KmsConfigurationProperty[] | cdktn.IResolvable): void;
    resetKmsConfiguration(): void;
    get kmsConfigurationInput(): cdktn.IResolvable | AwsTokenVaultCmk.KmsConfigurationProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsTokenVaultCmkKmsConfigurationPropertyToTerraform(struct?: AwsTokenVaultCmk.KmsConfigurationProperty | cdktn.IResolvable): any;
export declare function awsTokenVaultCmkKmsConfigurationPropertyToHclTerraform(struct?: AwsTokenVaultCmk.KmsConfigurationProperty | cdktn.IResolvable): any;
export declare namespace AwsTokenVaultCmk {
    interface KmsConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_token_vault_cmk#key_type AwsTokenVaultCmk#key_type}
        */
        readonly keyType: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_token_vault_cmk#kms_key_arn AwsTokenVaultCmk#kms_key_arn}
        */
        readonly kmsKeyArn?: string;
    }
    class KmsConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): KmsConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: KmsConfigurationProperty | cdktn.IResolvable | undefined);
        private _keyType?;
        get keyType(): string;
        set keyType(value: string);
        get keyTypeInput(): string | undefined;
        private _kmsKeyArn?;
        get kmsKeyArn(): string;
        set kmsKeyArn(value: string);
        resetKmsKeyArn(): void;
        get kmsKeyArnInput(): string | undefined;
    }
    class KmsConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: KmsConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): KmsConfigurationPropertyOutputReference;
    }
}
