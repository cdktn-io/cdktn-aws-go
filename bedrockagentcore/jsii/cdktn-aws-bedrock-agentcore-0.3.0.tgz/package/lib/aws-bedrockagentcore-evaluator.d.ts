import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsEvaluatorConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_evaluator#description AwsEvaluator#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_evaluator#evaluator_name AwsEvaluator#evaluator_name}
    */
    readonly evaluatorName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_evaluator#kms_key_arn AwsEvaluator#kms_key_arn}
    */
    readonly kmsKeyArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_evaluator#level AwsEvaluator#level}
    */
    readonly level: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_evaluator#region AwsEvaluator#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_evaluator#tags AwsEvaluator#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * evaluator_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_evaluator#evaluator_config AwsEvaluator#evaluator_config}
    */
    readonly evaluatorConfig?: AwsEvaluator.EvaluatorConfigProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_evaluator#timeouts AwsEvaluator#timeouts}
    */
    readonly timeouts?: AwsEvaluator.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_evaluator aws_bedrockagentcore_evaluator}
*/
export declare class AwsEvaluator extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_bedrockagentcore_evaluator";
    /**
    * Generates CDKTN code for importing a AwsEvaluator resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsEvaluator to import
    * @param importFromId The id of the existing AwsEvaluator that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_evaluator#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsEvaluator to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_evaluator aws_bedrockagentcore_evaluator} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsEvaluatorConfig
    */
    constructor(scope: Construct, id: string, config: AwsEvaluatorConfig);
    get createdAt(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get evaluatorArn(): string;
    get evaluatorId(): string;
    private _evaluatorName?;
    get evaluatorName(): string;
    set evaluatorName(value: string);
    get evaluatorNameInput(): string | undefined;
    private _kmsKeyArn?;
    get kmsKeyArn(): string;
    set kmsKeyArn(value: string);
    resetKmsKeyArn(): void;
    get kmsKeyArnInput(): string | undefined;
    private _level?;
    get level(): string;
    set level(value: string);
    get levelInput(): string | undefined;
    get lockedForModification(): cdktn.IResolvable;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get status(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    private _evaluatorConfig;
    get evaluatorConfig(): AwsEvaluator.EvaluatorConfigPropertyList;
    putEvaluatorConfig(value: AwsEvaluator.EvaluatorConfigProperty[] | cdktn.IResolvable): void;
    resetEvaluatorConfig(): void;
    get evaluatorConfigInput(): cdktn.IResolvable | AwsEvaluator.EvaluatorConfigProperty[] | undefined;
    private _timeouts;
    get timeouts(): AwsEvaluator.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsEvaluator.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsEvaluator.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsEvaluatorLambdaConfigPropertyToTerraform(struct?: AwsEvaluator.LambdaConfigProperty | cdktn.IResolvable): any;
export declare function awsEvaluatorLambdaConfigPropertyToHclTerraform(struct?: AwsEvaluator.LambdaConfigProperty | cdktn.IResolvable): any;
export declare function awsEvaluatorCodeBasedPropertyToTerraform(struct?: AwsEvaluator.CodeBasedProperty | cdktn.IResolvable): any;
export declare function awsEvaluatorCodeBasedPropertyToHclTerraform(struct?: AwsEvaluator.CodeBasedProperty | cdktn.IResolvable): any;
export declare function awsEvaluatorInferenceConfigPropertyToTerraform(struct?: AwsEvaluator.InferenceConfigProperty | cdktn.IResolvable): any;
export declare function awsEvaluatorInferenceConfigPropertyToHclTerraform(struct?: AwsEvaluator.InferenceConfigProperty | cdktn.IResolvable): any;
export declare function awsEvaluatorBedrockEvaluatorModelConfigPropertyToTerraform(struct?: AwsEvaluator.BedrockEvaluatorModelConfigProperty | cdktn.IResolvable): any;
export declare function awsEvaluatorBedrockEvaluatorModelConfigPropertyToHclTerraform(struct?: AwsEvaluator.BedrockEvaluatorModelConfigProperty | cdktn.IResolvable): any;
export declare function awsEvaluatorModelConfigPropertyToTerraform(struct?: AwsEvaluator.ModelConfigProperty | cdktn.IResolvable): any;
export declare function awsEvaluatorModelConfigPropertyToHclTerraform(struct?: AwsEvaluator.ModelConfigProperty | cdktn.IResolvable): any;
export declare function awsEvaluatorCategoricalPropertyToTerraform(struct?: AwsEvaluator.CategoricalProperty | cdktn.IResolvable): any;
export declare function awsEvaluatorCategoricalPropertyToHclTerraform(struct?: AwsEvaluator.CategoricalProperty | cdktn.IResolvable): any;
export declare function awsEvaluatorNumericalPropertyToTerraform(struct?: AwsEvaluator.NumericalProperty | cdktn.IResolvable): any;
export declare function awsEvaluatorNumericalPropertyToHclTerraform(struct?: AwsEvaluator.NumericalProperty | cdktn.IResolvable): any;
export declare function awsEvaluatorRatingScalePropertyToTerraform(struct?: AwsEvaluator.RatingScaleProperty | cdktn.IResolvable): any;
export declare function awsEvaluatorRatingScalePropertyToHclTerraform(struct?: AwsEvaluator.RatingScaleProperty | cdktn.IResolvable): any;
export declare function awsEvaluatorLlmAsAJudgePropertyToTerraform(struct?: AwsEvaluator.LlmAsAJudgeProperty | cdktn.IResolvable): any;
export declare function awsEvaluatorLlmAsAJudgePropertyToHclTerraform(struct?: AwsEvaluator.LlmAsAJudgeProperty | cdktn.IResolvable): any;
export declare function awsEvaluatorEvaluatorConfigPropertyToTerraform(struct?: AwsEvaluator.EvaluatorConfigProperty | cdktn.IResolvable): any;
export declare function awsEvaluatorEvaluatorConfigPropertyToHclTerraform(struct?: AwsEvaluator.EvaluatorConfigProperty | cdktn.IResolvable): any;
export declare function awsEvaluatorTimeoutsPropertyToTerraform(struct?: AwsEvaluator.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsEvaluatorTimeoutsPropertyToHclTerraform(struct?: AwsEvaluator.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsEvaluator {
    interface LambdaConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_evaluator#lambda_arn AwsEvaluator#lambda_arn}
        */
        readonly lambdaArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_evaluator#lambda_timeout_in_seconds AwsEvaluator#lambda_timeout_in_seconds}
        */
        readonly lambdaTimeoutInSeconds?: number;
    }
    class LambdaConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): LambdaConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: LambdaConfigProperty | cdktn.IResolvable | undefined);
        private _lambdaArn?;
        get lambdaArn(): string;
        set lambdaArn(value: string);
        get lambdaArnInput(): string | undefined;
        private _lambdaTimeoutInSeconds?;
        get lambdaTimeoutInSeconds(): number;
        set lambdaTimeoutInSeconds(value: number);
        resetLambdaTimeoutInSeconds(): void;
        get lambdaTimeoutInSecondsInput(): number | undefined;
    }
    class LambdaConfigPropertyList extends cdktn.ComplexList {
        internalValue?: LambdaConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): LambdaConfigPropertyOutputReference;
    }
    interface CodeBasedProperty {
        /**
        * lambda_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_evaluator#lambda_config AwsEvaluator#lambda_config}
        */
        readonly lambdaConfig?: LambdaConfigProperty[] | cdktn.IResolvable;
    }
    class CodeBasedPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CodeBasedProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CodeBasedProperty | cdktn.IResolvable | undefined);
        private _lambdaConfig;
        get lambdaConfig(): LambdaConfigPropertyList;
        putLambdaConfig(value: LambdaConfigProperty[] | cdktn.IResolvable): void;
        resetLambdaConfig(): void;
        get lambdaConfigInput(): cdktn.IResolvable | LambdaConfigProperty[] | undefined;
    }
    class CodeBasedPropertyList extends cdktn.ComplexList {
        internalValue?: CodeBasedProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CodeBasedPropertyOutputReference;
    }
    interface InferenceConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_evaluator#max_tokens AwsEvaluator#max_tokens}
        */
        readonly maxTokens?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_evaluator#stop_sequences AwsEvaluator#stop_sequences}
        */
        readonly stopSequences?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_evaluator#temperature AwsEvaluator#temperature}
        */
        readonly temperature?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_evaluator#top_p AwsEvaluator#top_p}
        */
        readonly topP?: number;
    }
    class InferenceConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): InferenceConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: InferenceConfigProperty | cdktn.IResolvable | undefined);
        private _maxTokens?;
        get maxTokens(): number;
        set maxTokens(value: number);
        resetMaxTokens(): void;
        get maxTokensInput(): number | undefined;
        private _stopSequences?;
        get stopSequences(): string[];
        set stopSequences(value: string[]);
        resetStopSequences(): void;
        get stopSequencesInput(): string[] | undefined;
        private _temperature?;
        get temperature(): number;
        set temperature(value: number);
        resetTemperature(): void;
        get temperatureInput(): number | undefined;
        private _topP?;
        get topP(): number;
        set topP(value: number);
        resetTopP(): void;
        get topPInput(): number | undefined;
    }
    class InferenceConfigPropertyList extends cdktn.ComplexList {
        internalValue?: InferenceConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): InferenceConfigPropertyOutputReference;
    }
    interface BedrockEvaluatorModelConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_evaluator#additional_model_request_fields AwsEvaluator#additional_model_request_fields}
        */
        readonly additionalModelRequestFields?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_evaluator#model_id AwsEvaluator#model_id}
        */
        readonly modelId: string;
        /**
        * inference_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_evaluator#inference_config AwsEvaluator#inference_config}
        */
        readonly inferenceConfig?: InferenceConfigProperty[] | cdktn.IResolvable;
    }
    class BedrockEvaluatorModelConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): BedrockEvaluatorModelConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: BedrockEvaluatorModelConfigProperty | cdktn.IResolvable | undefined);
        private _additionalModelRequestFields?;
        get additionalModelRequestFields(): string;
        set additionalModelRequestFields(value: string);
        resetAdditionalModelRequestFields(): void;
        get additionalModelRequestFieldsInput(): string | undefined;
        private _modelId?;
        get modelId(): string;
        set modelId(value: string);
        get modelIdInput(): string | undefined;
        private _inferenceConfig;
        get inferenceConfig(): InferenceConfigPropertyList;
        putInferenceConfig(value: InferenceConfigProperty[] | cdktn.IResolvable): void;
        resetInferenceConfig(): void;
        get inferenceConfigInput(): cdktn.IResolvable | InferenceConfigProperty[] | undefined;
    }
    class BedrockEvaluatorModelConfigPropertyList extends cdktn.ComplexList {
        internalValue?: BedrockEvaluatorModelConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): BedrockEvaluatorModelConfigPropertyOutputReference;
    }
    interface ModelConfigProperty {
        /**
        * bedrock_evaluator_model_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_evaluator#bedrock_evaluator_model_config AwsEvaluator#bedrock_evaluator_model_config}
        */
        readonly bedrockEvaluatorModelConfig?: BedrockEvaluatorModelConfigProperty[] | cdktn.IResolvable;
    }
    class ModelConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ModelConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ModelConfigProperty | cdktn.IResolvable | undefined);
        private _bedrockEvaluatorModelConfig;
        get bedrockEvaluatorModelConfig(): BedrockEvaluatorModelConfigPropertyList;
        putBedrockEvaluatorModelConfig(value: BedrockEvaluatorModelConfigProperty[] | cdktn.IResolvable): void;
        resetBedrockEvaluatorModelConfig(): void;
        get bedrockEvaluatorModelConfigInput(): cdktn.IResolvable | BedrockEvaluatorModelConfigProperty[] | undefined;
    }
    class ModelConfigPropertyList extends cdktn.ComplexList {
        internalValue?: ModelConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ModelConfigPropertyOutputReference;
    }
    interface CategoricalProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_evaluator#definition AwsEvaluator#definition}
        */
        readonly definition: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_evaluator#label AwsEvaluator#label}
        */
        readonly label: string;
    }
    class CategoricalPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CategoricalProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CategoricalProperty | cdktn.IResolvable | undefined);
        private _definition?;
        get definition(): string;
        set definition(value: string);
        get definitionInput(): string | undefined;
        private _label?;
        get label(): string;
        set label(value: string);
        get labelInput(): string | undefined;
    }
    class CategoricalPropertyList extends cdktn.ComplexList {
        internalValue?: CategoricalProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CategoricalPropertyOutputReference;
    }
    interface NumericalProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_evaluator#definition AwsEvaluator#definition}
        */
        readonly definition: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_evaluator#label AwsEvaluator#label}
        */
        readonly label: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_evaluator#value AwsEvaluator#value}
        */
        readonly value: number;
    }
    class NumericalPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): NumericalProperty | cdktn.IResolvable | undefined;
        set internalValue(value: NumericalProperty | cdktn.IResolvable | undefined);
        private _definition?;
        get definition(): string;
        set definition(value: string);
        get definitionInput(): string | undefined;
        private _label?;
        get label(): string;
        set label(value: string);
        get labelInput(): string | undefined;
        private _value?;
        get value(): number;
        set value(value: number);
        get valueInput(): number | undefined;
    }
    class NumericalPropertyList extends cdktn.ComplexList {
        internalValue?: NumericalProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): NumericalPropertyOutputReference;
    }
    interface RatingScaleProperty {
        /**
        * categorical block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_evaluator#categorical AwsEvaluator#categorical}
        */
        readonly categorical?: CategoricalProperty[] | cdktn.IResolvable;
        /**
        * numerical block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_evaluator#numerical AwsEvaluator#numerical}
        */
        readonly numerical?: NumericalProperty[] | cdktn.IResolvable;
    }
    class RatingScalePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RatingScaleProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RatingScaleProperty | cdktn.IResolvable | undefined);
        private _categorical;
        get categorical(): CategoricalPropertyList;
        putCategorical(value: CategoricalProperty[] | cdktn.IResolvable): void;
        resetCategorical(): void;
        get categoricalInput(): cdktn.IResolvable | CategoricalProperty[] | undefined;
        private _numerical;
        get numerical(): NumericalPropertyList;
        putNumerical(value: NumericalProperty[] | cdktn.IResolvable): void;
        resetNumerical(): void;
        get numericalInput(): cdktn.IResolvable | NumericalProperty[] | undefined;
    }
    class RatingScalePropertyList extends cdktn.ComplexList {
        internalValue?: RatingScaleProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RatingScalePropertyOutputReference;
    }
    interface LlmAsAJudgeProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_evaluator#instructions AwsEvaluator#instructions}
        */
        readonly instructions: string;
        /**
        * model_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_evaluator#model_config AwsEvaluator#model_config}
        */
        readonly modelConfig?: ModelConfigProperty[] | cdktn.IResolvable;
        /**
        * rating_scale block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_evaluator#rating_scale AwsEvaluator#rating_scale}
        */
        readonly ratingScale?: RatingScaleProperty[] | cdktn.IResolvable;
    }
    class LlmAsAJudgePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): LlmAsAJudgeProperty | cdktn.IResolvable | undefined;
        set internalValue(value: LlmAsAJudgeProperty | cdktn.IResolvable | undefined);
        private _instructions?;
        get instructions(): string;
        set instructions(value: string);
        get instructionsInput(): string | undefined;
        private _modelConfig;
        get modelConfig(): ModelConfigPropertyList;
        putModelConfig(value: ModelConfigProperty[] | cdktn.IResolvable): void;
        resetModelConfig(): void;
        get modelConfigInput(): cdktn.IResolvable | ModelConfigProperty[] | undefined;
        private _ratingScale;
        get ratingScale(): RatingScalePropertyList;
        putRatingScale(value: RatingScaleProperty[] | cdktn.IResolvable): void;
        resetRatingScale(): void;
        get ratingScaleInput(): cdktn.IResolvable | RatingScaleProperty[] | undefined;
    }
    class LlmAsAJudgePropertyList extends cdktn.ComplexList {
        internalValue?: LlmAsAJudgeProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): LlmAsAJudgePropertyOutputReference;
    }
    interface EvaluatorConfigProperty {
        /**
        * code_based block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_evaluator#code_based AwsEvaluator#code_based}
        */
        readonly codeBased?: CodeBasedProperty[] | cdktn.IResolvable;
        /**
        * llm_as_a_judge block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_evaluator#llm_as_a_judge AwsEvaluator#llm_as_a_judge}
        */
        readonly llmAsAJudge?: LlmAsAJudgeProperty[] | cdktn.IResolvable;
    }
    class EvaluatorConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EvaluatorConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: EvaluatorConfigProperty | cdktn.IResolvable | undefined);
        private _codeBased;
        get codeBased(): CodeBasedPropertyList;
        putCodeBased(value: CodeBasedProperty[] | cdktn.IResolvable): void;
        resetCodeBased(): void;
        get codeBasedInput(): cdktn.IResolvable | CodeBasedProperty[] | undefined;
        private _llmAsAJudge;
        get llmAsAJudge(): LlmAsAJudgePropertyList;
        putLlmAsAJudge(value: LlmAsAJudgeProperty[] | cdktn.IResolvable): void;
        resetLlmAsAJudge(): void;
        get llmAsAJudgeInput(): cdktn.IResolvable | LlmAsAJudgeProperty[] | undefined;
    }
    class EvaluatorConfigPropertyList extends cdktn.ComplexList {
        internalValue?: EvaluatorConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EvaluatorConfigPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_evaluator#create AwsEvaluator#create}
        */
        readonly create?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Setting a timeout for a Delete operation is only applicable if changes are saved into state before the destroy operation occurs.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_evaluator#delete AwsEvaluator#delete}
        */
        readonly delete?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_evaluator#update AwsEvaluator#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
