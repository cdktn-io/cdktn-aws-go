import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsOnlineEvaluationConfigConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_online_evaluation_config#description AwsOnlineEvaluationConfig#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_online_evaluation_config#enable_on_create AwsOnlineEvaluationConfig#enable_on_create}
    */
    readonly enableOnCreate: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_online_evaluation_config#evaluation_execution_role_arn AwsOnlineEvaluationConfig#evaluation_execution_role_arn}
    */
    readonly evaluationExecutionRoleArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_online_evaluation_config#execution_status AwsOnlineEvaluationConfig#execution_status}
    */
    readonly executionStatus?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_online_evaluation_config#online_evaluation_config_name AwsOnlineEvaluationConfig#online_evaluation_config_name}
    */
    readonly onlineEvaluationConfigName: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_online_evaluation_config#region AwsOnlineEvaluationConfig#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_online_evaluation_config#tags AwsOnlineEvaluationConfig#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * data_source_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_online_evaluation_config#data_source_config AwsOnlineEvaluationConfig#data_source_config}
    */
    readonly dataSourceConfig?: AwsOnlineEvaluationConfig.DataSourceConfigProperty[] | cdktn.IResolvable;
    /**
    * evaluator block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_online_evaluation_config#evaluator AwsOnlineEvaluationConfig#evaluator}
    */
    readonly evaluator?: AwsOnlineEvaluationConfig.EvaluatorProperty[] | cdktn.IResolvable;
    /**
    * rule block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_online_evaluation_config#rule AwsOnlineEvaluationConfig#rule}
    */
    readonly rule?: AwsOnlineEvaluationConfig.RuleProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_online_evaluation_config#timeouts AwsOnlineEvaluationConfig#timeouts}
    */
    readonly timeouts?: AwsOnlineEvaluationConfig.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_online_evaluation_config aws_bedrockagentcore_online_evaluation_config}
*/
export declare class AwsOnlineEvaluationConfig extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_bedrockagentcore_online_evaluation_config";
    /**
    * Generates CDKTN code for importing a AwsOnlineEvaluationConfig resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsOnlineEvaluationConfig to import
    * @param importFromId The id of the existing AwsOnlineEvaluationConfig that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_online_evaluation_config#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsOnlineEvaluationConfig to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_online_evaluation_config aws_bedrockagentcore_online_evaluation_config} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsOnlineEvaluationConfigConfig
    */
    constructor(scope: Construct, id: string, config: AwsOnlineEvaluationConfigConfig);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _enableOnCreate?;
    get enableOnCreate(): boolean | cdktn.IResolvable;
    set enableOnCreate(value: boolean | cdktn.IResolvable);
    get enableOnCreateInput(): boolean | cdktn.IResolvable | undefined;
    private _evaluationExecutionRoleArn?;
    get evaluationExecutionRoleArn(): string;
    set evaluationExecutionRoleArn(value: string);
    get evaluationExecutionRoleArnInput(): string | undefined;
    private _executionStatus?;
    get executionStatus(): string;
    set executionStatus(value: string);
    resetExecutionStatus(): void;
    get executionStatusInput(): string | undefined;
    get onlineEvaluationConfigArn(): string;
    get onlineEvaluationConfigId(): string;
    private _onlineEvaluationConfigName?;
    get onlineEvaluationConfigName(): string;
    set onlineEvaluationConfigName(value: string);
    get onlineEvaluationConfigNameInput(): string | undefined;
    private _outputConfig;
    get outputConfig(): AwsOnlineEvaluationConfig.OutputConfigPropertyList;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    private _dataSourceConfig;
    get dataSourceConfig(): AwsOnlineEvaluationConfig.DataSourceConfigPropertyList;
    putDataSourceConfig(value: AwsOnlineEvaluationConfig.DataSourceConfigProperty[] | cdktn.IResolvable): void;
    resetDataSourceConfig(): void;
    get dataSourceConfigInput(): cdktn.IResolvable | AwsOnlineEvaluationConfig.DataSourceConfigProperty[] | undefined;
    private _evaluator;
    get evaluator(): AwsOnlineEvaluationConfig.EvaluatorPropertyList;
    putEvaluator(value: AwsOnlineEvaluationConfig.EvaluatorProperty[] | cdktn.IResolvable): void;
    resetEvaluator(): void;
    get evaluatorInput(): cdktn.IResolvable | AwsOnlineEvaluationConfig.EvaluatorProperty[] | undefined;
    private _rule;
    get rule(): AwsOnlineEvaluationConfig.RulePropertyList;
    putRule(value: AwsOnlineEvaluationConfig.RuleProperty[] | cdktn.IResolvable): void;
    resetRule(): void;
    get ruleInput(): cdktn.IResolvable | AwsOnlineEvaluationConfig.RuleProperty[] | undefined;
    private _timeouts;
    get timeouts(): AwsOnlineEvaluationConfig.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsOnlineEvaluationConfig.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsOnlineEvaluationConfig.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsOnlineEvaluationConfigCloudwatchConfigPropertyToTerraform(struct?: AwsOnlineEvaluationConfig.CloudwatchConfigProperty): any;
export declare function awsOnlineEvaluationConfigCloudwatchConfigPropertyToHclTerraform(struct?: AwsOnlineEvaluationConfig.CloudwatchConfigProperty): any;
export declare function awsOnlineEvaluationConfigOutputConfigPropertyToTerraform(struct?: AwsOnlineEvaluationConfig.OutputConfigProperty): any;
export declare function awsOnlineEvaluationConfigOutputConfigPropertyToHclTerraform(struct?: AwsOnlineEvaluationConfig.OutputConfigProperty): any;
export declare function awsOnlineEvaluationConfigCloudwatchLogsPropertyToTerraform(struct?: AwsOnlineEvaluationConfig.CloudwatchLogsProperty | cdktn.IResolvable): any;
export declare function awsOnlineEvaluationConfigCloudwatchLogsPropertyToHclTerraform(struct?: AwsOnlineEvaluationConfig.CloudwatchLogsProperty | cdktn.IResolvable): any;
export declare function awsOnlineEvaluationConfigDataSourceConfigPropertyToTerraform(struct?: AwsOnlineEvaluationConfig.DataSourceConfigProperty | cdktn.IResolvable): any;
export declare function awsOnlineEvaluationConfigDataSourceConfigPropertyToHclTerraform(struct?: AwsOnlineEvaluationConfig.DataSourceConfigProperty | cdktn.IResolvable): any;
export declare function awsOnlineEvaluationConfigEvaluatorPropertyToTerraform(struct?: AwsOnlineEvaluationConfig.EvaluatorProperty | cdktn.IResolvable): any;
export declare function awsOnlineEvaluationConfigEvaluatorPropertyToHclTerraform(struct?: AwsOnlineEvaluationConfig.EvaluatorProperty | cdktn.IResolvable): any;
export declare function awsOnlineEvaluationConfigValuePropertyToTerraform(struct?: AwsOnlineEvaluationConfig.ValueProperty | cdktn.IResolvable): any;
export declare function awsOnlineEvaluationConfigValuePropertyToHclTerraform(struct?: AwsOnlineEvaluationConfig.ValueProperty | cdktn.IResolvable): any;
export declare function awsOnlineEvaluationConfigFilterPropertyToTerraform(struct?: AwsOnlineEvaluationConfig.FilterProperty | cdktn.IResolvable): any;
export declare function awsOnlineEvaluationConfigFilterPropertyToHclTerraform(struct?: AwsOnlineEvaluationConfig.FilterProperty | cdktn.IResolvable): any;
export declare function awsOnlineEvaluationConfigSamplingConfigPropertyToTerraform(struct?: AwsOnlineEvaluationConfig.SamplingConfigProperty | cdktn.IResolvable): any;
export declare function awsOnlineEvaluationConfigSamplingConfigPropertyToHclTerraform(struct?: AwsOnlineEvaluationConfig.SamplingConfigProperty | cdktn.IResolvable): any;
export declare function awsOnlineEvaluationConfigSessionConfigPropertyToTerraform(struct?: AwsOnlineEvaluationConfig.SessionConfigProperty | cdktn.IResolvable): any;
export declare function awsOnlineEvaluationConfigSessionConfigPropertyToHclTerraform(struct?: AwsOnlineEvaluationConfig.SessionConfigProperty | cdktn.IResolvable): any;
export declare function awsOnlineEvaluationConfigRulePropertyToTerraform(struct?: AwsOnlineEvaluationConfig.RuleProperty | cdktn.IResolvable): any;
export declare function awsOnlineEvaluationConfigRulePropertyToHclTerraform(struct?: AwsOnlineEvaluationConfig.RuleProperty | cdktn.IResolvable): any;
export declare function awsOnlineEvaluationConfigTimeoutsPropertyToTerraform(struct?: AwsOnlineEvaluationConfig.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsOnlineEvaluationConfigTimeoutsPropertyToHclTerraform(struct?: AwsOnlineEvaluationConfig.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsOnlineEvaluationConfig {
    interface CloudwatchConfigProperty {
    }
    class CloudwatchConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CloudwatchConfigProperty | undefined;
        set internalValue(value: CloudwatchConfigProperty | undefined);
        get logGroupName(): string;
    }
    class CloudwatchConfigPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CloudwatchConfigPropertyOutputReference;
    }
    interface OutputConfigProperty {
    }
    class OutputConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): OutputConfigProperty | undefined;
        set internalValue(value: OutputConfigProperty | undefined);
        private _cloudwatchConfig;
        get cloudwatchConfig(): CloudwatchConfigPropertyList;
    }
    class OutputConfigPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): OutputConfigPropertyOutputReference;
    }
    interface CloudwatchLogsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_online_evaluation_config#log_group_names AwsOnlineEvaluationConfig#log_group_names}
        */
        readonly logGroupNames: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_online_evaluation_config#service_names AwsOnlineEvaluationConfig#service_names}
        */
        readonly serviceNames: string[];
    }
    class CloudwatchLogsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CloudwatchLogsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CloudwatchLogsProperty | cdktn.IResolvable | undefined);
        private _logGroupNames?;
        get logGroupNames(): string[];
        set logGroupNames(value: string[]);
        get logGroupNamesInput(): string[] | undefined;
        private _serviceNames?;
        get serviceNames(): string[];
        set serviceNames(value: string[]);
        get serviceNamesInput(): string[] | undefined;
    }
    class CloudwatchLogsPropertyList extends cdktn.ComplexList {
        internalValue?: CloudwatchLogsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CloudwatchLogsPropertyOutputReference;
    }
    interface DataSourceConfigProperty {
        /**
        * cloudwatch_logs block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_online_evaluation_config#cloudwatch_logs AwsOnlineEvaluationConfig#cloudwatch_logs}
        */
        readonly cloudwatchLogs?: CloudwatchLogsProperty[] | cdktn.IResolvable;
    }
    class DataSourceConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DataSourceConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DataSourceConfigProperty | cdktn.IResolvable | undefined);
        private _cloudwatchLogs;
        get cloudwatchLogs(): CloudwatchLogsPropertyList;
        putCloudwatchLogs(value: CloudwatchLogsProperty[] | cdktn.IResolvable): void;
        resetCloudwatchLogs(): void;
        get cloudwatchLogsInput(): cdktn.IResolvable | CloudwatchLogsProperty[] | undefined;
    }
    class DataSourceConfigPropertyList extends cdktn.ComplexList {
        internalValue?: DataSourceConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DataSourceConfigPropertyOutputReference;
    }
    interface EvaluatorProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_online_evaluation_config#evaluator_id AwsOnlineEvaluationConfig#evaluator_id}
        */
        readonly evaluatorId: string;
    }
    class EvaluatorPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EvaluatorProperty | cdktn.IResolvable | undefined;
        set internalValue(value: EvaluatorProperty | cdktn.IResolvable | undefined);
        private _evaluatorId?;
        get evaluatorId(): string;
        set evaluatorId(value: string);
        get evaluatorIdInput(): string | undefined;
    }
    class EvaluatorPropertyList extends cdktn.ComplexList {
        internalValue?: EvaluatorProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EvaluatorPropertyOutputReference;
    }
    interface ValueProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_online_evaluation_config#boolean_value AwsOnlineEvaluationConfig#boolean_value}
        */
        readonly booleanValue?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_online_evaluation_config#double_value AwsOnlineEvaluationConfig#double_value}
        */
        readonly doubleValue?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_online_evaluation_config#string_value AwsOnlineEvaluationConfig#string_value}
        */
        readonly stringValue?: string;
    }
    class ValuePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ValueProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ValueProperty | cdktn.IResolvable | undefined);
        private _booleanValue?;
        get booleanValue(): boolean | cdktn.IResolvable;
        set booleanValue(value: boolean | cdktn.IResolvable);
        resetBooleanValue(): void;
        get booleanValueInput(): boolean | cdktn.IResolvable | undefined;
        private _doubleValue?;
        get doubleValue(): number;
        set doubleValue(value: number);
        resetDoubleValue(): void;
        get doubleValueInput(): number | undefined;
        private _stringValue?;
        get stringValue(): string;
        set stringValue(value: string);
        resetStringValue(): void;
        get stringValueInput(): string | undefined;
    }
    class ValuePropertyList extends cdktn.ComplexList {
        internalValue?: ValueProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ValuePropertyOutputReference;
    }
    interface FilterProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_online_evaluation_config#key AwsOnlineEvaluationConfig#key}
        */
        readonly key: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_online_evaluation_config#operator AwsOnlineEvaluationConfig#operator}
        */
        readonly operator: string;
        /**
        * value block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_online_evaluation_config#value AwsOnlineEvaluationConfig#value}
        */
        readonly value?: ValueProperty[] | cdktn.IResolvable;
    }
    class FilterPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): FilterProperty | cdktn.IResolvable | undefined;
        set internalValue(value: FilterProperty | cdktn.IResolvable | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        get keyInput(): string | undefined;
        private _operator?;
        get operator(): string;
        set operator(value: string);
        get operatorInput(): string | undefined;
        private _value;
        get value(): ValuePropertyList;
        putValue(value: ValueProperty[] | cdktn.IResolvable): void;
        resetValue(): void;
        get valueInput(): cdktn.IResolvable | ValueProperty[] | undefined;
    }
    class FilterPropertyList extends cdktn.ComplexList {
        internalValue?: FilterProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): FilterPropertyOutputReference;
    }
    interface SamplingConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_online_evaluation_config#sampling_percentage AwsOnlineEvaluationConfig#sampling_percentage}
        */
        readonly samplingPercentage: number;
    }
    class SamplingConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SamplingConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SamplingConfigProperty | cdktn.IResolvable | undefined);
        private _samplingPercentage?;
        get samplingPercentage(): number;
        set samplingPercentage(value: number);
        get samplingPercentageInput(): number | undefined;
    }
    class SamplingConfigPropertyList extends cdktn.ComplexList {
        internalValue?: SamplingConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SamplingConfigPropertyOutputReference;
    }
    interface SessionConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_online_evaluation_config#session_timeout_minutes AwsOnlineEvaluationConfig#session_timeout_minutes}
        */
        readonly sessionTimeoutMinutes: number;
    }
    class SessionConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SessionConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SessionConfigProperty | cdktn.IResolvable | undefined);
        private _sessionTimeoutMinutes?;
        get sessionTimeoutMinutes(): number;
        set sessionTimeoutMinutes(value: number);
        get sessionTimeoutMinutesInput(): number | undefined;
    }
    class SessionConfigPropertyList extends cdktn.ComplexList {
        internalValue?: SessionConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SessionConfigPropertyOutputReference;
    }
    interface RuleProperty {
        /**
        * filter block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_online_evaluation_config#filter AwsOnlineEvaluationConfig#filter}
        */
        readonly filter?: FilterProperty[] | cdktn.IResolvable;
        /**
        * sampling_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_online_evaluation_config#sampling_config AwsOnlineEvaluationConfig#sampling_config}
        */
        readonly samplingConfig?: SamplingConfigProperty[] | cdktn.IResolvable;
        /**
        * session_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_online_evaluation_config#session_config AwsOnlineEvaluationConfig#session_config}
        */
        readonly sessionConfig?: SessionConfigProperty[] | cdktn.IResolvable;
    }
    class RulePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RuleProperty | cdktn.IResolvable | undefined);
        private _filter;
        get filter(): FilterPropertyList;
        putFilter(value: FilterProperty[] | cdktn.IResolvable): void;
        resetFilter(): void;
        get filterInput(): cdktn.IResolvable | FilterProperty[] | undefined;
        private _samplingConfig;
        get samplingConfig(): SamplingConfigPropertyList;
        putSamplingConfig(value: SamplingConfigProperty[] | cdktn.IResolvable): void;
        resetSamplingConfig(): void;
        get samplingConfigInput(): cdktn.IResolvable | SamplingConfigProperty[] | undefined;
        private _sessionConfig;
        get sessionConfig(): SessionConfigPropertyList;
        putSessionConfig(value: SessionConfigProperty[] | cdktn.IResolvable): void;
        resetSessionConfig(): void;
        get sessionConfigInput(): cdktn.IResolvable | SessionConfigProperty[] | undefined;
    }
    class RulePropertyList extends cdktn.ComplexList {
        internalValue?: RuleProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RulePropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_online_evaluation_config#create AwsOnlineEvaluationConfig#create}
        */
        readonly create?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Setting a timeout for a Delete operation is only applicable if changes are saved into state before the destroy operation occurs.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_online_evaluation_config#delete AwsOnlineEvaluationConfig#delete}
        */
        readonly delete?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_online_evaluation_config#update AwsOnlineEvaluationConfig#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
