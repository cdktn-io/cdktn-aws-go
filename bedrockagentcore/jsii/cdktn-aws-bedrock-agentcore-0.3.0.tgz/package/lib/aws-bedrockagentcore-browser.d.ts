import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsBrowserConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_browser#description AwsBrowser#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_browser#execution_role_arn AwsBrowser#execution_role_arn}
    */
    readonly executionRoleArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_browser#name AwsBrowser#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_browser#region AwsBrowser#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_browser#tags AwsBrowser#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * browser_signing block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_browser#browser_signing AwsBrowser#browser_signing}
    */
    readonly browserSigning?: AwsBrowser.BrowserSigningProperty[] | cdktn.IResolvable;
    /**
    * certificate block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_browser#certificate AwsBrowser#certificate}
    */
    readonly certificate?: AwsBrowser.CertificateProperty[] | cdktn.IResolvable;
    /**
    * enterprise_policy block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_browser#enterprise_policy AwsBrowser#enterprise_policy}
    */
    readonly enterprisePolicy?: AwsBrowser.EnterprisePolicyProperty[] | cdktn.IResolvable;
    /**
    * network_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_browser#network_configuration AwsBrowser#network_configuration}
    */
    readonly networkConfiguration?: AwsBrowser.NetworkConfigurationProperty[] | cdktn.IResolvable;
    /**
    * recording block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_browser#recording AwsBrowser#recording}
    */
    readonly recording?: AwsBrowser.RecordingProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_browser#timeouts AwsBrowser#timeouts}
    */
    readonly timeouts?: AwsBrowser.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_browser aws_bedrockagentcore_browser}
*/
export declare class AwsBrowser extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_bedrockagentcore_browser";
    /**
    * Generates CDKTN code for importing a AwsBrowser resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsBrowser to import
    * @param importFromId The id of the existing AwsBrowser that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_browser#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsBrowser to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_browser aws_bedrockagentcore_browser} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsBrowserConfig
    */
    constructor(scope: Construct, id: string, config: AwsBrowserConfig);
    get browserArn(): string;
    get browserId(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _executionRoleArn?;
    get executionRoleArn(): string;
    set executionRoleArn(value: string);
    resetExecutionRoleArn(): void;
    get executionRoleArnInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    private _browserSigning;
    get browserSigning(): AwsBrowser.BrowserSigningPropertyList;
    putBrowserSigning(value: AwsBrowser.BrowserSigningProperty[] | cdktn.IResolvable): void;
    resetBrowserSigning(): void;
    get browserSigningInput(): cdktn.IResolvable | AwsBrowser.BrowserSigningProperty[] | undefined;
    private _certificate;
    get certificate(): AwsBrowser.CertificatePropertyList;
    putCertificate(value: AwsBrowser.CertificateProperty[] | cdktn.IResolvable): void;
    resetCertificate(): void;
    get certificateInput(): cdktn.IResolvable | AwsBrowser.CertificateProperty[] | undefined;
    private _enterprisePolicy;
    get enterprisePolicy(): AwsBrowser.EnterprisePolicyPropertyList;
    putEnterprisePolicy(value: AwsBrowser.EnterprisePolicyProperty[] | cdktn.IResolvable): void;
    resetEnterprisePolicy(): void;
    get enterprisePolicyInput(): cdktn.IResolvable | AwsBrowser.EnterprisePolicyProperty[] | undefined;
    private _networkConfiguration;
    get networkConfiguration(): AwsBrowser.NetworkConfigurationPropertyList;
    putNetworkConfiguration(value: AwsBrowser.NetworkConfigurationProperty[] | cdktn.IResolvable): void;
    resetNetworkConfiguration(): void;
    get networkConfigurationInput(): cdktn.IResolvable | AwsBrowser.NetworkConfigurationProperty[] | undefined;
    private _recording;
    get recording(): AwsBrowser.RecordingPropertyList;
    putRecording(value: AwsBrowser.RecordingProperty[] | cdktn.IResolvable): void;
    resetRecording(): void;
    get recordingInput(): cdktn.IResolvable | AwsBrowser.RecordingProperty[] | undefined;
    private _timeouts;
    get timeouts(): AwsBrowser.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsBrowser.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsBrowser.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsBrowserBrowserSigningPropertyToTerraform(struct?: AwsBrowser.BrowserSigningProperty | cdktn.IResolvable): any;
export declare function awsBrowserBrowserSigningPropertyToHclTerraform(struct?: AwsBrowser.BrowserSigningProperty | cdktn.IResolvable): any;
export declare function awsBrowserSecretsManagerPropertyToTerraform(struct?: AwsBrowser.SecretsManagerProperty | cdktn.IResolvable): any;
export declare function awsBrowserSecretsManagerPropertyToHclTerraform(struct?: AwsBrowser.SecretsManagerProperty | cdktn.IResolvable): any;
export declare function awsBrowserCertificateLocationPropertyToTerraform(struct?: AwsBrowser.CertificateLocationProperty | cdktn.IResolvable): any;
export declare function awsBrowserCertificateLocationPropertyToHclTerraform(struct?: AwsBrowser.CertificateLocationProperty | cdktn.IResolvable): any;
export declare function awsBrowserCertificatePropertyToTerraform(struct?: AwsBrowser.CertificateProperty | cdktn.IResolvable): any;
export declare function awsBrowserCertificatePropertyToHclTerraform(struct?: AwsBrowser.CertificateProperty | cdktn.IResolvable): any;
export declare function awsBrowserS3PropertyToTerraform(struct?: AwsBrowser.S3Property | cdktn.IResolvable): any;
export declare function awsBrowserS3PropertyToHclTerraform(struct?: AwsBrowser.S3Property | cdktn.IResolvable): any;
export declare function awsBrowserEnterprisePolicyLocationPropertyToTerraform(struct?: AwsBrowser.EnterprisePolicyLocationProperty | cdktn.IResolvable): any;
export declare function awsBrowserEnterprisePolicyLocationPropertyToHclTerraform(struct?: AwsBrowser.EnterprisePolicyLocationProperty | cdktn.IResolvable): any;
export declare function awsBrowserEnterprisePolicyPropertyToTerraform(struct?: AwsBrowser.EnterprisePolicyProperty | cdktn.IResolvable): any;
export declare function awsBrowserEnterprisePolicyPropertyToHclTerraform(struct?: AwsBrowser.EnterprisePolicyProperty | cdktn.IResolvable): any;
export declare function awsBrowserVpcConfigPropertyToTerraform(struct?: AwsBrowser.VpcConfigProperty | cdktn.IResolvable): any;
export declare function awsBrowserVpcConfigPropertyToHclTerraform(struct?: AwsBrowser.VpcConfigProperty | cdktn.IResolvable): any;
export declare function awsBrowserNetworkConfigurationPropertyToTerraform(struct?: AwsBrowser.NetworkConfigurationProperty | cdktn.IResolvable): any;
export declare function awsBrowserNetworkConfigurationPropertyToHclTerraform(struct?: AwsBrowser.NetworkConfigurationProperty | cdktn.IResolvable): any;
export declare function awsBrowserS3LocationPropertyToTerraform(struct?: AwsBrowser.S3LocationProperty | cdktn.IResolvable): any;
export declare function awsBrowserS3LocationPropertyToHclTerraform(struct?: AwsBrowser.S3LocationProperty | cdktn.IResolvable): any;
export declare function awsBrowserRecordingPropertyToTerraform(struct?: AwsBrowser.RecordingProperty | cdktn.IResolvable): any;
export declare function awsBrowserRecordingPropertyToHclTerraform(struct?: AwsBrowser.RecordingProperty | cdktn.IResolvable): any;
export declare function awsBrowserTimeoutsPropertyToTerraform(struct?: AwsBrowser.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsBrowserTimeoutsPropertyToHclTerraform(struct?: AwsBrowser.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsBrowser {
    interface BrowserSigningProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_browser#enabled AwsBrowser#enabled}
        */
        readonly enabled: boolean | cdktn.IResolvable;
    }
    class BrowserSigningPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): BrowserSigningProperty | cdktn.IResolvable | undefined;
        set internalValue(value: BrowserSigningProperty | cdktn.IResolvable | undefined);
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
    }
    class BrowserSigningPropertyList extends cdktn.ComplexList {
        internalValue?: BrowserSigningProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): BrowserSigningPropertyOutputReference;
    }
    interface SecretsManagerProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_browser#secret_arn AwsBrowser#secret_arn}
        */
        readonly secretArn: string;
    }
    class SecretsManagerPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SecretsManagerProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SecretsManagerProperty | cdktn.IResolvable | undefined);
        private _secretArn?;
        get secretArn(): string;
        set secretArn(value: string);
        get secretArnInput(): string | undefined;
    }
    class SecretsManagerPropertyList extends cdktn.ComplexList {
        internalValue?: SecretsManagerProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SecretsManagerPropertyOutputReference;
    }
    interface CertificateLocationProperty {
        /**
        * secrets_manager block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_browser#secrets_manager AwsBrowser#secrets_manager}
        */
        readonly secretsManager?: SecretsManagerProperty[] | cdktn.IResolvable;
    }
    class CertificateLocationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CertificateLocationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CertificateLocationProperty | cdktn.IResolvable | undefined);
        private _secretsManager;
        get secretsManager(): SecretsManagerPropertyList;
        putSecretsManager(value: SecretsManagerProperty[] | cdktn.IResolvable): void;
        resetSecretsManager(): void;
        get secretsManagerInput(): cdktn.IResolvable | SecretsManagerProperty[] | undefined;
    }
    class CertificateLocationPropertyList extends cdktn.ComplexList {
        internalValue?: CertificateLocationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CertificateLocationPropertyOutputReference;
    }
    interface CertificateProperty {
        /**
        * location block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_browser#location AwsBrowser#location}
        */
        readonly location?: CertificateLocationProperty[] | cdktn.IResolvable;
    }
    class CertificatePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CertificateProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CertificateProperty | cdktn.IResolvable | undefined);
        private _location;
        get location(): CertificateLocationPropertyList;
        putLocation(value: CertificateLocationProperty[] | cdktn.IResolvable): void;
        resetLocation(): void;
        get locationInput(): cdktn.IResolvable | CertificateLocationProperty[] | undefined;
    }
    class CertificatePropertyList extends cdktn.ComplexList {
        internalValue?: CertificateProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CertificatePropertyOutputReference;
    }
    interface S3Property {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_browser#bucket AwsBrowser#bucket}
        */
        readonly bucket: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_browser#prefix AwsBrowser#prefix}
        */
        readonly prefix: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_browser#version_id AwsBrowser#version_id}
        */
        readonly versionId?: string;
    }
    class S3PropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): S3Property | cdktn.IResolvable | undefined;
        set internalValue(value: S3Property | cdktn.IResolvable | undefined);
        private _bucket?;
        get bucket(): string;
        set bucket(value: string);
        get bucketInput(): string | undefined;
        private _prefix?;
        get prefix(): string;
        set prefix(value: string);
        get prefixInput(): string | undefined;
        private _versionId?;
        get versionId(): string;
        set versionId(value: string);
        resetVersionId(): void;
        get versionIdInput(): string | undefined;
    }
    class S3PropertyList extends cdktn.ComplexList {
        internalValue?: S3Property[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): S3PropertyOutputReference;
    }
    interface EnterprisePolicyLocationProperty {
        /**
        * s3 block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_browser#s3 AwsBrowser#s3}
        */
        readonly s3?: S3Property[] | cdktn.IResolvable;
    }
    class EnterprisePolicyLocationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EnterprisePolicyLocationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: EnterprisePolicyLocationProperty | cdktn.IResolvable | undefined);
        private _s3;
        get s3(): S3PropertyList;
        putS3(value: S3Property[] | cdktn.IResolvable): void;
        resetS3(): void;
        get s3Input(): cdktn.IResolvable | S3Property[] | undefined;
    }
    class EnterprisePolicyLocationPropertyList extends cdktn.ComplexList {
        internalValue?: EnterprisePolicyLocationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EnterprisePolicyLocationPropertyOutputReference;
    }
    interface EnterprisePolicyProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_browser#type AwsBrowser#type}
        */
        readonly type?: string;
        /**
        * location block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_browser#location AwsBrowser#location}
        */
        readonly location?: EnterprisePolicyLocationProperty[] | cdktn.IResolvable;
    }
    class EnterprisePolicyPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EnterprisePolicyProperty | cdktn.IResolvable | undefined;
        set internalValue(value: EnterprisePolicyProperty | cdktn.IResolvable | undefined);
        private _type?;
        get type(): string;
        set type(value: string);
        resetType(): void;
        get typeInput(): string | undefined;
        private _location;
        get location(): EnterprisePolicyLocationPropertyList;
        putLocation(value: EnterprisePolicyLocationProperty[] | cdktn.IResolvable): void;
        resetLocation(): void;
        get locationInput(): cdktn.IResolvable | EnterprisePolicyLocationProperty[] | undefined;
    }
    class EnterprisePolicyPropertyList extends cdktn.ComplexList {
        internalValue?: EnterprisePolicyProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EnterprisePolicyPropertyOutputReference;
    }
    interface VpcConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_browser#security_groups AwsBrowser#security_groups}
        */
        readonly securityGroups: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_browser#subnets AwsBrowser#subnets}
        */
        readonly subnets: string[];
    }
    class VpcConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): VpcConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: VpcConfigProperty | cdktn.IResolvable | undefined);
        private _securityGroups?;
        get securityGroups(): string[];
        set securityGroups(value: string[]);
        get securityGroupsInput(): string[] | undefined;
        private _subnets?;
        get subnets(): string[];
        set subnets(value: string[]);
        get subnetsInput(): string[] | undefined;
    }
    class VpcConfigPropertyList extends cdktn.ComplexList {
        internalValue?: VpcConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): VpcConfigPropertyOutputReference;
    }
    interface NetworkConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_browser#network_mode AwsBrowser#network_mode}
        */
        readonly networkMode: string;
        /**
        * vpc_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_browser#vpc_config AwsBrowser#vpc_config}
        */
        readonly vpcConfig?: VpcConfigProperty[] | cdktn.IResolvable;
    }
    class NetworkConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): NetworkConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: NetworkConfigurationProperty | cdktn.IResolvable | undefined);
        private _networkMode?;
        get networkMode(): string;
        set networkMode(value: string);
        get networkModeInput(): string | undefined;
        private _vpcConfig;
        get vpcConfig(): VpcConfigPropertyList;
        putVpcConfig(value: VpcConfigProperty[] | cdktn.IResolvable): void;
        resetVpcConfig(): void;
        get vpcConfigInput(): cdktn.IResolvable | VpcConfigProperty[] | undefined;
    }
    class NetworkConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: NetworkConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): NetworkConfigurationPropertyOutputReference;
    }
    interface S3LocationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_browser#bucket AwsBrowser#bucket}
        */
        readonly bucket: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_browser#prefix AwsBrowser#prefix}
        */
        readonly prefix: string;
    }
    class S3LocationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): S3LocationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: S3LocationProperty | cdktn.IResolvable | undefined);
        private _bucket?;
        get bucket(): string;
        set bucket(value: string);
        get bucketInput(): string | undefined;
        private _prefix?;
        get prefix(): string;
        set prefix(value: string);
        get prefixInput(): string | undefined;
    }
    class S3LocationPropertyList extends cdktn.ComplexList {
        internalValue?: S3LocationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): S3LocationPropertyOutputReference;
    }
    interface RecordingProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_browser#enabled AwsBrowser#enabled}
        */
        readonly enabled?: boolean | cdktn.IResolvable;
        /**
        * s3_location block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_browser#s3_location AwsBrowser#s3_location}
        */
        readonly s3Location?: S3LocationProperty[] | cdktn.IResolvable;
    }
    class RecordingPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RecordingProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RecordingProperty | cdktn.IResolvable | undefined);
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        resetEnabled(): void;
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
        private _s3Location;
        get s3Location(): S3LocationPropertyList;
        putS3Location(value: S3LocationProperty[] | cdktn.IResolvable): void;
        resetS3Location(): void;
        get s3LocationInput(): cdktn.IResolvable | S3LocationProperty[] | undefined;
    }
    class RecordingPropertyList extends cdktn.ComplexList {
        internalValue?: RecordingProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RecordingPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_browser#create AwsBrowser#create}
        */
        readonly create?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Setting a timeout for a Delete operation is only applicable if changes are saved into state before the destroy operation occurs.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_browser#delete AwsBrowser#delete}
        */
        readonly delete?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
    }
}
