import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsAgentRuntimeConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_agent_runtime#agent_runtime_name AwsAgentRuntime#agent_runtime_name}
    */
    readonly agentRuntimeName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_agent_runtime#description AwsAgentRuntime#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_agent_runtime#environment_variables AwsAgentRuntime#environment_variables}
    */
    readonly environmentVariables?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_agent_runtime#lifecycle_configuration AwsAgentRuntime#lifecycle_configuration}
    */
    readonly lifecycleConfiguration?: AwsAgentRuntime.LifecycleConfigurationProperty[] | cdktn.IResolvable;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_agent_runtime#region AwsAgentRuntime#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_agent_runtime#role_arn AwsAgentRuntime#role_arn}
    */
    readonly roleArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_agent_runtime#tags AwsAgentRuntime#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * agent_runtime_artifact block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_agent_runtime#agent_runtime_artifact AwsAgentRuntime#agent_runtime_artifact}
    */
    readonly agentRuntimeArtifact?: AwsAgentRuntime.AgentRuntimeArtifactProperty[] | cdktn.IResolvable;
    /**
    * authorizer_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_agent_runtime#authorizer_configuration AwsAgentRuntime#authorizer_configuration}
    */
    readonly authorizerConfiguration?: AwsAgentRuntime.AuthorizerConfigurationProperty[] | cdktn.IResolvable;
    /**
    * filesystem_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_agent_runtime#filesystem_configuration AwsAgentRuntime#filesystem_configuration}
    */
    readonly filesystemConfiguration?: AwsAgentRuntime.FilesystemConfigurationProperty[] | cdktn.IResolvable;
    /**
    * network_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_agent_runtime#network_configuration AwsAgentRuntime#network_configuration}
    */
    readonly networkConfiguration?: AwsAgentRuntime.NetworkConfigurationProperty[] | cdktn.IResolvable;
    /**
    * protocol_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_agent_runtime#protocol_configuration AwsAgentRuntime#protocol_configuration}
    */
    readonly protocolConfiguration?: AwsAgentRuntime.ProtocolConfigurationProperty[] | cdktn.IResolvable;
    /**
    * request_header_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_agent_runtime#request_header_configuration AwsAgentRuntime#request_header_configuration}
    */
    readonly requestHeaderConfiguration?: AwsAgentRuntime.RequestHeaderConfigurationProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_agent_runtime#timeouts AwsAgentRuntime#timeouts}
    */
    readonly timeouts?: AwsAgentRuntime.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_agent_runtime aws_bedrockagentcore_agent_runtime}
*/
export declare class AwsAgentRuntime extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_bedrockagentcore_agent_runtime";
    /**
    * Generates CDKTN code for importing a AwsAgentRuntime resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsAgentRuntime to import
    * @param importFromId The id of the existing AwsAgentRuntime that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_agent_runtime#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsAgentRuntime to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_agent_runtime aws_bedrockagentcore_agent_runtime} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsAgentRuntimeConfig
    */
    constructor(scope: Construct, id: string, config: AwsAgentRuntimeConfig);
    get agentRuntimeArn(): string;
    get agentRuntimeId(): string;
    private _agentRuntimeName?;
    get agentRuntimeName(): string;
    set agentRuntimeName(value: string);
    get agentRuntimeNameInput(): string | undefined;
    get agentRuntimeVersion(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _environmentVariables?;
    get environmentVariables(): {
        [key: string]: string;
    };
    set environmentVariables(value: {
        [key: string]: string;
    });
    resetEnvironmentVariables(): void;
    get environmentVariablesInput(): {
        [key: string]: string;
    } | undefined;
    private _lifecycleConfiguration;
    get lifecycleConfiguration(): AwsAgentRuntime.LifecycleConfigurationPropertyList;
    putLifecycleConfiguration(value: AwsAgentRuntime.LifecycleConfigurationProperty[] | cdktn.IResolvable): void;
    resetLifecycleConfiguration(): void;
    get lifecycleConfigurationInput(): cdktn.IResolvable | AwsAgentRuntime.LifecycleConfigurationProperty[] | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _roleArn?;
    get roleArn(): string;
    set roleArn(value: string);
    get roleArnInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    private _workloadIdentityDetails;
    get workloadIdentityDetails(): AwsAgentRuntime.WorkloadIdentityDetailsPropertyList;
    private _agentRuntimeArtifact;
    get agentRuntimeArtifact(): AwsAgentRuntime.AgentRuntimeArtifactPropertyList;
    putAgentRuntimeArtifact(value: AwsAgentRuntime.AgentRuntimeArtifactProperty[] | cdktn.IResolvable): void;
    resetAgentRuntimeArtifact(): void;
    get agentRuntimeArtifactInput(): cdktn.IResolvable | AwsAgentRuntime.AgentRuntimeArtifactProperty[] | undefined;
    private _authorizerConfiguration;
    get authorizerConfiguration(): AwsAgentRuntime.AuthorizerConfigurationPropertyList;
    putAuthorizerConfiguration(value: AwsAgentRuntime.AuthorizerConfigurationProperty[] | cdktn.IResolvable): void;
    resetAuthorizerConfiguration(): void;
    get authorizerConfigurationInput(): cdktn.IResolvable | AwsAgentRuntime.AuthorizerConfigurationProperty[] | undefined;
    private _filesystemConfiguration;
    get filesystemConfiguration(): AwsAgentRuntime.FilesystemConfigurationPropertyList;
    putFilesystemConfiguration(value: AwsAgentRuntime.FilesystemConfigurationProperty[] | cdktn.IResolvable): void;
    resetFilesystemConfiguration(): void;
    get filesystemConfigurationInput(): cdktn.IResolvable | AwsAgentRuntime.FilesystemConfigurationProperty[] | undefined;
    private _networkConfiguration;
    get networkConfiguration(): AwsAgentRuntime.NetworkConfigurationPropertyList;
    putNetworkConfiguration(value: AwsAgentRuntime.NetworkConfigurationProperty[] | cdktn.IResolvable): void;
    resetNetworkConfiguration(): void;
    get networkConfigurationInput(): cdktn.IResolvable | AwsAgentRuntime.NetworkConfigurationProperty[] | undefined;
    private _protocolConfiguration;
    get protocolConfiguration(): AwsAgentRuntime.ProtocolConfigurationPropertyList;
    putProtocolConfiguration(value: AwsAgentRuntime.ProtocolConfigurationProperty[] | cdktn.IResolvable): void;
    resetProtocolConfiguration(): void;
    get protocolConfigurationInput(): cdktn.IResolvable | AwsAgentRuntime.ProtocolConfigurationProperty[] | undefined;
    private _requestHeaderConfiguration;
    get requestHeaderConfiguration(): AwsAgentRuntime.RequestHeaderConfigurationPropertyList;
    putRequestHeaderConfiguration(value: AwsAgentRuntime.RequestHeaderConfigurationProperty[] | cdktn.IResolvable): void;
    resetRequestHeaderConfiguration(): void;
    get requestHeaderConfigurationInput(): cdktn.IResolvable | AwsAgentRuntime.RequestHeaderConfigurationProperty[] | undefined;
    private _timeouts;
    get timeouts(): AwsAgentRuntime.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsAgentRuntime.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsAgentRuntime.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsAgentRuntimeLifecycleConfigurationPropertyToTerraform(struct?: AwsAgentRuntime.LifecycleConfigurationProperty | cdktn.IResolvable): any;
export declare function awsAgentRuntimeLifecycleConfigurationPropertyToHclTerraform(struct?: AwsAgentRuntime.LifecycleConfigurationProperty | cdktn.IResolvable): any;
export declare function awsAgentRuntimeWorkloadIdentityDetailsPropertyToTerraform(struct?: AwsAgentRuntime.WorkloadIdentityDetailsProperty): any;
export declare function awsAgentRuntimeWorkloadIdentityDetailsPropertyToHclTerraform(struct?: AwsAgentRuntime.WorkloadIdentityDetailsProperty): any;
export declare function awsAgentRuntimeS3PropertyToTerraform(struct?: AwsAgentRuntime.S3Property | cdktn.IResolvable): any;
export declare function awsAgentRuntimeS3PropertyToHclTerraform(struct?: AwsAgentRuntime.S3Property | cdktn.IResolvable): any;
export declare function awsAgentRuntimeCodePropertyToTerraform(struct?: AwsAgentRuntime.CodeProperty | cdktn.IResolvable): any;
export declare function awsAgentRuntimeCodePropertyToHclTerraform(struct?: AwsAgentRuntime.CodeProperty | cdktn.IResolvable): any;
export declare function awsAgentRuntimeCodeConfigurationPropertyToTerraform(struct?: AwsAgentRuntime.CodeConfigurationProperty | cdktn.IResolvable): any;
export declare function awsAgentRuntimeCodeConfigurationPropertyToHclTerraform(struct?: AwsAgentRuntime.CodeConfigurationProperty | cdktn.IResolvable): any;
export declare function awsAgentRuntimeContainerConfigurationPropertyToTerraform(struct?: AwsAgentRuntime.ContainerConfigurationProperty | cdktn.IResolvable): any;
export declare function awsAgentRuntimeContainerConfigurationPropertyToHclTerraform(struct?: AwsAgentRuntime.ContainerConfigurationProperty | cdktn.IResolvable): any;
export declare function awsAgentRuntimeAgentRuntimeArtifactPropertyToTerraform(struct?: AwsAgentRuntime.AgentRuntimeArtifactProperty | cdktn.IResolvable): any;
export declare function awsAgentRuntimeAgentRuntimeArtifactPropertyToHclTerraform(struct?: AwsAgentRuntime.AgentRuntimeArtifactProperty | cdktn.IResolvable): any;
export declare function awsAgentRuntimeHostingEnvironmentPropertyToTerraform(struct?: AwsAgentRuntime.HostingEnvironmentProperty | cdktn.IResolvable): any;
export declare function awsAgentRuntimeHostingEnvironmentPropertyToHclTerraform(struct?: AwsAgentRuntime.HostingEnvironmentProperty | cdktn.IResolvable): any;
export declare function awsAgentRuntimeAllowedWorkloadConfigurationPropertyToTerraform(struct?: AwsAgentRuntime.AllowedWorkloadConfigurationProperty | cdktn.IResolvable): any;
export declare function awsAgentRuntimeAllowedWorkloadConfigurationPropertyToHclTerraform(struct?: AwsAgentRuntime.AllowedWorkloadConfigurationProperty | cdktn.IResolvable): any;
export declare function awsAgentRuntimeClaimMatchValuePropertyToTerraform(struct?: AwsAgentRuntime.ClaimMatchValueProperty | cdktn.IResolvable): any;
export declare function awsAgentRuntimeClaimMatchValuePropertyToHclTerraform(struct?: AwsAgentRuntime.ClaimMatchValueProperty | cdktn.IResolvable): any;
export declare function awsAgentRuntimeAuthorizingClaimMatchValuePropertyToTerraform(struct?: AwsAgentRuntime.AuthorizingClaimMatchValueProperty | cdktn.IResolvable): any;
export declare function awsAgentRuntimeAuthorizingClaimMatchValuePropertyToHclTerraform(struct?: AwsAgentRuntime.AuthorizingClaimMatchValueProperty | cdktn.IResolvable): any;
export declare function awsAgentRuntimeCustomClaimPropertyToTerraform(struct?: AwsAgentRuntime.CustomClaimProperty | cdktn.IResolvable): any;
export declare function awsAgentRuntimeCustomClaimPropertyToHclTerraform(struct?: AwsAgentRuntime.CustomClaimProperty | cdktn.IResolvable): any;
export declare function awsAgentRuntimeAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointManagedVpcResourcePropertyToTerraform(struct?: AwsAgentRuntime.AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointManagedVpcResourceProperty | cdktn.IResolvable): any;
export declare function awsAgentRuntimeAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointManagedVpcResourcePropertyToHclTerraform(struct?: AwsAgentRuntime.AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointManagedVpcResourceProperty | cdktn.IResolvable): any;
export declare function awsAgentRuntimeAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointSelfManagedLatticeResourcePropertyToTerraform(struct?: AwsAgentRuntime.AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointSelfManagedLatticeResourceProperty | cdktn.IResolvable): any;
export declare function awsAgentRuntimeAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointSelfManagedLatticeResourcePropertyToHclTerraform(struct?: AwsAgentRuntime.AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointSelfManagedLatticeResourceProperty | cdktn.IResolvable): any;
export declare function awsAgentRuntimeAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointPropertyToTerraform(struct?: AwsAgentRuntime.AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointProperty | cdktn.IResolvable): any;
export declare function awsAgentRuntimeAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointPropertyToHclTerraform(struct?: AwsAgentRuntime.AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointProperty | cdktn.IResolvable): any;
export declare function awsAgentRuntimeAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointManagedVpcResourcePropertyToTerraform(struct?: AwsAgentRuntime.AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointManagedVpcResourceProperty | cdktn.IResolvable): any;
export declare function awsAgentRuntimeAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointManagedVpcResourcePropertyToHclTerraform(struct?: AwsAgentRuntime.AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointManagedVpcResourceProperty | cdktn.IResolvable): any;
export declare function awsAgentRuntimeAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointSelfManagedLatticeResourcePropertyToTerraform(struct?: AwsAgentRuntime.AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointSelfManagedLatticeResourceProperty | cdktn.IResolvable): any;
export declare function awsAgentRuntimeAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointSelfManagedLatticeResourcePropertyToHclTerraform(struct?: AwsAgentRuntime.AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointSelfManagedLatticeResourceProperty | cdktn.IResolvable): any;
export declare function awsAgentRuntimeAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointPropertyToTerraform(struct?: AwsAgentRuntime.AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointProperty | cdktn.IResolvable): any;
export declare function awsAgentRuntimeAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointPropertyToHclTerraform(struct?: AwsAgentRuntime.AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointProperty | cdktn.IResolvable): any;
export declare function awsAgentRuntimePrivateEndpointOverridesPropertyToTerraform(struct?: AwsAgentRuntime.PrivateEndpointOverridesProperty | cdktn.IResolvable): any;
export declare function awsAgentRuntimePrivateEndpointOverridesPropertyToHclTerraform(struct?: AwsAgentRuntime.PrivateEndpointOverridesProperty | cdktn.IResolvable): any;
export declare function awsAgentRuntimeCustomJwtAuthorizerPropertyToTerraform(struct?: AwsAgentRuntime.CustomJwtAuthorizerProperty | cdktn.IResolvable): any;
export declare function awsAgentRuntimeCustomJwtAuthorizerPropertyToHclTerraform(struct?: AwsAgentRuntime.CustomJwtAuthorizerProperty | cdktn.IResolvable): any;
export declare function awsAgentRuntimeAuthorizerConfigurationPropertyToTerraform(struct?: AwsAgentRuntime.AuthorizerConfigurationProperty | cdktn.IResolvable): any;
export declare function awsAgentRuntimeAuthorizerConfigurationPropertyToHclTerraform(struct?: AwsAgentRuntime.AuthorizerConfigurationProperty | cdktn.IResolvable): any;
export declare function awsAgentRuntimeEfsAccessPointPropertyToTerraform(struct?: AwsAgentRuntime.EfsAccessPointProperty | cdktn.IResolvable): any;
export declare function awsAgentRuntimeEfsAccessPointPropertyToHclTerraform(struct?: AwsAgentRuntime.EfsAccessPointProperty | cdktn.IResolvable): any;
export declare function awsAgentRuntimeS3FilesAccessPointPropertyToTerraform(struct?: AwsAgentRuntime.S3FilesAccessPointProperty | cdktn.IResolvable): any;
export declare function awsAgentRuntimeS3FilesAccessPointPropertyToHclTerraform(struct?: AwsAgentRuntime.S3FilesAccessPointProperty | cdktn.IResolvable): any;
export declare function awsAgentRuntimeSessionStoragePropertyToTerraform(struct?: AwsAgentRuntime.SessionStorageProperty | cdktn.IResolvable): any;
export declare function awsAgentRuntimeSessionStoragePropertyToHclTerraform(struct?: AwsAgentRuntime.SessionStorageProperty | cdktn.IResolvable): any;
export declare function awsAgentRuntimeFilesystemConfigurationPropertyToTerraform(struct?: AwsAgentRuntime.FilesystemConfigurationProperty | cdktn.IResolvable): any;
export declare function awsAgentRuntimeFilesystemConfigurationPropertyToHclTerraform(struct?: AwsAgentRuntime.FilesystemConfigurationProperty | cdktn.IResolvable): any;
export declare function awsAgentRuntimeNetworkModeConfigPropertyToTerraform(struct?: AwsAgentRuntime.NetworkModeConfigProperty | cdktn.IResolvable): any;
export declare function awsAgentRuntimeNetworkModeConfigPropertyToHclTerraform(struct?: AwsAgentRuntime.NetworkModeConfigProperty | cdktn.IResolvable): any;
export declare function awsAgentRuntimeNetworkConfigurationPropertyToTerraform(struct?: AwsAgentRuntime.NetworkConfigurationProperty | cdktn.IResolvable): any;
export declare function awsAgentRuntimeNetworkConfigurationPropertyToHclTerraform(struct?: AwsAgentRuntime.NetworkConfigurationProperty | cdktn.IResolvable): any;
export declare function awsAgentRuntimeProtocolConfigurationPropertyToTerraform(struct?: AwsAgentRuntime.ProtocolConfigurationProperty | cdktn.IResolvable): any;
export declare function awsAgentRuntimeProtocolConfigurationPropertyToHclTerraform(struct?: AwsAgentRuntime.ProtocolConfigurationProperty | cdktn.IResolvable): any;
export declare function awsAgentRuntimeRequestHeaderConfigurationPropertyToTerraform(struct?: AwsAgentRuntime.RequestHeaderConfigurationProperty | cdktn.IResolvable): any;
export declare function awsAgentRuntimeRequestHeaderConfigurationPropertyToHclTerraform(struct?: AwsAgentRuntime.RequestHeaderConfigurationProperty | cdktn.IResolvable): any;
export declare function awsAgentRuntimeTimeoutsPropertyToTerraform(struct?: AwsAgentRuntime.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsAgentRuntimeTimeoutsPropertyToHclTerraform(struct?: AwsAgentRuntime.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsAgentRuntime {
    interface LifecycleConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_agent_runtime#idle_runtime_session_timeout AwsAgentRuntime#idle_runtime_session_timeout}
        */
        readonly idleRuntimeSessionTimeout?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_agent_runtime#max_lifetime AwsAgentRuntime#max_lifetime}
        */
        readonly maxLifetime?: number;
    }
    class LifecycleConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): LifecycleConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: LifecycleConfigurationProperty | cdktn.IResolvable | undefined);
        private _idleRuntimeSessionTimeout?;
        get idleRuntimeSessionTimeout(): number;
        set idleRuntimeSessionTimeout(value: number);
        resetIdleRuntimeSessionTimeout(): void;
        get idleRuntimeSessionTimeoutInput(): number | undefined;
        private _maxLifetime?;
        get maxLifetime(): number;
        set maxLifetime(value: number);
        resetMaxLifetime(): void;
        get maxLifetimeInput(): number | undefined;
    }
    class LifecycleConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: LifecycleConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): LifecycleConfigurationPropertyOutputReference;
    }
    interface WorkloadIdentityDetailsProperty {
    }
    class WorkloadIdentityDetailsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkloadIdentityDetailsProperty | undefined;
        set internalValue(value: WorkloadIdentityDetailsProperty | undefined);
        get workloadIdentityArn(): string;
    }
    class WorkloadIdentityDetailsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkloadIdentityDetailsPropertyOutputReference;
    }
    interface S3Property {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_agent_runtime#bucket AwsAgentRuntime#bucket}
        */
        readonly bucket: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_agent_runtime#prefix AwsAgentRuntime#prefix}
        */
        readonly prefix: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_agent_runtime#version_id AwsAgentRuntime#version_id}
        */
        readonly versionId?: string;
    }
    class S3PropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): S3Property | cdktn.IResolvable | undefined;
        set internalValue(value: S3Property | cdktn.IResolvable | undefined);
        private _bucket?;
        get bucket(): string;
        set bucket(value: string);
        get bucketInput(): string | undefined;
        private _prefix?;
        get prefix(): string;
        set prefix(value: string);
        get prefixInput(): string | undefined;
        private _versionId?;
        get versionId(): string;
        set versionId(value: string);
        resetVersionId(): void;
        get versionIdInput(): string | undefined;
    }
    class S3PropertyList extends cdktn.ComplexList {
        internalValue?: S3Property[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): S3PropertyOutputReference;
    }
    interface CodeProperty {
        /**
        * s3 block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_agent_runtime#s3 AwsAgentRuntime#s3}
        */
        readonly s3?: S3Property[] | cdktn.IResolvable;
    }
    class CodePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CodeProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CodeProperty | cdktn.IResolvable | undefined);
        private _s3;
        get s3(): S3PropertyList;
        putS3(value: S3Property[] | cdktn.IResolvable): void;
        resetS3(): void;
        get s3Input(): cdktn.IResolvable | S3Property[] | undefined;
    }
    class CodePropertyList extends cdktn.ComplexList {
        internalValue?: CodeProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CodePropertyOutputReference;
    }
    interface CodeConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_agent_runtime#entry_point AwsAgentRuntime#entry_point}
        */
        readonly entryPoint: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_agent_runtime#runtime AwsAgentRuntime#runtime}
        */
        readonly runtime: string;
        /**
        * code block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_agent_runtime#code AwsAgentRuntime#code}
        */
        readonly code?: CodeProperty[] | cdktn.IResolvable;
    }
    class CodeConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CodeConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CodeConfigurationProperty | cdktn.IResolvable | undefined);
        private _entryPoint?;
        get entryPoint(): string[];
        set entryPoint(value: string[]);
        get entryPointInput(): string[] | undefined;
        private _runtime?;
        get runtime(): string;
        set runtime(value: string);
        get runtimeInput(): string | undefined;
        private _code;
        get code(): CodePropertyList;
        putCode(value: CodeProperty[] | cdktn.IResolvable): void;
        resetCode(): void;
        get codeInput(): cdktn.IResolvable | CodeProperty[] | undefined;
    }
    class CodeConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: CodeConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CodeConfigurationPropertyOutputReference;
    }
    interface ContainerConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_agent_runtime#container_uri AwsAgentRuntime#container_uri}
        */
        readonly containerUri: string;
    }
    class ContainerConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ContainerConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ContainerConfigurationProperty | cdktn.IResolvable | undefined);
        private _containerUri?;
        get containerUri(): string;
        set containerUri(value: string);
        get containerUriInput(): string | undefined;
    }
    class ContainerConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: ContainerConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ContainerConfigurationPropertyOutputReference;
    }
    interface AgentRuntimeArtifactProperty {
        /**
        * code_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_agent_runtime#code_configuration AwsAgentRuntime#code_configuration}
        */
        readonly codeConfiguration?: CodeConfigurationProperty[] | cdktn.IResolvable;
        /**
        * container_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_agent_runtime#container_configuration AwsAgentRuntime#container_configuration}
        */
        readonly containerConfiguration?: ContainerConfigurationProperty[] | cdktn.IResolvable;
    }
    class AgentRuntimeArtifactPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AgentRuntimeArtifactProperty | cdktn.IResolvable | undefined;
        set internalValue(value: AgentRuntimeArtifactProperty | cdktn.IResolvable | undefined);
        private _codeConfiguration;
        get codeConfiguration(): CodeConfigurationPropertyList;
        putCodeConfiguration(value: CodeConfigurationProperty[] | cdktn.IResolvable): void;
        resetCodeConfiguration(): void;
        get codeConfigurationInput(): cdktn.IResolvable | CodeConfigurationProperty[] | undefined;
        private _containerConfiguration;
        get containerConfiguration(): ContainerConfigurationPropertyList;
        putContainerConfiguration(value: ContainerConfigurationProperty[] | cdktn.IResolvable): void;
        resetContainerConfiguration(): void;
        get containerConfigurationInput(): cdktn.IResolvable | ContainerConfigurationProperty[] | undefined;
    }
    class AgentRuntimeArtifactPropertyList extends cdktn.ComplexList {
        internalValue?: AgentRuntimeArtifactProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AgentRuntimeArtifactPropertyOutputReference;
    }
    interface HostingEnvironmentProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_agent_runtime#arn AwsAgentRuntime#arn}
        */
        readonly arn: string;
    }
    class HostingEnvironmentPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): HostingEnvironmentProperty | cdktn.IResolvable | undefined;
        set internalValue(value: HostingEnvironmentProperty | cdktn.IResolvable | undefined);
        private _arn?;
        get arn(): string;
        set arn(value: string);
        get arnInput(): string | undefined;
    }
    class HostingEnvironmentPropertyList extends cdktn.ComplexList {
        internalValue?: HostingEnvironmentProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): HostingEnvironmentPropertyOutputReference;
    }
    interface AllowedWorkloadConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_agent_runtime#workload_identities AwsAgentRuntime#workload_identities}
        */
        readonly workloadIdentities?: string[];
        /**
        * hosting_environment block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_agent_runtime#hosting_environment AwsAgentRuntime#hosting_environment}
        */
        readonly hostingEnvironment?: HostingEnvironmentProperty[] | cdktn.IResolvable;
    }
    class AllowedWorkloadConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AllowedWorkloadConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: AllowedWorkloadConfigurationProperty | cdktn.IResolvable | undefined);
        private _workloadIdentities?;
        get workloadIdentities(): string[];
        set workloadIdentities(value: string[]);
        resetWorkloadIdentities(): void;
        get workloadIdentitiesInput(): string[] | undefined;
        private _hostingEnvironment;
        get hostingEnvironment(): HostingEnvironmentPropertyList;
        putHostingEnvironment(value: HostingEnvironmentProperty[] | cdktn.IResolvable): void;
        resetHostingEnvironment(): void;
        get hostingEnvironmentInput(): cdktn.IResolvable | HostingEnvironmentProperty[] | undefined;
    }
    class AllowedWorkloadConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: AllowedWorkloadConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AllowedWorkloadConfigurationPropertyOutputReference;
    }
    interface ClaimMatchValueProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_agent_runtime#match_value_string AwsAgentRuntime#match_value_string}
        */
        readonly matchValueString?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_agent_runtime#match_value_string_list AwsAgentRuntime#match_value_string_list}
        */
        readonly matchValueStringList?: string[];
    }
    class ClaimMatchValuePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ClaimMatchValueProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ClaimMatchValueProperty | cdktn.IResolvable | undefined);
        private _matchValueString?;
        get matchValueString(): string;
        set matchValueString(value: string);
        resetMatchValueString(): void;
        get matchValueStringInput(): string | undefined;
        private _matchValueStringList?;
        get matchValueStringList(): string[];
        set matchValueStringList(value: string[]);
        resetMatchValueStringList(): void;
        get matchValueStringListInput(): string[] | undefined;
    }
    class ClaimMatchValuePropertyList extends cdktn.ComplexList {
        internalValue?: ClaimMatchValueProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ClaimMatchValuePropertyOutputReference;
    }
    interface AuthorizingClaimMatchValueProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_agent_runtime#claim_match_operator AwsAgentRuntime#claim_match_operator}
        */
        readonly claimMatchOperator: string;
        /**
        * claim_match_value block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_agent_runtime#claim_match_value AwsAgentRuntime#claim_match_value}
        */
        readonly claimMatchValue?: ClaimMatchValueProperty[] | cdktn.IResolvable;
    }
    class AuthorizingClaimMatchValuePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AuthorizingClaimMatchValueProperty | cdktn.IResolvable | undefined;
        set internalValue(value: AuthorizingClaimMatchValueProperty | cdktn.IResolvable | undefined);
        private _claimMatchOperator?;
        get claimMatchOperator(): string;
        set claimMatchOperator(value: string);
        get claimMatchOperatorInput(): string | undefined;
        private _claimMatchValue;
        get claimMatchValue(): ClaimMatchValuePropertyList;
        putClaimMatchValue(value: ClaimMatchValueProperty[] | cdktn.IResolvable): void;
        resetClaimMatchValue(): void;
        get claimMatchValueInput(): cdktn.IResolvable | ClaimMatchValueProperty[] | undefined;
    }
    class AuthorizingClaimMatchValuePropertyList extends cdktn.ComplexList {
        internalValue?: AuthorizingClaimMatchValueProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AuthorizingClaimMatchValuePropertyOutputReference;
    }
    interface CustomClaimProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_agent_runtime#inbound_token_claim_name AwsAgentRuntime#inbound_token_claim_name}
        */
        readonly inboundTokenClaimName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_agent_runtime#inbound_token_claim_value_type AwsAgentRuntime#inbound_token_claim_value_type}
        */
        readonly inboundTokenClaimValueType: string;
        /**
        * authorizing_claim_match_value block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_agent_runtime#authorizing_claim_match_value AwsAgentRuntime#authorizing_claim_match_value}
        */
        readonly authorizingClaimMatchValue?: AuthorizingClaimMatchValueProperty[] | cdktn.IResolvable;
    }
    class CustomClaimPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CustomClaimProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CustomClaimProperty | cdktn.IResolvable | undefined);
        private _inboundTokenClaimName?;
        get inboundTokenClaimName(): string;
        set inboundTokenClaimName(value: string);
        get inboundTokenClaimNameInput(): string | undefined;
        private _inboundTokenClaimValueType?;
        get inboundTokenClaimValueType(): string;
        set inboundTokenClaimValueType(value: string);
        get inboundTokenClaimValueTypeInput(): string | undefined;
        private _authorizingClaimMatchValue;
        get authorizingClaimMatchValue(): AuthorizingClaimMatchValuePropertyList;
        putAuthorizingClaimMatchValue(value: AuthorizingClaimMatchValueProperty[] | cdktn.IResolvable): void;
        resetAuthorizingClaimMatchValue(): void;
        get authorizingClaimMatchValueInput(): cdktn.IResolvable | AuthorizingClaimMatchValueProperty[] | undefined;
    }
    class CustomClaimPropertyList extends cdktn.ComplexList {
        internalValue?: CustomClaimProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CustomClaimPropertyOutputReference;
    }
    interface AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointManagedVpcResourceProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_agent_runtime#endpoint_ip_address_type AwsAgentRuntime#endpoint_ip_address_type}
        */
        readonly endpointIpAddressType: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_agent_runtime#routing_domain AwsAgentRuntime#routing_domain}
        */
        readonly routingDomain?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_agent_runtime#security_group_ids AwsAgentRuntime#security_group_ids}
        */
        readonly securityGroupIds?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_agent_runtime#subnet_ids AwsAgentRuntime#subnet_ids}
        */
        readonly subnetIds: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_agent_runtime#tags AwsAgentRuntime#tags}
        */
        readonly tags?: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_agent_runtime#vpc_identifier AwsAgentRuntime#vpc_identifier}
        */
        readonly vpcIdentifier: string;
    }
    class AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointManagedVpcResourcePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointManagedVpcResourceProperty | cdktn.IResolvable | undefined;
        set internalValue(value: AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointManagedVpcResourceProperty | cdktn.IResolvable | undefined);
        private _endpointIpAddressType?;
        get endpointIpAddressType(): string;
        set endpointIpAddressType(value: string);
        get endpointIpAddressTypeInput(): string | undefined;
        private _routingDomain?;
        get routingDomain(): string;
        set routingDomain(value: string);
        resetRoutingDomain(): void;
        get routingDomainInput(): string | undefined;
        private _securityGroupIds?;
        get securityGroupIds(): string[];
        set securityGroupIds(value: string[]);
        resetSecurityGroupIds(): void;
        get securityGroupIdsInput(): string[] | undefined;
        private _subnetIds?;
        get subnetIds(): string[];
        set subnetIds(value: string[]);
        get subnetIdsInput(): string[] | undefined;
        private _tags?;
        get tags(): {
            [key: string]: string;
        };
        set tags(value: {
            [key: string]: string;
        });
        resetTags(): void;
        get tagsInput(): {
            [key: string]: string;
        } | undefined;
        private _vpcIdentifier?;
        get vpcIdentifier(): string;
        set vpcIdentifier(value: string);
        get vpcIdentifierInput(): string | undefined;
    }
    class AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointManagedVpcResourcePropertyList extends cdktn.ComplexList {
        internalValue?: AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointManagedVpcResourceProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointManagedVpcResourcePropertyOutputReference;
    }
    interface AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointSelfManagedLatticeResourceProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_agent_runtime#resource_configuration_identifier AwsAgentRuntime#resource_configuration_identifier}
        */
        readonly resourceConfigurationIdentifier: string;
    }
    class AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointSelfManagedLatticeResourcePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointSelfManagedLatticeResourceProperty | cdktn.IResolvable | undefined;
        set internalValue(value: AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointSelfManagedLatticeResourceProperty | cdktn.IResolvable | undefined);
        private _resourceConfigurationIdentifier?;
        get resourceConfigurationIdentifier(): string;
        set resourceConfigurationIdentifier(value: string);
        get resourceConfigurationIdentifierInput(): string | undefined;
    }
    class AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointSelfManagedLatticeResourcePropertyList extends cdktn.ComplexList {
        internalValue?: AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointSelfManagedLatticeResourceProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointSelfManagedLatticeResourcePropertyOutputReference;
    }
    interface AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointProperty {
        /**
        * managed_vpc_resource block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_agent_runtime#managed_vpc_resource AwsAgentRuntime#managed_vpc_resource}
        */
        readonly managedVpcResource?: AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointManagedVpcResourceProperty[] | cdktn.IResolvable;
        /**
        * self_managed_lattice_resource block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_agent_runtime#self_managed_lattice_resource AwsAgentRuntime#self_managed_lattice_resource}
        */
        readonly selfManagedLatticeResource?: AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointSelfManagedLatticeResourceProperty[] | cdktn.IResolvable;
    }
    class AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointProperty | cdktn.IResolvable | undefined;
        set internalValue(value: AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointProperty | cdktn.IResolvable | undefined);
        private _managedVpcResource;
        get managedVpcResource(): AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointManagedVpcResourcePropertyList;
        putManagedVpcResource(value: AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointManagedVpcResourceProperty[] | cdktn.IResolvable): void;
        resetManagedVpcResource(): void;
        get managedVpcResourceInput(): cdktn.IResolvable | AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointManagedVpcResourceProperty[] | undefined;
        private _selfManagedLatticeResource;
        get selfManagedLatticeResource(): AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointSelfManagedLatticeResourcePropertyList;
        putSelfManagedLatticeResource(value: AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointSelfManagedLatticeResourceProperty[] | cdktn.IResolvable): void;
        resetSelfManagedLatticeResource(): void;
        get selfManagedLatticeResourceInput(): cdktn.IResolvable | AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointSelfManagedLatticeResourceProperty[] | undefined;
    }
    class AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointPropertyList extends cdktn.ComplexList {
        internalValue?: AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointPropertyOutputReference;
    }
    interface AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointManagedVpcResourceProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_agent_runtime#endpoint_ip_address_type AwsAgentRuntime#endpoint_ip_address_type}
        */
        readonly endpointIpAddressType: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_agent_runtime#routing_domain AwsAgentRuntime#routing_domain}
        */
        readonly routingDomain?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_agent_runtime#security_group_ids AwsAgentRuntime#security_group_ids}
        */
        readonly securityGroupIds?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_agent_runtime#subnet_ids AwsAgentRuntime#subnet_ids}
        */
        readonly subnetIds: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_agent_runtime#tags AwsAgentRuntime#tags}
        */
        readonly tags?: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_agent_runtime#vpc_identifier AwsAgentRuntime#vpc_identifier}
        */
        readonly vpcIdentifier: string;
    }
    class AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointManagedVpcResourcePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointManagedVpcResourceProperty | cdktn.IResolvable | undefined;
        set internalValue(value: AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointManagedVpcResourceProperty | cdktn.IResolvable | undefined);
        private _endpointIpAddressType?;
        get endpointIpAddressType(): string;
        set endpointIpAddressType(value: string);
        get endpointIpAddressTypeInput(): string | undefined;
        private _routingDomain?;
        get routingDomain(): string;
        set routingDomain(value: string);
        resetRoutingDomain(): void;
        get routingDomainInput(): string | undefined;
        private _securityGroupIds?;
        get securityGroupIds(): string[];
        set securityGroupIds(value: string[]);
        resetSecurityGroupIds(): void;
        get securityGroupIdsInput(): string[] | undefined;
        private _subnetIds?;
        get subnetIds(): string[];
        set subnetIds(value: string[]);
        get subnetIdsInput(): string[] | undefined;
        private _tags?;
        get tags(): {
            [key: string]: string;
        };
        set tags(value: {
            [key: string]: string;
        });
        resetTags(): void;
        get tagsInput(): {
            [key: string]: string;
        } | undefined;
        private _vpcIdentifier?;
        get vpcIdentifier(): string;
        set vpcIdentifier(value: string);
        get vpcIdentifierInput(): string | undefined;
    }
    class AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointManagedVpcResourcePropertyList extends cdktn.ComplexList {
        internalValue?: AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointManagedVpcResourceProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointManagedVpcResourcePropertyOutputReference;
    }
    interface AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointSelfManagedLatticeResourceProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_agent_runtime#resource_configuration_identifier AwsAgentRuntime#resource_configuration_identifier}
        */
        readonly resourceConfigurationIdentifier: string;
    }
    class AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointSelfManagedLatticeResourcePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointSelfManagedLatticeResourceProperty | cdktn.IResolvable | undefined;
        set internalValue(value: AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointSelfManagedLatticeResourceProperty | cdktn.IResolvable | undefined);
        private _resourceConfigurationIdentifier?;
        get resourceConfigurationIdentifier(): string;
        set resourceConfigurationIdentifier(value: string);
        get resourceConfigurationIdentifierInput(): string | undefined;
    }
    class AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointSelfManagedLatticeResourcePropertyList extends cdktn.ComplexList {
        internalValue?: AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointSelfManagedLatticeResourceProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointSelfManagedLatticeResourcePropertyOutputReference;
    }
    interface AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointProperty {
        /**
        * managed_vpc_resource block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_agent_runtime#managed_vpc_resource AwsAgentRuntime#managed_vpc_resource}
        */
        readonly managedVpcResource?: AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointManagedVpcResourceProperty[] | cdktn.IResolvable;
        /**
        * self_managed_lattice_resource block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_agent_runtime#self_managed_lattice_resource AwsAgentRuntime#self_managed_lattice_resource}
        */
        readonly selfManagedLatticeResource?: AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointSelfManagedLatticeResourceProperty[] | cdktn.IResolvable;
    }
    class AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointProperty | cdktn.IResolvable | undefined;
        set internalValue(value: AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointProperty | cdktn.IResolvable | undefined);
        private _managedVpcResource;
        get managedVpcResource(): AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointManagedVpcResourcePropertyList;
        putManagedVpcResource(value: AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointManagedVpcResourceProperty[] | cdktn.IResolvable): void;
        resetManagedVpcResource(): void;
        get managedVpcResourceInput(): cdktn.IResolvable | AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointManagedVpcResourceProperty[] | undefined;
        private _selfManagedLatticeResource;
        get selfManagedLatticeResource(): AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointSelfManagedLatticeResourcePropertyList;
        putSelfManagedLatticeResource(value: AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointSelfManagedLatticeResourceProperty[] | cdktn.IResolvable): void;
        resetSelfManagedLatticeResource(): void;
        get selfManagedLatticeResourceInput(): cdktn.IResolvable | AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointSelfManagedLatticeResourceProperty[] | undefined;
    }
    class AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointPropertyList extends cdktn.ComplexList {
        internalValue?: AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointPropertyOutputReference;
    }
    interface PrivateEndpointOverridesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_agent_runtime#domain AwsAgentRuntime#domain}
        */
        readonly domain: string;
        /**
        * private_endpoint block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_agent_runtime#private_endpoint AwsAgentRuntime#private_endpoint}
        */
        readonly privateEndpoint?: AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointProperty[] | cdktn.IResolvable;
    }
    class PrivateEndpointOverridesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): PrivateEndpointOverridesProperty | cdktn.IResolvable | undefined;
        set internalValue(value: PrivateEndpointOverridesProperty | cdktn.IResolvable | undefined);
        private _domain?;
        get domain(): string;
        set domain(value: string);
        get domainInput(): string | undefined;
        private _privateEndpoint;
        get privateEndpoint(): AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointPropertyList;
        putPrivateEndpoint(value: AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointProperty[] | cdktn.IResolvable): void;
        resetPrivateEndpoint(): void;
        get privateEndpointInput(): cdktn.IResolvable | AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointProperty[] | undefined;
    }
    class PrivateEndpointOverridesPropertyList extends cdktn.ComplexList {
        internalValue?: PrivateEndpointOverridesProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): PrivateEndpointOverridesPropertyOutputReference;
    }
    interface CustomJwtAuthorizerProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_agent_runtime#allowed_audience AwsAgentRuntime#allowed_audience}
        */
        readonly allowedAudience?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_agent_runtime#allowed_clients AwsAgentRuntime#allowed_clients}
        */
        readonly allowedClients?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_agent_runtime#allowed_scopes AwsAgentRuntime#allowed_scopes}
        */
        readonly allowedScopes?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_agent_runtime#discovery_url AwsAgentRuntime#discovery_url}
        */
        readonly discoveryUrl: string;
        /**
        * allowed_workload_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_agent_runtime#allowed_workload_configuration AwsAgentRuntime#allowed_workload_configuration}
        */
        readonly allowedWorkloadConfiguration?: AllowedWorkloadConfigurationProperty[] | cdktn.IResolvable;
        /**
        * custom_claim block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_agent_runtime#custom_claim AwsAgentRuntime#custom_claim}
        */
        readonly customClaim?: CustomClaimProperty[] | cdktn.IResolvable;
        /**
        * private_endpoint block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_agent_runtime#private_endpoint AwsAgentRuntime#private_endpoint}
        */
        readonly privateEndpoint?: AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointProperty[] | cdktn.IResolvable;
        /**
        * private_endpoint_overrides block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_agent_runtime#private_endpoint_overrides AwsAgentRuntime#private_endpoint_overrides}
        */
        readonly privateEndpointOverrides?: PrivateEndpointOverridesProperty[] | cdktn.IResolvable;
    }
    class CustomJwtAuthorizerPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CustomJwtAuthorizerProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CustomJwtAuthorizerProperty | cdktn.IResolvable | undefined);
        private _allowedAudience?;
        get allowedAudience(): string[];
        set allowedAudience(value: string[]);
        resetAllowedAudience(): void;
        get allowedAudienceInput(): string[] | undefined;
        private _allowedClients?;
        get allowedClients(): string[];
        set allowedClients(value: string[]);
        resetAllowedClients(): void;
        get allowedClientsInput(): string[] | undefined;
        private _allowedScopes?;
        get allowedScopes(): string[];
        set allowedScopes(value: string[]);
        resetAllowedScopes(): void;
        get allowedScopesInput(): string[] | undefined;
        private _discoveryUrl?;
        get discoveryUrl(): string;
        set discoveryUrl(value: string);
        get discoveryUrlInput(): string | undefined;
        private _allowedWorkloadConfiguration;
        get allowedWorkloadConfiguration(): AllowedWorkloadConfigurationPropertyList;
        putAllowedWorkloadConfiguration(value: AllowedWorkloadConfigurationProperty[] | cdktn.IResolvable): void;
        resetAllowedWorkloadConfiguration(): void;
        get allowedWorkloadConfigurationInput(): cdktn.IResolvable | AllowedWorkloadConfigurationProperty[] | undefined;
        private _customClaim;
        get customClaim(): CustomClaimPropertyList;
        putCustomClaim(value: CustomClaimProperty[] | cdktn.IResolvable): void;
        resetCustomClaim(): void;
        get customClaimInput(): cdktn.IResolvable | CustomClaimProperty[] | undefined;
        private _privateEndpoint;
        get privateEndpoint(): AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointPropertyList;
        putPrivateEndpoint(value: AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointProperty[] | cdktn.IResolvable): void;
        resetPrivateEndpoint(): void;
        get privateEndpointInput(): cdktn.IResolvable | AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointProperty[] | undefined;
        private _privateEndpointOverrides;
        get privateEndpointOverrides(): PrivateEndpointOverridesPropertyList;
        putPrivateEndpointOverrides(value: PrivateEndpointOverridesProperty[] | cdktn.IResolvable): void;
        resetPrivateEndpointOverrides(): void;
        get privateEndpointOverridesInput(): cdktn.IResolvable | PrivateEndpointOverridesProperty[] | undefined;
    }
    class CustomJwtAuthorizerPropertyList extends cdktn.ComplexList {
        internalValue?: CustomJwtAuthorizerProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CustomJwtAuthorizerPropertyOutputReference;
    }
    interface AuthorizerConfigurationProperty {
        /**
        * custom_jwt_authorizer block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_agent_runtime#custom_jwt_authorizer AwsAgentRuntime#custom_jwt_authorizer}
        */
        readonly customJwtAuthorizer?: CustomJwtAuthorizerProperty[] | cdktn.IResolvable;
    }
    class AuthorizerConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AuthorizerConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: AuthorizerConfigurationProperty | cdktn.IResolvable | undefined);
        private _customJwtAuthorizer;
        get customJwtAuthorizer(): CustomJwtAuthorizerPropertyList;
        putCustomJwtAuthorizer(value: CustomJwtAuthorizerProperty[] | cdktn.IResolvable): void;
        resetCustomJwtAuthorizer(): void;
        get customJwtAuthorizerInput(): cdktn.IResolvable | CustomJwtAuthorizerProperty[] | undefined;
    }
    class AuthorizerConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: AuthorizerConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AuthorizerConfigurationPropertyOutputReference;
    }
    interface EfsAccessPointProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_agent_runtime#access_point_arn AwsAgentRuntime#access_point_arn}
        */
        readonly accessPointArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_agent_runtime#mount_path AwsAgentRuntime#mount_path}
        */
        readonly mountPath: string;
    }
    class EfsAccessPointPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EfsAccessPointProperty | cdktn.IResolvable | undefined;
        set internalValue(value: EfsAccessPointProperty | cdktn.IResolvable | undefined);
        private _accessPointArn?;
        get accessPointArn(): string;
        set accessPointArn(value: string);
        get accessPointArnInput(): string | undefined;
        private _mountPath?;
        get mountPath(): string;
        set mountPath(value: string);
        get mountPathInput(): string | undefined;
    }
    class EfsAccessPointPropertyList extends cdktn.ComplexList {
        internalValue?: EfsAccessPointProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EfsAccessPointPropertyOutputReference;
    }
    interface S3FilesAccessPointProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_agent_runtime#access_point_arn AwsAgentRuntime#access_point_arn}
        */
        readonly accessPointArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_agent_runtime#mount_path AwsAgentRuntime#mount_path}
        */
        readonly mountPath: string;
    }
    class S3FilesAccessPointPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): S3FilesAccessPointProperty | cdktn.IResolvable | undefined;
        set internalValue(value: S3FilesAccessPointProperty | cdktn.IResolvable | undefined);
        private _accessPointArn?;
        get accessPointArn(): string;
        set accessPointArn(value: string);
        get accessPointArnInput(): string | undefined;
        private _mountPath?;
        get mountPath(): string;
        set mountPath(value: string);
        get mountPathInput(): string | undefined;
    }
    class S3FilesAccessPointPropertyList extends cdktn.ComplexList {
        internalValue?: S3FilesAccessPointProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): S3FilesAccessPointPropertyOutputReference;
    }
    interface SessionStorageProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_agent_runtime#mount_path AwsAgentRuntime#mount_path}
        */
        readonly mountPath: string;
    }
    class SessionStoragePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SessionStorageProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SessionStorageProperty | cdktn.IResolvable | undefined);
        private _mountPath?;
        get mountPath(): string;
        set mountPath(value: string);
        get mountPathInput(): string | undefined;
    }
    class SessionStoragePropertyList extends cdktn.ComplexList {
        internalValue?: SessionStorageProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SessionStoragePropertyOutputReference;
    }
    interface FilesystemConfigurationProperty {
        /**
        * efs_access_point block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_agent_runtime#efs_access_point AwsAgentRuntime#efs_access_point}
        */
        readonly efsAccessPoint?: EfsAccessPointProperty[] | cdktn.IResolvable;
        /**
        * s3_files_access_point block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_agent_runtime#s3_files_access_point AwsAgentRuntime#s3_files_access_point}
        */
        readonly s3FilesAccessPoint?: S3FilesAccessPointProperty[] | cdktn.IResolvable;
        /**
        * session_storage block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_agent_runtime#session_storage AwsAgentRuntime#session_storage}
        */
        readonly sessionStorage?: SessionStorageProperty[] | cdktn.IResolvable;
    }
    class FilesystemConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): FilesystemConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: FilesystemConfigurationProperty | cdktn.IResolvable | undefined);
        private _efsAccessPoint;
        get efsAccessPoint(): EfsAccessPointPropertyList;
        putEfsAccessPoint(value: EfsAccessPointProperty[] | cdktn.IResolvable): void;
        resetEfsAccessPoint(): void;
        get efsAccessPointInput(): cdktn.IResolvable | EfsAccessPointProperty[] | undefined;
        private _s3FilesAccessPoint;
        get s3FilesAccessPoint(): S3FilesAccessPointPropertyList;
        putS3FilesAccessPoint(value: S3FilesAccessPointProperty[] | cdktn.IResolvable): void;
        resetS3FilesAccessPoint(): void;
        get s3FilesAccessPointInput(): cdktn.IResolvable | S3FilesAccessPointProperty[] | undefined;
        private _sessionStorage;
        get sessionStorage(): SessionStoragePropertyList;
        putSessionStorage(value: SessionStorageProperty[] | cdktn.IResolvable): void;
        resetSessionStorage(): void;
        get sessionStorageInput(): cdktn.IResolvable | SessionStorageProperty[] | undefined;
    }
    class FilesystemConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: FilesystemConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): FilesystemConfigurationPropertyOutputReference;
    }
    interface NetworkModeConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_agent_runtime#security_groups AwsAgentRuntime#security_groups}
        */
        readonly securityGroups: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_agent_runtime#subnets AwsAgentRuntime#subnets}
        */
        readonly subnets: string[];
    }
    class NetworkModeConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): NetworkModeConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: NetworkModeConfigProperty | cdktn.IResolvable | undefined);
        get requireServiceS3Endpoint(): cdktn.IResolvable;
        private _securityGroups?;
        get securityGroups(): string[];
        set securityGroups(value: string[]);
        get securityGroupsInput(): string[] | undefined;
        private _subnets?;
        get subnets(): string[];
        set subnets(value: string[]);
        get subnetsInput(): string[] | undefined;
    }
    class NetworkModeConfigPropertyList extends cdktn.ComplexList {
        internalValue?: NetworkModeConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): NetworkModeConfigPropertyOutputReference;
    }
    interface NetworkConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_agent_runtime#network_mode AwsAgentRuntime#network_mode}
        */
        readonly networkMode: string;
        /**
        * network_mode_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_agent_runtime#network_mode_config AwsAgentRuntime#network_mode_config}
        */
        readonly networkModeConfig?: NetworkModeConfigProperty[] | cdktn.IResolvable;
    }
    class NetworkConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): NetworkConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: NetworkConfigurationProperty | cdktn.IResolvable | undefined);
        private _networkMode?;
        get networkMode(): string;
        set networkMode(value: string);
        get networkModeInput(): string | undefined;
        private _networkModeConfig;
        get networkModeConfig(): NetworkModeConfigPropertyList;
        putNetworkModeConfig(value: NetworkModeConfigProperty[] | cdktn.IResolvable): void;
        resetNetworkModeConfig(): void;
        get networkModeConfigInput(): cdktn.IResolvable | NetworkModeConfigProperty[] | undefined;
    }
    class NetworkConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: NetworkConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): NetworkConfigurationPropertyOutputReference;
    }
    interface ProtocolConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_agent_runtime#server_protocol AwsAgentRuntime#server_protocol}
        */
        readonly serverProtocol?: string;
    }
    class ProtocolConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ProtocolConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ProtocolConfigurationProperty | cdktn.IResolvable | undefined);
        private _serverProtocol?;
        get serverProtocol(): string;
        set serverProtocol(value: string);
        resetServerProtocol(): void;
        get serverProtocolInput(): string | undefined;
    }
    class ProtocolConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: ProtocolConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ProtocolConfigurationPropertyOutputReference;
    }
    interface RequestHeaderConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_agent_runtime#request_header_allowlist AwsAgentRuntime#request_header_allowlist}
        */
        readonly requestHeaderAllowlist?: string[];
    }
    class RequestHeaderConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RequestHeaderConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RequestHeaderConfigurationProperty | cdktn.IResolvable | undefined);
        private _requestHeaderAllowlist?;
        get requestHeaderAllowlist(): string[];
        set requestHeaderAllowlist(value: string[]);
        resetRequestHeaderAllowlist(): void;
        get requestHeaderAllowlistInput(): string[] | undefined;
    }
    class RequestHeaderConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: RequestHeaderConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RequestHeaderConfigurationPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_agent_runtime#create AwsAgentRuntime#create}
        */
        readonly create?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Setting a timeout for a Delete operation is only applicable if changes are saved into state before the destroy operation occurs.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_agent_runtime#delete AwsAgentRuntime#delete}
        */
        readonly delete?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_agent_runtime#update AwsAgentRuntime#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
