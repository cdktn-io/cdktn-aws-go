import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsGatewayConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway#authorizer_type AwsGateway#authorizer_type}
    */
    readonly authorizerType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway#description AwsGateway#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway#exception_level AwsGateway#exception_level}
    */
    readonly exceptionLevel?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway#kms_key_arn AwsGateway#kms_key_arn}
    */
    readonly kmsKeyArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway#name AwsGateway#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway#protocol_type AwsGateway#protocol_type}
    */
    readonly protocolType?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway#region AwsGateway#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway#role_arn AwsGateway#role_arn}
    */
    readonly roleArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway#tags AwsGateway#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * authorizer_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway#authorizer_configuration AwsGateway#authorizer_configuration}
    */
    readonly authorizerConfiguration?: AwsGateway.AuthorizerConfigurationProperty[] | cdktn.IResolvable;
    /**
    * interceptor_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway#interceptor_configuration AwsGateway#interceptor_configuration}
    */
    readonly interceptorConfiguration?: AwsGateway.InterceptorConfigurationProperty[] | cdktn.IResolvable;
    /**
    * policy_engine_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway#policy_engine_configuration AwsGateway#policy_engine_configuration}
    */
    readonly policyEngineConfiguration?: AwsGateway.PolicyEngineConfigurationProperty[] | cdktn.IResolvable;
    /**
    * protocol_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway#protocol_configuration AwsGateway#protocol_configuration}
    */
    readonly protocolConfiguration?: AwsGateway.ProtocolConfigurationProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway#timeouts AwsGateway#timeouts}
    */
    readonly timeouts?: AwsGateway.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway aws_bedrockagentcore_gateway}
*/
export declare class AwsGateway extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_bedrockagentcore_gateway";
    /**
    * Generates CDKTN code for importing a AwsGateway resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsGateway to import
    * @param importFromId The id of the existing AwsGateway that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsGateway to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway aws_bedrockagentcore_gateway} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsGatewayConfig
    */
    constructor(scope: Construct, id: string, config: AwsGatewayConfig);
    private _authorizerType?;
    get authorizerType(): string;
    set authorizerType(value: string);
    get authorizerTypeInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _exceptionLevel?;
    get exceptionLevel(): string;
    set exceptionLevel(value: string);
    resetExceptionLevel(): void;
    get exceptionLevelInput(): string | undefined;
    get gatewayArn(): string;
    get gatewayId(): string;
    get gatewayUrl(): string;
    private _kmsKeyArn?;
    get kmsKeyArn(): string;
    set kmsKeyArn(value: string);
    resetKmsKeyArn(): void;
    get kmsKeyArnInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _protocolType?;
    get protocolType(): string;
    set protocolType(value: string);
    resetProtocolType(): void;
    get protocolTypeInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _roleArn?;
    get roleArn(): string;
    set roleArn(value: string);
    get roleArnInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    private _workloadIdentityDetails;
    get workloadIdentityDetails(): AwsGateway.WorkloadIdentityDetailsPropertyList;
    private _authorizerConfiguration;
    get authorizerConfiguration(): AwsGateway.AuthorizerConfigurationPropertyList;
    putAuthorizerConfiguration(value: AwsGateway.AuthorizerConfigurationProperty[] | cdktn.IResolvable): void;
    resetAuthorizerConfiguration(): void;
    get authorizerConfigurationInput(): cdktn.IResolvable | AwsGateway.AuthorizerConfigurationProperty[] | undefined;
    private _interceptorConfiguration;
    get interceptorConfiguration(): AwsGateway.InterceptorConfigurationPropertyList;
    putInterceptorConfiguration(value: AwsGateway.InterceptorConfigurationProperty[] | cdktn.IResolvable): void;
    resetInterceptorConfiguration(): void;
    get interceptorConfigurationInput(): cdktn.IResolvable | AwsGateway.InterceptorConfigurationProperty[] | undefined;
    private _policyEngineConfiguration;
    get policyEngineConfiguration(): AwsGateway.PolicyEngineConfigurationPropertyList;
    putPolicyEngineConfiguration(value: AwsGateway.PolicyEngineConfigurationProperty[] | cdktn.IResolvable): void;
    resetPolicyEngineConfiguration(): void;
    get policyEngineConfigurationInput(): cdktn.IResolvable | AwsGateway.PolicyEngineConfigurationProperty[] | undefined;
    private _protocolConfiguration;
    get protocolConfiguration(): AwsGateway.ProtocolConfigurationPropertyList;
    putProtocolConfiguration(value: AwsGateway.ProtocolConfigurationProperty[] | cdktn.IResolvable): void;
    resetProtocolConfiguration(): void;
    get protocolConfigurationInput(): cdktn.IResolvable | AwsGateway.ProtocolConfigurationProperty[] | undefined;
    private _timeouts;
    get timeouts(): AwsGateway.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsGateway.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsGateway.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsGatewayWorkloadIdentityDetailsPropertyToTerraform(struct?: AwsGateway.WorkloadIdentityDetailsProperty): any;
export declare function awsGatewayWorkloadIdentityDetailsPropertyToHclTerraform(struct?: AwsGateway.WorkloadIdentityDetailsProperty): any;
export declare function awsGatewayHostingEnvironmentPropertyToTerraform(struct?: AwsGateway.HostingEnvironmentProperty | cdktn.IResolvable): any;
export declare function awsGatewayHostingEnvironmentPropertyToHclTerraform(struct?: AwsGateway.HostingEnvironmentProperty | cdktn.IResolvable): any;
export declare function awsGatewayAllowedWorkloadConfigurationPropertyToTerraform(struct?: AwsGateway.AllowedWorkloadConfigurationProperty | cdktn.IResolvable): any;
export declare function awsGatewayAllowedWorkloadConfigurationPropertyToHclTerraform(struct?: AwsGateway.AllowedWorkloadConfigurationProperty | cdktn.IResolvable): any;
export declare function awsGatewayClaimMatchValuePropertyToTerraform(struct?: AwsGateway.ClaimMatchValueProperty | cdktn.IResolvable): any;
export declare function awsGatewayClaimMatchValuePropertyToHclTerraform(struct?: AwsGateway.ClaimMatchValueProperty | cdktn.IResolvable): any;
export declare function awsGatewayAuthorizingClaimMatchValuePropertyToTerraform(struct?: AwsGateway.AuthorizingClaimMatchValueProperty | cdktn.IResolvable): any;
export declare function awsGatewayAuthorizingClaimMatchValuePropertyToHclTerraform(struct?: AwsGateway.AuthorizingClaimMatchValueProperty | cdktn.IResolvable): any;
export declare function awsGatewayCustomClaimPropertyToTerraform(struct?: AwsGateway.CustomClaimProperty | cdktn.IResolvable): any;
export declare function awsGatewayCustomClaimPropertyToHclTerraform(struct?: AwsGateway.CustomClaimProperty | cdktn.IResolvable): any;
export declare function awsGatewayAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointManagedVpcResourcePropertyToTerraform(struct?: AwsGateway.AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointManagedVpcResourceProperty | cdktn.IResolvable): any;
export declare function awsGatewayAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointManagedVpcResourcePropertyToHclTerraform(struct?: AwsGateway.AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointManagedVpcResourceProperty | cdktn.IResolvable): any;
export declare function awsGatewayAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointSelfManagedLatticeResourcePropertyToTerraform(struct?: AwsGateway.AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointSelfManagedLatticeResourceProperty | cdktn.IResolvable): any;
export declare function awsGatewayAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointSelfManagedLatticeResourcePropertyToHclTerraform(struct?: AwsGateway.AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointSelfManagedLatticeResourceProperty | cdktn.IResolvable): any;
export declare function awsGatewayAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointPropertyToTerraform(struct?: AwsGateway.AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointProperty | cdktn.IResolvable): any;
export declare function awsGatewayAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointPropertyToHclTerraform(struct?: AwsGateway.AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointProperty | cdktn.IResolvable): any;
export declare function awsGatewayAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointManagedVpcResourcePropertyToTerraform(struct?: AwsGateway.AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointManagedVpcResourceProperty | cdktn.IResolvable): any;
export declare function awsGatewayAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointManagedVpcResourcePropertyToHclTerraform(struct?: AwsGateway.AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointManagedVpcResourceProperty | cdktn.IResolvable): any;
export declare function awsGatewayAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointSelfManagedLatticeResourcePropertyToTerraform(struct?: AwsGateway.AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointSelfManagedLatticeResourceProperty | cdktn.IResolvable): any;
export declare function awsGatewayAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointSelfManagedLatticeResourcePropertyToHclTerraform(struct?: AwsGateway.AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointSelfManagedLatticeResourceProperty | cdktn.IResolvable): any;
export declare function awsGatewayAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointPropertyToTerraform(struct?: AwsGateway.AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointProperty | cdktn.IResolvable): any;
export declare function awsGatewayAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointPropertyToHclTerraform(struct?: AwsGateway.AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointProperty | cdktn.IResolvable): any;
export declare function awsGatewayPrivateEndpointOverridesPropertyToTerraform(struct?: AwsGateway.PrivateEndpointOverridesProperty | cdktn.IResolvable): any;
export declare function awsGatewayPrivateEndpointOverridesPropertyToHclTerraform(struct?: AwsGateway.PrivateEndpointOverridesProperty | cdktn.IResolvable): any;
export declare function awsGatewayCustomJwtAuthorizerPropertyToTerraform(struct?: AwsGateway.CustomJwtAuthorizerProperty | cdktn.IResolvable): any;
export declare function awsGatewayCustomJwtAuthorizerPropertyToHclTerraform(struct?: AwsGateway.CustomJwtAuthorizerProperty | cdktn.IResolvable): any;
export declare function awsGatewayAuthorizerConfigurationPropertyToTerraform(struct?: AwsGateway.AuthorizerConfigurationProperty | cdktn.IResolvable): any;
export declare function awsGatewayAuthorizerConfigurationPropertyToHclTerraform(struct?: AwsGateway.AuthorizerConfigurationProperty | cdktn.IResolvable): any;
export declare function awsGatewayInputConfigurationPropertyToTerraform(struct?: AwsGateway.InputConfigurationProperty | cdktn.IResolvable): any;
export declare function awsGatewayInputConfigurationPropertyToHclTerraform(struct?: AwsGateway.InputConfigurationProperty | cdktn.IResolvable): any;
export declare function awsGatewayLambdaPropertyToTerraform(struct?: AwsGateway.LambdaProperty | cdktn.IResolvable): any;
export declare function awsGatewayLambdaPropertyToHclTerraform(struct?: AwsGateway.LambdaProperty | cdktn.IResolvable): any;
export declare function awsGatewayInterceptorPropertyToTerraform(struct?: AwsGateway.InterceptorProperty | cdktn.IResolvable): any;
export declare function awsGatewayInterceptorPropertyToHclTerraform(struct?: AwsGateway.InterceptorProperty | cdktn.IResolvable): any;
export declare function awsGatewayInterceptorConfigurationPropertyToTerraform(struct?: AwsGateway.InterceptorConfigurationProperty | cdktn.IResolvable): any;
export declare function awsGatewayInterceptorConfigurationPropertyToHclTerraform(struct?: AwsGateway.InterceptorConfigurationProperty | cdktn.IResolvable): any;
export declare function awsGatewayPolicyEngineConfigurationPropertyToTerraform(struct?: AwsGateway.PolicyEngineConfigurationProperty | cdktn.IResolvable): any;
export declare function awsGatewayPolicyEngineConfigurationPropertyToHclTerraform(struct?: AwsGateway.PolicyEngineConfigurationProperty | cdktn.IResolvable): any;
export declare function awsGatewaySessionConfigurationPropertyToTerraform(struct?: AwsGateway.SessionConfigurationProperty | cdktn.IResolvable): any;
export declare function awsGatewaySessionConfigurationPropertyToHclTerraform(struct?: AwsGateway.SessionConfigurationProperty | cdktn.IResolvable): any;
export declare function awsGatewayStreamingConfigurationPropertyToTerraform(struct?: AwsGateway.StreamingConfigurationProperty | cdktn.IResolvable): any;
export declare function awsGatewayStreamingConfigurationPropertyToHclTerraform(struct?: AwsGateway.StreamingConfigurationProperty | cdktn.IResolvable): any;
export declare function awsGatewayMcpPropertyToTerraform(struct?: AwsGateway.McpProperty | cdktn.IResolvable): any;
export declare function awsGatewayMcpPropertyToHclTerraform(struct?: AwsGateway.McpProperty | cdktn.IResolvable): any;
export declare function awsGatewayProtocolConfigurationPropertyToTerraform(struct?: AwsGateway.ProtocolConfigurationProperty | cdktn.IResolvable): any;
export declare function awsGatewayProtocolConfigurationPropertyToHclTerraform(struct?: AwsGateway.ProtocolConfigurationProperty | cdktn.IResolvable): any;
export declare function awsGatewayTimeoutsPropertyToTerraform(struct?: AwsGateway.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsGatewayTimeoutsPropertyToHclTerraform(struct?: AwsGateway.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsGateway {
    interface WorkloadIdentityDetailsProperty {
    }
    class WorkloadIdentityDetailsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkloadIdentityDetailsProperty | undefined;
        set internalValue(value: WorkloadIdentityDetailsProperty | undefined);
        get workloadIdentityArn(): string;
    }
    class WorkloadIdentityDetailsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkloadIdentityDetailsPropertyOutputReference;
    }
    interface HostingEnvironmentProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway#arn AwsGateway#arn}
        */
        readonly arn: string;
    }
    class HostingEnvironmentPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): HostingEnvironmentProperty | cdktn.IResolvable | undefined;
        set internalValue(value: HostingEnvironmentProperty | cdktn.IResolvable | undefined);
        private _arn?;
        get arn(): string;
        set arn(value: string);
        get arnInput(): string | undefined;
    }
    class HostingEnvironmentPropertyList extends cdktn.ComplexList {
        internalValue?: HostingEnvironmentProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): HostingEnvironmentPropertyOutputReference;
    }
    interface AllowedWorkloadConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway#workload_identities AwsGateway#workload_identities}
        */
        readonly workloadIdentities?: string[];
        /**
        * hosting_environment block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway#hosting_environment AwsGateway#hosting_environment}
        */
        readonly hostingEnvironment?: HostingEnvironmentProperty[] | cdktn.IResolvable;
    }
    class AllowedWorkloadConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AllowedWorkloadConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: AllowedWorkloadConfigurationProperty | cdktn.IResolvable | undefined);
        private _workloadIdentities?;
        get workloadIdentities(): string[];
        set workloadIdentities(value: string[]);
        resetWorkloadIdentities(): void;
        get workloadIdentitiesInput(): string[] | undefined;
        private _hostingEnvironment;
        get hostingEnvironment(): HostingEnvironmentPropertyList;
        putHostingEnvironment(value: HostingEnvironmentProperty[] | cdktn.IResolvable): void;
        resetHostingEnvironment(): void;
        get hostingEnvironmentInput(): cdktn.IResolvable | HostingEnvironmentProperty[] | undefined;
    }
    class AllowedWorkloadConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: AllowedWorkloadConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AllowedWorkloadConfigurationPropertyOutputReference;
    }
    interface ClaimMatchValueProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway#match_value_string AwsGateway#match_value_string}
        */
        readonly matchValueString?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway#match_value_string_list AwsGateway#match_value_string_list}
        */
        readonly matchValueStringList?: string[];
    }
    class ClaimMatchValuePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ClaimMatchValueProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ClaimMatchValueProperty | cdktn.IResolvable | undefined);
        private _matchValueString?;
        get matchValueString(): string;
        set matchValueString(value: string);
        resetMatchValueString(): void;
        get matchValueStringInput(): string | undefined;
        private _matchValueStringList?;
        get matchValueStringList(): string[];
        set matchValueStringList(value: string[]);
        resetMatchValueStringList(): void;
        get matchValueStringListInput(): string[] | undefined;
    }
    class ClaimMatchValuePropertyList extends cdktn.ComplexList {
        internalValue?: ClaimMatchValueProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ClaimMatchValuePropertyOutputReference;
    }
    interface AuthorizingClaimMatchValueProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway#claim_match_operator AwsGateway#claim_match_operator}
        */
        readonly claimMatchOperator: string;
        /**
        * claim_match_value block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway#claim_match_value AwsGateway#claim_match_value}
        */
        readonly claimMatchValue?: ClaimMatchValueProperty[] | cdktn.IResolvable;
    }
    class AuthorizingClaimMatchValuePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AuthorizingClaimMatchValueProperty | cdktn.IResolvable | undefined;
        set internalValue(value: AuthorizingClaimMatchValueProperty | cdktn.IResolvable | undefined);
        private _claimMatchOperator?;
        get claimMatchOperator(): string;
        set claimMatchOperator(value: string);
        get claimMatchOperatorInput(): string | undefined;
        private _claimMatchValue;
        get claimMatchValue(): ClaimMatchValuePropertyList;
        putClaimMatchValue(value: ClaimMatchValueProperty[] | cdktn.IResolvable): void;
        resetClaimMatchValue(): void;
        get claimMatchValueInput(): cdktn.IResolvable | ClaimMatchValueProperty[] | undefined;
    }
    class AuthorizingClaimMatchValuePropertyList extends cdktn.ComplexList {
        internalValue?: AuthorizingClaimMatchValueProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AuthorizingClaimMatchValuePropertyOutputReference;
    }
    interface CustomClaimProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway#inbound_token_claim_name AwsGateway#inbound_token_claim_name}
        */
        readonly inboundTokenClaimName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway#inbound_token_claim_value_type AwsGateway#inbound_token_claim_value_type}
        */
        readonly inboundTokenClaimValueType: string;
        /**
        * authorizing_claim_match_value block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway#authorizing_claim_match_value AwsGateway#authorizing_claim_match_value}
        */
        readonly authorizingClaimMatchValue?: AuthorizingClaimMatchValueProperty[] | cdktn.IResolvable;
    }
    class CustomClaimPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CustomClaimProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CustomClaimProperty | cdktn.IResolvable | undefined);
        private _inboundTokenClaimName?;
        get inboundTokenClaimName(): string;
        set inboundTokenClaimName(value: string);
        get inboundTokenClaimNameInput(): string | undefined;
        private _inboundTokenClaimValueType?;
        get inboundTokenClaimValueType(): string;
        set inboundTokenClaimValueType(value: string);
        get inboundTokenClaimValueTypeInput(): string | undefined;
        private _authorizingClaimMatchValue;
        get authorizingClaimMatchValue(): AuthorizingClaimMatchValuePropertyList;
        putAuthorizingClaimMatchValue(value: AuthorizingClaimMatchValueProperty[] | cdktn.IResolvable): void;
        resetAuthorizingClaimMatchValue(): void;
        get authorizingClaimMatchValueInput(): cdktn.IResolvable | AuthorizingClaimMatchValueProperty[] | undefined;
    }
    class CustomClaimPropertyList extends cdktn.ComplexList {
        internalValue?: CustomClaimProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CustomClaimPropertyOutputReference;
    }
    interface AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointManagedVpcResourceProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway#endpoint_ip_address_type AwsGateway#endpoint_ip_address_type}
        */
        readonly endpointIpAddressType: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway#routing_domain AwsGateway#routing_domain}
        */
        readonly routingDomain?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway#security_group_ids AwsGateway#security_group_ids}
        */
        readonly securityGroupIds?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway#subnet_ids AwsGateway#subnet_ids}
        */
        readonly subnetIds: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway#tags AwsGateway#tags}
        */
        readonly tags?: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway#vpc_identifier AwsGateway#vpc_identifier}
        */
        readonly vpcIdentifier: string;
    }
    class AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointManagedVpcResourcePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointManagedVpcResourceProperty | cdktn.IResolvable | undefined;
        set internalValue(value: AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointManagedVpcResourceProperty | cdktn.IResolvable | undefined);
        private _endpointIpAddressType?;
        get endpointIpAddressType(): string;
        set endpointIpAddressType(value: string);
        get endpointIpAddressTypeInput(): string | undefined;
        private _routingDomain?;
        get routingDomain(): string;
        set routingDomain(value: string);
        resetRoutingDomain(): void;
        get routingDomainInput(): string | undefined;
        private _securityGroupIds?;
        get securityGroupIds(): string[];
        set securityGroupIds(value: string[]);
        resetSecurityGroupIds(): void;
        get securityGroupIdsInput(): string[] | undefined;
        private _subnetIds?;
        get subnetIds(): string[];
        set subnetIds(value: string[]);
        get subnetIdsInput(): string[] | undefined;
        private _tags?;
        get tags(): {
            [key: string]: string;
        };
        set tags(value: {
            [key: string]: string;
        });
        resetTags(): void;
        get tagsInput(): {
            [key: string]: string;
        } | undefined;
        private _vpcIdentifier?;
        get vpcIdentifier(): string;
        set vpcIdentifier(value: string);
        get vpcIdentifierInput(): string | undefined;
    }
    class AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointManagedVpcResourcePropertyList extends cdktn.ComplexList {
        internalValue?: AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointManagedVpcResourceProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointManagedVpcResourcePropertyOutputReference;
    }
    interface AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointSelfManagedLatticeResourceProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway#resource_configuration_identifier AwsGateway#resource_configuration_identifier}
        */
        readonly resourceConfigurationIdentifier: string;
    }
    class AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointSelfManagedLatticeResourcePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointSelfManagedLatticeResourceProperty | cdktn.IResolvable | undefined;
        set internalValue(value: AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointSelfManagedLatticeResourceProperty | cdktn.IResolvable | undefined);
        private _resourceConfigurationIdentifier?;
        get resourceConfigurationIdentifier(): string;
        set resourceConfigurationIdentifier(value: string);
        get resourceConfigurationIdentifierInput(): string | undefined;
    }
    class AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointSelfManagedLatticeResourcePropertyList extends cdktn.ComplexList {
        internalValue?: AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointSelfManagedLatticeResourceProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointSelfManagedLatticeResourcePropertyOutputReference;
    }
    interface AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointProperty {
        /**
        * managed_vpc_resource block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway#managed_vpc_resource AwsGateway#managed_vpc_resource}
        */
        readonly managedVpcResource?: AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointManagedVpcResourceProperty[] | cdktn.IResolvable;
        /**
        * self_managed_lattice_resource block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway#self_managed_lattice_resource AwsGateway#self_managed_lattice_resource}
        */
        readonly selfManagedLatticeResource?: AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointSelfManagedLatticeResourceProperty[] | cdktn.IResolvable;
    }
    class AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointProperty | cdktn.IResolvable | undefined;
        set internalValue(value: AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointProperty | cdktn.IResolvable | undefined);
        private _managedVpcResource;
        get managedVpcResource(): AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointManagedVpcResourcePropertyList;
        putManagedVpcResource(value: AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointManagedVpcResourceProperty[] | cdktn.IResolvable): void;
        resetManagedVpcResource(): void;
        get managedVpcResourceInput(): cdktn.IResolvable | AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointManagedVpcResourceProperty[] | undefined;
        private _selfManagedLatticeResource;
        get selfManagedLatticeResource(): AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointSelfManagedLatticeResourcePropertyList;
        putSelfManagedLatticeResource(value: AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointSelfManagedLatticeResourceProperty[] | cdktn.IResolvable): void;
        resetSelfManagedLatticeResource(): void;
        get selfManagedLatticeResourceInput(): cdktn.IResolvable | AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointSelfManagedLatticeResourceProperty[] | undefined;
    }
    class AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointPropertyList extends cdktn.ComplexList {
        internalValue?: AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointPropertyOutputReference;
    }
    interface AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointManagedVpcResourceProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway#endpoint_ip_address_type AwsGateway#endpoint_ip_address_type}
        */
        readonly endpointIpAddressType: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway#routing_domain AwsGateway#routing_domain}
        */
        readonly routingDomain?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway#security_group_ids AwsGateway#security_group_ids}
        */
        readonly securityGroupIds?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway#subnet_ids AwsGateway#subnet_ids}
        */
        readonly subnetIds: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway#tags AwsGateway#tags}
        */
        readonly tags?: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway#vpc_identifier AwsGateway#vpc_identifier}
        */
        readonly vpcIdentifier: string;
    }
    class AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointManagedVpcResourcePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointManagedVpcResourceProperty | cdktn.IResolvable | undefined;
        set internalValue(value: AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointManagedVpcResourceProperty | cdktn.IResolvable | undefined);
        private _endpointIpAddressType?;
        get endpointIpAddressType(): string;
        set endpointIpAddressType(value: string);
        get endpointIpAddressTypeInput(): string | undefined;
        private _routingDomain?;
        get routingDomain(): string;
        set routingDomain(value: string);
        resetRoutingDomain(): void;
        get routingDomainInput(): string | undefined;
        private _securityGroupIds?;
        get securityGroupIds(): string[];
        set securityGroupIds(value: string[]);
        resetSecurityGroupIds(): void;
        get securityGroupIdsInput(): string[] | undefined;
        private _subnetIds?;
        get subnetIds(): string[];
        set subnetIds(value: string[]);
        get subnetIdsInput(): string[] | undefined;
        private _tags?;
        get tags(): {
            [key: string]: string;
        };
        set tags(value: {
            [key: string]: string;
        });
        resetTags(): void;
        get tagsInput(): {
            [key: string]: string;
        } | undefined;
        private _vpcIdentifier?;
        get vpcIdentifier(): string;
        set vpcIdentifier(value: string);
        get vpcIdentifierInput(): string | undefined;
    }
    class AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointManagedVpcResourcePropertyList extends cdktn.ComplexList {
        internalValue?: AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointManagedVpcResourceProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointManagedVpcResourcePropertyOutputReference;
    }
    interface AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointSelfManagedLatticeResourceProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway#resource_configuration_identifier AwsGateway#resource_configuration_identifier}
        */
        readonly resourceConfigurationIdentifier: string;
    }
    class AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointSelfManagedLatticeResourcePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointSelfManagedLatticeResourceProperty | cdktn.IResolvable | undefined;
        set internalValue(value: AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointSelfManagedLatticeResourceProperty | cdktn.IResolvable | undefined);
        private _resourceConfigurationIdentifier?;
        get resourceConfigurationIdentifier(): string;
        set resourceConfigurationIdentifier(value: string);
        get resourceConfigurationIdentifierInput(): string | undefined;
    }
    class AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointSelfManagedLatticeResourcePropertyList extends cdktn.ComplexList {
        internalValue?: AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointSelfManagedLatticeResourceProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointSelfManagedLatticeResourcePropertyOutputReference;
    }
    interface AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointProperty {
        /**
        * managed_vpc_resource block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway#managed_vpc_resource AwsGateway#managed_vpc_resource}
        */
        readonly managedVpcResource?: AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointManagedVpcResourceProperty[] | cdktn.IResolvable;
        /**
        * self_managed_lattice_resource block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway#self_managed_lattice_resource AwsGateway#self_managed_lattice_resource}
        */
        readonly selfManagedLatticeResource?: AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointSelfManagedLatticeResourceProperty[] | cdktn.IResolvable;
    }
    class AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointProperty | cdktn.IResolvable | undefined;
        set internalValue(value: AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointProperty | cdktn.IResolvable | undefined);
        private _managedVpcResource;
        get managedVpcResource(): AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointManagedVpcResourcePropertyList;
        putManagedVpcResource(value: AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointManagedVpcResourceProperty[] | cdktn.IResolvable): void;
        resetManagedVpcResource(): void;
        get managedVpcResourceInput(): cdktn.IResolvable | AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointManagedVpcResourceProperty[] | undefined;
        private _selfManagedLatticeResource;
        get selfManagedLatticeResource(): AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointSelfManagedLatticeResourcePropertyList;
        putSelfManagedLatticeResource(value: AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointSelfManagedLatticeResourceProperty[] | cdktn.IResolvable): void;
        resetSelfManagedLatticeResource(): void;
        get selfManagedLatticeResourceInput(): cdktn.IResolvable | AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointSelfManagedLatticeResourceProperty[] | undefined;
    }
    class AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointPropertyList extends cdktn.ComplexList {
        internalValue?: AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointPropertyOutputReference;
    }
    interface PrivateEndpointOverridesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway#domain AwsGateway#domain}
        */
        readonly domain: string;
        /**
        * private_endpoint block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway#private_endpoint AwsGateway#private_endpoint}
        */
        readonly privateEndpoint?: AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointProperty[] | cdktn.IResolvable;
    }
    class PrivateEndpointOverridesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): PrivateEndpointOverridesProperty | cdktn.IResolvable | undefined;
        set internalValue(value: PrivateEndpointOverridesProperty | cdktn.IResolvable | undefined);
        private _domain?;
        get domain(): string;
        set domain(value: string);
        get domainInput(): string | undefined;
        private _privateEndpoint;
        get privateEndpoint(): AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointPropertyList;
        putPrivateEndpoint(value: AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointProperty[] | cdktn.IResolvable): void;
        resetPrivateEndpoint(): void;
        get privateEndpointInput(): cdktn.IResolvable | AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointProperty[] | undefined;
    }
    class PrivateEndpointOverridesPropertyList extends cdktn.ComplexList {
        internalValue?: PrivateEndpointOverridesProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): PrivateEndpointOverridesPropertyOutputReference;
    }
    interface CustomJwtAuthorizerProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway#allowed_audience AwsGateway#allowed_audience}
        */
        readonly allowedAudience?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway#allowed_clients AwsGateway#allowed_clients}
        */
        readonly allowedClients?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway#allowed_scopes AwsGateway#allowed_scopes}
        */
        readonly allowedScopes?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway#discovery_url AwsGateway#discovery_url}
        */
        readonly discoveryUrl: string;
        /**
        * allowed_workload_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway#allowed_workload_configuration AwsGateway#allowed_workload_configuration}
        */
        readonly allowedWorkloadConfiguration?: AllowedWorkloadConfigurationProperty[] | cdktn.IResolvable;
        /**
        * custom_claim block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway#custom_claim AwsGateway#custom_claim}
        */
        readonly customClaim?: CustomClaimProperty[] | cdktn.IResolvable;
        /**
        * private_endpoint block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway#private_endpoint AwsGateway#private_endpoint}
        */
        readonly privateEndpoint?: AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointProperty[] | cdktn.IResolvable;
        /**
        * private_endpoint_overrides block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway#private_endpoint_overrides AwsGateway#private_endpoint_overrides}
        */
        readonly privateEndpointOverrides?: PrivateEndpointOverridesProperty[] | cdktn.IResolvable;
    }
    class CustomJwtAuthorizerPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CustomJwtAuthorizerProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CustomJwtAuthorizerProperty | cdktn.IResolvable | undefined);
        private _allowedAudience?;
        get allowedAudience(): string[];
        set allowedAudience(value: string[]);
        resetAllowedAudience(): void;
        get allowedAudienceInput(): string[] | undefined;
        private _allowedClients?;
        get allowedClients(): string[];
        set allowedClients(value: string[]);
        resetAllowedClients(): void;
        get allowedClientsInput(): string[] | undefined;
        private _allowedScopes?;
        get allowedScopes(): string[];
        set allowedScopes(value: string[]);
        resetAllowedScopes(): void;
        get allowedScopesInput(): string[] | undefined;
        private _discoveryUrl?;
        get discoveryUrl(): string;
        set discoveryUrl(value: string);
        get discoveryUrlInput(): string | undefined;
        private _allowedWorkloadConfiguration;
        get allowedWorkloadConfiguration(): AllowedWorkloadConfigurationPropertyList;
        putAllowedWorkloadConfiguration(value: AllowedWorkloadConfigurationProperty[] | cdktn.IResolvable): void;
        resetAllowedWorkloadConfiguration(): void;
        get allowedWorkloadConfigurationInput(): cdktn.IResolvable | AllowedWorkloadConfigurationProperty[] | undefined;
        private _customClaim;
        get customClaim(): CustomClaimPropertyList;
        putCustomClaim(value: CustomClaimProperty[] | cdktn.IResolvable): void;
        resetCustomClaim(): void;
        get customClaimInput(): cdktn.IResolvable | CustomClaimProperty[] | undefined;
        private _privateEndpoint;
        get privateEndpoint(): AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointPropertyList;
        putPrivateEndpoint(value: AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointProperty[] | cdktn.IResolvable): void;
        resetPrivateEndpoint(): void;
        get privateEndpointInput(): cdktn.IResolvable | AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointProperty[] | undefined;
        private _privateEndpointOverrides;
        get privateEndpointOverrides(): PrivateEndpointOverridesPropertyList;
        putPrivateEndpointOverrides(value: PrivateEndpointOverridesProperty[] | cdktn.IResolvable): void;
        resetPrivateEndpointOverrides(): void;
        get privateEndpointOverridesInput(): cdktn.IResolvable | PrivateEndpointOverridesProperty[] | undefined;
    }
    class CustomJwtAuthorizerPropertyList extends cdktn.ComplexList {
        internalValue?: CustomJwtAuthorizerProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CustomJwtAuthorizerPropertyOutputReference;
    }
    interface AuthorizerConfigurationProperty {
        /**
        * custom_jwt_authorizer block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway#custom_jwt_authorizer AwsGateway#custom_jwt_authorizer}
        */
        readonly customJwtAuthorizer?: CustomJwtAuthorizerProperty[] | cdktn.IResolvable;
    }
    class AuthorizerConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AuthorizerConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: AuthorizerConfigurationProperty | cdktn.IResolvable | undefined);
        private _customJwtAuthorizer;
        get customJwtAuthorizer(): CustomJwtAuthorizerPropertyList;
        putCustomJwtAuthorizer(value: CustomJwtAuthorizerProperty[] | cdktn.IResolvable): void;
        resetCustomJwtAuthorizer(): void;
        get customJwtAuthorizerInput(): cdktn.IResolvable | CustomJwtAuthorizerProperty[] | undefined;
    }
    class AuthorizerConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: AuthorizerConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AuthorizerConfigurationPropertyOutputReference;
    }
    interface InputConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway#pass_request_headers AwsGateway#pass_request_headers}
        */
        readonly passRequestHeaders: boolean | cdktn.IResolvable;
    }
    class InputConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): InputConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: InputConfigurationProperty | cdktn.IResolvable | undefined);
        private _passRequestHeaders?;
        get passRequestHeaders(): boolean | cdktn.IResolvable;
        set passRequestHeaders(value: boolean | cdktn.IResolvable);
        get passRequestHeadersInput(): boolean | cdktn.IResolvable | undefined;
    }
    class InputConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: InputConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): InputConfigurationPropertyOutputReference;
    }
    interface LambdaProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway#arn AwsGateway#arn}
        */
        readonly arn: string;
    }
    class LambdaPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): LambdaProperty | cdktn.IResolvable | undefined;
        set internalValue(value: LambdaProperty | cdktn.IResolvable | undefined);
        private _arn?;
        get arn(): string;
        set arn(value: string);
        get arnInput(): string | undefined;
    }
    class LambdaPropertyList extends cdktn.ComplexList {
        internalValue?: LambdaProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): LambdaPropertyOutputReference;
    }
    interface InterceptorProperty {
        /**
        * lambda block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway#lambda AwsGateway#lambda}
        */
        readonly lambda?: LambdaProperty[] | cdktn.IResolvable;
    }
    class InterceptorPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): InterceptorProperty | cdktn.IResolvable | undefined;
        set internalValue(value: InterceptorProperty | cdktn.IResolvable | undefined);
        private _lambda;
        get lambda(): LambdaPropertyList;
        putLambda(value: LambdaProperty[] | cdktn.IResolvable): void;
        resetLambda(): void;
        get lambdaInput(): cdktn.IResolvable | LambdaProperty[] | undefined;
    }
    class InterceptorPropertyList extends cdktn.ComplexList {
        internalValue?: InterceptorProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): InterceptorPropertyOutputReference;
    }
    interface InterceptorConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway#interception_points AwsGateway#interception_points}
        */
        readonly interceptionPoints: string[];
        /**
        * input_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway#input_configuration AwsGateway#input_configuration}
        */
        readonly inputConfiguration?: InputConfigurationProperty[] | cdktn.IResolvable;
        /**
        * interceptor block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway#interceptor AwsGateway#interceptor}
        */
        readonly interceptor?: InterceptorProperty[] | cdktn.IResolvable;
    }
    class InterceptorConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): InterceptorConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: InterceptorConfigurationProperty | cdktn.IResolvable | undefined);
        private _interceptionPoints?;
        get interceptionPoints(): string[];
        set interceptionPoints(value: string[]);
        get interceptionPointsInput(): string[] | undefined;
        private _inputConfiguration;
        get inputConfiguration(): InputConfigurationPropertyList;
        putInputConfiguration(value: InputConfigurationProperty[] | cdktn.IResolvable): void;
        resetInputConfiguration(): void;
        get inputConfigurationInput(): cdktn.IResolvable | InputConfigurationProperty[] | undefined;
        private _interceptor;
        get interceptor(): InterceptorPropertyList;
        putInterceptor(value: InterceptorProperty[] | cdktn.IResolvable): void;
        resetInterceptor(): void;
        get interceptorInput(): cdktn.IResolvable | InterceptorProperty[] | undefined;
    }
    class InterceptorConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: InterceptorConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): InterceptorConfigurationPropertyOutputReference;
    }
    interface PolicyEngineConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway#arn AwsGateway#arn}
        */
        readonly arn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway#mode AwsGateway#mode}
        */
        readonly mode: string;
    }
    class PolicyEngineConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): PolicyEngineConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: PolicyEngineConfigurationProperty | cdktn.IResolvable | undefined);
        private _arn?;
        get arn(): string;
        set arn(value: string);
        get arnInput(): string | undefined;
        private _mode?;
        get mode(): string;
        set mode(value: string);
        get modeInput(): string | undefined;
    }
    class PolicyEngineConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: PolicyEngineConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): PolicyEngineConfigurationPropertyOutputReference;
    }
    interface SessionConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway#session_timeout_in_seconds AwsGateway#session_timeout_in_seconds}
        */
        readonly sessionTimeoutInSeconds?: number;
    }
    class SessionConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SessionConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SessionConfigurationProperty | cdktn.IResolvable | undefined);
        private _sessionTimeoutInSeconds?;
        get sessionTimeoutInSeconds(): number;
        set sessionTimeoutInSeconds(value: number);
        resetSessionTimeoutInSeconds(): void;
        get sessionTimeoutInSecondsInput(): number | undefined;
    }
    class SessionConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: SessionConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SessionConfigurationPropertyOutputReference;
    }
    interface StreamingConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway#enable_response_streaming AwsGateway#enable_response_streaming}
        */
        readonly enableResponseStreaming?: boolean | cdktn.IResolvable;
    }
    class StreamingConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): StreamingConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: StreamingConfigurationProperty | cdktn.IResolvable | undefined);
        private _enableResponseStreaming?;
        get enableResponseStreaming(): boolean | cdktn.IResolvable;
        set enableResponseStreaming(value: boolean | cdktn.IResolvable);
        resetEnableResponseStreaming(): void;
        get enableResponseStreamingInput(): boolean | cdktn.IResolvable | undefined;
    }
    class StreamingConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: StreamingConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): StreamingConfigurationPropertyOutputReference;
    }
    interface McpProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway#instructions AwsGateway#instructions}
        */
        readonly instructions?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway#search_type AwsGateway#search_type}
        */
        readonly searchType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway#supported_versions AwsGateway#supported_versions}
        */
        readonly supportedVersions?: string[];
        /**
        * session_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway#session_configuration AwsGateway#session_configuration}
        */
        readonly sessionConfiguration?: SessionConfigurationProperty[] | cdktn.IResolvable;
        /**
        * streaming_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway#streaming_configuration AwsGateway#streaming_configuration}
        */
        readonly streamingConfiguration?: StreamingConfigurationProperty[] | cdktn.IResolvable;
    }
    class McpPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): McpProperty | cdktn.IResolvable | undefined;
        set internalValue(value: McpProperty | cdktn.IResolvable | undefined);
        private _instructions?;
        get instructions(): string;
        set instructions(value: string);
        resetInstructions(): void;
        get instructionsInput(): string | undefined;
        private _searchType?;
        get searchType(): string;
        set searchType(value: string);
        resetSearchType(): void;
        get searchTypeInput(): string | undefined;
        private _supportedVersions?;
        get supportedVersions(): string[];
        set supportedVersions(value: string[]);
        resetSupportedVersions(): void;
        get supportedVersionsInput(): string[] | undefined;
        private _sessionConfiguration;
        get sessionConfiguration(): SessionConfigurationPropertyList;
        putSessionConfiguration(value: SessionConfigurationProperty[] | cdktn.IResolvable): void;
        resetSessionConfiguration(): void;
        get sessionConfigurationInput(): cdktn.IResolvable | SessionConfigurationProperty[] | undefined;
        private _streamingConfiguration;
        get streamingConfiguration(): StreamingConfigurationPropertyList;
        putStreamingConfiguration(value: StreamingConfigurationProperty[] | cdktn.IResolvable): void;
        resetStreamingConfiguration(): void;
        get streamingConfigurationInput(): cdktn.IResolvable | StreamingConfigurationProperty[] | undefined;
    }
    class McpPropertyList extends cdktn.ComplexList {
        internalValue?: McpProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): McpPropertyOutputReference;
    }
    interface ProtocolConfigurationProperty {
        /**
        * mcp block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway#mcp AwsGateway#mcp}
        */
        readonly mcp?: McpProperty[] | cdktn.IResolvable;
    }
    class ProtocolConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ProtocolConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ProtocolConfigurationProperty | cdktn.IResolvable | undefined);
        private _mcp;
        get mcp(): McpPropertyList;
        putMcp(value: McpProperty[] | cdktn.IResolvable): void;
        resetMcp(): void;
        get mcpInput(): cdktn.IResolvable | McpProperty[] | undefined;
    }
    class ProtocolConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: ProtocolConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ProtocolConfigurationPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway#create AwsGateway#create}
        */
        readonly create?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Setting a timeout for a Delete operation is only applicable if changes are saved into state before the destroy operation occurs.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway#delete AwsGateway#delete}
        */
        readonly delete?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway#update AwsGateway#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
