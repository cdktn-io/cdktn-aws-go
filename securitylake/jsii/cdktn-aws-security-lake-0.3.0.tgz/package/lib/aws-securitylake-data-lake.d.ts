import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsDataLakeConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securitylake_data_lake#meta_store_manager_role_arn AwsDataLake#meta_store_manager_role_arn}
    */
    readonly metaStoreManagerRoleArn: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securitylake_data_lake#region AwsDataLake#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securitylake_data_lake#tags AwsDataLake#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securitylake_data_lake#configuration AwsDataLake#configuration}
    */
    readonly configuration?: AwsDataLake.ConfigurationProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securitylake_data_lake#timeouts AwsDataLake#timeouts}
    */
    readonly timeouts?: AwsDataLake.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securitylake_data_lake aws_securitylake_data_lake}
*/
export declare class AwsDataLake extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_securitylake_data_lake";
    /**
    * Generates CDKTN code for importing a AwsDataLake resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsDataLake to import
    * @param importFromId The id of the existing AwsDataLake that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securitylake_data_lake#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsDataLake to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securitylake_data_lake aws_securitylake_data_lake} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsDataLakeConfig
    */
    constructor(scope: Construct, id: string, config: AwsDataLakeConfig);
    get arn(): string;
    get id(): string;
    private _metaStoreManagerRoleArn?;
    get metaStoreManagerRoleArn(): string;
    set metaStoreManagerRoleArn(value: string);
    get metaStoreManagerRoleArnInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get s3BucketArn(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    private _configuration;
    get configuration(): AwsDataLake.ConfigurationPropertyList;
    putConfiguration(value: AwsDataLake.ConfigurationProperty[] | cdktn.IResolvable): void;
    resetConfiguration(): void;
    get configurationInput(): cdktn.IResolvable | AwsDataLake.ConfigurationProperty[] | undefined;
    private _timeouts;
    get timeouts(): AwsDataLake.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsDataLake.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsDataLake.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsDataLakeEncryptionConfigurationPropertyToTerraform(struct?: AwsDataLake.EncryptionConfigurationProperty | cdktn.IResolvable): any;
export declare function awsDataLakeEncryptionConfigurationPropertyToHclTerraform(struct?: AwsDataLake.EncryptionConfigurationProperty | cdktn.IResolvable): any;
export declare function awsDataLakeExpirationPropertyToTerraform(struct?: AwsDataLake.ExpirationProperty | cdktn.IResolvable): any;
export declare function awsDataLakeExpirationPropertyToHclTerraform(struct?: AwsDataLake.ExpirationProperty | cdktn.IResolvable): any;
export declare function awsDataLakeTransitionPropertyToTerraform(struct?: AwsDataLake.TransitionProperty | cdktn.IResolvable): any;
export declare function awsDataLakeTransitionPropertyToHclTerraform(struct?: AwsDataLake.TransitionProperty | cdktn.IResolvable): any;
export declare function awsDataLakeLifecycleConfigurationPropertyToTerraform(struct?: AwsDataLake.LifecycleConfigurationProperty | cdktn.IResolvable): any;
export declare function awsDataLakeLifecycleConfigurationPropertyToHclTerraform(struct?: AwsDataLake.LifecycleConfigurationProperty | cdktn.IResolvable): any;
export declare function awsDataLakeReplicationConfigurationPropertyToTerraform(struct?: AwsDataLake.ReplicationConfigurationProperty | cdktn.IResolvable): any;
export declare function awsDataLakeReplicationConfigurationPropertyToHclTerraform(struct?: AwsDataLake.ReplicationConfigurationProperty | cdktn.IResolvable): any;
export declare function awsDataLakeConfigurationPropertyToTerraform(struct?: AwsDataLake.ConfigurationProperty | cdktn.IResolvable): any;
export declare function awsDataLakeConfigurationPropertyToHclTerraform(struct?: AwsDataLake.ConfigurationProperty | cdktn.IResolvable): any;
export declare function awsDataLakeTimeoutsPropertyToTerraform(struct?: AwsDataLake.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsDataLakeTimeoutsPropertyToHclTerraform(struct?: AwsDataLake.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsDataLake {
    interface EncryptionConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securitylake_data_lake#kms_key_id AwsDataLake#kms_key_id}
        */
        readonly kmsKeyId?: string;
    }
    class EncryptionConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EncryptionConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: EncryptionConfigurationProperty | cdktn.IResolvable | undefined);
        private _kmsKeyId?;
        get kmsKeyId(): string;
        set kmsKeyId(value: string);
        resetKmsKeyId(): void;
        get kmsKeyIdInput(): string | undefined;
    }
    class EncryptionConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: EncryptionConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EncryptionConfigurationPropertyOutputReference;
    }
    interface ExpirationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securitylake_data_lake#days AwsDataLake#days}
        */
        readonly days?: number;
    }
    class ExpirationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ExpirationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ExpirationProperty | cdktn.IResolvable | undefined);
        private _days?;
        get days(): number;
        set days(value: number);
        resetDays(): void;
        get daysInput(): number | undefined;
    }
    class ExpirationPropertyList extends cdktn.ComplexList {
        internalValue?: ExpirationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ExpirationPropertyOutputReference;
    }
    interface TransitionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securitylake_data_lake#days AwsDataLake#days}
        */
        readonly days?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securitylake_data_lake#storage_class AwsDataLake#storage_class}
        */
        readonly storageClass?: string;
    }
    class TransitionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TransitionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TransitionProperty | cdktn.IResolvable | undefined);
        private _days?;
        get days(): number;
        set days(value: number);
        resetDays(): void;
        get daysInput(): number | undefined;
        private _storageClass?;
        get storageClass(): string;
        set storageClass(value: string);
        resetStorageClass(): void;
        get storageClassInput(): string | undefined;
    }
    class TransitionPropertyList extends cdktn.ComplexList {
        internalValue?: TransitionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TransitionPropertyOutputReference;
    }
    interface LifecycleConfigurationProperty {
        /**
        * expiration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securitylake_data_lake#expiration AwsDataLake#expiration}
        */
        readonly expiration?: ExpirationProperty[] | cdktn.IResolvable;
        /**
        * transition block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securitylake_data_lake#transition AwsDataLake#transition}
        */
        readonly transition?: TransitionProperty[] | cdktn.IResolvable;
    }
    class LifecycleConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): LifecycleConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: LifecycleConfigurationProperty | cdktn.IResolvable | undefined);
        private _expiration;
        get expiration(): ExpirationPropertyList;
        putExpiration(value: ExpirationProperty[] | cdktn.IResolvable): void;
        resetExpiration(): void;
        get expirationInput(): cdktn.IResolvable | ExpirationProperty[] | undefined;
        private _transition;
        get transition(): TransitionPropertyList;
        putTransition(value: TransitionProperty[] | cdktn.IResolvable): void;
        resetTransition(): void;
        get transitionInput(): cdktn.IResolvable | TransitionProperty[] | undefined;
    }
    class LifecycleConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: LifecycleConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): LifecycleConfigurationPropertyOutputReference;
    }
    interface ReplicationConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securitylake_data_lake#regions AwsDataLake#regions}
        */
        readonly regions?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securitylake_data_lake#role_arn AwsDataLake#role_arn}
        */
        readonly roleArn?: string;
    }
    class ReplicationConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ReplicationConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ReplicationConfigurationProperty | cdktn.IResolvable | undefined);
        private _regions?;
        get regions(): string[];
        set regions(value: string[]);
        resetRegions(): void;
        get regionsInput(): string[] | undefined;
        private _roleArn?;
        get roleArn(): string;
        set roleArn(value: string);
        resetRoleArn(): void;
        get roleArnInput(): string | undefined;
    }
    class ReplicationConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: ReplicationConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ReplicationConfigurationPropertyOutputReference;
    }
    interface ConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securitylake_data_lake#encryption_configuration AwsDataLake#encryption_configuration}
        */
        readonly encryptionConfiguration?: EncryptionConfigurationProperty[] | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securitylake_data_lake#region AwsDataLake#region}
        */
        readonly region: string;
        /**
        * lifecycle_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securitylake_data_lake#lifecycle_configuration AwsDataLake#lifecycle_configuration}
        */
        readonly lifecycleConfiguration?: LifecycleConfigurationProperty[] | cdktn.IResolvable;
        /**
        * replication_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securitylake_data_lake#replication_configuration AwsDataLake#replication_configuration}
        */
        readonly replicationConfiguration?: ReplicationConfigurationProperty[] | cdktn.IResolvable;
    }
    class ConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ConfigurationProperty | cdktn.IResolvable | undefined);
        private _encryptionConfiguration;
        get encryptionConfiguration(): EncryptionConfigurationPropertyList;
        putEncryptionConfiguration(value: EncryptionConfigurationProperty[] | cdktn.IResolvable): void;
        resetEncryptionConfiguration(): void;
        get encryptionConfigurationInput(): cdktn.IResolvable | EncryptionConfigurationProperty[] | undefined;
        private _region?;
        get region(): string;
        set region(value: string);
        get regionInput(): string | undefined;
        private _lifecycleConfiguration;
        get lifecycleConfiguration(): LifecycleConfigurationPropertyList;
        putLifecycleConfiguration(value: LifecycleConfigurationProperty[] | cdktn.IResolvable): void;
        resetLifecycleConfiguration(): void;
        get lifecycleConfigurationInput(): cdktn.IResolvable | LifecycleConfigurationProperty[] | undefined;
        private _replicationConfiguration;
        get replicationConfiguration(): ReplicationConfigurationPropertyList;
        putReplicationConfiguration(value: ReplicationConfigurationProperty[] | cdktn.IResolvable): void;
        resetReplicationConfiguration(): void;
        get replicationConfigurationInput(): cdktn.IResolvable | ReplicationConfigurationProperty[] | undefined;
    }
    class ConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: ConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ConfigurationPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securitylake_data_lake#create AwsDataLake#create}
        */
        readonly create?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Setting a timeout for a Delete operation is only applicable if changes are saved into state before the destroy operation occurs.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securitylake_data_lake#delete AwsDataLake#delete}
        */
        readonly delete?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securitylake_data_lake#update AwsDataLake#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
