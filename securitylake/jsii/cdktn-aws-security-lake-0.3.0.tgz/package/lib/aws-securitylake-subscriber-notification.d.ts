import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsSubscriberNotificationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securitylake_subscriber_notification#region AwsSubscriberNotification#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securitylake_subscriber_notification#subscriber_id AwsSubscriberNotification#subscriber_id}
    */
    readonly subscriberId: string;
    /**
    * configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securitylake_subscriber_notification#configuration AwsSubscriberNotification#configuration}
    */
    readonly configuration?: AwsSubscriberNotification.ConfigurationProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securitylake_subscriber_notification aws_securitylake_subscriber_notification}
*/
export declare class AwsSubscriberNotification extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_securitylake_subscriber_notification";
    /**
    * Generates CDKTN code for importing a AwsSubscriberNotification resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsSubscriberNotification to import
    * @param importFromId The id of the existing AwsSubscriberNotification that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securitylake_subscriber_notification#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsSubscriberNotification to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securitylake_subscriber_notification aws_securitylake_subscriber_notification} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsSubscriberNotificationConfig
    */
    constructor(scope: Construct, id: string, config: AwsSubscriberNotificationConfig);
    get endpointId(): string;
    get id(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get subscriberEndpoint(): string;
    private _subscriberId?;
    get subscriberId(): string;
    set subscriberId(value: string);
    get subscriberIdInput(): string | undefined;
    private _configuration;
    get configuration(): AwsSubscriberNotification.ConfigurationPropertyList;
    putConfiguration(value: AwsSubscriberNotification.ConfigurationProperty[] | cdktn.IResolvable): void;
    resetConfiguration(): void;
    get configurationInput(): cdktn.IResolvable | AwsSubscriberNotification.ConfigurationProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsSubscriberNotificationHttpsNotificationConfigurationPropertyToTerraform(struct?: AwsSubscriberNotification.HttpsNotificationConfigurationProperty | cdktn.IResolvable): any;
export declare function awsSubscriberNotificationHttpsNotificationConfigurationPropertyToHclTerraform(struct?: AwsSubscriberNotification.HttpsNotificationConfigurationProperty | cdktn.IResolvable): any;
export declare function awsSubscriberNotificationSqsNotificationConfigurationPropertyToTerraform(struct?: AwsSubscriberNotification.SqsNotificationConfigurationProperty | cdktn.IResolvable): any;
export declare function awsSubscriberNotificationSqsNotificationConfigurationPropertyToHclTerraform(struct?: AwsSubscriberNotification.SqsNotificationConfigurationProperty | cdktn.IResolvable): any;
export declare function awsSubscriberNotificationConfigurationPropertyToTerraform(struct?: AwsSubscriberNotification.ConfigurationProperty | cdktn.IResolvable): any;
export declare function awsSubscriberNotificationConfigurationPropertyToHclTerraform(struct?: AwsSubscriberNotification.ConfigurationProperty | cdktn.IResolvable): any;
export declare namespace AwsSubscriberNotification {
    interface HttpsNotificationConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securitylake_subscriber_notification#authorization_api_key_name AwsSubscriberNotification#authorization_api_key_name}
        */
        readonly authorizationApiKeyName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securitylake_subscriber_notification#authorization_api_key_value AwsSubscriberNotification#authorization_api_key_value}
        */
        readonly authorizationApiKeyValue?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securitylake_subscriber_notification#endpoint AwsSubscriberNotification#endpoint}
        */
        readonly endpoint: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securitylake_subscriber_notification#http_method AwsSubscriberNotification#http_method}
        */
        readonly httpMethod?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securitylake_subscriber_notification#target_role_arn AwsSubscriberNotification#target_role_arn}
        */
        readonly targetRoleArn: string;
    }
    class HttpsNotificationConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): HttpsNotificationConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: HttpsNotificationConfigurationProperty | cdktn.IResolvable | undefined);
        private _authorizationApiKeyName?;
        get authorizationApiKeyName(): string;
        set authorizationApiKeyName(value: string);
        resetAuthorizationApiKeyName(): void;
        get authorizationApiKeyNameInput(): string | undefined;
        private _authorizationApiKeyValue?;
        get authorizationApiKeyValue(): string;
        set authorizationApiKeyValue(value: string);
        resetAuthorizationApiKeyValue(): void;
        get authorizationApiKeyValueInput(): string | undefined;
        private _endpoint?;
        get endpoint(): string;
        set endpoint(value: string);
        get endpointInput(): string | undefined;
        private _httpMethod?;
        get httpMethod(): string;
        set httpMethod(value: string);
        resetHttpMethod(): void;
        get httpMethodInput(): string | undefined;
        private _targetRoleArn?;
        get targetRoleArn(): string;
        set targetRoleArn(value: string);
        get targetRoleArnInput(): string | undefined;
    }
    class HttpsNotificationConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: HttpsNotificationConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): HttpsNotificationConfigurationPropertyOutputReference;
    }
    interface SqsNotificationConfigurationProperty {
    }
    class SqsNotificationConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SqsNotificationConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SqsNotificationConfigurationProperty | cdktn.IResolvable | undefined);
    }
    class SqsNotificationConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: SqsNotificationConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SqsNotificationConfigurationPropertyOutputReference;
    }
    interface ConfigurationProperty {
        /**
        * https_notification_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securitylake_subscriber_notification#https_notification_configuration AwsSubscriberNotification#https_notification_configuration}
        */
        readonly httpsNotificationConfiguration?: HttpsNotificationConfigurationProperty[] | cdktn.IResolvable;
        /**
        * sqs_notification_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securitylake_subscriber_notification#sqs_notification_configuration AwsSubscriberNotification#sqs_notification_configuration}
        */
        readonly sqsNotificationConfiguration?: SqsNotificationConfigurationProperty[] | cdktn.IResolvable;
    }
    class ConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ConfigurationProperty | cdktn.IResolvable | undefined);
        private _httpsNotificationConfiguration;
        get httpsNotificationConfiguration(): HttpsNotificationConfigurationPropertyList;
        putHttpsNotificationConfiguration(value: HttpsNotificationConfigurationProperty[] | cdktn.IResolvable): void;
        resetHttpsNotificationConfiguration(): void;
        get httpsNotificationConfigurationInput(): cdktn.IResolvable | HttpsNotificationConfigurationProperty[] | undefined;
        private _sqsNotificationConfiguration;
        get sqsNotificationConfiguration(): SqsNotificationConfigurationPropertyList;
        putSqsNotificationConfiguration(value: SqsNotificationConfigurationProperty[] | cdktn.IResolvable): void;
        resetSqsNotificationConfiguration(): void;
        get sqsNotificationConfigurationInput(): cdktn.IResolvable | SqsNotificationConfigurationProperty[] | undefined;
    }
    class ConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: ConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ConfigurationPropertyOutputReference;
    }
}
