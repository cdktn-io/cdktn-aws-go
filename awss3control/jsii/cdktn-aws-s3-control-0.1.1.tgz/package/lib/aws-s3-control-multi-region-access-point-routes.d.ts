import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsS3ControlMultiRegionAccessPointRoutesConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_multi_region_access_point_routes#account_id AwsS3ControlMultiRegionAccessPointRoutes#account_id}
    */
    readonly accountId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_multi_region_access_point_routes#mrap AwsS3ControlMultiRegionAccessPointRoutes#mrap}
    */
    readonly mrap: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_multi_region_access_point_routes#region AwsS3ControlMultiRegionAccessPointRoutes#region}
    */
    readonly region?: string;
    /**
    * route block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_multi_region_access_point_routes#route AwsS3ControlMultiRegionAccessPointRoutes#route}
    */
    readonly route?: AwsS3ControlMultiRegionAccessPointRoutes.RouteProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_multi_region_access_point_routes aws_s3control_multi_region_access_point_routes}
*/
export declare class AwsS3ControlMultiRegionAccessPointRoutes extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_s3control_multi_region_access_point_routes";
    /**
    * Generates CDKTN code for importing a AwsS3ControlMultiRegionAccessPointRoutes resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsS3ControlMultiRegionAccessPointRoutes to import
    * @param importFromId The id of the existing AwsS3ControlMultiRegionAccessPointRoutes that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_multi_region_access_point_routes#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsS3ControlMultiRegionAccessPointRoutes to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_multi_region_access_point_routes aws_s3control_multi_region_access_point_routes} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsS3ControlMultiRegionAccessPointRoutesConfig
    */
    constructor(scope: Construct, id: string, config: AwsS3ControlMultiRegionAccessPointRoutesConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    resetAccountId(): void;
    get accountIdInput(): string | undefined;
    private _mrap?;
    get mrap(): string;
    set mrap(value: string);
    get mrapInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _route;
    get route(): AwsS3ControlMultiRegionAccessPointRoutes.RoutePropertyList;
    putRoute(value: AwsS3ControlMultiRegionAccessPointRoutes.RouteProperty[] | cdktn.IResolvable): void;
    resetRoute(): void;
    get routeInput(): cdktn.IResolvable | AwsS3ControlMultiRegionAccessPointRoutes.RouteProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsS3ControlMultiRegionAccessPointRoutesRoutePropertyToTerraform(struct?: AwsS3ControlMultiRegionAccessPointRoutes.RouteProperty | cdktn.IResolvable): any;
export declare function awsS3ControlMultiRegionAccessPointRoutesRoutePropertyToHclTerraform(struct?: AwsS3ControlMultiRegionAccessPointRoutes.RouteProperty | cdktn.IResolvable): any;
export declare namespace AwsS3ControlMultiRegionAccessPointRoutes {
    interface RouteProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_multi_region_access_point_routes#bucket AwsS3ControlMultiRegionAccessPointRoutes#bucket}
        */
        readonly bucket: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_multi_region_access_point_routes#region AwsS3ControlMultiRegionAccessPointRoutes#region}
        */
        readonly region: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_multi_region_access_point_routes#traffic_dial_percentage AwsS3ControlMultiRegionAccessPointRoutes#traffic_dial_percentage}
        */
        readonly trafficDialPercentage: number;
    }
    class RoutePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RouteProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RouteProperty | cdktn.IResolvable | undefined);
        private _bucket?;
        get bucket(): string;
        set bucket(value: string);
        get bucketInput(): string | undefined;
        private _region?;
        get region(): string;
        set region(value: string);
        get regionInput(): string | undefined;
        private _trafficDialPercentage?;
        get trafficDialPercentage(): number;
        set trafficDialPercentage(value: number);
        get trafficDialPercentageInput(): number | undefined;
    }
    class RoutePropertyList extends cdktn.ComplexList {
        internalValue?: RouteProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RoutePropertyOutputReference;
    }
}
