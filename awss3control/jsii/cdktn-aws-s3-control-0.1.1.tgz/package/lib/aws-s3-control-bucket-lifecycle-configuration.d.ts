import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsS3ControlBucketLifecycleConfigurationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_bucket_lifecycle_configuration#bucket AwsS3ControlBucketLifecycleConfiguration#bucket}
    */
    readonly bucket: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_bucket_lifecycle_configuration#id AwsS3ControlBucketLifecycleConfiguration#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_bucket_lifecycle_configuration#region AwsS3ControlBucketLifecycleConfiguration#region}
    */
    readonly region?: string;
    /**
    * rule block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_bucket_lifecycle_configuration#rule AwsS3ControlBucketLifecycleConfiguration#rule}
    */
    readonly rule: AwsS3ControlBucketLifecycleConfiguration.RuleProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_bucket_lifecycle_configuration aws_s3control_bucket_lifecycle_configuration}
*/
export declare class AwsS3ControlBucketLifecycleConfiguration extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_s3control_bucket_lifecycle_configuration";
    /**
    * Generates CDKTN code for importing a AwsS3ControlBucketLifecycleConfiguration resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsS3ControlBucketLifecycleConfiguration to import
    * @param importFromId The id of the existing AwsS3ControlBucketLifecycleConfiguration that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_bucket_lifecycle_configuration#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsS3ControlBucketLifecycleConfiguration to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_bucket_lifecycle_configuration aws_s3control_bucket_lifecycle_configuration} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsS3ControlBucketLifecycleConfigurationConfig
    */
    constructor(scope: Construct, id: string, config: AwsS3ControlBucketLifecycleConfigurationConfig);
    private _bucket?;
    get bucket(): string;
    set bucket(value: string);
    get bucketInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _rule;
    get rule(): AwsS3ControlBucketLifecycleConfiguration.RulePropertyList;
    putRule(value: AwsS3ControlBucketLifecycleConfiguration.RuleProperty[] | cdktn.IResolvable): void;
    get ruleInput(): cdktn.IResolvable | AwsS3ControlBucketLifecycleConfiguration.RuleProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsS3ControlBucketLifecycleConfigurationAbortIncompleteMultipartUploadPropertyToTerraform(struct?: AwsS3ControlBucketLifecycleConfiguration.AbortIncompleteMultipartUploadPropertyOutputReference | AwsS3ControlBucketLifecycleConfiguration.AbortIncompleteMultipartUploadProperty): any;
export declare function awsS3ControlBucketLifecycleConfigurationAbortIncompleteMultipartUploadPropertyToHclTerraform(struct?: AwsS3ControlBucketLifecycleConfiguration.AbortIncompleteMultipartUploadPropertyOutputReference | AwsS3ControlBucketLifecycleConfiguration.AbortIncompleteMultipartUploadProperty): any;
export declare function awsS3ControlBucketLifecycleConfigurationExpirationPropertyToTerraform(struct?: AwsS3ControlBucketLifecycleConfiguration.ExpirationPropertyOutputReference | AwsS3ControlBucketLifecycleConfiguration.ExpirationProperty): any;
export declare function awsS3ControlBucketLifecycleConfigurationExpirationPropertyToHclTerraform(struct?: AwsS3ControlBucketLifecycleConfiguration.ExpirationPropertyOutputReference | AwsS3ControlBucketLifecycleConfiguration.ExpirationProperty): any;
export declare function awsS3ControlBucketLifecycleConfigurationFilterPropertyToTerraform(struct?: AwsS3ControlBucketLifecycleConfiguration.FilterPropertyOutputReference | AwsS3ControlBucketLifecycleConfiguration.FilterProperty): any;
export declare function awsS3ControlBucketLifecycleConfigurationFilterPropertyToHclTerraform(struct?: AwsS3ControlBucketLifecycleConfiguration.FilterPropertyOutputReference | AwsS3ControlBucketLifecycleConfiguration.FilterProperty): any;
export declare function awsS3ControlBucketLifecycleConfigurationRulePropertyToTerraform(struct?: AwsS3ControlBucketLifecycleConfiguration.RuleProperty | cdktn.IResolvable): any;
export declare function awsS3ControlBucketLifecycleConfigurationRulePropertyToHclTerraform(struct?: AwsS3ControlBucketLifecycleConfiguration.RuleProperty | cdktn.IResolvable): any;
export declare namespace AwsS3ControlBucketLifecycleConfiguration {
    interface AbortIncompleteMultipartUploadProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_bucket_lifecycle_configuration#days_after_initiation AwsS3ControlBucketLifecycleConfiguration#days_after_initiation}
        */
        readonly daysAfterInitiation: number;
    }
    class AbortIncompleteMultipartUploadPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AbortIncompleteMultipartUploadProperty | undefined;
        set internalValue(value: AbortIncompleteMultipartUploadProperty | undefined);
        private _daysAfterInitiation?;
        get daysAfterInitiation(): number;
        set daysAfterInitiation(value: number);
        get daysAfterInitiationInput(): number | undefined;
    }
    interface ExpirationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_bucket_lifecycle_configuration#date AwsS3ControlBucketLifecycleConfiguration#date}
        */
        readonly date?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_bucket_lifecycle_configuration#days AwsS3ControlBucketLifecycleConfiguration#days}
        */
        readonly days?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_bucket_lifecycle_configuration#expired_object_delete_marker AwsS3ControlBucketLifecycleConfiguration#expired_object_delete_marker}
        */
        readonly expiredObjectDeleteMarker?: boolean | cdktn.IResolvable;
    }
    class ExpirationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ExpirationProperty | undefined;
        set internalValue(value: ExpirationProperty | undefined);
        private _date?;
        get date(): string;
        set date(value: string);
        resetDate(): void;
        get dateInput(): string | undefined;
        private _days?;
        get days(): number;
        set days(value: number);
        resetDays(): void;
        get daysInput(): number | undefined;
        private _expiredObjectDeleteMarker?;
        get expiredObjectDeleteMarker(): boolean | cdktn.IResolvable;
        set expiredObjectDeleteMarker(value: boolean | cdktn.IResolvable);
        resetExpiredObjectDeleteMarker(): void;
        get expiredObjectDeleteMarkerInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface FilterProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_bucket_lifecycle_configuration#prefix AwsS3ControlBucketLifecycleConfiguration#prefix}
        */
        readonly prefix?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_bucket_lifecycle_configuration#tags AwsS3ControlBucketLifecycleConfiguration#tags}
        */
        readonly tags?: {
            [key: string]: string;
        };
    }
    class FilterPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): FilterProperty | undefined;
        set internalValue(value: FilterProperty | undefined);
        private _prefix?;
        get prefix(): string;
        set prefix(value: string);
        resetPrefix(): void;
        get prefixInput(): string | undefined;
        private _tags?;
        get tags(): {
            [key: string]: string;
        };
        set tags(value: {
            [key: string]: string;
        });
        resetTags(): void;
        get tagsInput(): {
            [key: string]: string;
        } | undefined;
    }
    interface RuleProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_bucket_lifecycle_configuration#id AwsS3ControlBucketLifecycleConfiguration#id}
        *
        * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
        * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
        */
        readonly id: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_bucket_lifecycle_configuration#status AwsS3ControlBucketLifecycleConfiguration#status}
        */
        readonly status?: string;
        /**
        * abort_incomplete_multipart_upload block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_bucket_lifecycle_configuration#abort_incomplete_multipart_upload AwsS3ControlBucketLifecycleConfiguration#abort_incomplete_multipart_upload}
        */
        readonly abortIncompleteMultipartUpload?: AbortIncompleteMultipartUploadProperty;
        /**
        * expiration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_bucket_lifecycle_configuration#expiration AwsS3ControlBucketLifecycleConfiguration#expiration}
        */
        readonly expiration?: ExpirationProperty;
        /**
        * filter block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_bucket_lifecycle_configuration#filter AwsS3ControlBucketLifecycleConfiguration#filter}
        */
        readonly filter?: FilterProperty;
    }
    class RulePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RuleProperty | cdktn.IResolvable | undefined);
        private _id?;
        get id(): string;
        set id(value: string);
        get idInput(): string | undefined;
        private _status?;
        get status(): string;
        set status(value: string);
        resetStatus(): void;
        get statusInput(): string | undefined;
        private _abortIncompleteMultipartUpload;
        get abortIncompleteMultipartUpload(): AbortIncompleteMultipartUploadPropertyOutputReference;
        putAbortIncompleteMultipartUpload(value: AbortIncompleteMultipartUploadProperty): void;
        resetAbortIncompleteMultipartUpload(): void;
        get abortIncompleteMultipartUploadInput(): AbortIncompleteMultipartUploadProperty | undefined;
        private _expiration;
        get expiration(): ExpirationPropertyOutputReference;
        putExpiration(value: ExpirationProperty): void;
        resetExpiration(): void;
        get expirationInput(): ExpirationProperty | undefined;
        private _filter;
        get filter(): FilterPropertyOutputReference;
        putFilter(value: FilterProperty): void;
        resetFilter(): void;
        get filterInput(): FilterProperty | undefined;
    }
    class RulePropertyList extends cdktn.ComplexList {
        internalValue?: RuleProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RulePropertyOutputReference;
    }
}
