import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsS3ControlMultiRegionAccessPointPolicyConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_multi_region_access_point_policy#account_id AwsS3ControlMultiRegionAccessPointPolicy#account_id}
    */
    readonly accountId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_multi_region_access_point_policy#id AwsS3ControlMultiRegionAccessPointPolicy#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_multi_region_access_point_policy#region AwsS3ControlMultiRegionAccessPointPolicy#region}
    */
    readonly region?: string;
    /**
    * details block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_multi_region_access_point_policy#details AwsS3ControlMultiRegionAccessPointPolicy#details}
    */
    readonly details: AwsS3ControlMultiRegionAccessPointPolicy.DetailsProperty;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_multi_region_access_point_policy#timeouts AwsS3ControlMultiRegionAccessPointPolicy#timeouts}
    */
    readonly timeouts?: AwsS3ControlMultiRegionAccessPointPolicy.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_multi_region_access_point_policy aws_s3control_multi_region_access_point_policy}
*/
export declare class AwsS3ControlMultiRegionAccessPointPolicy extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_s3control_multi_region_access_point_policy";
    /**
    * Generates CDKTN code for importing a AwsS3ControlMultiRegionAccessPointPolicy resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsS3ControlMultiRegionAccessPointPolicy to import
    * @param importFromId The id of the existing AwsS3ControlMultiRegionAccessPointPolicy that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_multi_region_access_point_policy#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsS3ControlMultiRegionAccessPointPolicy to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_multi_region_access_point_policy aws_s3control_multi_region_access_point_policy} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsS3ControlMultiRegionAccessPointPolicyConfig
    */
    constructor(scope: Construct, id: string, config: AwsS3ControlMultiRegionAccessPointPolicyConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    resetAccountId(): void;
    get accountIdInput(): string | undefined;
    get established(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get proposed(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _details;
    get details(): AwsS3ControlMultiRegionAccessPointPolicy.DetailsPropertyOutputReference;
    putDetails(value: AwsS3ControlMultiRegionAccessPointPolicy.DetailsProperty): void;
    get detailsInput(): AwsS3ControlMultiRegionAccessPointPolicy.DetailsProperty | undefined;
    private _timeouts;
    get timeouts(): AwsS3ControlMultiRegionAccessPointPolicy.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsS3ControlMultiRegionAccessPointPolicy.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsS3ControlMultiRegionAccessPointPolicy.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsS3ControlMultiRegionAccessPointPolicyDetailsPropertyToTerraform(struct?: AwsS3ControlMultiRegionAccessPointPolicy.DetailsPropertyOutputReference | AwsS3ControlMultiRegionAccessPointPolicy.DetailsProperty): any;
export declare function awsS3ControlMultiRegionAccessPointPolicyDetailsPropertyToHclTerraform(struct?: AwsS3ControlMultiRegionAccessPointPolicy.DetailsPropertyOutputReference | AwsS3ControlMultiRegionAccessPointPolicy.DetailsProperty): any;
export declare function awsS3ControlMultiRegionAccessPointPolicyTimeoutsPropertyToTerraform(struct?: AwsS3ControlMultiRegionAccessPointPolicy.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsS3ControlMultiRegionAccessPointPolicyTimeoutsPropertyToHclTerraform(struct?: AwsS3ControlMultiRegionAccessPointPolicy.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsS3ControlMultiRegionAccessPointPolicy {
    interface DetailsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_multi_region_access_point_policy#name AwsS3ControlMultiRegionAccessPointPolicy#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_multi_region_access_point_policy#policy AwsS3ControlMultiRegionAccessPointPolicy#policy}
        */
        readonly policy: string;
    }
    class DetailsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DetailsProperty | undefined;
        set internalValue(value: DetailsProperty | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _policy?;
        get policy(): string;
        set policy(value: string);
        get policyInput(): string | undefined;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_multi_region_access_point_policy#create AwsS3ControlMultiRegionAccessPointPolicy#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_multi_region_access_point_policy#update AwsS3ControlMultiRegionAccessPointPolicy#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
