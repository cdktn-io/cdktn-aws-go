import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsS3ControlAccessGrantConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_access_grant#access_grants_location_id AwsS3ControlAccessGrant#access_grants_location_id}
    */
    readonly accessGrantsLocationId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_access_grant#account_id AwsS3ControlAccessGrant#account_id}
    */
    readonly accountId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_access_grant#permission AwsS3ControlAccessGrant#permission}
    */
    readonly permission: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_access_grant#region AwsS3ControlAccessGrant#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_access_grant#s3_prefix_type AwsS3ControlAccessGrant#s3_prefix_type}
    */
    readonly s3PrefixType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_access_grant#tags AwsS3ControlAccessGrant#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * access_grants_location_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_access_grant#access_grants_location_configuration AwsS3ControlAccessGrant#access_grants_location_configuration}
    */
    readonly accessGrantsLocationConfiguration?: AwsS3ControlAccessGrant.AccessGrantsLocationConfigurationProperty[] | cdktn.IResolvable;
    /**
    * grantee block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_access_grant#grantee AwsS3ControlAccessGrant#grantee}
    */
    readonly grantee?: AwsS3ControlAccessGrant.GranteeProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_access_grant aws_s3control_access_grant}
*/
export declare class AwsS3ControlAccessGrant extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_s3control_access_grant";
    /**
    * Generates CDKTN code for importing a AwsS3ControlAccessGrant resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsS3ControlAccessGrant to import
    * @param importFromId The id of the existing AwsS3ControlAccessGrant that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_access_grant#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsS3ControlAccessGrant to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_access_grant aws_s3control_access_grant} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsS3ControlAccessGrantConfig
    */
    constructor(scope: Construct, id: string, config: AwsS3ControlAccessGrantConfig);
    get accessGrantArn(): string;
    get accessGrantId(): string;
    private _accessGrantsLocationId?;
    get accessGrantsLocationId(): string;
    set accessGrantsLocationId(value: string);
    get accessGrantsLocationIdInput(): string | undefined;
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    resetAccountId(): void;
    get accountIdInput(): string | undefined;
    get grantScope(): string;
    get id(): string;
    private _permission?;
    get permission(): string;
    set permission(value: string);
    get permissionInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _s3PrefixType?;
    get s3PrefixType(): string;
    set s3PrefixType(value: string);
    resetS3PrefixType(): void;
    get s3PrefixTypeInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    private _accessGrantsLocationConfiguration;
    get accessGrantsLocationConfiguration(): AwsS3ControlAccessGrant.AccessGrantsLocationConfigurationPropertyList;
    putAccessGrantsLocationConfiguration(value: AwsS3ControlAccessGrant.AccessGrantsLocationConfigurationProperty[] | cdktn.IResolvable): void;
    resetAccessGrantsLocationConfiguration(): void;
    get accessGrantsLocationConfigurationInput(): cdktn.IResolvable | AwsS3ControlAccessGrant.AccessGrantsLocationConfigurationProperty[] | undefined;
    private _grantee;
    get grantee(): AwsS3ControlAccessGrant.GranteePropertyList;
    putGrantee(value: AwsS3ControlAccessGrant.GranteeProperty[] | cdktn.IResolvable): void;
    resetGrantee(): void;
    get granteeInput(): cdktn.IResolvable | AwsS3ControlAccessGrant.GranteeProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsS3ControlAccessGrantAccessGrantsLocationConfigurationPropertyToTerraform(struct?: AwsS3ControlAccessGrant.AccessGrantsLocationConfigurationProperty | cdktn.IResolvable): any;
export declare function awsS3ControlAccessGrantAccessGrantsLocationConfigurationPropertyToHclTerraform(struct?: AwsS3ControlAccessGrant.AccessGrantsLocationConfigurationProperty | cdktn.IResolvable): any;
export declare function awsS3ControlAccessGrantGranteePropertyToTerraform(struct?: AwsS3ControlAccessGrant.GranteeProperty | cdktn.IResolvable): any;
export declare function awsS3ControlAccessGrantGranteePropertyToHclTerraform(struct?: AwsS3ControlAccessGrant.GranteeProperty | cdktn.IResolvable): any;
export declare namespace AwsS3ControlAccessGrant {
    interface AccessGrantsLocationConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_access_grant#s3_sub_prefix AwsS3ControlAccessGrant#s3_sub_prefix}
        */
        readonly s3SubPrefix?: string;
    }
    class AccessGrantsLocationConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AccessGrantsLocationConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: AccessGrantsLocationConfigurationProperty | cdktn.IResolvable | undefined);
        private _s3SubPrefix?;
        get s3SubPrefix(): string;
        set s3SubPrefix(value: string);
        resetS3SubPrefix(): void;
        get s3SubPrefixInput(): string | undefined;
    }
    class AccessGrantsLocationConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: AccessGrantsLocationConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AccessGrantsLocationConfigurationPropertyOutputReference;
    }
    interface GranteeProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_access_grant#grantee_identifier AwsS3ControlAccessGrant#grantee_identifier}
        */
        readonly granteeIdentifier: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_access_grant#grantee_type AwsS3ControlAccessGrant#grantee_type}
        */
        readonly granteeType: string;
    }
    class GranteePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): GranteeProperty | cdktn.IResolvable | undefined;
        set internalValue(value: GranteeProperty | cdktn.IResolvable | undefined);
        private _granteeIdentifier?;
        get granteeIdentifier(): string;
        set granteeIdentifier(value: string);
        get granteeIdentifierInput(): string | undefined;
        private _granteeType?;
        get granteeType(): string;
        set granteeType(value: string);
        get granteeTypeInput(): string | undefined;
    }
    class GranteePropertyList extends cdktn.ComplexList {
        internalValue?: GranteeProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): GranteePropertyOutputReference;
    }
}
