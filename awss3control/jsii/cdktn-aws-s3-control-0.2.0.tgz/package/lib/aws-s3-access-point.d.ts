import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfAccessPointConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_access_point#account_id TfAccessPoint#account_id}
    */
    readonly accountId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_access_point#bucket TfAccessPoint#bucket}
    */
    readonly bucket: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_access_point#bucket_account_id TfAccessPoint#bucket_account_id}
    */
    readonly bucketAccountId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_access_point#id TfAccessPoint#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_access_point#name TfAccessPoint#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_access_point#policy TfAccessPoint#policy}
    */
    readonly policy?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_access_point#region TfAccessPoint#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_access_point#tags TfAccessPoint#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_access_point#tags_all TfAccessPoint#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * public_access_block_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_access_point#public_access_block_configuration TfAccessPoint#public_access_block_configuration}
    */
    readonly publicAccessBlockConfiguration?: TfAccessPoint.PublicAccessBlockConfigurationProperty;
    /**
    * vpc_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_access_point#vpc_configuration TfAccessPoint#vpc_configuration}
    */
    readonly vpcConfiguration?: TfAccessPoint.VpcConfigurationProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_access_point aws_s3_access_point}
*/
export declare class TfAccessPoint extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_s3_access_point";
    /**
    * Generates CDKTN code for importing a TfAccessPoint resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfAccessPoint to import
    * @param importFromId The id of the existing TfAccessPoint that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_access_point#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfAccessPoint to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_access_point aws_s3_access_point} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfAccessPointConfig
    */
    constructor(scope: Construct, id: string, config: TfAccessPointConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    resetAccountId(): void;
    get accountIdInput(): string | undefined;
    get alias(): string;
    get arn(): string;
    private _bucket?;
    get bucket(): string;
    set bucket(value: string);
    get bucketInput(): string | undefined;
    private _bucketAccountId?;
    get bucketAccountId(): string;
    set bucketAccountId(value: string);
    resetBucketAccountId(): void;
    get bucketAccountIdInput(): string | undefined;
    get domainName(): string;
    private _endpoints;
    get endpoints(): cdktn.StringMap;
    get hasPublicAccessPolicy(): cdktn.IResolvable;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get networkOrigin(): string;
    private _policy?;
    get policy(): string;
    set policy(value: string);
    resetPolicy(): void;
    get policyInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _publicAccessBlockConfiguration;
    get publicAccessBlockConfiguration(): TfAccessPoint.PublicAccessBlockConfigurationPropertyOutputReference;
    putPublicAccessBlockConfiguration(value: TfAccessPoint.PublicAccessBlockConfigurationProperty): void;
    resetPublicAccessBlockConfiguration(): void;
    get publicAccessBlockConfigurationInput(): TfAccessPoint.PublicAccessBlockConfigurationProperty | undefined;
    private _vpcConfiguration;
    get vpcConfiguration(): TfAccessPoint.VpcConfigurationPropertyOutputReference;
    putVpcConfiguration(value: TfAccessPoint.VpcConfigurationProperty): void;
    resetVpcConfiguration(): void;
    get vpcConfigurationInput(): TfAccessPoint.VpcConfigurationProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfAccessPointPublicAccessBlockConfigurationPropertyToTerraform(struct?: TfAccessPoint.PublicAccessBlockConfigurationPropertyOutputReference | TfAccessPoint.PublicAccessBlockConfigurationProperty): any;
export declare function tfAccessPointPublicAccessBlockConfigurationPropertyToHclTerraform(struct?: TfAccessPoint.PublicAccessBlockConfigurationPropertyOutputReference | TfAccessPoint.PublicAccessBlockConfigurationProperty): any;
export declare function tfAccessPointVpcConfigurationPropertyToTerraform(struct?: TfAccessPoint.VpcConfigurationPropertyOutputReference | TfAccessPoint.VpcConfigurationProperty): any;
export declare function tfAccessPointVpcConfigurationPropertyToHclTerraform(struct?: TfAccessPoint.VpcConfigurationPropertyOutputReference | TfAccessPoint.VpcConfigurationProperty): any;
export declare namespace TfAccessPoint {
    interface PublicAccessBlockConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_access_point#block_public_acls TfAccessPoint#block_public_acls}
        */
        readonly blockPublicAcls?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_access_point#block_public_policy TfAccessPoint#block_public_policy}
        */
        readonly blockPublicPolicy?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_access_point#ignore_public_acls TfAccessPoint#ignore_public_acls}
        */
        readonly ignorePublicAcls?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_access_point#restrict_public_buckets TfAccessPoint#restrict_public_buckets}
        */
        readonly restrictPublicBuckets?: boolean | cdktn.IResolvable;
    }
    class PublicAccessBlockConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): PublicAccessBlockConfigurationProperty | undefined;
        set internalValue(value: PublicAccessBlockConfigurationProperty | undefined);
        private _blockPublicAcls?;
        get blockPublicAcls(): boolean | cdktn.IResolvable;
        set blockPublicAcls(value: boolean | cdktn.IResolvable);
        resetBlockPublicAcls(): void;
        get blockPublicAclsInput(): boolean | cdktn.IResolvable | undefined;
        private _blockPublicPolicy?;
        get blockPublicPolicy(): boolean | cdktn.IResolvable;
        set blockPublicPolicy(value: boolean | cdktn.IResolvable);
        resetBlockPublicPolicy(): void;
        get blockPublicPolicyInput(): boolean | cdktn.IResolvable | undefined;
        private _ignorePublicAcls?;
        get ignorePublicAcls(): boolean | cdktn.IResolvable;
        set ignorePublicAcls(value: boolean | cdktn.IResolvable);
        resetIgnorePublicAcls(): void;
        get ignorePublicAclsInput(): boolean | cdktn.IResolvable | undefined;
        private _restrictPublicBuckets?;
        get restrictPublicBuckets(): boolean | cdktn.IResolvable;
        set restrictPublicBuckets(value: boolean | cdktn.IResolvable);
        resetRestrictPublicBuckets(): void;
        get restrictPublicBucketsInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface VpcConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_access_point#vpc_id TfAccessPoint#vpc_id}
        */
        readonly vpcId: string;
    }
    class VpcConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): VpcConfigurationProperty | undefined;
        set internalValue(value: VpcConfigurationProperty | undefined);
        private _vpcId?;
        get vpcId(): string;
        set vpcId(value: string);
        get vpcIdInput(): string | undefined;
    }
}
