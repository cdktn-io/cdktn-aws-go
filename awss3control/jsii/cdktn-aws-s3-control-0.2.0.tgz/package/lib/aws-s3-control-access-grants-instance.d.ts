import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfAccessGrantsInstanceConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_access_grants_instance#account_id TfAccessGrantsInstance#account_id}
    */
    readonly accountId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_access_grants_instance#identity_center_arn TfAccessGrantsInstance#identity_center_arn}
    */
    readonly identityCenterArn?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_access_grants_instance#region TfAccessGrantsInstance#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_access_grants_instance#tags TfAccessGrantsInstance#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_access_grants_instance aws_s3control_access_grants_instance}
*/
export declare class TfAccessGrantsInstance extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_s3control_access_grants_instance";
    /**
    * Generates CDKTN code for importing a TfAccessGrantsInstance resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfAccessGrantsInstance to import
    * @param importFromId The id of the existing TfAccessGrantsInstance that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_access_grants_instance#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfAccessGrantsInstance to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_access_grants_instance aws_s3control_access_grants_instance} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfAccessGrantsInstanceConfig = {}
    */
    constructor(scope: Construct, id: string, config?: TfAccessGrantsInstanceConfig);
    get accessGrantsInstanceArn(): string;
    get accessGrantsInstanceId(): string;
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    resetAccountId(): void;
    get accountIdInput(): string | undefined;
    get id(): string;
    get identityCenterApplicationArn(): string;
    private _identityCenterArn?;
    get identityCenterArn(): string;
    set identityCenterArn(value: string);
    resetIdentityCenterArn(): void;
    get identityCenterArnInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
