import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfObjectLambdaAccessPointConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_object_lambda_access_point#account_id TfObjectLambdaAccessPoint#account_id}
    */
    readonly accountId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_object_lambda_access_point#id TfObjectLambdaAccessPoint#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_object_lambda_access_point#name TfObjectLambdaAccessPoint#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_object_lambda_access_point#region TfObjectLambdaAccessPoint#region}
    */
    readonly region?: string;
    /**
    * configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_object_lambda_access_point#configuration TfObjectLambdaAccessPoint#configuration}
    */
    readonly configuration: TfObjectLambdaAccessPoint.ConfigurationProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_object_lambda_access_point aws_s3control_object_lambda_access_point}
*/
export declare class TfObjectLambdaAccessPoint extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_s3control_object_lambda_access_point";
    /**
    * Generates CDKTN code for importing a TfObjectLambdaAccessPoint resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfObjectLambdaAccessPoint to import
    * @param importFromId The id of the existing TfObjectLambdaAccessPoint that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_object_lambda_access_point#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfObjectLambdaAccessPoint to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_object_lambda_access_point aws_s3control_object_lambda_access_point} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfObjectLambdaAccessPointConfig
    */
    constructor(scope: Construct, id: string, config: TfObjectLambdaAccessPointConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    resetAccountId(): void;
    get accountIdInput(): string | undefined;
    get alias(): string;
    get arn(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _configuration;
    get configuration(): TfObjectLambdaAccessPoint.ConfigurationPropertyOutputReference;
    putConfiguration(value: TfObjectLambdaAccessPoint.ConfigurationProperty): void;
    get configurationInput(): TfObjectLambdaAccessPoint.ConfigurationProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfObjectLambdaAccessPointAwsLambdaPropertyToTerraform(struct?: TfObjectLambdaAccessPoint.AwsLambdaPropertyOutputReference | TfObjectLambdaAccessPoint.AwsLambdaProperty): any;
export declare function tfObjectLambdaAccessPointAwsLambdaPropertyToHclTerraform(struct?: TfObjectLambdaAccessPoint.AwsLambdaPropertyOutputReference | TfObjectLambdaAccessPoint.AwsLambdaProperty): any;
export declare function tfObjectLambdaAccessPointContentTransformationPropertyToTerraform(struct?: TfObjectLambdaAccessPoint.ContentTransformationPropertyOutputReference | TfObjectLambdaAccessPoint.ContentTransformationProperty): any;
export declare function tfObjectLambdaAccessPointContentTransformationPropertyToHclTerraform(struct?: TfObjectLambdaAccessPoint.ContentTransformationPropertyOutputReference | TfObjectLambdaAccessPoint.ContentTransformationProperty): any;
export declare function tfObjectLambdaAccessPointTransformationConfigurationPropertyToTerraform(struct?: TfObjectLambdaAccessPoint.TransformationConfigurationProperty | cdktn.IResolvable): any;
export declare function tfObjectLambdaAccessPointTransformationConfigurationPropertyToHclTerraform(struct?: TfObjectLambdaAccessPoint.TransformationConfigurationProperty | cdktn.IResolvable): any;
export declare function tfObjectLambdaAccessPointConfigurationPropertyToTerraform(struct?: TfObjectLambdaAccessPoint.ConfigurationPropertyOutputReference | TfObjectLambdaAccessPoint.ConfigurationProperty): any;
export declare function tfObjectLambdaAccessPointConfigurationPropertyToHclTerraform(struct?: TfObjectLambdaAccessPoint.ConfigurationPropertyOutputReference | TfObjectLambdaAccessPoint.ConfigurationProperty): any;
export declare namespace TfObjectLambdaAccessPoint {
    interface AwsLambdaProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_object_lambda_access_point#function_arn TfObjectLambdaAccessPoint#function_arn}
        */
        readonly functionArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_object_lambda_access_point#function_payload TfObjectLambdaAccessPoint#function_payload}
        */
        readonly functionPayload?: string;
    }
    class AwsLambdaPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AwsLambdaProperty | undefined;
        set internalValue(value: AwsLambdaProperty | undefined);
        private _functionArn?;
        get functionArn(): string;
        set functionArn(value: string);
        get functionArnInput(): string | undefined;
        private _functionPayload?;
        get functionPayload(): string;
        set functionPayload(value: string);
        resetFunctionPayload(): void;
        get functionPayloadInput(): string | undefined;
    }
    interface ContentTransformationProperty {
        /**
        * aws_lambda block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_object_lambda_access_point#aws_lambda TfObjectLambdaAccessPoint#aws_lambda}
        */
        readonly awsLambda: AwsLambdaProperty;
    }
    class ContentTransformationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ContentTransformationProperty | undefined;
        set internalValue(value: ContentTransformationProperty | undefined);
        private _awsLambda;
        get awsLambda(): AwsLambdaPropertyOutputReference;
        putAwsLambda(value: AwsLambdaProperty): void;
        get awsLambdaInput(): AwsLambdaProperty | undefined;
    }
    interface TransformationConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_object_lambda_access_point#actions TfObjectLambdaAccessPoint#actions}
        */
        readonly actions: string[];
        /**
        * content_transformation block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_object_lambda_access_point#content_transformation TfObjectLambdaAccessPoint#content_transformation}
        */
        readonly contentTransformation: ContentTransformationProperty;
    }
    class TransformationConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TransformationConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TransformationConfigurationProperty | cdktn.IResolvable | undefined);
        private _actions?;
        get actions(): string[];
        set actions(value: string[]);
        get actionsInput(): string[] | undefined;
        private _contentTransformation;
        get contentTransformation(): ContentTransformationPropertyOutputReference;
        putContentTransformation(value: ContentTransformationProperty): void;
        get contentTransformationInput(): ContentTransformationProperty | undefined;
    }
    class TransformationConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: TransformationConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TransformationConfigurationPropertyOutputReference;
    }
    interface ConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_object_lambda_access_point#allowed_features TfObjectLambdaAccessPoint#allowed_features}
        */
        readonly allowedFeatures?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_object_lambda_access_point#cloud_watch_metrics_enabled TfObjectLambdaAccessPoint#cloud_watch_metrics_enabled}
        */
        readonly cloudWatchMetricsEnabled?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_object_lambda_access_point#supporting_access_point TfObjectLambdaAccessPoint#supporting_access_point}
        */
        readonly supportingAccessPoint: string;
        /**
        * transformation_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_object_lambda_access_point#transformation_configuration TfObjectLambdaAccessPoint#transformation_configuration}
        */
        readonly transformationConfiguration: TransformationConfigurationProperty[] | cdktn.IResolvable;
    }
    class ConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ConfigurationProperty | undefined;
        set internalValue(value: ConfigurationProperty | undefined);
        private _allowedFeatures?;
        get allowedFeatures(): string[];
        set allowedFeatures(value: string[]);
        resetAllowedFeatures(): void;
        get allowedFeaturesInput(): string[] | undefined;
        private _cloudWatchMetricsEnabled?;
        get cloudWatchMetricsEnabled(): boolean | cdktn.IResolvable;
        set cloudWatchMetricsEnabled(value: boolean | cdktn.IResolvable);
        resetCloudWatchMetricsEnabled(): void;
        get cloudWatchMetricsEnabledInput(): boolean | cdktn.IResolvable | undefined;
        private _supportingAccessPoint?;
        get supportingAccessPoint(): string;
        set supportingAccessPoint(value: string);
        get supportingAccessPointInput(): string | undefined;
        private _transformationConfiguration;
        get transformationConfiguration(): TransformationConfigurationPropertyList;
        putTransformationConfiguration(value: TransformationConfigurationProperty[] | cdktn.IResolvable): void;
        get transformationConfigurationInput(): cdktn.IResolvable | TransformationConfigurationProperty[] | undefined;
    }
}
