import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfStorageLensConfigurationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_storage_lens_configuration#account_id TfStorageLensConfiguration#account_id}
    */
    readonly accountId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_storage_lens_configuration#config_id TfStorageLensConfiguration#config_id}
    */
    readonly configId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_storage_lens_configuration#id TfStorageLensConfiguration#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_storage_lens_configuration#region TfStorageLensConfiguration#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_storage_lens_configuration#tags TfStorageLensConfiguration#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_storage_lens_configuration#tags_all TfStorageLensConfiguration#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * storage_lens_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_storage_lens_configuration#storage_lens_configuration TfStorageLensConfiguration#storage_lens_configuration}
    */
    readonly storageLensConfiguration: TfStorageLensConfiguration.StorageLensConfigurationProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_storage_lens_configuration aws_s3control_storage_lens_configuration}
*/
export declare class TfStorageLensConfiguration extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_s3control_storage_lens_configuration";
    /**
    * Generates CDKTN code for importing a TfStorageLensConfiguration resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfStorageLensConfiguration to import
    * @param importFromId The id of the existing TfStorageLensConfiguration that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_storage_lens_configuration#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfStorageLensConfiguration to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_storage_lens_configuration aws_s3control_storage_lens_configuration} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfStorageLensConfigurationConfig
    */
    constructor(scope: Construct, id: string, config: TfStorageLensConfigurationConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    resetAccountId(): void;
    get accountIdInput(): string | undefined;
    get arn(): string;
    private _configId?;
    get configId(): string;
    set configId(value: string);
    get configIdInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _storageLensConfiguration;
    get storageLensConfiguration(): TfStorageLensConfiguration.StorageLensConfigurationPropertyOutputReference;
    putStorageLensConfiguration(value: TfStorageLensConfiguration.StorageLensConfigurationProperty): void;
    get storageLensConfigurationInput(): TfStorageLensConfiguration.StorageLensConfigurationProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfStorageLensConfigurationStorageLensConfigurationAccountLevelActivityMetricsPropertyToTerraform(struct?: TfStorageLensConfiguration.StorageLensConfigurationAccountLevelActivityMetricsPropertyOutputReference | TfStorageLensConfiguration.StorageLensConfigurationAccountLevelActivityMetricsProperty): any;
export declare function tfStorageLensConfigurationStorageLensConfigurationAccountLevelActivityMetricsPropertyToHclTerraform(struct?: TfStorageLensConfiguration.StorageLensConfigurationAccountLevelActivityMetricsPropertyOutputReference | TfStorageLensConfiguration.StorageLensConfigurationAccountLevelActivityMetricsProperty): any;
export declare function tfStorageLensConfigurationStorageLensConfigurationAccountLevelAdvancedCostOptimizationMetricsPropertyToTerraform(struct?: TfStorageLensConfiguration.StorageLensConfigurationAccountLevelAdvancedCostOptimizationMetricsPropertyOutputReference | TfStorageLensConfiguration.StorageLensConfigurationAccountLevelAdvancedCostOptimizationMetricsProperty): any;
export declare function tfStorageLensConfigurationStorageLensConfigurationAccountLevelAdvancedCostOptimizationMetricsPropertyToHclTerraform(struct?: TfStorageLensConfiguration.StorageLensConfigurationAccountLevelAdvancedCostOptimizationMetricsPropertyOutputReference | TfStorageLensConfiguration.StorageLensConfigurationAccountLevelAdvancedCostOptimizationMetricsProperty): any;
export declare function tfStorageLensConfigurationStorageLensConfigurationAccountLevelAdvancedDataProtectionMetricsPropertyToTerraform(struct?: TfStorageLensConfiguration.StorageLensConfigurationAccountLevelAdvancedDataProtectionMetricsPropertyOutputReference | TfStorageLensConfiguration.StorageLensConfigurationAccountLevelAdvancedDataProtectionMetricsProperty): any;
export declare function tfStorageLensConfigurationStorageLensConfigurationAccountLevelAdvancedDataProtectionMetricsPropertyToHclTerraform(struct?: TfStorageLensConfiguration.StorageLensConfigurationAccountLevelAdvancedDataProtectionMetricsPropertyOutputReference | TfStorageLensConfiguration.StorageLensConfigurationAccountLevelAdvancedDataProtectionMetricsProperty): any;
export declare function tfStorageLensConfigurationStorageLensConfigurationAccountLevelAdvancedPerformanceMetricsPropertyToTerraform(struct?: TfStorageLensConfiguration.StorageLensConfigurationAccountLevelAdvancedPerformanceMetricsPropertyOutputReference | TfStorageLensConfiguration.StorageLensConfigurationAccountLevelAdvancedPerformanceMetricsProperty): any;
export declare function tfStorageLensConfigurationStorageLensConfigurationAccountLevelAdvancedPerformanceMetricsPropertyToHclTerraform(struct?: TfStorageLensConfiguration.StorageLensConfigurationAccountLevelAdvancedPerformanceMetricsPropertyOutputReference | TfStorageLensConfiguration.StorageLensConfigurationAccountLevelAdvancedPerformanceMetricsProperty): any;
export declare function tfStorageLensConfigurationStorageLensConfigurationAccountLevelBucketLevelActivityMetricsPropertyToTerraform(struct?: TfStorageLensConfiguration.StorageLensConfigurationAccountLevelBucketLevelActivityMetricsPropertyOutputReference | TfStorageLensConfiguration.StorageLensConfigurationAccountLevelBucketLevelActivityMetricsProperty): any;
export declare function tfStorageLensConfigurationStorageLensConfigurationAccountLevelBucketLevelActivityMetricsPropertyToHclTerraform(struct?: TfStorageLensConfiguration.StorageLensConfigurationAccountLevelBucketLevelActivityMetricsPropertyOutputReference | TfStorageLensConfiguration.StorageLensConfigurationAccountLevelBucketLevelActivityMetricsProperty): any;
export declare function tfStorageLensConfigurationStorageLensConfigurationAccountLevelBucketLevelAdvancedCostOptimizationMetricsPropertyToTerraform(struct?: TfStorageLensConfiguration.StorageLensConfigurationAccountLevelBucketLevelAdvancedCostOptimizationMetricsPropertyOutputReference | TfStorageLensConfiguration.StorageLensConfigurationAccountLevelBucketLevelAdvancedCostOptimizationMetricsProperty): any;
export declare function tfStorageLensConfigurationStorageLensConfigurationAccountLevelBucketLevelAdvancedCostOptimizationMetricsPropertyToHclTerraform(struct?: TfStorageLensConfiguration.StorageLensConfigurationAccountLevelBucketLevelAdvancedCostOptimizationMetricsPropertyOutputReference | TfStorageLensConfiguration.StorageLensConfigurationAccountLevelBucketLevelAdvancedCostOptimizationMetricsProperty): any;
export declare function tfStorageLensConfigurationStorageLensConfigurationAccountLevelBucketLevelAdvancedDataProtectionMetricsPropertyToTerraform(struct?: TfStorageLensConfiguration.StorageLensConfigurationAccountLevelBucketLevelAdvancedDataProtectionMetricsPropertyOutputReference | TfStorageLensConfiguration.StorageLensConfigurationAccountLevelBucketLevelAdvancedDataProtectionMetricsProperty): any;
export declare function tfStorageLensConfigurationStorageLensConfigurationAccountLevelBucketLevelAdvancedDataProtectionMetricsPropertyToHclTerraform(struct?: TfStorageLensConfiguration.StorageLensConfigurationAccountLevelBucketLevelAdvancedDataProtectionMetricsPropertyOutputReference | TfStorageLensConfiguration.StorageLensConfigurationAccountLevelBucketLevelAdvancedDataProtectionMetricsProperty): any;
export declare function tfStorageLensConfigurationStorageLensConfigurationAccountLevelBucketLevelAdvancedPerformanceMetricsPropertyToTerraform(struct?: TfStorageLensConfiguration.StorageLensConfigurationAccountLevelBucketLevelAdvancedPerformanceMetricsPropertyOutputReference | TfStorageLensConfiguration.StorageLensConfigurationAccountLevelBucketLevelAdvancedPerformanceMetricsProperty): any;
export declare function tfStorageLensConfigurationStorageLensConfigurationAccountLevelBucketLevelAdvancedPerformanceMetricsPropertyToHclTerraform(struct?: TfStorageLensConfiguration.StorageLensConfigurationAccountLevelBucketLevelAdvancedPerformanceMetricsPropertyOutputReference | TfStorageLensConfiguration.StorageLensConfigurationAccountLevelBucketLevelAdvancedPerformanceMetricsProperty): any;
export declare function tfStorageLensConfigurationStorageLensConfigurationAccountLevelBucketLevelDetailedStatusCodeMetricsPropertyToTerraform(struct?: TfStorageLensConfiguration.StorageLensConfigurationAccountLevelBucketLevelDetailedStatusCodeMetricsPropertyOutputReference | TfStorageLensConfiguration.StorageLensConfigurationAccountLevelBucketLevelDetailedStatusCodeMetricsProperty): any;
export declare function tfStorageLensConfigurationStorageLensConfigurationAccountLevelBucketLevelDetailedStatusCodeMetricsPropertyToHclTerraform(struct?: TfStorageLensConfiguration.StorageLensConfigurationAccountLevelBucketLevelDetailedStatusCodeMetricsPropertyOutputReference | TfStorageLensConfiguration.StorageLensConfigurationAccountLevelBucketLevelDetailedStatusCodeMetricsProperty): any;
export declare function tfStorageLensConfigurationSelectionCriteriaPropertyToTerraform(struct?: TfStorageLensConfiguration.SelectionCriteriaPropertyOutputReference | TfStorageLensConfiguration.SelectionCriteriaProperty): any;
export declare function tfStorageLensConfigurationSelectionCriteriaPropertyToHclTerraform(struct?: TfStorageLensConfiguration.SelectionCriteriaPropertyOutputReference | TfStorageLensConfiguration.SelectionCriteriaProperty): any;
export declare function tfStorageLensConfigurationStorageMetricsPropertyToTerraform(struct?: TfStorageLensConfiguration.StorageMetricsPropertyOutputReference | TfStorageLensConfiguration.StorageMetricsProperty): any;
export declare function tfStorageLensConfigurationStorageMetricsPropertyToHclTerraform(struct?: TfStorageLensConfiguration.StorageMetricsPropertyOutputReference | TfStorageLensConfiguration.StorageMetricsProperty): any;
export declare function tfStorageLensConfigurationPrefixLevelPropertyToTerraform(struct?: TfStorageLensConfiguration.PrefixLevelPropertyOutputReference | TfStorageLensConfiguration.PrefixLevelProperty): any;
export declare function tfStorageLensConfigurationPrefixLevelPropertyToHclTerraform(struct?: TfStorageLensConfiguration.PrefixLevelPropertyOutputReference | TfStorageLensConfiguration.PrefixLevelProperty): any;
export declare function tfStorageLensConfigurationBucketLevelPropertyToTerraform(struct?: TfStorageLensConfiguration.BucketLevelPropertyOutputReference | TfStorageLensConfiguration.BucketLevelProperty): any;
export declare function tfStorageLensConfigurationBucketLevelPropertyToHclTerraform(struct?: TfStorageLensConfiguration.BucketLevelPropertyOutputReference | TfStorageLensConfiguration.BucketLevelProperty): any;
export declare function tfStorageLensConfigurationStorageLensConfigurationAccountLevelDetailedStatusCodeMetricsPropertyToTerraform(struct?: TfStorageLensConfiguration.StorageLensConfigurationAccountLevelDetailedStatusCodeMetricsPropertyOutputReference | TfStorageLensConfiguration.StorageLensConfigurationAccountLevelDetailedStatusCodeMetricsProperty): any;
export declare function tfStorageLensConfigurationStorageLensConfigurationAccountLevelDetailedStatusCodeMetricsPropertyToHclTerraform(struct?: TfStorageLensConfiguration.StorageLensConfigurationAccountLevelDetailedStatusCodeMetricsPropertyOutputReference | TfStorageLensConfiguration.StorageLensConfigurationAccountLevelDetailedStatusCodeMetricsProperty): any;
export declare function tfStorageLensConfigurationAccountLevelPropertyToTerraform(struct?: TfStorageLensConfiguration.AccountLevelPropertyOutputReference | TfStorageLensConfiguration.AccountLevelProperty): any;
export declare function tfStorageLensConfigurationAccountLevelPropertyToHclTerraform(struct?: TfStorageLensConfiguration.AccountLevelPropertyOutputReference | TfStorageLensConfiguration.AccountLevelProperty): any;
export declare function tfStorageLensConfigurationAwsOrgPropertyToTerraform(struct?: TfStorageLensConfiguration.AwsOrgPropertyOutputReference | TfStorageLensConfiguration.AwsOrgProperty): any;
export declare function tfStorageLensConfigurationAwsOrgPropertyToHclTerraform(struct?: TfStorageLensConfiguration.AwsOrgPropertyOutputReference | TfStorageLensConfiguration.AwsOrgProperty): any;
export declare function tfStorageLensConfigurationCloudWatchMetricsPropertyToTerraform(struct?: TfStorageLensConfiguration.CloudWatchMetricsPropertyOutputReference | TfStorageLensConfiguration.CloudWatchMetricsProperty): any;
export declare function tfStorageLensConfigurationCloudWatchMetricsPropertyToHclTerraform(struct?: TfStorageLensConfiguration.CloudWatchMetricsPropertyOutputReference | TfStorageLensConfiguration.CloudWatchMetricsProperty): any;
export declare function tfStorageLensConfigurationStorageLensConfigurationDataExportS3BucketDestinationEncryptionSseKmsPropertyToTerraform(struct?: TfStorageLensConfiguration.StorageLensConfigurationDataExportS3BucketDestinationEncryptionSseKmsPropertyOutputReference | TfStorageLensConfiguration.StorageLensConfigurationDataExportS3BucketDestinationEncryptionSseKmsProperty): any;
export declare function tfStorageLensConfigurationStorageLensConfigurationDataExportS3BucketDestinationEncryptionSseKmsPropertyToHclTerraform(struct?: TfStorageLensConfiguration.StorageLensConfigurationDataExportS3BucketDestinationEncryptionSseKmsPropertyOutputReference | TfStorageLensConfiguration.StorageLensConfigurationDataExportS3BucketDestinationEncryptionSseKmsProperty): any;
export declare function tfStorageLensConfigurationStorageLensConfigurationDataExportS3BucketDestinationEncryptionSseS3PropertyToTerraform(struct?: TfStorageLensConfiguration.StorageLensConfigurationDataExportS3BucketDestinationEncryptionSseS3Property | cdktn.IResolvable): any;
export declare function tfStorageLensConfigurationStorageLensConfigurationDataExportS3BucketDestinationEncryptionSseS3PropertyToHclTerraform(struct?: TfStorageLensConfiguration.StorageLensConfigurationDataExportS3BucketDestinationEncryptionSseS3Property | cdktn.IResolvable): any;
export declare function tfStorageLensConfigurationStorageLensConfigurationDataExportS3BucketDestinationEncryptionPropertyToTerraform(struct?: TfStorageLensConfiguration.StorageLensConfigurationDataExportS3BucketDestinationEncryptionPropertyOutputReference | TfStorageLensConfiguration.StorageLensConfigurationDataExportS3BucketDestinationEncryptionProperty): any;
export declare function tfStorageLensConfigurationStorageLensConfigurationDataExportS3BucketDestinationEncryptionPropertyToHclTerraform(struct?: TfStorageLensConfiguration.StorageLensConfigurationDataExportS3BucketDestinationEncryptionPropertyOutputReference | TfStorageLensConfiguration.StorageLensConfigurationDataExportS3BucketDestinationEncryptionProperty): any;
export declare function tfStorageLensConfigurationStorageLensConfigurationDataExportS3BucketDestinationPropertyToTerraform(struct?: TfStorageLensConfiguration.StorageLensConfigurationDataExportS3BucketDestinationPropertyOutputReference | TfStorageLensConfiguration.StorageLensConfigurationDataExportS3BucketDestinationProperty): any;
export declare function tfStorageLensConfigurationStorageLensConfigurationDataExportS3BucketDestinationPropertyToHclTerraform(struct?: TfStorageLensConfiguration.StorageLensConfigurationDataExportS3BucketDestinationPropertyOutputReference | TfStorageLensConfiguration.StorageLensConfigurationDataExportS3BucketDestinationProperty): any;
export declare function tfStorageLensConfigurationStorageLensConfigurationDataExportStorageLensTableDestinationEncryptionSseKmsPropertyToTerraform(struct?: TfStorageLensConfiguration.StorageLensConfigurationDataExportStorageLensTableDestinationEncryptionSseKmsPropertyOutputReference | TfStorageLensConfiguration.StorageLensConfigurationDataExportStorageLensTableDestinationEncryptionSseKmsProperty): any;
export declare function tfStorageLensConfigurationStorageLensConfigurationDataExportStorageLensTableDestinationEncryptionSseKmsPropertyToHclTerraform(struct?: TfStorageLensConfiguration.StorageLensConfigurationDataExportStorageLensTableDestinationEncryptionSseKmsPropertyOutputReference | TfStorageLensConfiguration.StorageLensConfigurationDataExportStorageLensTableDestinationEncryptionSseKmsProperty): any;
export declare function tfStorageLensConfigurationStorageLensConfigurationDataExportStorageLensTableDestinationEncryptionSseS3PropertyToTerraform(struct?: TfStorageLensConfiguration.StorageLensConfigurationDataExportStorageLensTableDestinationEncryptionSseS3Property | cdktn.IResolvable): any;
export declare function tfStorageLensConfigurationStorageLensConfigurationDataExportStorageLensTableDestinationEncryptionSseS3PropertyToHclTerraform(struct?: TfStorageLensConfiguration.StorageLensConfigurationDataExportStorageLensTableDestinationEncryptionSseS3Property | cdktn.IResolvable): any;
export declare function tfStorageLensConfigurationStorageLensConfigurationDataExportStorageLensTableDestinationEncryptionPropertyToTerraform(struct?: TfStorageLensConfiguration.StorageLensConfigurationDataExportStorageLensTableDestinationEncryptionPropertyOutputReference | TfStorageLensConfiguration.StorageLensConfigurationDataExportStorageLensTableDestinationEncryptionProperty): any;
export declare function tfStorageLensConfigurationStorageLensConfigurationDataExportStorageLensTableDestinationEncryptionPropertyToHclTerraform(struct?: TfStorageLensConfiguration.StorageLensConfigurationDataExportStorageLensTableDestinationEncryptionPropertyOutputReference | TfStorageLensConfiguration.StorageLensConfigurationDataExportStorageLensTableDestinationEncryptionProperty): any;
export declare function tfStorageLensConfigurationStorageLensConfigurationDataExportStorageLensTableDestinationPropertyToTerraform(struct?: TfStorageLensConfiguration.StorageLensConfigurationDataExportStorageLensTableDestinationPropertyOutputReference | TfStorageLensConfiguration.StorageLensConfigurationDataExportStorageLensTableDestinationProperty): any;
export declare function tfStorageLensConfigurationStorageLensConfigurationDataExportStorageLensTableDestinationPropertyToHclTerraform(struct?: TfStorageLensConfiguration.StorageLensConfigurationDataExportStorageLensTableDestinationPropertyOutputReference | TfStorageLensConfiguration.StorageLensConfigurationDataExportStorageLensTableDestinationProperty): any;
export declare function tfStorageLensConfigurationDataExportPropertyToTerraform(struct?: TfStorageLensConfiguration.DataExportPropertyOutputReference | TfStorageLensConfiguration.DataExportProperty): any;
export declare function tfStorageLensConfigurationDataExportPropertyToHclTerraform(struct?: TfStorageLensConfiguration.DataExportPropertyOutputReference | TfStorageLensConfiguration.DataExportProperty): any;
export declare function tfStorageLensConfigurationExcludePropertyToTerraform(struct?: TfStorageLensConfiguration.ExcludePropertyOutputReference | TfStorageLensConfiguration.ExcludeProperty): any;
export declare function tfStorageLensConfigurationExcludePropertyToHclTerraform(struct?: TfStorageLensConfiguration.ExcludePropertyOutputReference | TfStorageLensConfiguration.ExcludeProperty): any;
export declare function tfStorageLensConfigurationStorageLensConfigurationExpandedPrefixesDataExportS3BucketDestinationEncryptionSseKmsPropertyToTerraform(struct?: TfStorageLensConfiguration.StorageLensConfigurationExpandedPrefixesDataExportS3BucketDestinationEncryptionSseKmsPropertyOutputReference | TfStorageLensConfiguration.StorageLensConfigurationExpandedPrefixesDataExportS3BucketDestinationEncryptionSseKmsProperty): any;
export declare function tfStorageLensConfigurationStorageLensConfigurationExpandedPrefixesDataExportS3BucketDestinationEncryptionSseKmsPropertyToHclTerraform(struct?: TfStorageLensConfiguration.StorageLensConfigurationExpandedPrefixesDataExportS3BucketDestinationEncryptionSseKmsPropertyOutputReference | TfStorageLensConfiguration.StorageLensConfigurationExpandedPrefixesDataExportS3BucketDestinationEncryptionSseKmsProperty): any;
export declare function tfStorageLensConfigurationStorageLensConfigurationExpandedPrefixesDataExportS3BucketDestinationEncryptionSseS3PropertyToTerraform(struct?: TfStorageLensConfiguration.StorageLensConfigurationExpandedPrefixesDataExportS3BucketDestinationEncryptionSseS3Property | cdktn.IResolvable): any;
export declare function tfStorageLensConfigurationStorageLensConfigurationExpandedPrefixesDataExportS3BucketDestinationEncryptionSseS3PropertyToHclTerraform(struct?: TfStorageLensConfiguration.StorageLensConfigurationExpandedPrefixesDataExportS3BucketDestinationEncryptionSseS3Property | cdktn.IResolvable): any;
export declare function tfStorageLensConfigurationStorageLensConfigurationExpandedPrefixesDataExportS3BucketDestinationEncryptionPropertyToTerraform(struct?: TfStorageLensConfiguration.StorageLensConfigurationExpandedPrefixesDataExportS3BucketDestinationEncryptionPropertyOutputReference | TfStorageLensConfiguration.StorageLensConfigurationExpandedPrefixesDataExportS3BucketDestinationEncryptionProperty): any;
export declare function tfStorageLensConfigurationStorageLensConfigurationExpandedPrefixesDataExportS3BucketDestinationEncryptionPropertyToHclTerraform(struct?: TfStorageLensConfiguration.StorageLensConfigurationExpandedPrefixesDataExportS3BucketDestinationEncryptionPropertyOutputReference | TfStorageLensConfiguration.StorageLensConfigurationExpandedPrefixesDataExportS3BucketDestinationEncryptionProperty): any;
export declare function tfStorageLensConfigurationStorageLensConfigurationExpandedPrefixesDataExportS3BucketDestinationPropertyToTerraform(struct?: TfStorageLensConfiguration.StorageLensConfigurationExpandedPrefixesDataExportS3BucketDestinationPropertyOutputReference | TfStorageLensConfiguration.StorageLensConfigurationExpandedPrefixesDataExportS3BucketDestinationProperty): any;
export declare function tfStorageLensConfigurationStorageLensConfigurationExpandedPrefixesDataExportS3BucketDestinationPropertyToHclTerraform(struct?: TfStorageLensConfiguration.StorageLensConfigurationExpandedPrefixesDataExportS3BucketDestinationPropertyOutputReference | TfStorageLensConfiguration.StorageLensConfigurationExpandedPrefixesDataExportS3BucketDestinationProperty): any;
export declare function tfStorageLensConfigurationStorageLensConfigurationExpandedPrefixesDataExportStorageLensTableDestinationEncryptionSseKmsPropertyToTerraform(struct?: TfStorageLensConfiguration.StorageLensConfigurationExpandedPrefixesDataExportStorageLensTableDestinationEncryptionSseKmsPropertyOutputReference | TfStorageLensConfiguration.StorageLensConfigurationExpandedPrefixesDataExportStorageLensTableDestinationEncryptionSseKmsProperty): any;
export declare function tfStorageLensConfigurationStorageLensConfigurationExpandedPrefixesDataExportStorageLensTableDestinationEncryptionSseKmsPropertyToHclTerraform(struct?: TfStorageLensConfiguration.StorageLensConfigurationExpandedPrefixesDataExportStorageLensTableDestinationEncryptionSseKmsPropertyOutputReference | TfStorageLensConfiguration.StorageLensConfigurationExpandedPrefixesDataExportStorageLensTableDestinationEncryptionSseKmsProperty): any;
export declare function tfStorageLensConfigurationStorageLensConfigurationExpandedPrefixesDataExportStorageLensTableDestinationEncryptionSseS3PropertyToTerraform(struct?: TfStorageLensConfiguration.StorageLensConfigurationExpandedPrefixesDataExportStorageLensTableDestinationEncryptionSseS3Property | cdktn.IResolvable): any;
export declare function tfStorageLensConfigurationStorageLensConfigurationExpandedPrefixesDataExportStorageLensTableDestinationEncryptionSseS3PropertyToHclTerraform(struct?: TfStorageLensConfiguration.StorageLensConfigurationExpandedPrefixesDataExportStorageLensTableDestinationEncryptionSseS3Property | cdktn.IResolvable): any;
export declare function tfStorageLensConfigurationStorageLensConfigurationExpandedPrefixesDataExportStorageLensTableDestinationEncryptionPropertyToTerraform(struct?: TfStorageLensConfiguration.StorageLensConfigurationExpandedPrefixesDataExportStorageLensTableDestinationEncryptionPropertyOutputReference | TfStorageLensConfiguration.StorageLensConfigurationExpandedPrefixesDataExportStorageLensTableDestinationEncryptionProperty): any;
export declare function tfStorageLensConfigurationStorageLensConfigurationExpandedPrefixesDataExportStorageLensTableDestinationEncryptionPropertyToHclTerraform(struct?: TfStorageLensConfiguration.StorageLensConfigurationExpandedPrefixesDataExportStorageLensTableDestinationEncryptionPropertyOutputReference | TfStorageLensConfiguration.StorageLensConfigurationExpandedPrefixesDataExportStorageLensTableDestinationEncryptionProperty): any;
export declare function tfStorageLensConfigurationStorageLensConfigurationExpandedPrefixesDataExportStorageLensTableDestinationPropertyToTerraform(struct?: TfStorageLensConfiguration.StorageLensConfigurationExpandedPrefixesDataExportStorageLensTableDestinationPropertyOutputReference | TfStorageLensConfiguration.StorageLensConfigurationExpandedPrefixesDataExportStorageLensTableDestinationProperty): any;
export declare function tfStorageLensConfigurationStorageLensConfigurationExpandedPrefixesDataExportStorageLensTableDestinationPropertyToHclTerraform(struct?: TfStorageLensConfiguration.StorageLensConfigurationExpandedPrefixesDataExportStorageLensTableDestinationPropertyOutputReference | TfStorageLensConfiguration.StorageLensConfigurationExpandedPrefixesDataExportStorageLensTableDestinationProperty): any;
export declare function tfStorageLensConfigurationExpandedPrefixesDataExportPropertyToTerraform(struct?: TfStorageLensConfiguration.ExpandedPrefixesDataExportPropertyOutputReference | TfStorageLensConfiguration.ExpandedPrefixesDataExportProperty): any;
export declare function tfStorageLensConfigurationExpandedPrefixesDataExportPropertyToHclTerraform(struct?: TfStorageLensConfiguration.ExpandedPrefixesDataExportPropertyOutputReference | TfStorageLensConfiguration.ExpandedPrefixesDataExportProperty): any;
export declare function tfStorageLensConfigurationIncludePropertyToTerraform(struct?: TfStorageLensConfiguration.IncludePropertyOutputReference | TfStorageLensConfiguration.IncludeProperty): any;
export declare function tfStorageLensConfigurationIncludePropertyToHclTerraform(struct?: TfStorageLensConfiguration.IncludePropertyOutputReference | TfStorageLensConfiguration.IncludeProperty): any;
export declare function tfStorageLensConfigurationStorageLensConfigurationPropertyToTerraform(struct?: TfStorageLensConfiguration.StorageLensConfigurationPropertyOutputReference | TfStorageLensConfiguration.StorageLensConfigurationProperty): any;
export declare function tfStorageLensConfigurationStorageLensConfigurationPropertyToHclTerraform(struct?: TfStorageLensConfiguration.StorageLensConfigurationPropertyOutputReference | TfStorageLensConfiguration.StorageLensConfigurationProperty): any;
export declare namespace TfStorageLensConfiguration {
    interface StorageLensConfigurationAccountLevelActivityMetricsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_storage_lens_configuration#enabled TfStorageLensConfiguration#enabled}
        */
        readonly enabled?: boolean | cdktn.IResolvable;
    }
    class StorageLensConfigurationAccountLevelActivityMetricsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): StorageLensConfigurationAccountLevelActivityMetricsProperty | undefined;
        set internalValue(value: StorageLensConfigurationAccountLevelActivityMetricsProperty | undefined);
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        resetEnabled(): void;
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface StorageLensConfigurationAccountLevelAdvancedCostOptimizationMetricsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_storage_lens_configuration#enabled TfStorageLensConfiguration#enabled}
        */
        readonly enabled?: boolean | cdktn.IResolvable;
    }
    class StorageLensConfigurationAccountLevelAdvancedCostOptimizationMetricsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): StorageLensConfigurationAccountLevelAdvancedCostOptimizationMetricsProperty | undefined;
        set internalValue(value: StorageLensConfigurationAccountLevelAdvancedCostOptimizationMetricsProperty | undefined);
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        resetEnabled(): void;
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface StorageLensConfigurationAccountLevelAdvancedDataProtectionMetricsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_storage_lens_configuration#enabled TfStorageLensConfiguration#enabled}
        */
        readonly enabled?: boolean | cdktn.IResolvable;
    }
    class StorageLensConfigurationAccountLevelAdvancedDataProtectionMetricsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): StorageLensConfigurationAccountLevelAdvancedDataProtectionMetricsProperty | undefined;
        set internalValue(value: StorageLensConfigurationAccountLevelAdvancedDataProtectionMetricsProperty | undefined);
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        resetEnabled(): void;
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface StorageLensConfigurationAccountLevelAdvancedPerformanceMetricsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_storage_lens_configuration#enabled TfStorageLensConfiguration#enabled}
        */
        readonly enabled?: boolean | cdktn.IResolvable;
    }
    class StorageLensConfigurationAccountLevelAdvancedPerformanceMetricsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): StorageLensConfigurationAccountLevelAdvancedPerformanceMetricsProperty | undefined;
        set internalValue(value: StorageLensConfigurationAccountLevelAdvancedPerformanceMetricsProperty | undefined);
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        resetEnabled(): void;
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface StorageLensConfigurationAccountLevelBucketLevelActivityMetricsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_storage_lens_configuration#enabled TfStorageLensConfiguration#enabled}
        */
        readonly enabled?: boolean | cdktn.IResolvable;
    }
    class StorageLensConfigurationAccountLevelBucketLevelActivityMetricsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): StorageLensConfigurationAccountLevelBucketLevelActivityMetricsProperty | undefined;
        set internalValue(value: StorageLensConfigurationAccountLevelBucketLevelActivityMetricsProperty | undefined);
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        resetEnabled(): void;
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface StorageLensConfigurationAccountLevelBucketLevelAdvancedCostOptimizationMetricsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_storage_lens_configuration#enabled TfStorageLensConfiguration#enabled}
        */
        readonly enabled?: boolean | cdktn.IResolvable;
    }
    class StorageLensConfigurationAccountLevelBucketLevelAdvancedCostOptimizationMetricsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): StorageLensConfigurationAccountLevelBucketLevelAdvancedCostOptimizationMetricsProperty | undefined;
        set internalValue(value: StorageLensConfigurationAccountLevelBucketLevelAdvancedCostOptimizationMetricsProperty | undefined);
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        resetEnabled(): void;
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface StorageLensConfigurationAccountLevelBucketLevelAdvancedDataProtectionMetricsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_storage_lens_configuration#enabled TfStorageLensConfiguration#enabled}
        */
        readonly enabled?: boolean | cdktn.IResolvable;
    }
    class StorageLensConfigurationAccountLevelBucketLevelAdvancedDataProtectionMetricsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): StorageLensConfigurationAccountLevelBucketLevelAdvancedDataProtectionMetricsProperty | undefined;
        set internalValue(value: StorageLensConfigurationAccountLevelBucketLevelAdvancedDataProtectionMetricsProperty | undefined);
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        resetEnabled(): void;
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface StorageLensConfigurationAccountLevelBucketLevelAdvancedPerformanceMetricsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_storage_lens_configuration#enabled TfStorageLensConfiguration#enabled}
        */
        readonly enabled?: boolean | cdktn.IResolvable;
    }
    class StorageLensConfigurationAccountLevelBucketLevelAdvancedPerformanceMetricsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): StorageLensConfigurationAccountLevelBucketLevelAdvancedPerformanceMetricsProperty | undefined;
        set internalValue(value: StorageLensConfigurationAccountLevelBucketLevelAdvancedPerformanceMetricsProperty | undefined);
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        resetEnabled(): void;
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface StorageLensConfigurationAccountLevelBucketLevelDetailedStatusCodeMetricsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_storage_lens_configuration#enabled TfStorageLensConfiguration#enabled}
        */
        readonly enabled?: boolean | cdktn.IResolvable;
    }
    class StorageLensConfigurationAccountLevelBucketLevelDetailedStatusCodeMetricsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): StorageLensConfigurationAccountLevelBucketLevelDetailedStatusCodeMetricsProperty | undefined;
        set internalValue(value: StorageLensConfigurationAccountLevelBucketLevelDetailedStatusCodeMetricsProperty | undefined);
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        resetEnabled(): void;
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface SelectionCriteriaProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_storage_lens_configuration#delimiter TfStorageLensConfiguration#delimiter}
        */
        readonly delimiter?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_storage_lens_configuration#max_depth TfStorageLensConfiguration#max_depth}
        */
        readonly maxDepth?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_storage_lens_configuration#min_storage_bytes_percentage TfStorageLensConfiguration#min_storage_bytes_percentage}
        */
        readonly minStorageBytesPercentage?: number;
    }
    class SelectionCriteriaPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SelectionCriteriaProperty | undefined;
        set internalValue(value: SelectionCriteriaProperty | undefined);
        private _delimiter?;
        get delimiter(): string;
        set delimiter(value: string);
        resetDelimiter(): void;
        get delimiterInput(): string | undefined;
        private _maxDepth?;
        get maxDepth(): number;
        set maxDepth(value: number);
        resetMaxDepth(): void;
        get maxDepthInput(): number | undefined;
        private _minStorageBytesPercentage?;
        get minStorageBytesPercentage(): number;
        set minStorageBytesPercentage(value: number);
        resetMinStorageBytesPercentage(): void;
        get minStorageBytesPercentageInput(): number | undefined;
    }
    interface StorageMetricsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_storage_lens_configuration#enabled TfStorageLensConfiguration#enabled}
        */
        readonly enabled?: boolean | cdktn.IResolvable;
        /**
        * selection_criteria block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_storage_lens_configuration#selection_criteria TfStorageLensConfiguration#selection_criteria}
        */
        readonly selectionCriteria?: SelectionCriteriaProperty;
    }
    class StorageMetricsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): StorageMetricsProperty | undefined;
        set internalValue(value: StorageMetricsProperty | undefined);
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        resetEnabled(): void;
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
        private _selectionCriteria;
        get selectionCriteria(): SelectionCriteriaPropertyOutputReference;
        putSelectionCriteria(value: SelectionCriteriaProperty): void;
        resetSelectionCriteria(): void;
        get selectionCriteriaInput(): SelectionCriteriaProperty | undefined;
    }
    interface PrefixLevelProperty {
        /**
        * storage_metrics block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_storage_lens_configuration#storage_metrics TfStorageLensConfiguration#storage_metrics}
        */
        readonly storageMetrics: StorageMetricsProperty;
    }
    class PrefixLevelPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): PrefixLevelProperty | undefined;
        set internalValue(value: PrefixLevelProperty | undefined);
        private _storageMetrics;
        get storageMetrics(): StorageMetricsPropertyOutputReference;
        putStorageMetrics(value: StorageMetricsProperty): void;
        get storageMetricsInput(): StorageMetricsProperty | undefined;
    }
    interface BucketLevelProperty {
        /**
        * activity_metrics block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_storage_lens_configuration#activity_metrics TfStorageLensConfiguration#activity_metrics}
        */
        readonly activityMetrics?: StorageLensConfigurationAccountLevelBucketLevelActivityMetricsProperty;
        /**
        * advanced_cost_optimization_metrics block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_storage_lens_configuration#advanced_cost_optimization_metrics TfStorageLensConfiguration#advanced_cost_optimization_metrics}
        */
        readonly advancedCostOptimizationMetrics?: StorageLensConfigurationAccountLevelBucketLevelAdvancedCostOptimizationMetricsProperty;
        /**
        * advanced_data_protection_metrics block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_storage_lens_configuration#advanced_data_protection_metrics TfStorageLensConfiguration#advanced_data_protection_metrics}
        */
        readonly advancedDataProtectionMetrics?: StorageLensConfigurationAccountLevelBucketLevelAdvancedDataProtectionMetricsProperty;
        /**
        * advanced_performance_metrics block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_storage_lens_configuration#advanced_performance_metrics TfStorageLensConfiguration#advanced_performance_metrics}
        */
        readonly advancedPerformanceMetrics?: StorageLensConfigurationAccountLevelBucketLevelAdvancedPerformanceMetricsProperty;
        /**
        * detailed_status_code_metrics block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_storage_lens_configuration#detailed_status_code_metrics TfStorageLensConfiguration#detailed_status_code_metrics}
        */
        readonly detailedStatusCodeMetrics?: StorageLensConfigurationAccountLevelBucketLevelDetailedStatusCodeMetricsProperty;
        /**
        * prefix_level block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_storage_lens_configuration#prefix_level TfStorageLensConfiguration#prefix_level}
        */
        readonly prefixLevel?: PrefixLevelProperty;
    }
    class BucketLevelPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): BucketLevelProperty | undefined;
        set internalValue(value: BucketLevelProperty | undefined);
        private _activityMetrics;
        get activityMetrics(): StorageLensConfigurationAccountLevelBucketLevelActivityMetricsPropertyOutputReference;
        putActivityMetrics(value: StorageLensConfigurationAccountLevelBucketLevelActivityMetricsProperty): void;
        resetActivityMetrics(): void;
        get activityMetricsInput(): StorageLensConfigurationAccountLevelBucketLevelActivityMetricsProperty | undefined;
        private _advancedCostOptimizationMetrics;
        get advancedCostOptimizationMetrics(): StorageLensConfigurationAccountLevelBucketLevelAdvancedCostOptimizationMetricsPropertyOutputReference;
        putAdvancedCostOptimizationMetrics(value: StorageLensConfigurationAccountLevelBucketLevelAdvancedCostOptimizationMetricsProperty): void;
        resetAdvancedCostOptimizationMetrics(): void;
        get advancedCostOptimizationMetricsInput(): StorageLensConfigurationAccountLevelBucketLevelAdvancedCostOptimizationMetricsProperty | undefined;
        private _advancedDataProtectionMetrics;
        get advancedDataProtectionMetrics(): StorageLensConfigurationAccountLevelBucketLevelAdvancedDataProtectionMetricsPropertyOutputReference;
        putAdvancedDataProtectionMetrics(value: StorageLensConfigurationAccountLevelBucketLevelAdvancedDataProtectionMetricsProperty): void;
        resetAdvancedDataProtectionMetrics(): void;
        get advancedDataProtectionMetricsInput(): StorageLensConfigurationAccountLevelBucketLevelAdvancedDataProtectionMetricsProperty | undefined;
        private _advancedPerformanceMetrics;
        get advancedPerformanceMetrics(): StorageLensConfigurationAccountLevelBucketLevelAdvancedPerformanceMetricsPropertyOutputReference;
        putAdvancedPerformanceMetrics(value: StorageLensConfigurationAccountLevelBucketLevelAdvancedPerformanceMetricsProperty): void;
        resetAdvancedPerformanceMetrics(): void;
        get advancedPerformanceMetricsInput(): StorageLensConfigurationAccountLevelBucketLevelAdvancedPerformanceMetricsProperty | undefined;
        private _detailedStatusCodeMetrics;
        get detailedStatusCodeMetrics(): StorageLensConfigurationAccountLevelBucketLevelDetailedStatusCodeMetricsPropertyOutputReference;
        putDetailedStatusCodeMetrics(value: StorageLensConfigurationAccountLevelBucketLevelDetailedStatusCodeMetricsProperty): void;
        resetDetailedStatusCodeMetrics(): void;
        get detailedStatusCodeMetricsInput(): StorageLensConfigurationAccountLevelBucketLevelDetailedStatusCodeMetricsProperty | undefined;
        private _prefixLevel;
        get prefixLevel(): PrefixLevelPropertyOutputReference;
        putPrefixLevel(value: PrefixLevelProperty): void;
        resetPrefixLevel(): void;
        get prefixLevelInput(): PrefixLevelProperty | undefined;
    }
    interface StorageLensConfigurationAccountLevelDetailedStatusCodeMetricsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_storage_lens_configuration#enabled TfStorageLensConfiguration#enabled}
        */
        readonly enabled?: boolean | cdktn.IResolvable;
    }
    class StorageLensConfigurationAccountLevelDetailedStatusCodeMetricsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): StorageLensConfigurationAccountLevelDetailedStatusCodeMetricsProperty | undefined;
        set internalValue(value: StorageLensConfigurationAccountLevelDetailedStatusCodeMetricsProperty | undefined);
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        resetEnabled(): void;
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface AccountLevelProperty {
        /**
        * activity_metrics block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_storage_lens_configuration#activity_metrics TfStorageLensConfiguration#activity_metrics}
        */
        readonly activityMetrics?: StorageLensConfigurationAccountLevelActivityMetricsProperty;
        /**
        * advanced_cost_optimization_metrics block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_storage_lens_configuration#advanced_cost_optimization_metrics TfStorageLensConfiguration#advanced_cost_optimization_metrics}
        */
        readonly advancedCostOptimizationMetrics?: StorageLensConfigurationAccountLevelAdvancedCostOptimizationMetricsProperty;
        /**
        * advanced_data_protection_metrics block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_storage_lens_configuration#advanced_data_protection_metrics TfStorageLensConfiguration#advanced_data_protection_metrics}
        */
        readonly advancedDataProtectionMetrics?: StorageLensConfigurationAccountLevelAdvancedDataProtectionMetricsProperty;
        /**
        * advanced_performance_metrics block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_storage_lens_configuration#advanced_performance_metrics TfStorageLensConfiguration#advanced_performance_metrics}
        */
        readonly advancedPerformanceMetrics?: StorageLensConfigurationAccountLevelAdvancedPerformanceMetricsProperty;
        /**
        * bucket_level block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_storage_lens_configuration#bucket_level TfStorageLensConfiguration#bucket_level}
        */
        readonly bucketLevel: BucketLevelProperty;
        /**
        * detailed_status_code_metrics block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_storage_lens_configuration#detailed_status_code_metrics TfStorageLensConfiguration#detailed_status_code_metrics}
        */
        readonly detailedStatusCodeMetrics?: StorageLensConfigurationAccountLevelDetailedStatusCodeMetricsProperty;
    }
    class AccountLevelPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AccountLevelProperty | undefined;
        set internalValue(value: AccountLevelProperty | undefined);
        private _activityMetrics;
        get activityMetrics(): StorageLensConfigurationAccountLevelActivityMetricsPropertyOutputReference;
        putActivityMetrics(value: StorageLensConfigurationAccountLevelActivityMetricsProperty): void;
        resetActivityMetrics(): void;
        get activityMetricsInput(): StorageLensConfigurationAccountLevelActivityMetricsProperty | undefined;
        private _advancedCostOptimizationMetrics;
        get advancedCostOptimizationMetrics(): StorageLensConfigurationAccountLevelAdvancedCostOptimizationMetricsPropertyOutputReference;
        putAdvancedCostOptimizationMetrics(value: StorageLensConfigurationAccountLevelAdvancedCostOptimizationMetricsProperty): void;
        resetAdvancedCostOptimizationMetrics(): void;
        get advancedCostOptimizationMetricsInput(): StorageLensConfigurationAccountLevelAdvancedCostOptimizationMetricsProperty | undefined;
        private _advancedDataProtectionMetrics;
        get advancedDataProtectionMetrics(): StorageLensConfigurationAccountLevelAdvancedDataProtectionMetricsPropertyOutputReference;
        putAdvancedDataProtectionMetrics(value: StorageLensConfigurationAccountLevelAdvancedDataProtectionMetricsProperty): void;
        resetAdvancedDataProtectionMetrics(): void;
        get advancedDataProtectionMetricsInput(): StorageLensConfigurationAccountLevelAdvancedDataProtectionMetricsProperty | undefined;
        private _advancedPerformanceMetrics;
        get advancedPerformanceMetrics(): StorageLensConfigurationAccountLevelAdvancedPerformanceMetricsPropertyOutputReference;
        putAdvancedPerformanceMetrics(value: StorageLensConfigurationAccountLevelAdvancedPerformanceMetricsProperty): void;
        resetAdvancedPerformanceMetrics(): void;
        get advancedPerformanceMetricsInput(): StorageLensConfigurationAccountLevelAdvancedPerformanceMetricsProperty | undefined;
        private _bucketLevel;
        get bucketLevel(): BucketLevelPropertyOutputReference;
        putBucketLevel(value: BucketLevelProperty): void;
        get bucketLevelInput(): BucketLevelProperty | undefined;
        private _detailedStatusCodeMetrics;
        get detailedStatusCodeMetrics(): StorageLensConfigurationAccountLevelDetailedStatusCodeMetricsPropertyOutputReference;
        putDetailedStatusCodeMetrics(value: StorageLensConfigurationAccountLevelDetailedStatusCodeMetricsProperty): void;
        resetDetailedStatusCodeMetrics(): void;
        get detailedStatusCodeMetricsInput(): StorageLensConfigurationAccountLevelDetailedStatusCodeMetricsProperty | undefined;
    }
    interface AwsOrgProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_storage_lens_configuration#arn TfStorageLensConfiguration#arn}
        */
        readonly arn: string;
    }
    class AwsOrgPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AwsOrgProperty | undefined;
        set internalValue(value: AwsOrgProperty | undefined);
        private _arn?;
        get arn(): string;
        set arn(value: string);
        get arnInput(): string | undefined;
    }
    interface CloudWatchMetricsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_storage_lens_configuration#enabled TfStorageLensConfiguration#enabled}
        */
        readonly enabled: boolean | cdktn.IResolvable;
    }
    class CloudWatchMetricsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CloudWatchMetricsProperty | undefined;
        set internalValue(value: CloudWatchMetricsProperty | undefined);
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface StorageLensConfigurationDataExportS3BucketDestinationEncryptionSseKmsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_storage_lens_configuration#key_id TfStorageLensConfiguration#key_id}
        */
        readonly keyId: string;
    }
    class StorageLensConfigurationDataExportS3BucketDestinationEncryptionSseKmsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): StorageLensConfigurationDataExportS3BucketDestinationEncryptionSseKmsProperty | undefined;
        set internalValue(value: StorageLensConfigurationDataExportS3BucketDestinationEncryptionSseKmsProperty | undefined);
        private _keyId?;
        get keyId(): string;
        set keyId(value: string);
        get keyIdInput(): string | undefined;
    }
    interface StorageLensConfigurationDataExportS3BucketDestinationEncryptionSseS3Property {
    }
    class StorageLensConfigurationDataExportS3BucketDestinationEncryptionSseS3PropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): StorageLensConfigurationDataExportS3BucketDestinationEncryptionSseS3Property | cdktn.IResolvable | undefined;
        set internalValue(value: StorageLensConfigurationDataExportS3BucketDestinationEncryptionSseS3Property | cdktn.IResolvable | undefined);
    }
    class StorageLensConfigurationDataExportS3BucketDestinationEncryptionSseS3PropertyList extends cdktn.ComplexList {
        internalValue?: StorageLensConfigurationDataExportS3BucketDestinationEncryptionSseS3Property[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): StorageLensConfigurationDataExportS3BucketDestinationEncryptionSseS3PropertyOutputReference;
    }
    interface StorageLensConfigurationDataExportS3BucketDestinationEncryptionProperty {
        /**
        * sse_kms block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_storage_lens_configuration#sse_kms TfStorageLensConfiguration#sse_kms}
        */
        readonly sseKms?: StorageLensConfigurationDataExportS3BucketDestinationEncryptionSseKmsProperty;
        /**
        * sse_s3 block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_storage_lens_configuration#sse_s3 TfStorageLensConfiguration#sse_s3}
        */
        readonly sseS3?: StorageLensConfigurationDataExportS3BucketDestinationEncryptionSseS3Property[] | cdktn.IResolvable;
    }
    class StorageLensConfigurationDataExportS3BucketDestinationEncryptionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): StorageLensConfigurationDataExportS3BucketDestinationEncryptionProperty | undefined;
        set internalValue(value: StorageLensConfigurationDataExportS3BucketDestinationEncryptionProperty | undefined);
        private _sseKms;
        get sseKms(): StorageLensConfigurationDataExportS3BucketDestinationEncryptionSseKmsPropertyOutputReference;
        putSseKms(value: StorageLensConfigurationDataExportS3BucketDestinationEncryptionSseKmsProperty): void;
        resetSseKms(): void;
        get sseKmsInput(): StorageLensConfigurationDataExportS3BucketDestinationEncryptionSseKmsProperty | undefined;
        private _sseS3;
        get sseS3(): StorageLensConfigurationDataExportS3BucketDestinationEncryptionSseS3PropertyList;
        putSseS3(value: StorageLensConfigurationDataExportS3BucketDestinationEncryptionSseS3Property[] | cdktn.IResolvable): void;
        resetSseS3(): void;
        get sseS3Input(): cdktn.IResolvable | StorageLensConfigurationDataExportS3BucketDestinationEncryptionSseS3Property[] | undefined;
    }
    interface StorageLensConfigurationDataExportS3BucketDestinationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_storage_lens_configuration#account_id TfStorageLensConfiguration#account_id}
        */
        readonly accountId: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_storage_lens_configuration#arn TfStorageLensConfiguration#arn}
        */
        readonly arn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_storage_lens_configuration#format TfStorageLensConfiguration#format}
        */
        readonly format: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_storage_lens_configuration#output_schema_version TfStorageLensConfiguration#output_schema_version}
        */
        readonly outputSchemaVersion: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_storage_lens_configuration#prefix TfStorageLensConfiguration#prefix}
        */
        readonly prefix?: string;
        /**
        * encryption block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_storage_lens_configuration#encryption TfStorageLensConfiguration#encryption}
        */
        readonly encryption?: StorageLensConfigurationDataExportS3BucketDestinationEncryptionProperty;
    }
    class StorageLensConfigurationDataExportS3BucketDestinationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): StorageLensConfigurationDataExportS3BucketDestinationProperty | undefined;
        set internalValue(value: StorageLensConfigurationDataExportS3BucketDestinationProperty | undefined);
        private _accountId?;
        get accountId(): string;
        set accountId(value: string);
        get accountIdInput(): string | undefined;
        private _arn?;
        get arn(): string;
        set arn(value: string);
        get arnInput(): string | undefined;
        private _format?;
        get format(): string;
        set format(value: string);
        get formatInput(): string | undefined;
        private _outputSchemaVersion?;
        get outputSchemaVersion(): string;
        set outputSchemaVersion(value: string);
        get outputSchemaVersionInput(): string | undefined;
        private _prefix?;
        get prefix(): string;
        set prefix(value: string);
        resetPrefix(): void;
        get prefixInput(): string | undefined;
        private _encryption;
        get encryption(): StorageLensConfigurationDataExportS3BucketDestinationEncryptionPropertyOutputReference;
        putEncryption(value: StorageLensConfigurationDataExportS3BucketDestinationEncryptionProperty): void;
        resetEncryption(): void;
        get encryptionInput(): StorageLensConfigurationDataExportS3BucketDestinationEncryptionProperty | undefined;
    }
    interface StorageLensConfigurationDataExportStorageLensTableDestinationEncryptionSseKmsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_storage_lens_configuration#key_id TfStorageLensConfiguration#key_id}
        */
        readonly keyId: string;
    }
    class StorageLensConfigurationDataExportStorageLensTableDestinationEncryptionSseKmsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): StorageLensConfigurationDataExportStorageLensTableDestinationEncryptionSseKmsProperty | undefined;
        set internalValue(value: StorageLensConfigurationDataExportStorageLensTableDestinationEncryptionSseKmsProperty | undefined);
        private _keyId?;
        get keyId(): string;
        set keyId(value: string);
        get keyIdInput(): string | undefined;
    }
    interface StorageLensConfigurationDataExportStorageLensTableDestinationEncryptionSseS3Property {
    }
    class StorageLensConfigurationDataExportStorageLensTableDestinationEncryptionSseS3PropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): StorageLensConfigurationDataExportStorageLensTableDestinationEncryptionSseS3Property | cdktn.IResolvable | undefined;
        set internalValue(value: StorageLensConfigurationDataExportStorageLensTableDestinationEncryptionSseS3Property | cdktn.IResolvable | undefined);
    }
    class StorageLensConfigurationDataExportStorageLensTableDestinationEncryptionSseS3PropertyList extends cdktn.ComplexList {
        internalValue?: StorageLensConfigurationDataExportStorageLensTableDestinationEncryptionSseS3Property[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): StorageLensConfigurationDataExportStorageLensTableDestinationEncryptionSseS3PropertyOutputReference;
    }
    interface StorageLensConfigurationDataExportStorageLensTableDestinationEncryptionProperty {
        /**
        * sse_kms block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_storage_lens_configuration#sse_kms TfStorageLensConfiguration#sse_kms}
        */
        readonly sseKms?: StorageLensConfigurationDataExportStorageLensTableDestinationEncryptionSseKmsProperty;
        /**
        * sse_s3 block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_storage_lens_configuration#sse_s3 TfStorageLensConfiguration#sse_s3}
        */
        readonly sseS3?: StorageLensConfigurationDataExportStorageLensTableDestinationEncryptionSseS3Property[] | cdktn.IResolvable;
    }
    class StorageLensConfigurationDataExportStorageLensTableDestinationEncryptionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): StorageLensConfigurationDataExportStorageLensTableDestinationEncryptionProperty | undefined;
        set internalValue(value: StorageLensConfigurationDataExportStorageLensTableDestinationEncryptionProperty | undefined);
        private _sseKms;
        get sseKms(): StorageLensConfigurationDataExportStorageLensTableDestinationEncryptionSseKmsPropertyOutputReference;
        putSseKms(value: StorageLensConfigurationDataExportStorageLensTableDestinationEncryptionSseKmsProperty): void;
        resetSseKms(): void;
        get sseKmsInput(): StorageLensConfigurationDataExportStorageLensTableDestinationEncryptionSseKmsProperty | undefined;
        private _sseS3;
        get sseS3(): StorageLensConfigurationDataExportStorageLensTableDestinationEncryptionSseS3PropertyList;
        putSseS3(value: StorageLensConfigurationDataExportStorageLensTableDestinationEncryptionSseS3Property[] | cdktn.IResolvable): void;
        resetSseS3(): void;
        get sseS3Input(): cdktn.IResolvable | StorageLensConfigurationDataExportStorageLensTableDestinationEncryptionSseS3Property[] | undefined;
    }
    interface StorageLensConfigurationDataExportStorageLensTableDestinationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_storage_lens_configuration#enabled TfStorageLensConfiguration#enabled}
        */
        readonly enabled: boolean | cdktn.IResolvable;
        /**
        * encryption block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_storage_lens_configuration#encryption TfStorageLensConfiguration#encryption}
        */
        readonly encryption?: StorageLensConfigurationDataExportStorageLensTableDestinationEncryptionProperty;
    }
    class StorageLensConfigurationDataExportStorageLensTableDestinationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): StorageLensConfigurationDataExportStorageLensTableDestinationProperty | undefined;
        set internalValue(value: StorageLensConfigurationDataExportStorageLensTableDestinationProperty | undefined);
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
        private _encryption;
        get encryption(): StorageLensConfigurationDataExportStorageLensTableDestinationEncryptionPropertyOutputReference;
        putEncryption(value: StorageLensConfigurationDataExportStorageLensTableDestinationEncryptionProperty): void;
        resetEncryption(): void;
        get encryptionInput(): StorageLensConfigurationDataExportStorageLensTableDestinationEncryptionProperty | undefined;
    }
    interface DataExportProperty {
        /**
        * cloud_watch_metrics block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_storage_lens_configuration#cloud_watch_metrics TfStorageLensConfiguration#cloud_watch_metrics}
        */
        readonly cloudWatchMetrics?: CloudWatchMetricsProperty;
        /**
        * s3_bucket_destination block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_storage_lens_configuration#s3_bucket_destination TfStorageLensConfiguration#s3_bucket_destination}
        */
        readonly s3BucketDestination?: StorageLensConfigurationDataExportS3BucketDestinationProperty;
        /**
        * storage_lens_table_destination block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_storage_lens_configuration#storage_lens_table_destination TfStorageLensConfiguration#storage_lens_table_destination}
        */
        readonly storageLensTableDestination?: StorageLensConfigurationDataExportStorageLensTableDestinationProperty;
    }
    class DataExportPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DataExportProperty | undefined;
        set internalValue(value: DataExportProperty | undefined);
        private _cloudWatchMetrics;
        get cloudWatchMetrics(): CloudWatchMetricsPropertyOutputReference;
        putCloudWatchMetrics(value: CloudWatchMetricsProperty): void;
        resetCloudWatchMetrics(): void;
        get cloudWatchMetricsInput(): CloudWatchMetricsProperty | undefined;
        private _s3BucketDestination;
        get s3BucketDestination(): StorageLensConfigurationDataExportS3BucketDestinationPropertyOutputReference;
        putS3BucketDestination(value: StorageLensConfigurationDataExportS3BucketDestinationProperty): void;
        resetS3BucketDestination(): void;
        get s3BucketDestinationInput(): StorageLensConfigurationDataExportS3BucketDestinationProperty | undefined;
        private _storageLensTableDestination;
        get storageLensTableDestination(): StorageLensConfigurationDataExportStorageLensTableDestinationPropertyOutputReference;
        putStorageLensTableDestination(value: StorageLensConfigurationDataExportStorageLensTableDestinationProperty): void;
        resetStorageLensTableDestination(): void;
        get storageLensTableDestinationInput(): StorageLensConfigurationDataExportStorageLensTableDestinationProperty | undefined;
    }
    interface ExcludeProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_storage_lens_configuration#buckets TfStorageLensConfiguration#buckets}
        */
        readonly buckets?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_storage_lens_configuration#regions TfStorageLensConfiguration#regions}
        */
        readonly regions?: string[];
    }
    class ExcludePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ExcludeProperty | undefined;
        set internalValue(value: ExcludeProperty | undefined);
        private _buckets?;
        get buckets(): string[];
        set buckets(value: string[]);
        resetBuckets(): void;
        get bucketsInput(): string[] | undefined;
        private _regions?;
        get regions(): string[];
        set regions(value: string[]);
        resetRegions(): void;
        get regionsInput(): string[] | undefined;
    }
    interface StorageLensConfigurationExpandedPrefixesDataExportS3BucketDestinationEncryptionSseKmsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_storage_lens_configuration#key_id TfStorageLensConfiguration#key_id}
        */
        readonly keyId: string;
    }
    class StorageLensConfigurationExpandedPrefixesDataExportS3BucketDestinationEncryptionSseKmsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): StorageLensConfigurationExpandedPrefixesDataExportS3BucketDestinationEncryptionSseKmsProperty | undefined;
        set internalValue(value: StorageLensConfigurationExpandedPrefixesDataExportS3BucketDestinationEncryptionSseKmsProperty | undefined);
        private _keyId?;
        get keyId(): string;
        set keyId(value: string);
        get keyIdInput(): string | undefined;
    }
    interface StorageLensConfigurationExpandedPrefixesDataExportS3BucketDestinationEncryptionSseS3Property {
    }
    class StorageLensConfigurationExpandedPrefixesDataExportS3BucketDestinationEncryptionSseS3PropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): StorageLensConfigurationExpandedPrefixesDataExportS3BucketDestinationEncryptionSseS3Property | cdktn.IResolvable | undefined;
        set internalValue(value: StorageLensConfigurationExpandedPrefixesDataExportS3BucketDestinationEncryptionSseS3Property | cdktn.IResolvable | undefined);
    }
    class StorageLensConfigurationExpandedPrefixesDataExportS3BucketDestinationEncryptionSseS3PropertyList extends cdktn.ComplexList {
        internalValue?: StorageLensConfigurationExpandedPrefixesDataExportS3BucketDestinationEncryptionSseS3Property[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): StorageLensConfigurationExpandedPrefixesDataExportS3BucketDestinationEncryptionSseS3PropertyOutputReference;
    }
    interface StorageLensConfigurationExpandedPrefixesDataExportS3BucketDestinationEncryptionProperty {
        /**
        * sse_kms block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_storage_lens_configuration#sse_kms TfStorageLensConfiguration#sse_kms}
        */
        readonly sseKms?: StorageLensConfigurationExpandedPrefixesDataExportS3BucketDestinationEncryptionSseKmsProperty;
        /**
        * sse_s3 block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_storage_lens_configuration#sse_s3 TfStorageLensConfiguration#sse_s3}
        */
        readonly sseS3?: StorageLensConfigurationExpandedPrefixesDataExportS3BucketDestinationEncryptionSseS3Property[] | cdktn.IResolvable;
    }
    class StorageLensConfigurationExpandedPrefixesDataExportS3BucketDestinationEncryptionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): StorageLensConfigurationExpandedPrefixesDataExportS3BucketDestinationEncryptionProperty | undefined;
        set internalValue(value: StorageLensConfigurationExpandedPrefixesDataExportS3BucketDestinationEncryptionProperty | undefined);
        private _sseKms;
        get sseKms(): StorageLensConfigurationExpandedPrefixesDataExportS3BucketDestinationEncryptionSseKmsPropertyOutputReference;
        putSseKms(value: StorageLensConfigurationExpandedPrefixesDataExportS3BucketDestinationEncryptionSseKmsProperty): void;
        resetSseKms(): void;
        get sseKmsInput(): StorageLensConfigurationExpandedPrefixesDataExportS3BucketDestinationEncryptionSseKmsProperty | undefined;
        private _sseS3;
        get sseS3(): StorageLensConfigurationExpandedPrefixesDataExportS3BucketDestinationEncryptionSseS3PropertyList;
        putSseS3(value: StorageLensConfigurationExpandedPrefixesDataExportS3BucketDestinationEncryptionSseS3Property[] | cdktn.IResolvable): void;
        resetSseS3(): void;
        get sseS3Input(): cdktn.IResolvable | StorageLensConfigurationExpandedPrefixesDataExportS3BucketDestinationEncryptionSseS3Property[] | undefined;
    }
    interface StorageLensConfigurationExpandedPrefixesDataExportS3BucketDestinationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_storage_lens_configuration#account_id TfStorageLensConfiguration#account_id}
        */
        readonly accountId: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_storage_lens_configuration#arn TfStorageLensConfiguration#arn}
        */
        readonly arn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_storage_lens_configuration#format TfStorageLensConfiguration#format}
        */
        readonly format: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_storage_lens_configuration#output_schema_version TfStorageLensConfiguration#output_schema_version}
        */
        readonly outputSchemaVersion: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_storage_lens_configuration#prefix TfStorageLensConfiguration#prefix}
        */
        readonly prefix?: string;
        /**
        * encryption block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_storage_lens_configuration#encryption TfStorageLensConfiguration#encryption}
        */
        readonly encryption?: StorageLensConfigurationExpandedPrefixesDataExportS3BucketDestinationEncryptionProperty;
    }
    class StorageLensConfigurationExpandedPrefixesDataExportS3BucketDestinationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): StorageLensConfigurationExpandedPrefixesDataExportS3BucketDestinationProperty | undefined;
        set internalValue(value: StorageLensConfigurationExpandedPrefixesDataExportS3BucketDestinationProperty | undefined);
        private _accountId?;
        get accountId(): string;
        set accountId(value: string);
        get accountIdInput(): string | undefined;
        private _arn?;
        get arn(): string;
        set arn(value: string);
        get arnInput(): string | undefined;
        private _format?;
        get format(): string;
        set format(value: string);
        get formatInput(): string | undefined;
        private _outputSchemaVersion?;
        get outputSchemaVersion(): string;
        set outputSchemaVersion(value: string);
        get outputSchemaVersionInput(): string | undefined;
        private _prefix?;
        get prefix(): string;
        set prefix(value: string);
        resetPrefix(): void;
        get prefixInput(): string | undefined;
        private _encryption;
        get encryption(): StorageLensConfigurationExpandedPrefixesDataExportS3BucketDestinationEncryptionPropertyOutputReference;
        putEncryption(value: StorageLensConfigurationExpandedPrefixesDataExportS3BucketDestinationEncryptionProperty): void;
        resetEncryption(): void;
        get encryptionInput(): StorageLensConfigurationExpandedPrefixesDataExportS3BucketDestinationEncryptionProperty | undefined;
    }
    interface StorageLensConfigurationExpandedPrefixesDataExportStorageLensTableDestinationEncryptionSseKmsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_storage_lens_configuration#key_id TfStorageLensConfiguration#key_id}
        */
        readonly keyId: string;
    }
    class StorageLensConfigurationExpandedPrefixesDataExportStorageLensTableDestinationEncryptionSseKmsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): StorageLensConfigurationExpandedPrefixesDataExportStorageLensTableDestinationEncryptionSseKmsProperty | undefined;
        set internalValue(value: StorageLensConfigurationExpandedPrefixesDataExportStorageLensTableDestinationEncryptionSseKmsProperty | undefined);
        private _keyId?;
        get keyId(): string;
        set keyId(value: string);
        get keyIdInput(): string | undefined;
    }
    interface StorageLensConfigurationExpandedPrefixesDataExportStorageLensTableDestinationEncryptionSseS3Property {
    }
    class StorageLensConfigurationExpandedPrefixesDataExportStorageLensTableDestinationEncryptionSseS3PropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): StorageLensConfigurationExpandedPrefixesDataExportStorageLensTableDestinationEncryptionSseS3Property | cdktn.IResolvable | undefined;
        set internalValue(value: StorageLensConfigurationExpandedPrefixesDataExportStorageLensTableDestinationEncryptionSseS3Property | cdktn.IResolvable | undefined);
    }
    class StorageLensConfigurationExpandedPrefixesDataExportStorageLensTableDestinationEncryptionSseS3PropertyList extends cdktn.ComplexList {
        internalValue?: StorageLensConfigurationExpandedPrefixesDataExportStorageLensTableDestinationEncryptionSseS3Property[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): StorageLensConfigurationExpandedPrefixesDataExportStorageLensTableDestinationEncryptionSseS3PropertyOutputReference;
    }
    interface StorageLensConfigurationExpandedPrefixesDataExportStorageLensTableDestinationEncryptionProperty {
        /**
        * sse_kms block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_storage_lens_configuration#sse_kms TfStorageLensConfiguration#sse_kms}
        */
        readonly sseKms?: StorageLensConfigurationExpandedPrefixesDataExportStorageLensTableDestinationEncryptionSseKmsProperty;
        /**
        * sse_s3 block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_storage_lens_configuration#sse_s3 TfStorageLensConfiguration#sse_s3}
        */
        readonly sseS3?: StorageLensConfigurationExpandedPrefixesDataExportStorageLensTableDestinationEncryptionSseS3Property[] | cdktn.IResolvable;
    }
    class StorageLensConfigurationExpandedPrefixesDataExportStorageLensTableDestinationEncryptionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): StorageLensConfigurationExpandedPrefixesDataExportStorageLensTableDestinationEncryptionProperty | undefined;
        set internalValue(value: StorageLensConfigurationExpandedPrefixesDataExportStorageLensTableDestinationEncryptionProperty | undefined);
        private _sseKms;
        get sseKms(): StorageLensConfigurationExpandedPrefixesDataExportStorageLensTableDestinationEncryptionSseKmsPropertyOutputReference;
        putSseKms(value: StorageLensConfigurationExpandedPrefixesDataExportStorageLensTableDestinationEncryptionSseKmsProperty): void;
        resetSseKms(): void;
        get sseKmsInput(): StorageLensConfigurationExpandedPrefixesDataExportStorageLensTableDestinationEncryptionSseKmsProperty | undefined;
        private _sseS3;
        get sseS3(): StorageLensConfigurationExpandedPrefixesDataExportStorageLensTableDestinationEncryptionSseS3PropertyList;
        putSseS3(value: StorageLensConfigurationExpandedPrefixesDataExportStorageLensTableDestinationEncryptionSseS3Property[] | cdktn.IResolvable): void;
        resetSseS3(): void;
        get sseS3Input(): cdktn.IResolvable | StorageLensConfigurationExpandedPrefixesDataExportStorageLensTableDestinationEncryptionSseS3Property[] | undefined;
    }
    interface StorageLensConfigurationExpandedPrefixesDataExportStorageLensTableDestinationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_storage_lens_configuration#enabled TfStorageLensConfiguration#enabled}
        */
        readonly enabled: boolean | cdktn.IResolvable;
        /**
        * encryption block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_storage_lens_configuration#encryption TfStorageLensConfiguration#encryption}
        */
        readonly encryption?: StorageLensConfigurationExpandedPrefixesDataExportStorageLensTableDestinationEncryptionProperty;
    }
    class StorageLensConfigurationExpandedPrefixesDataExportStorageLensTableDestinationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): StorageLensConfigurationExpandedPrefixesDataExportStorageLensTableDestinationProperty | undefined;
        set internalValue(value: StorageLensConfigurationExpandedPrefixesDataExportStorageLensTableDestinationProperty | undefined);
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
        private _encryption;
        get encryption(): StorageLensConfigurationExpandedPrefixesDataExportStorageLensTableDestinationEncryptionPropertyOutputReference;
        putEncryption(value: StorageLensConfigurationExpandedPrefixesDataExportStorageLensTableDestinationEncryptionProperty): void;
        resetEncryption(): void;
        get encryptionInput(): StorageLensConfigurationExpandedPrefixesDataExportStorageLensTableDestinationEncryptionProperty | undefined;
    }
    interface ExpandedPrefixesDataExportProperty {
        /**
        * s3_bucket_destination block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_storage_lens_configuration#s3_bucket_destination TfStorageLensConfiguration#s3_bucket_destination}
        */
        readonly s3BucketDestination?: StorageLensConfigurationExpandedPrefixesDataExportS3BucketDestinationProperty;
        /**
        * storage_lens_table_destination block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_storage_lens_configuration#storage_lens_table_destination TfStorageLensConfiguration#storage_lens_table_destination}
        */
        readonly storageLensTableDestination?: StorageLensConfigurationExpandedPrefixesDataExportStorageLensTableDestinationProperty;
    }
    class ExpandedPrefixesDataExportPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ExpandedPrefixesDataExportProperty | undefined;
        set internalValue(value: ExpandedPrefixesDataExportProperty | undefined);
        private _s3BucketDestination;
        get s3BucketDestination(): StorageLensConfigurationExpandedPrefixesDataExportS3BucketDestinationPropertyOutputReference;
        putS3BucketDestination(value: StorageLensConfigurationExpandedPrefixesDataExportS3BucketDestinationProperty): void;
        resetS3BucketDestination(): void;
        get s3BucketDestinationInput(): StorageLensConfigurationExpandedPrefixesDataExportS3BucketDestinationProperty | undefined;
        private _storageLensTableDestination;
        get storageLensTableDestination(): StorageLensConfigurationExpandedPrefixesDataExportStorageLensTableDestinationPropertyOutputReference;
        putStorageLensTableDestination(value: StorageLensConfigurationExpandedPrefixesDataExportStorageLensTableDestinationProperty): void;
        resetStorageLensTableDestination(): void;
        get storageLensTableDestinationInput(): StorageLensConfigurationExpandedPrefixesDataExportStorageLensTableDestinationProperty | undefined;
    }
    interface IncludeProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_storage_lens_configuration#buckets TfStorageLensConfiguration#buckets}
        */
        readonly buckets?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_storage_lens_configuration#regions TfStorageLensConfiguration#regions}
        */
        readonly regions?: string[];
    }
    class IncludePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): IncludeProperty | undefined;
        set internalValue(value: IncludeProperty | undefined);
        private _buckets?;
        get buckets(): string[];
        set buckets(value: string[]);
        resetBuckets(): void;
        get bucketsInput(): string[] | undefined;
        private _regions?;
        get regions(): string[];
        set regions(value: string[]);
        resetRegions(): void;
        get regionsInput(): string[] | undefined;
    }
    interface StorageLensConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_storage_lens_configuration#enabled TfStorageLensConfiguration#enabled}
        */
        readonly enabled: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_storage_lens_configuration#prefix_delimiter TfStorageLensConfiguration#prefix_delimiter}
        */
        readonly prefixDelimiter?: string;
        /**
        * account_level block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_storage_lens_configuration#account_level TfStorageLensConfiguration#account_level}
        */
        readonly accountLevel: AccountLevelProperty;
        /**
        * aws_org block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_storage_lens_configuration#aws_org TfStorageLensConfiguration#aws_org}
        */
        readonly awsOrg?: AwsOrgProperty;
        /**
        * data_export block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_storage_lens_configuration#data_export TfStorageLensConfiguration#data_export}
        */
        readonly dataExport?: DataExportProperty;
        /**
        * exclude block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_storage_lens_configuration#exclude TfStorageLensConfiguration#exclude}
        */
        readonly exclude?: ExcludeProperty;
        /**
        * expanded_prefixes_data_export block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_storage_lens_configuration#expanded_prefixes_data_export TfStorageLensConfiguration#expanded_prefixes_data_export}
        */
        readonly expandedPrefixesDataExport?: ExpandedPrefixesDataExportProperty;
        /**
        * include block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3control_storage_lens_configuration#include TfStorageLensConfiguration#include}
        */
        readonly include?: IncludeProperty;
    }
    class StorageLensConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): StorageLensConfigurationProperty | undefined;
        set internalValue(value: StorageLensConfigurationProperty | undefined);
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
        private _prefixDelimiter?;
        get prefixDelimiter(): string;
        set prefixDelimiter(value: string);
        resetPrefixDelimiter(): void;
        get prefixDelimiterInput(): string | undefined;
        private _accountLevel;
        get accountLevel(): AccountLevelPropertyOutputReference;
        putAccountLevel(value: AccountLevelProperty): void;
        get accountLevelInput(): AccountLevelProperty | undefined;
        private _awsOrg;
        get awsOrg(): AwsOrgPropertyOutputReference;
        putAwsOrg(value: AwsOrgProperty): void;
        resetAwsOrg(): void;
        get awsOrgInput(): AwsOrgProperty | undefined;
        private _dataExport;
        get dataExport(): DataExportPropertyOutputReference;
        putDataExport(value: DataExportProperty): void;
        resetDataExport(): void;
        get dataExportInput(): DataExportProperty | undefined;
        private _exclude;
        get exclude(): ExcludePropertyOutputReference;
        putExclude(value: ExcludeProperty): void;
        resetExclude(): void;
        get excludeInput(): ExcludeProperty | undefined;
        private _expandedPrefixesDataExport;
        get expandedPrefixesDataExport(): ExpandedPrefixesDataExportPropertyOutputReference;
        putExpandedPrefixesDataExport(value: ExpandedPrefixesDataExportProperty): void;
        resetExpandedPrefixesDataExport(): void;
        get expandedPrefixesDataExportInput(): ExpandedPrefixesDataExportProperty | undefined;
        private _include;
        get include(): IncludePropertyOutputReference;
        putInclude(value: IncludeProperty): void;
        resetInclude(): void;
        get includeInput(): IncludeProperty | undefined;
    }
}
