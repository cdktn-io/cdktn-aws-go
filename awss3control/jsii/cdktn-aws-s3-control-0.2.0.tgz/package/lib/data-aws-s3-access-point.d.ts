import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataTfAccessPointConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/s3_access_point#account_id DataTfAccessPoint#account_id}
    */
    readonly accountId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/s3_access_point#name DataTfAccessPoint#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/s3_access_point#region DataTfAccessPoint#region}
    */
    readonly region?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/s3_access_point aws_s3_access_point}
*/
export declare class DataTfAccessPoint extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_s3_access_point";
    /**
    * Generates CDKTN code for importing a DataTfAccessPoint resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataTfAccessPoint to import
    * @param importFromId The id of the existing DataTfAccessPoint that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/s3_access_point#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataTfAccessPoint to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/s3_access_point aws_s3_access_point} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataTfAccessPointConfig
    */
    constructor(scope: Construct, id: string, config: DataTfAccessPointConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    resetAccountId(): void;
    get accountIdInput(): string | undefined;
    get alias(): string;
    get arn(): string;
    get bucket(): string;
    get bucketAccountId(): string;
    get dataSourceId(): string;
    get dataSourceType(): string;
    private _endpoints;
    get endpoints(): cdktn.StringMap;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get networkOrigin(): string;
    private _publicAccessBlockConfiguration;
    get publicAccessBlockConfiguration(): DataTfAccessPoint.PublicAccessBlockConfigurationPropertyList;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags;
    get tags(): cdktn.StringMap;
    private _vpcConfiguration;
    get vpcConfiguration(): DataTfAccessPoint.VpcConfigurationPropertyList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataTfAccessPointPublicAccessBlockConfigurationPropertyToTerraform(struct?: DataTfAccessPoint.PublicAccessBlockConfigurationProperty): any;
export declare function dataTfAccessPointPublicAccessBlockConfigurationPropertyToHclTerraform(struct?: DataTfAccessPoint.PublicAccessBlockConfigurationProperty): any;
export declare function dataTfAccessPointVpcConfigurationPropertyToTerraform(struct?: DataTfAccessPoint.VpcConfigurationProperty): any;
export declare function dataTfAccessPointVpcConfigurationPropertyToHclTerraform(struct?: DataTfAccessPoint.VpcConfigurationProperty): any;
export declare namespace DataTfAccessPoint {
    interface PublicAccessBlockConfigurationProperty {
    }
    class PublicAccessBlockConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): PublicAccessBlockConfigurationProperty | undefined;
        set internalValue(value: PublicAccessBlockConfigurationProperty | undefined);
        get blockPublicAcls(): cdktn.IResolvable;
        get blockPublicPolicy(): cdktn.IResolvable;
        get ignorePublicAcls(): cdktn.IResolvable;
        get restrictPublicBuckets(): cdktn.IResolvable;
    }
    class PublicAccessBlockConfigurationPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): PublicAccessBlockConfigurationPropertyOutputReference;
    }
    interface VpcConfigurationProperty {
    }
    class VpcConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): VpcConfigurationProperty | undefined;
        set internalValue(value: VpcConfigurationProperty | undefined);
        get vpcId(): string;
    }
    class VpcConfigurationPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): VpcConfigurationPropertyOutputReference;
    }
}
