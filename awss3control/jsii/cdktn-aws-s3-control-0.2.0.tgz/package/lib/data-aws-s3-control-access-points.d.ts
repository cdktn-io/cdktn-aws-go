import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataTfAccessPointsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/s3control_access_points#account_id DataTfAccessPoints#account_id}
    */
    readonly accountId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/s3control_access_points#bucket DataTfAccessPoints#bucket}
    */
    readonly bucket?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/s3control_access_points#data_source_id DataTfAccessPoints#data_source_id}
    */
    readonly dataSourceId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/s3control_access_points#data_source_type DataTfAccessPoints#data_source_type}
    */
    readonly dataSourceType?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/s3control_access_points#region DataTfAccessPoints#region}
    */
    readonly region?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/s3control_access_points aws_s3control_access_points}
*/
export declare class DataTfAccessPoints extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_s3control_access_points";
    /**
    * Generates CDKTN code for importing a DataTfAccessPoints resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataTfAccessPoints to import
    * @param importFromId The id of the existing DataTfAccessPoints that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/s3control_access_points#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataTfAccessPoints to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/s3control_access_points aws_s3control_access_points} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataTfAccessPointsConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataTfAccessPointsConfig);
    private _accessPoints;
    get accessPoints(): DataTfAccessPoints.AccessPointsPropertyList;
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    resetAccountId(): void;
    get accountIdInput(): string | undefined;
    private _bucket?;
    get bucket(): string;
    set bucket(value: string);
    resetBucket(): void;
    get bucketInput(): string | undefined;
    private _dataSourceId?;
    get dataSourceId(): string;
    set dataSourceId(value: string);
    resetDataSourceId(): void;
    get dataSourceIdInput(): string | undefined;
    private _dataSourceType?;
    get dataSourceType(): string;
    set dataSourceType(value: string);
    resetDataSourceType(): void;
    get dataSourceTypeInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataTfAccessPointsVpcConfigurationPropertyToTerraform(struct?: DataTfAccessPoints.VpcConfigurationProperty): any;
export declare function dataTfAccessPointsVpcConfigurationPropertyToHclTerraform(struct?: DataTfAccessPoints.VpcConfigurationProperty): any;
export declare function dataTfAccessPointsAccessPointsPropertyToTerraform(struct?: DataTfAccessPoints.AccessPointsProperty): any;
export declare function dataTfAccessPointsAccessPointsPropertyToHclTerraform(struct?: DataTfAccessPoints.AccessPointsProperty): any;
export declare namespace DataTfAccessPoints {
    interface VpcConfigurationProperty {
    }
    class VpcConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): VpcConfigurationProperty | undefined;
        set internalValue(value: VpcConfigurationProperty | undefined);
        get vpcId(): string;
    }
    class VpcConfigurationPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): VpcConfigurationPropertyOutputReference;
    }
    interface AccessPointsProperty {
    }
    class AccessPointsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AccessPointsProperty | undefined;
        set internalValue(value: AccessPointsProperty | undefined);
        get accessPointArn(): string;
        get alias(): string;
        get bucket(): string;
        get bucketAccountId(): string;
        get dataSourceId(): string;
        get dataSourceType(): string;
        get name(): string;
        get networkOrigin(): string;
        private _vpcConfiguration;
        get vpcConfiguration(): VpcConfigurationPropertyList;
    }
    class AccessPointsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AccessPointsPropertyOutputReference;
    }
}
