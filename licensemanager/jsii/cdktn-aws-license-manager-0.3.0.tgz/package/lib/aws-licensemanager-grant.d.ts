import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsGrantConfig extends cdktn.TerraformMetaArguments {
    /**
    * Allowed operations for the grant. This is a subset of the allowed operations on the license.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/licensemanager_grant#allowed_operations AwsGrant#allowed_operations}
    */
    readonly allowedOperations: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/licensemanager_grant#id AwsGrant#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * License ARN.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/licensemanager_grant#license_arn AwsGrant#license_arn}
    */
    readonly licenseArn: string;
    /**
    * Name of the grant.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/licensemanager_grant#name AwsGrant#name}
    */
    readonly name: string;
    /**
    * The grantee principal ARN. The target account for the grant in the form of the ARN for an account principal of the root user.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/licensemanager_grant#principal AwsGrant#principal}
    */
    readonly principal: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/licensemanager_grant#region AwsGrant#region}
    */
    readonly region?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/licensemanager_grant aws_licensemanager_grant}
*/
export declare class AwsGrant extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_licensemanager_grant";
    /**
    * Generates CDKTN code for importing a AwsGrant resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsGrant to import
    * @param importFromId The id of the existing AwsGrant that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/licensemanager_grant#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsGrant to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/licensemanager_grant aws_licensemanager_grant} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsGrantConfig
    */
    constructor(scope: Construct, id: string, config: AwsGrantConfig);
    private _allowedOperations?;
    get allowedOperations(): string[];
    set allowedOperations(value: string[]);
    get allowedOperationsInput(): string[] | undefined;
    get arn(): string;
    get homeRegion(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _licenseArn?;
    get licenseArn(): string;
    set licenseArn(value: string);
    get licenseArnInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get parentArn(): string;
    private _principal?;
    get principal(): string;
    set principal(value: string);
    get principalInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get status(): string;
    get version(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
