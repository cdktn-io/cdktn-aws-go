import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfScalingPlanConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscalingplans_scaling_plan#id TfScalingPlan#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscalingplans_scaling_plan#name TfScalingPlan#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscalingplans_scaling_plan#region TfScalingPlan#region}
    */
    readonly region?: string;
    /**
    * application_source block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscalingplans_scaling_plan#application_source TfScalingPlan#application_source}
    */
    readonly applicationSource: TfScalingPlan.ApplicationSourceProperty;
    /**
    * scaling_instruction block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscalingplans_scaling_plan#scaling_instruction TfScalingPlan#scaling_instruction}
    */
    readonly scalingInstruction: TfScalingPlan.ScalingInstructionProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscalingplans_scaling_plan aws_autoscalingplans_scaling_plan}
*/
export declare class TfScalingPlan extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_autoscalingplans_scaling_plan";
    /**
    * Generates CDKTN code for importing a TfScalingPlan resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfScalingPlan to import
    * @param importFromId The id of the existing TfScalingPlan that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscalingplans_scaling_plan#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfScalingPlan to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscalingplans_scaling_plan aws_autoscalingplans_scaling_plan} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfScalingPlanConfig
    */
    constructor(scope: Construct, id: string, config: TfScalingPlanConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get scalingPlanVersion(): number;
    private _applicationSource;
    get applicationSource(): TfScalingPlan.ApplicationSourcePropertyOutputReference;
    putApplicationSource(value: TfScalingPlan.ApplicationSourceProperty): void;
    get applicationSourceInput(): TfScalingPlan.ApplicationSourceProperty | undefined;
    private _scalingInstruction;
    get scalingInstruction(): TfScalingPlan.ScalingInstructionPropertyList;
    putScalingInstruction(value: TfScalingPlan.ScalingInstructionProperty[] | cdktn.IResolvable): void;
    get scalingInstructionInput(): cdktn.IResolvable | TfScalingPlan.ScalingInstructionProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfScalingPlanTagFilterPropertyToTerraform(struct?: TfScalingPlan.TagFilterProperty | cdktn.IResolvable): any;
export declare function tfScalingPlanTagFilterPropertyToHclTerraform(struct?: TfScalingPlan.TagFilterProperty | cdktn.IResolvable): any;
export declare function tfScalingPlanApplicationSourcePropertyToTerraform(struct?: TfScalingPlan.ApplicationSourcePropertyOutputReference | TfScalingPlan.ApplicationSourceProperty): any;
export declare function tfScalingPlanApplicationSourcePropertyToHclTerraform(struct?: TfScalingPlan.ApplicationSourcePropertyOutputReference | TfScalingPlan.ApplicationSourceProperty): any;
export declare function tfScalingPlanCustomizedLoadMetricSpecificationPropertyToTerraform(struct?: TfScalingPlan.CustomizedLoadMetricSpecificationPropertyOutputReference | TfScalingPlan.CustomizedLoadMetricSpecificationProperty): any;
export declare function tfScalingPlanCustomizedLoadMetricSpecificationPropertyToHclTerraform(struct?: TfScalingPlan.CustomizedLoadMetricSpecificationPropertyOutputReference | TfScalingPlan.CustomizedLoadMetricSpecificationProperty): any;
export declare function tfScalingPlanPredefinedLoadMetricSpecificationPropertyToTerraform(struct?: TfScalingPlan.PredefinedLoadMetricSpecificationPropertyOutputReference | TfScalingPlan.PredefinedLoadMetricSpecificationProperty): any;
export declare function tfScalingPlanPredefinedLoadMetricSpecificationPropertyToHclTerraform(struct?: TfScalingPlan.PredefinedLoadMetricSpecificationPropertyOutputReference | TfScalingPlan.PredefinedLoadMetricSpecificationProperty): any;
export declare function tfScalingPlanCustomizedScalingMetricSpecificationPropertyToTerraform(struct?: TfScalingPlan.CustomizedScalingMetricSpecificationPropertyOutputReference | TfScalingPlan.CustomizedScalingMetricSpecificationProperty): any;
export declare function tfScalingPlanCustomizedScalingMetricSpecificationPropertyToHclTerraform(struct?: TfScalingPlan.CustomizedScalingMetricSpecificationPropertyOutputReference | TfScalingPlan.CustomizedScalingMetricSpecificationProperty): any;
export declare function tfScalingPlanPredefinedScalingMetricSpecificationPropertyToTerraform(struct?: TfScalingPlan.PredefinedScalingMetricSpecificationPropertyOutputReference | TfScalingPlan.PredefinedScalingMetricSpecificationProperty): any;
export declare function tfScalingPlanPredefinedScalingMetricSpecificationPropertyToHclTerraform(struct?: TfScalingPlan.PredefinedScalingMetricSpecificationPropertyOutputReference | TfScalingPlan.PredefinedScalingMetricSpecificationProperty): any;
export declare function tfScalingPlanTargetTrackingConfigurationPropertyToTerraform(struct?: TfScalingPlan.TargetTrackingConfigurationProperty | cdktn.IResolvable): any;
export declare function tfScalingPlanTargetTrackingConfigurationPropertyToHclTerraform(struct?: TfScalingPlan.TargetTrackingConfigurationProperty | cdktn.IResolvable): any;
export declare function tfScalingPlanScalingInstructionPropertyToTerraform(struct?: TfScalingPlan.ScalingInstructionProperty | cdktn.IResolvable): any;
export declare function tfScalingPlanScalingInstructionPropertyToHclTerraform(struct?: TfScalingPlan.ScalingInstructionProperty | cdktn.IResolvable): any;
export declare namespace TfScalingPlan {
    interface TagFilterProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscalingplans_scaling_plan#key TfScalingPlan#key}
        */
        readonly key: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscalingplans_scaling_plan#values TfScalingPlan#values}
        */
        readonly values?: string[];
    }
    class TagFilterPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TagFilterProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TagFilterProperty | cdktn.IResolvable | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        get keyInput(): string | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        resetValues(): void;
        get valuesInput(): string[] | undefined;
    }
    class TagFilterPropertyList extends cdktn.ComplexList {
        internalValue?: TagFilterProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TagFilterPropertyOutputReference;
    }
    interface ApplicationSourceProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscalingplans_scaling_plan#cloudformation_stack_arn TfScalingPlan#cloudformation_stack_arn}
        */
        readonly cloudformationStackArn?: string;
        /**
        * tag_filter block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscalingplans_scaling_plan#tag_filter TfScalingPlan#tag_filter}
        */
        readonly tagFilter?: TagFilterProperty[] | cdktn.IResolvable;
    }
    class ApplicationSourcePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ApplicationSourceProperty | undefined;
        set internalValue(value: ApplicationSourceProperty | undefined);
        private _cloudformationStackArn?;
        get cloudformationStackArn(): string;
        set cloudformationStackArn(value: string);
        resetCloudformationStackArn(): void;
        get cloudformationStackArnInput(): string | undefined;
        private _tagFilter;
        get tagFilter(): TagFilterPropertyList;
        putTagFilter(value: TagFilterProperty[] | cdktn.IResolvable): void;
        resetTagFilter(): void;
        get tagFilterInput(): cdktn.IResolvable | TagFilterProperty[] | undefined;
    }
    interface CustomizedLoadMetricSpecificationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscalingplans_scaling_plan#dimensions TfScalingPlan#dimensions}
        */
        readonly dimensions?: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscalingplans_scaling_plan#metric_name TfScalingPlan#metric_name}
        */
        readonly metricName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscalingplans_scaling_plan#namespace TfScalingPlan#namespace}
        */
        readonly namespace: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscalingplans_scaling_plan#statistic TfScalingPlan#statistic}
        */
        readonly statistic: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscalingplans_scaling_plan#unit TfScalingPlan#unit}
        */
        readonly unit?: string;
    }
    class CustomizedLoadMetricSpecificationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CustomizedLoadMetricSpecificationProperty | undefined;
        set internalValue(value: CustomizedLoadMetricSpecificationProperty | undefined);
        private _dimensions?;
        get dimensions(): {
            [key: string]: string;
        };
        set dimensions(value: {
            [key: string]: string;
        });
        resetDimensions(): void;
        get dimensionsInput(): {
            [key: string]: string;
        } | undefined;
        private _metricName?;
        get metricName(): string;
        set metricName(value: string);
        get metricNameInput(): string | undefined;
        private _namespace?;
        get namespace(): string;
        set namespace(value: string);
        get namespaceInput(): string | undefined;
        private _statistic?;
        get statistic(): string;
        set statistic(value: string);
        get statisticInput(): string | undefined;
        private _unit?;
        get unit(): string;
        set unit(value: string);
        resetUnit(): void;
        get unitInput(): string | undefined;
    }
    interface PredefinedLoadMetricSpecificationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscalingplans_scaling_plan#predefined_load_metric_type TfScalingPlan#predefined_load_metric_type}
        */
        readonly predefinedLoadMetricType: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscalingplans_scaling_plan#resource_label TfScalingPlan#resource_label}
        */
        readonly resourceLabel?: string;
    }
    class PredefinedLoadMetricSpecificationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): PredefinedLoadMetricSpecificationProperty | undefined;
        set internalValue(value: PredefinedLoadMetricSpecificationProperty | undefined);
        private _predefinedLoadMetricType?;
        get predefinedLoadMetricType(): string;
        set predefinedLoadMetricType(value: string);
        get predefinedLoadMetricTypeInput(): string | undefined;
        private _resourceLabel?;
        get resourceLabel(): string;
        set resourceLabel(value: string);
        resetResourceLabel(): void;
        get resourceLabelInput(): string | undefined;
    }
    interface CustomizedScalingMetricSpecificationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscalingplans_scaling_plan#dimensions TfScalingPlan#dimensions}
        */
        readonly dimensions?: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscalingplans_scaling_plan#metric_name TfScalingPlan#metric_name}
        */
        readonly metricName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscalingplans_scaling_plan#namespace TfScalingPlan#namespace}
        */
        readonly namespace: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscalingplans_scaling_plan#statistic TfScalingPlan#statistic}
        */
        readonly statistic: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscalingplans_scaling_plan#unit TfScalingPlan#unit}
        */
        readonly unit?: string;
    }
    class CustomizedScalingMetricSpecificationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CustomizedScalingMetricSpecificationProperty | undefined;
        set internalValue(value: CustomizedScalingMetricSpecificationProperty | undefined);
        private _dimensions?;
        get dimensions(): {
            [key: string]: string;
        };
        set dimensions(value: {
            [key: string]: string;
        });
        resetDimensions(): void;
        get dimensionsInput(): {
            [key: string]: string;
        } | undefined;
        private _metricName?;
        get metricName(): string;
        set metricName(value: string);
        get metricNameInput(): string | undefined;
        private _namespace?;
        get namespace(): string;
        set namespace(value: string);
        get namespaceInput(): string | undefined;
        private _statistic?;
        get statistic(): string;
        set statistic(value: string);
        get statisticInput(): string | undefined;
        private _unit?;
        get unit(): string;
        set unit(value: string);
        resetUnit(): void;
        get unitInput(): string | undefined;
    }
    interface PredefinedScalingMetricSpecificationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscalingplans_scaling_plan#predefined_scaling_metric_type TfScalingPlan#predefined_scaling_metric_type}
        */
        readonly predefinedScalingMetricType: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscalingplans_scaling_plan#resource_label TfScalingPlan#resource_label}
        */
        readonly resourceLabel?: string;
    }
    class PredefinedScalingMetricSpecificationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): PredefinedScalingMetricSpecificationProperty | undefined;
        set internalValue(value: PredefinedScalingMetricSpecificationProperty | undefined);
        private _predefinedScalingMetricType?;
        get predefinedScalingMetricType(): string;
        set predefinedScalingMetricType(value: string);
        get predefinedScalingMetricTypeInput(): string | undefined;
        private _resourceLabel?;
        get resourceLabel(): string;
        set resourceLabel(value: string);
        resetResourceLabel(): void;
        get resourceLabelInput(): string | undefined;
    }
    interface TargetTrackingConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscalingplans_scaling_plan#disable_scale_in TfScalingPlan#disable_scale_in}
        */
        readonly disableScaleIn?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscalingplans_scaling_plan#estimated_instance_warmup TfScalingPlan#estimated_instance_warmup}
        */
        readonly estimatedInstanceWarmup?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscalingplans_scaling_plan#scale_in_cooldown TfScalingPlan#scale_in_cooldown}
        */
        readonly scaleInCooldown?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscalingplans_scaling_plan#scale_out_cooldown TfScalingPlan#scale_out_cooldown}
        */
        readonly scaleOutCooldown?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscalingplans_scaling_plan#target_value TfScalingPlan#target_value}
        */
        readonly targetValue: number;
        /**
        * customized_scaling_metric_specification block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscalingplans_scaling_plan#customized_scaling_metric_specification TfScalingPlan#customized_scaling_metric_specification}
        */
        readonly customizedScalingMetricSpecification?: CustomizedScalingMetricSpecificationProperty;
        /**
        * predefined_scaling_metric_specification block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscalingplans_scaling_plan#predefined_scaling_metric_specification TfScalingPlan#predefined_scaling_metric_specification}
        */
        readonly predefinedScalingMetricSpecification?: PredefinedScalingMetricSpecificationProperty;
    }
    class TargetTrackingConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TargetTrackingConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TargetTrackingConfigurationProperty | cdktn.IResolvable | undefined);
        private _disableScaleIn?;
        get disableScaleIn(): boolean | cdktn.IResolvable;
        set disableScaleIn(value: boolean | cdktn.IResolvable);
        resetDisableScaleIn(): void;
        get disableScaleInInput(): boolean | cdktn.IResolvable | undefined;
        private _estimatedInstanceWarmup?;
        get estimatedInstanceWarmup(): number;
        set estimatedInstanceWarmup(value: number);
        resetEstimatedInstanceWarmup(): void;
        get estimatedInstanceWarmupInput(): number | undefined;
        private _scaleInCooldown?;
        get scaleInCooldown(): number;
        set scaleInCooldown(value: number);
        resetScaleInCooldown(): void;
        get scaleInCooldownInput(): number | undefined;
        private _scaleOutCooldown?;
        get scaleOutCooldown(): number;
        set scaleOutCooldown(value: number);
        resetScaleOutCooldown(): void;
        get scaleOutCooldownInput(): number | undefined;
        private _targetValue?;
        get targetValue(): number;
        set targetValue(value: number);
        get targetValueInput(): number | undefined;
        private _customizedScalingMetricSpecification;
        get customizedScalingMetricSpecification(): CustomizedScalingMetricSpecificationPropertyOutputReference;
        putCustomizedScalingMetricSpecification(value: CustomizedScalingMetricSpecificationProperty): void;
        resetCustomizedScalingMetricSpecification(): void;
        get customizedScalingMetricSpecificationInput(): CustomizedScalingMetricSpecificationProperty | undefined;
        private _predefinedScalingMetricSpecification;
        get predefinedScalingMetricSpecification(): PredefinedScalingMetricSpecificationPropertyOutputReference;
        putPredefinedScalingMetricSpecification(value: PredefinedScalingMetricSpecificationProperty): void;
        resetPredefinedScalingMetricSpecification(): void;
        get predefinedScalingMetricSpecificationInput(): PredefinedScalingMetricSpecificationProperty | undefined;
    }
    class TargetTrackingConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: TargetTrackingConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TargetTrackingConfigurationPropertyOutputReference;
    }
    interface ScalingInstructionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscalingplans_scaling_plan#disable_dynamic_scaling TfScalingPlan#disable_dynamic_scaling}
        */
        readonly disableDynamicScaling?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscalingplans_scaling_plan#max_capacity TfScalingPlan#max_capacity}
        */
        readonly maxCapacity: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscalingplans_scaling_plan#min_capacity TfScalingPlan#min_capacity}
        */
        readonly minCapacity: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscalingplans_scaling_plan#predictive_scaling_max_capacity_behavior TfScalingPlan#predictive_scaling_max_capacity_behavior}
        */
        readonly predictiveScalingMaxCapacityBehavior?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscalingplans_scaling_plan#predictive_scaling_max_capacity_buffer TfScalingPlan#predictive_scaling_max_capacity_buffer}
        */
        readonly predictiveScalingMaxCapacityBuffer?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscalingplans_scaling_plan#predictive_scaling_mode TfScalingPlan#predictive_scaling_mode}
        */
        readonly predictiveScalingMode?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscalingplans_scaling_plan#resource_id TfScalingPlan#resource_id}
        */
        readonly resourceId: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscalingplans_scaling_plan#scalable_dimension TfScalingPlan#scalable_dimension}
        */
        readonly scalableDimension: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscalingplans_scaling_plan#scaling_policy_update_behavior TfScalingPlan#scaling_policy_update_behavior}
        */
        readonly scalingPolicyUpdateBehavior?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscalingplans_scaling_plan#scheduled_action_buffer_time TfScalingPlan#scheduled_action_buffer_time}
        */
        readonly scheduledActionBufferTime?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscalingplans_scaling_plan#service_namespace TfScalingPlan#service_namespace}
        */
        readonly serviceNamespace: string;
        /**
        * customized_load_metric_specification block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscalingplans_scaling_plan#customized_load_metric_specification TfScalingPlan#customized_load_metric_specification}
        */
        readonly customizedLoadMetricSpecification?: CustomizedLoadMetricSpecificationProperty;
        /**
        * predefined_load_metric_specification block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscalingplans_scaling_plan#predefined_load_metric_specification TfScalingPlan#predefined_load_metric_specification}
        */
        readonly predefinedLoadMetricSpecification?: PredefinedLoadMetricSpecificationProperty;
        /**
        * target_tracking_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscalingplans_scaling_plan#target_tracking_configuration TfScalingPlan#target_tracking_configuration}
        */
        readonly targetTrackingConfiguration: TargetTrackingConfigurationProperty[] | cdktn.IResolvable;
    }
    class ScalingInstructionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ScalingInstructionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ScalingInstructionProperty | cdktn.IResolvable | undefined);
        private _disableDynamicScaling?;
        get disableDynamicScaling(): boolean | cdktn.IResolvable;
        set disableDynamicScaling(value: boolean | cdktn.IResolvable);
        resetDisableDynamicScaling(): void;
        get disableDynamicScalingInput(): boolean | cdktn.IResolvable | undefined;
        private _maxCapacity?;
        get maxCapacity(): number;
        set maxCapacity(value: number);
        get maxCapacityInput(): number | undefined;
        private _minCapacity?;
        get minCapacity(): number;
        set minCapacity(value: number);
        get minCapacityInput(): number | undefined;
        private _predictiveScalingMaxCapacityBehavior?;
        get predictiveScalingMaxCapacityBehavior(): string;
        set predictiveScalingMaxCapacityBehavior(value: string);
        resetPredictiveScalingMaxCapacityBehavior(): void;
        get predictiveScalingMaxCapacityBehaviorInput(): string | undefined;
        private _predictiveScalingMaxCapacityBuffer?;
        get predictiveScalingMaxCapacityBuffer(): number;
        set predictiveScalingMaxCapacityBuffer(value: number);
        resetPredictiveScalingMaxCapacityBuffer(): void;
        get predictiveScalingMaxCapacityBufferInput(): number | undefined;
        private _predictiveScalingMode?;
        get predictiveScalingMode(): string;
        set predictiveScalingMode(value: string);
        resetPredictiveScalingMode(): void;
        get predictiveScalingModeInput(): string | undefined;
        private _resourceId?;
        get resourceId(): string;
        set resourceId(value: string);
        get resourceIdInput(): string | undefined;
        private _scalableDimension?;
        get scalableDimension(): string;
        set scalableDimension(value: string);
        get scalableDimensionInput(): string | undefined;
        private _scalingPolicyUpdateBehavior?;
        get scalingPolicyUpdateBehavior(): string;
        set scalingPolicyUpdateBehavior(value: string);
        resetScalingPolicyUpdateBehavior(): void;
        get scalingPolicyUpdateBehaviorInput(): string | undefined;
        private _scheduledActionBufferTime?;
        get scheduledActionBufferTime(): number;
        set scheduledActionBufferTime(value: number);
        resetScheduledActionBufferTime(): void;
        get scheduledActionBufferTimeInput(): number | undefined;
        private _serviceNamespace?;
        get serviceNamespace(): string;
        set serviceNamespace(value: string);
        get serviceNamespaceInput(): string | undefined;
        private _customizedLoadMetricSpecification;
        get customizedLoadMetricSpecification(): CustomizedLoadMetricSpecificationPropertyOutputReference;
        putCustomizedLoadMetricSpecification(value: CustomizedLoadMetricSpecificationProperty): void;
        resetCustomizedLoadMetricSpecification(): void;
        get customizedLoadMetricSpecificationInput(): CustomizedLoadMetricSpecificationProperty | undefined;
        private _predefinedLoadMetricSpecification;
        get predefinedLoadMetricSpecification(): PredefinedLoadMetricSpecificationPropertyOutputReference;
        putPredefinedLoadMetricSpecification(value: PredefinedLoadMetricSpecificationProperty): void;
        resetPredefinedLoadMetricSpecification(): void;
        get predefinedLoadMetricSpecificationInput(): PredefinedLoadMetricSpecificationProperty | undefined;
        private _targetTrackingConfiguration;
        get targetTrackingConfiguration(): TargetTrackingConfigurationPropertyList;
        putTargetTrackingConfiguration(value: TargetTrackingConfigurationProperty[] | cdktn.IResolvable): void;
        get targetTrackingConfigurationInput(): cdktn.IResolvable | TargetTrackingConfigurationProperty[] | undefined;
    }
    class ScalingInstructionPropertyList extends cdktn.ComplexList {
        internalValue?: ScalingInstructionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ScalingInstructionPropertyOutputReference;
    }
}
