import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfRestoreTestingPlanConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/backup_restore_testing_plan#name TfRestoreTestingPlan#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/backup_restore_testing_plan#region TfRestoreTestingPlan#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/backup_restore_testing_plan#schedule_expression TfRestoreTestingPlan#schedule_expression}
    */
    readonly scheduleExpression: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/backup_restore_testing_plan#schedule_expression_timezone TfRestoreTestingPlan#schedule_expression_timezone}
    */
    readonly scheduleExpressionTimezone?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/backup_restore_testing_plan#start_window_hours TfRestoreTestingPlan#start_window_hours}
    */
    readonly startWindowHours?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/backup_restore_testing_plan#tags TfRestoreTestingPlan#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * recovery_point_selection block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/backup_restore_testing_plan#recovery_point_selection TfRestoreTestingPlan#recovery_point_selection}
    */
    readonly recoveryPointSelection?: TfRestoreTestingPlan.RecoveryPointSelectionProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/backup_restore_testing_plan aws_backup_restore_testing_plan}
*/
export declare class TfRestoreTestingPlan extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_backup_restore_testing_plan";
    /**
    * Generates CDKTN code for importing a TfRestoreTestingPlan resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfRestoreTestingPlan to import
    * @param importFromId The id of the existing TfRestoreTestingPlan that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/backup_restore_testing_plan#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfRestoreTestingPlan to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/backup_restore_testing_plan aws_backup_restore_testing_plan} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfRestoreTestingPlanConfig
    */
    constructor(scope: Construct, id: string, config: TfRestoreTestingPlanConfig);
    get arn(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _scheduleExpression?;
    get scheduleExpression(): string;
    set scheduleExpression(value: string);
    get scheduleExpressionInput(): string | undefined;
    private _scheduleExpressionTimezone?;
    get scheduleExpressionTimezone(): string;
    set scheduleExpressionTimezone(value: string);
    resetScheduleExpressionTimezone(): void;
    get scheduleExpressionTimezoneInput(): string | undefined;
    private _startWindowHours?;
    get startWindowHours(): number;
    set startWindowHours(value: number);
    resetStartWindowHours(): void;
    get startWindowHoursInput(): number | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    private _recoveryPointSelection;
    get recoveryPointSelection(): TfRestoreTestingPlan.RecoveryPointSelectionPropertyList;
    putRecoveryPointSelection(value: TfRestoreTestingPlan.RecoveryPointSelectionProperty[] | cdktn.IResolvable): void;
    resetRecoveryPointSelection(): void;
    get recoveryPointSelectionInput(): cdktn.IResolvable | TfRestoreTestingPlan.RecoveryPointSelectionProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfRestoreTestingPlanRecoveryPointSelectionPropertyToTerraform(struct?: TfRestoreTestingPlan.RecoveryPointSelectionProperty | cdktn.IResolvable): any;
export declare function tfRestoreTestingPlanRecoveryPointSelectionPropertyToHclTerraform(struct?: TfRestoreTestingPlan.RecoveryPointSelectionProperty | cdktn.IResolvable): any;
export declare namespace TfRestoreTestingPlan {
    interface RecoveryPointSelectionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/backup_restore_testing_plan#algorithm TfRestoreTestingPlan#algorithm}
        */
        readonly algorithm: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/backup_restore_testing_plan#exclude_vaults TfRestoreTestingPlan#exclude_vaults}
        */
        readonly excludeVaults?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/backup_restore_testing_plan#include_vaults TfRestoreTestingPlan#include_vaults}
        */
        readonly includeVaults: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/backup_restore_testing_plan#recovery_point_types TfRestoreTestingPlan#recovery_point_types}
        */
        readonly recoveryPointTypes: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/backup_restore_testing_plan#selection_window_days TfRestoreTestingPlan#selection_window_days}
        */
        readonly selectionWindowDays?: number;
    }
    class RecoveryPointSelectionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RecoveryPointSelectionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RecoveryPointSelectionProperty | cdktn.IResolvable | undefined);
        private _algorithm?;
        get algorithm(): string;
        set algorithm(value: string);
        get algorithmInput(): string | undefined;
        private _excludeVaults?;
        get excludeVaults(): string[];
        set excludeVaults(value: string[]);
        resetExcludeVaults(): void;
        get excludeVaultsInput(): string[] | undefined;
        private _includeVaults?;
        get includeVaults(): string[];
        set includeVaults(value: string[]);
        get includeVaultsInput(): string[] | undefined;
        private _recoveryPointTypes?;
        get recoveryPointTypes(): string[];
        set recoveryPointTypes(value: string[]);
        get recoveryPointTypesInput(): string[] | undefined;
        private _selectionWindowDays?;
        get selectionWindowDays(): number;
        set selectionWindowDays(value: number);
        resetSelectionWindowDays(): void;
        get selectionWindowDaysInput(): number | undefined;
    }
    class RecoveryPointSelectionPropertyList extends cdktn.ComplexList {
        internalValue?: RecoveryPointSelectionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RecoveryPointSelectionPropertyOutputReference;
    }
}
