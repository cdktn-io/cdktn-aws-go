import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfRegionSettingsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/backup_region_settings#id TfRegionSettings#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/backup_region_settings#region TfRegionSettings#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/backup_region_settings#resource_type_management_preference TfRegionSettings#resource_type_management_preference}
    */
    readonly resourceTypeManagementPreference?: {
        [key: string]: (boolean | cdktn.IResolvable);
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/backup_region_settings#resource_type_opt_in_preference TfRegionSettings#resource_type_opt_in_preference}
    */
    readonly resourceTypeOptInPreference: {
        [key: string]: (boolean | cdktn.IResolvable);
    };
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/backup_region_settings aws_backup_region_settings}
*/
export declare class TfRegionSettings extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_backup_region_settings";
    /**
    * Generates CDKTN code for importing a TfRegionSettings resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfRegionSettings to import
    * @param importFromId The id of the existing TfRegionSettings that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/backup_region_settings#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfRegionSettings to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/backup_region_settings aws_backup_region_settings} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfRegionSettingsConfig
    */
    constructor(scope: Construct, id: string, config: TfRegionSettingsConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _resourceTypeManagementPreference?;
    get resourceTypeManagementPreference(): {
        [key: string]: (boolean | cdktn.IResolvable);
    };
    set resourceTypeManagementPreference(value: {
        [key: string]: (boolean | cdktn.IResolvable);
    });
    resetResourceTypeManagementPreference(): void;
    get resourceTypeManagementPreferenceInput(): {
        [key: string]: boolean | cdktn.IResolvable;
    } | undefined;
    private _resourceTypeOptInPreference?;
    get resourceTypeOptInPreference(): {
        [key: string]: (boolean | cdktn.IResolvable);
    };
    set resourceTypeOptInPreference(value: {
        [key: string]: (boolean | cdktn.IResolvable);
    });
    get resourceTypeOptInPreferenceInput(): {
        [key: string]: boolean | cdktn.IResolvable;
    } | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
