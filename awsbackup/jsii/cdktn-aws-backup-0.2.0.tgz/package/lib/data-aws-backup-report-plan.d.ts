import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataTfReportPlanConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/backup_report_plan#id DataTfReportPlan#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/backup_report_plan#name DataTfReportPlan#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/backup_report_plan#region DataTfReportPlan#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/backup_report_plan#tags DataTfReportPlan#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/backup_report_plan aws_backup_report_plan}
*/
export declare class DataTfReportPlan extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_backup_report_plan";
    /**
    * Generates CDKTN code for importing a DataTfReportPlan resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataTfReportPlan to import
    * @param importFromId The id of the existing DataTfReportPlan that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/backup_report_plan#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataTfReportPlan to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/backup_report_plan aws_backup_report_plan} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataTfReportPlanConfig
    */
    constructor(scope: Construct, id: string, config: DataTfReportPlanConfig);
    get arn(): string;
    get creationTime(): string;
    get deploymentStatus(): string;
    get description(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _reportDeliveryChannel;
    get reportDeliveryChannel(): DataTfReportPlan.ReportDeliveryChannelPropertyList;
    private _reportSetting;
    get reportSetting(): DataTfReportPlan.ReportSettingPropertyList;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataTfReportPlanReportDeliveryChannelPropertyToTerraform(struct?: DataTfReportPlan.ReportDeliveryChannelProperty): any;
export declare function dataTfReportPlanReportDeliveryChannelPropertyToHclTerraform(struct?: DataTfReportPlan.ReportDeliveryChannelProperty): any;
export declare function dataTfReportPlanReportSettingPropertyToTerraform(struct?: DataTfReportPlan.ReportSettingProperty): any;
export declare function dataTfReportPlanReportSettingPropertyToHclTerraform(struct?: DataTfReportPlan.ReportSettingProperty): any;
export declare namespace DataTfReportPlan {
    interface ReportDeliveryChannelProperty {
    }
    class ReportDeliveryChannelPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ReportDeliveryChannelProperty | undefined;
        set internalValue(value: ReportDeliveryChannelProperty | undefined);
        get formats(): string[];
        get s3BucketName(): string;
        get s3KeyPrefix(): string;
    }
    class ReportDeliveryChannelPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ReportDeliveryChannelPropertyOutputReference;
    }
    interface ReportSettingProperty {
    }
    class ReportSettingPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ReportSettingProperty | undefined;
        set internalValue(value: ReportSettingProperty | undefined);
        get accounts(): string[];
        get frameworkArns(): string[];
        get numberOfFrameworks(): number;
        get organizationUnits(): string[];
        get regions(): string[];
        get reportTemplate(): string;
    }
    class ReportSettingPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ReportSettingPropertyOutputReference;
    }
}
