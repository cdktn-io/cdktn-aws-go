import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfRestoreTestingSelectionConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/backup_restore_testing_selection#iam_role_arn TfRestoreTestingSelection#iam_role_arn}
    */
    readonly iamRoleArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/backup_restore_testing_selection#name TfRestoreTestingSelection#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/backup_restore_testing_selection#protected_resource_arns TfRestoreTestingSelection#protected_resource_arns}
    */
    readonly protectedResourceArns?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/backup_restore_testing_selection#protected_resource_type TfRestoreTestingSelection#protected_resource_type}
    */
    readonly protectedResourceType: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/backup_restore_testing_selection#region TfRestoreTestingSelection#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/backup_restore_testing_selection#restore_metadata_overrides TfRestoreTestingSelection#restore_metadata_overrides}
    */
    readonly restoreMetadataOverrides?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/backup_restore_testing_selection#restore_testing_plan_name TfRestoreTestingSelection#restore_testing_plan_name}
    */
    readonly restoreTestingPlanName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/backup_restore_testing_selection#validation_window_hours TfRestoreTestingSelection#validation_window_hours}
    */
    readonly validationWindowHours?: number;
    /**
    * protected_resource_conditions block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/backup_restore_testing_selection#protected_resource_conditions TfRestoreTestingSelection#protected_resource_conditions}
    */
    readonly protectedResourceConditions?: TfRestoreTestingSelection.ProtectedResourceConditionsProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/backup_restore_testing_selection aws_backup_restore_testing_selection}
*/
export declare class TfRestoreTestingSelection extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_backup_restore_testing_selection";
    /**
    * Generates CDKTN code for importing a TfRestoreTestingSelection resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfRestoreTestingSelection to import
    * @param importFromId The id of the existing TfRestoreTestingSelection that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/backup_restore_testing_selection#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfRestoreTestingSelection to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/backup_restore_testing_selection aws_backup_restore_testing_selection} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfRestoreTestingSelectionConfig
    */
    constructor(scope: Construct, id: string, config: TfRestoreTestingSelectionConfig);
    private _iamRoleArn?;
    get iamRoleArn(): string;
    set iamRoleArn(value: string);
    get iamRoleArnInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _protectedResourceArns?;
    get protectedResourceArns(): string[];
    set protectedResourceArns(value: string[]);
    resetProtectedResourceArns(): void;
    get protectedResourceArnsInput(): string[] | undefined;
    private _protectedResourceType?;
    get protectedResourceType(): string;
    set protectedResourceType(value: string);
    get protectedResourceTypeInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _restoreMetadataOverrides?;
    get restoreMetadataOverrides(): {
        [key: string]: string;
    };
    set restoreMetadataOverrides(value: {
        [key: string]: string;
    });
    resetRestoreMetadataOverrides(): void;
    get restoreMetadataOverridesInput(): {
        [key: string]: string;
    } | undefined;
    private _restoreTestingPlanName?;
    get restoreTestingPlanName(): string;
    set restoreTestingPlanName(value: string);
    get restoreTestingPlanNameInput(): string | undefined;
    private _validationWindowHours?;
    get validationWindowHours(): number;
    set validationWindowHours(value: number);
    resetValidationWindowHours(): void;
    get validationWindowHoursInput(): number | undefined;
    private _protectedResourceConditions;
    get protectedResourceConditions(): TfRestoreTestingSelection.ProtectedResourceConditionsPropertyList;
    putProtectedResourceConditions(value: TfRestoreTestingSelection.ProtectedResourceConditionsProperty[] | cdktn.IResolvable): void;
    resetProtectedResourceConditions(): void;
    get protectedResourceConditionsInput(): cdktn.IResolvable | TfRestoreTestingSelection.ProtectedResourceConditionsProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfRestoreTestingSelectionStringEqualsPropertyToTerraform(struct?: TfRestoreTestingSelection.StringEqualsProperty | cdktn.IResolvable): any;
export declare function tfRestoreTestingSelectionStringEqualsPropertyToHclTerraform(struct?: TfRestoreTestingSelection.StringEqualsProperty | cdktn.IResolvable): any;
export declare function tfRestoreTestingSelectionStringNotEqualsPropertyToTerraform(struct?: TfRestoreTestingSelection.StringNotEqualsProperty | cdktn.IResolvable): any;
export declare function tfRestoreTestingSelectionStringNotEqualsPropertyToHclTerraform(struct?: TfRestoreTestingSelection.StringNotEqualsProperty | cdktn.IResolvable): any;
export declare function tfRestoreTestingSelectionProtectedResourceConditionsPropertyToTerraform(struct?: TfRestoreTestingSelection.ProtectedResourceConditionsProperty | cdktn.IResolvable): any;
export declare function tfRestoreTestingSelectionProtectedResourceConditionsPropertyToHclTerraform(struct?: TfRestoreTestingSelection.ProtectedResourceConditionsProperty | cdktn.IResolvable): any;
export declare namespace TfRestoreTestingSelection {
    interface StringEqualsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/backup_restore_testing_selection#key TfRestoreTestingSelection#key}
        */
        readonly key: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/backup_restore_testing_selection#value TfRestoreTestingSelection#value}
        */
        readonly value: string;
    }
    class StringEqualsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): StringEqualsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: StringEqualsProperty | cdktn.IResolvable | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        get keyInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class StringEqualsPropertyList extends cdktn.ComplexList {
        internalValue?: StringEqualsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): StringEqualsPropertyOutputReference;
    }
    interface StringNotEqualsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/backup_restore_testing_selection#key TfRestoreTestingSelection#key}
        */
        readonly key: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/backup_restore_testing_selection#value TfRestoreTestingSelection#value}
        */
        readonly value: string;
    }
    class StringNotEqualsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): StringNotEqualsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: StringNotEqualsProperty | cdktn.IResolvable | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        get keyInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class StringNotEqualsPropertyList extends cdktn.ComplexList {
        internalValue?: StringNotEqualsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): StringNotEqualsPropertyOutputReference;
    }
    interface ProtectedResourceConditionsProperty {
        /**
        * string_equals block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/backup_restore_testing_selection#string_equals TfRestoreTestingSelection#string_equals}
        */
        readonly stringEquals?: StringEqualsProperty[] | cdktn.IResolvable;
        /**
        * string_not_equals block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/backup_restore_testing_selection#string_not_equals TfRestoreTestingSelection#string_not_equals}
        */
        readonly stringNotEquals?: StringNotEqualsProperty[] | cdktn.IResolvable;
    }
    class ProtectedResourceConditionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ProtectedResourceConditionsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ProtectedResourceConditionsProperty | cdktn.IResolvable | undefined);
        private _stringEquals;
        get stringEquals(): StringEqualsPropertyList;
        putStringEquals(value: StringEqualsProperty[] | cdktn.IResolvable): void;
        resetStringEquals(): void;
        get stringEqualsInput(): cdktn.IResolvable | StringEqualsProperty[] | undefined;
        private _stringNotEquals;
        get stringNotEquals(): StringNotEqualsPropertyList;
        putStringNotEquals(value: StringNotEqualsProperty[] | cdktn.IResolvable): void;
        resetStringNotEquals(): void;
        get stringNotEqualsInput(): cdktn.IResolvable | StringNotEqualsProperty[] | undefined;
    }
    class ProtectedResourceConditionsPropertyList extends cdktn.ComplexList {
        internalValue?: ProtectedResourceConditionsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ProtectedResourceConditionsPropertyOutputReference;
    }
}
