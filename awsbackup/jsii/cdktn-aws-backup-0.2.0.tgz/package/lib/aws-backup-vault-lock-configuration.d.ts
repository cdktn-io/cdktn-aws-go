import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfVaultLockConfigurationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/backup_vault_lock_configuration#backup_vault_name TfVaultLockConfiguration#backup_vault_name}
    */
    readonly backupVaultName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/backup_vault_lock_configuration#changeable_for_days TfVaultLockConfiguration#changeable_for_days}
    */
    readonly changeableForDays?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/backup_vault_lock_configuration#id TfVaultLockConfiguration#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/backup_vault_lock_configuration#max_retention_days TfVaultLockConfiguration#max_retention_days}
    */
    readonly maxRetentionDays?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/backup_vault_lock_configuration#min_retention_days TfVaultLockConfiguration#min_retention_days}
    */
    readonly minRetentionDays?: number;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/backup_vault_lock_configuration#region TfVaultLockConfiguration#region}
    */
    readonly region?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/backup_vault_lock_configuration aws_backup_vault_lock_configuration}
*/
export declare class TfVaultLockConfiguration extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_backup_vault_lock_configuration";
    /**
    * Generates CDKTN code for importing a TfVaultLockConfiguration resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfVaultLockConfiguration to import
    * @param importFromId The id of the existing TfVaultLockConfiguration that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/backup_vault_lock_configuration#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfVaultLockConfiguration to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/backup_vault_lock_configuration aws_backup_vault_lock_configuration} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfVaultLockConfigurationConfig
    */
    constructor(scope: Construct, id: string, config: TfVaultLockConfigurationConfig);
    get backupVaultArn(): string;
    private _backupVaultName?;
    get backupVaultName(): string;
    set backupVaultName(value: string);
    get backupVaultNameInput(): string | undefined;
    private _changeableForDays?;
    get changeableForDays(): number;
    set changeableForDays(value: number);
    resetChangeableForDays(): void;
    get changeableForDaysInput(): number | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _maxRetentionDays?;
    get maxRetentionDays(): number;
    set maxRetentionDays(value: number);
    resetMaxRetentionDays(): void;
    get maxRetentionDaysInput(): number | undefined;
    private _minRetentionDays?;
    get minRetentionDays(): number;
    set minRetentionDays(value: number);
    resetMinRetentionDays(): void;
    get minRetentionDaysInput(): number | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
