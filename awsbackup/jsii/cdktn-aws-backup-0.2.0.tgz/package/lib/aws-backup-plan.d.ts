import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfPlanConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/backup_plan#id TfPlan#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/backup_plan#name TfPlan#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/backup_plan#region TfPlan#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/backup_plan#tags TfPlan#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/backup_plan#tags_all TfPlan#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * advanced_backup_setting block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/backup_plan#advanced_backup_setting TfPlan#advanced_backup_setting}
    */
    readonly advancedBackupSetting?: TfPlan.AdvancedBackupSettingProperty[] | cdktn.IResolvable;
    /**
    * rule block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/backup_plan#rule TfPlan#rule}
    */
    readonly rule: TfPlan.RuleProperty[] | cdktn.IResolvable;
    /**
    * scan_setting block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/backup_plan#scan_setting TfPlan#scan_setting}
    */
    readonly scanSetting?: TfPlan.ScanSettingProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/backup_plan aws_backup_plan}
*/
export declare class TfPlan extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_backup_plan";
    /**
    * Generates CDKTN code for importing a TfPlan resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfPlan to import
    * @param importFromId The id of the existing TfPlan that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/backup_plan#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfPlan to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/backup_plan aws_backup_plan} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfPlanConfig
    */
    constructor(scope: Construct, id: string, config: TfPlanConfig);
    get arn(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    get version(): string;
    private _advancedBackupSetting;
    get advancedBackupSetting(): TfPlan.AdvancedBackupSettingPropertyList;
    putAdvancedBackupSetting(value: TfPlan.AdvancedBackupSettingProperty[] | cdktn.IResolvable): void;
    resetAdvancedBackupSetting(): void;
    get advancedBackupSettingInput(): cdktn.IResolvable | TfPlan.AdvancedBackupSettingProperty[] | undefined;
    private _rule;
    get rule(): TfPlan.RulePropertyList;
    putRule(value: TfPlan.RuleProperty[] | cdktn.IResolvable): void;
    get ruleInput(): cdktn.IResolvable | TfPlan.RuleProperty[] | undefined;
    private _scanSetting;
    get scanSetting(): TfPlan.ScanSettingPropertyList;
    putScanSetting(value: TfPlan.ScanSettingProperty[] | cdktn.IResolvable): void;
    resetScanSetting(): void;
    get scanSettingInput(): cdktn.IResolvable | TfPlan.ScanSettingProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfPlanAdvancedBackupSettingPropertyToTerraform(struct?: TfPlan.AdvancedBackupSettingProperty | cdktn.IResolvable): any;
export declare function tfPlanAdvancedBackupSettingPropertyToHclTerraform(struct?: TfPlan.AdvancedBackupSettingProperty | cdktn.IResolvable): any;
export declare function tfPlanRuleCopyActionLifecyclePropertyToTerraform(struct?: TfPlan.RuleCopyActionLifecyclePropertyOutputReference | TfPlan.RuleCopyActionLifecycleProperty): any;
export declare function tfPlanRuleCopyActionLifecyclePropertyToHclTerraform(struct?: TfPlan.RuleCopyActionLifecyclePropertyOutputReference | TfPlan.RuleCopyActionLifecycleProperty): any;
export declare function tfPlanCopyActionPropertyToTerraform(struct?: TfPlan.CopyActionProperty | cdktn.IResolvable): any;
export declare function tfPlanCopyActionPropertyToHclTerraform(struct?: TfPlan.CopyActionProperty | cdktn.IResolvable): any;
export declare function tfPlanRuleLifecyclePropertyToTerraform(struct?: TfPlan.RuleLifecyclePropertyOutputReference | TfPlan.RuleLifecycleProperty): any;
export declare function tfPlanRuleLifecyclePropertyToHclTerraform(struct?: TfPlan.RuleLifecyclePropertyOutputReference | TfPlan.RuleLifecycleProperty): any;
export declare function tfPlanScanActionPropertyToTerraform(struct?: TfPlan.ScanActionProperty | cdktn.IResolvable): any;
export declare function tfPlanScanActionPropertyToHclTerraform(struct?: TfPlan.ScanActionProperty | cdktn.IResolvable): any;
export declare function tfPlanRulePropertyToTerraform(struct?: TfPlan.RuleProperty | cdktn.IResolvable): any;
export declare function tfPlanRulePropertyToHclTerraform(struct?: TfPlan.RuleProperty | cdktn.IResolvable): any;
export declare function tfPlanScanSettingPropertyToTerraform(struct?: TfPlan.ScanSettingProperty | cdktn.IResolvable): any;
export declare function tfPlanScanSettingPropertyToHclTerraform(struct?: TfPlan.ScanSettingProperty | cdktn.IResolvable): any;
export declare namespace TfPlan {
    interface AdvancedBackupSettingProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/backup_plan#backup_options TfPlan#backup_options}
        */
        readonly backupOptions: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/backup_plan#resource_type TfPlan#resource_type}
        */
        readonly resourceType: string;
    }
    class AdvancedBackupSettingPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AdvancedBackupSettingProperty | cdktn.IResolvable | undefined;
        set internalValue(value: AdvancedBackupSettingProperty | cdktn.IResolvable | undefined);
        private _backupOptions?;
        get backupOptions(): {
            [key: string]: string;
        };
        set backupOptions(value: {
            [key: string]: string;
        });
        get backupOptionsInput(): {
            [key: string]: string;
        } | undefined;
        private _resourceType?;
        get resourceType(): string;
        set resourceType(value: string);
        get resourceTypeInput(): string | undefined;
    }
    class AdvancedBackupSettingPropertyList extends cdktn.ComplexList {
        internalValue?: AdvancedBackupSettingProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AdvancedBackupSettingPropertyOutputReference;
    }
    interface RuleCopyActionLifecycleProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/backup_plan#cold_storage_after TfPlan#cold_storage_after}
        */
        readonly coldStorageAfter?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/backup_plan#delete_after TfPlan#delete_after}
        */
        readonly deleteAfter?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/backup_plan#opt_in_to_archive_for_supported_resources TfPlan#opt_in_to_archive_for_supported_resources}
        */
        readonly optInToArchiveForSupportedResources?: boolean | cdktn.IResolvable;
    }
    class RuleCopyActionLifecyclePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RuleCopyActionLifecycleProperty | undefined;
        set internalValue(value: RuleCopyActionLifecycleProperty | undefined);
        private _coldStorageAfter?;
        get coldStorageAfter(): number;
        set coldStorageAfter(value: number);
        resetColdStorageAfter(): void;
        get coldStorageAfterInput(): number | undefined;
        private _deleteAfter?;
        get deleteAfter(): number;
        set deleteAfter(value: number);
        resetDeleteAfter(): void;
        get deleteAfterInput(): number | undefined;
        private _optInToArchiveForSupportedResources?;
        get optInToArchiveForSupportedResources(): boolean | cdktn.IResolvable;
        set optInToArchiveForSupportedResources(value: boolean | cdktn.IResolvable);
        resetOptInToArchiveForSupportedResources(): void;
        get optInToArchiveForSupportedResourcesInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface CopyActionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/backup_plan#destination_vault_arn TfPlan#destination_vault_arn}
        */
        readonly destinationVaultArn: string;
        /**
        * lifecycle block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/backup_plan#lifecycle TfPlan#lifecycle}
        */
        readonly lifecycle?: RuleCopyActionLifecycleProperty;
    }
    class CopyActionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CopyActionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CopyActionProperty | cdktn.IResolvable | undefined);
        private _destinationVaultArn?;
        get destinationVaultArn(): string;
        set destinationVaultArn(value: string);
        get destinationVaultArnInput(): string | undefined;
        private _lifecycle;
        get lifecycle(): RuleCopyActionLifecyclePropertyOutputReference;
        putLifecycle(value: RuleCopyActionLifecycleProperty): void;
        resetLifecycle(): void;
        get lifecycleInput(): RuleCopyActionLifecycleProperty | undefined;
    }
    class CopyActionPropertyList extends cdktn.ComplexList {
        internalValue?: CopyActionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CopyActionPropertyOutputReference;
    }
    interface RuleLifecycleProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/backup_plan#cold_storage_after TfPlan#cold_storage_after}
        */
        readonly coldStorageAfter?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/backup_plan#delete_after TfPlan#delete_after}
        */
        readonly deleteAfter?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/backup_plan#opt_in_to_archive_for_supported_resources TfPlan#opt_in_to_archive_for_supported_resources}
        */
        readonly optInToArchiveForSupportedResources?: boolean | cdktn.IResolvable;
    }
    class RuleLifecyclePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RuleLifecycleProperty | undefined;
        set internalValue(value: RuleLifecycleProperty | undefined);
        private _coldStorageAfter?;
        get coldStorageAfter(): number;
        set coldStorageAfter(value: number);
        resetColdStorageAfter(): void;
        get coldStorageAfterInput(): number | undefined;
        private _deleteAfter?;
        get deleteAfter(): number;
        set deleteAfter(value: number);
        resetDeleteAfter(): void;
        get deleteAfterInput(): number | undefined;
        private _optInToArchiveForSupportedResources?;
        get optInToArchiveForSupportedResources(): boolean | cdktn.IResolvable;
        set optInToArchiveForSupportedResources(value: boolean | cdktn.IResolvable);
        resetOptInToArchiveForSupportedResources(): void;
        get optInToArchiveForSupportedResourcesInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface ScanActionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/backup_plan#malware_scanner TfPlan#malware_scanner}
        */
        readonly malwareScanner: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/backup_plan#scan_mode TfPlan#scan_mode}
        */
        readonly scanMode: string;
    }
    class ScanActionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ScanActionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ScanActionProperty | cdktn.IResolvable | undefined);
        private _malwareScanner?;
        get malwareScanner(): string;
        set malwareScanner(value: string);
        get malwareScannerInput(): string | undefined;
        private _scanMode?;
        get scanMode(): string;
        set scanMode(value: string);
        get scanModeInput(): string | undefined;
    }
    class ScanActionPropertyList extends cdktn.ComplexList {
        internalValue?: ScanActionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ScanActionPropertyOutputReference;
    }
    interface RuleProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/backup_plan#completion_window TfPlan#completion_window}
        */
        readonly completionWindow?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/backup_plan#enable_continuous_backup TfPlan#enable_continuous_backup}
        */
        readonly enableContinuousBackup?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/backup_plan#recovery_point_tags TfPlan#recovery_point_tags}
        */
        readonly recoveryPointTags?: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/backup_plan#rule_name TfPlan#rule_name}
        */
        readonly ruleName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/backup_plan#schedule TfPlan#schedule}
        */
        readonly schedule?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/backup_plan#schedule_expression_timezone TfPlan#schedule_expression_timezone}
        */
        readonly scheduleExpressionTimezone?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/backup_plan#start_window TfPlan#start_window}
        */
        readonly startWindow?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/backup_plan#target_logically_air_gapped_backup_vault_arn TfPlan#target_logically_air_gapped_backup_vault_arn}
        */
        readonly targetLogicallyAirGappedBackupVaultArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/backup_plan#target_vault_name TfPlan#target_vault_name}
        */
        readonly targetVaultName: string;
        /**
        * copy_action block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/backup_plan#copy_action TfPlan#copy_action}
        */
        readonly copyAction?: CopyActionProperty[] | cdktn.IResolvable;
        /**
        * lifecycle block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/backup_plan#lifecycle TfPlan#lifecycle}
        */
        readonly lifecycle?: RuleLifecycleProperty;
        /**
        * scan_action block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/backup_plan#scan_action TfPlan#scan_action}
        */
        readonly scanAction?: ScanActionProperty[] | cdktn.IResolvable;
    }
    class RulePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RuleProperty | cdktn.IResolvable | undefined);
        private _completionWindow?;
        get completionWindow(): number;
        set completionWindow(value: number);
        resetCompletionWindow(): void;
        get completionWindowInput(): number | undefined;
        private _enableContinuousBackup?;
        get enableContinuousBackup(): boolean | cdktn.IResolvable;
        set enableContinuousBackup(value: boolean | cdktn.IResolvable);
        resetEnableContinuousBackup(): void;
        get enableContinuousBackupInput(): boolean | cdktn.IResolvable | undefined;
        private _recoveryPointTags?;
        get recoveryPointTags(): {
            [key: string]: string;
        };
        set recoveryPointTags(value: {
            [key: string]: string;
        });
        resetRecoveryPointTags(): void;
        get recoveryPointTagsInput(): {
            [key: string]: string;
        } | undefined;
        private _ruleName?;
        get ruleName(): string;
        set ruleName(value: string);
        get ruleNameInput(): string | undefined;
        private _schedule?;
        get schedule(): string;
        set schedule(value: string);
        resetSchedule(): void;
        get scheduleInput(): string | undefined;
        private _scheduleExpressionTimezone?;
        get scheduleExpressionTimezone(): string;
        set scheduleExpressionTimezone(value: string);
        resetScheduleExpressionTimezone(): void;
        get scheduleExpressionTimezoneInput(): string | undefined;
        private _startWindow?;
        get startWindow(): number;
        set startWindow(value: number);
        resetStartWindow(): void;
        get startWindowInput(): number | undefined;
        private _targetLogicallyAirGappedBackupVaultArn?;
        get targetLogicallyAirGappedBackupVaultArn(): string;
        set targetLogicallyAirGappedBackupVaultArn(value: string);
        resetTargetLogicallyAirGappedBackupVaultArn(): void;
        get targetLogicallyAirGappedBackupVaultArnInput(): string | undefined;
        private _targetVaultName?;
        get targetVaultName(): string;
        set targetVaultName(value: string);
        get targetVaultNameInput(): string | undefined;
        private _copyAction;
        get copyAction(): CopyActionPropertyList;
        putCopyAction(value: CopyActionProperty[] | cdktn.IResolvable): void;
        resetCopyAction(): void;
        get copyActionInput(): cdktn.IResolvable | CopyActionProperty[] | undefined;
        private _lifecycle;
        get lifecycle(): RuleLifecyclePropertyOutputReference;
        putLifecycle(value: RuleLifecycleProperty): void;
        resetLifecycle(): void;
        get lifecycleInput(): RuleLifecycleProperty | undefined;
        private _scanAction;
        get scanAction(): ScanActionPropertyList;
        putScanAction(value: ScanActionProperty[] | cdktn.IResolvable): void;
        resetScanAction(): void;
        get scanActionInput(): cdktn.IResolvable | ScanActionProperty[] | undefined;
    }
    class RulePropertyList extends cdktn.ComplexList {
        internalValue?: RuleProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RulePropertyOutputReference;
    }
    interface ScanSettingProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/backup_plan#malware_scanner TfPlan#malware_scanner}
        */
        readonly malwareScanner: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/backup_plan#resource_types TfPlan#resource_types}
        */
        readonly resourceTypes: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/backup_plan#scanner_role_arn TfPlan#scanner_role_arn}
        */
        readonly scannerRoleArn: string;
    }
    class ScanSettingPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ScanSettingProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ScanSettingProperty | cdktn.IResolvable | undefined);
        private _malwareScanner?;
        get malwareScanner(): string;
        set malwareScanner(value: string);
        get malwareScannerInput(): string | undefined;
        private _resourceTypes?;
        get resourceTypes(): string[];
        set resourceTypes(value: string[]);
        get resourceTypesInput(): string[] | undefined;
        private _scannerRoleArn?;
        get scannerRoleArn(): string;
        set scannerRoleArn(value: string);
        get scannerRoleArnInput(): string | undefined;
    }
    class ScanSettingPropertyList extends cdktn.ComplexList {
        internalValue?: ScanSettingProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ScanSettingPropertyOutputReference;
    }
}
