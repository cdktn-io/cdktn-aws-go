import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsBackupFrameworkConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/backup_framework#description AwsBackupFramework#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/backup_framework#id AwsBackupFramework#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/backup_framework#name AwsBackupFramework#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/backup_framework#region AwsBackupFramework#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/backup_framework#tags AwsBackupFramework#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/backup_framework#tags_all AwsBackupFramework#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * control block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/backup_framework#control AwsBackupFramework#control}
    */
    readonly control: AwsBackupFramework.ControlProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/backup_framework#timeouts AwsBackupFramework#timeouts}
    */
    readonly timeouts?: AwsBackupFramework.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/backup_framework aws_backup_framework}
*/
export declare class AwsBackupFramework extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_backup_framework";
    /**
    * Generates CDKTN code for importing a AwsBackupFramework resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsBackupFramework to import
    * @param importFromId The id of the existing AwsBackupFramework that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/backup_framework#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsBackupFramework to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/backup_framework aws_backup_framework} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsBackupFrameworkConfig
    */
    constructor(scope: Construct, id: string, config: AwsBackupFrameworkConfig);
    get arn(): string;
    get creationTime(): string;
    get deploymentStatus(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get status(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _control;
    get control(): AwsBackupFramework.ControlPropertyList;
    putControl(value: AwsBackupFramework.ControlProperty[] | cdktn.IResolvable): void;
    get controlInput(): cdktn.IResolvable | AwsBackupFramework.ControlProperty[] | undefined;
    private _timeouts;
    get timeouts(): AwsBackupFramework.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsBackupFramework.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsBackupFramework.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsBackupFrameworkInputParameterPropertyToTerraform(struct?: AwsBackupFramework.InputParameterProperty | cdktn.IResolvable): any;
export declare function awsBackupFrameworkInputParameterPropertyToHclTerraform(struct?: AwsBackupFramework.InputParameterProperty | cdktn.IResolvable): any;
export declare function awsBackupFrameworkScopePropertyToTerraform(struct?: AwsBackupFramework.ScopePropertyOutputReference | AwsBackupFramework.ScopeProperty): any;
export declare function awsBackupFrameworkScopePropertyToHclTerraform(struct?: AwsBackupFramework.ScopePropertyOutputReference | AwsBackupFramework.ScopeProperty): any;
export declare function awsBackupFrameworkControlPropertyToTerraform(struct?: AwsBackupFramework.ControlProperty | cdktn.IResolvable): any;
export declare function awsBackupFrameworkControlPropertyToHclTerraform(struct?: AwsBackupFramework.ControlProperty | cdktn.IResolvable): any;
export declare function awsBackupFrameworkTimeoutsPropertyToTerraform(struct?: AwsBackupFramework.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsBackupFrameworkTimeoutsPropertyToHclTerraform(struct?: AwsBackupFramework.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsBackupFramework {
    interface InputParameterProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/backup_framework#name AwsBackupFramework#name}
        */
        readonly name?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/backup_framework#value AwsBackupFramework#value}
        */
        readonly value?: string;
    }
    class InputParameterPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): InputParameterProperty | cdktn.IResolvable | undefined;
        set internalValue(value: InputParameterProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        resetName(): void;
        get nameInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        resetValue(): void;
        get valueInput(): string | undefined;
    }
    class InputParameterPropertyList extends cdktn.ComplexList {
        internalValue?: InputParameterProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): InputParameterPropertyOutputReference;
    }
    interface ScopeProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/backup_framework#compliance_resource_ids AwsBackupFramework#compliance_resource_ids}
        */
        readonly complianceResourceIds?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/backup_framework#compliance_resource_types AwsBackupFramework#compliance_resource_types}
        */
        readonly complianceResourceTypes?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/backup_framework#tags AwsBackupFramework#tags}
        */
        readonly tags?: {
            [key: string]: string;
        };
    }
    class ScopePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ScopeProperty | undefined;
        set internalValue(value: ScopeProperty | undefined);
        private _complianceResourceIds?;
        get complianceResourceIds(): string[];
        set complianceResourceIds(value: string[]);
        resetComplianceResourceIds(): void;
        get complianceResourceIdsInput(): string[] | undefined;
        private _complianceResourceTypes?;
        get complianceResourceTypes(): string[];
        set complianceResourceTypes(value: string[]);
        resetComplianceResourceTypes(): void;
        get complianceResourceTypesInput(): string[] | undefined;
        private _tags?;
        get tags(): {
            [key: string]: string;
        };
        set tags(value: {
            [key: string]: string;
        });
        resetTags(): void;
        get tagsInput(): {
            [key: string]: string;
        } | undefined;
    }
    interface ControlProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/backup_framework#name AwsBackupFramework#name}
        */
        readonly name: string;
        /**
        * input_parameter block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/backup_framework#input_parameter AwsBackupFramework#input_parameter}
        */
        readonly inputParameter?: InputParameterProperty[] | cdktn.IResolvable;
        /**
        * scope block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/backup_framework#scope AwsBackupFramework#scope}
        */
        readonly scope?: ScopeProperty;
    }
    class ControlPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ControlProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ControlProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _inputParameter;
        get inputParameter(): InputParameterPropertyList;
        putInputParameter(value: InputParameterProperty[] | cdktn.IResolvable): void;
        resetInputParameter(): void;
        get inputParameterInput(): cdktn.IResolvable | InputParameterProperty[] | undefined;
        private _scope;
        get scope(): ScopePropertyOutputReference;
        putScope(value: ScopeProperty): void;
        resetScope(): void;
        get scopeInput(): ScopeProperty | undefined;
    }
    class ControlPropertyList extends cdktn.ComplexList {
        internalValue?: ControlProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ControlPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/backup_framework#create AwsBackupFramework#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/backup_framework#delete AwsBackupFramework#delete}
        */
        readonly delete?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/backup_framework#update AwsBackupFramework#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
