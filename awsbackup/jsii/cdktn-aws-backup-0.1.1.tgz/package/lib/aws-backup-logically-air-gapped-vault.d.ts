import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsBackupLogicallyAirGappedVaultConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/backup_logically_air_gapped_vault#encryption_key_arn AwsBackupLogicallyAirGappedVault#encryption_key_arn}
    */
    readonly encryptionKeyArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/backup_logically_air_gapped_vault#max_retention_days AwsBackupLogicallyAirGappedVault#max_retention_days}
    */
    readonly maxRetentionDays: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/backup_logically_air_gapped_vault#min_retention_days AwsBackupLogicallyAirGappedVault#min_retention_days}
    */
    readonly minRetentionDays: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/backup_logically_air_gapped_vault#name AwsBackupLogicallyAirGappedVault#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/backup_logically_air_gapped_vault#region AwsBackupLogicallyAirGappedVault#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/backup_logically_air_gapped_vault#tags AwsBackupLogicallyAirGappedVault#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/backup_logically_air_gapped_vault#timeouts AwsBackupLogicallyAirGappedVault#timeouts}
    */
    readonly timeouts?: AwsBackupLogicallyAirGappedVault.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/backup_logically_air_gapped_vault aws_backup_logically_air_gapped_vault}
*/
export declare class AwsBackupLogicallyAirGappedVault extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_backup_logically_air_gapped_vault";
    /**
    * Generates CDKTN code for importing a AwsBackupLogicallyAirGappedVault resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsBackupLogicallyAirGappedVault to import
    * @param importFromId The id of the existing AwsBackupLogicallyAirGappedVault that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/backup_logically_air_gapped_vault#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsBackupLogicallyAirGappedVault to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/backup_logically_air_gapped_vault aws_backup_logically_air_gapped_vault} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsBackupLogicallyAirGappedVaultConfig
    */
    constructor(scope: Construct, id: string, config: AwsBackupLogicallyAirGappedVaultConfig);
    get arn(): string;
    private _encryptionKeyArn?;
    get encryptionKeyArn(): string;
    set encryptionKeyArn(value: string);
    resetEncryptionKeyArn(): void;
    get encryptionKeyArnInput(): string | undefined;
    get id(): string;
    private _maxRetentionDays?;
    get maxRetentionDays(): number;
    set maxRetentionDays(value: number);
    get maxRetentionDaysInput(): number | undefined;
    private _minRetentionDays?;
    get minRetentionDays(): number;
    set minRetentionDays(value: number);
    get minRetentionDaysInput(): number | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    private _timeouts;
    get timeouts(): AwsBackupLogicallyAirGappedVault.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsBackupLogicallyAirGappedVault.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsBackupLogicallyAirGappedVault.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsBackupLogicallyAirGappedVaultTimeoutsPropertyToTerraform(struct?: AwsBackupLogicallyAirGappedVault.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsBackupLogicallyAirGappedVaultTimeoutsPropertyToHclTerraform(struct?: AwsBackupLogicallyAirGappedVault.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsBackupLogicallyAirGappedVault {
    interface TimeoutsProperty {
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/backup_logically_air_gapped_vault#create AwsBackupLogicallyAirGappedVault#create}
        */
        readonly create?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
    }
}
