import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsBackupPlanConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/backup_plan#id DataAwsBackupPlan#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/backup_plan#plan_id DataAwsBackupPlan#plan_id}
    */
    readonly planId: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/backup_plan#region DataAwsBackupPlan#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/backup_plan#tags DataAwsBackupPlan#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/backup_plan aws_backup_plan}
*/
export declare class DataAwsBackupPlan extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_backup_plan";
    /**
    * Generates CDKTN code for importing a DataAwsBackupPlan resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsBackupPlan to import
    * @param importFromId The id of the existing DataAwsBackupPlan that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/backup_plan#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsBackupPlan to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/backup_plan aws_backup_plan} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsBackupPlanConfig
    */
    constructor(scope: Construct, id: string, config: DataAwsBackupPlanConfig);
    get arn(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get name(): string;
    private _planId?;
    get planId(): string;
    set planId(value: string);
    get planIdInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _rule;
    get rule(): DataAwsBackupPlan.RulePropertyList;
    private _scanSetting;
    get scanSetting(): DataAwsBackupPlan.ScanSettingPropertyList;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    get version(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataAwsBackupPlanRuleCopyActionLifecyclePropertyToTerraform(struct?: DataAwsBackupPlan.RuleCopyActionLifecycleProperty): any;
export declare function dataAwsBackupPlanRuleCopyActionLifecyclePropertyToHclTerraform(struct?: DataAwsBackupPlan.RuleCopyActionLifecycleProperty): any;
export declare function dataAwsBackupPlanCopyActionPropertyToTerraform(struct?: DataAwsBackupPlan.CopyActionProperty): any;
export declare function dataAwsBackupPlanCopyActionPropertyToHclTerraform(struct?: DataAwsBackupPlan.CopyActionProperty): any;
export declare function dataAwsBackupPlanRuleLifecyclePropertyToTerraform(struct?: DataAwsBackupPlan.RuleLifecycleProperty): any;
export declare function dataAwsBackupPlanRuleLifecyclePropertyToHclTerraform(struct?: DataAwsBackupPlan.RuleLifecycleProperty): any;
export declare function dataAwsBackupPlanScanActionPropertyToTerraform(struct?: DataAwsBackupPlan.ScanActionProperty): any;
export declare function dataAwsBackupPlanScanActionPropertyToHclTerraform(struct?: DataAwsBackupPlan.ScanActionProperty): any;
export declare function dataAwsBackupPlanRulePropertyToTerraform(struct?: DataAwsBackupPlan.RuleProperty): any;
export declare function dataAwsBackupPlanRulePropertyToHclTerraform(struct?: DataAwsBackupPlan.RuleProperty): any;
export declare function dataAwsBackupPlanScanSettingPropertyToTerraform(struct?: DataAwsBackupPlan.ScanSettingProperty): any;
export declare function dataAwsBackupPlanScanSettingPropertyToHclTerraform(struct?: DataAwsBackupPlan.ScanSettingProperty): any;
export declare namespace DataAwsBackupPlan {
    interface RuleCopyActionLifecycleProperty {
    }
    class RuleCopyActionLifecyclePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleCopyActionLifecycleProperty | undefined;
        set internalValue(value: RuleCopyActionLifecycleProperty | undefined);
        get coldStorageAfter(): number;
        get deleteAfter(): number;
        get optInToArchiveForSupportedResources(): cdktn.IResolvable;
    }
    class RuleCopyActionLifecyclePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleCopyActionLifecyclePropertyOutputReference;
    }
    interface CopyActionProperty {
    }
    class CopyActionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CopyActionProperty | undefined;
        set internalValue(value: CopyActionProperty | undefined);
        get destinationVaultArn(): string;
        private _lifecycle;
        get lifecycle(): RuleCopyActionLifecyclePropertyList;
    }
    class CopyActionPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CopyActionPropertyOutputReference;
    }
    interface RuleLifecycleProperty {
    }
    class RuleLifecyclePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleLifecycleProperty | undefined;
        set internalValue(value: RuleLifecycleProperty | undefined);
        get coldStorageAfter(): number;
        get deleteAfter(): number;
        get optInToArchiveForSupportedResources(): cdktn.IResolvable;
    }
    class RuleLifecyclePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleLifecyclePropertyOutputReference;
    }
    interface ScanActionProperty {
    }
    class ScanActionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ScanActionProperty | undefined;
        set internalValue(value: ScanActionProperty | undefined);
        get malwareScanner(): string;
        get scanMode(): string;
    }
    class ScanActionPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ScanActionPropertyOutputReference;
    }
    interface RuleProperty {
    }
    class RulePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleProperty | undefined;
        set internalValue(value: RuleProperty | undefined);
        get completionWindow(): number;
        private _copyAction;
        get copyAction(): CopyActionPropertyList;
        get enableContinuousBackup(): cdktn.IResolvable;
        private _lifecycle;
        get lifecycle(): RuleLifecyclePropertyList;
        private _recoveryPointTags;
        get recoveryPointTags(): cdktn.StringMap;
        get ruleName(): string;
        private _scanAction;
        get scanAction(): ScanActionPropertyList;
        get schedule(): string;
        get scheduleExpressionTimezone(): string;
        get startWindow(): number;
        get targetLogicallyAirGappedBackupVaultArn(): string;
        get targetVaultName(): string;
    }
    class RulePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RulePropertyOutputReference;
    }
    interface ScanSettingProperty {
    }
    class ScanSettingPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ScanSettingProperty | undefined;
        set internalValue(value: ScanSettingProperty | undefined);
        get malwareScanner(): string;
        get resourceTypes(): string[];
        get scannerRoleArn(): string;
    }
    class ScanSettingPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ScanSettingPropertyOutputReference;
    }
}
