import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsBackupReportPlanConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/backup_report_plan#description AwsBackupReportPlan#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/backup_report_plan#id AwsBackupReportPlan#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/backup_report_plan#name AwsBackupReportPlan#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/backup_report_plan#region AwsBackupReportPlan#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/backup_report_plan#tags AwsBackupReportPlan#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/backup_report_plan#tags_all AwsBackupReportPlan#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * report_delivery_channel block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/backup_report_plan#report_delivery_channel AwsBackupReportPlan#report_delivery_channel}
    */
    readonly reportDeliveryChannel: AwsBackupReportPlan.ReportDeliveryChannelProperty;
    /**
    * report_setting block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/backup_report_plan#report_setting AwsBackupReportPlan#report_setting}
    */
    readonly reportSetting: AwsBackupReportPlan.ReportSettingProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/backup_report_plan aws_backup_report_plan}
*/
export declare class AwsBackupReportPlan extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_backup_report_plan";
    /**
    * Generates CDKTN code for importing a AwsBackupReportPlan resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsBackupReportPlan to import
    * @param importFromId The id of the existing AwsBackupReportPlan that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/backup_report_plan#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsBackupReportPlan to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/backup_report_plan aws_backup_report_plan} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsBackupReportPlanConfig
    */
    constructor(scope: Construct, id: string, config: AwsBackupReportPlanConfig);
    get arn(): string;
    get creationTime(): string;
    get deploymentStatus(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _reportDeliveryChannel;
    get reportDeliveryChannel(): AwsBackupReportPlan.ReportDeliveryChannelPropertyOutputReference;
    putReportDeliveryChannel(value: AwsBackupReportPlan.ReportDeliveryChannelProperty): void;
    get reportDeliveryChannelInput(): AwsBackupReportPlan.ReportDeliveryChannelProperty | undefined;
    private _reportSetting;
    get reportSetting(): AwsBackupReportPlan.ReportSettingPropertyOutputReference;
    putReportSetting(value: AwsBackupReportPlan.ReportSettingProperty): void;
    get reportSettingInput(): AwsBackupReportPlan.ReportSettingProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsBackupReportPlanReportDeliveryChannelPropertyToTerraform(struct?: AwsBackupReportPlan.ReportDeliveryChannelPropertyOutputReference | AwsBackupReportPlan.ReportDeliveryChannelProperty): any;
export declare function awsBackupReportPlanReportDeliveryChannelPropertyToHclTerraform(struct?: AwsBackupReportPlan.ReportDeliveryChannelPropertyOutputReference | AwsBackupReportPlan.ReportDeliveryChannelProperty): any;
export declare function awsBackupReportPlanReportSettingPropertyToTerraform(struct?: AwsBackupReportPlan.ReportSettingPropertyOutputReference | AwsBackupReportPlan.ReportSettingProperty): any;
export declare function awsBackupReportPlanReportSettingPropertyToHclTerraform(struct?: AwsBackupReportPlan.ReportSettingPropertyOutputReference | AwsBackupReportPlan.ReportSettingProperty): any;
export declare namespace AwsBackupReportPlan {
    interface ReportDeliveryChannelProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/backup_report_plan#formats AwsBackupReportPlan#formats}
        */
        readonly formats?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/backup_report_plan#s3_bucket_name AwsBackupReportPlan#s3_bucket_name}
        */
        readonly s3BucketName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/backup_report_plan#s3_key_prefix AwsBackupReportPlan#s3_key_prefix}
        */
        readonly s3KeyPrefix?: string;
    }
    class ReportDeliveryChannelPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ReportDeliveryChannelProperty | undefined;
        set internalValue(value: ReportDeliveryChannelProperty | undefined);
        private _formats?;
        get formats(): string[];
        set formats(value: string[]);
        resetFormats(): void;
        get formatsInput(): string[] | undefined;
        private _s3BucketName?;
        get s3BucketName(): string;
        set s3BucketName(value: string);
        get s3BucketNameInput(): string | undefined;
        private _s3KeyPrefix?;
        get s3KeyPrefix(): string;
        set s3KeyPrefix(value: string);
        resetS3KeyPrefix(): void;
        get s3KeyPrefixInput(): string | undefined;
    }
    interface ReportSettingProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/backup_report_plan#accounts AwsBackupReportPlan#accounts}
        */
        readonly accounts?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/backup_report_plan#framework_arns AwsBackupReportPlan#framework_arns}
        */
        readonly frameworkArns?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/backup_report_plan#number_of_frameworks AwsBackupReportPlan#number_of_frameworks}
        */
        readonly numberOfFrameworks?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/backup_report_plan#organization_units AwsBackupReportPlan#organization_units}
        */
        readonly organizationUnits?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/backup_report_plan#regions AwsBackupReportPlan#regions}
        */
        readonly regions?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/backup_report_plan#report_template AwsBackupReportPlan#report_template}
        */
        readonly reportTemplate: string;
    }
    class ReportSettingPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ReportSettingProperty | undefined;
        set internalValue(value: ReportSettingProperty | undefined);
        private _accounts?;
        get accounts(): string[];
        set accounts(value: string[]);
        resetAccounts(): void;
        get accountsInput(): string[] | undefined;
        private _frameworkArns?;
        get frameworkArns(): string[];
        set frameworkArns(value: string[]);
        resetFrameworkArns(): void;
        get frameworkArnsInput(): string[] | undefined;
        private _numberOfFrameworks?;
        get numberOfFrameworks(): number;
        set numberOfFrameworks(value: number);
        resetNumberOfFrameworks(): void;
        get numberOfFrameworksInput(): number | undefined;
        private _organizationUnits?;
        get organizationUnits(): string[];
        set organizationUnits(value: string[]);
        resetOrganizationUnits(): void;
        get organizationUnitsInput(): string[] | undefined;
        private _regions?;
        get regions(): string[];
        set regions(value: string[]);
        resetRegions(): void;
        get regionsInput(): string[] | undefined;
        private _reportTemplate?;
        get reportTemplate(): string;
        set reportTemplate(value: string);
        get reportTemplateInput(): string | undefined;
    }
}
