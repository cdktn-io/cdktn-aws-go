import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsUserDefinedFunctionConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_user_defined_function#catalog_id AwsUserDefinedFunction#catalog_id}
    */
    readonly catalogId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_user_defined_function#class_name AwsUserDefinedFunction#class_name}
    */
    readonly className: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_user_defined_function#database_name AwsUserDefinedFunction#database_name}
    */
    readonly databaseName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_user_defined_function#id AwsUserDefinedFunction#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_user_defined_function#name AwsUserDefinedFunction#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_user_defined_function#owner_name AwsUserDefinedFunction#owner_name}
    */
    readonly ownerName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_user_defined_function#owner_type AwsUserDefinedFunction#owner_type}
    */
    readonly ownerType: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_user_defined_function#region AwsUserDefinedFunction#region}
    */
    readonly region?: string;
    /**
    * resource_uris block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_user_defined_function#resource_uris AwsUserDefinedFunction#resource_uris}
    */
    readonly resourceUris?: AwsUserDefinedFunction.ResourceUrisProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_user_defined_function aws_glue_user_defined_function}
*/
export declare class AwsUserDefinedFunction extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_glue_user_defined_function";
    /**
    * Generates CDKTN code for importing a AwsUserDefinedFunction resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsUserDefinedFunction to import
    * @param importFromId The id of the existing AwsUserDefinedFunction that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_user_defined_function#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsUserDefinedFunction to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_user_defined_function aws_glue_user_defined_function} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsUserDefinedFunctionConfig
    */
    constructor(scope: Construct, id: string, config: AwsUserDefinedFunctionConfig);
    get arn(): string;
    private _catalogId?;
    get catalogId(): string;
    set catalogId(value: string);
    resetCatalogId(): void;
    get catalogIdInput(): string | undefined;
    private _className?;
    get className(): string;
    set className(value: string);
    get classNameInput(): string | undefined;
    get createTime(): string;
    private _databaseName?;
    get databaseName(): string;
    set databaseName(value: string);
    get databaseNameInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _ownerName?;
    get ownerName(): string;
    set ownerName(value: string);
    get ownerNameInput(): string | undefined;
    private _ownerType?;
    get ownerType(): string;
    set ownerType(value: string);
    get ownerTypeInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _resourceUris;
    get resourceUris(): AwsUserDefinedFunction.ResourceUrisPropertyList;
    putResourceUris(value: AwsUserDefinedFunction.ResourceUrisProperty[] | cdktn.IResolvable): void;
    resetResourceUris(): void;
    get resourceUrisInput(): cdktn.IResolvable | AwsUserDefinedFunction.ResourceUrisProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsUserDefinedFunctionResourceUrisPropertyToTerraform(struct?: AwsUserDefinedFunction.ResourceUrisProperty | cdktn.IResolvable): any;
export declare function awsUserDefinedFunctionResourceUrisPropertyToHclTerraform(struct?: AwsUserDefinedFunction.ResourceUrisProperty | cdktn.IResolvable): any;
export declare namespace AwsUserDefinedFunction {
    interface ResourceUrisProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_user_defined_function#resource_type AwsUserDefinedFunction#resource_type}
        */
        readonly resourceType: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_user_defined_function#uri AwsUserDefinedFunction#uri}
        */
        readonly uri: string;
    }
    class ResourceUrisPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ResourceUrisProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ResourceUrisProperty | cdktn.IResolvable | undefined);
        private _resourceType?;
        get resourceType(): string;
        set resourceType(value: string);
        get resourceTypeInput(): string | undefined;
        private _uri?;
        get uri(): string;
        set uri(value: string);
        get uriInput(): string | undefined;
    }
    class ResourceUrisPropertyList extends cdktn.ComplexList {
        internalValue?: ResourceUrisProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ResourceUrisPropertyOutputReference;
    }
}
