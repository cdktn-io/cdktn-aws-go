import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsCatalogTableConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/glue_catalog_table#catalog_id DataAwsCatalogTable#catalog_id}
    */
    readonly catalogId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/glue_catalog_table#database_name DataAwsCatalogTable#database_name}
    */
    readonly databaseName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/glue_catalog_table#id DataAwsCatalogTable#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/glue_catalog_table#name DataAwsCatalogTable#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/glue_catalog_table#query_as_of_time DataAwsCatalogTable#query_as_of_time}
    */
    readonly queryAsOfTime?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/glue_catalog_table#region DataAwsCatalogTable#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/glue_catalog_table#transaction_id DataAwsCatalogTable#transaction_id}
    */
    readonly transactionId?: number;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/glue_catalog_table aws_glue_catalog_table}
*/
export declare class DataAwsCatalogTable extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_glue_catalog_table";
    /**
    * Generates CDKTN code for importing a DataAwsCatalogTable resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsCatalogTable to import
    * @param importFromId The id of the existing DataAwsCatalogTable that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/glue_catalog_table#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsCatalogTable to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/glue_catalog_table aws_glue_catalog_table} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsCatalogTableConfig
    */
    constructor(scope: Construct, id: string, config: DataAwsCatalogTableConfig);
    get arn(): string;
    private _catalogId?;
    get catalogId(): string;
    set catalogId(value: string);
    resetCatalogId(): void;
    get catalogIdInput(): string | undefined;
    private _databaseName?;
    get databaseName(): string;
    set databaseName(value: string);
    get databaseNameInput(): string | undefined;
    get description(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get owner(): string;
    private _parameters;
    get parameters(): cdktn.StringMap;
    private _partitionIndex;
    get partitionIndex(): DataAwsCatalogTable.PartitionIndexPropertyList;
    private _partitionKeys;
    get partitionKeys(): DataAwsCatalogTable.PartitionKeysPropertyList;
    private _queryAsOfTime?;
    get queryAsOfTime(): string;
    set queryAsOfTime(value: string);
    resetQueryAsOfTime(): void;
    get queryAsOfTimeInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get retention(): number;
    private _storageDescriptor;
    get storageDescriptor(): DataAwsCatalogTable.StorageDescriptorPropertyList;
    get tableType(): string;
    private _targetTable;
    get targetTable(): DataAwsCatalogTable.TargetTablePropertyList;
    private _transactionId?;
    get transactionId(): number;
    set transactionId(value: number);
    resetTransactionId(): void;
    get transactionIdInput(): number | undefined;
    get viewExpandedText(): string;
    get viewOriginalText(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataAwsCatalogTablePartitionIndexPropertyToTerraform(struct?: DataAwsCatalogTable.PartitionIndexProperty): any;
export declare function dataAwsCatalogTablePartitionIndexPropertyToHclTerraform(struct?: DataAwsCatalogTable.PartitionIndexProperty): any;
export declare function dataAwsCatalogTablePartitionKeysPropertyToTerraform(struct?: DataAwsCatalogTable.PartitionKeysProperty): any;
export declare function dataAwsCatalogTablePartitionKeysPropertyToHclTerraform(struct?: DataAwsCatalogTable.PartitionKeysProperty): any;
export declare function dataAwsCatalogTableColumnsPropertyToTerraform(struct?: DataAwsCatalogTable.ColumnsProperty): any;
export declare function dataAwsCatalogTableColumnsPropertyToHclTerraform(struct?: DataAwsCatalogTable.ColumnsProperty): any;
export declare function dataAwsCatalogTableSchemaIdPropertyToTerraform(struct?: DataAwsCatalogTable.SchemaIdProperty): any;
export declare function dataAwsCatalogTableSchemaIdPropertyToHclTerraform(struct?: DataAwsCatalogTable.SchemaIdProperty): any;
export declare function dataAwsCatalogTableSchemaReferencePropertyToTerraform(struct?: DataAwsCatalogTable.SchemaReferenceProperty): any;
export declare function dataAwsCatalogTableSchemaReferencePropertyToHclTerraform(struct?: DataAwsCatalogTable.SchemaReferenceProperty): any;
export declare function dataAwsCatalogTableSerDeInfoPropertyToTerraform(struct?: DataAwsCatalogTable.SerDeInfoProperty): any;
export declare function dataAwsCatalogTableSerDeInfoPropertyToHclTerraform(struct?: DataAwsCatalogTable.SerDeInfoProperty): any;
export declare function dataAwsCatalogTableSkewedInfoPropertyToTerraform(struct?: DataAwsCatalogTable.SkewedInfoProperty): any;
export declare function dataAwsCatalogTableSkewedInfoPropertyToHclTerraform(struct?: DataAwsCatalogTable.SkewedInfoProperty): any;
export declare function dataAwsCatalogTableSortColumnsPropertyToTerraform(struct?: DataAwsCatalogTable.SortColumnsProperty): any;
export declare function dataAwsCatalogTableSortColumnsPropertyToHclTerraform(struct?: DataAwsCatalogTable.SortColumnsProperty): any;
export declare function dataAwsCatalogTableStorageDescriptorPropertyToTerraform(struct?: DataAwsCatalogTable.StorageDescriptorProperty): any;
export declare function dataAwsCatalogTableStorageDescriptorPropertyToHclTerraform(struct?: DataAwsCatalogTable.StorageDescriptorProperty): any;
export declare function dataAwsCatalogTableTargetTablePropertyToTerraform(struct?: DataAwsCatalogTable.TargetTableProperty): any;
export declare function dataAwsCatalogTableTargetTablePropertyToHclTerraform(struct?: DataAwsCatalogTable.TargetTableProperty): any;
export declare namespace DataAwsCatalogTable {
    interface PartitionIndexProperty {
    }
    class PartitionIndexPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): PartitionIndexProperty | undefined;
        set internalValue(value: PartitionIndexProperty | undefined);
        get indexName(): string;
        get indexStatus(): string;
        get keys(): string[];
    }
    class PartitionIndexPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): PartitionIndexPropertyOutputReference;
    }
    interface PartitionKeysProperty {
    }
    class PartitionKeysPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): PartitionKeysProperty | undefined;
        set internalValue(value: PartitionKeysProperty | undefined);
        get comment(): string;
        get name(): string;
        private _parameters;
        get parameters(): cdktn.StringMap;
        get type(): string;
    }
    class PartitionKeysPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): PartitionKeysPropertyOutputReference;
    }
    interface ColumnsProperty {
    }
    class ColumnsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ColumnsProperty | undefined;
        set internalValue(value: ColumnsProperty | undefined);
        get comment(): string;
        get name(): string;
        private _parameters;
        get parameters(): cdktn.StringMap;
        get type(): string;
    }
    class ColumnsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ColumnsPropertyOutputReference;
    }
    interface SchemaIdProperty {
    }
    class SchemaIdPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SchemaIdProperty | undefined;
        set internalValue(value: SchemaIdProperty | undefined);
        get registryName(): string;
        get schemaArn(): string;
        get schemaName(): string;
    }
    class SchemaIdPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SchemaIdPropertyOutputReference;
    }
    interface SchemaReferenceProperty {
    }
    class SchemaReferencePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SchemaReferenceProperty | undefined;
        set internalValue(value: SchemaReferenceProperty | undefined);
        private _schemaId;
        get schemaId(): SchemaIdPropertyList;
        get schemaVersionId(): string;
        get schemaVersionNumber(): number;
    }
    class SchemaReferencePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SchemaReferencePropertyOutputReference;
    }
    interface SerDeInfoProperty {
    }
    class SerDeInfoPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SerDeInfoProperty | undefined;
        set internalValue(value: SerDeInfoProperty | undefined);
        get name(): string;
        private _parameters;
        get parameters(): cdktn.StringMap;
        get serializationLibrary(): string;
    }
    class SerDeInfoPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SerDeInfoPropertyOutputReference;
    }
    interface SkewedInfoProperty {
    }
    class SkewedInfoPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SkewedInfoProperty | undefined;
        set internalValue(value: SkewedInfoProperty | undefined);
        get skewedColumnNames(): string[];
        private _skewedColumnValueLocationMaps;
        get skewedColumnValueLocationMaps(): cdktn.StringMap;
        get skewedColumnValues(): string[];
    }
    class SkewedInfoPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SkewedInfoPropertyOutputReference;
    }
    interface SortColumnsProperty {
    }
    class SortColumnsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SortColumnsProperty | undefined;
        set internalValue(value: SortColumnsProperty | undefined);
        get column(): string;
        get sortOrder(): number;
    }
    class SortColumnsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SortColumnsPropertyOutputReference;
    }
    interface StorageDescriptorProperty {
    }
    class StorageDescriptorPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): StorageDescriptorProperty | undefined;
        set internalValue(value: StorageDescriptorProperty | undefined);
        get additionalLocations(): string[];
        get bucketColumns(): string[];
        private _columns;
        get columns(): ColumnsPropertyList;
        get compressed(): cdktn.IResolvable;
        get inputFormat(): string;
        get location(): string;
        get numberOfBuckets(): number;
        get outputFormat(): string;
        private _parameters;
        get parameters(): cdktn.StringMap;
        private _schemaReference;
        get schemaReference(): SchemaReferencePropertyList;
        private _serDeInfo;
        get serDeInfo(): SerDeInfoPropertyList;
        private _skewedInfo;
        get skewedInfo(): SkewedInfoPropertyList;
        private _sortColumns;
        get sortColumns(): SortColumnsPropertyList;
        get storedAsSubDirectories(): cdktn.IResolvable;
    }
    class StorageDescriptorPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): StorageDescriptorPropertyOutputReference;
    }
    interface TargetTableProperty {
    }
    class TargetTablePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TargetTableProperty | undefined;
        set internalValue(value: TargetTableProperty | undefined);
        get catalogId(): string;
        get databaseName(): string;
        get name(): string;
        get region(): string;
    }
    class TargetTablePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TargetTablePropertyOutputReference;
    }
}
