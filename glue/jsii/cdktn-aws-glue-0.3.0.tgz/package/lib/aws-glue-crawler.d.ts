import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsCrawlerConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_crawler#classifiers AwsCrawler#classifiers}
    */
    readonly classifiers?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_crawler#configuration AwsCrawler#configuration}
    */
    readonly configuration?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_crawler#database_name AwsCrawler#database_name}
    */
    readonly databaseName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_crawler#description AwsCrawler#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_crawler#id AwsCrawler#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_crawler#name AwsCrawler#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_crawler#region AwsCrawler#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_crawler#role AwsCrawler#role}
    */
    readonly role: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_crawler#schedule AwsCrawler#schedule}
    */
    readonly schedule?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_crawler#security_configuration AwsCrawler#security_configuration}
    */
    readonly securityConfiguration?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_crawler#table_prefix AwsCrawler#table_prefix}
    */
    readonly tablePrefix?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_crawler#tags AwsCrawler#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_crawler#tags_all AwsCrawler#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * catalog_target block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_crawler#catalog_target AwsCrawler#catalog_target}
    */
    readonly catalogTarget?: AwsCrawler.CatalogTargetProperty[] | cdktn.IResolvable;
    /**
    * delta_target block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_crawler#delta_target AwsCrawler#delta_target}
    */
    readonly deltaTarget?: AwsCrawler.DeltaTargetProperty[] | cdktn.IResolvable;
    /**
    * dynamodb_target block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_crawler#dynamodb_target AwsCrawler#dynamodb_target}
    */
    readonly dynamodbTarget?: AwsCrawler.DynamodbTargetProperty[] | cdktn.IResolvable;
    /**
    * hudi_target block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_crawler#hudi_target AwsCrawler#hudi_target}
    */
    readonly hudiTarget?: AwsCrawler.HudiTargetProperty[] | cdktn.IResolvable;
    /**
    * iceberg_target block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_crawler#iceberg_target AwsCrawler#iceberg_target}
    */
    readonly icebergTarget?: AwsCrawler.IcebergTargetProperty[] | cdktn.IResolvable;
    /**
    * jdbc_target block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_crawler#jdbc_target AwsCrawler#jdbc_target}
    */
    readonly jdbcTarget?: AwsCrawler.JdbcTargetProperty[] | cdktn.IResolvable;
    /**
    * lake_formation_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_crawler#lake_formation_configuration AwsCrawler#lake_formation_configuration}
    */
    readonly lakeFormationConfiguration?: AwsCrawler.LakeFormationConfigurationProperty;
    /**
    * lineage_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_crawler#lineage_configuration AwsCrawler#lineage_configuration}
    */
    readonly lineageConfiguration?: AwsCrawler.LineageConfigurationProperty;
    /**
    * mongodb_target block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_crawler#mongodb_target AwsCrawler#mongodb_target}
    */
    readonly mongodbTarget?: AwsCrawler.MongodbTargetProperty[] | cdktn.IResolvable;
    /**
    * recrawl_policy block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_crawler#recrawl_policy AwsCrawler#recrawl_policy}
    */
    readonly recrawlPolicy?: AwsCrawler.RecrawlPolicyProperty;
    /**
    * s3_target block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_crawler#s3_target AwsCrawler#s3_target}
    */
    readonly s3Target?: AwsCrawler.S3TargetProperty[] | cdktn.IResolvable;
    /**
    * schema_change_policy block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_crawler#schema_change_policy AwsCrawler#schema_change_policy}
    */
    readonly schemaChangePolicy?: AwsCrawler.SchemaChangePolicyProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_crawler aws_glue_crawler}
*/
export declare class AwsCrawler extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_glue_crawler";
    /**
    * Generates CDKTN code for importing a AwsCrawler resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsCrawler to import
    * @param importFromId The id of the existing AwsCrawler that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_crawler#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsCrawler to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_crawler aws_glue_crawler} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsCrawlerConfig
    */
    constructor(scope: Construct, id: string, config: AwsCrawlerConfig);
    get arn(): string;
    private _classifiers?;
    get classifiers(): string[];
    set classifiers(value: string[]);
    resetClassifiers(): void;
    get classifiersInput(): string[] | undefined;
    private _configuration?;
    get configuration(): string;
    set configuration(value: string);
    resetConfiguration(): void;
    get configurationInput(): string | undefined;
    private _databaseName?;
    get databaseName(): string;
    set databaseName(value: string);
    get databaseNameInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _role?;
    get role(): string;
    set role(value: string);
    get roleInput(): string | undefined;
    private _schedule?;
    get schedule(): string;
    set schedule(value: string);
    resetSchedule(): void;
    get scheduleInput(): string | undefined;
    private _securityConfiguration?;
    get securityConfiguration(): string;
    set securityConfiguration(value: string);
    resetSecurityConfiguration(): void;
    get securityConfigurationInput(): string | undefined;
    private _tablePrefix?;
    get tablePrefix(): string;
    set tablePrefix(value: string);
    resetTablePrefix(): void;
    get tablePrefixInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _catalogTarget;
    get catalogTarget(): AwsCrawler.CatalogTargetPropertyList;
    putCatalogTarget(value: AwsCrawler.CatalogTargetProperty[] | cdktn.IResolvable): void;
    resetCatalogTarget(): void;
    get catalogTargetInput(): cdktn.IResolvable | AwsCrawler.CatalogTargetProperty[] | undefined;
    private _deltaTarget;
    get deltaTarget(): AwsCrawler.DeltaTargetPropertyList;
    putDeltaTarget(value: AwsCrawler.DeltaTargetProperty[] | cdktn.IResolvable): void;
    resetDeltaTarget(): void;
    get deltaTargetInput(): cdktn.IResolvable | AwsCrawler.DeltaTargetProperty[] | undefined;
    private _dynamodbTarget;
    get dynamodbTarget(): AwsCrawler.DynamodbTargetPropertyList;
    putDynamodbTarget(value: AwsCrawler.DynamodbTargetProperty[] | cdktn.IResolvable): void;
    resetDynamodbTarget(): void;
    get dynamodbTargetInput(): cdktn.IResolvable | AwsCrawler.DynamodbTargetProperty[] | undefined;
    private _hudiTarget;
    get hudiTarget(): AwsCrawler.HudiTargetPropertyList;
    putHudiTarget(value: AwsCrawler.HudiTargetProperty[] | cdktn.IResolvable): void;
    resetHudiTarget(): void;
    get hudiTargetInput(): cdktn.IResolvable | AwsCrawler.HudiTargetProperty[] | undefined;
    private _icebergTarget;
    get icebergTarget(): AwsCrawler.IcebergTargetPropertyList;
    putIcebergTarget(value: AwsCrawler.IcebergTargetProperty[] | cdktn.IResolvable): void;
    resetIcebergTarget(): void;
    get icebergTargetInput(): cdktn.IResolvable | AwsCrawler.IcebergTargetProperty[] | undefined;
    private _jdbcTarget;
    get jdbcTarget(): AwsCrawler.JdbcTargetPropertyList;
    putJdbcTarget(value: AwsCrawler.JdbcTargetProperty[] | cdktn.IResolvable): void;
    resetJdbcTarget(): void;
    get jdbcTargetInput(): cdktn.IResolvable | AwsCrawler.JdbcTargetProperty[] | undefined;
    private _lakeFormationConfiguration;
    get lakeFormationConfiguration(): AwsCrawler.LakeFormationConfigurationPropertyOutputReference;
    putLakeFormationConfiguration(value: AwsCrawler.LakeFormationConfigurationProperty): void;
    resetLakeFormationConfiguration(): void;
    get lakeFormationConfigurationInput(): AwsCrawler.LakeFormationConfigurationProperty | undefined;
    private _lineageConfiguration;
    get lineageConfiguration(): AwsCrawler.LineageConfigurationPropertyOutputReference;
    putLineageConfiguration(value: AwsCrawler.LineageConfigurationProperty): void;
    resetLineageConfiguration(): void;
    get lineageConfigurationInput(): AwsCrawler.LineageConfigurationProperty | undefined;
    private _mongodbTarget;
    get mongodbTarget(): AwsCrawler.MongodbTargetPropertyList;
    putMongodbTarget(value: AwsCrawler.MongodbTargetProperty[] | cdktn.IResolvable): void;
    resetMongodbTarget(): void;
    get mongodbTargetInput(): cdktn.IResolvable | AwsCrawler.MongodbTargetProperty[] | undefined;
    private _recrawlPolicy;
    get recrawlPolicy(): AwsCrawler.RecrawlPolicyPropertyOutputReference;
    putRecrawlPolicy(value: AwsCrawler.RecrawlPolicyProperty): void;
    resetRecrawlPolicy(): void;
    get recrawlPolicyInput(): AwsCrawler.RecrawlPolicyProperty | undefined;
    private _s3Target;
    get s3Target(): AwsCrawler.S3TargetPropertyList;
    putS3Target(value: AwsCrawler.S3TargetProperty[] | cdktn.IResolvable): void;
    resetS3Target(): void;
    get s3TargetInput(): cdktn.IResolvable | AwsCrawler.S3TargetProperty[] | undefined;
    private _schemaChangePolicy;
    get schemaChangePolicy(): AwsCrawler.SchemaChangePolicyPropertyOutputReference;
    putSchemaChangePolicy(value: AwsCrawler.SchemaChangePolicyProperty): void;
    resetSchemaChangePolicy(): void;
    get schemaChangePolicyInput(): AwsCrawler.SchemaChangePolicyProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsCrawlerCatalogTargetPropertyToTerraform(struct?: AwsCrawler.CatalogTargetProperty | cdktn.IResolvable): any;
export declare function awsCrawlerCatalogTargetPropertyToHclTerraform(struct?: AwsCrawler.CatalogTargetProperty | cdktn.IResolvable): any;
export declare function awsCrawlerDeltaTargetPropertyToTerraform(struct?: AwsCrawler.DeltaTargetProperty | cdktn.IResolvable): any;
export declare function awsCrawlerDeltaTargetPropertyToHclTerraform(struct?: AwsCrawler.DeltaTargetProperty | cdktn.IResolvable): any;
export declare function awsCrawlerDynamodbTargetPropertyToTerraform(struct?: AwsCrawler.DynamodbTargetProperty | cdktn.IResolvable): any;
export declare function awsCrawlerDynamodbTargetPropertyToHclTerraform(struct?: AwsCrawler.DynamodbTargetProperty | cdktn.IResolvable): any;
export declare function awsCrawlerHudiTargetPropertyToTerraform(struct?: AwsCrawler.HudiTargetProperty | cdktn.IResolvable): any;
export declare function awsCrawlerHudiTargetPropertyToHclTerraform(struct?: AwsCrawler.HudiTargetProperty | cdktn.IResolvable): any;
export declare function awsCrawlerIcebergTargetPropertyToTerraform(struct?: AwsCrawler.IcebergTargetProperty | cdktn.IResolvable): any;
export declare function awsCrawlerIcebergTargetPropertyToHclTerraform(struct?: AwsCrawler.IcebergTargetProperty | cdktn.IResolvable): any;
export declare function awsCrawlerJdbcTargetPropertyToTerraform(struct?: AwsCrawler.JdbcTargetProperty | cdktn.IResolvable): any;
export declare function awsCrawlerJdbcTargetPropertyToHclTerraform(struct?: AwsCrawler.JdbcTargetProperty | cdktn.IResolvable): any;
export declare function awsCrawlerLakeFormationConfigurationPropertyToTerraform(struct?: AwsCrawler.LakeFormationConfigurationPropertyOutputReference | AwsCrawler.LakeFormationConfigurationProperty): any;
export declare function awsCrawlerLakeFormationConfigurationPropertyToHclTerraform(struct?: AwsCrawler.LakeFormationConfigurationPropertyOutputReference | AwsCrawler.LakeFormationConfigurationProperty): any;
export declare function awsCrawlerLineageConfigurationPropertyToTerraform(struct?: AwsCrawler.LineageConfigurationPropertyOutputReference | AwsCrawler.LineageConfigurationProperty): any;
export declare function awsCrawlerLineageConfigurationPropertyToHclTerraform(struct?: AwsCrawler.LineageConfigurationPropertyOutputReference | AwsCrawler.LineageConfigurationProperty): any;
export declare function awsCrawlerMongodbTargetPropertyToTerraform(struct?: AwsCrawler.MongodbTargetProperty | cdktn.IResolvable): any;
export declare function awsCrawlerMongodbTargetPropertyToHclTerraform(struct?: AwsCrawler.MongodbTargetProperty | cdktn.IResolvable): any;
export declare function awsCrawlerRecrawlPolicyPropertyToTerraform(struct?: AwsCrawler.RecrawlPolicyPropertyOutputReference | AwsCrawler.RecrawlPolicyProperty): any;
export declare function awsCrawlerRecrawlPolicyPropertyToHclTerraform(struct?: AwsCrawler.RecrawlPolicyPropertyOutputReference | AwsCrawler.RecrawlPolicyProperty): any;
export declare function awsCrawlerS3TargetPropertyToTerraform(struct?: AwsCrawler.S3TargetProperty | cdktn.IResolvable): any;
export declare function awsCrawlerS3TargetPropertyToHclTerraform(struct?: AwsCrawler.S3TargetProperty | cdktn.IResolvable): any;
export declare function awsCrawlerSchemaChangePolicyPropertyToTerraform(struct?: AwsCrawler.SchemaChangePolicyPropertyOutputReference | AwsCrawler.SchemaChangePolicyProperty): any;
export declare function awsCrawlerSchemaChangePolicyPropertyToHclTerraform(struct?: AwsCrawler.SchemaChangePolicyPropertyOutputReference | AwsCrawler.SchemaChangePolicyProperty): any;
export declare namespace AwsCrawler {
    interface CatalogTargetProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_crawler#connection_name AwsCrawler#connection_name}
        */
        readonly connectionName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_crawler#database_name AwsCrawler#database_name}
        */
        readonly databaseName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_crawler#dlq_event_queue_arn AwsCrawler#dlq_event_queue_arn}
        */
        readonly dlqEventQueueArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_crawler#event_queue_arn AwsCrawler#event_queue_arn}
        */
        readonly eventQueueArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_crawler#tables AwsCrawler#tables}
        */
        readonly tables: string[];
    }
    class CatalogTargetPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CatalogTargetProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CatalogTargetProperty | cdktn.IResolvable | undefined);
        private _connectionName?;
        get connectionName(): string;
        set connectionName(value: string);
        resetConnectionName(): void;
        get connectionNameInput(): string | undefined;
        private _databaseName?;
        get databaseName(): string;
        set databaseName(value: string);
        get databaseNameInput(): string | undefined;
        private _dlqEventQueueArn?;
        get dlqEventQueueArn(): string;
        set dlqEventQueueArn(value: string);
        resetDlqEventQueueArn(): void;
        get dlqEventQueueArnInput(): string | undefined;
        private _eventQueueArn?;
        get eventQueueArn(): string;
        set eventQueueArn(value: string);
        resetEventQueueArn(): void;
        get eventQueueArnInput(): string | undefined;
        private _tables?;
        get tables(): string[];
        set tables(value: string[]);
        get tablesInput(): string[] | undefined;
    }
    class CatalogTargetPropertyList extends cdktn.ComplexList {
        internalValue?: CatalogTargetProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CatalogTargetPropertyOutputReference;
    }
    interface DeltaTargetProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_crawler#connection_name AwsCrawler#connection_name}
        */
        readonly connectionName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_crawler#create_native_delta_table AwsCrawler#create_native_delta_table}
        */
        readonly createNativeDeltaTable?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_crawler#delta_tables AwsCrawler#delta_tables}
        */
        readonly deltaTables: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_crawler#write_manifest AwsCrawler#write_manifest}
        */
        readonly writeManifest: boolean | cdktn.IResolvable;
    }
    class DeltaTargetPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DeltaTargetProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DeltaTargetProperty | cdktn.IResolvable | undefined);
        private _connectionName?;
        get connectionName(): string;
        set connectionName(value: string);
        resetConnectionName(): void;
        get connectionNameInput(): string | undefined;
        private _createNativeDeltaTable?;
        get createNativeDeltaTable(): boolean | cdktn.IResolvable;
        set createNativeDeltaTable(value: boolean | cdktn.IResolvable);
        resetCreateNativeDeltaTable(): void;
        get createNativeDeltaTableInput(): boolean | cdktn.IResolvable | undefined;
        private _deltaTables?;
        get deltaTables(): string[];
        set deltaTables(value: string[]);
        get deltaTablesInput(): string[] | undefined;
        private _writeManifest?;
        get writeManifest(): boolean | cdktn.IResolvable;
        set writeManifest(value: boolean | cdktn.IResolvable);
        get writeManifestInput(): boolean | cdktn.IResolvable | undefined;
    }
    class DeltaTargetPropertyList extends cdktn.ComplexList {
        internalValue?: DeltaTargetProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DeltaTargetPropertyOutputReference;
    }
    interface DynamodbTargetProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_crawler#path AwsCrawler#path}
        */
        readonly path: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_crawler#scan_all AwsCrawler#scan_all}
        */
        readonly scanAll?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_crawler#scan_rate AwsCrawler#scan_rate}
        */
        readonly scanRate?: number;
    }
    class DynamodbTargetPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DynamodbTargetProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DynamodbTargetProperty | cdktn.IResolvable | undefined);
        private _path?;
        get path(): string;
        set path(value: string);
        get pathInput(): string | undefined;
        private _scanAll?;
        get scanAll(): boolean | cdktn.IResolvable;
        set scanAll(value: boolean | cdktn.IResolvable);
        resetScanAll(): void;
        get scanAllInput(): boolean | cdktn.IResolvable | undefined;
        private _scanRate?;
        get scanRate(): number;
        set scanRate(value: number);
        resetScanRate(): void;
        get scanRateInput(): number | undefined;
    }
    class DynamodbTargetPropertyList extends cdktn.ComplexList {
        internalValue?: DynamodbTargetProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DynamodbTargetPropertyOutputReference;
    }
    interface HudiTargetProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_crawler#connection_name AwsCrawler#connection_name}
        */
        readonly connectionName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_crawler#exclusions AwsCrawler#exclusions}
        */
        readonly exclusions?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_crawler#maximum_traversal_depth AwsCrawler#maximum_traversal_depth}
        */
        readonly maximumTraversalDepth: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_crawler#paths AwsCrawler#paths}
        */
        readonly paths: string[];
    }
    class HudiTargetPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): HudiTargetProperty | cdktn.IResolvable | undefined;
        set internalValue(value: HudiTargetProperty | cdktn.IResolvable | undefined);
        private _connectionName?;
        get connectionName(): string;
        set connectionName(value: string);
        resetConnectionName(): void;
        get connectionNameInput(): string | undefined;
        private _exclusions?;
        get exclusions(): string[];
        set exclusions(value: string[]);
        resetExclusions(): void;
        get exclusionsInput(): string[] | undefined;
        private _maximumTraversalDepth?;
        get maximumTraversalDepth(): number;
        set maximumTraversalDepth(value: number);
        get maximumTraversalDepthInput(): number | undefined;
        private _paths?;
        get paths(): string[];
        set paths(value: string[]);
        get pathsInput(): string[] | undefined;
    }
    class HudiTargetPropertyList extends cdktn.ComplexList {
        internalValue?: HudiTargetProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): HudiTargetPropertyOutputReference;
    }
    interface IcebergTargetProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_crawler#connection_name AwsCrawler#connection_name}
        */
        readonly connectionName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_crawler#exclusions AwsCrawler#exclusions}
        */
        readonly exclusions?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_crawler#maximum_traversal_depth AwsCrawler#maximum_traversal_depth}
        */
        readonly maximumTraversalDepth: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_crawler#paths AwsCrawler#paths}
        */
        readonly paths: string[];
    }
    class IcebergTargetPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): IcebergTargetProperty | cdktn.IResolvable | undefined;
        set internalValue(value: IcebergTargetProperty | cdktn.IResolvable | undefined);
        private _connectionName?;
        get connectionName(): string;
        set connectionName(value: string);
        resetConnectionName(): void;
        get connectionNameInput(): string | undefined;
        private _exclusions?;
        get exclusions(): string[];
        set exclusions(value: string[]);
        resetExclusions(): void;
        get exclusionsInput(): string[] | undefined;
        private _maximumTraversalDepth?;
        get maximumTraversalDepth(): number;
        set maximumTraversalDepth(value: number);
        get maximumTraversalDepthInput(): number | undefined;
        private _paths?;
        get paths(): string[];
        set paths(value: string[]);
        get pathsInput(): string[] | undefined;
    }
    class IcebergTargetPropertyList extends cdktn.ComplexList {
        internalValue?: IcebergTargetProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): IcebergTargetPropertyOutputReference;
    }
    interface JdbcTargetProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_crawler#connection_name AwsCrawler#connection_name}
        */
        readonly connectionName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_crawler#enable_additional_metadata AwsCrawler#enable_additional_metadata}
        */
        readonly enableAdditionalMetadata?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_crawler#exclusions AwsCrawler#exclusions}
        */
        readonly exclusions?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_crawler#path AwsCrawler#path}
        */
        readonly path: string;
    }
    class JdbcTargetPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): JdbcTargetProperty | cdktn.IResolvable | undefined;
        set internalValue(value: JdbcTargetProperty | cdktn.IResolvable | undefined);
        private _connectionName?;
        get connectionName(): string;
        set connectionName(value: string);
        get connectionNameInput(): string | undefined;
        private _enableAdditionalMetadata?;
        get enableAdditionalMetadata(): string[];
        set enableAdditionalMetadata(value: string[]);
        resetEnableAdditionalMetadata(): void;
        get enableAdditionalMetadataInput(): string[] | undefined;
        private _exclusions?;
        get exclusions(): string[];
        set exclusions(value: string[]);
        resetExclusions(): void;
        get exclusionsInput(): string[] | undefined;
        private _path?;
        get path(): string;
        set path(value: string);
        get pathInput(): string | undefined;
    }
    class JdbcTargetPropertyList extends cdktn.ComplexList {
        internalValue?: JdbcTargetProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): JdbcTargetPropertyOutputReference;
    }
    interface LakeFormationConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_crawler#account_id AwsCrawler#account_id}
        */
        readonly accountId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_crawler#use_lake_formation_credentials AwsCrawler#use_lake_formation_credentials}
        */
        readonly useLakeFormationCredentials?: boolean | cdktn.IResolvable;
    }
    class LakeFormationConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): LakeFormationConfigurationProperty | undefined;
        set internalValue(value: LakeFormationConfigurationProperty | undefined);
        private _accountId?;
        get accountId(): string;
        set accountId(value: string);
        resetAccountId(): void;
        get accountIdInput(): string | undefined;
        private _useLakeFormationCredentials?;
        get useLakeFormationCredentials(): boolean | cdktn.IResolvable;
        set useLakeFormationCredentials(value: boolean | cdktn.IResolvable);
        resetUseLakeFormationCredentials(): void;
        get useLakeFormationCredentialsInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface LineageConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_crawler#crawler_lineage_settings AwsCrawler#crawler_lineage_settings}
        */
        readonly crawlerLineageSettings?: string;
    }
    class LineageConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): LineageConfigurationProperty | undefined;
        set internalValue(value: LineageConfigurationProperty | undefined);
        private _crawlerLineageSettings?;
        get crawlerLineageSettings(): string;
        set crawlerLineageSettings(value: string);
        resetCrawlerLineageSettings(): void;
        get crawlerLineageSettingsInput(): string | undefined;
    }
    interface MongodbTargetProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_crawler#connection_name AwsCrawler#connection_name}
        */
        readonly connectionName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_crawler#path AwsCrawler#path}
        */
        readonly path: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_crawler#scan_all AwsCrawler#scan_all}
        */
        readonly scanAll?: boolean | cdktn.IResolvable;
    }
    class MongodbTargetPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): MongodbTargetProperty | cdktn.IResolvable | undefined;
        set internalValue(value: MongodbTargetProperty | cdktn.IResolvable | undefined);
        private _connectionName?;
        get connectionName(): string;
        set connectionName(value: string);
        get connectionNameInput(): string | undefined;
        private _path?;
        get path(): string;
        set path(value: string);
        get pathInput(): string | undefined;
        private _scanAll?;
        get scanAll(): boolean | cdktn.IResolvable;
        set scanAll(value: boolean | cdktn.IResolvable);
        resetScanAll(): void;
        get scanAllInput(): boolean | cdktn.IResolvable | undefined;
    }
    class MongodbTargetPropertyList extends cdktn.ComplexList {
        internalValue?: MongodbTargetProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): MongodbTargetPropertyOutputReference;
    }
    interface RecrawlPolicyProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_crawler#recrawl_behavior AwsCrawler#recrawl_behavior}
        */
        readonly recrawlBehavior?: string;
    }
    class RecrawlPolicyPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RecrawlPolicyProperty | undefined;
        set internalValue(value: RecrawlPolicyProperty | undefined);
        private _recrawlBehavior?;
        get recrawlBehavior(): string;
        set recrawlBehavior(value: string);
        resetRecrawlBehavior(): void;
        get recrawlBehaviorInput(): string | undefined;
    }
    interface S3TargetProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_crawler#connection_name AwsCrawler#connection_name}
        */
        readonly connectionName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_crawler#dlq_event_queue_arn AwsCrawler#dlq_event_queue_arn}
        */
        readonly dlqEventQueueArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_crawler#event_queue_arn AwsCrawler#event_queue_arn}
        */
        readonly eventQueueArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_crawler#exclusions AwsCrawler#exclusions}
        */
        readonly exclusions?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_crawler#path AwsCrawler#path}
        */
        readonly path: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_crawler#sample_size AwsCrawler#sample_size}
        */
        readonly sampleSize?: number;
    }
    class S3TargetPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): S3TargetProperty | cdktn.IResolvable | undefined;
        set internalValue(value: S3TargetProperty | cdktn.IResolvable | undefined);
        private _connectionName?;
        get connectionName(): string;
        set connectionName(value: string);
        resetConnectionName(): void;
        get connectionNameInput(): string | undefined;
        private _dlqEventQueueArn?;
        get dlqEventQueueArn(): string;
        set dlqEventQueueArn(value: string);
        resetDlqEventQueueArn(): void;
        get dlqEventQueueArnInput(): string | undefined;
        private _eventQueueArn?;
        get eventQueueArn(): string;
        set eventQueueArn(value: string);
        resetEventQueueArn(): void;
        get eventQueueArnInput(): string | undefined;
        private _exclusions?;
        get exclusions(): string[];
        set exclusions(value: string[]);
        resetExclusions(): void;
        get exclusionsInput(): string[] | undefined;
        private _path?;
        get path(): string;
        set path(value: string);
        get pathInput(): string | undefined;
        private _sampleSize?;
        get sampleSize(): number;
        set sampleSize(value: number);
        resetSampleSize(): void;
        get sampleSizeInput(): number | undefined;
    }
    class S3TargetPropertyList extends cdktn.ComplexList {
        internalValue?: S3TargetProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): S3TargetPropertyOutputReference;
    }
    interface SchemaChangePolicyProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_crawler#delete_behavior AwsCrawler#delete_behavior}
        */
        readonly deleteBehavior?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_crawler#update_behavior AwsCrawler#update_behavior}
        */
        readonly updateBehavior?: string;
    }
    class SchemaChangePolicyPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SchemaChangePolicyProperty | undefined;
        set internalValue(value: SchemaChangePolicyProperty | undefined);
        private _deleteBehavior?;
        get deleteBehavior(): string;
        set deleteBehavior(value: string);
        resetDeleteBehavior(): void;
        get deleteBehaviorInput(): string | undefined;
        private _updateBehavior?;
        get updateBehavior(): string;
        set updateBehavior(value: string);
        resetUpdateBehavior(): void;
        get updateBehaviorInput(): string | undefined;
    }
}
