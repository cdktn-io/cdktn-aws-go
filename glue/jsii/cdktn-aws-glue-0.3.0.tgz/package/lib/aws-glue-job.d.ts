import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsJobConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_job#connections AwsJob#connections}
    */
    readonly connections?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_job#default_arguments AwsJob#default_arguments}
    */
    readonly defaultArguments?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_job#description AwsJob#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_job#execution_class AwsJob#execution_class}
    */
    readonly executionClass?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_job#glue_version AwsJob#glue_version}
    */
    readonly glueVersion?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_job#id AwsJob#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_job#job_mode AwsJob#job_mode}
    */
    readonly jobMode?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_job#job_run_queuing_enabled AwsJob#job_run_queuing_enabled}
    */
    readonly jobRunQueuingEnabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_job#maintenance_window AwsJob#maintenance_window}
    */
    readonly maintenanceWindow?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_job#max_capacity AwsJob#max_capacity}
    */
    readonly maxCapacity?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_job#max_retries AwsJob#max_retries}
    */
    readonly maxRetries?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_job#name AwsJob#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_job#non_overridable_arguments AwsJob#non_overridable_arguments}
    */
    readonly nonOverridableArguments?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_job#number_of_workers AwsJob#number_of_workers}
    */
    readonly numberOfWorkers?: number;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_job#region AwsJob#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_job#role_arn AwsJob#role_arn}
    */
    readonly roleArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_job#security_configuration AwsJob#security_configuration}
    */
    readonly securityConfiguration?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_job#tags AwsJob#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_job#tags_all AwsJob#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_job#timeout AwsJob#timeout}
    */
    readonly timeout?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_job#worker_type AwsJob#worker_type}
    */
    readonly workerType?: string;
    /**
    * command block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_job#command AwsJob#command}
    */
    readonly command: AwsJob.CommandProperty;
    /**
    * execution_property block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_job#execution_property AwsJob#execution_property}
    */
    readonly executionProperty?: AwsJob.ExecutionPropertyProperty;
    /**
    * notification_property block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_job#notification_property AwsJob#notification_property}
    */
    readonly notificationProperty?: AwsJob.NotificationPropertyProperty;
    /**
    * source_control_details block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_job#source_control_details AwsJob#source_control_details}
    */
    readonly sourceControlDetails?: AwsJob.SourceControlDetailsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_job aws_glue_job}
*/
export declare class AwsJob extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_glue_job";
    /**
    * Generates CDKTN code for importing a AwsJob resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsJob to import
    * @param importFromId The id of the existing AwsJob that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_job#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsJob to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_job aws_glue_job} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsJobConfig
    */
    constructor(scope: Construct, id: string, config: AwsJobConfig);
    get arn(): string;
    private _connections?;
    get connections(): string[];
    set connections(value: string[]);
    resetConnections(): void;
    get connectionsInput(): string[] | undefined;
    private _defaultArguments?;
    get defaultArguments(): {
        [key: string]: string;
    };
    set defaultArguments(value: {
        [key: string]: string;
    });
    resetDefaultArguments(): void;
    get defaultArgumentsInput(): {
        [key: string]: string;
    } | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _executionClass?;
    get executionClass(): string;
    set executionClass(value: string);
    resetExecutionClass(): void;
    get executionClassInput(): string | undefined;
    private _glueVersion?;
    get glueVersion(): string;
    set glueVersion(value: string);
    resetGlueVersion(): void;
    get glueVersionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _jobMode?;
    get jobMode(): string;
    set jobMode(value: string);
    resetJobMode(): void;
    get jobModeInput(): string | undefined;
    private _jobRunQueuingEnabled?;
    get jobRunQueuingEnabled(): boolean | cdktn.IResolvable;
    set jobRunQueuingEnabled(value: boolean | cdktn.IResolvable);
    resetJobRunQueuingEnabled(): void;
    get jobRunQueuingEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _maintenanceWindow?;
    get maintenanceWindow(): string;
    set maintenanceWindow(value: string);
    resetMaintenanceWindow(): void;
    get maintenanceWindowInput(): string | undefined;
    private _maxCapacity?;
    get maxCapacity(): number;
    set maxCapacity(value: number);
    resetMaxCapacity(): void;
    get maxCapacityInput(): number | undefined;
    private _maxRetries?;
    get maxRetries(): number;
    set maxRetries(value: number);
    resetMaxRetries(): void;
    get maxRetriesInput(): number | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _nonOverridableArguments?;
    get nonOverridableArguments(): {
        [key: string]: string;
    };
    set nonOverridableArguments(value: {
        [key: string]: string;
    });
    resetNonOverridableArguments(): void;
    get nonOverridableArgumentsInput(): {
        [key: string]: string;
    } | undefined;
    private _numberOfWorkers?;
    get numberOfWorkers(): number;
    set numberOfWorkers(value: number);
    resetNumberOfWorkers(): void;
    get numberOfWorkersInput(): number | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _roleArn?;
    get roleArn(): string;
    set roleArn(value: string);
    get roleArnInput(): string | undefined;
    private _securityConfiguration?;
    get securityConfiguration(): string;
    set securityConfiguration(value: string);
    resetSecurityConfiguration(): void;
    get securityConfigurationInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _timeout?;
    get timeout(): number;
    set timeout(value: number);
    resetTimeout(): void;
    get timeoutInput(): number | undefined;
    private _workerType?;
    get workerType(): string;
    set workerType(value: string);
    resetWorkerType(): void;
    get workerTypeInput(): string | undefined;
    private _command;
    get command(): AwsJob.CommandPropertyOutputReference;
    putCommand(value: AwsJob.CommandProperty): void;
    get commandInput(): AwsJob.CommandProperty | undefined;
    private _executionProperty;
    get executionProperty(): AwsJob.ExecutionPropertyPropertyOutputReference;
    putExecutionProperty(value: AwsJob.ExecutionPropertyProperty): void;
    resetExecutionProperty(): void;
    get executionPropertyInput(): AwsJob.ExecutionPropertyProperty | undefined;
    private _notificationProperty;
    get notificationProperty(): AwsJob.NotificationPropertyPropertyOutputReference;
    putNotificationProperty(value: AwsJob.NotificationPropertyProperty): void;
    resetNotificationProperty(): void;
    get notificationPropertyInput(): AwsJob.NotificationPropertyProperty | undefined;
    private _sourceControlDetails;
    get sourceControlDetails(): AwsJob.SourceControlDetailsPropertyOutputReference;
    putSourceControlDetails(value: AwsJob.SourceControlDetailsProperty): void;
    resetSourceControlDetails(): void;
    get sourceControlDetailsInput(): AwsJob.SourceControlDetailsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsJobCommandPropertyToTerraform(struct?: AwsJob.CommandPropertyOutputReference | AwsJob.CommandProperty): any;
export declare function awsJobCommandPropertyToHclTerraform(struct?: AwsJob.CommandPropertyOutputReference | AwsJob.CommandProperty): any;
export declare function awsJobExecutionPropertyPropertyToTerraform(struct?: AwsJob.ExecutionPropertyPropertyOutputReference | AwsJob.ExecutionPropertyProperty): any;
export declare function awsJobExecutionPropertyPropertyToHclTerraform(struct?: AwsJob.ExecutionPropertyPropertyOutputReference | AwsJob.ExecutionPropertyProperty): any;
export declare function awsJobNotificationPropertyPropertyToTerraform(struct?: AwsJob.NotificationPropertyPropertyOutputReference | AwsJob.NotificationPropertyProperty): any;
export declare function awsJobNotificationPropertyPropertyToHclTerraform(struct?: AwsJob.NotificationPropertyPropertyOutputReference | AwsJob.NotificationPropertyProperty): any;
export declare function awsJobSourceControlDetailsPropertyToTerraform(struct?: AwsJob.SourceControlDetailsPropertyOutputReference | AwsJob.SourceControlDetailsProperty): any;
export declare function awsJobSourceControlDetailsPropertyToHclTerraform(struct?: AwsJob.SourceControlDetailsPropertyOutputReference | AwsJob.SourceControlDetailsProperty): any;
export declare namespace AwsJob {
    interface CommandProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_job#name AwsJob#name}
        */
        readonly name?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_job#python_version AwsJob#python_version}
        */
        readonly pythonVersion?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_job#runtime AwsJob#runtime}
        */
        readonly runtime?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_job#script_location AwsJob#script_location}
        */
        readonly scriptLocation: string;
    }
    class CommandPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CommandProperty | undefined;
        set internalValue(value: CommandProperty | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        resetName(): void;
        get nameInput(): string | undefined;
        private _pythonVersion?;
        get pythonVersion(): string;
        set pythonVersion(value: string);
        resetPythonVersion(): void;
        get pythonVersionInput(): string | undefined;
        private _runtime?;
        get runtime(): string;
        set runtime(value: string);
        resetRuntime(): void;
        get runtimeInput(): string | undefined;
        private _scriptLocation?;
        get scriptLocation(): string;
        set scriptLocation(value: string);
        get scriptLocationInput(): string | undefined;
    }
    interface ExecutionPropertyProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_job#max_concurrent_runs AwsJob#max_concurrent_runs}
        */
        readonly maxConcurrentRuns?: number;
    }
    class ExecutionPropertyPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ExecutionPropertyProperty | undefined;
        set internalValue(value: ExecutionPropertyProperty | undefined);
        private _maxConcurrentRuns?;
        get maxConcurrentRuns(): number;
        set maxConcurrentRuns(value: number);
        resetMaxConcurrentRuns(): void;
        get maxConcurrentRunsInput(): number | undefined;
    }
    interface NotificationPropertyProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_job#notify_delay_after AwsJob#notify_delay_after}
        */
        readonly notifyDelayAfter?: number;
    }
    class NotificationPropertyPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): NotificationPropertyProperty | undefined;
        set internalValue(value: NotificationPropertyProperty | undefined);
        private _notifyDelayAfter?;
        get notifyDelayAfter(): number;
        set notifyDelayAfter(value: number);
        resetNotifyDelayAfter(): void;
        get notifyDelayAfterInput(): number | undefined;
    }
    interface SourceControlDetailsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_job#auth_strategy AwsJob#auth_strategy}
        */
        readonly authStrategy?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_job#auth_token AwsJob#auth_token}
        */
        readonly authToken?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_job#branch AwsJob#branch}
        */
        readonly branch?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_job#folder AwsJob#folder}
        */
        readonly folder?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_job#last_commit_id AwsJob#last_commit_id}
        */
        readonly lastCommitId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_job#owner AwsJob#owner}
        */
        readonly owner?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_job#provider AwsJob#provider}
        */
        readonly provider?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_job#repository AwsJob#repository}
        */
        readonly repository?: string;
    }
    class SourceControlDetailsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SourceControlDetailsProperty | undefined;
        set internalValue(value: SourceControlDetailsProperty | undefined);
        private _authStrategy?;
        get authStrategy(): string;
        set authStrategy(value: string);
        resetAuthStrategy(): void;
        get authStrategyInput(): string | undefined;
        private _authToken?;
        get authToken(): string;
        set authToken(value: string);
        resetAuthToken(): void;
        get authTokenInput(): string | undefined;
        private _branch?;
        get branch(): string;
        set branch(value: string);
        resetBranch(): void;
        get branchInput(): string | undefined;
        private _folder?;
        get folder(): string;
        set folder(value: string);
        resetFolder(): void;
        get folderInput(): string | undefined;
        private _lastCommitId?;
        get lastCommitId(): string;
        set lastCommitId(value: string);
        resetLastCommitId(): void;
        get lastCommitIdInput(): string | undefined;
        private _owner?;
        get owner(): string;
        set owner(value: string);
        resetOwner(): void;
        get ownerInput(): string | undefined;
        private _provider?;
        get provider(): string;
        set provider(value: string);
        resetProvider(): void;
        get providerInput(): string | undefined;
        private _repository?;
        get repository(): string;
        set repository(value: string);
        resetRepository(): void;
        get repositoryInput(): string | undefined;
    }
}
