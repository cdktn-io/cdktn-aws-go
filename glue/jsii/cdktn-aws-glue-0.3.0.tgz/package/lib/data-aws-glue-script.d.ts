import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsScriptConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/glue_script#id DataAwsScript#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/glue_script#language DataAwsScript#language}
    */
    readonly language?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/glue_script#region DataAwsScript#region}
    */
    readonly region?: string;
    /**
    * dag_edge block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/glue_script#dag_edge DataAwsScript#dag_edge}
    */
    readonly dagEdge: DataAwsScript.DagEdgeProperty[] | cdktn.IResolvable;
    /**
    * dag_node block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/glue_script#dag_node DataAwsScript#dag_node}
    */
    readonly dagNode: DataAwsScript.DagNodeProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/glue_script aws_glue_script}
*/
export declare class DataAwsScript extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_glue_script";
    /**
    * Generates CDKTN code for importing a DataAwsScript resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsScript to import
    * @param importFromId The id of the existing DataAwsScript that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/glue_script#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsScript to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/glue_script aws_glue_script} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsScriptConfig
    */
    constructor(scope: Construct, id: string, config: DataAwsScriptConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _language?;
    get language(): string;
    set language(value: string);
    resetLanguage(): void;
    get languageInput(): string | undefined;
    get pythonScript(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get scalaCode(): string;
    private _dagEdge;
    get dagEdge(): DataAwsScript.DagEdgePropertyList;
    putDagEdge(value: DataAwsScript.DagEdgeProperty[] | cdktn.IResolvable): void;
    get dagEdgeInput(): cdktn.IResolvable | DataAwsScript.DagEdgeProperty[] | undefined;
    private _dagNode;
    get dagNode(): DataAwsScript.DagNodePropertyList;
    putDagNode(value: DataAwsScript.DagNodeProperty[] | cdktn.IResolvable): void;
    get dagNodeInput(): cdktn.IResolvable | DataAwsScript.DagNodeProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataAwsScriptDagEdgePropertyToTerraform(struct?: DataAwsScript.DagEdgeProperty | cdktn.IResolvable): any;
export declare function dataAwsScriptDagEdgePropertyToHclTerraform(struct?: DataAwsScript.DagEdgeProperty | cdktn.IResolvable): any;
export declare function dataAwsScriptArgsPropertyToTerraform(struct?: DataAwsScript.ArgsProperty | cdktn.IResolvable): any;
export declare function dataAwsScriptArgsPropertyToHclTerraform(struct?: DataAwsScript.ArgsProperty | cdktn.IResolvable): any;
export declare function dataAwsScriptDagNodePropertyToTerraform(struct?: DataAwsScript.DagNodeProperty | cdktn.IResolvable): any;
export declare function dataAwsScriptDagNodePropertyToHclTerraform(struct?: DataAwsScript.DagNodeProperty | cdktn.IResolvable): any;
export declare namespace DataAwsScript {
    interface DagEdgeProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/glue_script#source DataAwsScript#source}
        */
        readonly source: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/glue_script#target DataAwsScript#target}
        */
        readonly target: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/glue_script#target_parameter DataAwsScript#target_parameter}
        */
        readonly targetParameter?: string;
    }
    class DagEdgePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DagEdgeProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DagEdgeProperty | cdktn.IResolvable | undefined);
        private _source?;
        get source(): string;
        set source(value: string);
        get sourceInput(): string | undefined;
        private _target?;
        get target(): string;
        set target(value: string);
        get targetInput(): string | undefined;
        private _targetParameter?;
        get targetParameter(): string;
        set targetParameter(value: string);
        resetTargetParameter(): void;
        get targetParameterInput(): string | undefined;
    }
    class DagEdgePropertyList extends cdktn.ComplexList {
        internalValue?: DagEdgeProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DagEdgePropertyOutputReference;
    }
    interface ArgsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/glue_script#name DataAwsScript#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/glue_script#param DataAwsScript#param}
        */
        readonly param?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/glue_script#value DataAwsScript#value}
        */
        readonly value: string;
    }
    class ArgsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ArgsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ArgsProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _param?;
        get param(): boolean | cdktn.IResolvable;
        set param(value: boolean | cdktn.IResolvable);
        resetParam(): void;
        get paramInput(): boolean | cdktn.IResolvable | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class ArgsPropertyList extends cdktn.ComplexList {
        internalValue?: ArgsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ArgsPropertyOutputReference;
    }
    interface DagNodeProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/glue_script#id DataAwsScript#id}
        *
        * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
        * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
        */
        readonly id: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/glue_script#line_number DataAwsScript#line_number}
        */
        readonly lineNumber?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/glue_script#node_type DataAwsScript#node_type}
        */
        readonly nodeType: string;
        /**
        * args block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/glue_script#args DataAwsScript#args}
        */
        readonly args: ArgsProperty[] | cdktn.IResolvable;
    }
    class DagNodePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DagNodeProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DagNodeProperty | cdktn.IResolvable | undefined);
        private _id?;
        get id(): string;
        set id(value: string);
        get idInput(): string | undefined;
        private _lineNumber?;
        get lineNumber(): number;
        set lineNumber(value: number);
        resetLineNumber(): void;
        get lineNumberInput(): number | undefined;
        private _nodeType?;
        get nodeType(): string;
        set nodeType(value: string);
        get nodeTypeInput(): string | undefined;
        private _args;
        get args(): ArgsPropertyList;
        putArgs(value: ArgsProperty[] | cdktn.IResolvable): void;
        get argsInput(): cdktn.IResolvable | ArgsProperty[] | undefined;
    }
    class DagNodePropertyList extends cdktn.ComplexList {
        internalValue?: DagNodeProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DagNodePropertyOutputReference;
    }
}
