import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsDataCatalogEncryptionSettingsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_data_catalog_encryption_settings#catalog_id AwsDataCatalogEncryptionSettings#catalog_id}
    */
    readonly catalogId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_data_catalog_encryption_settings#id AwsDataCatalogEncryptionSettings#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_data_catalog_encryption_settings#region AwsDataCatalogEncryptionSettings#region}
    */
    readonly region?: string;
    /**
    * data_catalog_encryption_settings block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_data_catalog_encryption_settings#data_catalog_encryption_settings AwsDataCatalogEncryptionSettings#data_catalog_encryption_settings}
    */
    readonly dataCatalogEncryptionSettings: AwsDataCatalogEncryptionSettings.DataCatalogEncryptionSettingsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_data_catalog_encryption_settings aws_glue_data_catalog_encryption_settings}
*/
export declare class AwsDataCatalogEncryptionSettings extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_glue_data_catalog_encryption_settings";
    /**
    * Generates CDKTN code for importing a AwsDataCatalogEncryptionSettings resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsDataCatalogEncryptionSettings to import
    * @param importFromId The id of the existing AwsDataCatalogEncryptionSettings that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_data_catalog_encryption_settings#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsDataCatalogEncryptionSettings to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_data_catalog_encryption_settings aws_glue_data_catalog_encryption_settings} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsDataCatalogEncryptionSettingsConfig
    */
    constructor(scope: Construct, id: string, config: AwsDataCatalogEncryptionSettingsConfig);
    private _catalogId?;
    get catalogId(): string;
    set catalogId(value: string);
    resetCatalogId(): void;
    get catalogIdInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _dataCatalogEncryptionSettings;
    get dataCatalogEncryptionSettings(): AwsDataCatalogEncryptionSettings.DataCatalogEncryptionSettingsPropertyOutputReference;
    putDataCatalogEncryptionSettings(value: AwsDataCatalogEncryptionSettings.DataCatalogEncryptionSettingsProperty): void;
    get dataCatalogEncryptionSettingsInput(): AwsDataCatalogEncryptionSettings.DataCatalogEncryptionSettingsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsDataCatalogEncryptionSettingsConnectionPasswordEncryptionPropertyToTerraform(struct?: AwsDataCatalogEncryptionSettings.ConnectionPasswordEncryptionPropertyOutputReference | AwsDataCatalogEncryptionSettings.ConnectionPasswordEncryptionProperty): any;
export declare function awsDataCatalogEncryptionSettingsConnectionPasswordEncryptionPropertyToHclTerraform(struct?: AwsDataCatalogEncryptionSettings.ConnectionPasswordEncryptionPropertyOutputReference | AwsDataCatalogEncryptionSettings.ConnectionPasswordEncryptionProperty): any;
export declare function awsDataCatalogEncryptionSettingsEncryptionAtRestPropertyToTerraform(struct?: AwsDataCatalogEncryptionSettings.EncryptionAtRestPropertyOutputReference | AwsDataCatalogEncryptionSettings.EncryptionAtRestProperty): any;
export declare function awsDataCatalogEncryptionSettingsEncryptionAtRestPropertyToHclTerraform(struct?: AwsDataCatalogEncryptionSettings.EncryptionAtRestPropertyOutputReference | AwsDataCatalogEncryptionSettings.EncryptionAtRestProperty): any;
export declare function awsDataCatalogEncryptionSettingsDataCatalogEncryptionSettingsPropertyToTerraform(struct?: AwsDataCatalogEncryptionSettings.DataCatalogEncryptionSettingsPropertyOutputReference | AwsDataCatalogEncryptionSettings.DataCatalogEncryptionSettingsProperty): any;
export declare function awsDataCatalogEncryptionSettingsDataCatalogEncryptionSettingsPropertyToHclTerraform(struct?: AwsDataCatalogEncryptionSettings.DataCatalogEncryptionSettingsPropertyOutputReference | AwsDataCatalogEncryptionSettings.DataCatalogEncryptionSettingsProperty): any;
export declare namespace AwsDataCatalogEncryptionSettings {
    interface ConnectionPasswordEncryptionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_data_catalog_encryption_settings#aws_kms_key_id AwsDataCatalogEncryptionSettings#aws_kms_key_id}
        */
        readonly awsKmsKeyId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_data_catalog_encryption_settings#return_connection_password_encrypted AwsDataCatalogEncryptionSettings#return_connection_password_encrypted}
        */
        readonly returnConnectionPasswordEncrypted: boolean | cdktn.IResolvable;
    }
    class ConnectionPasswordEncryptionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ConnectionPasswordEncryptionProperty | undefined;
        set internalValue(value: ConnectionPasswordEncryptionProperty | undefined);
        private _awsKmsKeyId?;
        get awsKmsKeyId(): string;
        set awsKmsKeyId(value: string);
        resetAwsKmsKeyId(): void;
        get awsKmsKeyIdInput(): string | undefined;
        private _returnConnectionPasswordEncrypted?;
        get returnConnectionPasswordEncrypted(): boolean | cdktn.IResolvable;
        set returnConnectionPasswordEncrypted(value: boolean | cdktn.IResolvable);
        get returnConnectionPasswordEncryptedInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface EncryptionAtRestProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_data_catalog_encryption_settings#catalog_encryption_mode AwsDataCatalogEncryptionSettings#catalog_encryption_mode}
        */
        readonly catalogEncryptionMode: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_data_catalog_encryption_settings#catalog_encryption_service_role AwsDataCatalogEncryptionSettings#catalog_encryption_service_role}
        */
        readonly catalogEncryptionServiceRole?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_data_catalog_encryption_settings#sse_aws_kms_key_id AwsDataCatalogEncryptionSettings#sse_aws_kms_key_id}
        */
        readonly sseAwsKmsKeyId?: string;
    }
    class EncryptionAtRestPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): EncryptionAtRestProperty | undefined;
        set internalValue(value: EncryptionAtRestProperty | undefined);
        private _catalogEncryptionMode?;
        get catalogEncryptionMode(): string;
        set catalogEncryptionMode(value: string);
        get catalogEncryptionModeInput(): string | undefined;
        private _catalogEncryptionServiceRole?;
        get catalogEncryptionServiceRole(): string;
        set catalogEncryptionServiceRole(value: string);
        resetCatalogEncryptionServiceRole(): void;
        get catalogEncryptionServiceRoleInput(): string | undefined;
        private _sseAwsKmsKeyId?;
        get sseAwsKmsKeyId(): string;
        set sseAwsKmsKeyId(value: string);
        resetSseAwsKmsKeyId(): void;
        get sseAwsKmsKeyIdInput(): string | undefined;
    }
    interface DataCatalogEncryptionSettingsProperty {
        /**
        * connection_password_encryption block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_data_catalog_encryption_settings#connection_password_encryption AwsDataCatalogEncryptionSettings#connection_password_encryption}
        */
        readonly connectionPasswordEncryption: ConnectionPasswordEncryptionProperty;
        /**
        * encryption_at_rest block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glue_data_catalog_encryption_settings#encryption_at_rest AwsDataCatalogEncryptionSettings#encryption_at_rest}
        */
        readonly encryptionAtRest: EncryptionAtRestProperty;
    }
    class DataCatalogEncryptionSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DataCatalogEncryptionSettingsProperty | undefined;
        set internalValue(value: DataCatalogEncryptionSettingsProperty | undefined);
        private _connectionPasswordEncryption;
        get connectionPasswordEncryption(): ConnectionPasswordEncryptionPropertyOutputReference;
        putConnectionPasswordEncryption(value: ConnectionPasswordEncryptionProperty): void;
        get connectionPasswordEncryptionInput(): ConnectionPasswordEncryptionProperty | undefined;
        private _encryptionAtRest;
        get encryptionAtRest(): EncryptionAtRestPropertyOutputReference;
        putEncryptionAtRest(value: EncryptionAtRestProperty): void;
        get encryptionAtRestInput(): EncryptionAtRestProperty | undefined;
    }
}
