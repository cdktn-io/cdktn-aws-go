import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsEc2ClientVpnEndpointConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ec2_client_vpn_endpoint#client_vpn_endpoint_id DataAwsEc2ClientVpnEndpoint#client_vpn_endpoint_id}
    */
    readonly clientVpnEndpointId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ec2_client_vpn_endpoint#id DataAwsEc2ClientVpnEndpoint#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ec2_client_vpn_endpoint#region DataAwsEc2ClientVpnEndpoint#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ec2_client_vpn_endpoint#tags DataAwsEc2ClientVpnEndpoint#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * filter block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ec2_client_vpn_endpoint#filter DataAwsEc2ClientVpnEndpoint#filter}
    */
    readonly filter?: DataAwsEc2ClientVpnEndpoint.FilterProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ec2_client_vpn_endpoint#timeouts DataAwsEc2ClientVpnEndpoint#timeouts}
    */
    readonly timeouts?: DataAwsEc2ClientVpnEndpoint.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ec2_client_vpn_endpoint aws_ec2_client_vpn_endpoint}
*/
export declare class DataAwsEc2ClientVpnEndpoint extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_ec2_client_vpn_endpoint";
    /**
    * Generates CDKTN code for importing a DataAwsEc2ClientVpnEndpoint resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsEc2ClientVpnEndpoint to import
    * @param importFromId The id of the existing DataAwsEc2ClientVpnEndpoint that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ec2_client_vpn_endpoint#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsEc2ClientVpnEndpoint to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ec2_client_vpn_endpoint aws_ec2_client_vpn_endpoint} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsEc2ClientVpnEndpointConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataAwsEc2ClientVpnEndpointConfig);
    get arn(): string;
    private _authenticationOptions;
    get authenticationOptions(): DataAwsEc2ClientVpnEndpoint.AuthenticationOptionsPropertyList;
    get clientCidrBlock(): string;
    private _clientConnectOptions;
    get clientConnectOptions(): DataAwsEc2ClientVpnEndpoint.ClientConnectOptionsPropertyList;
    private _clientLoginBannerOptions;
    get clientLoginBannerOptions(): DataAwsEc2ClientVpnEndpoint.ClientLoginBannerOptionsPropertyList;
    private _clientRouteEnforcementOptions;
    get clientRouteEnforcementOptions(): DataAwsEc2ClientVpnEndpoint.ClientRouteEnforcementOptionsPropertyList;
    private _clientVpnEndpointId?;
    get clientVpnEndpointId(): string;
    set clientVpnEndpointId(value: string);
    resetClientVpnEndpointId(): void;
    get clientVpnEndpointIdInput(): string | undefined;
    private _connectionLogOptions;
    get connectionLogOptions(): DataAwsEc2ClientVpnEndpoint.ConnectionLogOptionsPropertyList;
    get description(): string;
    get dnsName(): string;
    get dnsServers(): string[];
    get endpointIpAddressType(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get securityGroupIds(): string[];
    get selfServicePortal(): string;
    get selfServicePortalUrl(): string;
    get serverCertificateArn(): string;
    get sessionTimeoutHours(): number;
    get splitTunnel(): cdktn.IResolvable;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    get trafficIpAddressType(): string;
    private _transitGatewayConfiguration;
    get transitGatewayConfiguration(): DataAwsEc2ClientVpnEndpoint.TransitGatewayConfigurationPropertyList;
    get transportProtocol(): string;
    get vpcId(): string;
    get vpnPort(): number;
    private _filter;
    get filter(): DataAwsEc2ClientVpnEndpoint.FilterPropertyList;
    putFilter(value: DataAwsEc2ClientVpnEndpoint.FilterProperty[] | cdktn.IResolvable): void;
    resetFilter(): void;
    get filterInput(): cdktn.IResolvable | DataAwsEc2ClientVpnEndpoint.FilterProperty[] | undefined;
    private _timeouts;
    get timeouts(): DataAwsEc2ClientVpnEndpoint.TimeoutsPropertyOutputReference;
    putTimeouts(value: DataAwsEc2ClientVpnEndpoint.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | DataAwsEc2ClientVpnEndpoint.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataAwsEc2ClientVpnEndpointAuthenticationOptionsPropertyToTerraform(struct?: DataAwsEc2ClientVpnEndpoint.AuthenticationOptionsProperty): any;
export declare function dataAwsEc2ClientVpnEndpointAuthenticationOptionsPropertyToHclTerraform(struct?: DataAwsEc2ClientVpnEndpoint.AuthenticationOptionsProperty): any;
export declare function dataAwsEc2ClientVpnEndpointClientConnectOptionsPropertyToTerraform(struct?: DataAwsEc2ClientVpnEndpoint.ClientConnectOptionsProperty): any;
export declare function dataAwsEc2ClientVpnEndpointClientConnectOptionsPropertyToHclTerraform(struct?: DataAwsEc2ClientVpnEndpoint.ClientConnectOptionsProperty): any;
export declare function dataAwsEc2ClientVpnEndpointClientLoginBannerOptionsPropertyToTerraform(struct?: DataAwsEc2ClientVpnEndpoint.ClientLoginBannerOptionsProperty): any;
export declare function dataAwsEc2ClientVpnEndpointClientLoginBannerOptionsPropertyToHclTerraform(struct?: DataAwsEc2ClientVpnEndpoint.ClientLoginBannerOptionsProperty): any;
export declare function dataAwsEc2ClientVpnEndpointClientRouteEnforcementOptionsPropertyToTerraform(struct?: DataAwsEc2ClientVpnEndpoint.ClientRouteEnforcementOptionsProperty): any;
export declare function dataAwsEc2ClientVpnEndpointClientRouteEnforcementOptionsPropertyToHclTerraform(struct?: DataAwsEc2ClientVpnEndpoint.ClientRouteEnforcementOptionsProperty): any;
export declare function dataAwsEc2ClientVpnEndpointConnectionLogOptionsPropertyToTerraform(struct?: DataAwsEc2ClientVpnEndpoint.ConnectionLogOptionsProperty): any;
export declare function dataAwsEc2ClientVpnEndpointConnectionLogOptionsPropertyToHclTerraform(struct?: DataAwsEc2ClientVpnEndpoint.ConnectionLogOptionsProperty): any;
export declare function dataAwsEc2ClientVpnEndpointTransitGatewayConfigurationPropertyToTerraform(struct?: DataAwsEc2ClientVpnEndpoint.TransitGatewayConfigurationProperty): any;
export declare function dataAwsEc2ClientVpnEndpointTransitGatewayConfigurationPropertyToHclTerraform(struct?: DataAwsEc2ClientVpnEndpoint.TransitGatewayConfigurationProperty): any;
export declare function dataAwsEc2ClientVpnEndpointFilterPropertyToTerraform(struct?: DataAwsEc2ClientVpnEndpoint.FilterProperty | cdktn.IResolvable): any;
export declare function dataAwsEc2ClientVpnEndpointFilterPropertyToHclTerraform(struct?: DataAwsEc2ClientVpnEndpoint.FilterProperty | cdktn.IResolvable): any;
export declare function dataAwsEc2ClientVpnEndpointTimeoutsPropertyToTerraform(struct?: DataAwsEc2ClientVpnEndpoint.TimeoutsProperty | cdktn.IResolvable): any;
export declare function dataAwsEc2ClientVpnEndpointTimeoutsPropertyToHclTerraform(struct?: DataAwsEc2ClientVpnEndpoint.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace DataAwsEc2ClientVpnEndpoint {
    interface AuthenticationOptionsProperty {
    }
    class AuthenticationOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AuthenticationOptionsProperty | undefined;
        set internalValue(value: AuthenticationOptionsProperty | undefined);
        get activeDirectoryId(): string;
        get rootCertificateChainArn(): string;
        get samlProviderArn(): string;
        get selfServiceSamlProviderArn(): string;
        get type(): string;
    }
    class AuthenticationOptionsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AuthenticationOptionsPropertyOutputReference;
    }
    interface ClientConnectOptionsProperty {
    }
    class ClientConnectOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ClientConnectOptionsProperty | undefined;
        set internalValue(value: ClientConnectOptionsProperty | undefined);
        get enabled(): cdktn.IResolvable;
        get lambdaFunctionArn(): string;
    }
    class ClientConnectOptionsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ClientConnectOptionsPropertyOutputReference;
    }
    interface ClientLoginBannerOptionsProperty {
    }
    class ClientLoginBannerOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ClientLoginBannerOptionsProperty | undefined;
        set internalValue(value: ClientLoginBannerOptionsProperty | undefined);
        get bannerText(): string;
        get enabled(): cdktn.IResolvable;
    }
    class ClientLoginBannerOptionsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ClientLoginBannerOptionsPropertyOutputReference;
    }
    interface ClientRouteEnforcementOptionsProperty {
    }
    class ClientRouteEnforcementOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ClientRouteEnforcementOptionsProperty | undefined;
        set internalValue(value: ClientRouteEnforcementOptionsProperty | undefined);
        get enforced(): cdktn.IResolvable;
    }
    class ClientRouteEnforcementOptionsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ClientRouteEnforcementOptionsPropertyOutputReference;
    }
    interface ConnectionLogOptionsProperty {
    }
    class ConnectionLogOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ConnectionLogOptionsProperty | undefined;
        set internalValue(value: ConnectionLogOptionsProperty | undefined);
        get cloudwatchLogGroup(): string;
        get cloudwatchLogStream(): string;
        get enabled(): cdktn.IResolvable;
    }
    class ConnectionLogOptionsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ConnectionLogOptionsPropertyOutputReference;
    }
    interface TransitGatewayConfigurationProperty {
    }
    class TransitGatewayConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TransitGatewayConfigurationProperty | undefined;
        set internalValue(value: TransitGatewayConfigurationProperty | undefined);
        get availabilityZoneIds(): string[];
        get availabilityZones(): string[];
        get transitGatewayAttachmentId(): string;
        get transitGatewayId(): string;
    }
    class TransitGatewayConfigurationPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TransitGatewayConfigurationPropertyOutputReference;
    }
    interface FilterProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ec2_client_vpn_endpoint#name DataAwsEc2ClientVpnEndpoint#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ec2_client_vpn_endpoint#values DataAwsEc2ClientVpnEndpoint#values}
        */
        readonly values: string[];
    }
    class FilterPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): FilterProperty | cdktn.IResolvable | undefined;
        set internalValue(value: FilterProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        get valuesInput(): string[] | undefined;
    }
    class FilterPropertyList extends cdktn.ComplexList {
        internalValue?: FilterProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): FilterPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ec2_client_vpn_endpoint#read DataAwsEc2ClientVpnEndpoint#read}
        */
        readonly read?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _read?;
        get read(): string;
        set read(value: string);
        resetRead(): void;
        get readInput(): string | undefined;
    }
}
