import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfEndpointConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_client_vpn_endpoint#client_cidr_block TfEndpoint#client_cidr_block}
    */
    readonly clientCidrBlock?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_client_vpn_endpoint#description TfEndpoint#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_client_vpn_endpoint#disconnect_on_session_timeout TfEndpoint#disconnect_on_session_timeout}
    */
    readonly disconnectOnSessionTimeout?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_client_vpn_endpoint#dns_servers TfEndpoint#dns_servers}
    */
    readonly dnsServers?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_client_vpn_endpoint#endpoint_ip_address_type TfEndpoint#endpoint_ip_address_type}
    */
    readonly endpointIpAddressType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_client_vpn_endpoint#id TfEndpoint#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_client_vpn_endpoint#region TfEndpoint#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_client_vpn_endpoint#security_group_ids TfEndpoint#security_group_ids}
    */
    readonly securityGroupIds?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_client_vpn_endpoint#self_service_portal TfEndpoint#self_service_portal}
    */
    readonly selfServicePortal?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_client_vpn_endpoint#server_certificate_arn TfEndpoint#server_certificate_arn}
    */
    readonly serverCertificateArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_client_vpn_endpoint#session_timeout_hours TfEndpoint#session_timeout_hours}
    */
    readonly sessionTimeoutHours?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_client_vpn_endpoint#split_tunnel TfEndpoint#split_tunnel}
    */
    readonly splitTunnel?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_client_vpn_endpoint#tags TfEndpoint#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_client_vpn_endpoint#tags_all TfEndpoint#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_client_vpn_endpoint#traffic_ip_address_type TfEndpoint#traffic_ip_address_type}
    */
    readonly trafficIpAddressType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_client_vpn_endpoint#transport_protocol TfEndpoint#transport_protocol}
    */
    readonly transportProtocol?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_client_vpn_endpoint#vpc_id TfEndpoint#vpc_id}
    */
    readonly vpcId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_client_vpn_endpoint#vpn_port TfEndpoint#vpn_port}
    */
    readonly vpnPort?: number;
    /**
    * authentication_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_client_vpn_endpoint#authentication_options TfEndpoint#authentication_options}
    */
    readonly authenticationOptions: TfEndpoint.AuthenticationOptionsProperty[] | cdktn.IResolvable;
    /**
    * client_connect_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_client_vpn_endpoint#client_connect_options TfEndpoint#client_connect_options}
    */
    readonly clientConnectOptions?: TfEndpoint.ClientConnectOptionsProperty;
    /**
    * client_login_banner_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_client_vpn_endpoint#client_login_banner_options TfEndpoint#client_login_banner_options}
    */
    readonly clientLoginBannerOptions?: TfEndpoint.ClientLoginBannerOptionsProperty;
    /**
    * client_route_enforcement_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_client_vpn_endpoint#client_route_enforcement_options TfEndpoint#client_route_enforcement_options}
    */
    readonly clientRouteEnforcementOptions?: TfEndpoint.ClientRouteEnforcementOptionsProperty;
    /**
    * connection_log_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_client_vpn_endpoint#connection_log_options TfEndpoint#connection_log_options}
    */
    readonly connectionLogOptions: TfEndpoint.ConnectionLogOptionsProperty;
    /**
    * transit_gateway_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_client_vpn_endpoint#transit_gateway_configuration TfEndpoint#transit_gateway_configuration}
    */
    readonly transitGatewayConfiguration?: TfEndpoint.TransitGatewayConfigurationProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_client_vpn_endpoint aws_ec2_client_vpn_endpoint}
*/
export declare class TfEndpoint extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_ec2_client_vpn_endpoint";
    /**
    * Generates CDKTN code for importing a TfEndpoint resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfEndpoint to import
    * @param importFromId The id of the existing TfEndpoint that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_client_vpn_endpoint#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfEndpoint to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_client_vpn_endpoint aws_ec2_client_vpn_endpoint} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfEndpointConfig
    */
    constructor(scope: Construct, id: string, config: TfEndpointConfig);
    get arn(): string;
    private _clientCidrBlock?;
    get clientCidrBlock(): string;
    set clientCidrBlock(value: string);
    resetClientCidrBlock(): void;
    get clientCidrBlockInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _disconnectOnSessionTimeout?;
    get disconnectOnSessionTimeout(): boolean | cdktn.IResolvable;
    set disconnectOnSessionTimeout(value: boolean | cdktn.IResolvable);
    resetDisconnectOnSessionTimeout(): void;
    get disconnectOnSessionTimeoutInput(): boolean | cdktn.IResolvable | undefined;
    get dnsName(): string;
    private _dnsServers?;
    get dnsServers(): string[];
    set dnsServers(value: string[]);
    resetDnsServers(): void;
    get dnsServersInput(): string[] | undefined;
    private _endpointIpAddressType?;
    get endpointIpAddressType(): string;
    set endpointIpAddressType(value: string);
    resetEndpointIpAddressType(): void;
    get endpointIpAddressTypeInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _securityGroupIds?;
    get securityGroupIds(): string[];
    set securityGroupIds(value: string[]);
    resetSecurityGroupIds(): void;
    get securityGroupIdsInput(): string[] | undefined;
    private _selfServicePortal?;
    get selfServicePortal(): string;
    set selfServicePortal(value: string);
    resetSelfServicePortal(): void;
    get selfServicePortalInput(): string | undefined;
    get selfServicePortalUrl(): string;
    private _serverCertificateArn?;
    get serverCertificateArn(): string;
    set serverCertificateArn(value: string);
    get serverCertificateArnInput(): string | undefined;
    private _sessionTimeoutHours?;
    get sessionTimeoutHours(): number;
    set sessionTimeoutHours(value: number);
    resetSessionTimeoutHours(): void;
    get sessionTimeoutHoursInput(): number | undefined;
    private _splitTunnel?;
    get splitTunnel(): boolean | cdktn.IResolvable;
    set splitTunnel(value: boolean | cdktn.IResolvable);
    resetSplitTunnel(): void;
    get splitTunnelInput(): boolean | cdktn.IResolvable | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _trafficIpAddressType?;
    get trafficIpAddressType(): string;
    set trafficIpAddressType(value: string);
    resetTrafficIpAddressType(): void;
    get trafficIpAddressTypeInput(): string | undefined;
    private _transportProtocol?;
    get transportProtocol(): string;
    set transportProtocol(value: string);
    resetTransportProtocol(): void;
    get transportProtocolInput(): string | undefined;
    private _vpcId?;
    get vpcId(): string;
    set vpcId(value: string);
    resetVpcId(): void;
    get vpcIdInput(): string | undefined;
    private _vpnPort?;
    get vpnPort(): number;
    set vpnPort(value: number);
    resetVpnPort(): void;
    get vpnPortInput(): number | undefined;
    private _authenticationOptions;
    get authenticationOptions(): TfEndpoint.AuthenticationOptionsPropertyList;
    putAuthenticationOptions(value: TfEndpoint.AuthenticationOptionsProperty[] | cdktn.IResolvable): void;
    get authenticationOptionsInput(): cdktn.IResolvable | TfEndpoint.AuthenticationOptionsProperty[] | undefined;
    private _clientConnectOptions;
    get clientConnectOptions(): TfEndpoint.ClientConnectOptionsPropertyOutputReference;
    putClientConnectOptions(value: TfEndpoint.ClientConnectOptionsProperty): void;
    resetClientConnectOptions(): void;
    get clientConnectOptionsInput(): TfEndpoint.ClientConnectOptionsProperty | undefined;
    private _clientLoginBannerOptions;
    get clientLoginBannerOptions(): TfEndpoint.ClientLoginBannerOptionsPropertyOutputReference;
    putClientLoginBannerOptions(value: TfEndpoint.ClientLoginBannerOptionsProperty): void;
    resetClientLoginBannerOptions(): void;
    get clientLoginBannerOptionsInput(): TfEndpoint.ClientLoginBannerOptionsProperty | undefined;
    private _clientRouteEnforcementOptions;
    get clientRouteEnforcementOptions(): TfEndpoint.ClientRouteEnforcementOptionsPropertyOutputReference;
    putClientRouteEnforcementOptions(value: TfEndpoint.ClientRouteEnforcementOptionsProperty): void;
    resetClientRouteEnforcementOptions(): void;
    get clientRouteEnforcementOptionsInput(): TfEndpoint.ClientRouteEnforcementOptionsProperty | undefined;
    private _connectionLogOptions;
    get connectionLogOptions(): TfEndpoint.ConnectionLogOptionsPropertyOutputReference;
    putConnectionLogOptions(value: TfEndpoint.ConnectionLogOptionsProperty): void;
    get connectionLogOptionsInput(): TfEndpoint.ConnectionLogOptionsProperty | undefined;
    private _transitGatewayConfiguration;
    get transitGatewayConfiguration(): TfEndpoint.TransitGatewayConfigurationPropertyOutputReference;
    putTransitGatewayConfiguration(value: TfEndpoint.TransitGatewayConfigurationProperty): void;
    resetTransitGatewayConfiguration(): void;
    get transitGatewayConfigurationInput(): TfEndpoint.TransitGatewayConfigurationProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfEndpointAuthenticationOptionsPropertyToTerraform(struct?: TfEndpoint.AuthenticationOptionsProperty | cdktn.IResolvable): any;
export declare function tfEndpointAuthenticationOptionsPropertyToHclTerraform(struct?: TfEndpoint.AuthenticationOptionsProperty | cdktn.IResolvable): any;
export declare function tfEndpointClientConnectOptionsPropertyToTerraform(struct?: TfEndpoint.ClientConnectOptionsPropertyOutputReference | TfEndpoint.ClientConnectOptionsProperty): any;
export declare function tfEndpointClientConnectOptionsPropertyToHclTerraform(struct?: TfEndpoint.ClientConnectOptionsPropertyOutputReference | TfEndpoint.ClientConnectOptionsProperty): any;
export declare function tfEndpointClientLoginBannerOptionsPropertyToTerraform(struct?: TfEndpoint.ClientLoginBannerOptionsPropertyOutputReference | TfEndpoint.ClientLoginBannerOptionsProperty): any;
export declare function tfEndpointClientLoginBannerOptionsPropertyToHclTerraform(struct?: TfEndpoint.ClientLoginBannerOptionsPropertyOutputReference | TfEndpoint.ClientLoginBannerOptionsProperty): any;
export declare function tfEndpointClientRouteEnforcementOptionsPropertyToTerraform(struct?: TfEndpoint.ClientRouteEnforcementOptionsPropertyOutputReference | TfEndpoint.ClientRouteEnforcementOptionsProperty): any;
export declare function tfEndpointClientRouteEnforcementOptionsPropertyToHclTerraform(struct?: TfEndpoint.ClientRouteEnforcementOptionsPropertyOutputReference | TfEndpoint.ClientRouteEnforcementOptionsProperty): any;
export declare function tfEndpointConnectionLogOptionsPropertyToTerraform(struct?: TfEndpoint.ConnectionLogOptionsPropertyOutputReference | TfEndpoint.ConnectionLogOptionsProperty): any;
export declare function tfEndpointConnectionLogOptionsPropertyToHclTerraform(struct?: TfEndpoint.ConnectionLogOptionsPropertyOutputReference | TfEndpoint.ConnectionLogOptionsProperty): any;
export declare function tfEndpointTransitGatewayConfigurationPropertyToTerraform(struct?: TfEndpoint.TransitGatewayConfigurationPropertyOutputReference | TfEndpoint.TransitGatewayConfigurationProperty): any;
export declare function tfEndpointTransitGatewayConfigurationPropertyToHclTerraform(struct?: TfEndpoint.TransitGatewayConfigurationPropertyOutputReference | TfEndpoint.TransitGatewayConfigurationProperty): any;
export declare namespace TfEndpoint {
    interface AuthenticationOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_client_vpn_endpoint#active_directory_id TfEndpoint#active_directory_id}
        */
        readonly activeDirectoryId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_client_vpn_endpoint#root_certificate_chain_arn TfEndpoint#root_certificate_chain_arn}
        */
        readonly rootCertificateChainArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_client_vpn_endpoint#saml_provider_arn TfEndpoint#saml_provider_arn}
        */
        readonly samlProviderArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_client_vpn_endpoint#self_service_saml_provider_arn TfEndpoint#self_service_saml_provider_arn}
        */
        readonly selfServiceSamlProviderArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_client_vpn_endpoint#type TfEndpoint#type}
        */
        readonly type: string;
    }
    class AuthenticationOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AuthenticationOptionsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: AuthenticationOptionsProperty | cdktn.IResolvable | undefined);
        private _activeDirectoryId?;
        get activeDirectoryId(): string;
        set activeDirectoryId(value: string);
        resetActiveDirectoryId(): void;
        get activeDirectoryIdInput(): string | undefined;
        private _rootCertificateChainArn?;
        get rootCertificateChainArn(): string;
        set rootCertificateChainArn(value: string);
        resetRootCertificateChainArn(): void;
        get rootCertificateChainArnInput(): string | undefined;
        private _samlProviderArn?;
        get samlProviderArn(): string;
        set samlProviderArn(value: string);
        resetSamlProviderArn(): void;
        get samlProviderArnInput(): string | undefined;
        private _selfServiceSamlProviderArn?;
        get selfServiceSamlProviderArn(): string;
        set selfServiceSamlProviderArn(value: string);
        resetSelfServiceSamlProviderArn(): void;
        get selfServiceSamlProviderArnInput(): string | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
    }
    class AuthenticationOptionsPropertyList extends cdktn.ComplexList {
        internalValue?: AuthenticationOptionsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AuthenticationOptionsPropertyOutputReference;
    }
    interface ClientConnectOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_client_vpn_endpoint#enabled TfEndpoint#enabled}
        */
        readonly enabled?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_client_vpn_endpoint#lambda_function_arn TfEndpoint#lambda_function_arn}
        */
        readonly lambdaFunctionArn?: string;
    }
    class ClientConnectOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ClientConnectOptionsProperty | undefined;
        set internalValue(value: ClientConnectOptionsProperty | undefined);
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        resetEnabled(): void;
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
        private _lambdaFunctionArn?;
        get lambdaFunctionArn(): string;
        set lambdaFunctionArn(value: string);
        resetLambdaFunctionArn(): void;
        get lambdaFunctionArnInput(): string | undefined;
    }
    interface ClientLoginBannerOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_client_vpn_endpoint#banner_text TfEndpoint#banner_text}
        */
        readonly bannerText?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_client_vpn_endpoint#enabled TfEndpoint#enabled}
        */
        readonly enabled?: boolean | cdktn.IResolvable;
    }
    class ClientLoginBannerOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ClientLoginBannerOptionsProperty | undefined;
        set internalValue(value: ClientLoginBannerOptionsProperty | undefined);
        private _bannerText?;
        get bannerText(): string;
        set bannerText(value: string);
        resetBannerText(): void;
        get bannerTextInput(): string | undefined;
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        resetEnabled(): void;
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface ClientRouteEnforcementOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_client_vpn_endpoint#enforced TfEndpoint#enforced}
        */
        readonly enforced?: boolean | cdktn.IResolvable;
    }
    class ClientRouteEnforcementOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ClientRouteEnforcementOptionsProperty | undefined;
        set internalValue(value: ClientRouteEnforcementOptionsProperty | undefined);
        private _enforced?;
        get enforced(): boolean | cdktn.IResolvable;
        set enforced(value: boolean | cdktn.IResolvable);
        resetEnforced(): void;
        get enforcedInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface ConnectionLogOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_client_vpn_endpoint#cloudwatch_log_group TfEndpoint#cloudwatch_log_group}
        */
        readonly cloudwatchLogGroup?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_client_vpn_endpoint#cloudwatch_log_stream TfEndpoint#cloudwatch_log_stream}
        */
        readonly cloudwatchLogStream?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_client_vpn_endpoint#enabled TfEndpoint#enabled}
        */
        readonly enabled: boolean | cdktn.IResolvable;
    }
    class ConnectionLogOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ConnectionLogOptionsProperty | undefined;
        set internalValue(value: ConnectionLogOptionsProperty | undefined);
        private _cloudwatchLogGroup?;
        get cloudwatchLogGroup(): string;
        set cloudwatchLogGroup(value: string);
        resetCloudwatchLogGroup(): void;
        get cloudwatchLogGroupInput(): string | undefined;
        private _cloudwatchLogStream?;
        get cloudwatchLogStream(): string;
        set cloudwatchLogStream(value: string);
        resetCloudwatchLogStream(): void;
        get cloudwatchLogStreamInput(): string | undefined;
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface TransitGatewayConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_client_vpn_endpoint#availability_zone_ids TfEndpoint#availability_zone_ids}
        */
        readonly availabilityZoneIds?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_client_vpn_endpoint#availability_zones TfEndpoint#availability_zones}
        */
        readonly availabilityZones?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_client_vpn_endpoint#transit_gateway_id TfEndpoint#transit_gateway_id}
        */
        readonly transitGatewayId?: string;
    }
    class TransitGatewayConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TransitGatewayConfigurationProperty | undefined;
        set internalValue(value: TransitGatewayConfigurationProperty | undefined);
        private _availabilityZoneIds?;
        get availabilityZoneIds(): string[];
        set availabilityZoneIds(value: string[]);
        resetAvailabilityZoneIds(): void;
        get availabilityZoneIdsInput(): string[] | undefined;
        private _availabilityZones?;
        get availabilityZones(): string[];
        set availabilityZones(value: string[]);
        resetAvailabilityZones(): void;
        get availabilityZonesInput(): string[] | undefined;
        get transitGatewayAttachmentId(): string;
        private _transitGatewayId?;
        get transitGatewayId(): string;
        set transitGatewayId(value: string);
        resetTransitGatewayId(): void;
        get transitGatewayIdInput(): string | undefined;
    }
}
