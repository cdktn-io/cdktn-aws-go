import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsDistributionConfig extends cdktn.TerraformMetaArguments {
    /**
    * The bundle ID to use for the distribution.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lightsail_distribution#bundle_id AwsDistribution#bundle_id}
    */
    readonly bundleId: string;
    /**
    * The name of the SSL/TLS certificate attached to the distribution, if any.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lightsail_distribution#certificate_name AwsDistribution#certificate_name}
    */
    readonly certificateName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lightsail_distribution#id AwsDistribution#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The IP address type of the distribution.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lightsail_distribution#ip_address_type AwsDistribution#ip_address_type}
    */
    readonly ipAddressType?: string;
    /**
    * Indicates whether the distribution is enabled.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lightsail_distribution#is_enabled AwsDistribution#is_enabled}
    */
    readonly isEnabled?: boolean | cdktn.IResolvable;
    /**
    * The name of the distribution.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lightsail_distribution#name AwsDistribution#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lightsail_distribution#region AwsDistribution#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lightsail_distribution#tags AwsDistribution#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lightsail_distribution#tags_all AwsDistribution#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * cache_behavior block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lightsail_distribution#cache_behavior AwsDistribution#cache_behavior}
    */
    readonly cacheBehavior?: AwsDistribution.CacheBehaviorProperty[] | cdktn.IResolvable;
    /**
    * cache_behavior_settings block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lightsail_distribution#cache_behavior_settings AwsDistribution#cache_behavior_settings}
    */
    readonly cacheBehaviorSettings?: AwsDistribution.CacheBehaviorSettingsProperty;
    /**
    * default_cache_behavior block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lightsail_distribution#default_cache_behavior AwsDistribution#default_cache_behavior}
    */
    readonly defaultCacheBehavior: AwsDistribution.DefaultCacheBehaviorProperty;
    /**
    * origin block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lightsail_distribution#origin AwsDistribution#origin}
    */
    readonly origin: AwsDistribution.OriginProperty;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lightsail_distribution#timeouts AwsDistribution#timeouts}
    */
    readonly timeouts?: AwsDistribution.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lightsail_distribution aws_lightsail_distribution}
*/
export declare class AwsDistribution extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_lightsail_distribution";
    /**
    * Generates CDKTN code for importing a AwsDistribution resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsDistribution to import
    * @param importFromId The id of the existing AwsDistribution that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lightsail_distribution#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsDistribution to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lightsail_distribution aws_lightsail_distribution} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsDistributionConfig
    */
    constructor(scope: Construct, id: string, config: AwsDistributionConfig);
    get alternativeDomainNames(): string[];
    get arn(): string;
    private _bundleId?;
    get bundleId(): string;
    set bundleId(value: string);
    get bundleIdInput(): string | undefined;
    private _certificateName?;
    get certificateName(): string;
    set certificateName(value: string);
    resetCertificateName(): void;
    get certificateNameInput(): string | undefined;
    get createdAt(): string;
    get domainName(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _ipAddressType?;
    get ipAddressType(): string;
    set ipAddressType(value: string);
    resetIpAddressType(): void;
    get ipAddressTypeInput(): string | undefined;
    private _isEnabled?;
    get isEnabled(): boolean | cdktn.IResolvable;
    set isEnabled(value: boolean | cdktn.IResolvable);
    resetIsEnabled(): void;
    get isEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _location;
    get location(): AwsDistribution.LocationPropertyList;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get originPublicDns(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get resourceType(): string;
    get status(): string;
    get supportCode(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _cacheBehavior;
    get cacheBehavior(): AwsDistribution.CacheBehaviorPropertyList;
    putCacheBehavior(value: AwsDistribution.CacheBehaviorProperty[] | cdktn.IResolvable): void;
    resetCacheBehavior(): void;
    get cacheBehaviorInput(): cdktn.IResolvable | AwsDistribution.CacheBehaviorProperty[] | undefined;
    private _cacheBehaviorSettings;
    get cacheBehaviorSettings(): AwsDistribution.CacheBehaviorSettingsPropertyOutputReference;
    putCacheBehaviorSettings(value: AwsDistribution.CacheBehaviorSettingsProperty): void;
    resetCacheBehaviorSettings(): void;
    get cacheBehaviorSettingsInput(): AwsDistribution.CacheBehaviorSettingsProperty | undefined;
    private _defaultCacheBehavior;
    get defaultCacheBehavior(): AwsDistribution.DefaultCacheBehaviorPropertyOutputReference;
    putDefaultCacheBehavior(value: AwsDistribution.DefaultCacheBehaviorProperty): void;
    get defaultCacheBehaviorInput(): AwsDistribution.DefaultCacheBehaviorProperty | undefined;
    private _origin;
    get origin(): AwsDistribution.OriginPropertyOutputReference;
    putOrigin(value: AwsDistribution.OriginProperty): void;
    get originInput(): AwsDistribution.OriginProperty | undefined;
    private _timeouts;
    get timeouts(): AwsDistribution.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsDistribution.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsDistribution.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsDistributionLocationPropertyToTerraform(struct?: AwsDistribution.LocationProperty): any;
export declare function awsDistributionLocationPropertyToHclTerraform(struct?: AwsDistribution.LocationProperty): any;
export declare function awsDistributionCacheBehaviorPropertyToTerraform(struct?: AwsDistribution.CacheBehaviorProperty | cdktn.IResolvable): any;
export declare function awsDistributionCacheBehaviorPropertyToHclTerraform(struct?: AwsDistribution.CacheBehaviorProperty | cdktn.IResolvable): any;
export declare function awsDistributionForwardedCookiesPropertyToTerraform(struct?: AwsDistribution.ForwardedCookiesPropertyOutputReference | AwsDistribution.ForwardedCookiesProperty): any;
export declare function awsDistributionForwardedCookiesPropertyToHclTerraform(struct?: AwsDistribution.ForwardedCookiesPropertyOutputReference | AwsDistribution.ForwardedCookiesProperty): any;
export declare function awsDistributionForwardedHeadersPropertyToTerraform(struct?: AwsDistribution.ForwardedHeadersPropertyOutputReference | AwsDistribution.ForwardedHeadersProperty): any;
export declare function awsDistributionForwardedHeadersPropertyToHclTerraform(struct?: AwsDistribution.ForwardedHeadersPropertyOutputReference | AwsDistribution.ForwardedHeadersProperty): any;
export declare function awsDistributionForwardedQueryStringsPropertyToTerraform(struct?: AwsDistribution.ForwardedQueryStringsPropertyOutputReference | AwsDistribution.ForwardedQueryStringsProperty): any;
export declare function awsDistributionForwardedQueryStringsPropertyToHclTerraform(struct?: AwsDistribution.ForwardedQueryStringsPropertyOutputReference | AwsDistribution.ForwardedQueryStringsProperty): any;
export declare function awsDistributionCacheBehaviorSettingsPropertyToTerraform(struct?: AwsDistribution.CacheBehaviorSettingsPropertyOutputReference | AwsDistribution.CacheBehaviorSettingsProperty): any;
export declare function awsDistributionCacheBehaviorSettingsPropertyToHclTerraform(struct?: AwsDistribution.CacheBehaviorSettingsPropertyOutputReference | AwsDistribution.CacheBehaviorSettingsProperty): any;
export declare function awsDistributionDefaultCacheBehaviorPropertyToTerraform(struct?: AwsDistribution.DefaultCacheBehaviorPropertyOutputReference | AwsDistribution.DefaultCacheBehaviorProperty): any;
export declare function awsDistributionDefaultCacheBehaviorPropertyToHclTerraform(struct?: AwsDistribution.DefaultCacheBehaviorPropertyOutputReference | AwsDistribution.DefaultCacheBehaviorProperty): any;
export declare function awsDistributionOriginPropertyToTerraform(struct?: AwsDistribution.OriginPropertyOutputReference | AwsDistribution.OriginProperty): any;
export declare function awsDistributionOriginPropertyToHclTerraform(struct?: AwsDistribution.OriginPropertyOutputReference | AwsDistribution.OriginProperty): any;
export declare function awsDistributionTimeoutsPropertyToTerraform(struct?: AwsDistribution.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsDistributionTimeoutsPropertyToHclTerraform(struct?: AwsDistribution.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsDistribution {
    interface LocationProperty {
    }
    class LocationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): LocationProperty | undefined;
        set internalValue(value: LocationProperty | undefined);
        get availabilityZone(): string;
        get regionName(): string;
    }
    class LocationPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): LocationPropertyOutputReference;
    }
    interface CacheBehaviorProperty {
        /**
        * The cache behavior for the specified path.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lightsail_distribution#behavior AwsDistribution#behavior}
        */
        readonly behavior: string;
        /**
        * The path to a directory or file to cached, or not cache. Use an asterisk symbol to specify wildcard directories (path/to/assets/*), and file types (*.html, *jpg, *js). Directories and file paths are case-sensitive.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lightsail_distribution#path AwsDistribution#path}
        */
        readonly path: string;
    }
    class CacheBehaviorPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CacheBehaviorProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CacheBehaviorProperty | cdktn.IResolvable | undefined);
        private _behavior?;
        get behavior(): string;
        set behavior(value: string);
        get behaviorInput(): string | undefined;
        private _path?;
        get path(): string;
        set path(value: string);
        get pathInput(): string | undefined;
    }
    class CacheBehaviorPropertyList extends cdktn.ComplexList {
        internalValue?: CacheBehaviorProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CacheBehaviorPropertyOutputReference;
    }
    interface ForwardedCookiesProperty {
        /**
        * The specific cookies to forward to your distribution's origin.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lightsail_distribution#cookies_allow_list AwsDistribution#cookies_allow_list}
        */
        readonly cookiesAllowList?: string[];
        /**
        * Specifies which cookies to forward to the distribution's origin for a cache behavior: all, none, or allow-list to forward only the cookies specified in the cookiesAllowList parameter.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lightsail_distribution#option AwsDistribution#option}
        */
        readonly option?: string;
    }
    class ForwardedCookiesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ForwardedCookiesProperty | undefined;
        set internalValue(value: ForwardedCookiesProperty | undefined);
        private _cookiesAllowList?;
        get cookiesAllowList(): string[];
        set cookiesAllowList(value: string[]);
        resetCookiesAllowList(): void;
        get cookiesAllowListInput(): string[] | undefined;
        private _option?;
        get option(): string;
        set option(value: string);
        resetOption(): void;
        get optionInput(): string | undefined;
    }
    interface ForwardedHeadersProperty {
        /**
        * The specific headers to forward to your distribution's origin.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lightsail_distribution#headers_allow_list AwsDistribution#headers_allow_list}
        */
        readonly headersAllowList?: string[];
        /**
        * The headers that you want your distribution to forward to your origin and base caching on.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lightsail_distribution#option AwsDistribution#option}
        */
        readonly option?: string;
    }
    class ForwardedHeadersPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ForwardedHeadersProperty | undefined;
        set internalValue(value: ForwardedHeadersProperty | undefined);
        private _headersAllowList?;
        get headersAllowList(): string[];
        set headersAllowList(value: string[]);
        resetHeadersAllowList(): void;
        get headersAllowListInput(): string[] | undefined;
        private _option?;
        get option(): string;
        set option(value: string);
        resetOption(): void;
        get optionInput(): string | undefined;
    }
    interface ForwardedQueryStringsProperty {
        /**
        * Indicates whether the distribution forwards and caches based on query strings.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lightsail_distribution#option AwsDistribution#option}
        */
        readonly option?: boolean | cdktn.IResolvable;
        /**
        * The specific query strings that the distribution forwards to the origin.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lightsail_distribution#query_strings_allowed_list AwsDistribution#query_strings_allowed_list}
        */
        readonly queryStringsAllowedList?: string[];
    }
    class ForwardedQueryStringsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ForwardedQueryStringsProperty | undefined;
        set internalValue(value: ForwardedQueryStringsProperty | undefined);
        private _option?;
        get option(): boolean | cdktn.IResolvable;
        set option(value: boolean | cdktn.IResolvable);
        resetOption(): void;
        get optionInput(): boolean | cdktn.IResolvable | undefined;
        private _queryStringsAllowedList?;
        get queryStringsAllowedList(): string[];
        set queryStringsAllowedList(value: string[]);
        resetQueryStringsAllowedList(): void;
        get queryStringsAllowedListInput(): string[] | undefined;
    }
    interface CacheBehaviorSettingsProperty {
        /**
        * The HTTP methods that are processed and forwarded to the distribution's origin.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lightsail_distribution#allowed_http_methods AwsDistribution#allowed_http_methods}
        */
        readonly allowedHttpMethods?: string;
        /**
        * The HTTP method responses that are cached by your distribution.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lightsail_distribution#cached_http_methods AwsDistribution#cached_http_methods}
        */
        readonly cachedHttpMethods?: string;
        /**
        * The default amount of time that objects stay in the distribution's cache before the distribution forwards another request to the origin to determine whether the content has been updated.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lightsail_distribution#default_ttl AwsDistribution#default_ttl}
        */
        readonly defaultTtl?: number;
        /**
        * The maximum amount of time that objects stay in the distribution's cache before the distribution forwards another request to the origin to determine whether the object has been updated.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lightsail_distribution#maximum_ttl AwsDistribution#maximum_ttl}
        */
        readonly maximumTtl?: number;
        /**
        * The minimum amount of time that objects stay in the distribution's cache before the distribution forwards another request to the origin to determine whether the object has been updated.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lightsail_distribution#minimum_ttl AwsDistribution#minimum_ttl}
        */
        readonly minimumTtl?: number;
        /**
        * forwarded_cookies block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lightsail_distribution#forwarded_cookies AwsDistribution#forwarded_cookies}
        */
        readonly forwardedCookies?: ForwardedCookiesProperty;
        /**
        * forwarded_headers block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lightsail_distribution#forwarded_headers AwsDistribution#forwarded_headers}
        */
        readonly forwardedHeaders?: ForwardedHeadersProperty;
        /**
        * forwarded_query_strings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lightsail_distribution#forwarded_query_strings AwsDistribution#forwarded_query_strings}
        */
        readonly forwardedQueryStrings?: ForwardedQueryStringsProperty;
    }
    class CacheBehaviorSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CacheBehaviorSettingsProperty | undefined;
        set internalValue(value: CacheBehaviorSettingsProperty | undefined);
        private _allowedHttpMethods?;
        get allowedHttpMethods(): string;
        set allowedHttpMethods(value: string);
        resetAllowedHttpMethods(): void;
        get allowedHttpMethodsInput(): string | undefined;
        private _cachedHttpMethods?;
        get cachedHttpMethods(): string;
        set cachedHttpMethods(value: string);
        resetCachedHttpMethods(): void;
        get cachedHttpMethodsInput(): string | undefined;
        private _defaultTtl?;
        get defaultTtl(): number;
        set defaultTtl(value: number);
        resetDefaultTtl(): void;
        get defaultTtlInput(): number | undefined;
        private _maximumTtl?;
        get maximumTtl(): number;
        set maximumTtl(value: number);
        resetMaximumTtl(): void;
        get maximumTtlInput(): number | undefined;
        private _minimumTtl?;
        get minimumTtl(): number;
        set minimumTtl(value: number);
        resetMinimumTtl(): void;
        get minimumTtlInput(): number | undefined;
        private _forwardedCookies;
        get forwardedCookies(): ForwardedCookiesPropertyOutputReference;
        putForwardedCookies(value: ForwardedCookiesProperty): void;
        resetForwardedCookies(): void;
        get forwardedCookiesInput(): ForwardedCookiesProperty | undefined;
        private _forwardedHeaders;
        get forwardedHeaders(): ForwardedHeadersPropertyOutputReference;
        putForwardedHeaders(value: ForwardedHeadersProperty): void;
        resetForwardedHeaders(): void;
        get forwardedHeadersInput(): ForwardedHeadersProperty | undefined;
        private _forwardedQueryStrings;
        get forwardedQueryStrings(): ForwardedQueryStringsPropertyOutputReference;
        putForwardedQueryStrings(value: ForwardedQueryStringsProperty): void;
        resetForwardedQueryStrings(): void;
        get forwardedQueryStringsInput(): ForwardedQueryStringsProperty | undefined;
    }
    interface DefaultCacheBehaviorProperty {
        /**
        * The cache behavior of the distribution.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lightsail_distribution#behavior AwsDistribution#behavior}
        */
        readonly behavior: string;
    }
    class DefaultCacheBehaviorPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DefaultCacheBehaviorProperty | undefined;
        set internalValue(value: DefaultCacheBehaviorProperty | undefined);
        private _behavior?;
        get behavior(): string;
        set behavior(value: string);
        get behaviorInput(): string | undefined;
    }
    interface OriginProperty {
        /**
        * The name of the origin resource.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lightsail_distribution#name AwsDistribution#name}
        */
        readonly name: string;
        /**
        * The protocol that your Amazon Lightsail distribution uses when establishing a connection with your origin to pull content.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lightsail_distribution#protocol_policy AwsDistribution#protocol_policy}
        */
        readonly protocolPolicy?: string;
        /**
        * The AWS Region name of the origin resource.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lightsail_distribution#region_name AwsDistribution#region_name}
        */
        readonly regionName: string;
    }
    class OriginPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): OriginProperty | undefined;
        set internalValue(value: OriginProperty | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _protocolPolicy?;
        get protocolPolicy(): string;
        set protocolPolicy(value: string);
        resetProtocolPolicy(): void;
        get protocolPolicyInput(): string | undefined;
        private _regionName?;
        get regionName(): string;
        set regionName(value: string);
        get regionNameInput(): string | undefined;
        get resourceType(): string;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lightsail_distribution#create AwsDistribution#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lightsail_distribution#delete AwsDistribution#delete}
        */
        readonly delete?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lightsail_distribution#update AwsDistribution#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
