import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsInstancePublicPortsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lightsail_instance_public_ports#id AwsInstancePublicPorts#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lightsail_instance_public_ports#instance_name AwsInstancePublicPorts#instance_name}
    */
    readonly instanceName: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lightsail_instance_public_ports#region AwsInstancePublicPorts#region}
    */
    readonly region?: string;
    /**
    * port_info block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lightsail_instance_public_ports#port_info AwsInstancePublicPorts#port_info}
    */
    readonly portInfo: AwsInstancePublicPorts.PortInfoProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lightsail_instance_public_ports aws_lightsail_instance_public_ports}
*/
export declare class AwsInstancePublicPorts extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_lightsail_instance_public_ports";
    /**
    * Generates CDKTN code for importing a AwsInstancePublicPorts resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsInstancePublicPorts to import
    * @param importFromId The id of the existing AwsInstancePublicPorts that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lightsail_instance_public_ports#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsInstancePublicPorts to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lightsail_instance_public_ports aws_lightsail_instance_public_ports} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsInstancePublicPortsConfig
    */
    constructor(scope: Construct, id: string, config: AwsInstancePublicPortsConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _instanceName?;
    get instanceName(): string;
    set instanceName(value: string);
    get instanceNameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _portInfo;
    get portInfo(): AwsInstancePublicPorts.PortInfoPropertyList;
    putPortInfo(value: AwsInstancePublicPorts.PortInfoProperty[] | cdktn.IResolvable): void;
    get portInfoInput(): cdktn.IResolvable | AwsInstancePublicPorts.PortInfoProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsInstancePublicPortsPortInfoPropertyToTerraform(struct?: AwsInstancePublicPorts.PortInfoProperty | cdktn.IResolvable): any;
export declare function awsInstancePublicPortsPortInfoPropertyToHclTerraform(struct?: AwsInstancePublicPorts.PortInfoProperty | cdktn.IResolvable): any;
export declare namespace AwsInstancePublicPorts {
    interface PortInfoProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lightsail_instance_public_ports#cidr_list_aliases AwsInstancePublicPorts#cidr_list_aliases}
        */
        readonly cidrListAliases?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lightsail_instance_public_ports#cidrs AwsInstancePublicPorts#cidrs}
        */
        readonly cidrs?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lightsail_instance_public_ports#from_port AwsInstancePublicPorts#from_port}
        */
        readonly fromPort: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lightsail_instance_public_ports#ipv6_cidrs AwsInstancePublicPorts#ipv6_cidrs}
        */
        readonly ipv6Cidrs?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lightsail_instance_public_ports#protocol AwsInstancePublicPorts#protocol}
        */
        readonly protocol: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lightsail_instance_public_ports#to_port AwsInstancePublicPorts#to_port}
        */
        readonly toPort: number;
    }
    class PortInfoPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): PortInfoProperty | cdktn.IResolvable | undefined;
        set internalValue(value: PortInfoProperty | cdktn.IResolvable | undefined);
        private _cidrListAliases?;
        get cidrListAliases(): string[];
        set cidrListAliases(value: string[]);
        resetCidrListAliases(): void;
        get cidrListAliasesInput(): string[] | undefined;
        private _cidrs?;
        get cidrs(): string[];
        set cidrs(value: string[]);
        resetCidrs(): void;
        get cidrsInput(): string[] | undefined;
        private _fromPort?;
        get fromPort(): number;
        set fromPort(value: number);
        get fromPortInput(): number | undefined;
        private _ipv6Cidrs?;
        get ipv6Cidrs(): string[];
        set ipv6Cidrs(value: string[]);
        resetIpv6Cidrs(): void;
        get ipv6CidrsInput(): string[] | undefined;
        private _protocol?;
        get protocol(): string;
        set protocol(value: string);
        get protocolInput(): string | undefined;
        private _toPort?;
        get toPort(): number;
        set toPort(value: number);
        get toPortInput(): number | undefined;
    }
    class PortInfoPropertyList extends cdktn.ComplexList {
        internalValue?: PortInfoProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): PortInfoPropertyOutputReference;
    }
}
