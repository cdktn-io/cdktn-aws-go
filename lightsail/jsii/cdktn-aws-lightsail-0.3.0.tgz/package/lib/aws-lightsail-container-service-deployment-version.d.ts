import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsContainerServiceDeploymentVersionConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lightsail_container_service_deployment_version#id AwsContainerServiceDeploymentVersion#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lightsail_container_service_deployment_version#region AwsContainerServiceDeploymentVersion#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lightsail_container_service_deployment_version#service_name AwsContainerServiceDeploymentVersion#service_name}
    */
    readonly serviceName: string;
    /**
    * container block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lightsail_container_service_deployment_version#container AwsContainerServiceDeploymentVersion#container}
    */
    readonly container: AwsContainerServiceDeploymentVersion.ContainerProperty[] | cdktn.IResolvable;
    /**
    * public_endpoint block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lightsail_container_service_deployment_version#public_endpoint AwsContainerServiceDeploymentVersion#public_endpoint}
    */
    readonly publicEndpoint?: AwsContainerServiceDeploymentVersion.PublicEndpointProperty;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lightsail_container_service_deployment_version#timeouts AwsContainerServiceDeploymentVersion#timeouts}
    */
    readonly timeouts?: AwsContainerServiceDeploymentVersion.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lightsail_container_service_deployment_version aws_lightsail_container_service_deployment_version}
*/
export declare class AwsContainerServiceDeploymentVersion extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_lightsail_container_service_deployment_version";
    /**
    * Generates CDKTN code for importing a AwsContainerServiceDeploymentVersion resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsContainerServiceDeploymentVersion to import
    * @param importFromId The id of the existing AwsContainerServiceDeploymentVersion that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lightsail_container_service_deployment_version#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsContainerServiceDeploymentVersion to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lightsail_container_service_deployment_version aws_lightsail_container_service_deployment_version} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsContainerServiceDeploymentVersionConfig
    */
    constructor(scope: Construct, id: string, config: AwsContainerServiceDeploymentVersionConfig);
    get createdAt(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _serviceName?;
    get serviceName(): string;
    set serviceName(value: string);
    get serviceNameInput(): string | undefined;
    get state(): string;
    get version(): number;
    private _container;
    get container(): AwsContainerServiceDeploymentVersion.ContainerPropertyList;
    putContainer(value: AwsContainerServiceDeploymentVersion.ContainerProperty[] | cdktn.IResolvable): void;
    get containerInput(): cdktn.IResolvable | AwsContainerServiceDeploymentVersion.ContainerProperty[] | undefined;
    private _publicEndpoint;
    get publicEndpoint(): AwsContainerServiceDeploymentVersion.PublicEndpointPropertyOutputReference;
    putPublicEndpoint(value: AwsContainerServiceDeploymentVersion.PublicEndpointProperty): void;
    resetPublicEndpoint(): void;
    get publicEndpointInput(): AwsContainerServiceDeploymentVersion.PublicEndpointProperty | undefined;
    private _timeouts;
    get timeouts(): AwsContainerServiceDeploymentVersion.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsContainerServiceDeploymentVersion.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsContainerServiceDeploymentVersion.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsContainerServiceDeploymentVersionContainerPropertyToTerraform(struct?: AwsContainerServiceDeploymentVersion.ContainerProperty | cdktn.IResolvable): any;
export declare function awsContainerServiceDeploymentVersionContainerPropertyToHclTerraform(struct?: AwsContainerServiceDeploymentVersion.ContainerProperty | cdktn.IResolvable): any;
export declare function awsContainerServiceDeploymentVersionHealthCheckPropertyToTerraform(struct?: AwsContainerServiceDeploymentVersion.HealthCheckPropertyOutputReference | AwsContainerServiceDeploymentVersion.HealthCheckProperty): any;
export declare function awsContainerServiceDeploymentVersionHealthCheckPropertyToHclTerraform(struct?: AwsContainerServiceDeploymentVersion.HealthCheckPropertyOutputReference | AwsContainerServiceDeploymentVersion.HealthCheckProperty): any;
export declare function awsContainerServiceDeploymentVersionPublicEndpointPropertyToTerraform(struct?: AwsContainerServiceDeploymentVersion.PublicEndpointPropertyOutputReference | AwsContainerServiceDeploymentVersion.PublicEndpointProperty): any;
export declare function awsContainerServiceDeploymentVersionPublicEndpointPropertyToHclTerraform(struct?: AwsContainerServiceDeploymentVersion.PublicEndpointPropertyOutputReference | AwsContainerServiceDeploymentVersion.PublicEndpointProperty): any;
export declare function awsContainerServiceDeploymentVersionTimeoutsPropertyToTerraform(struct?: AwsContainerServiceDeploymentVersion.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsContainerServiceDeploymentVersionTimeoutsPropertyToHclTerraform(struct?: AwsContainerServiceDeploymentVersion.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsContainerServiceDeploymentVersion {
    interface ContainerProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lightsail_container_service_deployment_version#command AwsContainerServiceDeploymentVersion#command}
        */
        readonly command?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lightsail_container_service_deployment_version#container_name AwsContainerServiceDeploymentVersion#container_name}
        */
        readonly containerName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lightsail_container_service_deployment_version#environment AwsContainerServiceDeploymentVersion#environment}
        */
        readonly environment?: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lightsail_container_service_deployment_version#image AwsContainerServiceDeploymentVersion#image}
        */
        readonly image: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lightsail_container_service_deployment_version#ports AwsContainerServiceDeploymentVersion#ports}
        */
        readonly ports?: {
            [key: string]: string;
        };
    }
    class ContainerPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ContainerProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ContainerProperty | cdktn.IResolvable | undefined);
        private _command?;
        get command(): string[];
        set command(value: string[]);
        resetCommand(): void;
        get commandInput(): string[] | undefined;
        private _containerName?;
        get containerName(): string;
        set containerName(value: string);
        get containerNameInput(): string | undefined;
        private _environment?;
        get environment(): {
            [key: string]: string;
        };
        set environment(value: {
            [key: string]: string;
        });
        resetEnvironment(): void;
        get environmentInput(): {
            [key: string]: string;
        } | undefined;
        private _image?;
        get image(): string;
        set image(value: string);
        get imageInput(): string | undefined;
        private _ports?;
        get ports(): {
            [key: string]: string;
        };
        set ports(value: {
            [key: string]: string;
        });
        resetPorts(): void;
        get portsInput(): {
            [key: string]: string;
        } | undefined;
    }
    class ContainerPropertyList extends cdktn.ComplexList {
        internalValue?: ContainerProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ContainerPropertyOutputReference;
    }
    interface HealthCheckProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lightsail_container_service_deployment_version#healthy_threshold AwsContainerServiceDeploymentVersion#healthy_threshold}
        */
        readonly healthyThreshold?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lightsail_container_service_deployment_version#interval_seconds AwsContainerServiceDeploymentVersion#interval_seconds}
        */
        readonly intervalSeconds?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lightsail_container_service_deployment_version#path AwsContainerServiceDeploymentVersion#path}
        */
        readonly path?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lightsail_container_service_deployment_version#success_codes AwsContainerServiceDeploymentVersion#success_codes}
        */
        readonly successCodes?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lightsail_container_service_deployment_version#timeout_seconds AwsContainerServiceDeploymentVersion#timeout_seconds}
        */
        readonly timeoutSeconds?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lightsail_container_service_deployment_version#unhealthy_threshold AwsContainerServiceDeploymentVersion#unhealthy_threshold}
        */
        readonly unhealthyThreshold?: number;
    }
    class HealthCheckPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): HealthCheckProperty | undefined;
        set internalValue(value: HealthCheckProperty | undefined);
        private _healthyThreshold?;
        get healthyThreshold(): number;
        set healthyThreshold(value: number);
        resetHealthyThreshold(): void;
        get healthyThresholdInput(): number | undefined;
        private _intervalSeconds?;
        get intervalSeconds(): number;
        set intervalSeconds(value: number);
        resetIntervalSeconds(): void;
        get intervalSecondsInput(): number | undefined;
        private _path?;
        get path(): string;
        set path(value: string);
        resetPath(): void;
        get pathInput(): string | undefined;
        private _successCodes?;
        get successCodes(): string;
        set successCodes(value: string);
        resetSuccessCodes(): void;
        get successCodesInput(): string | undefined;
        private _timeoutSeconds?;
        get timeoutSeconds(): number;
        set timeoutSeconds(value: number);
        resetTimeoutSeconds(): void;
        get timeoutSecondsInput(): number | undefined;
        private _unhealthyThreshold?;
        get unhealthyThreshold(): number;
        set unhealthyThreshold(value: number);
        resetUnhealthyThreshold(): void;
        get unhealthyThresholdInput(): number | undefined;
    }
    interface PublicEndpointProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lightsail_container_service_deployment_version#container_name AwsContainerServiceDeploymentVersion#container_name}
        */
        readonly containerName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lightsail_container_service_deployment_version#container_port AwsContainerServiceDeploymentVersion#container_port}
        */
        readonly containerPort: number;
        /**
        * health_check block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lightsail_container_service_deployment_version#health_check AwsContainerServiceDeploymentVersion#health_check}
        */
        readonly healthCheck: HealthCheckProperty;
    }
    class PublicEndpointPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): PublicEndpointProperty | undefined;
        set internalValue(value: PublicEndpointProperty | undefined);
        private _containerName?;
        get containerName(): string;
        set containerName(value: string);
        get containerNameInput(): string | undefined;
        private _containerPort?;
        get containerPort(): number;
        set containerPort(value: number);
        get containerPortInput(): number | undefined;
        private _healthCheck;
        get healthCheck(): HealthCheckPropertyOutputReference;
        putHealthCheck(value: HealthCheckProperty): void;
        get healthCheckInput(): HealthCheckProperty | undefined;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lightsail_container_service_deployment_version#create AwsContainerServiceDeploymentVersion#create}
        */
        readonly create?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
    }
}
