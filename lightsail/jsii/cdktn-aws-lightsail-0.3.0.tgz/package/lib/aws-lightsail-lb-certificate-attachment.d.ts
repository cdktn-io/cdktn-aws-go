import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsLbCertificateAttachmentConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lightsail_lb_certificate_attachment#certificate_name AwsLbCertificateAttachment#certificate_name}
    */
    readonly certificateName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lightsail_lb_certificate_attachment#id AwsLbCertificateAttachment#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lightsail_lb_certificate_attachment#lb_name AwsLbCertificateAttachment#lb_name}
    */
    readonly lbName: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lightsail_lb_certificate_attachment#region AwsLbCertificateAttachment#region}
    */
    readonly region?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lightsail_lb_certificate_attachment aws_lightsail_lb_certificate_attachment}
*/
export declare class AwsLbCertificateAttachment extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_lightsail_lb_certificate_attachment";
    /**
    * Generates CDKTN code for importing a AwsLbCertificateAttachment resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsLbCertificateAttachment to import
    * @param importFromId The id of the existing AwsLbCertificateAttachment that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lightsail_lb_certificate_attachment#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsLbCertificateAttachment to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lightsail_lb_certificate_attachment aws_lightsail_lb_certificate_attachment} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsLbCertificateAttachmentConfig
    */
    constructor(scope: Construct, id: string, config: AwsLbCertificateAttachmentConfig);
    private _certificateName?;
    get certificateName(): string;
    set certificateName(value: string);
    get certificateNameInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _lbName?;
    get lbName(): string;
    set lbName(value: string);
    get lbNameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
