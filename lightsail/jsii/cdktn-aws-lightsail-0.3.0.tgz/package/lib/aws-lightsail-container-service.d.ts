import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsContainerServiceConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lightsail_container_service#id AwsContainerService#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lightsail_container_service#is_disabled AwsContainerService#is_disabled}
    */
    readonly isDisabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lightsail_container_service#name AwsContainerService#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lightsail_container_service#power AwsContainerService#power}
    */
    readonly power: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lightsail_container_service#region AwsContainerService#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lightsail_container_service#scale AwsContainerService#scale}
    */
    readonly scale: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lightsail_container_service#tags AwsContainerService#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lightsail_container_service#tags_all AwsContainerService#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * private_registry_access block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lightsail_container_service#private_registry_access AwsContainerService#private_registry_access}
    */
    readonly privateRegistryAccess?: AwsContainerService.PrivateRegistryAccessProperty;
    /**
    * public_domain_names block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lightsail_container_service#public_domain_names AwsContainerService#public_domain_names}
    */
    readonly publicDomainNames?: AwsContainerService.PublicDomainNamesProperty;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lightsail_container_service#timeouts AwsContainerService#timeouts}
    */
    readonly timeouts?: AwsContainerService.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lightsail_container_service aws_lightsail_container_service}
*/
export declare class AwsContainerService extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_lightsail_container_service";
    /**
    * Generates CDKTN code for importing a AwsContainerService resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsContainerService to import
    * @param importFromId The id of the existing AwsContainerService that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lightsail_container_service#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsContainerService to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lightsail_container_service aws_lightsail_container_service} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsContainerServiceConfig
    */
    constructor(scope: Construct, id: string, config: AwsContainerServiceConfig);
    get arn(): string;
    get availabilityZone(): string;
    get createdAt(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _isDisabled?;
    get isDisabled(): boolean | cdktn.IResolvable;
    set isDisabled(value: boolean | cdktn.IResolvable);
    resetIsDisabled(): void;
    get isDisabledInput(): boolean | cdktn.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _power?;
    get power(): string;
    set power(value: string);
    get powerInput(): string | undefined;
    get powerId(): string;
    get principalArn(): string;
    get privateDomainName(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get resourceType(): string;
    private _scale?;
    get scale(): number;
    set scale(value: number);
    get scaleInput(): number | undefined;
    get state(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    get url(): string;
    private _privateRegistryAccess;
    get privateRegistryAccess(): AwsContainerService.PrivateRegistryAccessPropertyOutputReference;
    putPrivateRegistryAccess(value: AwsContainerService.PrivateRegistryAccessProperty): void;
    resetPrivateRegistryAccess(): void;
    get privateRegistryAccessInput(): AwsContainerService.PrivateRegistryAccessProperty | undefined;
    private _publicDomainNames;
    get publicDomainNames(): AwsContainerService.PublicDomainNamesPropertyOutputReference;
    putPublicDomainNames(value: AwsContainerService.PublicDomainNamesProperty): void;
    resetPublicDomainNames(): void;
    get publicDomainNamesInput(): AwsContainerService.PublicDomainNamesProperty | undefined;
    private _timeouts;
    get timeouts(): AwsContainerService.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsContainerService.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsContainerService.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsContainerServiceEcrImagePullerRolePropertyToTerraform(struct?: AwsContainerService.EcrImagePullerRolePropertyOutputReference | AwsContainerService.EcrImagePullerRoleProperty): any;
export declare function awsContainerServiceEcrImagePullerRolePropertyToHclTerraform(struct?: AwsContainerService.EcrImagePullerRolePropertyOutputReference | AwsContainerService.EcrImagePullerRoleProperty): any;
export declare function awsContainerServicePrivateRegistryAccessPropertyToTerraform(struct?: AwsContainerService.PrivateRegistryAccessPropertyOutputReference | AwsContainerService.PrivateRegistryAccessProperty): any;
export declare function awsContainerServicePrivateRegistryAccessPropertyToHclTerraform(struct?: AwsContainerService.PrivateRegistryAccessPropertyOutputReference | AwsContainerService.PrivateRegistryAccessProperty): any;
export declare function awsContainerServiceCertificatePropertyToTerraform(struct?: AwsContainerService.CertificateProperty | cdktn.IResolvable): any;
export declare function awsContainerServiceCertificatePropertyToHclTerraform(struct?: AwsContainerService.CertificateProperty | cdktn.IResolvable): any;
export declare function awsContainerServicePublicDomainNamesPropertyToTerraform(struct?: AwsContainerService.PublicDomainNamesPropertyOutputReference | AwsContainerService.PublicDomainNamesProperty): any;
export declare function awsContainerServicePublicDomainNamesPropertyToHclTerraform(struct?: AwsContainerService.PublicDomainNamesPropertyOutputReference | AwsContainerService.PublicDomainNamesProperty): any;
export declare function awsContainerServiceTimeoutsPropertyToTerraform(struct?: AwsContainerService.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsContainerServiceTimeoutsPropertyToHclTerraform(struct?: AwsContainerService.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsContainerService {
    interface EcrImagePullerRoleProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lightsail_container_service#is_active AwsContainerService#is_active}
        */
        readonly isActive?: boolean | cdktn.IResolvable;
    }
    class EcrImagePullerRolePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): EcrImagePullerRoleProperty | undefined;
        set internalValue(value: EcrImagePullerRoleProperty | undefined);
        private _isActive?;
        get isActive(): boolean | cdktn.IResolvable;
        set isActive(value: boolean | cdktn.IResolvable);
        resetIsActive(): void;
        get isActiveInput(): boolean | cdktn.IResolvable | undefined;
        get principalArn(): string;
    }
    interface PrivateRegistryAccessProperty {
        /**
        * ecr_image_puller_role block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lightsail_container_service#ecr_image_puller_role AwsContainerService#ecr_image_puller_role}
        */
        readonly ecrImagePullerRole?: EcrImagePullerRoleProperty;
    }
    class PrivateRegistryAccessPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): PrivateRegistryAccessProperty | undefined;
        set internalValue(value: PrivateRegistryAccessProperty | undefined);
        private _ecrImagePullerRole;
        get ecrImagePullerRole(): EcrImagePullerRolePropertyOutputReference;
        putEcrImagePullerRole(value: EcrImagePullerRoleProperty): void;
        resetEcrImagePullerRole(): void;
        get ecrImagePullerRoleInput(): EcrImagePullerRoleProperty | undefined;
    }
    interface CertificateProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lightsail_container_service#certificate_name AwsContainerService#certificate_name}
        */
        readonly certificateName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lightsail_container_service#domain_names AwsContainerService#domain_names}
        */
        readonly domainNames: string[];
    }
    class CertificatePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CertificateProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CertificateProperty | cdktn.IResolvable | undefined);
        private _certificateName?;
        get certificateName(): string;
        set certificateName(value: string);
        get certificateNameInput(): string | undefined;
        private _domainNames?;
        get domainNames(): string[];
        set domainNames(value: string[]);
        get domainNamesInput(): string[] | undefined;
    }
    class CertificatePropertyList extends cdktn.ComplexList {
        internalValue?: CertificateProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CertificatePropertyOutputReference;
    }
    interface PublicDomainNamesProperty {
        /**
        * certificate block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lightsail_container_service#certificate AwsContainerService#certificate}
        */
        readonly certificate: CertificateProperty[] | cdktn.IResolvable;
    }
    class PublicDomainNamesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): PublicDomainNamesProperty | undefined;
        set internalValue(value: PublicDomainNamesProperty | undefined);
        private _certificate;
        get certificate(): CertificatePropertyList;
        putCertificate(value: CertificateProperty[] | cdktn.IResolvable): void;
        get certificateInput(): cdktn.IResolvable | CertificateProperty[] | undefined;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lightsail_container_service#create AwsContainerService#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lightsail_container_service#delete AwsContainerService#delete}
        */
        readonly delete?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lightsail_container_service#update AwsContainerService#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
