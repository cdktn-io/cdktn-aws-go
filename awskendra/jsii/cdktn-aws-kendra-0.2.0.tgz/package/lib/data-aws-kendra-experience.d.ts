import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataTfExperienceConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/kendra_experience#experience_id DataTfExperience#experience_id}
    */
    readonly experienceId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/kendra_experience#id DataTfExperience#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/kendra_experience#index_id DataTfExperience#index_id}
    */
    readonly indexId: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/kendra_experience#region DataTfExperience#region}
    */
    readonly region?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/kendra_experience aws_kendra_experience}
*/
export declare class DataTfExperience extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_kendra_experience";
    /**
    * Generates CDKTN code for importing a DataTfExperience resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataTfExperience to import
    * @param importFromId The id of the existing DataTfExperience that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/kendra_experience#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataTfExperience to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/kendra_experience aws_kendra_experience} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataTfExperienceConfig
    */
    constructor(scope: Construct, id: string, config: DataTfExperienceConfig);
    get arn(): string;
    private _configuration;
    get configuration(): DataTfExperience.ConfigurationPropertyList;
    get createdAt(): string;
    get description(): string;
    private _endpoints;
    get endpoints(): DataTfExperience.EndpointsPropertyList;
    get errorMessage(): string;
    private _experienceId?;
    get experienceId(): string;
    set experienceId(value: string);
    get experienceIdInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _indexId?;
    get indexId(): string;
    set indexId(value: string);
    get indexIdInput(): string | undefined;
    get name(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get roleArn(): string;
    get status(): string;
    get updatedAt(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataTfExperienceContentSourceConfigurationPropertyToTerraform(struct?: DataTfExperience.ContentSourceConfigurationProperty): any;
export declare function dataTfExperienceContentSourceConfigurationPropertyToHclTerraform(struct?: DataTfExperience.ContentSourceConfigurationProperty): any;
export declare function dataTfExperienceUserIdentityConfigurationPropertyToTerraform(struct?: DataTfExperience.UserIdentityConfigurationProperty): any;
export declare function dataTfExperienceUserIdentityConfigurationPropertyToHclTerraform(struct?: DataTfExperience.UserIdentityConfigurationProperty): any;
export declare function dataTfExperienceConfigurationPropertyToTerraform(struct?: DataTfExperience.ConfigurationProperty): any;
export declare function dataTfExperienceConfigurationPropertyToHclTerraform(struct?: DataTfExperience.ConfigurationProperty): any;
export declare function dataTfExperienceEndpointsPropertyToTerraform(struct?: DataTfExperience.EndpointsProperty): any;
export declare function dataTfExperienceEndpointsPropertyToHclTerraform(struct?: DataTfExperience.EndpointsProperty): any;
export declare namespace DataTfExperience {
    interface ContentSourceConfigurationProperty {
    }
    class ContentSourceConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ContentSourceConfigurationProperty | undefined;
        set internalValue(value: ContentSourceConfigurationProperty | undefined);
        get dataSourceIds(): string[];
        get directPutContent(): cdktn.IResolvable;
        get faqIds(): string[];
    }
    class ContentSourceConfigurationPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ContentSourceConfigurationPropertyOutputReference;
    }
    interface UserIdentityConfigurationProperty {
    }
    class UserIdentityConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): UserIdentityConfigurationProperty | undefined;
        set internalValue(value: UserIdentityConfigurationProperty | undefined);
        get identityAttributeName(): string;
    }
    class UserIdentityConfigurationPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): UserIdentityConfigurationPropertyOutputReference;
    }
    interface ConfigurationProperty {
    }
    class ConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ConfigurationProperty | undefined;
        set internalValue(value: ConfigurationProperty | undefined);
        private _contentSourceConfiguration;
        get contentSourceConfiguration(): ContentSourceConfigurationPropertyList;
        private _userIdentityConfiguration;
        get userIdentityConfiguration(): UserIdentityConfigurationPropertyList;
    }
    class ConfigurationPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ConfigurationPropertyOutputReference;
    }
    interface EndpointsProperty {
    }
    class EndpointsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EndpointsProperty | undefined;
        set internalValue(value: EndpointsProperty | undefined);
        get endpoint(): string;
        get endpointType(): string;
    }
    class EndpointsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EndpointsPropertyOutputReference;
    }
}
