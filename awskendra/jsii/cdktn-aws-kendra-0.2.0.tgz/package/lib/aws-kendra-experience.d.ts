import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfExperienceConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_experience#description TfExperience#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_experience#id TfExperience#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_experience#index_id TfExperience#index_id}
    */
    readonly indexId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_experience#name TfExperience#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_experience#region TfExperience#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_experience#role_arn TfExperience#role_arn}
    */
    readonly roleArn: string;
    /**
    * configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_experience#configuration TfExperience#configuration}
    */
    readonly configuration?: TfExperience.ConfigurationProperty;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_experience#timeouts TfExperience#timeouts}
    */
    readonly timeouts?: TfExperience.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_experience aws_kendra_experience}
*/
export declare class TfExperience extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_kendra_experience";
    /**
    * Generates CDKTN code for importing a TfExperience resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfExperience to import
    * @param importFromId The id of the existing TfExperience that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_experience#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfExperience to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_experience aws_kendra_experience} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfExperienceConfig
    */
    constructor(scope: Construct, id: string, config: TfExperienceConfig);
    get arn(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _endpoints;
    get endpoints(): TfExperience.EndpointsPropertyList;
    get experienceId(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _indexId?;
    get indexId(): string;
    set indexId(value: string);
    get indexIdInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _roleArn?;
    get roleArn(): string;
    set roleArn(value: string);
    get roleArnInput(): string | undefined;
    get status(): string;
    private _configuration;
    get configuration(): TfExperience.ConfigurationPropertyOutputReference;
    putConfiguration(value: TfExperience.ConfigurationProperty): void;
    resetConfiguration(): void;
    get configurationInput(): TfExperience.ConfigurationProperty | undefined;
    private _timeouts;
    get timeouts(): TfExperience.TimeoutsPropertyOutputReference;
    putTimeouts(value: TfExperience.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | TfExperience.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfExperienceEndpointsPropertyToTerraform(struct?: TfExperience.EndpointsProperty): any;
export declare function tfExperienceEndpointsPropertyToHclTerraform(struct?: TfExperience.EndpointsProperty): any;
export declare function tfExperienceContentSourceConfigurationPropertyToTerraform(struct?: TfExperience.ContentSourceConfigurationPropertyOutputReference | TfExperience.ContentSourceConfigurationProperty): any;
export declare function tfExperienceContentSourceConfigurationPropertyToHclTerraform(struct?: TfExperience.ContentSourceConfigurationPropertyOutputReference | TfExperience.ContentSourceConfigurationProperty): any;
export declare function tfExperienceUserIdentityConfigurationPropertyToTerraform(struct?: TfExperience.UserIdentityConfigurationPropertyOutputReference | TfExperience.UserIdentityConfigurationProperty): any;
export declare function tfExperienceUserIdentityConfigurationPropertyToHclTerraform(struct?: TfExperience.UserIdentityConfigurationPropertyOutputReference | TfExperience.UserIdentityConfigurationProperty): any;
export declare function tfExperienceConfigurationPropertyToTerraform(struct?: TfExperience.ConfigurationPropertyOutputReference | TfExperience.ConfigurationProperty): any;
export declare function tfExperienceConfigurationPropertyToHclTerraform(struct?: TfExperience.ConfigurationPropertyOutputReference | TfExperience.ConfigurationProperty): any;
export declare function tfExperienceTimeoutsPropertyToTerraform(struct?: TfExperience.TimeoutsProperty | cdktn.IResolvable): any;
export declare function tfExperienceTimeoutsPropertyToHclTerraform(struct?: TfExperience.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace TfExperience {
    interface EndpointsProperty {
    }
    class EndpointsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EndpointsProperty | undefined;
        set internalValue(value: EndpointsProperty | undefined);
        get endpoint(): string;
        get endpointType(): string;
    }
    class EndpointsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EndpointsPropertyOutputReference;
    }
    interface ContentSourceConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_experience#data_source_ids TfExperience#data_source_ids}
        */
        readonly dataSourceIds?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_experience#direct_put_content TfExperience#direct_put_content}
        */
        readonly directPutContent?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_experience#faq_ids TfExperience#faq_ids}
        */
        readonly faqIds?: string[];
    }
    class ContentSourceConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ContentSourceConfigurationProperty | undefined;
        set internalValue(value: ContentSourceConfigurationProperty | undefined);
        private _dataSourceIds?;
        get dataSourceIds(): string[];
        set dataSourceIds(value: string[]);
        resetDataSourceIds(): void;
        get dataSourceIdsInput(): string[] | undefined;
        private _directPutContent?;
        get directPutContent(): boolean | cdktn.IResolvable;
        set directPutContent(value: boolean | cdktn.IResolvable);
        resetDirectPutContent(): void;
        get directPutContentInput(): boolean | cdktn.IResolvable | undefined;
        private _faqIds?;
        get faqIds(): string[];
        set faqIds(value: string[]);
        resetFaqIds(): void;
        get faqIdsInput(): string[] | undefined;
    }
    interface UserIdentityConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_experience#identity_attribute_name TfExperience#identity_attribute_name}
        */
        readonly identityAttributeName: string;
    }
    class UserIdentityConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): UserIdentityConfigurationProperty | undefined;
        set internalValue(value: UserIdentityConfigurationProperty | undefined);
        private _identityAttributeName?;
        get identityAttributeName(): string;
        set identityAttributeName(value: string);
        get identityAttributeNameInput(): string | undefined;
    }
    interface ConfigurationProperty {
        /**
        * content_source_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_experience#content_source_configuration TfExperience#content_source_configuration}
        */
        readonly contentSourceConfiguration?: ContentSourceConfigurationProperty;
        /**
        * user_identity_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_experience#user_identity_configuration TfExperience#user_identity_configuration}
        */
        readonly userIdentityConfiguration?: UserIdentityConfigurationProperty;
    }
    class ConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ConfigurationProperty | undefined;
        set internalValue(value: ConfigurationProperty | undefined);
        private _contentSourceConfiguration;
        get contentSourceConfiguration(): ContentSourceConfigurationPropertyOutputReference;
        putContentSourceConfiguration(value: ContentSourceConfigurationProperty): void;
        resetContentSourceConfiguration(): void;
        get contentSourceConfigurationInput(): ContentSourceConfigurationProperty | undefined;
        private _userIdentityConfiguration;
        get userIdentityConfiguration(): UserIdentityConfigurationPropertyOutputReference;
        putUserIdentityConfiguration(value: UserIdentityConfigurationProperty): void;
        resetUserIdentityConfiguration(): void;
        get userIdentityConfigurationInput(): UserIdentityConfigurationProperty | undefined;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_experience#create TfExperience#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_experience#delete TfExperience#delete}
        */
        readonly delete?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_experience#update TfExperience#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
