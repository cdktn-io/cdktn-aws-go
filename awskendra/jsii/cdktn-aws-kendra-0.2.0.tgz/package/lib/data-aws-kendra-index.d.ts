import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataTfIndexConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/kendra_index#id DataTfIndex#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/kendra_index#region DataTfIndex#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/kendra_index#tags DataTfIndex#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/kendra_index aws_kendra_index}
*/
export declare class DataTfIndex extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_kendra_index";
    /**
    * Generates CDKTN code for importing a DataTfIndex resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataTfIndex to import
    * @param importFromId The id of the existing DataTfIndex that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/kendra_index#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataTfIndex to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/kendra_index aws_kendra_index} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataTfIndexConfig
    */
    constructor(scope: Construct, id: string, config: DataTfIndexConfig);
    get arn(): string;
    private _capacityUnits;
    get capacityUnits(): DataTfIndex.CapacityUnitsPropertyList;
    get createdAt(): string;
    get description(): string;
    private _documentMetadataConfigurationUpdates;
    get documentMetadataConfigurationUpdates(): DataTfIndex.DocumentMetadataConfigurationUpdatesPropertyList;
    get edition(): string;
    get errorMessage(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    private _indexStatistics;
    get indexStatistics(): DataTfIndex.IndexStatisticsPropertyList;
    get name(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get roleArn(): string;
    private _serverSideEncryptionConfiguration;
    get serverSideEncryptionConfiguration(): DataTfIndex.ServerSideEncryptionConfigurationPropertyList;
    get status(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    get updatedAt(): string;
    get userContextPolicy(): string;
    private _userGroupResolutionConfiguration;
    get userGroupResolutionConfiguration(): DataTfIndex.UserGroupResolutionConfigurationPropertyList;
    private _userTokenConfigurations;
    get userTokenConfigurations(): DataTfIndex.UserTokenConfigurationsPropertyList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataTfIndexCapacityUnitsPropertyToTerraform(struct?: DataTfIndex.CapacityUnitsProperty): any;
export declare function dataTfIndexCapacityUnitsPropertyToHclTerraform(struct?: DataTfIndex.CapacityUnitsProperty): any;
export declare function dataTfIndexRelevancePropertyToTerraform(struct?: DataTfIndex.RelevanceProperty): any;
export declare function dataTfIndexRelevancePropertyToHclTerraform(struct?: DataTfIndex.RelevanceProperty): any;
export declare function dataTfIndexSearchPropertyToTerraform(struct?: DataTfIndex.SearchProperty): any;
export declare function dataTfIndexSearchPropertyToHclTerraform(struct?: DataTfIndex.SearchProperty): any;
export declare function dataTfIndexDocumentMetadataConfigurationUpdatesPropertyToTerraform(struct?: DataTfIndex.DocumentMetadataConfigurationUpdatesProperty): any;
export declare function dataTfIndexDocumentMetadataConfigurationUpdatesPropertyToHclTerraform(struct?: DataTfIndex.DocumentMetadataConfigurationUpdatesProperty): any;
export declare function dataTfIndexFaqStatisticsPropertyToTerraform(struct?: DataTfIndex.FaqStatisticsProperty): any;
export declare function dataTfIndexFaqStatisticsPropertyToHclTerraform(struct?: DataTfIndex.FaqStatisticsProperty): any;
export declare function dataTfIndexTextDocumentStatisticsPropertyToTerraform(struct?: DataTfIndex.TextDocumentStatisticsProperty): any;
export declare function dataTfIndexTextDocumentStatisticsPropertyToHclTerraform(struct?: DataTfIndex.TextDocumentStatisticsProperty): any;
export declare function dataTfIndexIndexStatisticsPropertyToTerraform(struct?: DataTfIndex.IndexStatisticsProperty): any;
export declare function dataTfIndexIndexStatisticsPropertyToHclTerraform(struct?: DataTfIndex.IndexStatisticsProperty): any;
export declare function dataTfIndexServerSideEncryptionConfigurationPropertyToTerraform(struct?: DataTfIndex.ServerSideEncryptionConfigurationProperty): any;
export declare function dataTfIndexServerSideEncryptionConfigurationPropertyToHclTerraform(struct?: DataTfIndex.ServerSideEncryptionConfigurationProperty): any;
export declare function dataTfIndexUserGroupResolutionConfigurationPropertyToTerraform(struct?: DataTfIndex.UserGroupResolutionConfigurationProperty): any;
export declare function dataTfIndexUserGroupResolutionConfigurationPropertyToHclTerraform(struct?: DataTfIndex.UserGroupResolutionConfigurationProperty): any;
export declare function dataTfIndexJsonTokenTypeConfigurationPropertyToTerraform(struct?: DataTfIndex.JsonTokenTypeConfigurationProperty): any;
export declare function dataTfIndexJsonTokenTypeConfigurationPropertyToHclTerraform(struct?: DataTfIndex.JsonTokenTypeConfigurationProperty): any;
export declare function dataTfIndexJwtTokenTypeConfigurationPropertyToTerraform(struct?: DataTfIndex.JwtTokenTypeConfigurationProperty): any;
export declare function dataTfIndexJwtTokenTypeConfigurationPropertyToHclTerraform(struct?: DataTfIndex.JwtTokenTypeConfigurationProperty): any;
export declare function dataTfIndexUserTokenConfigurationsPropertyToTerraform(struct?: DataTfIndex.UserTokenConfigurationsProperty): any;
export declare function dataTfIndexUserTokenConfigurationsPropertyToHclTerraform(struct?: DataTfIndex.UserTokenConfigurationsProperty): any;
export declare namespace DataTfIndex {
    interface CapacityUnitsProperty {
    }
    class CapacityUnitsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CapacityUnitsProperty | undefined;
        set internalValue(value: CapacityUnitsProperty | undefined);
        get queryCapacityUnits(): number;
        get storageCapacityUnits(): number;
    }
    class CapacityUnitsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CapacityUnitsPropertyOutputReference;
    }
    interface RelevanceProperty {
    }
    class RelevancePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RelevanceProperty | undefined;
        set internalValue(value: RelevanceProperty | undefined);
        get duration(): string;
        get freshness(): cdktn.IResolvable;
        get importance(): number;
        get rankOrder(): string;
        private _valuesImportanceMap;
        get valuesImportanceMap(): cdktn.NumberMap;
    }
    class RelevancePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RelevancePropertyOutputReference;
    }
    interface SearchProperty {
    }
    class SearchPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SearchProperty | undefined;
        set internalValue(value: SearchProperty | undefined);
        get displayable(): cdktn.IResolvable;
        get facetable(): cdktn.IResolvable;
        get searchable(): cdktn.IResolvable;
        get sortable(): cdktn.IResolvable;
    }
    class SearchPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SearchPropertyOutputReference;
    }
    interface DocumentMetadataConfigurationUpdatesProperty {
    }
    class DocumentMetadataConfigurationUpdatesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DocumentMetadataConfigurationUpdatesProperty | undefined;
        set internalValue(value: DocumentMetadataConfigurationUpdatesProperty | undefined);
        get name(): string;
        private _relevance;
        get relevance(): RelevancePropertyList;
        private _search;
        get search(): SearchPropertyList;
        get type(): string;
    }
    class DocumentMetadataConfigurationUpdatesPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DocumentMetadataConfigurationUpdatesPropertyOutputReference;
    }
    interface FaqStatisticsProperty {
    }
    class FaqStatisticsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): FaqStatisticsProperty | undefined;
        set internalValue(value: FaqStatisticsProperty | undefined);
        get indexedQuestionAnswersCount(): number;
    }
    class FaqStatisticsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): FaqStatisticsPropertyOutputReference;
    }
    interface TextDocumentStatisticsProperty {
    }
    class TextDocumentStatisticsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TextDocumentStatisticsProperty | undefined;
        set internalValue(value: TextDocumentStatisticsProperty | undefined);
        get indexedTextBytes(): number;
        get indexedTextDocumentsCount(): number;
    }
    class TextDocumentStatisticsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TextDocumentStatisticsPropertyOutputReference;
    }
    interface IndexStatisticsProperty {
    }
    class IndexStatisticsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): IndexStatisticsProperty | undefined;
        set internalValue(value: IndexStatisticsProperty | undefined);
        private _faqStatistics;
        get faqStatistics(): FaqStatisticsPropertyList;
        private _textDocumentStatistics;
        get textDocumentStatistics(): TextDocumentStatisticsPropertyList;
    }
    class IndexStatisticsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): IndexStatisticsPropertyOutputReference;
    }
    interface ServerSideEncryptionConfigurationProperty {
    }
    class ServerSideEncryptionConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ServerSideEncryptionConfigurationProperty | undefined;
        set internalValue(value: ServerSideEncryptionConfigurationProperty | undefined);
        get kmsKeyId(): string;
    }
    class ServerSideEncryptionConfigurationPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ServerSideEncryptionConfigurationPropertyOutputReference;
    }
    interface UserGroupResolutionConfigurationProperty {
    }
    class UserGroupResolutionConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): UserGroupResolutionConfigurationProperty | undefined;
        set internalValue(value: UserGroupResolutionConfigurationProperty | undefined);
        get userGroupResolutionMode(): string;
    }
    class UserGroupResolutionConfigurationPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): UserGroupResolutionConfigurationPropertyOutputReference;
    }
    interface JsonTokenTypeConfigurationProperty {
    }
    class JsonTokenTypeConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): JsonTokenTypeConfigurationProperty | undefined;
        set internalValue(value: JsonTokenTypeConfigurationProperty | undefined);
        get groupAttributeField(): string;
        get userNameAttributeField(): string;
    }
    class JsonTokenTypeConfigurationPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): JsonTokenTypeConfigurationPropertyOutputReference;
    }
    interface JwtTokenTypeConfigurationProperty {
    }
    class JwtTokenTypeConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): JwtTokenTypeConfigurationProperty | undefined;
        set internalValue(value: JwtTokenTypeConfigurationProperty | undefined);
        get claimRegex(): string;
        get groupAttributeField(): string;
        get issuer(): string;
        get keyLocation(): string;
        get secretsManagerArn(): string;
        get url(): string;
        get userNameAttributeField(): string;
    }
    class JwtTokenTypeConfigurationPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): JwtTokenTypeConfigurationPropertyOutputReference;
    }
    interface UserTokenConfigurationsProperty {
    }
    class UserTokenConfigurationsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): UserTokenConfigurationsProperty | undefined;
        set internalValue(value: UserTokenConfigurationsProperty | undefined);
        private _jsonTokenTypeConfiguration;
        get jsonTokenTypeConfiguration(): JsonTokenTypeConfigurationPropertyList;
        private _jwtTokenTypeConfiguration;
        get jwtTokenTypeConfiguration(): JwtTokenTypeConfigurationPropertyList;
    }
    class UserTokenConfigurationsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): UserTokenConfigurationsPropertyOutputReference;
    }
}
