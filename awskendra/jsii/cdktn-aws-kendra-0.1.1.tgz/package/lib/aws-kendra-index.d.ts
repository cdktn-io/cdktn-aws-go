import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsKendraIndexConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_index#description AwsKendraIndex#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_index#edition AwsKendraIndex#edition}
    */
    readonly edition?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_index#id AwsKendraIndex#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_index#name AwsKendraIndex#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_index#region AwsKendraIndex#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_index#role_arn AwsKendraIndex#role_arn}
    */
    readonly roleArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_index#tags AwsKendraIndex#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_index#tags_all AwsKendraIndex#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_index#user_context_policy AwsKendraIndex#user_context_policy}
    */
    readonly userContextPolicy?: string;
    /**
    * capacity_units block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_index#capacity_units AwsKendraIndex#capacity_units}
    */
    readonly capacityUnits?: AwsKendraIndex.CapacityUnitsProperty;
    /**
    * document_metadata_configuration_updates block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_index#document_metadata_configuration_updates AwsKendraIndex#document_metadata_configuration_updates}
    */
    readonly documentMetadataConfigurationUpdates?: AwsKendraIndex.DocumentMetadataConfigurationUpdatesProperty[] | cdktn.IResolvable;
    /**
    * server_side_encryption_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_index#server_side_encryption_configuration AwsKendraIndex#server_side_encryption_configuration}
    */
    readonly serverSideEncryptionConfiguration?: AwsKendraIndex.ServerSideEncryptionConfigurationProperty;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_index#timeouts AwsKendraIndex#timeouts}
    */
    readonly timeouts?: AwsKendraIndex.TimeoutsProperty;
    /**
    * user_group_resolution_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_index#user_group_resolution_configuration AwsKendraIndex#user_group_resolution_configuration}
    */
    readonly userGroupResolutionConfiguration?: AwsKendraIndex.UserGroupResolutionConfigurationProperty;
    /**
    * user_token_configurations block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_index#user_token_configurations AwsKendraIndex#user_token_configurations}
    */
    readonly userTokenConfigurations?: AwsKendraIndex.UserTokenConfigurationsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_index aws_kendra_index}
*/
export declare class AwsKendraIndex extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_kendra_index";
    /**
    * Generates CDKTN code for importing a AwsKendraIndex resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsKendraIndex to import
    * @param importFromId The id of the existing AwsKendraIndex that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_index#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsKendraIndex to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_index aws_kendra_index} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsKendraIndexConfig
    */
    constructor(scope: Construct, id: string, config: AwsKendraIndexConfig);
    get arn(): string;
    get createdAt(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _edition?;
    get edition(): string;
    set edition(value: string);
    resetEdition(): void;
    get editionInput(): string | undefined;
    get errorMessage(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _indexStatistics;
    get indexStatistics(): AwsKendraIndex.IndexStatisticsPropertyList;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _roleArn?;
    get roleArn(): string;
    set roleArn(value: string);
    get roleArnInput(): string | undefined;
    get status(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    get updatedAt(): string;
    private _userContextPolicy?;
    get userContextPolicy(): string;
    set userContextPolicy(value: string);
    resetUserContextPolicy(): void;
    get userContextPolicyInput(): string | undefined;
    private _capacityUnits;
    get capacityUnits(): AwsKendraIndex.CapacityUnitsPropertyOutputReference;
    putCapacityUnits(value: AwsKendraIndex.CapacityUnitsProperty): void;
    resetCapacityUnits(): void;
    get capacityUnitsInput(): AwsKendraIndex.CapacityUnitsProperty | undefined;
    private _documentMetadataConfigurationUpdates;
    get documentMetadataConfigurationUpdates(): AwsKendraIndex.DocumentMetadataConfigurationUpdatesPropertyList;
    putDocumentMetadataConfigurationUpdates(value: AwsKendraIndex.DocumentMetadataConfigurationUpdatesProperty[] | cdktn.IResolvable): void;
    resetDocumentMetadataConfigurationUpdates(): void;
    get documentMetadataConfigurationUpdatesInput(): cdktn.IResolvable | AwsKendraIndex.DocumentMetadataConfigurationUpdatesProperty[] | undefined;
    private _serverSideEncryptionConfiguration;
    get serverSideEncryptionConfiguration(): AwsKendraIndex.ServerSideEncryptionConfigurationPropertyOutputReference;
    putServerSideEncryptionConfiguration(value: AwsKendraIndex.ServerSideEncryptionConfigurationProperty): void;
    resetServerSideEncryptionConfiguration(): void;
    get serverSideEncryptionConfigurationInput(): AwsKendraIndex.ServerSideEncryptionConfigurationProperty | undefined;
    private _timeouts;
    get timeouts(): AwsKendraIndex.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsKendraIndex.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsKendraIndex.TimeoutsProperty | undefined;
    private _userGroupResolutionConfiguration;
    get userGroupResolutionConfiguration(): AwsKendraIndex.UserGroupResolutionConfigurationPropertyOutputReference;
    putUserGroupResolutionConfiguration(value: AwsKendraIndex.UserGroupResolutionConfigurationProperty): void;
    resetUserGroupResolutionConfiguration(): void;
    get userGroupResolutionConfigurationInput(): AwsKendraIndex.UserGroupResolutionConfigurationProperty | undefined;
    private _userTokenConfigurations;
    get userTokenConfigurations(): AwsKendraIndex.UserTokenConfigurationsPropertyOutputReference;
    putUserTokenConfigurations(value: AwsKendraIndex.UserTokenConfigurationsProperty): void;
    resetUserTokenConfigurations(): void;
    get userTokenConfigurationsInput(): AwsKendraIndex.UserTokenConfigurationsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsKendraIndexFaqStatisticsPropertyToTerraform(struct?: AwsKendraIndex.FaqStatisticsProperty): any;
export declare function awsKendraIndexFaqStatisticsPropertyToHclTerraform(struct?: AwsKendraIndex.FaqStatisticsProperty): any;
export declare function awsKendraIndexTextDocumentStatisticsPropertyToTerraform(struct?: AwsKendraIndex.TextDocumentStatisticsProperty): any;
export declare function awsKendraIndexTextDocumentStatisticsPropertyToHclTerraform(struct?: AwsKendraIndex.TextDocumentStatisticsProperty): any;
export declare function awsKendraIndexIndexStatisticsPropertyToTerraform(struct?: AwsKendraIndex.IndexStatisticsProperty): any;
export declare function awsKendraIndexIndexStatisticsPropertyToHclTerraform(struct?: AwsKendraIndex.IndexStatisticsProperty): any;
export declare function awsKendraIndexCapacityUnitsPropertyToTerraform(struct?: AwsKendraIndex.CapacityUnitsPropertyOutputReference | AwsKendraIndex.CapacityUnitsProperty): any;
export declare function awsKendraIndexCapacityUnitsPropertyToHclTerraform(struct?: AwsKendraIndex.CapacityUnitsPropertyOutputReference | AwsKendraIndex.CapacityUnitsProperty): any;
export declare function awsKendraIndexRelevancePropertyToTerraform(struct?: AwsKendraIndex.RelevancePropertyOutputReference | AwsKendraIndex.RelevanceProperty): any;
export declare function awsKendraIndexRelevancePropertyToHclTerraform(struct?: AwsKendraIndex.RelevancePropertyOutputReference | AwsKendraIndex.RelevanceProperty): any;
export declare function awsKendraIndexSearchPropertyToTerraform(struct?: AwsKendraIndex.SearchPropertyOutputReference | AwsKendraIndex.SearchProperty): any;
export declare function awsKendraIndexSearchPropertyToHclTerraform(struct?: AwsKendraIndex.SearchPropertyOutputReference | AwsKendraIndex.SearchProperty): any;
export declare function awsKendraIndexDocumentMetadataConfigurationUpdatesPropertyToTerraform(struct?: AwsKendraIndex.DocumentMetadataConfigurationUpdatesProperty | cdktn.IResolvable): any;
export declare function awsKendraIndexDocumentMetadataConfigurationUpdatesPropertyToHclTerraform(struct?: AwsKendraIndex.DocumentMetadataConfigurationUpdatesProperty | cdktn.IResolvable): any;
export declare function awsKendraIndexServerSideEncryptionConfigurationPropertyToTerraform(struct?: AwsKendraIndex.ServerSideEncryptionConfigurationPropertyOutputReference | AwsKendraIndex.ServerSideEncryptionConfigurationProperty): any;
export declare function awsKendraIndexServerSideEncryptionConfigurationPropertyToHclTerraform(struct?: AwsKendraIndex.ServerSideEncryptionConfigurationPropertyOutputReference | AwsKendraIndex.ServerSideEncryptionConfigurationProperty): any;
export declare function awsKendraIndexTimeoutsPropertyToTerraform(struct?: AwsKendraIndex.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsKendraIndexTimeoutsPropertyToHclTerraform(struct?: AwsKendraIndex.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsKendraIndexUserGroupResolutionConfigurationPropertyToTerraform(struct?: AwsKendraIndex.UserGroupResolutionConfigurationPropertyOutputReference | AwsKendraIndex.UserGroupResolutionConfigurationProperty): any;
export declare function awsKendraIndexUserGroupResolutionConfigurationPropertyToHclTerraform(struct?: AwsKendraIndex.UserGroupResolutionConfigurationPropertyOutputReference | AwsKendraIndex.UserGroupResolutionConfigurationProperty): any;
export declare function awsKendraIndexJsonTokenTypeConfigurationPropertyToTerraform(struct?: AwsKendraIndex.JsonTokenTypeConfigurationPropertyOutputReference | AwsKendraIndex.JsonTokenTypeConfigurationProperty): any;
export declare function awsKendraIndexJsonTokenTypeConfigurationPropertyToHclTerraform(struct?: AwsKendraIndex.JsonTokenTypeConfigurationPropertyOutputReference | AwsKendraIndex.JsonTokenTypeConfigurationProperty): any;
export declare function awsKendraIndexJwtTokenTypeConfigurationPropertyToTerraform(struct?: AwsKendraIndex.JwtTokenTypeConfigurationPropertyOutputReference | AwsKendraIndex.JwtTokenTypeConfigurationProperty): any;
export declare function awsKendraIndexJwtTokenTypeConfigurationPropertyToHclTerraform(struct?: AwsKendraIndex.JwtTokenTypeConfigurationPropertyOutputReference | AwsKendraIndex.JwtTokenTypeConfigurationProperty): any;
export declare function awsKendraIndexUserTokenConfigurationsPropertyToTerraform(struct?: AwsKendraIndex.UserTokenConfigurationsPropertyOutputReference | AwsKendraIndex.UserTokenConfigurationsProperty): any;
export declare function awsKendraIndexUserTokenConfigurationsPropertyToHclTerraform(struct?: AwsKendraIndex.UserTokenConfigurationsPropertyOutputReference | AwsKendraIndex.UserTokenConfigurationsProperty): any;
export declare namespace AwsKendraIndex {
    interface FaqStatisticsProperty {
    }
    class FaqStatisticsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): FaqStatisticsProperty | undefined;
        set internalValue(value: FaqStatisticsProperty | undefined);
        get indexedQuestionAnswersCount(): number;
    }
    class FaqStatisticsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): FaqStatisticsPropertyOutputReference;
    }
    interface TextDocumentStatisticsProperty {
    }
    class TextDocumentStatisticsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TextDocumentStatisticsProperty | undefined;
        set internalValue(value: TextDocumentStatisticsProperty | undefined);
        get indexedTextBytes(): number;
        get indexedTextDocumentsCount(): number;
    }
    class TextDocumentStatisticsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TextDocumentStatisticsPropertyOutputReference;
    }
    interface IndexStatisticsProperty {
    }
    class IndexStatisticsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): IndexStatisticsProperty | undefined;
        set internalValue(value: IndexStatisticsProperty | undefined);
        private _faqStatistics;
        get faqStatistics(): FaqStatisticsPropertyList;
        private _textDocumentStatistics;
        get textDocumentStatistics(): TextDocumentStatisticsPropertyList;
    }
    class IndexStatisticsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): IndexStatisticsPropertyOutputReference;
    }
    interface CapacityUnitsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_index#query_capacity_units AwsKendraIndex#query_capacity_units}
        */
        readonly queryCapacityUnits?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_index#storage_capacity_units AwsKendraIndex#storage_capacity_units}
        */
        readonly storageCapacityUnits?: number;
    }
    class CapacityUnitsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CapacityUnitsProperty | undefined;
        set internalValue(value: CapacityUnitsProperty | undefined);
        private _queryCapacityUnits?;
        get queryCapacityUnits(): number;
        set queryCapacityUnits(value: number);
        resetQueryCapacityUnits(): void;
        get queryCapacityUnitsInput(): number | undefined;
        private _storageCapacityUnits?;
        get storageCapacityUnits(): number;
        set storageCapacityUnits(value: number);
        resetStorageCapacityUnits(): void;
        get storageCapacityUnitsInput(): number | undefined;
    }
    interface RelevanceProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_index#duration AwsKendraIndex#duration}
        */
        readonly duration?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_index#freshness AwsKendraIndex#freshness}
        */
        readonly freshness?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_index#importance AwsKendraIndex#importance}
        */
        readonly importance?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_index#rank_order AwsKendraIndex#rank_order}
        */
        readonly rankOrder?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_index#values_importance_map AwsKendraIndex#values_importance_map}
        */
        readonly valuesImportanceMap?: {
            [key: string]: number;
        };
    }
    class RelevancePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RelevanceProperty | undefined;
        set internalValue(value: RelevanceProperty | undefined);
        private _duration?;
        get duration(): string;
        set duration(value: string);
        resetDuration(): void;
        get durationInput(): string | undefined;
        private _freshness?;
        get freshness(): boolean | cdktn.IResolvable;
        set freshness(value: boolean | cdktn.IResolvable);
        resetFreshness(): void;
        get freshnessInput(): boolean | cdktn.IResolvable | undefined;
        private _importance?;
        get importance(): number;
        set importance(value: number);
        resetImportance(): void;
        get importanceInput(): number | undefined;
        private _rankOrder?;
        get rankOrder(): string;
        set rankOrder(value: string);
        resetRankOrder(): void;
        get rankOrderInput(): string | undefined;
        private _valuesImportanceMap?;
        get valuesImportanceMap(): {
            [key: string]: number;
        };
        set valuesImportanceMap(value: {
            [key: string]: number;
        });
        resetValuesImportanceMap(): void;
        get valuesImportanceMapInput(): {
            [key: string]: number;
        } | undefined;
    }
    interface SearchProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_index#displayable AwsKendraIndex#displayable}
        */
        readonly displayable?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_index#facetable AwsKendraIndex#facetable}
        */
        readonly facetable?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_index#searchable AwsKendraIndex#searchable}
        */
        readonly searchable?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_index#sortable AwsKendraIndex#sortable}
        */
        readonly sortable?: boolean | cdktn.IResolvable;
    }
    class SearchPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SearchProperty | undefined;
        set internalValue(value: SearchProperty | undefined);
        private _displayable?;
        get displayable(): boolean | cdktn.IResolvable;
        set displayable(value: boolean | cdktn.IResolvable);
        resetDisplayable(): void;
        get displayableInput(): boolean | cdktn.IResolvable | undefined;
        private _facetable?;
        get facetable(): boolean | cdktn.IResolvable;
        set facetable(value: boolean | cdktn.IResolvable);
        resetFacetable(): void;
        get facetableInput(): boolean | cdktn.IResolvable | undefined;
        private _searchable?;
        get searchable(): boolean | cdktn.IResolvable;
        set searchable(value: boolean | cdktn.IResolvable);
        resetSearchable(): void;
        get searchableInput(): boolean | cdktn.IResolvable | undefined;
        private _sortable?;
        get sortable(): boolean | cdktn.IResolvable;
        set sortable(value: boolean | cdktn.IResolvable);
        resetSortable(): void;
        get sortableInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface DocumentMetadataConfigurationUpdatesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_index#name AwsKendraIndex#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_index#type AwsKendraIndex#type}
        */
        readonly type: string;
        /**
        * relevance block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_index#relevance AwsKendraIndex#relevance}
        */
        readonly relevance?: RelevanceProperty;
        /**
        * search block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_index#search AwsKendraIndex#search}
        */
        readonly search?: SearchProperty;
    }
    class DocumentMetadataConfigurationUpdatesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DocumentMetadataConfigurationUpdatesProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DocumentMetadataConfigurationUpdatesProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
        private _relevance;
        get relevance(): RelevancePropertyOutputReference;
        putRelevance(value: RelevanceProperty): void;
        resetRelevance(): void;
        get relevanceInput(): RelevanceProperty | undefined;
        private _search;
        get search(): SearchPropertyOutputReference;
        putSearch(value: SearchProperty): void;
        resetSearch(): void;
        get searchInput(): SearchProperty | undefined;
    }
    class DocumentMetadataConfigurationUpdatesPropertyList extends cdktn.ComplexList {
        internalValue?: DocumentMetadataConfigurationUpdatesProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DocumentMetadataConfigurationUpdatesPropertyOutputReference;
    }
    interface ServerSideEncryptionConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_index#kms_key_id AwsKendraIndex#kms_key_id}
        */
        readonly kmsKeyId?: string;
    }
    class ServerSideEncryptionConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ServerSideEncryptionConfigurationProperty | undefined;
        set internalValue(value: ServerSideEncryptionConfigurationProperty | undefined);
        private _kmsKeyId?;
        get kmsKeyId(): string;
        set kmsKeyId(value: string);
        resetKmsKeyId(): void;
        get kmsKeyIdInput(): string | undefined;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_index#create AwsKendraIndex#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_index#delete AwsKendraIndex#delete}
        */
        readonly delete?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_index#update AwsKendraIndex#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
    interface UserGroupResolutionConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_index#user_group_resolution_mode AwsKendraIndex#user_group_resolution_mode}
        */
        readonly userGroupResolutionMode: string;
    }
    class UserGroupResolutionConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): UserGroupResolutionConfigurationProperty | undefined;
        set internalValue(value: UserGroupResolutionConfigurationProperty | undefined);
        private _userGroupResolutionMode?;
        get userGroupResolutionMode(): string;
        set userGroupResolutionMode(value: string);
        get userGroupResolutionModeInput(): string | undefined;
    }
    interface JsonTokenTypeConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_index#group_attribute_field AwsKendraIndex#group_attribute_field}
        */
        readonly groupAttributeField: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_index#user_name_attribute_field AwsKendraIndex#user_name_attribute_field}
        */
        readonly userNameAttributeField: string;
    }
    class JsonTokenTypeConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): JsonTokenTypeConfigurationProperty | undefined;
        set internalValue(value: JsonTokenTypeConfigurationProperty | undefined);
        private _groupAttributeField?;
        get groupAttributeField(): string;
        set groupAttributeField(value: string);
        get groupAttributeFieldInput(): string | undefined;
        private _userNameAttributeField?;
        get userNameAttributeField(): string;
        set userNameAttributeField(value: string);
        get userNameAttributeFieldInput(): string | undefined;
    }
    interface JwtTokenTypeConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_index#claim_regex AwsKendraIndex#claim_regex}
        */
        readonly claimRegex?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_index#group_attribute_field AwsKendraIndex#group_attribute_field}
        */
        readonly groupAttributeField?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_index#issuer AwsKendraIndex#issuer}
        */
        readonly issuer?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_index#key_location AwsKendraIndex#key_location}
        */
        readonly keyLocation: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_index#secrets_manager_arn AwsKendraIndex#secrets_manager_arn}
        */
        readonly secretsManagerArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_index#url AwsKendraIndex#url}
        */
        readonly url?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_index#user_name_attribute_field AwsKendraIndex#user_name_attribute_field}
        */
        readonly userNameAttributeField?: string;
    }
    class JwtTokenTypeConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): JwtTokenTypeConfigurationProperty | undefined;
        set internalValue(value: JwtTokenTypeConfigurationProperty | undefined);
        private _claimRegex?;
        get claimRegex(): string;
        set claimRegex(value: string);
        resetClaimRegex(): void;
        get claimRegexInput(): string | undefined;
        private _groupAttributeField?;
        get groupAttributeField(): string;
        set groupAttributeField(value: string);
        resetGroupAttributeField(): void;
        get groupAttributeFieldInput(): string | undefined;
        private _issuer?;
        get issuer(): string;
        set issuer(value: string);
        resetIssuer(): void;
        get issuerInput(): string | undefined;
        private _keyLocation?;
        get keyLocation(): string;
        set keyLocation(value: string);
        get keyLocationInput(): string | undefined;
        private _secretsManagerArn?;
        get secretsManagerArn(): string;
        set secretsManagerArn(value: string);
        resetSecretsManagerArn(): void;
        get secretsManagerArnInput(): string | undefined;
        private _url?;
        get url(): string;
        set url(value: string);
        resetUrl(): void;
        get urlInput(): string | undefined;
        private _userNameAttributeField?;
        get userNameAttributeField(): string;
        set userNameAttributeField(value: string);
        resetUserNameAttributeField(): void;
        get userNameAttributeFieldInput(): string | undefined;
    }
    interface UserTokenConfigurationsProperty {
        /**
        * json_token_type_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_index#json_token_type_configuration AwsKendraIndex#json_token_type_configuration}
        */
        readonly jsonTokenTypeConfiguration?: JsonTokenTypeConfigurationProperty;
        /**
        * jwt_token_type_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_index#jwt_token_type_configuration AwsKendraIndex#jwt_token_type_configuration}
        */
        readonly jwtTokenTypeConfiguration?: JwtTokenTypeConfigurationProperty;
    }
    class UserTokenConfigurationsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): UserTokenConfigurationsProperty | undefined;
        set internalValue(value: UserTokenConfigurationsProperty | undefined);
        private _jsonTokenTypeConfiguration;
        get jsonTokenTypeConfiguration(): JsonTokenTypeConfigurationPropertyOutputReference;
        putJsonTokenTypeConfiguration(value: JsonTokenTypeConfigurationProperty): void;
        resetJsonTokenTypeConfiguration(): void;
        get jsonTokenTypeConfigurationInput(): JsonTokenTypeConfigurationProperty | undefined;
        private _jwtTokenTypeConfiguration;
        get jwtTokenTypeConfiguration(): JwtTokenTypeConfigurationPropertyOutputReference;
        putJwtTokenTypeConfiguration(value: JwtTokenTypeConfigurationProperty): void;
        resetJwtTokenTypeConfiguration(): void;
        get jwtTokenTypeConfigurationInput(): JwtTokenTypeConfigurationProperty | undefined;
    }
}
