import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsKendraQuerySuggestionsBlockListConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_query_suggestions_block_list#description AwsKendraQuerySuggestionsBlockList#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_query_suggestions_block_list#id AwsKendraQuerySuggestionsBlockList#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_query_suggestions_block_list#index_id AwsKendraQuerySuggestionsBlockList#index_id}
    */
    readonly indexId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_query_suggestions_block_list#name AwsKendraQuerySuggestionsBlockList#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_query_suggestions_block_list#region AwsKendraQuerySuggestionsBlockList#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_query_suggestions_block_list#role_arn AwsKendraQuerySuggestionsBlockList#role_arn}
    */
    readonly roleArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_query_suggestions_block_list#tags AwsKendraQuerySuggestionsBlockList#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_query_suggestions_block_list#tags_all AwsKendraQuerySuggestionsBlockList#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * source_s3_path block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_query_suggestions_block_list#source_s3_path AwsKendraQuerySuggestionsBlockList#source_s3_path}
    */
    readonly sourceS3Path: AwsKendraQuerySuggestionsBlockList.SourceS3PathProperty;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_query_suggestions_block_list#timeouts AwsKendraQuerySuggestionsBlockList#timeouts}
    */
    readonly timeouts?: AwsKendraQuerySuggestionsBlockList.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_query_suggestions_block_list aws_kendra_query_suggestions_block_list}
*/
export declare class AwsKendraQuerySuggestionsBlockList extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_kendra_query_suggestions_block_list";
    /**
    * Generates CDKTN code for importing a AwsKendraQuerySuggestionsBlockList resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsKendraQuerySuggestionsBlockList to import
    * @param importFromId The id of the existing AwsKendraQuerySuggestionsBlockList that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_query_suggestions_block_list#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsKendraQuerySuggestionsBlockList to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_query_suggestions_block_list aws_kendra_query_suggestions_block_list} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsKendraQuerySuggestionsBlockListConfig
    */
    constructor(scope: Construct, id: string, config: AwsKendraQuerySuggestionsBlockListConfig);
    get arn(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _indexId?;
    get indexId(): string;
    set indexId(value: string);
    get indexIdInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get querySuggestionsBlockListId(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _roleArn?;
    get roleArn(): string;
    set roleArn(value: string);
    get roleArnInput(): string | undefined;
    get status(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _sourceS3Path;
    get sourceS3Path(): AwsKendraQuerySuggestionsBlockList.SourceS3PathPropertyOutputReference;
    putSourceS3Path(value: AwsKendraQuerySuggestionsBlockList.SourceS3PathProperty): void;
    get sourceS3PathInput(): AwsKendraQuerySuggestionsBlockList.SourceS3PathProperty | undefined;
    private _timeouts;
    get timeouts(): AwsKendraQuerySuggestionsBlockList.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsKendraQuerySuggestionsBlockList.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsKendraQuerySuggestionsBlockList.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsKendraQuerySuggestionsBlockListSourceS3PathPropertyToTerraform(struct?: AwsKendraQuerySuggestionsBlockList.SourceS3PathPropertyOutputReference | AwsKendraQuerySuggestionsBlockList.SourceS3PathProperty): any;
export declare function awsKendraQuerySuggestionsBlockListSourceS3PathPropertyToHclTerraform(struct?: AwsKendraQuerySuggestionsBlockList.SourceS3PathPropertyOutputReference | AwsKendraQuerySuggestionsBlockList.SourceS3PathProperty): any;
export declare function awsKendraQuerySuggestionsBlockListTimeoutsPropertyToTerraform(struct?: AwsKendraQuerySuggestionsBlockList.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsKendraQuerySuggestionsBlockListTimeoutsPropertyToHclTerraform(struct?: AwsKendraQuerySuggestionsBlockList.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsKendraQuerySuggestionsBlockList {
    interface SourceS3PathProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_query_suggestions_block_list#bucket AwsKendraQuerySuggestionsBlockList#bucket}
        */
        readonly bucket: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_query_suggestions_block_list#key AwsKendraQuerySuggestionsBlockList#key}
        */
        readonly key: string;
    }
    class SourceS3PathPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SourceS3PathProperty | undefined;
        set internalValue(value: SourceS3PathProperty | undefined);
        private _bucket?;
        get bucket(): string;
        set bucket(value: string);
        get bucketInput(): string | undefined;
        private _key?;
        get key(): string;
        set key(value: string);
        get keyInput(): string | undefined;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_query_suggestions_block_list#create AwsKendraQuerySuggestionsBlockList#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_query_suggestions_block_list#delete AwsKendraQuerySuggestionsBlockList#delete}
        */
        readonly delete?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_query_suggestions_block_list#update AwsKendraQuerySuggestionsBlockList#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
