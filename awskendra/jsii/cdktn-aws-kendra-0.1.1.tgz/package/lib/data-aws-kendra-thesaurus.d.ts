import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsKendraThesaurusConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/kendra_thesaurus#id DataAwsKendraThesaurus#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/kendra_thesaurus#index_id DataAwsKendraThesaurus#index_id}
    */
    readonly indexId: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/kendra_thesaurus#region DataAwsKendraThesaurus#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/kendra_thesaurus#tags DataAwsKendraThesaurus#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/kendra_thesaurus#thesaurus_id DataAwsKendraThesaurus#thesaurus_id}
    */
    readonly thesaurusId: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/kendra_thesaurus aws_kendra_thesaurus}
*/
export declare class DataAwsKendraThesaurus extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_kendra_thesaurus";
    /**
    * Generates CDKTN code for importing a DataAwsKendraThesaurus resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsKendraThesaurus to import
    * @param importFromId The id of the existing DataAwsKendraThesaurus that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/kendra_thesaurus#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsKendraThesaurus to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/kendra_thesaurus aws_kendra_thesaurus} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsKendraThesaurusConfig
    */
    constructor(scope: Construct, id: string, config: DataAwsKendraThesaurusConfig);
    get arn(): string;
    get createdAt(): string;
    get description(): string;
    get errorMessage(): string;
    get fileSizeBytes(): number;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _indexId?;
    get indexId(): string;
    set indexId(value: string);
    get indexIdInput(): string | undefined;
    get name(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get roleArn(): string;
    private _sourceS3Path;
    get sourceS3Path(): DataAwsKendraThesaurus.SourceS3PathPropertyList;
    get status(): string;
    get synonymRuleCount(): number;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    get termCount(): number;
    private _thesaurusId?;
    get thesaurusId(): string;
    set thesaurusId(value: string);
    get thesaurusIdInput(): string | undefined;
    get updatedAt(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataAwsKendraThesaurusSourceS3PathPropertyToTerraform(struct?: DataAwsKendraThesaurus.SourceS3PathProperty): any;
export declare function dataAwsKendraThesaurusSourceS3PathPropertyToHclTerraform(struct?: DataAwsKendraThesaurus.SourceS3PathProperty): any;
export declare namespace DataAwsKendraThesaurus {
    interface SourceS3PathProperty {
    }
    class SourceS3PathPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SourceS3PathProperty | undefined;
        set internalValue(value: SourceS3PathProperty | undefined);
        get bucket(): string;
        get key(): string;
    }
    class SourceS3PathPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SourceS3PathPropertyOutputReference;
    }
}
