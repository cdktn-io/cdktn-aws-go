import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsAppintegrationsDataIntegrationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appintegrations_data_integration#description AwsAppintegrationsDataIntegration#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appintegrations_data_integration#id AwsAppintegrationsDataIntegration#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appintegrations_data_integration#kms_key AwsAppintegrationsDataIntegration#kms_key}
    */
    readonly kmsKey: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appintegrations_data_integration#name AwsAppintegrationsDataIntegration#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appintegrations_data_integration#region AwsAppintegrationsDataIntegration#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appintegrations_data_integration#source_uri AwsAppintegrationsDataIntegration#source_uri}
    */
    readonly sourceUri: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appintegrations_data_integration#tags AwsAppintegrationsDataIntegration#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appintegrations_data_integration#tags_all AwsAppintegrationsDataIntegration#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * schedule_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appintegrations_data_integration#schedule_config AwsAppintegrationsDataIntegration#schedule_config}
    */
    readonly scheduleConfig: AwsAppintegrationsDataIntegration.ScheduleConfigProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appintegrations_data_integration aws_appintegrations_data_integration}
*/
export declare class AwsAppintegrationsDataIntegration extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_appintegrations_data_integration";
    /**
    * Generates CDKTN code for importing a AwsAppintegrationsDataIntegration resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsAppintegrationsDataIntegration to import
    * @param importFromId The id of the existing AwsAppintegrationsDataIntegration that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appintegrations_data_integration#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsAppintegrationsDataIntegration to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appintegrations_data_integration aws_appintegrations_data_integration} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsAppintegrationsDataIntegrationConfig
    */
    constructor(scope: Construct, id: string, config: AwsAppintegrationsDataIntegrationConfig);
    get arn(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _kmsKey?;
    get kmsKey(): string;
    set kmsKey(value: string);
    get kmsKeyInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _sourceUri?;
    get sourceUri(): string;
    set sourceUri(value: string);
    get sourceUriInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _scheduleConfig;
    get scheduleConfig(): AwsAppintegrationsDataIntegration.ScheduleConfigPropertyOutputReference;
    putScheduleConfig(value: AwsAppintegrationsDataIntegration.ScheduleConfigProperty): void;
    get scheduleConfigInput(): AwsAppintegrationsDataIntegration.ScheduleConfigProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsAppintegrationsDataIntegrationScheduleConfigPropertyToTerraform(struct?: AwsAppintegrationsDataIntegration.ScheduleConfigPropertyOutputReference | AwsAppintegrationsDataIntegration.ScheduleConfigProperty): any;
export declare function awsAppintegrationsDataIntegrationScheduleConfigPropertyToHclTerraform(struct?: AwsAppintegrationsDataIntegration.ScheduleConfigPropertyOutputReference | AwsAppintegrationsDataIntegration.ScheduleConfigProperty): any;
export declare namespace AwsAppintegrationsDataIntegration {
    interface ScheduleConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appintegrations_data_integration#first_execution_from AwsAppintegrationsDataIntegration#first_execution_from}
        */
        readonly firstExecutionFrom: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appintegrations_data_integration#object AwsAppintegrationsDataIntegration#object}
        */
        readonly object: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appintegrations_data_integration#schedule_expression AwsAppintegrationsDataIntegration#schedule_expression}
        */
        readonly scheduleExpression: string;
    }
    class ScheduleConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ScheduleConfigProperty | undefined;
        set internalValue(value: ScheduleConfigProperty | undefined);
        private _firstExecutionFrom?;
        get firstExecutionFrom(): string;
        set firstExecutionFrom(value: string);
        get firstExecutionFromInput(): string | undefined;
        private _object?;
        get object(): string;
        set object(value: string);
        get objectInput(): string | undefined;
        private _scheduleExpression?;
        get scheduleExpression(): string;
        set scheduleExpression(value: string);
        get scheduleExpressionInput(): string | undefined;
    }
}
