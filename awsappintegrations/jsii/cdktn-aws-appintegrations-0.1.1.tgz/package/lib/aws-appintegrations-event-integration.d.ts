import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsAppintegrationsEventIntegrationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appintegrations_event_integration#description AwsAppintegrationsEventIntegration#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appintegrations_event_integration#eventbridge_bus AwsAppintegrationsEventIntegration#eventbridge_bus}
    */
    readonly eventbridgeBus: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appintegrations_event_integration#id AwsAppintegrationsEventIntegration#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appintegrations_event_integration#name AwsAppintegrationsEventIntegration#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appintegrations_event_integration#region AwsAppintegrationsEventIntegration#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appintegrations_event_integration#tags AwsAppintegrationsEventIntegration#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appintegrations_event_integration#tags_all AwsAppintegrationsEventIntegration#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * event_filter block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appintegrations_event_integration#event_filter AwsAppintegrationsEventIntegration#event_filter}
    */
    readonly eventFilter: AwsAppintegrationsEventIntegration.EventFilterProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appintegrations_event_integration aws_appintegrations_event_integration}
*/
export declare class AwsAppintegrationsEventIntegration extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_appintegrations_event_integration";
    /**
    * Generates CDKTN code for importing a AwsAppintegrationsEventIntegration resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsAppintegrationsEventIntegration to import
    * @param importFromId The id of the existing AwsAppintegrationsEventIntegration that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appintegrations_event_integration#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsAppintegrationsEventIntegration to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appintegrations_event_integration aws_appintegrations_event_integration} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsAppintegrationsEventIntegrationConfig
    */
    constructor(scope: Construct, id: string, config: AwsAppintegrationsEventIntegrationConfig);
    get arn(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _eventbridgeBus?;
    get eventbridgeBus(): string;
    set eventbridgeBus(value: string);
    get eventbridgeBusInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _eventFilter;
    get eventFilter(): AwsAppintegrationsEventIntegration.EventFilterPropertyOutputReference;
    putEventFilter(value: AwsAppintegrationsEventIntegration.EventFilterProperty): void;
    get eventFilterInput(): AwsAppintegrationsEventIntegration.EventFilterProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsAppintegrationsEventIntegrationEventFilterPropertyToTerraform(struct?: AwsAppintegrationsEventIntegration.EventFilterPropertyOutputReference | AwsAppintegrationsEventIntegration.EventFilterProperty): any;
export declare function awsAppintegrationsEventIntegrationEventFilterPropertyToHclTerraform(struct?: AwsAppintegrationsEventIntegration.EventFilterPropertyOutputReference | AwsAppintegrationsEventIntegration.EventFilterProperty): any;
export declare namespace AwsAppintegrationsEventIntegration {
    interface EventFilterProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appintegrations_event_integration#source AwsAppintegrationsEventIntegration#source}
        */
        readonly source: string;
    }
    class EventFilterPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): EventFilterProperty | undefined;
        set internalValue(value: EventFilterProperty | undefined);
        private _source?;
        get source(): string;
        set source(value: string);
        get sourceInput(): string | undefined;
    }
}
