import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsBedrockagentAgentActionGroupConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_agent_action_group#action_group_name AwsBedrockagentAgentActionGroup#action_group_name}
    */
    readonly actionGroupName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_agent_action_group#action_group_state AwsBedrockagentAgentActionGroup#action_group_state}
    */
    readonly actionGroupState?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_agent_action_group#agent_id AwsBedrockagentAgentActionGroup#agent_id}
    */
    readonly agentId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_agent_action_group#agent_version AwsBedrockagentAgentActionGroup#agent_version}
    */
    readonly agentVersion: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_agent_action_group#description AwsBedrockagentAgentActionGroup#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_agent_action_group#parent_action_group_signature AwsBedrockagentAgentActionGroup#parent_action_group_signature}
    */
    readonly parentActionGroupSignature?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_agent_action_group#prepare_agent AwsBedrockagentAgentActionGroup#prepare_agent}
    */
    readonly prepareAgent?: boolean | cdktn.IResolvable;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_agent_action_group#region AwsBedrockagentAgentActionGroup#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_agent_action_group#skip_resource_in_use_check AwsBedrockagentAgentActionGroup#skip_resource_in_use_check}
    */
    readonly skipResourceInUseCheck?: boolean | cdktn.IResolvable;
    /**
    * action_group_executor block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_agent_action_group#action_group_executor AwsBedrockagentAgentActionGroup#action_group_executor}
    */
    readonly actionGroupExecutor?: AwsBedrockagentAgentActionGroup.ActionGroupExecutorProperty[] | cdktn.IResolvable;
    /**
    * api_schema block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_agent_action_group#api_schema AwsBedrockagentAgentActionGroup#api_schema}
    */
    readonly apiSchema?: AwsBedrockagentAgentActionGroup.ApiSchemaProperty[] | cdktn.IResolvable;
    /**
    * function_schema block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_agent_action_group#function_schema AwsBedrockagentAgentActionGroup#function_schema}
    */
    readonly functionSchema?: AwsBedrockagentAgentActionGroup.FunctionSchemaProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_agent_action_group#timeouts AwsBedrockagentAgentActionGroup#timeouts}
    */
    readonly timeouts?: AwsBedrockagentAgentActionGroup.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_agent_action_group aws_bedrockagent_agent_action_group}
*/
export declare class AwsBedrockagentAgentActionGroup extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_bedrockagent_agent_action_group";
    /**
    * Generates CDKTN code for importing a AwsBedrockagentAgentActionGroup resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsBedrockagentAgentActionGroup to import
    * @param importFromId The id of the existing AwsBedrockagentAgentActionGroup that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_agent_action_group#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsBedrockagentAgentActionGroup to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_agent_action_group aws_bedrockagent_agent_action_group} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsBedrockagentAgentActionGroupConfig
    */
    constructor(scope: Construct, id: string, config: AwsBedrockagentAgentActionGroupConfig);
    get actionGroupId(): string;
    private _actionGroupName?;
    get actionGroupName(): string;
    set actionGroupName(value: string);
    get actionGroupNameInput(): string | undefined;
    private _actionGroupState?;
    get actionGroupState(): string;
    set actionGroupState(value: string);
    resetActionGroupState(): void;
    get actionGroupStateInput(): string | undefined;
    private _agentId?;
    get agentId(): string;
    set agentId(value: string);
    get agentIdInput(): string | undefined;
    private _agentVersion?;
    get agentVersion(): string;
    set agentVersion(value: string);
    get agentVersionInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get id(): string;
    private _parentActionGroupSignature?;
    get parentActionGroupSignature(): string;
    set parentActionGroupSignature(value: string);
    resetParentActionGroupSignature(): void;
    get parentActionGroupSignatureInput(): string | undefined;
    private _prepareAgent?;
    get prepareAgent(): boolean | cdktn.IResolvable;
    set prepareAgent(value: boolean | cdktn.IResolvable);
    resetPrepareAgent(): void;
    get prepareAgentInput(): boolean | cdktn.IResolvable | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _skipResourceInUseCheck?;
    get skipResourceInUseCheck(): boolean | cdktn.IResolvable;
    set skipResourceInUseCheck(value: boolean | cdktn.IResolvable);
    resetSkipResourceInUseCheck(): void;
    get skipResourceInUseCheckInput(): boolean | cdktn.IResolvable | undefined;
    private _actionGroupExecutor;
    get actionGroupExecutor(): AwsBedrockagentAgentActionGroup.ActionGroupExecutorPropertyList;
    putActionGroupExecutor(value: AwsBedrockagentAgentActionGroup.ActionGroupExecutorProperty[] | cdktn.IResolvable): void;
    resetActionGroupExecutor(): void;
    get actionGroupExecutorInput(): cdktn.IResolvable | AwsBedrockagentAgentActionGroup.ActionGroupExecutorProperty[] | undefined;
    private _apiSchema;
    get apiSchema(): AwsBedrockagentAgentActionGroup.ApiSchemaPropertyList;
    putApiSchema(value: AwsBedrockagentAgentActionGroup.ApiSchemaProperty[] | cdktn.IResolvable): void;
    resetApiSchema(): void;
    get apiSchemaInput(): cdktn.IResolvable | AwsBedrockagentAgentActionGroup.ApiSchemaProperty[] | undefined;
    private _functionSchema;
    get functionSchema(): AwsBedrockagentAgentActionGroup.FunctionSchemaPropertyList;
    putFunctionSchema(value: AwsBedrockagentAgentActionGroup.FunctionSchemaProperty[] | cdktn.IResolvable): void;
    resetFunctionSchema(): void;
    get functionSchemaInput(): cdktn.IResolvable | AwsBedrockagentAgentActionGroup.FunctionSchemaProperty[] | undefined;
    private _timeouts;
    get timeouts(): AwsBedrockagentAgentActionGroup.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsBedrockagentAgentActionGroup.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsBedrockagentAgentActionGroup.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsBedrockagentAgentActionGroupActionGroupExecutorPropertyToTerraform(struct?: AwsBedrockagentAgentActionGroup.ActionGroupExecutorProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentAgentActionGroupActionGroupExecutorPropertyToHclTerraform(struct?: AwsBedrockagentAgentActionGroup.ActionGroupExecutorProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentAgentActionGroupS3PropertyToTerraform(struct?: AwsBedrockagentAgentActionGroup.S3Property | cdktn.IResolvable): any;
export declare function awsBedrockagentAgentActionGroupS3PropertyToHclTerraform(struct?: AwsBedrockagentAgentActionGroup.S3Property | cdktn.IResolvable): any;
export declare function awsBedrockagentAgentActionGroupApiSchemaPropertyToTerraform(struct?: AwsBedrockagentAgentActionGroup.ApiSchemaProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentAgentActionGroupApiSchemaPropertyToHclTerraform(struct?: AwsBedrockagentAgentActionGroup.ApiSchemaProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentAgentActionGroupParametersPropertyToTerraform(struct?: AwsBedrockagentAgentActionGroup.ParametersProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentAgentActionGroupParametersPropertyToHclTerraform(struct?: AwsBedrockagentAgentActionGroup.ParametersProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentAgentActionGroupFunctionsPropertyToTerraform(struct?: AwsBedrockagentAgentActionGroup.FunctionsProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentAgentActionGroupFunctionsPropertyToHclTerraform(struct?: AwsBedrockagentAgentActionGroup.FunctionsProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentAgentActionGroupMemberFunctionsPropertyToTerraform(struct?: AwsBedrockagentAgentActionGroup.MemberFunctionsProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentAgentActionGroupMemberFunctionsPropertyToHclTerraform(struct?: AwsBedrockagentAgentActionGroup.MemberFunctionsProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentAgentActionGroupFunctionSchemaPropertyToTerraform(struct?: AwsBedrockagentAgentActionGroup.FunctionSchemaProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentAgentActionGroupFunctionSchemaPropertyToHclTerraform(struct?: AwsBedrockagentAgentActionGroup.FunctionSchemaProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentAgentActionGroupTimeoutsPropertyToTerraform(struct?: AwsBedrockagentAgentActionGroup.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentAgentActionGroupTimeoutsPropertyToHclTerraform(struct?: AwsBedrockagentAgentActionGroup.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsBedrockagentAgentActionGroup {
    interface ActionGroupExecutorProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_agent_action_group#custom_control AwsBedrockagentAgentActionGroup#custom_control}
        */
        readonly customControl?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_agent_action_group#lambda AwsBedrockagentAgentActionGroup#lambda}
        */
        readonly lambda?: string;
    }
    class ActionGroupExecutorPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ActionGroupExecutorProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ActionGroupExecutorProperty | cdktn.IResolvable | undefined);
        private _customControl?;
        get customControl(): string;
        set customControl(value: string);
        resetCustomControl(): void;
        get customControlInput(): string | undefined;
        private _lambda?;
        get lambda(): string;
        set lambda(value: string);
        resetLambda(): void;
        get lambdaInput(): string | undefined;
    }
    class ActionGroupExecutorPropertyList extends cdktn.ComplexList {
        internalValue?: ActionGroupExecutorProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ActionGroupExecutorPropertyOutputReference;
    }
    interface S3Property {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_agent_action_group#s3_bucket_name AwsBedrockagentAgentActionGroup#s3_bucket_name}
        */
        readonly s3BucketName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_agent_action_group#s3_object_key AwsBedrockagentAgentActionGroup#s3_object_key}
        */
        readonly s3ObjectKey?: string;
    }
    class S3PropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): S3Property | cdktn.IResolvable | undefined;
        set internalValue(value: S3Property | cdktn.IResolvable | undefined);
        private _s3BucketName?;
        get s3BucketName(): string;
        set s3BucketName(value: string);
        resetS3BucketName(): void;
        get s3BucketNameInput(): string | undefined;
        private _s3ObjectKey?;
        get s3ObjectKey(): string;
        set s3ObjectKey(value: string);
        resetS3ObjectKey(): void;
        get s3ObjectKeyInput(): string | undefined;
    }
    class S3PropertyList extends cdktn.ComplexList {
        internalValue?: S3Property[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): S3PropertyOutputReference;
    }
    interface ApiSchemaProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_agent_action_group#payload AwsBedrockagentAgentActionGroup#payload}
        */
        readonly payload?: string;
        /**
        * s3 block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_agent_action_group#s3 AwsBedrockagentAgentActionGroup#s3}
        */
        readonly s3?: S3Property[] | cdktn.IResolvable;
    }
    class ApiSchemaPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ApiSchemaProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ApiSchemaProperty | cdktn.IResolvable | undefined);
        private _payload?;
        get payload(): string;
        set payload(value: string);
        resetPayload(): void;
        get payloadInput(): string | undefined;
        private _s3;
        get s3(): S3PropertyList;
        putS3(value: S3Property[] | cdktn.IResolvable): void;
        resetS3(): void;
        get s3Input(): cdktn.IResolvable | S3Property[] | undefined;
    }
    class ApiSchemaPropertyList extends cdktn.ComplexList {
        internalValue?: ApiSchemaProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ApiSchemaPropertyOutputReference;
    }
    interface ParametersProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_agent_action_group#description AwsBedrockagentAgentActionGroup#description}
        */
        readonly description?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_agent_action_group#map_block_key AwsBedrockagentAgentActionGroup#map_block_key}
        */
        readonly mapBlockKey: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_agent_action_group#required AwsBedrockagentAgentActionGroup#required}
        */
        readonly required?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_agent_action_group#type AwsBedrockagentAgentActionGroup#type}
        */
        readonly type: string;
    }
    class ParametersPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ParametersProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ParametersProperty | cdktn.IResolvable | undefined);
        private _description?;
        get description(): string;
        set description(value: string);
        resetDescription(): void;
        get descriptionInput(): string | undefined;
        private _mapBlockKey?;
        get mapBlockKey(): string;
        set mapBlockKey(value: string);
        get mapBlockKeyInput(): string | undefined;
        private _required?;
        get required(): boolean | cdktn.IResolvable;
        set required(value: boolean | cdktn.IResolvable);
        resetRequired(): void;
        get requiredInput(): boolean | cdktn.IResolvable | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
    }
    class ParametersPropertyList extends cdktn.ComplexList {
        internalValue?: ParametersProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ParametersPropertyOutputReference;
    }
    interface FunctionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_agent_action_group#description AwsBedrockagentAgentActionGroup#description}
        */
        readonly description?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_agent_action_group#name AwsBedrockagentAgentActionGroup#name}
        */
        readonly name: string;
        /**
        * parameters block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_agent_action_group#parameters AwsBedrockagentAgentActionGroup#parameters}
        */
        readonly parameters?: ParametersProperty[] | cdktn.IResolvable;
    }
    class FunctionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): FunctionsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: FunctionsProperty | cdktn.IResolvable | undefined);
        private _description?;
        get description(): string;
        set description(value: string);
        resetDescription(): void;
        get descriptionInput(): string | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _parameters;
        get parameters(): ParametersPropertyList;
        putParameters(value: ParametersProperty[] | cdktn.IResolvable): void;
        resetParameters(): void;
        get parametersInput(): cdktn.IResolvable | ParametersProperty[] | undefined;
    }
    class FunctionsPropertyList extends cdktn.ComplexList {
        internalValue?: FunctionsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): FunctionsPropertyOutputReference;
    }
    interface MemberFunctionsProperty {
        /**
        * functions block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_agent_action_group#functions AwsBedrockagentAgentActionGroup#functions}
        */
        readonly functions?: FunctionsProperty[] | cdktn.IResolvable;
    }
    class MemberFunctionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): MemberFunctionsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: MemberFunctionsProperty | cdktn.IResolvable | undefined);
        private _functions;
        get functions(): FunctionsPropertyList;
        putFunctions(value: FunctionsProperty[] | cdktn.IResolvable): void;
        resetFunctions(): void;
        get functionsInput(): cdktn.IResolvable | FunctionsProperty[] | undefined;
    }
    class MemberFunctionsPropertyList extends cdktn.ComplexList {
        internalValue?: MemberFunctionsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): MemberFunctionsPropertyOutputReference;
    }
    interface FunctionSchemaProperty {
        /**
        * member_functions block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_agent_action_group#member_functions AwsBedrockagentAgentActionGroup#member_functions}
        */
        readonly memberFunctions?: MemberFunctionsProperty[] | cdktn.IResolvable;
    }
    class FunctionSchemaPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): FunctionSchemaProperty | cdktn.IResolvable | undefined;
        set internalValue(value: FunctionSchemaProperty | cdktn.IResolvable | undefined);
        private _memberFunctions;
        get memberFunctions(): MemberFunctionsPropertyList;
        putMemberFunctions(value: MemberFunctionsProperty[] | cdktn.IResolvable): void;
        resetMemberFunctions(): void;
        get memberFunctionsInput(): cdktn.IResolvable | MemberFunctionsProperty[] | undefined;
    }
    class FunctionSchemaPropertyList extends cdktn.ComplexList {
        internalValue?: FunctionSchemaProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): FunctionSchemaPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_agent_action_group#create AwsBedrockagentAgentActionGroup#create}
        */
        readonly create?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_agent_action_group#update AwsBedrockagentAgentActionGroup#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
