import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsBedrockagentAgentVersionsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/bedrockagent_agent_versions#agent_id DataAwsBedrockagentAgentVersions#agent_id}
    */
    readonly agentId: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/bedrockagent_agent_versions#region DataAwsBedrockagentAgentVersions#region}
    */
    readonly region?: string;
    /**
    * agent_version_summaries block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/bedrockagent_agent_versions#agent_version_summaries DataAwsBedrockagentAgentVersions#agent_version_summaries}
    */
    readonly agentVersionSummaries?: DataAwsBedrockagentAgentVersions.AgentVersionSummariesProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/bedrockagent_agent_versions aws_bedrockagent_agent_versions}
*/
export declare class DataAwsBedrockagentAgentVersions extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_bedrockagent_agent_versions";
    /**
    * Generates CDKTN code for importing a DataAwsBedrockagentAgentVersions resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsBedrockagentAgentVersions to import
    * @param importFromId The id of the existing DataAwsBedrockagentAgentVersions that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/bedrockagent_agent_versions#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsBedrockagentAgentVersions to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/bedrockagent_agent_versions aws_bedrockagent_agent_versions} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsBedrockagentAgentVersionsConfig
    */
    constructor(scope: Construct, id: string, config: DataAwsBedrockagentAgentVersionsConfig);
    private _agentId?;
    get agentId(): string;
    set agentId(value: string);
    get agentIdInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _agentVersionSummaries;
    get agentVersionSummaries(): DataAwsBedrockagentAgentVersions.AgentVersionSummariesPropertyList;
    putAgentVersionSummaries(value: DataAwsBedrockagentAgentVersions.AgentVersionSummariesProperty[] | cdktn.IResolvable): void;
    resetAgentVersionSummaries(): void;
    get agentVersionSummariesInput(): cdktn.IResolvable | DataAwsBedrockagentAgentVersions.AgentVersionSummariesProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataAwsBedrockagentAgentVersionsGuardrailConfigurationPropertyToTerraform(struct?: DataAwsBedrockagentAgentVersions.GuardrailConfigurationProperty | cdktn.IResolvable): any;
export declare function dataAwsBedrockagentAgentVersionsGuardrailConfigurationPropertyToHclTerraform(struct?: DataAwsBedrockagentAgentVersions.GuardrailConfigurationProperty | cdktn.IResolvable): any;
export declare function dataAwsBedrockagentAgentVersionsAgentVersionSummariesPropertyToTerraform(struct?: DataAwsBedrockagentAgentVersions.AgentVersionSummariesProperty | cdktn.IResolvable): any;
export declare function dataAwsBedrockagentAgentVersionsAgentVersionSummariesPropertyToHclTerraform(struct?: DataAwsBedrockagentAgentVersions.AgentVersionSummariesProperty | cdktn.IResolvable): any;
export declare namespace DataAwsBedrockagentAgentVersions {
    interface GuardrailConfigurationProperty {
    }
    class GuardrailConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): GuardrailConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: GuardrailConfigurationProperty | cdktn.IResolvable | undefined);
        get guardrailIdentifier(): string;
        get guardrailVersion(): string;
    }
    class GuardrailConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: GuardrailConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): GuardrailConfigurationPropertyOutputReference;
    }
    interface AgentVersionSummariesProperty {
        /**
        * guardrail_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/bedrockagent_agent_versions#guardrail_configuration DataAwsBedrockagentAgentVersions#guardrail_configuration}
        */
        readonly guardrailConfiguration?: GuardrailConfigurationProperty[] | cdktn.IResolvable;
    }
    class AgentVersionSummariesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AgentVersionSummariesProperty | cdktn.IResolvable | undefined;
        set internalValue(value: AgentVersionSummariesProperty | cdktn.IResolvable | undefined);
        get agentName(): string;
        get agentStatus(): string;
        get agentVersion(): string;
        get createdAt(): string;
        get description(): string;
        get updatedAt(): string;
        private _guardrailConfiguration;
        get guardrailConfiguration(): GuardrailConfigurationPropertyList;
        putGuardrailConfiguration(value: GuardrailConfigurationProperty[] | cdktn.IResolvable): void;
        resetGuardrailConfiguration(): void;
        get guardrailConfigurationInput(): cdktn.IResolvable | GuardrailConfigurationProperty[] | undefined;
    }
    class AgentVersionSummariesPropertyList extends cdktn.ComplexList {
        internalValue?: AgentVersionSummariesProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AgentVersionSummariesPropertyOutputReference;
    }
}
