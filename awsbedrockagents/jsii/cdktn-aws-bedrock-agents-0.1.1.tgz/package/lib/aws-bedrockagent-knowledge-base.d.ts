import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsBedrockagentKnowledgeBaseConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_knowledge_base#description AwsBedrockagentKnowledgeBase#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_knowledge_base#name AwsBedrockagentKnowledgeBase#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_knowledge_base#region AwsBedrockagentKnowledgeBase#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_knowledge_base#role_arn AwsBedrockagentKnowledgeBase#role_arn}
    */
    readonly roleArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_knowledge_base#tags AwsBedrockagentKnowledgeBase#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * knowledge_base_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_knowledge_base#knowledge_base_configuration AwsBedrockagentKnowledgeBase#knowledge_base_configuration}
    */
    readonly knowledgeBaseConfiguration?: AwsBedrockagentKnowledgeBase.KnowledgeBaseConfigurationProperty[] | cdktn.IResolvable;
    /**
    * storage_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_knowledge_base#storage_configuration AwsBedrockagentKnowledgeBase#storage_configuration}
    */
    readonly storageConfiguration?: AwsBedrockagentKnowledgeBase.StorageConfigurationProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_knowledge_base#timeouts AwsBedrockagentKnowledgeBase#timeouts}
    */
    readonly timeouts?: AwsBedrockagentKnowledgeBase.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_knowledge_base aws_bedrockagent_knowledge_base}
*/
export declare class AwsBedrockagentKnowledgeBase extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_bedrockagent_knowledge_base";
    /**
    * Generates CDKTN code for importing a AwsBedrockagentKnowledgeBase resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsBedrockagentKnowledgeBase to import
    * @param importFromId The id of the existing AwsBedrockagentKnowledgeBase that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_knowledge_base#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsBedrockagentKnowledgeBase to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_knowledge_base aws_bedrockagent_knowledge_base} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsBedrockagentKnowledgeBaseConfig
    */
    constructor(scope: Construct, id: string, config: AwsBedrockagentKnowledgeBaseConfig);
    get arn(): string;
    get createdAt(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get failureReasons(): string[];
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _roleArn?;
    get roleArn(): string;
    set roleArn(value: string);
    get roleArnInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    get updatedAt(): string;
    private _knowledgeBaseConfiguration;
    get knowledgeBaseConfiguration(): AwsBedrockagentKnowledgeBase.KnowledgeBaseConfigurationPropertyList;
    putKnowledgeBaseConfiguration(value: AwsBedrockagentKnowledgeBase.KnowledgeBaseConfigurationProperty[] | cdktn.IResolvable): void;
    resetKnowledgeBaseConfiguration(): void;
    get knowledgeBaseConfigurationInput(): cdktn.IResolvable | AwsBedrockagentKnowledgeBase.KnowledgeBaseConfigurationProperty[] | undefined;
    private _storageConfiguration;
    get storageConfiguration(): AwsBedrockagentKnowledgeBase.StorageConfigurationPropertyList;
    putStorageConfiguration(value: AwsBedrockagentKnowledgeBase.StorageConfigurationProperty[] | cdktn.IResolvable): void;
    resetStorageConfiguration(): void;
    get storageConfigurationInput(): cdktn.IResolvable | AwsBedrockagentKnowledgeBase.StorageConfigurationProperty[] | undefined;
    private _timeouts;
    get timeouts(): AwsBedrockagentKnowledgeBase.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsBedrockagentKnowledgeBase.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsBedrockagentKnowledgeBase.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsBedrockagentKnowledgeBaseKendraKnowledgeBaseConfigurationPropertyToTerraform(struct?: AwsBedrockagentKnowledgeBase.KendraKnowledgeBaseConfigurationProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentKnowledgeBaseKendraKnowledgeBaseConfigurationPropertyToHclTerraform(struct?: AwsBedrockagentKnowledgeBase.KendraKnowledgeBaseConfigurationProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentKnowledgeBaseKnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationAudioSegmentationConfigurationPropertyToTerraform(struct?: AwsBedrockagentKnowledgeBase.KnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationAudioSegmentationConfigurationProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentKnowledgeBaseKnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationAudioSegmentationConfigurationPropertyToHclTerraform(struct?: AwsBedrockagentKnowledgeBase.KnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationAudioSegmentationConfigurationProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentKnowledgeBaseKnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationAudioPropertyToTerraform(struct?: AwsBedrockagentKnowledgeBase.KnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationAudioProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentKnowledgeBaseKnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationAudioPropertyToHclTerraform(struct?: AwsBedrockagentKnowledgeBase.KnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationAudioProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentKnowledgeBaseKnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationVideoSegmentationConfigurationPropertyToTerraform(struct?: AwsBedrockagentKnowledgeBase.KnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationVideoSegmentationConfigurationProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentKnowledgeBaseKnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationVideoSegmentationConfigurationPropertyToHclTerraform(struct?: AwsBedrockagentKnowledgeBase.KnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationVideoSegmentationConfigurationProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentKnowledgeBaseKnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationVideoPropertyToTerraform(struct?: AwsBedrockagentKnowledgeBase.KnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationVideoProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentKnowledgeBaseKnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationVideoPropertyToHclTerraform(struct?: AwsBedrockagentKnowledgeBase.KnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationVideoProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentKnowledgeBaseKnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationPropertyToTerraform(struct?: AwsBedrockagentKnowledgeBase.KnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentKnowledgeBaseKnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationPropertyToHclTerraform(struct?: AwsBedrockagentKnowledgeBase.KnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentKnowledgeBaseKnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationEmbeddingModelConfigurationPropertyToTerraform(struct?: AwsBedrockagentKnowledgeBase.KnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationEmbeddingModelConfigurationProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentKnowledgeBaseKnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationEmbeddingModelConfigurationPropertyToHclTerraform(struct?: AwsBedrockagentKnowledgeBase.KnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationEmbeddingModelConfigurationProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentKnowledgeBaseServerSideEncryptionConfigurationPropertyToTerraform(struct?: AwsBedrockagentKnowledgeBase.ServerSideEncryptionConfigurationProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentKnowledgeBaseServerSideEncryptionConfigurationPropertyToHclTerraform(struct?: AwsBedrockagentKnowledgeBase.ServerSideEncryptionConfigurationProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentKnowledgeBaseManagedKnowledgeBaseConfigurationPropertyToTerraform(struct?: AwsBedrockagentKnowledgeBase.ManagedKnowledgeBaseConfigurationProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentKnowledgeBaseManagedKnowledgeBaseConfigurationPropertyToHclTerraform(struct?: AwsBedrockagentKnowledgeBase.ManagedKnowledgeBaseConfigurationProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationQueryEngineConfigurationProvisionedConfigurationAuthConfigurationPropertyToTerraform(struct?: AwsBedrockagentKnowledgeBase.KnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationQueryEngineConfigurationProvisionedConfigurationAuthConfigurationProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationQueryEngineConfigurationProvisionedConfigurationAuthConfigurationPropertyToHclTerraform(struct?: AwsBedrockagentKnowledgeBase.KnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationQueryEngineConfigurationProvisionedConfigurationAuthConfigurationProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentKnowledgeBaseProvisionedConfigurationPropertyToTerraform(struct?: AwsBedrockagentKnowledgeBase.ProvisionedConfigurationProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentKnowledgeBaseProvisionedConfigurationPropertyToHclTerraform(struct?: AwsBedrockagentKnowledgeBase.ProvisionedConfigurationProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationQueryEngineConfigurationServerlessConfigurationAuthConfigurationPropertyToTerraform(struct?: AwsBedrockagentKnowledgeBase.KnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationQueryEngineConfigurationServerlessConfigurationAuthConfigurationProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationQueryEngineConfigurationServerlessConfigurationAuthConfigurationPropertyToHclTerraform(struct?: AwsBedrockagentKnowledgeBase.KnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationQueryEngineConfigurationServerlessConfigurationAuthConfigurationProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentKnowledgeBaseServerlessConfigurationPropertyToTerraform(struct?: AwsBedrockagentKnowledgeBase.ServerlessConfigurationProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentKnowledgeBaseServerlessConfigurationPropertyToHclTerraform(struct?: AwsBedrockagentKnowledgeBase.ServerlessConfigurationProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentKnowledgeBaseQueryEngineConfigurationPropertyToTerraform(struct?: AwsBedrockagentKnowledgeBase.QueryEngineConfigurationProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentKnowledgeBaseQueryEngineConfigurationPropertyToHclTerraform(struct?: AwsBedrockagentKnowledgeBase.QueryEngineConfigurationProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentKnowledgeBaseCuratedQueryPropertyToTerraform(struct?: AwsBedrockagentKnowledgeBase.CuratedQueryProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentKnowledgeBaseCuratedQueryPropertyToHclTerraform(struct?: AwsBedrockagentKnowledgeBase.CuratedQueryProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentKnowledgeBaseColumnPropertyToTerraform(struct?: AwsBedrockagentKnowledgeBase.ColumnProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentKnowledgeBaseColumnPropertyToHclTerraform(struct?: AwsBedrockagentKnowledgeBase.ColumnProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentKnowledgeBaseTablePropertyToTerraform(struct?: AwsBedrockagentKnowledgeBase.TableProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentKnowledgeBaseTablePropertyToHclTerraform(struct?: AwsBedrockagentKnowledgeBase.TableProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentKnowledgeBaseGenerationContextPropertyToTerraform(struct?: AwsBedrockagentKnowledgeBase.GenerationContextProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentKnowledgeBaseGenerationContextPropertyToHclTerraform(struct?: AwsBedrockagentKnowledgeBase.GenerationContextProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentKnowledgeBaseQueryGenerationConfigurationPropertyToTerraform(struct?: AwsBedrockagentKnowledgeBase.QueryGenerationConfigurationProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentKnowledgeBaseQueryGenerationConfigurationPropertyToHclTerraform(struct?: AwsBedrockagentKnowledgeBase.QueryGenerationConfigurationProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentKnowledgeBaseAwsDataCatalogConfigurationPropertyToTerraform(struct?: AwsBedrockagentKnowledgeBase.AwsDataCatalogConfigurationProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentKnowledgeBaseAwsDataCatalogConfigurationPropertyToHclTerraform(struct?: AwsBedrockagentKnowledgeBase.AwsDataCatalogConfigurationProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationStorageConfigurationRedshiftConfigurationPropertyToTerraform(struct?: AwsBedrockagentKnowledgeBase.KnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationStorageConfigurationRedshiftConfigurationProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationStorageConfigurationRedshiftConfigurationPropertyToHclTerraform(struct?: AwsBedrockagentKnowledgeBase.KnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationStorageConfigurationRedshiftConfigurationProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationStorageConfigurationPropertyToTerraform(struct?: AwsBedrockagentKnowledgeBase.KnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationStorageConfigurationProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationStorageConfigurationPropertyToHclTerraform(struct?: AwsBedrockagentKnowledgeBase.KnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationStorageConfigurationProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationPropertyToTerraform(struct?: AwsBedrockagentKnowledgeBase.KnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentKnowledgeBaseKnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationPropertyToHclTerraform(struct?: AwsBedrockagentKnowledgeBase.KnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentKnowledgeBaseSqlKnowledgeBaseConfigurationPropertyToTerraform(struct?: AwsBedrockagentKnowledgeBase.SqlKnowledgeBaseConfigurationProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentKnowledgeBaseSqlKnowledgeBaseConfigurationPropertyToHclTerraform(struct?: AwsBedrockagentKnowledgeBase.SqlKnowledgeBaseConfigurationProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentKnowledgeBaseKnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationAudioSegmentationConfigurationPropertyToTerraform(struct?: AwsBedrockagentKnowledgeBase.KnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationAudioSegmentationConfigurationProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentKnowledgeBaseKnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationAudioSegmentationConfigurationPropertyToHclTerraform(struct?: AwsBedrockagentKnowledgeBase.KnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationAudioSegmentationConfigurationProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentKnowledgeBaseKnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationAudioPropertyToTerraform(struct?: AwsBedrockagentKnowledgeBase.KnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationAudioProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentKnowledgeBaseKnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationAudioPropertyToHclTerraform(struct?: AwsBedrockagentKnowledgeBase.KnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationAudioProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentKnowledgeBaseKnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationVideoSegmentationConfigurationPropertyToTerraform(struct?: AwsBedrockagentKnowledgeBase.KnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationVideoSegmentationConfigurationProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentKnowledgeBaseKnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationVideoSegmentationConfigurationPropertyToHclTerraform(struct?: AwsBedrockagentKnowledgeBase.KnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationVideoSegmentationConfigurationProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentKnowledgeBaseKnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationVideoPropertyToTerraform(struct?: AwsBedrockagentKnowledgeBase.KnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationVideoProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentKnowledgeBaseKnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationVideoPropertyToHclTerraform(struct?: AwsBedrockagentKnowledgeBase.KnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationVideoProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentKnowledgeBaseKnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationPropertyToTerraform(struct?: AwsBedrockagentKnowledgeBase.KnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentKnowledgeBaseKnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationPropertyToHclTerraform(struct?: AwsBedrockagentKnowledgeBase.KnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentKnowledgeBaseKnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationEmbeddingModelConfigurationPropertyToTerraform(struct?: AwsBedrockagentKnowledgeBase.KnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationEmbeddingModelConfigurationProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentKnowledgeBaseKnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationEmbeddingModelConfigurationPropertyToHclTerraform(struct?: AwsBedrockagentKnowledgeBase.KnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationEmbeddingModelConfigurationProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentKnowledgeBaseS3LocationPropertyToTerraform(struct?: AwsBedrockagentKnowledgeBase.S3LocationProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentKnowledgeBaseS3LocationPropertyToHclTerraform(struct?: AwsBedrockagentKnowledgeBase.S3LocationProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentKnowledgeBaseStorageLocationPropertyToTerraform(struct?: AwsBedrockagentKnowledgeBase.StorageLocationProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentKnowledgeBaseStorageLocationPropertyToHclTerraform(struct?: AwsBedrockagentKnowledgeBase.StorageLocationProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentKnowledgeBaseSupplementalDataStorageConfigurationPropertyToTerraform(struct?: AwsBedrockagentKnowledgeBase.SupplementalDataStorageConfigurationProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentKnowledgeBaseSupplementalDataStorageConfigurationPropertyToHclTerraform(struct?: AwsBedrockagentKnowledgeBase.SupplementalDataStorageConfigurationProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentKnowledgeBaseVectorKnowledgeBaseConfigurationPropertyToTerraform(struct?: AwsBedrockagentKnowledgeBase.VectorKnowledgeBaseConfigurationProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentKnowledgeBaseVectorKnowledgeBaseConfigurationPropertyToHclTerraform(struct?: AwsBedrockagentKnowledgeBase.VectorKnowledgeBaseConfigurationProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentKnowledgeBaseKnowledgeBaseConfigurationPropertyToTerraform(struct?: AwsBedrockagentKnowledgeBase.KnowledgeBaseConfigurationProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentKnowledgeBaseKnowledgeBaseConfigurationPropertyToHclTerraform(struct?: AwsBedrockagentKnowledgeBase.KnowledgeBaseConfigurationProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentKnowledgeBaseStorageConfigurationMongoDbAtlasConfigurationFieldMappingPropertyToTerraform(struct?: AwsBedrockagentKnowledgeBase.StorageConfigurationMongoDbAtlasConfigurationFieldMappingProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentKnowledgeBaseStorageConfigurationMongoDbAtlasConfigurationFieldMappingPropertyToHclTerraform(struct?: AwsBedrockagentKnowledgeBase.StorageConfigurationMongoDbAtlasConfigurationFieldMappingProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentKnowledgeBaseMongoDbAtlasConfigurationPropertyToTerraform(struct?: AwsBedrockagentKnowledgeBase.MongoDbAtlasConfigurationProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentKnowledgeBaseMongoDbAtlasConfigurationPropertyToHclTerraform(struct?: AwsBedrockagentKnowledgeBase.MongoDbAtlasConfigurationProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentKnowledgeBaseStorageConfigurationNeptuneAnalyticsConfigurationFieldMappingPropertyToTerraform(struct?: AwsBedrockagentKnowledgeBase.StorageConfigurationNeptuneAnalyticsConfigurationFieldMappingProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentKnowledgeBaseStorageConfigurationNeptuneAnalyticsConfigurationFieldMappingPropertyToHclTerraform(struct?: AwsBedrockagentKnowledgeBase.StorageConfigurationNeptuneAnalyticsConfigurationFieldMappingProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentKnowledgeBaseNeptuneAnalyticsConfigurationPropertyToTerraform(struct?: AwsBedrockagentKnowledgeBase.NeptuneAnalyticsConfigurationProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentKnowledgeBaseNeptuneAnalyticsConfigurationPropertyToHclTerraform(struct?: AwsBedrockagentKnowledgeBase.NeptuneAnalyticsConfigurationProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentKnowledgeBaseStorageConfigurationOpensearchManagedClusterConfigurationFieldMappingPropertyToTerraform(struct?: AwsBedrockagentKnowledgeBase.StorageConfigurationOpensearchManagedClusterConfigurationFieldMappingProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentKnowledgeBaseStorageConfigurationOpensearchManagedClusterConfigurationFieldMappingPropertyToHclTerraform(struct?: AwsBedrockagentKnowledgeBase.StorageConfigurationOpensearchManagedClusterConfigurationFieldMappingProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentKnowledgeBaseOpensearchManagedClusterConfigurationPropertyToTerraform(struct?: AwsBedrockagentKnowledgeBase.OpensearchManagedClusterConfigurationProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentKnowledgeBaseOpensearchManagedClusterConfigurationPropertyToHclTerraform(struct?: AwsBedrockagentKnowledgeBase.OpensearchManagedClusterConfigurationProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentKnowledgeBaseStorageConfigurationOpensearchServerlessConfigurationFieldMappingPropertyToTerraform(struct?: AwsBedrockagentKnowledgeBase.StorageConfigurationOpensearchServerlessConfigurationFieldMappingProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentKnowledgeBaseStorageConfigurationOpensearchServerlessConfigurationFieldMappingPropertyToHclTerraform(struct?: AwsBedrockagentKnowledgeBase.StorageConfigurationOpensearchServerlessConfigurationFieldMappingProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentKnowledgeBaseOpensearchServerlessConfigurationPropertyToTerraform(struct?: AwsBedrockagentKnowledgeBase.OpensearchServerlessConfigurationProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentKnowledgeBaseOpensearchServerlessConfigurationPropertyToHclTerraform(struct?: AwsBedrockagentKnowledgeBase.OpensearchServerlessConfigurationProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentKnowledgeBaseStorageConfigurationPineconeConfigurationFieldMappingPropertyToTerraform(struct?: AwsBedrockagentKnowledgeBase.StorageConfigurationPineconeConfigurationFieldMappingProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentKnowledgeBaseStorageConfigurationPineconeConfigurationFieldMappingPropertyToHclTerraform(struct?: AwsBedrockagentKnowledgeBase.StorageConfigurationPineconeConfigurationFieldMappingProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentKnowledgeBasePineconeConfigurationPropertyToTerraform(struct?: AwsBedrockagentKnowledgeBase.PineconeConfigurationProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentKnowledgeBasePineconeConfigurationPropertyToHclTerraform(struct?: AwsBedrockagentKnowledgeBase.PineconeConfigurationProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentKnowledgeBaseStorageConfigurationRdsConfigurationFieldMappingPropertyToTerraform(struct?: AwsBedrockagentKnowledgeBase.StorageConfigurationRdsConfigurationFieldMappingProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentKnowledgeBaseStorageConfigurationRdsConfigurationFieldMappingPropertyToHclTerraform(struct?: AwsBedrockagentKnowledgeBase.StorageConfigurationRdsConfigurationFieldMappingProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentKnowledgeBaseRdsConfigurationPropertyToTerraform(struct?: AwsBedrockagentKnowledgeBase.RdsConfigurationProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentKnowledgeBaseRdsConfigurationPropertyToHclTerraform(struct?: AwsBedrockagentKnowledgeBase.RdsConfigurationProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentKnowledgeBaseStorageConfigurationRedisEnterpriseCloudConfigurationFieldMappingPropertyToTerraform(struct?: AwsBedrockagentKnowledgeBase.StorageConfigurationRedisEnterpriseCloudConfigurationFieldMappingProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentKnowledgeBaseStorageConfigurationRedisEnterpriseCloudConfigurationFieldMappingPropertyToHclTerraform(struct?: AwsBedrockagentKnowledgeBase.StorageConfigurationRedisEnterpriseCloudConfigurationFieldMappingProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentKnowledgeBaseRedisEnterpriseCloudConfigurationPropertyToTerraform(struct?: AwsBedrockagentKnowledgeBase.RedisEnterpriseCloudConfigurationProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentKnowledgeBaseRedisEnterpriseCloudConfigurationPropertyToHclTerraform(struct?: AwsBedrockagentKnowledgeBase.RedisEnterpriseCloudConfigurationProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentKnowledgeBaseS3VectorsConfigurationPropertyToTerraform(struct?: AwsBedrockagentKnowledgeBase.S3VectorsConfigurationProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentKnowledgeBaseS3VectorsConfigurationPropertyToHclTerraform(struct?: AwsBedrockagentKnowledgeBase.S3VectorsConfigurationProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentKnowledgeBaseStorageConfigurationPropertyToTerraform(struct?: AwsBedrockagentKnowledgeBase.StorageConfigurationProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentKnowledgeBaseStorageConfigurationPropertyToHclTerraform(struct?: AwsBedrockagentKnowledgeBase.StorageConfigurationProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentKnowledgeBaseTimeoutsPropertyToTerraform(struct?: AwsBedrockagentKnowledgeBase.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentKnowledgeBaseTimeoutsPropertyToHclTerraform(struct?: AwsBedrockagentKnowledgeBase.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsBedrockagentKnowledgeBase {
    interface KendraKnowledgeBaseConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_knowledge_base#kendra_index_arn AwsBedrockagentKnowledgeBase#kendra_index_arn}
        */
        readonly kendraIndexArn: string;
    }
    class KendraKnowledgeBaseConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): KendraKnowledgeBaseConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: KendraKnowledgeBaseConfigurationProperty | cdktn.IResolvable | undefined);
        private _kendraIndexArn?;
        get kendraIndexArn(): string;
        set kendraIndexArn(value: string);
        get kendraIndexArnInput(): string | undefined;
    }
    class KendraKnowledgeBaseConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: KendraKnowledgeBaseConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): KendraKnowledgeBaseConfigurationPropertyOutputReference;
    }
    interface KnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationAudioSegmentationConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_knowledge_base#fixed_length_duration AwsBedrockagentKnowledgeBase#fixed_length_duration}
        */
        readonly fixedLengthDuration: number;
    }
    class KnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationAudioSegmentationConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): KnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationAudioSegmentationConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: KnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationAudioSegmentationConfigurationProperty | cdktn.IResolvable | undefined);
        private _fixedLengthDuration?;
        get fixedLengthDuration(): number;
        set fixedLengthDuration(value: number);
        get fixedLengthDurationInput(): number | undefined;
    }
    class KnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationAudioSegmentationConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: KnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationAudioSegmentationConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): KnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationAudioSegmentationConfigurationPropertyOutputReference;
    }
    interface KnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationAudioProperty {
        /**
        * segmentation_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_knowledge_base#segmentation_configuration AwsBedrockagentKnowledgeBase#segmentation_configuration}
        */
        readonly segmentationConfiguration?: KnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationAudioSegmentationConfigurationProperty[] | cdktn.IResolvable;
    }
    class KnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationAudioPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): KnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationAudioProperty | cdktn.IResolvable | undefined;
        set internalValue(value: KnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationAudioProperty | cdktn.IResolvable | undefined);
        private _segmentationConfiguration;
        get segmentationConfiguration(): KnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationAudioSegmentationConfigurationPropertyList;
        putSegmentationConfiguration(value: KnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationAudioSegmentationConfigurationProperty[] | cdktn.IResolvable): void;
        resetSegmentationConfiguration(): void;
        get segmentationConfigurationInput(): cdktn.IResolvable | KnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationAudioSegmentationConfigurationProperty[] | undefined;
    }
    class KnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationAudioPropertyList extends cdktn.ComplexList {
        internalValue?: KnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationAudioProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): KnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationAudioPropertyOutputReference;
    }
    interface KnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationVideoSegmentationConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_knowledge_base#fixed_length_duration AwsBedrockagentKnowledgeBase#fixed_length_duration}
        */
        readonly fixedLengthDuration: number;
    }
    class KnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationVideoSegmentationConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): KnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationVideoSegmentationConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: KnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationVideoSegmentationConfigurationProperty | cdktn.IResolvable | undefined);
        private _fixedLengthDuration?;
        get fixedLengthDuration(): number;
        set fixedLengthDuration(value: number);
        get fixedLengthDurationInput(): number | undefined;
    }
    class KnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationVideoSegmentationConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: KnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationVideoSegmentationConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): KnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationVideoSegmentationConfigurationPropertyOutputReference;
    }
    interface KnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationVideoProperty {
        /**
        * segmentation_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_knowledge_base#segmentation_configuration AwsBedrockagentKnowledgeBase#segmentation_configuration}
        */
        readonly segmentationConfiguration?: KnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationVideoSegmentationConfigurationProperty[] | cdktn.IResolvable;
    }
    class KnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationVideoPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): KnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationVideoProperty | cdktn.IResolvable | undefined;
        set internalValue(value: KnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationVideoProperty | cdktn.IResolvable | undefined);
        private _segmentationConfiguration;
        get segmentationConfiguration(): KnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationVideoSegmentationConfigurationPropertyList;
        putSegmentationConfiguration(value: KnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationVideoSegmentationConfigurationProperty[] | cdktn.IResolvable): void;
        resetSegmentationConfiguration(): void;
        get segmentationConfigurationInput(): cdktn.IResolvable | KnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationVideoSegmentationConfigurationProperty[] | undefined;
    }
    class KnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationVideoPropertyList extends cdktn.ComplexList {
        internalValue?: KnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationVideoProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): KnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationVideoPropertyOutputReference;
    }
    interface KnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_knowledge_base#dimensions AwsBedrockagentKnowledgeBase#dimensions}
        */
        readonly dimensions?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_knowledge_base#embedding_data_type AwsBedrockagentKnowledgeBase#embedding_data_type}
        */
        readonly embeddingDataType?: string;
        /**
        * audio block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_knowledge_base#audio AwsBedrockagentKnowledgeBase#audio}
        */
        readonly audio?: KnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationAudioProperty[] | cdktn.IResolvable;
        /**
        * video block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_knowledge_base#video AwsBedrockagentKnowledgeBase#video}
        */
        readonly video?: KnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationVideoProperty[] | cdktn.IResolvable;
    }
    class KnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): KnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: KnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationProperty | cdktn.IResolvable | undefined);
        private _dimensions?;
        get dimensions(): number;
        set dimensions(value: number);
        resetDimensions(): void;
        get dimensionsInput(): number | undefined;
        private _embeddingDataType?;
        get embeddingDataType(): string;
        set embeddingDataType(value: string);
        resetEmbeddingDataType(): void;
        get embeddingDataTypeInput(): string | undefined;
        private _audio;
        get audio(): KnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationAudioPropertyList;
        putAudio(value: KnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationAudioProperty[] | cdktn.IResolvable): void;
        resetAudio(): void;
        get audioInput(): cdktn.IResolvable | KnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationAudioProperty[] | undefined;
        private _video;
        get video(): KnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationVideoPropertyList;
        putVideo(value: KnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationVideoProperty[] | cdktn.IResolvable): void;
        resetVideo(): void;
        get videoInput(): cdktn.IResolvable | KnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationVideoProperty[] | undefined;
    }
    class KnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: KnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): KnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationPropertyOutputReference;
    }
    interface KnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationEmbeddingModelConfigurationProperty {
        /**
        * bedrock_embedding_model_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_knowledge_base#bedrock_embedding_model_configuration AwsBedrockagentKnowledgeBase#bedrock_embedding_model_configuration}
        */
        readonly bedrockEmbeddingModelConfiguration?: KnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationProperty[] | cdktn.IResolvable;
    }
    class KnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationEmbeddingModelConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): KnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationEmbeddingModelConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: KnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationEmbeddingModelConfigurationProperty | cdktn.IResolvable | undefined);
        private _bedrockEmbeddingModelConfiguration;
        get bedrockEmbeddingModelConfiguration(): KnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationPropertyList;
        putBedrockEmbeddingModelConfiguration(value: KnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationProperty[] | cdktn.IResolvable): void;
        resetBedrockEmbeddingModelConfiguration(): void;
        get bedrockEmbeddingModelConfigurationInput(): cdktn.IResolvable | KnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationProperty[] | undefined;
    }
    class KnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationEmbeddingModelConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: KnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationEmbeddingModelConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): KnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationEmbeddingModelConfigurationPropertyOutputReference;
    }
    interface ServerSideEncryptionConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_knowledge_base#kms_key_arn AwsBedrockagentKnowledgeBase#kms_key_arn}
        */
        readonly kmsKeyArn?: string;
    }
    class ServerSideEncryptionConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ServerSideEncryptionConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ServerSideEncryptionConfigurationProperty | cdktn.IResolvable | undefined);
        private _kmsKeyArn?;
        get kmsKeyArn(): string;
        set kmsKeyArn(value: string);
        resetKmsKeyArn(): void;
        get kmsKeyArnInput(): string | undefined;
    }
    class ServerSideEncryptionConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: ServerSideEncryptionConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ServerSideEncryptionConfigurationPropertyOutputReference;
    }
    interface ManagedKnowledgeBaseConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_knowledge_base#embedding_model_arn AwsBedrockagentKnowledgeBase#embedding_model_arn}
        */
        readonly embeddingModelArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_knowledge_base#embedding_model_type AwsBedrockagentKnowledgeBase#embedding_model_type}
        */
        readonly embeddingModelType?: string;
        /**
        * embedding_model_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_knowledge_base#embedding_model_configuration AwsBedrockagentKnowledgeBase#embedding_model_configuration}
        */
        readonly embeddingModelConfiguration?: KnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationEmbeddingModelConfigurationProperty[] | cdktn.IResolvable;
        /**
        * server_side_encryption_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_knowledge_base#server_side_encryption_configuration AwsBedrockagentKnowledgeBase#server_side_encryption_configuration}
        */
        readonly serverSideEncryptionConfiguration?: ServerSideEncryptionConfigurationProperty[] | cdktn.IResolvable;
    }
    class ManagedKnowledgeBaseConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ManagedKnowledgeBaseConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ManagedKnowledgeBaseConfigurationProperty | cdktn.IResolvable | undefined);
        private _embeddingModelArn?;
        get embeddingModelArn(): string;
        set embeddingModelArn(value: string);
        resetEmbeddingModelArn(): void;
        get embeddingModelArnInput(): string | undefined;
        private _embeddingModelType?;
        get embeddingModelType(): string;
        set embeddingModelType(value: string);
        resetEmbeddingModelType(): void;
        get embeddingModelTypeInput(): string | undefined;
        private _embeddingModelConfiguration;
        get embeddingModelConfiguration(): KnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationEmbeddingModelConfigurationPropertyList;
        putEmbeddingModelConfiguration(value: KnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationEmbeddingModelConfigurationProperty[] | cdktn.IResolvable): void;
        resetEmbeddingModelConfiguration(): void;
        get embeddingModelConfigurationInput(): cdktn.IResolvable | KnowledgeBaseConfigurationManagedKnowledgeBaseConfigurationEmbeddingModelConfigurationProperty[] | undefined;
        private _serverSideEncryptionConfiguration;
        get serverSideEncryptionConfiguration(): ServerSideEncryptionConfigurationPropertyList;
        putServerSideEncryptionConfiguration(value: ServerSideEncryptionConfigurationProperty[] | cdktn.IResolvable): void;
        resetServerSideEncryptionConfiguration(): void;
        get serverSideEncryptionConfigurationInput(): cdktn.IResolvable | ServerSideEncryptionConfigurationProperty[] | undefined;
    }
    class ManagedKnowledgeBaseConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: ManagedKnowledgeBaseConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ManagedKnowledgeBaseConfigurationPropertyOutputReference;
    }
    interface KnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationQueryEngineConfigurationProvisionedConfigurationAuthConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_knowledge_base#database_user AwsBedrockagentKnowledgeBase#database_user}
        */
        readonly databaseUser?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_knowledge_base#type AwsBedrockagentKnowledgeBase#type}
        */
        readonly type: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_knowledge_base#username_password_secret_arn AwsBedrockagentKnowledgeBase#username_password_secret_arn}
        */
        readonly usernamePasswordSecretArn?: string;
    }
    class KnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationQueryEngineConfigurationProvisionedConfigurationAuthConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): KnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationQueryEngineConfigurationProvisionedConfigurationAuthConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: KnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationQueryEngineConfigurationProvisionedConfigurationAuthConfigurationProperty | cdktn.IResolvable | undefined);
        private _databaseUser?;
        get databaseUser(): string;
        set databaseUser(value: string);
        resetDatabaseUser(): void;
        get databaseUserInput(): string | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
        private _usernamePasswordSecretArn?;
        get usernamePasswordSecretArn(): string;
        set usernamePasswordSecretArn(value: string);
        resetUsernamePasswordSecretArn(): void;
        get usernamePasswordSecretArnInput(): string | undefined;
    }
    class KnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationQueryEngineConfigurationProvisionedConfigurationAuthConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: KnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationQueryEngineConfigurationProvisionedConfigurationAuthConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): KnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationQueryEngineConfigurationProvisionedConfigurationAuthConfigurationPropertyOutputReference;
    }
    interface ProvisionedConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_knowledge_base#cluster_identifier AwsBedrockagentKnowledgeBase#cluster_identifier}
        */
        readonly clusterIdentifier: string;
        /**
        * auth_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_knowledge_base#auth_configuration AwsBedrockagentKnowledgeBase#auth_configuration}
        */
        readonly authConfiguration?: KnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationQueryEngineConfigurationProvisionedConfigurationAuthConfigurationProperty[] | cdktn.IResolvable;
    }
    class ProvisionedConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ProvisionedConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ProvisionedConfigurationProperty | cdktn.IResolvable | undefined);
        private _clusterIdentifier?;
        get clusterIdentifier(): string;
        set clusterIdentifier(value: string);
        get clusterIdentifierInput(): string | undefined;
        private _authConfiguration;
        get authConfiguration(): KnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationQueryEngineConfigurationProvisionedConfigurationAuthConfigurationPropertyList;
        putAuthConfiguration(value: KnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationQueryEngineConfigurationProvisionedConfigurationAuthConfigurationProperty[] | cdktn.IResolvable): void;
        resetAuthConfiguration(): void;
        get authConfigurationInput(): cdktn.IResolvable | KnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationQueryEngineConfigurationProvisionedConfigurationAuthConfigurationProperty[] | undefined;
    }
    class ProvisionedConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: ProvisionedConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ProvisionedConfigurationPropertyOutputReference;
    }
    interface KnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationQueryEngineConfigurationServerlessConfigurationAuthConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_knowledge_base#type AwsBedrockagentKnowledgeBase#type}
        */
        readonly type: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_knowledge_base#username_password_secret_arn AwsBedrockagentKnowledgeBase#username_password_secret_arn}
        */
        readonly usernamePasswordSecretArn?: string;
    }
    class KnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationQueryEngineConfigurationServerlessConfigurationAuthConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): KnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationQueryEngineConfigurationServerlessConfigurationAuthConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: KnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationQueryEngineConfigurationServerlessConfigurationAuthConfigurationProperty | cdktn.IResolvable | undefined);
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
        private _usernamePasswordSecretArn?;
        get usernamePasswordSecretArn(): string;
        set usernamePasswordSecretArn(value: string);
        resetUsernamePasswordSecretArn(): void;
        get usernamePasswordSecretArnInput(): string | undefined;
    }
    class KnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationQueryEngineConfigurationServerlessConfigurationAuthConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: KnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationQueryEngineConfigurationServerlessConfigurationAuthConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): KnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationQueryEngineConfigurationServerlessConfigurationAuthConfigurationPropertyOutputReference;
    }
    interface ServerlessConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_knowledge_base#workgroup_arn AwsBedrockagentKnowledgeBase#workgroup_arn}
        */
        readonly workgroupArn: string;
        /**
        * auth_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_knowledge_base#auth_configuration AwsBedrockagentKnowledgeBase#auth_configuration}
        */
        readonly authConfiguration?: KnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationQueryEngineConfigurationServerlessConfigurationAuthConfigurationProperty[] | cdktn.IResolvable;
    }
    class ServerlessConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ServerlessConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ServerlessConfigurationProperty | cdktn.IResolvable | undefined);
        private _workgroupArn?;
        get workgroupArn(): string;
        set workgroupArn(value: string);
        get workgroupArnInput(): string | undefined;
        private _authConfiguration;
        get authConfiguration(): KnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationQueryEngineConfigurationServerlessConfigurationAuthConfigurationPropertyList;
        putAuthConfiguration(value: KnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationQueryEngineConfigurationServerlessConfigurationAuthConfigurationProperty[] | cdktn.IResolvable): void;
        resetAuthConfiguration(): void;
        get authConfigurationInput(): cdktn.IResolvable | KnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationQueryEngineConfigurationServerlessConfigurationAuthConfigurationProperty[] | undefined;
    }
    class ServerlessConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: ServerlessConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ServerlessConfigurationPropertyOutputReference;
    }
    interface QueryEngineConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_knowledge_base#type AwsBedrockagentKnowledgeBase#type}
        */
        readonly type: string;
        /**
        * provisioned_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_knowledge_base#provisioned_configuration AwsBedrockagentKnowledgeBase#provisioned_configuration}
        */
        readonly provisionedConfiguration?: ProvisionedConfigurationProperty[] | cdktn.IResolvable;
        /**
        * serverless_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_knowledge_base#serverless_configuration AwsBedrockagentKnowledgeBase#serverless_configuration}
        */
        readonly serverlessConfiguration?: ServerlessConfigurationProperty[] | cdktn.IResolvable;
    }
    class QueryEngineConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): QueryEngineConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: QueryEngineConfigurationProperty | cdktn.IResolvable | undefined);
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
        private _provisionedConfiguration;
        get provisionedConfiguration(): ProvisionedConfigurationPropertyList;
        putProvisionedConfiguration(value: ProvisionedConfigurationProperty[] | cdktn.IResolvable): void;
        resetProvisionedConfiguration(): void;
        get provisionedConfigurationInput(): cdktn.IResolvable | ProvisionedConfigurationProperty[] | undefined;
        private _serverlessConfiguration;
        get serverlessConfiguration(): ServerlessConfigurationPropertyList;
        putServerlessConfiguration(value: ServerlessConfigurationProperty[] | cdktn.IResolvable): void;
        resetServerlessConfiguration(): void;
        get serverlessConfigurationInput(): cdktn.IResolvable | ServerlessConfigurationProperty[] | undefined;
    }
    class QueryEngineConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: QueryEngineConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): QueryEngineConfigurationPropertyOutputReference;
    }
    interface CuratedQueryProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_knowledge_base#natural_language AwsBedrockagentKnowledgeBase#natural_language}
        */
        readonly naturalLanguage: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_knowledge_base#sql AwsBedrockagentKnowledgeBase#sql}
        */
        readonly sql: string;
    }
    class CuratedQueryPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CuratedQueryProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CuratedQueryProperty | cdktn.IResolvable | undefined);
        private _naturalLanguage?;
        get naturalLanguage(): string;
        set naturalLanguage(value: string);
        get naturalLanguageInput(): string | undefined;
        private _sql?;
        get sql(): string;
        set sql(value: string);
        get sqlInput(): string | undefined;
    }
    class CuratedQueryPropertyList extends cdktn.ComplexList {
        internalValue?: CuratedQueryProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CuratedQueryPropertyOutputReference;
    }
    interface ColumnProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_knowledge_base#description AwsBedrockagentKnowledgeBase#description}
        */
        readonly description?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_knowledge_base#inclusion AwsBedrockagentKnowledgeBase#inclusion}
        */
        readonly inclusion?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_knowledge_base#name AwsBedrockagentKnowledgeBase#name}
        */
        readonly name?: string;
    }
    class ColumnPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ColumnProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ColumnProperty | cdktn.IResolvable | undefined);
        private _description?;
        get description(): string;
        set description(value: string);
        resetDescription(): void;
        get descriptionInput(): string | undefined;
        private _inclusion?;
        get inclusion(): string;
        set inclusion(value: string);
        resetInclusion(): void;
        get inclusionInput(): string | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        resetName(): void;
        get nameInput(): string | undefined;
    }
    class ColumnPropertyList extends cdktn.ComplexList {
        internalValue?: ColumnProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ColumnPropertyOutputReference;
    }
    interface TableProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_knowledge_base#description AwsBedrockagentKnowledgeBase#description}
        */
        readonly description?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_knowledge_base#inclusion AwsBedrockagentKnowledgeBase#inclusion}
        */
        readonly inclusion?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_knowledge_base#name AwsBedrockagentKnowledgeBase#name}
        */
        readonly name: string;
        /**
        * column block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_knowledge_base#column AwsBedrockagentKnowledgeBase#column}
        */
        readonly column?: ColumnProperty[] | cdktn.IResolvable;
    }
    class TablePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TableProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TableProperty | cdktn.IResolvable | undefined);
        private _description?;
        get description(): string;
        set description(value: string);
        resetDescription(): void;
        get descriptionInput(): string | undefined;
        private _inclusion?;
        get inclusion(): string;
        set inclusion(value: string);
        resetInclusion(): void;
        get inclusionInput(): string | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _column;
        get column(): ColumnPropertyList;
        putColumn(value: ColumnProperty[] | cdktn.IResolvable): void;
        resetColumn(): void;
        get columnInput(): cdktn.IResolvable | ColumnProperty[] | undefined;
    }
    class TablePropertyList extends cdktn.ComplexList {
        internalValue?: TableProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TablePropertyOutputReference;
    }
    interface GenerationContextProperty {
        /**
        * curated_query block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_knowledge_base#curated_query AwsBedrockagentKnowledgeBase#curated_query}
        */
        readonly curatedQuery?: CuratedQueryProperty[] | cdktn.IResolvable;
        /**
        * table block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_knowledge_base#table AwsBedrockagentKnowledgeBase#table}
        */
        readonly table?: TableProperty[] | cdktn.IResolvable;
    }
    class GenerationContextPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): GenerationContextProperty | cdktn.IResolvable | undefined;
        set internalValue(value: GenerationContextProperty | cdktn.IResolvable | undefined);
        private _curatedQuery;
        get curatedQuery(): CuratedQueryPropertyList;
        putCuratedQuery(value: CuratedQueryProperty[] | cdktn.IResolvable): void;
        resetCuratedQuery(): void;
        get curatedQueryInput(): cdktn.IResolvable | CuratedQueryProperty[] | undefined;
        private _table;
        get table(): TablePropertyList;
        putTable(value: TableProperty[] | cdktn.IResolvable): void;
        resetTable(): void;
        get tableInput(): cdktn.IResolvable | TableProperty[] | undefined;
    }
    class GenerationContextPropertyList extends cdktn.ComplexList {
        internalValue?: GenerationContextProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): GenerationContextPropertyOutputReference;
    }
    interface QueryGenerationConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_knowledge_base#execution_timeout_seconds AwsBedrockagentKnowledgeBase#execution_timeout_seconds}
        */
        readonly executionTimeoutSeconds?: number;
        /**
        * generation_context block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_knowledge_base#generation_context AwsBedrockagentKnowledgeBase#generation_context}
        */
        readonly generationContext?: GenerationContextProperty[] | cdktn.IResolvable;
    }
    class QueryGenerationConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): QueryGenerationConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: QueryGenerationConfigurationProperty | cdktn.IResolvable | undefined);
        private _executionTimeoutSeconds?;
        get executionTimeoutSeconds(): number;
        set executionTimeoutSeconds(value: number);
        resetExecutionTimeoutSeconds(): void;
        get executionTimeoutSecondsInput(): number | undefined;
        private _generationContext;
        get generationContext(): GenerationContextPropertyList;
        putGenerationContext(value: GenerationContextProperty[] | cdktn.IResolvable): void;
        resetGenerationContext(): void;
        get generationContextInput(): cdktn.IResolvable | GenerationContextProperty[] | undefined;
    }
    class QueryGenerationConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: QueryGenerationConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): QueryGenerationConfigurationPropertyOutputReference;
    }
    interface AwsDataCatalogConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_knowledge_base#table_names AwsBedrockagentKnowledgeBase#table_names}
        */
        readonly tableNames: string[];
    }
    class AwsDataCatalogConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AwsDataCatalogConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: AwsDataCatalogConfigurationProperty | cdktn.IResolvable | undefined);
        private _tableNames?;
        get tableNames(): string[];
        set tableNames(value: string[]);
        get tableNamesInput(): string[] | undefined;
    }
    class AwsDataCatalogConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: AwsDataCatalogConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AwsDataCatalogConfigurationPropertyOutputReference;
    }
    interface KnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationStorageConfigurationRedshiftConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_knowledge_base#database_name AwsBedrockagentKnowledgeBase#database_name}
        */
        readonly databaseName: string;
    }
    class KnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationStorageConfigurationRedshiftConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): KnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationStorageConfigurationRedshiftConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: KnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationStorageConfigurationRedshiftConfigurationProperty | cdktn.IResolvable | undefined);
        private _databaseName?;
        get databaseName(): string;
        set databaseName(value: string);
        get databaseNameInput(): string | undefined;
    }
    class KnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationStorageConfigurationRedshiftConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: KnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationStorageConfigurationRedshiftConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): KnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationStorageConfigurationRedshiftConfigurationPropertyOutputReference;
    }
    interface KnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationStorageConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_knowledge_base#type AwsBedrockagentKnowledgeBase#type}
        */
        readonly type: string;
        /**
        * aws_data_catalog_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_knowledge_base#aws_data_catalog_configuration AwsBedrockagentKnowledgeBase#aws_data_catalog_configuration}
        */
        readonly awsDataCatalogConfiguration?: AwsDataCatalogConfigurationProperty[] | cdktn.IResolvable;
        /**
        * redshift_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_knowledge_base#redshift_configuration AwsBedrockagentKnowledgeBase#redshift_configuration}
        */
        readonly redshiftConfiguration?: KnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationStorageConfigurationRedshiftConfigurationProperty[] | cdktn.IResolvable;
    }
    class KnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationStorageConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): KnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationStorageConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: KnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationStorageConfigurationProperty | cdktn.IResolvable | undefined);
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
        private _awsDataCatalogConfiguration;
        get awsDataCatalogConfiguration(): AwsDataCatalogConfigurationPropertyList;
        putAwsDataCatalogConfiguration(value: AwsDataCatalogConfigurationProperty[] | cdktn.IResolvable): void;
        resetAwsDataCatalogConfiguration(): void;
        get awsDataCatalogConfigurationInput(): cdktn.IResolvable | AwsDataCatalogConfigurationProperty[] | undefined;
        private _redshiftConfiguration;
        get redshiftConfiguration(): KnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationStorageConfigurationRedshiftConfigurationPropertyList;
        putRedshiftConfiguration(value: KnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationStorageConfigurationRedshiftConfigurationProperty[] | cdktn.IResolvable): void;
        resetRedshiftConfiguration(): void;
        get redshiftConfigurationInput(): cdktn.IResolvable | KnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationStorageConfigurationRedshiftConfigurationProperty[] | undefined;
    }
    class KnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationStorageConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: KnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationStorageConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): KnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationStorageConfigurationPropertyOutputReference;
    }
    interface KnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationProperty {
        /**
        * query_engine_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_knowledge_base#query_engine_configuration AwsBedrockagentKnowledgeBase#query_engine_configuration}
        */
        readonly queryEngineConfiguration?: QueryEngineConfigurationProperty[] | cdktn.IResolvable;
        /**
        * query_generation_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_knowledge_base#query_generation_configuration AwsBedrockagentKnowledgeBase#query_generation_configuration}
        */
        readonly queryGenerationConfiguration?: QueryGenerationConfigurationProperty[] | cdktn.IResolvable;
        /**
        * storage_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_knowledge_base#storage_configuration AwsBedrockagentKnowledgeBase#storage_configuration}
        */
        readonly storageConfiguration?: KnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationStorageConfigurationProperty[] | cdktn.IResolvable;
    }
    class KnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): KnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: KnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationProperty | cdktn.IResolvable | undefined);
        private _queryEngineConfiguration;
        get queryEngineConfiguration(): QueryEngineConfigurationPropertyList;
        putQueryEngineConfiguration(value: QueryEngineConfigurationProperty[] | cdktn.IResolvable): void;
        resetQueryEngineConfiguration(): void;
        get queryEngineConfigurationInput(): cdktn.IResolvable | QueryEngineConfigurationProperty[] | undefined;
        private _queryGenerationConfiguration;
        get queryGenerationConfiguration(): QueryGenerationConfigurationPropertyList;
        putQueryGenerationConfiguration(value: QueryGenerationConfigurationProperty[] | cdktn.IResolvable): void;
        resetQueryGenerationConfiguration(): void;
        get queryGenerationConfigurationInput(): cdktn.IResolvable | QueryGenerationConfigurationProperty[] | undefined;
        private _storageConfiguration;
        get storageConfiguration(): KnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationStorageConfigurationPropertyList;
        putStorageConfiguration(value: KnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationStorageConfigurationProperty[] | cdktn.IResolvable): void;
        resetStorageConfiguration(): void;
        get storageConfigurationInput(): cdktn.IResolvable | KnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationStorageConfigurationProperty[] | undefined;
    }
    class KnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: KnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): KnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationPropertyOutputReference;
    }
    interface SqlKnowledgeBaseConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_knowledge_base#type AwsBedrockagentKnowledgeBase#type}
        */
        readonly type: string;
        /**
        * redshift_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_knowledge_base#redshift_configuration AwsBedrockagentKnowledgeBase#redshift_configuration}
        */
        readonly redshiftConfiguration?: KnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationProperty[] | cdktn.IResolvable;
    }
    class SqlKnowledgeBaseConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SqlKnowledgeBaseConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SqlKnowledgeBaseConfigurationProperty | cdktn.IResolvable | undefined);
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
        private _redshiftConfiguration;
        get redshiftConfiguration(): KnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationPropertyList;
        putRedshiftConfiguration(value: KnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationProperty[] | cdktn.IResolvable): void;
        resetRedshiftConfiguration(): void;
        get redshiftConfigurationInput(): cdktn.IResolvable | KnowledgeBaseConfigurationSqlKnowledgeBaseConfigurationRedshiftConfigurationProperty[] | undefined;
    }
    class SqlKnowledgeBaseConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: SqlKnowledgeBaseConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SqlKnowledgeBaseConfigurationPropertyOutputReference;
    }
    interface KnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationAudioSegmentationConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_knowledge_base#fixed_length_duration AwsBedrockagentKnowledgeBase#fixed_length_duration}
        */
        readonly fixedLengthDuration: number;
    }
    class KnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationAudioSegmentationConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): KnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationAudioSegmentationConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: KnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationAudioSegmentationConfigurationProperty | cdktn.IResolvable | undefined);
        private _fixedLengthDuration?;
        get fixedLengthDuration(): number;
        set fixedLengthDuration(value: number);
        get fixedLengthDurationInput(): number | undefined;
    }
    class KnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationAudioSegmentationConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: KnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationAudioSegmentationConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): KnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationAudioSegmentationConfigurationPropertyOutputReference;
    }
    interface KnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationAudioProperty {
        /**
        * segmentation_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_knowledge_base#segmentation_configuration AwsBedrockagentKnowledgeBase#segmentation_configuration}
        */
        readonly segmentationConfiguration?: KnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationAudioSegmentationConfigurationProperty[] | cdktn.IResolvable;
    }
    class KnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationAudioPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): KnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationAudioProperty | cdktn.IResolvable | undefined;
        set internalValue(value: KnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationAudioProperty | cdktn.IResolvable | undefined);
        private _segmentationConfiguration;
        get segmentationConfiguration(): KnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationAudioSegmentationConfigurationPropertyList;
        putSegmentationConfiguration(value: KnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationAudioSegmentationConfigurationProperty[] | cdktn.IResolvable): void;
        resetSegmentationConfiguration(): void;
        get segmentationConfigurationInput(): cdktn.IResolvable | KnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationAudioSegmentationConfigurationProperty[] | undefined;
    }
    class KnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationAudioPropertyList extends cdktn.ComplexList {
        internalValue?: KnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationAudioProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): KnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationAudioPropertyOutputReference;
    }
    interface KnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationVideoSegmentationConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_knowledge_base#fixed_length_duration AwsBedrockagentKnowledgeBase#fixed_length_duration}
        */
        readonly fixedLengthDuration: number;
    }
    class KnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationVideoSegmentationConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): KnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationVideoSegmentationConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: KnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationVideoSegmentationConfigurationProperty | cdktn.IResolvable | undefined);
        private _fixedLengthDuration?;
        get fixedLengthDuration(): number;
        set fixedLengthDuration(value: number);
        get fixedLengthDurationInput(): number | undefined;
    }
    class KnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationVideoSegmentationConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: KnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationVideoSegmentationConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): KnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationVideoSegmentationConfigurationPropertyOutputReference;
    }
    interface KnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationVideoProperty {
        /**
        * segmentation_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_knowledge_base#segmentation_configuration AwsBedrockagentKnowledgeBase#segmentation_configuration}
        */
        readonly segmentationConfiguration?: KnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationVideoSegmentationConfigurationProperty[] | cdktn.IResolvable;
    }
    class KnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationVideoPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): KnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationVideoProperty | cdktn.IResolvable | undefined;
        set internalValue(value: KnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationVideoProperty | cdktn.IResolvable | undefined);
        private _segmentationConfiguration;
        get segmentationConfiguration(): KnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationVideoSegmentationConfigurationPropertyList;
        putSegmentationConfiguration(value: KnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationVideoSegmentationConfigurationProperty[] | cdktn.IResolvable): void;
        resetSegmentationConfiguration(): void;
        get segmentationConfigurationInput(): cdktn.IResolvable | KnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationVideoSegmentationConfigurationProperty[] | undefined;
    }
    class KnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationVideoPropertyList extends cdktn.ComplexList {
        internalValue?: KnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationVideoProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): KnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationVideoPropertyOutputReference;
    }
    interface KnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_knowledge_base#dimensions AwsBedrockagentKnowledgeBase#dimensions}
        */
        readonly dimensions?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_knowledge_base#embedding_data_type AwsBedrockagentKnowledgeBase#embedding_data_type}
        */
        readonly embeddingDataType?: string;
        /**
        * audio block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_knowledge_base#audio AwsBedrockagentKnowledgeBase#audio}
        */
        readonly audio?: KnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationAudioProperty[] | cdktn.IResolvable;
        /**
        * video block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_knowledge_base#video AwsBedrockagentKnowledgeBase#video}
        */
        readonly video?: KnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationVideoProperty[] | cdktn.IResolvable;
    }
    class KnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): KnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: KnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationProperty | cdktn.IResolvable | undefined);
        private _dimensions?;
        get dimensions(): number;
        set dimensions(value: number);
        resetDimensions(): void;
        get dimensionsInput(): number | undefined;
        private _embeddingDataType?;
        get embeddingDataType(): string;
        set embeddingDataType(value: string);
        resetEmbeddingDataType(): void;
        get embeddingDataTypeInput(): string | undefined;
        private _audio;
        get audio(): KnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationAudioPropertyList;
        putAudio(value: KnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationAudioProperty[] | cdktn.IResolvable): void;
        resetAudio(): void;
        get audioInput(): cdktn.IResolvable | KnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationAudioProperty[] | undefined;
        private _video;
        get video(): KnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationVideoPropertyList;
        putVideo(value: KnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationVideoProperty[] | cdktn.IResolvable): void;
        resetVideo(): void;
        get videoInput(): cdktn.IResolvable | KnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationVideoProperty[] | undefined;
    }
    class KnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: KnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): KnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationPropertyOutputReference;
    }
    interface KnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationEmbeddingModelConfigurationProperty {
        /**
        * bedrock_embedding_model_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_knowledge_base#bedrock_embedding_model_configuration AwsBedrockagentKnowledgeBase#bedrock_embedding_model_configuration}
        */
        readonly bedrockEmbeddingModelConfiguration?: KnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationProperty[] | cdktn.IResolvable;
    }
    class KnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationEmbeddingModelConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): KnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationEmbeddingModelConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: KnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationEmbeddingModelConfigurationProperty | cdktn.IResolvable | undefined);
        private _bedrockEmbeddingModelConfiguration;
        get bedrockEmbeddingModelConfiguration(): KnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationPropertyList;
        putBedrockEmbeddingModelConfiguration(value: KnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationProperty[] | cdktn.IResolvable): void;
        resetBedrockEmbeddingModelConfiguration(): void;
        get bedrockEmbeddingModelConfigurationInput(): cdktn.IResolvable | KnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationEmbeddingModelConfigurationBedrockEmbeddingModelConfigurationProperty[] | undefined;
    }
    class KnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationEmbeddingModelConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: KnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationEmbeddingModelConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): KnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationEmbeddingModelConfigurationPropertyOutputReference;
    }
    interface S3LocationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_knowledge_base#uri AwsBedrockagentKnowledgeBase#uri}
        */
        readonly uri: string;
    }
    class S3LocationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): S3LocationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: S3LocationProperty | cdktn.IResolvable | undefined);
        private _uri?;
        get uri(): string;
        set uri(value: string);
        get uriInput(): string | undefined;
    }
    class S3LocationPropertyList extends cdktn.ComplexList {
        internalValue?: S3LocationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): S3LocationPropertyOutputReference;
    }
    interface StorageLocationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_knowledge_base#type AwsBedrockagentKnowledgeBase#type}
        */
        readonly type: string;
        /**
        * s3_location block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_knowledge_base#s3_location AwsBedrockagentKnowledgeBase#s3_location}
        */
        readonly s3Location?: S3LocationProperty[] | cdktn.IResolvable;
    }
    class StorageLocationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): StorageLocationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: StorageLocationProperty | cdktn.IResolvable | undefined);
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
        private _s3Location;
        get s3Location(): S3LocationPropertyList;
        putS3Location(value: S3LocationProperty[] | cdktn.IResolvable): void;
        resetS3Location(): void;
        get s3LocationInput(): cdktn.IResolvable | S3LocationProperty[] | undefined;
    }
    class StorageLocationPropertyList extends cdktn.ComplexList {
        internalValue?: StorageLocationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): StorageLocationPropertyOutputReference;
    }
    interface SupplementalDataStorageConfigurationProperty {
        /**
        * storage_location block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_knowledge_base#storage_location AwsBedrockagentKnowledgeBase#storage_location}
        */
        readonly storageLocation?: StorageLocationProperty[] | cdktn.IResolvable;
    }
    class SupplementalDataStorageConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SupplementalDataStorageConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SupplementalDataStorageConfigurationProperty | cdktn.IResolvable | undefined);
        private _storageLocation;
        get storageLocation(): StorageLocationPropertyList;
        putStorageLocation(value: StorageLocationProperty[] | cdktn.IResolvable): void;
        resetStorageLocation(): void;
        get storageLocationInput(): cdktn.IResolvable | StorageLocationProperty[] | undefined;
    }
    class SupplementalDataStorageConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: SupplementalDataStorageConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SupplementalDataStorageConfigurationPropertyOutputReference;
    }
    interface VectorKnowledgeBaseConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_knowledge_base#embedding_model_arn AwsBedrockagentKnowledgeBase#embedding_model_arn}
        */
        readonly embeddingModelArn: string;
        /**
        * embedding_model_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_knowledge_base#embedding_model_configuration AwsBedrockagentKnowledgeBase#embedding_model_configuration}
        */
        readonly embeddingModelConfiguration?: KnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationEmbeddingModelConfigurationProperty[] | cdktn.IResolvable;
        /**
        * supplemental_data_storage_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_knowledge_base#supplemental_data_storage_configuration AwsBedrockagentKnowledgeBase#supplemental_data_storage_configuration}
        */
        readonly supplementalDataStorageConfiguration?: SupplementalDataStorageConfigurationProperty[] | cdktn.IResolvable;
    }
    class VectorKnowledgeBaseConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): VectorKnowledgeBaseConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: VectorKnowledgeBaseConfigurationProperty | cdktn.IResolvable | undefined);
        private _embeddingModelArn?;
        get embeddingModelArn(): string;
        set embeddingModelArn(value: string);
        get embeddingModelArnInput(): string | undefined;
        private _embeddingModelConfiguration;
        get embeddingModelConfiguration(): KnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationEmbeddingModelConfigurationPropertyList;
        putEmbeddingModelConfiguration(value: KnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationEmbeddingModelConfigurationProperty[] | cdktn.IResolvable): void;
        resetEmbeddingModelConfiguration(): void;
        get embeddingModelConfigurationInput(): cdktn.IResolvable | KnowledgeBaseConfigurationVectorKnowledgeBaseConfigurationEmbeddingModelConfigurationProperty[] | undefined;
        private _supplementalDataStorageConfiguration;
        get supplementalDataStorageConfiguration(): SupplementalDataStorageConfigurationPropertyList;
        putSupplementalDataStorageConfiguration(value: SupplementalDataStorageConfigurationProperty[] | cdktn.IResolvable): void;
        resetSupplementalDataStorageConfiguration(): void;
        get supplementalDataStorageConfigurationInput(): cdktn.IResolvable | SupplementalDataStorageConfigurationProperty[] | undefined;
    }
    class VectorKnowledgeBaseConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: VectorKnowledgeBaseConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): VectorKnowledgeBaseConfigurationPropertyOutputReference;
    }
    interface KnowledgeBaseConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_knowledge_base#type AwsBedrockagentKnowledgeBase#type}
        */
        readonly type: string;
        /**
        * kendra_knowledge_base_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_knowledge_base#kendra_knowledge_base_configuration AwsBedrockagentKnowledgeBase#kendra_knowledge_base_configuration}
        */
        readonly kendraKnowledgeBaseConfiguration?: KendraKnowledgeBaseConfigurationProperty[] | cdktn.IResolvable;
        /**
        * managed_knowledge_base_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_knowledge_base#managed_knowledge_base_configuration AwsBedrockagentKnowledgeBase#managed_knowledge_base_configuration}
        */
        readonly managedKnowledgeBaseConfiguration?: ManagedKnowledgeBaseConfigurationProperty[] | cdktn.IResolvable;
        /**
        * sql_knowledge_base_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_knowledge_base#sql_knowledge_base_configuration AwsBedrockagentKnowledgeBase#sql_knowledge_base_configuration}
        */
        readonly sqlKnowledgeBaseConfiguration?: SqlKnowledgeBaseConfigurationProperty[] | cdktn.IResolvable;
        /**
        * vector_knowledge_base_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_knowledge_base#vector_knowledge_base_configuration AwsBedrockagentKnowledgeBase#vector_knowledge_base_configuration}
        */
        readonly vectorKnowledgeBaseConfiguration?: VectorKnowledgeBaseConfigurationProperty[] | cdktn.IResolvable;
    }
    class KnowledgeBaseConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): KnowledgeBaseConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: KnowledgeBaseConfigurationProperty | cdktn.IResolvable | undefined);
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
        private _kendraKnowledgeBaseConfiguration;
        get kendraKnowledgeBaseConfiguration(): KendraKnowledgeBaseConfigurationPropertyList;
        putKendraKnowledgeBaseConfiguration(value: KendraKnowledgeBaseConfigurationProperty[] | cdktn.IResolvable): void;
        resetKendraKnowledgeBaseConfiguration(): void;
        get kendraKnowledgeBaseConfigurationInput(): cdktn.IResolvable | KendraKnowledgeBaseConfigurationProperty[] | undefined;
        private _managedKnowledgeBaseConfiguration;
        get managedKnowledgeBaseConfiguration(): ManagedKnowledgeBaseConfigurationPropertyList;
        putManagedKnowledgeBaseConfiguration(value: ManagedKnowledgeBaseConfigurationProperty[] | cdktn.IResolvable): void;
        resetManagedKnowledgeBaseConfiguration(): void;
        get managedKnowledgeBaseConfigurationInput(): cdktn.IResolvable | ManagedKnowledgeBaseConfigurationProperty[] | undefined;
        private _sqlKnowledgeBaseConfiguration;
        get sqlKnowledgeBaseConfiguration(): SqlKnowledgeBaseConfigurationPropertyList;
        putSqlKnowledgeBaseConfiguration(value: SqlKnowledgeBaseConfigurationProperty[] | cdktn.IResolvable): void;
        resetSqlKnowledgeBaseConfiguration(): void;
        get sqlKnowledgeBaseConfigurationInput(): cdktn.IResolvable | SqlKnowledgeBaseConfigurationProperty[] | undefined;
        private _vectorKnowledgeBaseConfiguration;
        get vectorKnowledgeBaseConfiguration(): VectorKnowledgeBaseConfigurationPropertyList;
        putVectorKnowledgeBaseConfiguration(value: VectorKnowledgeBaseConfigurationProperty[] | cdktn.IResolvable): void;
        resetVectorKnowledgeBaseConfiguration(): void;
        get vectorKnowledgeBaseConfigurationInput(): cdktn.IResolvable | VectorKnowledgeBaseConfigurationProperty[] | undefined;
    }
    class KnowledgeBaseConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: KnowledgeBaseConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): KnowledgeBaseConfigurationPropertyOutputReference;
    }
    interface StorageConfigurationMongoDbAtlasConfigurationFieldMappingProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_knowledge_base#metadata_field AwsBedrockagentKnowledgeBase#metadata_field}
        */
        readonly metadataField: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_knowledge_base#text_field AwsBedrockagentKnowledgeBase#text_field}
        */
        readonly textField: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_knowledge_base#vector_field AwsBedrockagentKnowledgeBase#vector_field}
        */
        readonly vectorField: string;
    }
    class StorageConfigurationMongoDbAtlasConfigurationFieldMappingPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): StorageConfigurationMongoDbAtlasConfigurationFieldMappingProperty | cdktn.IResolvable | undefined;
        set internalValue(value: StorageConfigurationMongoDbAtlasConfigurationFieldMappingProperty | cdktn.IResolvable | undefined);
        private _metadataField?;
        get metadataField(): string;
        set metadataField(value: string);
        get metadataFieldInput(): string | undefined;
        private _textField?;
        get textField(): string;
        set textField(value: string);
        get textFieldInput(): string | undefined;
        private _vectorField?;
        get vectorField(): string;
        set vectorField(value: string);
        get vectorFieldInput(): string | undefined;
    }
    class StorageConfigurationMongoDbAtlasConfigurationFieldMappingPropertyList extends cdktn.ComplexList {
        internalValue?: StorageConfigurationMongoDbAtlasConfigurationFieldMappingProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): StorageConfigurationMongoDbAtlasConfigurationFieldMappingPropertyOutputReference;
    }
    interface MongoDbAtlasConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_knowledge_base#collection_name AwsBedrockagentKnowledgeBase#collection_name}
        */
        readonly collectionName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_knowledge_base#credentials_secret_arn AwsBedrockagentKnowledgeBase#credentials_secret_arn}
        */
        readonly credentialsSecretArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_knowledge_base#database_name AwsBedrockagentKnowledgeBase#database_name}
        */
        readonly databaseName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_knowledge_base#endpoint AwsBedrockagentKnowledgeBase#endpoint}
        */
        readonly endpoint: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_knowledge_base#endpoint_service_name AwsBedrockagentKnowledgeBase#endpoint_service_name}
        */
        readonly endpointServiceName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_knowledge_base#text_index_name AwsBedrockagentKnowledgeBase#text_index_name}
        */
        readonly textIndexName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_knowledge_base#vector_index_name AwsBedrockagentKnowledgeBase#vector_index_name}
        */
        readonly vectorIndexName: string;
        /**
        * field_mapping block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_knowledge_base#field_mapping AwsBedrockagentKnowledgeBase#field_mapping}
        */
        readonly fieldMapping?: StorageConfigurationMongoDbAtlasConfigurationFieldMappingProperty[] | cdktn.IResolvable;
    }
    class MongoDbAtlasConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): MongoDbAtlasConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: MongoDbAtlasConfigurationProperty | cdktn.IResolvable | undefined);
        private _collectionName?;
        get collectionName(): string;
        set collectionName(value: string);
        get collectionNameInput(): string | undefined;
        private _credentialsSecretArn?;
        get credentialsSecretArn(): string;
        set credentialsSecretArn(value: string);
        get credentialsSecretArnInput(): string | undefined;
        private _databaseName?;
        get databaseName(): string;
        set databaseName(value: string);
        get databaseNameInput(): string | undefined;
        private _endpoint?;
        get endpoint(): string;
        set endpoint(value: string);
        get endpointInput(): string | undefined;
        private _endpointServiceName?;
        get endpointServiceName(): string;
        set endpointServiceName(value: string);
        resetEndpointServiceName(): void;
        get endpointServiceNameInput(): string | undefined;
        private _textIndexName?;
        get textIndexName(): string;
        set textIndexName(value: string);
        resetTextIndexName(): void;
        get textIndexNameInput(): string | undefined;
        private _vectorIndexName?;
        get vectorIndexName(): string;
        set vectorIndexName(value: string);
        get vectorIndexNameInput(): string | undefined;
        private _fieldMapping;
        get fieldMapping(): StorageConfigurationMongoDbAtlasConfigurationFieldMappingPropertyList;
        putFieldMapping(value: StorageConfigurationMongoDbAtlasConfigurationFieldMappingProperty[] | cdktn.IResolvable): void;
        resetFieldMapping(): void;
        get fieldMappingInput(): cdktn.IResolvable | StorageConfigurationMongoDbAtlasConfigurationFieldMappingProperty[] | undefined;
    }
    class MongoDbAtlasConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: MongoDbAtlasConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): MongoDbAtlasConfigurationPropertyOutputReference;
    }
    interface StorageConfigurationNeptuneAnalyticsConfigurationFieldMappingProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_knowledge_base#metadata_field AwsBedrockagentKnowledgeBase#metadata_field}
        */
        readonly metadataField: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_knowledge_base#text_field AwsBedrockagentKnowledgeBase#text_field}
        */
        readonly textField: string;
    }
    class StorageConfigurationNeptuneAnalyticsConfigurationFieldMappingPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): StorageConfigurationNeptuneAnalyticsConfigurationFieldMappingProperty | cdktn.IResolvable | undefined;
        set internalValue(value: StorageConfigurationNeptuneAnalyticsConfigurationFieldMappingProperty | cdktn.IResolvable | undefined);
        private _metadataField?;
        get metadataField(): string;
        set metadataField(value: string);
        get metadataFieldInput(): string | undefined;
        private _textField?;
        get textField(): string;
        set textField(value: string);
        get textFieldInput(): string | undefined;
    }
    class StorageConfigurationNeptuneAnalyticsConfigurationFieldMappingPropertyList extends cdktn.ComplexList {
        internalValue?: StorageConfigurationNeptuneAnalyticsConfigurationFieldMappingProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): StorageConfigurationNeptuneAnalyticsConfigurationFieldMappingPropertyOutputReference;
    }
    interface NeptuneAnalyticsConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_knowledge_base#graph_arn AwsBedrockagentKnowledgeBase#graph_arn}
        */
        readonly graphArn: string;
        /**
        * field_mapping block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_knowledge_base#field_mapping AwsBedrockagentKnowledgeBase#field_mapping}
        */
        readonly fieldMapping?: StorageConfigurationNeptuneAnalyticsConfigurationFieldMappingProperty[] | cdktn.IResolvable;
    }
    class NeptuneAnalyticsConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): NeptuneAnalyticsConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: NeptuneAnalyticsConfigurationProperty | cdktn.IResolvable | undefined);
        private _graphArn?;
        get graphArn(): string;
        set graphArn(value: string);
        get graphArnInput(): string | undefined;
        private _fieldMapping;
        get fieldMapping(): StorageConfigurationNeptuneAnalyticsConfigurationFieldMappingPropertyList;
        putFieldMapping(value: StorageConfigurationNeptuneAnalyticsConfigurationFieldMappingProperty[] | cdktn.IResolvable): void;
        resetFieldMapping(): void;
        get fieldMappingInput(): cdktn.IResolvable | StorageConfigurationNeptuneAnalyticsConfigurationFieldMappingProperty[] | undefined;
    }
    class NeptuneAnalyticsConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: NeptuneAnalyticsConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): NeptuneAnalyticsConfigurationPropertyOutputReference;
    }
    interface StorageConfigurationOpensearchManagedClusterConfigurationFieldMappingProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_knowledge_base#metadata_field AwsBedrockagentKnowledgeBase#metadata_field}
        */
        readonly metadataField: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_knowledge_base#text_field AwsBedrockagentKnowledgeBase#text_field}
        */
        readonly textField: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_knowledge_base#vector_field AwsBedrockagentKnowledgeBase#vector_field}
        */
        readonly vectorField: string;
    }
    class StorageConfigurationOpensearchManagedClusterConfigurationFieldMappingPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): StorageConfigurationOpensearchManagedClusterConfigurationFieldMappingProperty | cdktn.IResolvable | undefined;
        set internalValue(value: StorageConfigurationOpensearchManagedClusterConfigurationFieldMappingProperty | cdktn.IResolvable | undefined);
        private _metadataField?;
        get metadataField(): string;
        set metadataField(value: string);
        get metadataFieldInput(): string | undefined;
        private _textField?;
        get textField(): string;
        set textField(value: string);
        get textFieldInput(): string | undefined;
        private _vectorField?;
        get vectorField(): string;
        set vectorField(value: string);
        get vectorFieldInput(): string | undefined;
    }
    class StorageConfigurationOpensearchManagedClusterConfigurationFieldMappingPropertyList extends cdktn.ComplexList {
        internalValue?: StorageConfigurationOpensearchManagedClusterConfigurationFieldMappingProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): StorageConfigurationOpensearchManagedClusterConfigurationFieldMappingPropertyOutputReference;
    }
    interface OpensearchManagedClusterConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_knowledge_base#domain_arn AwsBedrockagentKnowledgeBase#domain_arn}
        */
        readonly domainArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_knowledge_base#domain_endpoint AwsBedrockagentKnowledgeBase#domain_endpoint}
        */
        readonly domainEndpoint: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_knowledge_base#vector_index_name AwsBedrockagentKnowledgeBase#vector_index_name}
        */
        readonly vectorIndexName: string;
        /**
        * field_mapping block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_knowledge_base#field_mapping AwsBedrockagentKnowledgeBase#field_mapping}
        */
        readonly fieldMapping?: StorageConfigurationOpensearchManagedClusterConfigurationFieldMappingProperty[] | cdktn.IResolvable;
    }
    class OpensearchManagedClusterConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): OpensearchManagedClusterConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: OpensearchManagedClusterConfigurationProperty | cdktn.IResolvable | undefined);
        private _domainArn?;
        get domainArn(): string;
        set domainArn(value: string);
        get domainArnInput(): string | undefined;
        private _domainEndpoint?;
        get domainEndpoint(): string;
        set domainEndpoint(value: string);
        get domainEndpointInput(): string | undefined;
        private _vectorIndexName?;
        get vectorIndexName(): string;
        set vectorIndexName(value: string);
        get vectorIndexNameInput(): string | undefined;
        private _fieldMapping;
        get fieldMapping(): StorageConfigurationOpensearchManagedClusterConfigurationFieldMappingPropertyList;
        putFieldMapping(value: StorageConfigurationOpensearchManagedClusterConfigurationFieldMappingProperty[] | cdktn.IResolvable): void;
        resetFieldMapping(): void;
        get fieldMappingInput(): cdktn.IResolvable | StorageConfigurationOpensearchManagedClusterConfigurationFieldMappingProperty[] | undefined;
    }
    class OpensearchManagedClusterConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: OpensearchManagedClusterConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): OpensearchManagedClusterConfigurationPropertyOutputReference;
    }
    interface StorageConfigurationOpensearchServerlessConfigurationFieldMappingProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_knowledge_base#metadata_field AwsBedrockagentKnowledgeBase#metadata_field}
        */
        readonly metadataField: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_knowledge_base#text_field AwsBedrockagentKnowledgeBase#text_field}
        */
        readonly textField: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_knowledge_base#vector_field AwsBedrockagentKnowledgeBase#vector_field}
        */
        readonly vectorField: string;
    }
    class StorageConfigurationOpensearchServerlessConfigurationFieldMappingPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): StorageConfigurationOpensearchServerlessConfigurationFieldMappingProperty | cdktn.IResolvable | undefined;
        set internalValue(value: StorageConfigurationOpensearchServerlessConfigurationFieldMappingProperty | cdktn.IResolvable | undefined);
        private _metadataField?;
        get metadataField(): string;
        set metadataField(value: string);
        get metadataFieldInput(): string | undefined;
        private _textField?;
        get textField(): string;
        set textField(value: string);
        get textFieldInput(): string | undefined;
        private _vectorField?;
        get vectorField(): string;
        set vectorField(value: string);
        get vectorFieldInput(): string | undefined;
    }
    class StorageConfigurationOpensearchServerlessConfigurationFieldMappingPropertyList extends cdktn.ComplexList {
        internalValue?: StorageConfigurationOpensearchServerlessConfigurationFieldMappingProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): StorageConfigurationOpensearchServerlessConfigurationFieldMappingPropertyOutputReference;
    }
    interface OpensearchServerlessConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_knowledge_base#collection_arn AwsBedrockagentKnowledgeBase#collection_arn}
        */
        readonly collectionArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_knowledge_base#vector_index_name AwsBedrockagentKnowledgeBase#vector_index_name}
        */
        readonly vectorIndexName: string;
        /**
        * field_mapping block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_knowledge_base#field_mapping AwsBedrockagentKnowledgeBase#field_mapping}
        */
        readonly fieldMapping?: StorageConfigurationOpensearchServerlessConfigurationFieldMappingProperty[] | cdktn.IResolvable;
    }
    class OpensearchServerlessConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): OpensearchServerlessConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: OpensearchServerlessConfigurationProperty | cdktn.IResolvable | undefined);
        private _collectionArn?;
        get collectionArn(): string;
        set collectionArn(value: string);
        get collectionArnInput(): string | undefined;
        private _vectorIndexName?;
        get vectorIndexName(): string;
        set vectorIndexName(value: string);
        get vectorIndexNameInput(): string | undefined;
        private _fieldMapping;
        get fieldMapping(): StorageConfigurationOpensearchServerlessConfigurationFieldMappingPropertyList;
        putFieldMapping(value: StorageConfigurationOpensearchServerlessConfigurationFieldMappingProperty[] | cdktn.IResolvable): void;
        resetFieldMapping(): void;
        get fieldMappingInput(): cdktn.IResolvable | StorageConfigurationOpensearchServerlessConfigurationFieldMappingProperty[] | undefined;
    }
    class OpensearchServerlessConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: OpensearchServerlessConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): OpensearchServerlessConfigurationPropertyOutputReference;
    }
    interface StorageConfigurationPineconeConfigurationFieldMappingProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_knowledge_base#metadata_field AwsBedrockagentKnowledgeBase#metadata_field}
        */
        readonly metadataField: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_knowledge_base#text_field AwsBedrockagentKnowledgeBase#text_field}
        */
        readonly textField: string;
    }
    class StorageConfigurationPineconeConfigurationFieldMappingPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): StorageConfigurationPineconeConfigurationFieldMappingProperty | cdktn.IResolvable | undefined;
        set internalValue(value: StorageConfigurationPineconeConfigurationFieldMappingProperty | cdktn.IResolvable | undefined);
        private _metadataField?;
        get metadataField(): string;
        set metadataField(value: string);
        get metadataFieldInput(): string | undefined;
        private _textField?;
        get textField(): string;
        set textField(value: string);
        get textFieldInput(): string | undefined;
    }
    class StorageConfigurationPineconeConfigurationFieldMappingPropertyList extends cdktn.ComplexList {
        internalValue?: StorageConfigurationPineconeConfigurationFieldMappingProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): StorageConfigurationPineconeConfigurationFieldMappingPropertyOutputReference;
    }
    interface PineconeConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_knowledge_base#connection_string AwsBedrockagentKnowledgeBase#connection_string}
        */
        readonly connectionString: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_knowledge_base#credentials_secret_arn AwsBedrockagentKnowledgeBase#credentials_secret_arn}
        */
        readonly credentialsSecretArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_knowledge_base#namespace AwsBedrockagentKnowledgeBase#namespace}
        */
        readonly namespace?: string;
        /**
        * field_mapping block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_knowledge_base#field_mapping AwsBedrockagentKnowledgeBase#field_mapping}
        */
        readonly fieldMapping?: StorageConfigurationPineconeConfigurationFieldMappingProperty[] | cdktn.IResolvable;
    }
    class PineconeConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): PineconeConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: PineconeConfigurationProperty | cdktn.IResolvable | undefined);
        private _connectionString?;
        get connectionString(): string;
        set connectionString(value: string);
        get connectionStringInput(): string | undefined;
        private _credentialsSecretArn?;
        get credentialsSecretArn(): string;
        set credentialsSecretArn(value: string);
        get credentialsSecretArnInput(): string | undefined;
        private _namespace?;
        get namespace(): string;
        set namespace(value: string);
        resetNamespace(): void;
        get namespaceInput(): string | undefined;
        private _fieldMapping;
        get fieldMapping(): StorageConfigurationPineconeConfigurationFieldMappingPropertyList;
        putFieldMapping(value: StorageConfigurationPineconeConfigurationFieldMappingProperty[] | cdktn.IResolvable): void;
        resetFieldMapping(): void;
        get fieldMappingInput(): cdktn.IResolvable | StorageConfigurationPineconeConfigurationFieldMappingProperty[] | undefined;
    }
    class PineconeConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: PineconeConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): PineconeConfigurationPropertyOutputReference;
    }
    interface StorageConfigurationRdsConfigurationFieldMappingProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_knowledge_base#custom_metadata_field AwsBedrockagentKnowledgeBase#custom_metadata_field}
        */
        readonly customMetadataField?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_knowledge_base#metadata_field AwsBedrockagentKnowledgeBase#metadata_field}
        */
        readonly metadataField: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_knowledge_base#primary_key_field AwsBedrockagentKnowledgeBase#primary_key_field}
        */
        readonly primaryKeyField: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_knowledge_base#text_field AwsBedrockagentKnowledgeBase#text_field}
        */
        readonly textField: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_knowledge_base#vector_field AwsBedrockagentKnowledgeBase#vector_field}
        */
        readonly vectorField: string;
    }
    class StorageConfigurationRdsConfigurationFieldMappingPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): StorageConfigurationRdsConfigurationFieldMappingProperty | cdktn.IResolvable | undefined;
        set internalValue(value: StorageConfigurationRdsConfigurationFieldMappingProperty | cdktn.IResolvable | undefined);
        private _customMetadataField?;
        get customMetadataField(): string;
        set customMetadataField(value: string);
        resetCustomMetadataField(): void;
        get customMetadataFieldInput(): string | undefined;
        private _metadataField?;
        get metadataField(): string;
        set metadataField(value: string);
        get metadataFieldInput(): string | undefined;
        private _primaryKeyField?;
        get primaryKeyField(): string;
        set primaryKeyField(value: string);
        get primaryKeyFieldInput(): string | undefined;
        private _textField?;
        get textField(): string;
        set textField(value: string);
        get textFieldInput(): string | undefined;
        private _vectorField?;
        get vectorField(): string;
        set vectorField(value: string);
        get vectorFieldInput(): string | undefined;
    }
    class StorageConfigurationRdsConfigurationFieldMappingPropertyList extends cdktn.ComplexList {
        internalValue?: StorageConfigurationRdsConfigurationFieldMappingProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): StorageConfigurationRdsConfigurationFieldMappingPropertyOutputReference;
    }
    interface RdsConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_knowledge_base#credentials_secret_arn AwsBedrockagentKnowledgeBase#credentials_secret_arn}
        */
        readonly credentialsSecretArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_knowledge_base#database_name AwsBedrockagentKnowledgeBase#database_name}
        */
        readonly databaseName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_knowledge_base#resource_arn AwsBedrockagentKnowledgeBase#resource_arn}
        */
        readonly resourceArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_knowledge_base#table_name AwsBedrockagentKnowledgeBase#table_name}
        */
        readonly tableName: string;
        /**
        * field_mapping block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_knowledge_base#field_mapping AwsBedrockagentKnowledgeBase#field_mapping}
        */
        readonly fieldMapping?: StorageConfigurationRdsConfigurationFieldMappingProperty[] | cdktn.IResolvable;
    }
    class RdsConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RdsConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RdsConfigurationProperty | cdktn.IResolvable | undefined);
        private _credentialsSecretArn?;
        get credentialsSecretArn(): string;
        set credentialsSecretArn(value: string);
        get credentialsSecretArnInput(): string | undefined;
        private _databaseName?;
        get databaseName(): string;
        set databaseName(value: string);
        get databaseNameInput(): string | undefined;
        private _resourceArn?;
        get resourceArn(): string;
        set resourceArn(value: string);
        get resourceArnInput(): string | undefined;
        private _tableName?;
        get tableName(): string;
        set tableName(value: string);
        get tableNameInput(): string | undefined;
        private _fieldMapping;
        get fieldMapping(): StorageConfigurationRdsConfigurationFieldMappingPropertyList;
        putFieldMapping(value: StorageConfigurationRdsConfigurationFieldMappingProperty[] | cdktn.IResolvable): void;
        resetFieldMapping(): void;
        get fieldMappingInput(): cdktn.IResolvable | StorageConfigurationRdsConfigurationFieldMappingProperty[] | undefined;
    }
    class RdsConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: RdsConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RdsConfigurationPropertyOutputReference;
    }
    interface StorageConfigurationRedisEnterpriseCloudConfigurationFieldMappingProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_knowledge_base#metadata_field AwsBedrockagentKnowledgeBase#metadata_field}
        */
        readonly metadataField?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_knowledge_base#text_field AwsBedrockagentKnowledgeBase#text_field}
        */
        readonly textField?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_knowledge_base#vector_field AwsBedrockagentKnowledgeBase#vector_field}
        */
        readonly vectorField?: string;
    }
    class StorageConfigurationRedisEnterpriseCloudConfigurationFieldMappingPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): StorageConfigurationRedisEnterpriseCloudConfigurationFieldMappingProperty | cdktn.IResolvable | undefined;
        set internalValue(value: StorageConfigurationRedisEnterpriseCloudConfigurationFieldMappingProperty | cdktn.IResolvable | undefined);
        private _metadataField?;
        get metadataField(): string;
        set metadataField(value: string);
        resetMetadataField(): void;
        get metadataFieldInput(): string | undefined;
        private _textField?;
        get textField(): string;
        set textField(value: string);
        resetTextField(): void;
        get textFieldInput(): string | undefined;
        private _vectorField?;
        get vectorField(): string;
        set vectorField(value: string);
        resetVectorField(): void;
        get vectorFieldInput(): string | undefined;
    }
    class StorageConfigurationRedisEnterpriseCloudConfigurationFieldMappingPropertyList extends cdktn.ComplexList {
        internalValue?: StorageConfigurationRedisEnterpriseCloudConfigurationFieldMappingProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): StorageConfigurationRedisEnterpriseCloudConfigurationFieldMappingPropertyOutputReference;
    }
    interface RedisEnterpriseCloudConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_knowledge_base#credentials_secret_arn AwsBedrockagentKnowledgeBase#credentials_secret_arn}
        */
        readonly credentialsSecretArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_knowledge_base#endpoint AwsBedrockagentKnowledgeBase#endpoint}
        */
        readonly endpoint: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_knowledge_base#vector_index_name AwsBedrockagentKnowledgeBase#vector_index_name}
        */
        readonly vectorIndexName: string;
        /**
        * field_mapping block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_knowledge_base#field_mapping AwsBedrockagentKnowledgeBase#field_mapping}
        */
        readonly fieldMapping?: StorageConfigurationRedisEnterpriseCloudConfigurationFieldMappingProperty[] | cdktn.IResolvable;
    }
    class RedisEnterpriseCloudConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RedisEnterpriseCloudConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RedisEnterpriseCloudConfigurationProperty | cdktn.IResolvable | undefined);
        private _credentialsSecretArn?;
        get credentialsSecretArn(): string;
        set credentialsSecretArn(value: string);
        get credentialsSecretArnInput(): string | undefined;
        private _endpoint?;
        get endpoint(): string;
        set endpoint(value: string);
        get endpointInput(): string | undefined;
        private _vectorIndexName?;
        get vectorIndexName(): string;
        set vectorIndexName(value: string);
        get vectorIndexNameInput(): string | undefined;
        private _fieldMapping;
        get fieldMapping(): StorageConfigurationRedisEnterpriseCloudConfigurationFieldMappingPropertyList;
        putFieldMapping(value: StorageConfigurationRedisEnterpriseCloudConfigurationFieldMappingProperty[] | cdktn.IResolvable): void;
        resetFieldMapping(): void;
        get fieldMappingInput(): cdktn.IResolvable | StorageConfigurationRedisEnterpriseCloudConfigurationFieldMappingProperty[] | undefined;
    }
    class RedisEnterpriseCloudConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: RedisEnterpriseCloudConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RedisEnterpriseCloudConfigurationPropertyOutputReference;
    }
    interface S3VectorsConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_knowledge_base#index_arn AwsBedrockagentKnowledgeBase#index_arn}
        */
        readonly indexArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_knowledge_base#index_name AwsBedrockagentKnowledgeBase#index_name}
        */
        readonly indexName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_knowledge_base#vector_bucket_arn AwsBedrockagentKnowledgeBase#vector_bucket_arn}
        */
        readonly vectorBucketArn?: string;
    }
    class S3VectorsConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): S3VectorsConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: S3VectorsConfigurationProperty | cdktn.IResolvable | undefined);
        private _indexArn?;
        get indexArn(): string;
        set indexArn(value: string);
        resetIndexArn(): void;
        get indexArnInput(): string | undefined;
        private _indexName?;
        get indexName(): string;
        set indexName(value: string);
        resetIndexName(): void;
        get indexNameInput(): string | undefined;
        private _vectorBucketArn?;
        get vectorBucketArn(): string;
        set vectorBucketArn(value: string);
        resetVectorBucketArn(): void;
        get vectorBucketArnInput(): string | undefined;
    }
    class S3VectorsConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: S3VectorsConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): S3VectorsConfigurationPropertyOutputReference;
    }
    interface StorageConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_knowledge_base#type AwsBedrockagentKnowledgeBase#type}
        */
        readonly type: string;
        /**
        * mongo_db_atlas_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_knowledge_base#mongo_db_atlas_configuration AwsBedrockagentKnowledgeBase#mongo_db_atlas_configuration}
        */
        readonly mongoDbAtlasConfiguration?: MongoDbAtlasConfigurationProperty[] | cdktn.IResolvable;
        /**
        * neptune_analytics_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_knowledge_base#neptune_analytics_configuration AwsBedrockagentKnowledgeBase#neptune_analytics_configuration}
        */
        readonly neptuneAnalyticsConfiguration?: NeptuneAnalyticsConfigurationProperty[] | cdktn.IResolvable;
        /**
        * opensearch_managed_cluster_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_knowledge_base#opensearch_managed_cluster_configuration AwsBedrockagentKnowledgeBase#opensearch_managed_cluster_configuration}
        */
        readonly opensearchManagedClusterConfiguration?: OpensearchManagedClusterConfigurationProperty[] | cdktn.IResolvable;
        /**
        * opensearch_serverless_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_knowledge_base#opensearch_serverless_configuration AwsBedrockagentKnowledgeBase#opensearch_serverless_configuration}
        */
        readonly opensearchServerlessConfiguration?: OpensearchServerlessConfigurationProperty[] | cdktn.IResolvable;
        /**
        * pinecone_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_knowledge_base#pinecone_configuration AwsBedrockagentKnowledgeBase#pinecone_configuration}
        */
        readonly pineconeConfiguration?: PineconeConfigurationProperty[] | cdktn.IResolvable;
        /**
        * rds_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_knowledge_base#rds_configuration AwsBedrockagentKnowledgeBase#rds_configuration}
        */
        readonly rdsConfiguration?: RdsConfigurationProperty[] | cdktn.IResolvable;
        /**
        * redis_enterprise_cloud_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_knowledge_base#redis_enterprise_cloud_configuration AwsBedrockagentKnowledgeBase#redis_enterprise_cloud_configuration}
        */
        readonly redisEnterpriseCloudConfiguration?: RedisEnterpriseCloudConfigurationProperty[] | cdktn.IResolvable;
        /**
        * s3_vectors_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_knowledge_base#s3_vectors_configuration AwsBedrockagentKnowledgeBase#s3_vectors_configuration}
        */
        readonly s3VectorsConfiguration?: S3VectorsConfigurationProperty[] | cdktn.IResolvable;
    }
    class StorageConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): StorageConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: StorageConfigurationProperty | cdktn.IResolvable | undefined);
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
        private _mongoDbAtlasConfiguration;
        get mongoDbAtlasConfiguration(): MongoDbAtlasConfigurationPropertyList;
        putMongoDbAtlasConfiguration(value: MongoDbAtlasConfigurationProperty[] | cdktn.IResolvable): void;
        resetMongoDbAtlasConfiguration(): void;
        get mongoDbAtlasConfigurationInput(): cdktn.IResolvable | MongoDbAtlasConfigurationProperty[] | undefined;
        private _neptuneAnalyticsConfiguration;
        get neptuneAnalyticsConfiguration(): NeptuneAnalyticsConfigurationPropertyList;
        putNeptuneAnalyticsConfiguration(value: NeptuneAnalyticsConfigurationProperty[] | cdktn.IResolvable): void;
        resetNeptuneAnalyticsConfiguration(): void;
        get neptuneAnalyticsConfigurationInput(): cdktn.IResolvable | NeptuneAnalyticsConfigurationProperty[] | undefined;
        private _opensearchManagedClusterConfiguration;
        get opensearchManagedClusterConfiguration(): OpensearchManagedClusterConfigurationPropertyList;
        putOpensearchManagedClusterConfiguration(value: OpensearchManagedClusterConfigurationProperty[] | cdktn.IResolvable): void;
        resetOpensearchManagedClusterConfiguration(): void;
        get opensearchManagedClusterConfigurationInput(): cdktn.IResolvable | OpensearchManagedClusterConfigurationProperty[] | undefined;
        private _opensearchServerlessConfiguration;
        get opensearchServerlessConfiguration(): OpensearchServerlessConfigurationPropertyList;
        putOpensearchServerlessConfiguration(value: OpensearchServerlessConfigurationProperty[] | cdktn.IResolvable): void;
        resetOpensearchServerlessConfiguration(): void;
        get opensearchServerlessConfigurationInput(): cdktn.IResolvable | OpensearchServerlessConfigurationProperty[] | undefined;
        private _pineconeConfiguration;
        get pineconeConfiguration(): PineconeConfigurationPropertyList;
        putPineconeConfiguration(value: PineconeConfigurationProperty[] | cdktn.IResolvable): void;
        resetPineconeConfiguration(): void;
        get pineconeConfigurationInput(): cdktn.IResolvable | PineconeConfigurationProperty[] | undefined;
        private _rdsConfiguration;
        get rdsConfiguration(): RdsConfigurationPropertyList;
        putRdsConfiguration(value: RdsConfigurationProperty[] | cdktn.IResolvable): void;
        resetRdsConfiguration(): void;
        get rdsConfigurationInput(): cdktn.IResolvable | RdsConfigurationProperty[] | undefined;
        private _redisEnterpriseCloudConfiguration;
        get redisEnterpriseCloudConfiguration(): RedisEnterpriseCloudConfigurationPropertyList;
        putRedisEnterpriseCloudConfiguration(value: RedisEnterpriseCloudConfigurationProperty[] | cdktn.IResolvable): void;
        resetRedisEnterpriseCloudConfiguration(): void;
        get redisEnterpriseCloudConfigurationInput(): cdktn.IResolvable | RedisEnterpriseCloudConfigurationProperty[] | undefined;
        private _s3VectorsConfiguration;
        get s3VectorsConfiguration(): S3VectorsConfigurationPropertyList;
        putS3VectorsConfiguration(value: S3VectorsConfigurationProperty[] | cdktn.IResolvable): void;
        resetS3VectorsConfiguration(): void;
        get s3VectorsConfigurationInput(): cdktn.IResolvable | S3VectorsConfigurationProperty[] | undefined;
    }
    class StorageConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: StorageConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): StorageConfigurationPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_knowledge_base#create AwsBedrockagentKnowledgeBase#create}
        */
        readonly create?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Setting a timeout for a Delete operation is only applicable if changes are saved into state before the destroy operation occurs.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_knowledge_base#delete AwsBedrockagentKnowledgeBase#delete}
        */
        readonly delete?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_knowledge_base#update AwsBedrockagentKnowledgeBase#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
