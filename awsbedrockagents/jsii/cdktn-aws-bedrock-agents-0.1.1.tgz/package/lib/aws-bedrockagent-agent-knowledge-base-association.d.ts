import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsBedrockagentAgentKnowledgeBaseAssociationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_agent_knowledge_base_association#agent_id AwsBedrockagentAgentKnowledgeBaseAssociation#agent_id}
    */
    readonly agentId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_agent_knowledge_base_association#agent_version AwsBedrockagentAgentKnowledgeBaseAssociation#agent_version}
    */
    readonly agentVersion?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_agent_knowledge_base_association#description AwsBedrockagentAgentKnowledgeBaseAssociation#description}
    */
    readonly description: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_agent_knowledge_base_association#knowledge_base_id AwsBedrockagentAgentKnowledgeBaseAssociation#knowledge_base_id}
    */
    readonly knowledgeBaseId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_agent_knowledge_base_association#knowledge_base_state AwsBedrockagentAgentKnowledgeBaseAssociation#knowledge_base_state}
    */
    readonly knowledgeBaseState: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_agent_knowledge_base_association#region AwsBedrockagentAgentKnowledgeBaseAssociation#region}
    */
    readonly region?: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_agent_knowledge_base_association#timeouts AwsBedrockagentAgentKnowledgeBaseAssociation#timeouts}
    */
    readonly timeouts?: AwsBedrockagentAgentKnowledgeBaseAssociation.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_agent_knowledge_base_association aws_bedrockagent_agent_knowledge_base_association}
*/
export declare class AwsBedrockagentAgentKnowledgeBaseAssociation extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_bedrockagent_agent_knowledge_base_association";
    /**
    * Generates CDKTN code for importing a AwsBedrockagentAgentKnowledgeBaseAssociation resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsBedrockagentAgentKnowledgeBaseAssociation to import
    * @param importFromId The id of the existing AwsBedrockagentAgentKnowledgeBaseAssociation that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_agent_knowledge_base_association#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsBedrockagentAgentKnowledgeBaseAssociation to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_agent_knowledge_base_association aws_bedrockagent_agent_knowledge_base_association} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsBedrockagentAgentKnowledgeBaseAssociationConfig
    */
    constructor(scope: Construct, id: string, config: AwsBedrockagentAgentKnowledgeBaseAssociationConfig);
    private _agentId?;
    get agentId(): string;
    set agentId(value: string);
    get agentIdInput(): string | undefined;
    private _agentVersion?;
    get agentVersion(): string;
    set agentVersion(value: string);
    resetAgentVersion(): void;
    get agentVersionInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    get descriptionInput(): string | undefined;
    get id(): string;
    private _knowledgeBaseId?;
    get knowledgeBaseId(): string;
    set knowledgeBaseId(value: string);
    get knowledgeBaseIdInput(): string | undefined;
    private _knowledgeBaseState?;
    get knowledgeBaseState(): string;
    set knowledgeBaseState(value: string);
    get knowledgeBaseStateInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _timeouts;
    get timeouts(): AwsBedrockagentAgentKnowledgeBaseAssociation.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsBedrockagentAgentKnowledgeBaseAssociation.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsBedrockagentAgentKnowledgeBaseAssociation.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsBedrockagentAgentKnowledgeBaseAssociationTimeoutsPropertyToTerraform(struct?: AwsBedrockagentAgentKnowledgeBaseAssociation.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentAgentKnowledgeBaseAssociationTimeoutsPropertyToHclTerraform(struct?: AwsBedrockagentAgentKnowledgeBaseAssociation.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsBedrockagentAgentKnowledgeBaseAssociation {
    interface TimeoutsProperty {
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_agent_knowledge_base_association#create AwsBedrockagentAgentKnowledgeBaseAssociation#create}
        */
        readonly create?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_agent_knowledge_base_association#update AwsBedrockagentAgentKnowledgeBaseAssociation#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
