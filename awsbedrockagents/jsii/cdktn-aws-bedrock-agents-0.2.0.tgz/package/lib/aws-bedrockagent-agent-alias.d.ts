import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfAgentAliasConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_agent_alias#agent_alias_name TfAgentAlias#agent_alias_name}
    */
    readonly agentAliasName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_agent_alias#agent_id TfAgentAlias#agent_id}
    */
    readonly agentId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_agent_alias#description TfAgentAlias#description}
    */
    readonly description?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_agent_alias#region TfAgentAlias#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_agent_alias#routing_configuration TfAgentAlias#routing_configuration}
    */
    readonly routingConfiguration?: TfAgentAlias.RoutingConfigurationProperty[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_agent_alias#tags TfAgentAlias#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_agent_alias#timeouts TfAgentAlias#timeouts}
    */
    readonly timeouts?: TfAgentAlias.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_agent_alias aws_bedrockagent_agent_alias}
*/
export declare class TfAgentAlias extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_bedrockagent_agent_alias";
    /**
    * Generates CDKTN code for importing a TfAgentAlias resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfAgentAlias to import
    * @param importFromId The id of the existing TfAgentAlias that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_agent_alias#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfAgentAlias to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_agent_alias aws_bedrockagent_agent_alias} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfAgentAliasConfig
    */
    constructor(scope: Construct, id: string, config: TfAgentAliasConfig);
    get agentAliasArn(): string;
    get agentAliasId(): string;
    private _agentAliasName?;
    get agentAliasName(): string;
    set agentAliasName(value: string);
    get agentAliasNameInput(): string | undefined;
    private _agentId?;
    get agentId(): string;
    set agentId(value: string);
    get agentIdInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get id(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _routingConfiguration;
    get routingConfiguration(): TfAgentAlias.RoutingConfigurationPropertyList;
    putRoutingConfiguration(value: TfAgentAlias.RoutingConfigurationProperty[] | cdktn.IResolvable): void;
    resetRoutingConfiguration(): void;
    get routingConfigurationInput(): cdktn.IResolvable | TfAgentAlias.RoutingConfigurationProperty[] | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    private _timeouts;
    get timeouts(): TfAgentAlias.TimeoutsPropertyOutputReference;
    putTimeouts(value: TfAgentAlias.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | TfAgentAlias.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfAgentAliasRoutingConfigurationPropertyToTerraform(struct?: TfAgentAlias.RoutingConfigurationProperty | cdktn.IResolvable): any;
export declare function tfAgentAliasRoutingConfigurationPropertyToHclTerraform(struct?: TfAgentAlias.RoutingConfigurationProperty | cdktn.IResolvable): any;
export declare function tfAgentAliasTimeoutsPropertyToTerraform(struct?: TfAgentAlias.TimeoutsProperty | cdktn.IResolvable): any;
export declare function tfAgentAliasTimeoutsPropertyToHclTerraform(struct?: TfAgentAlias.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace TfAgentAlias {
    interface RoutingConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_agent_alias#agent_version TfAgentAlias#agent_version}
        */
        readonly agentVersion?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_agent_alias#provisioned_throughput TfAgentAlias#provisioned_throughput}
        */
        readonly provisionedThroughput?: string;
    }
    class RoutingConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RoutingConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RoutingConfigurationProperty | cdktn.IResolvable | undefined);
        private _agentVersion?;
        get agentVersion(): string;
        set agentVersion(value: string);
        resetAgentVersion(): void;
        get agentVersionInput(): string | undefined;
        private _provisionedThroughput?;
        get provisionedThroughput(): string;
        set provisionedThroughput(value: string);
        resetProvisionedThroughput(): void;
        get provisionedThroughputInput(): string | undefined;
    }
    class RoutingConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: RoutingConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RoutingConfigurationPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_agent_alias#create TfAgentAlias#create}
        */
        readonly create?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Setting a timeout for a Delete operation is only applicable if changes are saved into state before the destroy operation occurs.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_agent_alias#delete TfAgentAlias#delete}
        */
        readonly delete?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_agent_alias#update TfAgentAlias#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
