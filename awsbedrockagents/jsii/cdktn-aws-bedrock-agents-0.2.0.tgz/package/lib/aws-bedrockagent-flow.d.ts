import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfFlowConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_flow#customer_encryption_key_arn TfFlow#customer_encryption_key_arn}
    */
    readonly customerEncryptionKeyArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_flow#description TfFlow#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_flow#execution_role_arn TfFlow#execution_role_arn}
    */
    readonly executionRoleArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_flow#name TfFlow#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_flow#region TfFlow#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_flow#tags TfFlow#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * definition block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_flow#definition TfFlow#definition}
    */
    readonly definition?: TfFlow.DefinitionProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_flow#timeouts TfFlow#timeouts}
    */
    readonly timeouts?: TfFlow.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_flow aws_bedrockagent_flow}
*/
export declare class TfFlow extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_bedrockagent_flow";
    /**
    * Generates CDKTN code for importing a TfFlow resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfFlow to import
    * @param importFromId The id of the existing TfFlow that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_flow#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfFlow to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_flow aws_bedrockagent_flow} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfFlowConfig
    */
    constructor(scope: Construct, id: string, config: TfFlowConfig);
    get arn(): string;
    get createdAt(): string;
    private _customerEncryptionKeyArn?;
    get customerEncryptionKeyArn(): string;
    set customerEncryptionKeyArn(value: string);
    resetCustomerEncryptionKeyArn(): void;
    get customerEncryptionKeyArnInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _executionRoleArn?;
    get executionRoleArn(): string;
    set executionRoleArn(value: string);
    get executionRoleArnInput(): string | undefined;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get status(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    get updatedAt(): string;
    get version(): string;
    private _definition;
    get definition(): TfFlow.DefinitionPropertyList;
    putDefinition(value: TfFlow.DefinitionProperty[] | cdktn.IResolvable): void;
    resetDefinition(): void;
    get definitionInput(): cdktn.IResolvable | TfFlow.DefinitionProperty[] | undefined;
    private _timeouts;
    get timeouts(): TfFlow.TimeoutsPropertyOutputReference;
    putTimeouts(value: TfFlow.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | TfFlow.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfFlowConditionalPropertyToTerraform(struct?: TfFlow.ConditionalProperty | cdktn.IResolvable): any;
export declare function tfFlowConditionalPropertyToHclTerraform(struct?: TfFlow.ConditionalProperty | cdktn.IResolvable): any;
export declare function tfFlowDataPropertyToTerraform(struct?: TfFlow.DataProperty | cdktn.IResolvable): any;
export declare function tfFlowDataPropertyToHclTerraform(struct?: TfFlow.DataProperty | cdktn.IResolvable): any;
export declare function tfFlowDefinitionConnectionConfigurationPropertyToTerraform(struct?: TfFlow.DefinitionConnectionConfigurationProperty | cdktn.IResolvable): any;
export declare function tfFlowDefinitionConnectionConfigurationPropertyToHclTerraform(struct?: TfFlow.DefinitionConnectionConfigurationProperty | cdktn.IResolvable): any;
export declare function tfFlowConnectionPropertyToTerraform(struct?: TfFlow.ConnectionProperty | cdktn.IResolvable): any;
export declare function tfFlowConnectionPropertyToHclTerraform(struct?: TfFlow.ConnectionProperty | cdktn.IResolvable): any;
export declare function tfFlowAgentPropertyToTerraform(struct?: TfFlow.AgentProperty | cdktn.IResolvable): any;
export declare function tfFlowAgentPropertyToHclTerraform(struct?: TfFlow.AgentProperty | cdktn.IResolvable): any;
export declare function tfFlowCollectorPropertyToTerraform(struct?: TfFlow.CollectorProperty | cdktn.IResolvable): any;
export declare function tfFlowCollectorPropertyToHclTerraform(struct?: TfFlow.CollectorProperty | cdktn.IResolvable): any;
export declare function tfFlowDefinitionNodeConfigurationConditionConditionPropertyToTerraform(struct?: TfFlow.DefinitionNodeConfigurationConditionConditionProperty | cdktn.IResolvable): any;
export declare function tfFlowDefinitionNodeConfigurationConditionConditionPropertyToHclTerraform(struct?: TfFlow.DefinitionNodeConfigurationConditionConditionProperty | cdktn.IResolvable): any;
export declare function tfFlowDefinitionNodeConfigurationConditionPropertyToTerraform(struct?: TfFlow.DefinitionNodeConfigurationConditionProperty | cdktn.IResolvable): any;
export declare function tfFlowDefinitionNodeConfigurationConditionPropertyToHclTerraform(struct?: TfFlow.DefinitionNodeConfigurationConditionProperty | cdktn.IResolvable): any;
export declare function tfFlowInlineCodePropertyToTerraform(struct?: TfFlow.InlineCodeProperty | cdktn.IResolvable): any;
export declare function tfFlowInlineCodePropertyToHclTerraform(struct?: TfFlow.InlineCodeProperty | cdktn.IResolvable): any;
export declare function tfFlowDefinitionNodeConfigurationInputPropertyToTerraform(struct?: TfFlow.DefinitionNodeConfigurationInputProperty | cdktn.IResolvable): any;
export declare function tfFlowDefinitionNodeConfigurationInputPropertyToHclTerraform(struct?: TfFlow.DefinitionNodeConfigurationInputProperty | cdktn.IResolvable): any;
export declare function tfFlowIteratorPropertyToTerraform(struct?: TfFlow.IteratorProperty | cdktn.IResolvable): any;
export declare function tfFlowIteratorPropertyToHclTerraform(struct?: TfFlow.IteratorProperty | cdktn.IResolvable): any;
export declare function tfFlowDefinitionNodeConfigurationKnowledgeBaseGuardrailConfigurationPropertyToTerraform(struct?: TfFlow.DefinitionNodeConfigurationKnowledgeBaseGuardrailConfigurationProperty | cdktn.IResolvable): any;
export declare function tfFlowDefinitionNodeConfigurationKnowledgeBaseGuardrailConfigurationPropertyToHclTerraform(struct?: TfFlow.DefinitionNodeConfigurationKnowledgeBaseGuardrailConfigurationProperty | cdktn.IResolvable): any;
export declare function tfFlowDefinitionNodeConfigurationKnowledgeBaseInferenceConfigurationTextPropertyToTerraform(struct?: TfFlow.DefinitionNodeConfigurationKnowledgeBaseInferenceConfigurationTextProperty | cdktn.IResolvable): any;
export declare function tfFlowDefinitionNodeConfigurationKnowledgeBaseInferenceConfigurationTextPropertyToHclTerraform(struct?: TfFlow.DefinitionNodeConfigurationKnowledgeBaseInferenceConfigurationTextProperty | cdktn.IResolvable): any;
export declare function tfFlowDefinitionNodeConfigurationKnowledgeBaseInferenceConfigurationPropertyToTerraform(struct?: TfFlow.DefinitionNodeConfigurationKnowledgeBaseInferenceConfigurationProperty | cdktn.IResolvable): any;
export declare function tfFlowDefinitionNodeConfigurationKnowledgeBaseInferenceConfigurationPropertyToHclTerraform(struct?: TfFlow.DefinitionNodeConfigurationKnowledgeBaseInferenceConfigurationProperty | cdktn.IResolvable): any;
export declare function tfFlowKnowledgeBasePropertyToTerraform(struct?: TfFlow.KnowledgeBaseProperty | cdktn.IResolvable): any;
export declare function tfFlowKnowledgeBasePropertyToHclTerraform(struct?: TfFlow.KnowledgeBaseProperty | cdktn.IResolvable): any;
export declare function tfFlowLambdaFunctionPropertyToTerraform(struct?: TfFlow.LambdaFunctionProperty | cdktn.IResolvable): any;
export declare function tfFlowLambdaFunctionPropertyToHclTerraform(struct?: TfFlow.LambdaFunctionProperty | cdktn.IResolvable): any;
export declare function tfFlowLexPropertyToTerraform(struct?: TfFlow.LexProperty | cdktn.IResolvable): any;
export declare function tfFlowLexPropertyToHclTerraform(struct?: TfFlow.LexProperty | cdktn.IResolvable): any;
export declare function tfFlowDefinitionNodeConfigurationOutputPropertyToTerraform(struct?: TfFlow.DefinitionNodeConfigurationOutputProperty | cdktn.IResolvable): any;
export declare function tfFlowDefinitionNodeConfigurationOutputPropertyToHclTerraform(struct?: TfFlow.DefinitionNodeConfigurationOutputProperty | cdktn.IResolvable): any;
export declare function tfFlowDefinitionNodeConfigurationPromptGuardrailConfigurationPropertyToTerraform(struct?: TfFlow.DefinitionNodeConfigurationPromptGuardrailConfigurationProperty | cdktn.IResolvable): any;
export declare function tfFlowDefinitionNodeConfigurationPromptGuardrailConfigurationPropertyToHclTerraform(struct?: TfFlow.DefinitionNodeConfigurationPromptGuardrailConfigurationProperty | cdktn.IResolvable): any;
export declare function tfFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineInferenceConfigurationTextPropertyToTerraform(struct?: TfFlow.DefinitionNodeConfigurationPromptSourceConfigurationInlineInferenceConfigurationTextProperty | cdktn.IResolvable): any;
export declare function tfFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineInferenceConfigurationTextPropertyToHclTerraform(struct?: TfFlow.DefinitionNodeConfigurationPromptSourceConfigurationInlineInferenceConfigurationTextProperty | cdktn.IResolvable): any;
export declare function tfFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineInferenceConfigurationPropertyToTerraform(struct?: TfFlow.DefinitionNodeConfigurationPromptSourceConfigurationInlineInferenceConfigurationProperty | cdktn.IResolvable): any;
export declare function tfFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineInferenceConfigurationPropertyToHclTerraform(struct?: TfFlow.DefinitionNodeConfigurationPromptSourceConfigurationInlineInferenceConfigurationProperty | cdktn.IResolvable): any;
export declare function tfFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatInputVariablePropertyToTerraform(struct?: TfFlow.DefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatInputVariableProperty | cdktn.IResolvable): any;
export declare function tfFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatInputVariablePropertyToHclTerraform(struct?: TfFlow.DefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatInputVariableProperty | cdktn.IResolvable): any;
export declare function tfFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatMessageContentCachePointPropertyToTerraform(struct?: TfFlow.DefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatMessageContentCachePointProperty | cdktn.IResolvable): any;
export declare function tfFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatMessageContentCachePointPropertyToHclTerraform(struct?: TfFlow.DefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatMessageContentCachePointProperty | cdktn.IResolvable): any;
export declare function tfFlowContentPropertyToTerraform(struct?: TfFlow.ContentProperty | cdktn.IResolvable): any;
export declare function tfFlowContentPropertyToHclTerraform(struct?: TfFlow.ContentProperty | cdktn.IResolvable): any;
export declare function tfFlowMessagePropertyToTerraform(struct?: TfFlow.MessageProperty | cdktn.IResolvable): any;
export declare function tfFlowMessagePropertyToHclTerraform(struct?: TfFlow.MessageProperty | cdktn.IResolvable): any;
export declare function tfFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatSystemCachePointPropertyToTerraform(struct?: TfFlow.DefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatSystemCachePointProperty | cdktn.IResolvable): any;
export declare function tfFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatSystemCachePointPropertyToHclTerraform(struct?: TfFlow.DefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatSystemCachePointProperty | cdktn.IResolvable): any;
export declare function tfFlowSystemPropertyToTerraform(struct?: TfFlow.SystemProperty | cdktn.IResolvable): any;
export declare function tfFlowSystemPropertyToHclTerraform(struct?: TfFlow.SystemProperty | cdktn.IResolvable): any;
export declare function tfFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatToolConfigurationToolCachePointPropertyToTerraform(struct?: TfFlow.DefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatToolConfigurationToolCachePointProperty | cdktn.IResolvable): any;
export declare function tfFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatToolConfigurationToolCachePointPropertyToHclTerraform(struct?: TfFlow.DefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatToolConfigurationToolCachePointProperty | cdktn.IResolvable): any;
export declare function tfFlowInputSchemaPropertyToTerraform(struct?: TfFlow.InputSchemaProperty | cdktn.IResolvable): any;
export declare function tfFlowInputSchemaPropertyToHclTerraform(struct?: TfFlow.InputSchemaProperty | cdktn.IResolvable): any;
export declare function tfFlowToolSpecPropertyToTerraform(struct?: TfFlow.ToolSpecProperty | cdktn.IResolvable): any;
export declare function tfFlowToolSpecPropertyToHclTerraform(struct?: TfFlow.ToolSpecProperty | cdktn.IResolvable): any;
export declare function tfFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatToolConfigurationToolPropertyToTerraform(struct?: TfFlow.DefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatToolConfigurationToolProperty | cdktn.IResolvable): any;
export declare function tfFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatToolConfigurationToolPropertyToHclTerraform(struct?: TfFlow.DefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatToolConfigurationToolProperty | cdktn.IResolvable): any;
export declare function tfFlowAnyPropertyToTerraform(struct?: TfFlow.AnyProperty | cdktn.IResolvable): any;
export declare function tfFlowAnyPropertyToHclTerraform(struct?: TfFlow.AnyProperty | cdktn.IResolvable): any;
export declare function tfFlowAutoPropertyToTerraform(struct?: TfFlow.AutoProperty | cdktn.IResolvable): any;
export declare function tfFlowAutoPropertyToHclTerraform(struct?: TfFlow.AutoProperty | cdktn.IResolvable): any;
export declare function tfFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatToolConfigurationToolChoiceToolPropertyToTerraform(struct?: TfFlow.DefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatToolConfigurationToolChoiceToolProperty | cdktn.IResolvable): any;
export declare function tfFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatToolConfigurationToolChoiceToolPropertyToHclTerraform(struct?: TfFlow.DefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatToolConfigurationToolChoiceToolProperty | cdktn.IResolvable): any;
export declare function tfFlowToolChoicePropertyToTerraform(struct?: TfFlow.ToolChoiceProperty | cdktn.IResolvable): any;
export declare function tfFlowToolChoicePropertyToHclTerraform(struct?: TfFlow.ToolChoiceProperty | cdktn.IResolvable): any;
export declare function tfFlowToolConfigurationPropertyToTerraform(struct?: TfFlow.ToolConfigurationProperty | cdktn.IResolvable): any;
export declare function tfFlowToolConfigurationPropertyToHclTerraform(struct?: TfFlow.ToolConfigurationProperty | cdktn.IResolvable): any;
export declare function tfFlowChatPropertyToTerraform(struct?: TfFlow.ChatProperty | cdktn.IResolvable): any;
export declare function tfFlowChatPropertyToHclTerraform(struct?: TfFlow.ChatProperty | cdktn.IResolvable): any;
export declare function tfFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationTextCachePointPropertyToTerraform(struct?: TfFlow.DefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationTextCachePointProperty | cdktn.IResolvable): any;
export declare function tfFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationTextCachePointPropertyToHclTerraform(struct?: TfFlow.DefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationTextCachePointProperty | cdktn.IResolvable): any;
export declare function tfFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationTextInputVariablePropertyToTerraform(struct?: TfFlow.DefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationTextInputVariableProperty | cdktn.IResolvable): any;
export declare function tfFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationTextInputVariablePropertyToHclTerraform(struct?: TfFlow.DefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationTextInputVariableProperty | cdktn.IResolvable): any;
export declare function tfFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationTextPropertyToTerraform(struct?: TfFlow.DefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationTextProperty | cdktn.IResolvable): any;
export declare function tfFlowDefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationTextPropertyToHclTerraform(struct?: TfFlow.DefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationTextProperty | cdktn.IResolvable): any;
export declare function tfFlowTemplateConfigurationPropertyToTerraform(struct?: TfFlow.TemplateConfigurationProperty | cdktn.IResolvable): any;
export declare function tfFlowTemplateConfigurationPropertyToHclTerraform(struct?: TfFlow.TemplateConfigurationProperty | cdktn.IResolvable): any;
export declare function tfFlowInlinePropertyToTerraform(struct?: TfFlow.InlineProperty | cdktn.IResolvable): any;
export declare function tfFlowInlinePropertyToHclTerraform(struct?: TfFlow.InlineProperty | cdktn.IResolvable): any;
export declare function tfFlowResourcePropertyToTerraform(struct?: TfFlow.ResourceProperty | cdktn.IResolvable): any;
export declare function tfFlowResourcePropertyToHclTerraform(struct?: TfFlow.ResourceProperty | cdktn.IResolvable): any;
export declare function tfFlowSourceConfigurationPropertyToTerraform(struct?: TfFlow.SourceConfigurationProperty | cdktn.IResolvable): any;
export declare function tfFlowSourceConfigurationPropertyToHclTerraform(struct?: TfFlow.SourceConfigurationProperty | cdktn.IResolvable): any;
export declare function tfFlowPromptPropertyToTerraform(struct?: TfFlow.PromptProperty | cdktn.IResolvable): any;
export declare function tfFlowPromptPropertyToHclTerraform(struct?: TfFlow.PromptProperty | cdktn.IResolvable): any;
export declare function tfFlowDefinitionNodeConfigurationRetrievalServiceConfigurationS3PropertyToTerraform(struct?: TfFlow.DefinitionNodeConfigurationRetrievalServiceConfigurationS3Property | cdktn.IResolvable): any;
export declare function tfFlowDefinitionNodeConfigurationRetrievalServiceConfigurationS3PropertyToHclTerraform(struct?: TfFlow.DefinitionNodeConfigurationRetrievalServiceConfigurationS3Property | cdktn.IResolvable): any;
export declare function tfFlowDefinitionNodeConfigurationRetrievalServiceConfigurationPropertyToTerraform(struct?: TfFlow.DefinitionNodeConfigurationRetrievalServiceConfigurationProperty | cdktn.IResolvable): any;
export declare function tfFlowDefinitionNodeConfigurationRetrievalServiceConfigurationPropertyToHclTerraform(struct?: TfFlow.DefinitionNodeConfigurationRetrievalServiceConfigurationProperty | cdktn.IResolvable): any;
export declare function tfFlowRetrievalPropertyToTerraform(struct?: TfFlow.RetrievalProperty | cdktn.IResolvable): any;
export declare function tfFlowRetrievalPropertyToHclTerraform(struct?: TfFlow.RetrievalProperty | cdktn.IResolvable): any;
export declare function tfFlowDefinitionNodeConfigurationStorageServiceConfigurationS3PropertyToTerraform(struct?: TfFlow.DefinitionNodeConfigurationStorageServiceConfigurationS3Property | cdktn.IResolvable): any;
export declare function tfFlowDefinitionNodeConfigurationStorageServiceConfigurationS3PropertyToHclTerraform(struct?: TfFlow.DefinitionNodeConfigurationStorageServiceConfigurationS3Property | cdktn.IResolvable): any;
export declare function tfFlowDefinitionNodeConfigurationStorageServiceConfigurationPropertyToTerraform(struct?: TfFlow.DefinitionNodeConfigurationStorageServiceConfigurationProperty | cdktn.IResolvable): any;
export declare function tfFlowDefinitionNodeConfigurationStorageServiceConfigurationPropertyToHclTerraform(struct?: TfFlow.DefinitionNodeConfigurationStorageServiceConfigurationProperty | cdktn.IResolvable): any;
export declare function tfFlowStoragePropertyToTerraform(struct?: TfFlow.StorageProperty | cdktn.IResolvable): any;
export declare function tfFlowStoragePropertyToHclTerraform(struct?: TfFlow.StorageProperty | cdktn.IResolvable): any;
export declare function tfFlowDefinitionNodeConfigurationPropertyToTerraform(struct?: TfFlow.DefinitionNodeConfigurationProperty | cdktn.IResolvable): any;
export declare function tfFlowDefinitionNodeConfigurationPropertyToHclTerraform(struct?: TfFlow.DefinitionNodeConfigurationProperty | cdktn.IResolvable): any;
export declare function tfFlowDefinitionNodeInputPropertyToTerraform(struct?: TfFlow.DefinitionNodeInputProperty | cdktn.IResolvable): any;
export declare function tfFlowDefinitionNodeInputPropertyToHclTerraform(struct?: TfFlow.DefinitionNodeInputProperty | cdktn.IResolvable): any;
export declare function tfFlowDefinitionNodeOutputPropertyToTerraform(struct?: TfFlow.DefinitionNodeOutputProperty | cdktn.IResolvable): any;
export declare function tfFlowDefinitionNodeOutputPropertyToHclTerraform(struct?: TfFlow.DefinitionNodeOutputProperty | cdktn.IResolvable): any;
export declare function tfFlowNodePropertyToTerraform(struct?: TfFlow.NodeProperty | cdktn.IResolvable): any;
export declare function tfFlowNodePropertyToHclTerraform(struct?: TfFlow.NodeProperty | cdktn.IResolvable): any;
export declare function tfFlowDefinitionPropertyToTerraform(struct?: TfFlow.DefinitionProperty | cdktn.IResolvable): any;
export declare function tfFlowDefinitionPropertyToHclTerraform(struct?: TfFlow.DefinitionProperty | cdktn.IResolvable): any;
export declare function tfFlowTimeoutsPropertyToTerraform(struct?: TfFlow.TimeoutsProperty | cdktn.IResolvable): any;
export declare function tfFlowTimeoutsPropertyToHclTerraform(struct?: TfFlow.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace TfFlow {
    interface ConditionalProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_flow#condition TfFlow#condition}
        */
        readonly condition: string;
    }
    class ConditionalPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ConditionalProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ConditionalProperty | cdktn.IResolvable | undefined);
        private _condition?;
        get condition(): string;
        set condition(value: string);
        get conditionInput(): string | undefined;
    }
    class ConditionalPropertyList extends cdktn.ComplexList {
        internalValue?: ConditionalProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ConditionalPropertyOutputReference;
    }
    interface DataProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_flow#source_output TfFlow#source_output}
        */
        readonly sourceOutput: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_flow#target_input TfFlow#target_input}
        */
        readonly targetInput: string;
    }
    class DataPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DataProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DataProperty | cdktn.IResolvable | undefined);
        private _sourceOutput?;
        get sourceOutput(): string;
        set sourceOutput(value: string);
        get sourceOutputInput(): string | undefined;
        private _targetInput?;
        get targetInput(): string;
        set targetInput(value: string);
        get targetInputInput(): string | undefined;
    }
    class DataPropertyList extends cdktn.ComplexList {
        internalValue?: DataProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DataPropertyOutputReference;
    }
    interface DefinitionConnectionConfigurationProperty {
        /**
        * conditional block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_flow#conditional TfFlow#conditional}
        */
        readonly conditional?: ConditionalProperty[] | cdktn.IResolvable;
        /**
        * data block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_flow#data TfFlow#data}
        */
        readonly data?: DataProperty[] | cdktn.IResolvable;
    }
    class DefinitionConnectionConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DefinitionConnectionConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DefinitionConnectionConfigurationProperty | cdktn.IResolvable | undefined);
        private _conditional;
        get conditional(): ConditionalPropertyList;
        putConditional(value: ConditionalProperty[] | cdktn.IResolvable): void;
        resetConditional(): void;
        get conditionalInput(): cdktn.IResolvable | ConditionalProperty[] | undefined;
        private _data;
        get data(): DataPropertyList;
        putData(value: DataProperty[] | cdktn.IResolvable): void;
        resetData(): void;
        get dataInput(): cdktn.IResolvable | DataProperty[] | undefined;
    }
    class DefinitionConnectionConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: DefinitionConnectionConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DefinitionConnectionConfigurationPropertyOutputReference;
    }
    interface ConnectionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_flow#name TfFlow#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_flow#source TfFlow#source}
        */
        readonly source: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_flow#target TfFlow#target}
        */
        readonly target: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_flow#type TfFlow#type}
        */
        readonly type: string;
        /**
        * configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_flow#configuration TfFlow#configuration}
        */
        readonly configuration?: DefinitionConnectionConfigurationProperty[] | cdktn.IResolvable;
    }
    class ConnectionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ConnectionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ConnectionProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _source?;
        get source(): string;
        set source(value: string);
        get sourceInput(): string | undefined;
        private _target?;
        get target(): string;
        set target(value: string);
        get targetInput(): string | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
        private _configuration;
        get configuration(): DefinitionConnectionConfigurationPropertyList;
        putConfiguration(value: DefinitionConnectionConfigurationProperty[] | cdktn.IResolvable): void;
        resetConfiguration(): void;
        get configurationInput(): cdktn.IResolvable | DefinitionConnectionConfigurationProperty[] | undefined;
    }
    class ConnectionPropertyList extends cdktn.ComplexList {
        internalValue?: ConnectionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ConnectionPropertyOutputReference;
    }
    interface AgentProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_flow#agent_alias_arn TfFlow#agent_alias_arn}
        */
        readonly agentAliasArn: string;
    }
    class AgentPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AgentProperty | cdktn.IResolvable | undefined;
        set internalValue(value: AgentProperty | cdktn.IResolvable | undefined);
        private _agentAliasArn?;
        get agentAliasArn(): string;
        set agentAliasArn(value: string);
        get agentAliasArnInput(): string | undefined;
    }
    class AgentPropertyList extends cdktn.ComplexList {
        internalValue?: AgentProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AgentPropertyOutputReference;
    }
    interface CollectorProperty {
    }
    class CollectorPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CollectorProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CollectorProperty | cdktn.IResolvable | undefined);
    }
    class CollectorPropertyList extends cdktn.ComplexList {
        internalValue?: CollectorProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CollectorPropertyOutputReference;
    }
    interface DefinitionNodeConfigurationConditionConditionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_flow#expression TfFlow#expression}
        */
        readonly expression?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_flow#name TfFlow#name}
        */
        readonly name: string;
    }
    class DefinitionNodeConfigurationConditionConditionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DefinitionNodeConfigurationConditionConditionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DefinitionNodeConfigurationConditionConditionProperty | cdktn.IResolvable | undefined);
        private _expression?;
        get expression(): string;
        set expression(value: string);
        resetExpression(): void;
        get expressionInput(): string | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
    }
    class DefinitionNodeConfigurationConditionConditionPropertyList extends cdktn.ComplexList {
        internalValue?: DefinitionNodeConfigurationConditionConditionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DefinitionNodeConfigurationConditionConditionPropertyOutputReference;
    }
    interface DefinitionNodeConfigurationConditionProperty {
        /**
        * condition block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_flow#condition TfFlow#condition}
        */
        readonly condition?: DefinitionNodeConfigurationConditionConditionProperty[] | cdktn.IResolvable;
    }
    class DefinitionNodeConfigurationConditionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DefinitionNodeConfigurationConditionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DefinitionNodeConfigurationConditionProperty | cdktn.IResolvable | undefined);
        private _condition;
        get condition(): DefinitionNodeConfigurationConditionConditionPropertyList;
        putCondition(value: DefinitionNodeConfigurationConditionConditionProperty[] | cdktn.IResolvable): void;
        resetCondition(): void;
        get conditionInput(): cdktn.IResolvable | DefinitionNodeConfigurationConditionConditionProperty[] | undefined;
    }
    class DefinitionNodeConfigurationConditionPropertyList extends cdktn.ComplexList {
        internalValue?: DefinitionNodeConfigurationConditionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DefinitionNodeConfigurationConditionPropertyOutputReference;
    }
    interface InlineCodeProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_flow#code TfFlow#code}
        */
        readonly code: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_flow#language TfFlow#language}
        */
        readonly language: string;
    }
    class InlineCodePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): InlineCodeProperty | cdktn.IResolvable | undefined;
        set internalValue(value: InlineCodeProperty | cdktn.IResolvable | undefined);
        private _code?;
        get code(): string;
        set code(value: string);
        get codeInput(): string | undefined;
        private _language?;
        get language(): string;
        set language(value: string);
        get languageInput(): string | undefined;
    }
    class InlineCodePropertyList extends cdktn.ComplexList {
        internalValue?: InlineCodeProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): InlineCodePropertyOutputReference;
    }
    interface DefinitionNodeConfigurationInputProperty {
    }
    class DefinitionNodeConfigurationInputPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DefinitionNodeConfigurationInputProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DefinitionNodeConfigurationInputProperty | cdktn.IResolvable | undefined);
    }
    class DefinitionNodeConfigurationInputPropertyList extends cdktn.ComplexList {
        internalValue?: DefinitionNodeConfigurationInputProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DefinitionNodeConfigurationInputPropertyOutputReference;
    }
    interface IteratorProperty {
    }
    class IteratorPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): IteratorProperty | cdktn.IResolvable | undefined;
        set internalValue(value: IteratorProperty | cdktn.IResolvable | undefined);
    }
    class IteratorPropertyList extends cdktn.ComplexList {
        internalValue?: IteratorProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): IteratorPropertyOutputReference;
    }
    interface DefinitionNodeConfigurationKnowledgeBaseGuardrailConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_flow#guardrail_identifier TfFlow#guardrail_identifier}
        */
        readonly guardrailIdentifier: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_flow#guardrail_version TfFlow#guardrail_version}
        */
        readonly guardrailVersion: string;
    }
    class DefinitionNodeConfigurationKnowledgeBaseGuardrailConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DefinitionNodeConfigurationKnowledgeBaseGuardrailConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DefinitionNodeConfigurationKnowledgeBaseGuardrailConfigurationProperty | cdktn.IResolvable | undefined);
        private _guardrailIdentifier?;
        get guardrailIdentifier(): string;
        set guardrailIdentifier(value: string);
        get guardrailIdentifierInput(): string | undefined;
        private _guardrailVersion?;
        get guardrailVersion(): string;
        set guardrailVersion(value: string);
        get guardrailVersionInput(): string | undefined;
    }
    class DefinitionNodeConfigurationKnowledgeBaseGuardrailConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: DefinitionNodeConfigurationKnowledgeBaseGuardrailConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DefinitionNodeConfigurationKnowledgeBaseGuardrailConfigurationPropertyOutputReference;
    }
    interface DefinitionNodeConfigurationKnowledgeBaseInferenceConfigurationTextProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_flow#max_tokens TfFlow#max_tokens}
        */
        readonly maxTokens?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_flow#stop_sequences TfFlow#stop_sequences}
        */
        readonly stopSequences?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_flow#temperature TfFlow#temperature}
        */
        readonly temperature?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_flow#top_p TfFlow#top_p}
        */
        readonly topP?: number;
    }
    class DefinitionNodeConfigurationKnowledgeBaseInferenceConfigurationTextPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DefinitionNodeConfigurationKnowledgeBaseInferenceConfigurationTextProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DefinitionNodeConfigurationKnowledgeBaseInferenceConfigurationTextProperty | cdktn.IResolvable | undefined);
        private _maxTokens?;
        get maxTokens(): number;
        set maxTokens(value: number);
        resetMaxTokens(): void;
        get maxTokensInput(): number | undefined;
        private _stopSequences?;
        get stopSequences(): string[];
        set stopSequences(value: string[]);
        resetStopSequences(): void;
        get stopSequencesInput(): string[] | undefined;
        private _temperature?;
        get temperature(): number;
        set temperature(value: number);
        resetTemperature(): void;
        get temperatureInput(): number | undefined;
        private _topP?;
        get topP(): number;
        set topP(value: number);
        resetTopP(): void;
        get topPInput(): number | undefined;
    }
    class DefinitionNodeConfigurationKnowledgeBaseInferenceConfigurationTextPropertyList extends cdktn.ComplexList {
        internalValue?: DefinitionNodeConfigurationKnowledgeBaseInferenceConfigurationTextProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DefinitionNodeConfigurationKnowledgeBaseInferenceConfigurationTextPropertyOutputReference;
    }
    interface DefinitionNodeConfigurationKnowledgeBaseInferenceConfigurationProperty {
        /**
        * text block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_flow#text TfFlow#text}
        */
        readonly text?: DefinitionNodeConfigurationKnowledgeBaseInferenceConfigurationTextProperty[] | cdktn.IResolvable;
    }
    class DefinitionNodeConfigurationKnowledgeBaseInferenceConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DefinitionNodeConfigurationKnowledgeBaseInferenceConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DefinitionNodeConfigurationKnowledgeBaseInferenceConfigurationProperty | cdktn.IResolvable | undefined);
        private _text;
        get text(): DefinitionNodeConfigurationKnowledgeBaseInferenceConfigurationTextPropertyList;
        putText(value: DefinitionNodeConfigurationKnowledgeBaseInferenceConfigurationTextProperty[] | cdktn.IResolvable): void;
        resetText(): void;
        get textInput(): cdktn.IResolvable | DefinitionNodeConfigurationKnowledgeBaseInferenceConfigurationTextProperty[] | undefined;
    }
    class DefinitionNodeConfigurationKnowledgeBaseInferenceConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: DefinitionNodeConfigurationKnowledgeBaseInferenceConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DefinitionNodeConfigurationKnowledgeBaseInferenceConfigurationPropertyOutputReference;
    }
    interface KnowledgeBaseProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_flow#knowledge_base_id TfFlow#knowledge_base_id}
        */
        readonly knowledgeBaseId: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_flow#model_id TfFlow#model_id}
        */
        readonly modelId: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_flow#number_of_results TfFlow#number_of_results}
        */
        readonly numberOfResults?: number;
        /**
        * guardrail_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_flow#guardrail_configuration TfFlow#guardrail_configuration}
        */
        readonly guardrailConfiguration?: DefinitionNodeConfigurationKnowledgeBaseGuardrailConfigurationProperty[] | cdktn.IResolvable;
        /**
        * inference_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_flow#inference_configuration TfFlow#inference_configuration}
        */
        readonly inferenceConfiguration?: DefinitionNodeConfigurationKnowledgeBaseInferenceConfigurationProperty[] | cdktn.IResolvable;
    }
    class KnowledgeBasePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): KnowledgeBaseProperty | cdktn.IResolvable | undefined;
        set internalValue(value: KnowledgeBaseProperty | cdktn.IResolvable | undefined);
        private _knowledgeBaseId?;
        get knowledgeBaseId(): string;
        set knowledgeBaseId(value: string);
        get knowledgeBaseIdInput(): string | undefined;
        private _modelId?;
        get modelId(): string;
        set modelId(value: string);
        get modelIdInput(): string | undefined;
        private _numberOfResults?;
        get numberOfResults(): number;
        set numberOfResults(value: number);
        resetNumberOfResults(): void;
        get numberOfResultsInput(): number | undefined;
        private _guardrailConfiguration;
        get guardrailConfiguration(): DefinitionNodeConfigurationKnowledgeBaseGuardrailConfigurationPropertyList;
        putGuardrailConfiguration(value: DefinitionNodeConfigurationKnowledgeBaseGuardrailConfigurationProperty[] | cdktn.IResolvable): void;
        resetGuardrailConfiguration(): void;
        get guardrailConfigurationInput(): cdktn.IResolvable | DefinitionNodeConfigurationKnowledgeBaseGuardrailConfigurationProperty[] | undefined;
        private _inferenceConfiguration;
        get inferenceConfiguration(): DefinitionNodeConfigurationKnowledgeBaseInferenceConfigurationPropertyList;
        putInferenceConfiguration(value: DefinitionNodeConfigurationKnowledgeBaseInferenceConfigurationProperty[] | cdktn.IResolvable): void;
        resetInferenceConfiguration(): void;
        get inferenceConfigurationInput(): cdktn.IResolvable | DefinitionNodeConfigurationKnowledgeBaseInferenceConfigurationProperty[] | undefined;
    }
    class KnowledgeBasePropertyList extends cdktn.ComplexList {
        internalValue?: KnowledgeBaseProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): KnowledgeBasePropertyOutputReference;
    }
    interface LambdaFunctionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_flow#lambda_arn TfFlow#lambda_arn}
        */
        readonly lambdaArn: string;
    }
    class LambdaFunctionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): LambdaFunctionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: LambdaFunctionProperty | cdktn.IResolvable | undefined);
        private _lambdaArn?;
        get lambdaArn(): string;
        set lambdaArn(value: string);
        get lambdaArnInput(): string | undefined;
    }
    class LambdaFunctionPropertyList extends cdktn.ComplexList {
        internalValue?: LambdaFunctionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): LambdaFunctionPropertyOutputReference;
    }
    interface LexProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_flow#bot_alias_arn TfFlow#bot_alias_arn}
        */
        readonly botAliasArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_flow#locale_id TfFlow#locale_id}
        */
        readonly localeId: string;
    }
    class LexPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): LexProperty | cdktn.IResolvable | undefined;
        set internalValue(value: LexProperty | cdktn.IResolvable | undefined);
        private _botAliasArn?;
        get botAliasArn(): string;
        set botAliasArn(value: string);
        get botAliasArnInput(): string | undefined;
        private _localeId?;
        get localeId(): string;
        set localeId(value: string);
        get localeIdInput(): string | undefined;
    }
    class LexPropertyList extends cdktn.ComplexList {
        internalValue?: LexProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): LexPropertyOutputReference;
    }
    interface DefinitionNodeConfigurationOutputProperty {
    }
    class DefinitionNodeConfigurationOutputPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DefinitionNodeConfigurationOutputProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DefinitionNodeConfigurationOutputProperty | cdktn.IResolvable | undefined);
    }
    class DefinitionNodeConfigurationOutputPropertyList extends cdktn.ComplexList {
        internalValue?: DefinitionNodeConfigurationOutputProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DefinitionNodeConfigurationOutputPropertyOutputReference;
    }
    interface DefinitionNodeConfigurationPromptGuardrailConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_flow#guardrail_identifier TfFlow#guardrail_identifier}
        */
        readonly guardrailIdentifier: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_flow#guardrail_version TfFlow#guardrail_version}
        */
        readonly guardrailVersion: string;
    }
    class DefinitionNodeConfigurationPromptGuardrailConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DefinitionNodeConfigurationPromptGuardrailConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DefinitionNodeConfigurationPromptGuardrailConfigurationProperty | cdktn.IResolvable | undefined);
        private _guardrailIdentifier?;
        get guardrailIdentifier(): string;
        set guardrailIdentifier(value: string);
        get guardrailIdentifierInput(): string | undefined;
        private _guardrailVersion?;
        get guardrailVersion(): string;
        set guardrailVersion(value: string);
        get guardrailVersionInput(): string | undefined;
    }
    class DefinitionNodeConfigurationPromptGuardrailConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: DefinitionNodeConfigurationPromptGuardrailConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DefinitionNodeConfigurationPromptGuardrailConfigurationPropertyOutputReference;
    }
    interface DefinitionNodeConfigurationPromptSourceConfigurationInlineInferenceConfigurationTextProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_flow#max_tokens TfFlow#max_tokens}
        */
        readonly maxTokens?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_flow#stop_sequences TfFlow#stop_sequences}
        */
        readonly stopSequences?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_flow#temperature TfFlow#temperature}
        */
        readonly temperature?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_flow#top_p TfFlow#top_p}
        */
        readonly topP?: number;
    }
    class DefinitionNodeConfigurationPromptSourceConfigurationInlineInferenceConfigurationTextPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DefinitionNodeConfigurationPromptSourceConfigurationInlineInferenceConfigurationTextProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DefinitionNodeConfigurationPromptSourceConfigurationInlineInferenceConfigurationTextProperty | cdktn.IResolvable | undefined);
        private _maxTokens?;
        get maxTokens(): number;
        set maxTokens(value: number);
        resetMaxTokens(): void;
        get maxTokensInput(): number | undefined;
        private _stopSequences?;
        get stopSequences(): string[];
        set stopSequences(value: string[]);
        resetStopSequences(): void;
        get stopSequencesInput(): string[] | undefined;
        private _temperature?;
        get temperature(): number;
        set temperature(value: number);
        resetTemperature(): void;
        get temperatureInput(): number | undefined;
        private _topP?;
        get topP(): number;
        set topP(value: number);
        resetTopP(): void;
        get topPInput(): number | undefined;
    }
    class DefinitionNodeConfigurationPromptSourceConfigurationInlineInferenceConfigurationTextPropertyList extends cdktn.ComplexList {
        internalValue?: DefinitionNodeConfigurationPromptSourceConfigurationInlineInferenceConfigurationTextProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DefinitionNodeConfigurationPromptSourceConfigurationInlineInferenceConfigurationTextPropertyOutputReference;
    }
    interface DefinitionNodeConfigurationPromptSourceConfigurationInlineInferenceConfigurationProperty {
        /**
        * text block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_flow#text TfFlow#text}
        */
        readonly text?: DefinitionNodeConfigurationPromptSourceConfigurationInlineInferenceConfigurationTextProperty[] | cdktn.IResolvable;
    }
    class DefinitionNodeConfigurationPromptSourceConfigurationInlineInferenceConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DefinitionNodeConfigurationPromptSourceConfigurationInlineInferenceConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DefinitionNodeConfigurationPromptSourceConfigurationInlineInferenceConfigurationProperty | cdktn.IResolvable | undefined);
        private _text;
        get text(): DefinitionNodeConfigurationPromptSourceConfigurationInlineInferenceConfigurationTextPropertyList;
        putText(value: DefinitionNodeConfigurationPromptSourceConfigurationInlineInferenceConfigurationTextProperty[] | cdktn.IResolvable): void;
        resetText(): void;
        get textInput(): cdktn.IResolvable | DefinitionNodeConfigurationPromptSourceConfigurationInlineInferenceConfigurationTextProperty[] | undefined;
    }
    class DefinitionNodeConfigurationPromptSourceConfigurationInlineInferenceConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: DefinitionNodeConfigurationPromptSourceConfigurationInlineInferenceConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DefinitionNodeConfigurationPromptSourceConfigurationInlineInferenceConfigurationPropertyOutputReference;
    }
    interface DefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatInputVariableProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_flow#name TfFlow#name}
        */
        readonly name: string;
    }
    class DefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatInputVariablePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatInputVariableProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatInputVariableProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
    }
    class DefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatInputVariablePropertyList extends cdktn.ComplexList {
        internalValue?: DefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatInputVariableProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatInputVariablePropertyOutputReference;
    }
    interface DefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatMessageContentCachePointProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_flow#type TfFlow#type}
        */
        readonly type: string;
    }
    class DefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatMessageContentCachePointPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatMessageContentCachePointProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatMessageContentCachePointProperty | cdktn.IResolvable | undefined);
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
    }
    class DefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatMessageContentCachePointPropertyList extends cdktn.ComplexList {
        internalValue?: DefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatMessageContentCachePointProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatMessageContentCachePointPropertyOutputReference;
    }
    interface ContentProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_flow#text TfFlow#text}
        */
        readonly text?: string;
        /**
        * cache_point block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_flow#cache_point TfFlow#cache_point}
        */
        readonly cachePoint?: DefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatMessageContentCachePointProperty[] | cdktn.IResolvable;
    }
    class ContentPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ContentProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ContentProperty | cdktn.IResolvable | undefined);
        private _text?;
        get text(): string;
        set text(value: string);
        resetText(): void;
        get textInput(): string | undefined;
        private _cachePoint;
        get cachePoint(): DefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatMessageContentCachePointPropertyList;
        putCachePoint(value: DefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatMessageContentCachePointProperty[] | cdktn.IResolvable): void;
        resetCachePoint(): void;
        get cachePointInput(): cdktn.IResolvable | DefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatMessageContentCachePointProperty[] | undefined;
    }
    class ContentPropertyList extends cdktn.ComplexList {
        internalValue?: ContentProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ContentPropertyOutputReference;
    }
    interface MessageProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_flow#role TfFlow#role}
        */
        readonly role: string;
        /**
        * content block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_flow#content TfFlow#content}
        */
        readonly content?: ContentProperty[] | cdktn.IResolvable;
    }
    class MessagePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): MessageProperty | cdktn.IResolvable | undefined;
        set internalValue(value: MessageProperty | cdktn.IResolvable | undefined);
        private _role?;
        get role(): string;
        set role(value: string);
        get roleInput(): string | undefined;
        private _content;
        get content(): ContentPropertyList;
        putContent(value: ContentProperty[] | cdktn.IResolvable): void;
        resetContent(): void;
        get contentInput(): cdktn.IResolvable | ContentProperty[] | undefined;
    }
    class MessagePropertyList extends cdktn.ComplexList {
        internalValue?: MessageProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): MessagePropertyOutputReference;
    }
    interface DefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatSystemCachePointProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_flow#type TfFlow#type}
        */
        readonly type: string;
    }
    class DefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatSystemCachePointPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatSystemCachePointProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatSystemCachePointProperty | cdktn.IResolvable | undefined);
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
    }
    class DefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatSystemCachePointPropertyList extends cdktn.ComplexList {
        internalValue?: DefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatSystemCachePointProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatSystemCachePointPropertyOutputReference;
    }
    interface SystemProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_flow#text TfFlow#text}
        */
        readonly text?: string;
        /**
        * cache_point block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_flow#cache_point TfFlow#cache_point}
        */
        readonly cachePoint?: DefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatSystemCachePointProperty[] | cdktn.IResolvable;
    }
    class SystemPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SystemProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SystemProperty | cdktn.IResolvable | undefined);
        private _text?;
        get text(): string;
        set text(value: string);
        resetText(): void;
        get textInput(): string | undefined;
        private _cachePoint;
        get cachePoint(): DefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatSystemCachePointPropertyList;
        putCachePoint(value: DefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatSystemCachePointProperty[] | cdktn.IResolvable): void;
        resetCachePoint(): void;
        get cachePointInput(): cdktn.IResolvable | DefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatSystemCachePointProperty[] | undefined;
    }
    class SystemPropertyList extends cdktn.ComplexList {
        internalValue?: SystemProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SystemPropertyOutputReference;
    }
    interface DefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatToolConfigurationToolCachePointProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_flow#type TfFlow#type}
        */
        readonly type: string;
    }
    class DefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatToolConfigurationToolCachePointPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatToolConfigurationToolCachePointProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatToolConfigurationToolCachePointProperty | cdktn.IResolvable | undefined);
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
    }
    class DefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatToolConfigurationToolCachePointPropertyList extends cdktn.ComplexList {
        internalValue?: DefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatToolConfigurationToolCachePointProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatToolConfigurationToolCachePointPropertyOutputReference;
    }
    interface InputSchemaProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_flow#json TfFlow#json}
        */
        readonly json?: string;
    }
    class InputSchemaPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): InputSchemaProperty | cdktn.IResolvable | undefined;
        set internalValue(value: InputSchemaProperty | cdktn.IResolvable | undefined);
        private _json?;
        get json(): string;
        set json(value: string);
        resetJson(): void;
        get jsonInput(): string | undefined;
    }
    class InputSchemaPropertyList extends cdktn.ComplexList {
        internalValue?: InputSchemaProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): InputSchemaPropertyOutputReference;
    }
    interface ToolSpecProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_flow#description TfFlow#description}
        */
        readonly description?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_flow#name TfFlow#name}
        */
        readonly name: string;
        /**
        * input_schema block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_flow#input_schema TfFlow#input_schema}
        */
        readonly inputSchema?: InputSchemaProperty[] | cdktn.IResolvable;
    }
    class ToolSpecPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ToolSpecProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ToolSpecProperty | cdktn.IResolvable | undefined);
        private _description?;
        get description(): string;
        set description(value: string);
        resetDescription(): void;
        get descriptionInput(): string | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _inputSchema;
        get inputSchema(): InputSchemaPropertyList;
        putInputSchema(value: InputSchemaProperty[] | cdktn.IResolvable): void;
        resetInputSchema(): void;
        get inputSchemaInput(): cdktn.IResolvable | InputSchemaProperty[] | undefined;
    }
    class ToolSpecPropertyList extends cdktn.ComplexList {
        internalValue?: ToolSpecProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ToolSpecPropertyOutputReference;
    }
    interface DefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatToolConfigurationToolProperty {
        /**
        * cache_point block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_flow#cache_point TfFlow#cache_point}
        */
        readonly cachePoint?: DefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatToolConfigurationToolCachePointProperty[] | cdktn.IResolvable;
        /**
        * tool_spec block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_flow#tool_spec TfFlow#tool_spec}
        */
        readonly toolSpec?: ToolSpecProperty[] | cdktn.IResolvable;
    }
    class DefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatToolConfigurationToolPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatToolConfigurationToolProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatToolConfigurationToolProperty | cdktn.IResolvable | undefined);
        private _cachePoint;
        get cachePoint(): DefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatToolConfigurationToolCachePointPropertyList;
        putCachePoint(value: DefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatToolConfigurationToolCachePointProperty[] | cdktn.IResolvable): void;
        resetCachePoint(): void;
        get cachePointInput(): cdktn.IResolvable | DefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatToolConfigurationToolCachePointProperty[] | undefined;
        private _toolSpec;
        get toolSpec(): ToolSpecPropertyList;
        putToolSpec(value: ToolSpecProperty[] | cdktn.IResolvable): void;
        resetToolSpec(): void;
        get toolSpecInput(): cdktn.IResolvable | ToolSpecProperty[] | undefined;
    }
    class DefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatToolConfigurationToolPropertyList extends cdktn.ComplexList {
        internalValue?: DefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatToolConfigurationToolProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatToolConfigurationToolPropertyOutputReference;
    }
    interface AnyProperty {
    }
    class AnyPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AnyProperty | cdktn.IResolvable | undefined;
        set internalValue(value: AnyProperty | cdktn.IResolvable | undefined);
    }
    class AnyPropertyList extends cdktn.ComplexList {
        internalValue?: AnyProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AnyPropertyOutputReference;
    }
    interface AutoProperty {
    }
    class AutoPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AutoProperty | cdktn.IResolvable | undefined;
        set internalValue(value: AutoProperty | cdktn.IResolvable | undefined);
    }
    class AutoPropertyList extends cdktn.ComplexList {
        internalValue?: AutoProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AutoPropertyOutputReference;
    }
    interface DefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatToolConfigurationToolChoiceToolProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_flow#name TfFlow#name}
        */
        readonly name: string;
    }
    class DefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatToolConfigurationToolChoiceToolPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatToolConfigurationToolChoiceToolProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatToolConfigurationToolChoiceToolProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
    }
    class DefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatToolConfigurationToolChoiceToolPropertyList extends cdktn.ComplexList {
        internalValue?: DefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatToolConfigurationToolChoiceToolProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatToolConfigurationToolChoiceToolPropertyOutputReference;
    }
    interface ToolChoiceProperty {
        /**
        * any block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_flow#any TfFlow#any}
        */
        readonly any?: AnyProperty[] | cdktn.IResolvable;
        /**
        * auto block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_flow#auto TfFlow#auto}
        */
        readonly auto?: AutoProperty[] | cdktn.IResolvable;
        /**
        * tool block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_flow#tool TfFlow#tool}
        */
        readonly tool?: DefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatToolConfigurationToolChoiceToolProperty[] | cdktn.IResolvable;
    }
    class ToolChoicePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ToolChoiceProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ToolChoiceProperty | cdktn.IResolvable | undefined);
        private _any;
        get any(): AnyPropertyList;
        putAny(value: AnyProperty[] | cdktn.IResolvable): void;
        resetAny(): void;
        get anyInput(): cdktn.IResolvable | AnyProperty[] | undefined;
        private _auto;
        get auto(): AutoPropertyList;
        putAuto(value: AutoProperty[] | cdktn.IResolvable): void;
        resetAuto(): void;
        get autoInput(): cdktn.IResolvable | AutoProperty[] | undefined;
        private _tool;
        get tool(): DefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatToolConfigurationToolChoiceToolPropertyList;
        putTool(value: DefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatToolConfigurationToolChoiceToolProperty[] | cdktn.IResolvable): void;
        resetTool(): void;
        get toolInput(): cdktn.IResolvable | DefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatToolConfigurationToolChoiceToolProperty[] | undefined;
    }
    class ToolChoicePropertyList extends cdktn.ComplexList {
        internalValue?: ToolChoiceProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ToolChoicePropertyOutputReference;
    }
    interface ToolConfigurationProperty {
        /**
        * tool block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_flow#tool TfFlow#tool}
        */
        readonly tool?: DefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatToolConfigurationToolProperty[] | cdktn.IResolvable;
        /**
        * tool_choice block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_flow#tool_choice TfFlow#tool_choice}
        */
        readonly toolChoice?: ToolChoiceProperty[] | cdktn.IResolvable;
    }
    class ToolConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ToolConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ToolConfigurationProperty | cdktn.IResolvable | undefined);
        private _tool;
        get tool(): DefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatToolConfigurationToolPropertyList;
        putTool(value: DefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatToolConfigurationToolProperty[] | cdktn.IResolvable): void;
        resetTool(): void;
        get toolInput(): cdktn.IResolvable | DefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatToolConfigurationToolProperty[] | undefined;
        private _toolChoice;
        get toolChoice(): ToolChoicePropertyList;
        putToolChoice(value: ToolChoiceProperty[] | cdktn.IResolvable): void;
        resetToolChoice(): void;
        get toolChoiceInput(): cdktn.IResolvable | ToolChoiceProperty[] | undefined;
    }
    class ToolConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: ToolConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ToolConfigurationPropertyOutputReference;
    }
    interface ChatProperty {
        /**
        * input_variable block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_flow#input_variable TfFlow#input_variable}
        */
        readonly inputVariable?: DefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatInputVariableProperty[] | cdktn.IResolvable;
        /**
        * message block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_flow#message TfFlow#message}
        */
        readonly message?: MessageProperty[] | cdktn.IResolvable;
        /**
        * system block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_flow#system TfFlow#system}
        */
        readonly systemAttribute?: SystemProperty[] | cdktn.IResolvable;
        /**
        * tool_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_flow#tool_configuration TfFlow#tool_configuration}
        */
        readonly toolConfiguration?: ToolConfigurationProperty[] | cdktn.IResolvable;
    }
    class ChatPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ChatProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ChatProperty | cdktn.IResolvable | undefined);
        private _inputVariable;
        get inputVariable(): DefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatInputVariablePropertyList;
        putInputVariable(value: DefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatInputVariableProperty[] | cdktn.IResolvable): void;
        resetInputVariable(): void;
        get inputVariableInput(): cdktn.IResolvable | DefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationChatInputVariableProperty[] | undefined;
        private _message;
        get message(): MessagePropertyList;
        putMessage(value: MessageProperty[] | cdktn.IResolvable): void;
        resetMessage(): void;
        get messageInput(): cdktn.IResolvable | MessageProperty[] | undefined;
        private _system;
        get systemAttribute(): SystemPropertyList;
        putSystemAttribute(value: SystemProperty[] | cdktn.IResolvable): void;
        resetSystemAttribute(): void;
        get systemAttributeInput(): cdktn.IResolvable | SystemProperty[] | undefined;
        private _toolConfiguration;
        get toolConfiguration(): ToolConfigurationPropertyList;
        putToolConfiguration(value: ToolConfigurationProperty[] | cdktn.IResolvable): void;
        resetToolConfiguration(): void;
        get toolConfigurationInput(): cdktn.IResolvable | ToolConfigurationProperty[] | undefined;
    }
    class ChatPropertyList extends cdktn.ComplexList {
        internalValue?: ChatProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ChatPropertyOutputReference;
    }
    interface DefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationTextCachePointProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_flow#type TfFlow#type}
        */
        readonly type: string;
    }
    class DefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationTextCachePointPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationTextCachePointProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationTextCachePointProperty | cdktn.IResolvable | undefined);
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
    }
    class DefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationTextCachePointPropertyList extends cdktn.ComplexList {
        internalValue?: DefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationTextCachePointProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationTextCachePointPropertyOutputReference;
    }
    interface DefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationTextInputVariableProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_flow#name TfFlow#name}
        */
        readonly name: string;
    }
    class DefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationTextInputVariablePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationTextInputVariableProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationTextInputVariableProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
    }
    class DefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationTextInputVariablePropertyList extends cdktn.ComplexList {
        internalValue?: DefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationTextInputVariableProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationTextInputVariablePropertyOutputReference;
    }
    interface DefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationTextProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_flow#text TfFlow#text}
        */
        readonly text: string;
        /**
        * cache_point block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_flow#cache_point TfFlow#cache_point}
        */
        readonly cachePoint?: DefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationTextCachePointProperty[] | cdktn.IResolvable;
        /**
        * input_variable block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_flow#input_variable TfFlow#input_variable}
        */
        readonly inputVariable?: DefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationTextInputVariableProperty[] | cdktn.IResolvable;
    }
    class DefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationTextPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationTextProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationTextProperty | cdktn.IResolvable | undefined);
        private _text?;
        get text(): string;
        set text(value: string);
        get textInput(): string | undefined;
        private _cachePoint;
        get cachePoint(): DefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationTextCachePointPropertyList;
        putCachePoint(value: DefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationTextCachePointProperty[] | cdktn.IResolvable): void;
        resetCachePoint(): void;
        get cachePointInput(): cdktn.IResolvable | DefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationTextCachePointProperty[] | undefined;
        private _inputVariable;
        get inputVariable(): DefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationTextInputVariablePropertyList;
        putInputVariable(value: DefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationTextInputVariableProperty[] | cdktn.IResolvable): void;
        resetInputVariable(): void;
        get inputVariableInput(): cdktn.IResolvable | DefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationTextInputVariableProperty[] | undefined;
    }
    class DefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationTextPropertyList extends cdktn.ComplexList {
        internalValue?: DefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationTextProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationTextPropertyOutputReference;
    }
    interface TemplateConfigurationProperty {
        /**
        * chat block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_flow#chat TfFlow#chat}
        */
        readonly chat?: ChatProperty[] | cdktn.IResolvable;
        /**
        * text block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_flow#text TfFlow#text}
        */
        readonly text?: DefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationTextProperty[] | cdktn.IResolvable;
    }
    class TemplateConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TemplateConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TemplateConfigurationProperty | cdktn.IResolvable | undefined);
        private _chat;
        get chat(): ChatPropertyList;
        putChat(value: ChatProperty[] | cdktn.IResolvable): void;
        resetChat(): void;
        get chatInput(): cdktn.IResolvable | ChatProperty[] | undefined;
        private _text;
        get text(): DefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationTextPropertyList;
        putText(value: DefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationTextProperty[] | cdktn.IResolvable): void;
        resetText(): void;
        get textInput(): cdktn.IResolvable | DefinitionNodeConfigurationPromptSourceConfigurationInlineTemplateConfigurationTextProperty[] | undefined;
    }
    class TemplateConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: TemplateConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TemplateConfigurationPropertyOutputReference;
    }
    interface InlineProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_flow#additional_model_request_fields TfFlow#additional_model_request_fields}
        */
        readonly additionalModelRequestFields?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_flow#model_id TfFlow#model_id}
        */
        readonly modelId: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_flow#template_type TfFlow#template_type}
        */
        readonly templateType: string;
        /**
        * inference_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_flow#inference_configuration TfFlow#inference_configuration}
        */
        readonly inferenceConfiguration?: DefinitionNodeConfigurationPromptSourceConfigurationInlineInferenceConfigurationProperty[] | cdktn.IResolvable;
        /**
        * template_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_flow#template_configuration TfFlow#template_configuration}
        */
        readonly templateConfiguration?: TemplateConfigurationProperty[] | cdktn.IResolvable;
    }
    class InlinePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): InlineProperty | cdktn.IResolvable | undefined;
        set internalValue(value: InlineProperty | cdktn.IResolvable | undefined);
        private _additionalModelRequestFields?;
        get additionalModelRequestFields(): string;
        set additionalModelRequestFields(value: string);
        resetAdditionalModelRequestFields(): void;
        get additionalModelRequestFieldsInput(): string | undefined;
        private _modelId?;
        get modelId(): string;
        set modelId(value: string);
        get modelIdInput(): string | undefined;
        private _templateType?;
        get templateType(): string;
        set templateType(value: string);
        get templateTypeInput(): string | undefined;
        private _inferenceConfiguration;
        get inferenceConfiguration(): DefinitionNodeConfigurationPromptSourceConfigurationInlineInferenceConfigurationPropertyList;
        putInferenceConfiguration(value: DefinitionNodeConfigurationPromptSourceConfigurationInlineInferenceConfigurationProperty[] | cdktn.IResolvable): void;
        resetInferenceConfiguration(): void;
        get inferenceConfigurationInput(): cdktn.IResolvable | DefinitionNodeConfigurationPromptSourceConfigurationInlineInferenceConfigurationProperty[] | undefined;
        private _templateConfiguration;
        get templateConfiguration(): TemplateConfigurationPropertyList;
        putTemplateConfiguration(value: TemplateConfigurationProperty[] | cdktn.IResolvable): void;
        resetTemplateConfiguration(): void;
        get templateConfigurationInput(): cdktn.IResolvable | TemplateConfigurationProperty[] | undefined;
    }
    class InlinePropertyList extends cdktn.ComplexList {
        internalValue?: InlineProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): InlinePropertyOutputReference;
    }
    interface ResourceProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_flow#prompt_arn TfFlow#prompt_arn}
        */
        readonly promptArn: string;
    }
    class ResourcePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ResourceProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ResourceProperty | cdktn.IResolvable | undefined);
        private _promptArn?;
        get promptArn(): string;
        set promptArn(value: string);
        get promptArnInput(): string | undefined;
    }
    class ResourcePropertyList extends cdktn.ComplexList {
        internalValue?: ResourceProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ResourcePropertyOutputReference;
    }
    interface SourceConfigurationProperty {
        /**
        * inline block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_flow#inline TfFlow#inline}
        */
        readonly inline?: InlineProperty[] | cdktn.IResolvable;
        /**
        * resource block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_flow#resource TfFlow#resource}
        */
        readonly resource?: ResourceProperty[] | cdktn.IResolvable;
    }
    class SourceConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SourceConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SourceConfigurationProperty | cdktn.IResolvable | undefined);
        private _inline;
        get inline(): InlinePropertyList;
        putInline(value: InlineProperty[] | cdktn.IResolvable): void;
        resetInline(): void;
        get inlineInput(): cdktn.IResolvable | InlineProperty[] | undefined;
        private _resource;
        get resource(): ResourcePropertyList;
        putResource(value: ResourceProperty[] | cdktn.IResolvable): void;
        resetResource(): void;
        get resourceInput(): cdktn.IResolvable | ResourceProperty[] | undefined;
    }
    class SourceConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: SourceConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SourceConfigurationPropertyOutputReference;
    }
    interface PromptProperty {
        /**
        * guardrail_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_flow#guardrail_configuration TfFlow#guardrail_configuration}
        */
        readonly guardrailConfiguration?: DefinitionNodeConfigurationPromptGuardrailConfigurationProperty[] | cdktn.IResolvable;
        /**
        * source_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_flow#source_configuration TfFlow#source_configuration}
        */
        readonly sourceConfiguration?: SourceConfigurationProperty[] | cdktn.IResolvable;
    }
    class PromptPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): PromptProperty | cdktn.IResolvable | undefined;
        set internalValue(value: PromptProperty | cdktn.IResolvable | undefined);
        private _guardrailConfiguration;
        get guardrailConfiguration(): DefinitionNodeConfigurationPromptGuardrailConfigurationPropertyList;
        putGuardrailConfiguration(value: DefinitionNodeConfigurationPromptGuardrailConfigurationProperty[] | cdktn.IResolvable): void;
        resetGuardrailConfiguration(): void;
        get guardrailConfigurationInput(): cdktn.IResolvable | DefinitionNodeConfigurationPromptGuardrailConfigurationProperty[] | undefined;
        private _sourceConfiguration;
        get sourceConfiguration(): SourceConfigurationPropertyList;
        putSourceConfiguration(value: SourceConfigurationProperty[] | cdktn.IResolvable): void;
        resetSourceConfiguration(): void;
        get sourceConfigurationInput(): cdktn.IResolvable | SourceConfigurationProperty[] | undefined;
    }
    class PromptPropertyList extends cdktn.ComplexList {
        internalValue?: PromptProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): PromptPropertyOutputReference;
    }
    interface DefinitionNodeConfigurationRetrievalServiceConfigurationS3Property {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_flow#bucket_name TfFlow#bucket_name}
        */
        readonly bucketName: string;
    }
    class DefinitionNodeConfigurationRetrievalServiceConfigurationS3PropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DefinitionNodeConfigurationRetrievalServiceConfigurationS3Property | cdktn.IResolvable | undefined;
        set internalValue(value: DefinitionNodeConfigurationRetrievalServiceConfigurationS3Property | cdktn.IResolvable | undefined);
        private _bucketName?;
        get bucketName(): string;
        set bucketName(value: string);
        get bucketNameInput(): string | undefined;
    }
    class DefinitionNodeConfigurationRetrievalServiceConfigurationS3PropertyList extends cdktn.ComplexList {
        internalValue?: DefinitionNodeConfigurationRetrievalServiceConfigurationS3Property[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DefinitionNodeConfigurationRetrievalServiceConfigurationS3PropertyOutputReference;
    }
    interface DefinitionNodeConfigurationRetrievalServiceConfigurationProperty {
        /**
        * s3 block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_flow#s3 TfFlow#s3}
        */
        readonly s3?: DefinitionNodeConfigurationRetrievalServiceConfigurationS3Property[] | cdktn.IResolvable;
    }
    class DefinitionNodeConfigurationRetrievalServiceConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DefinitionNodeConfigurationRetrievalServiceConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DefinitionNodeConfigurationRetrievalServiceConfigurationProperty | cdktn.IResolvable | undefined);
        private _s3;
        get s3(): DefinitionNodeConfigurationRetrievalServiceConfigurationS3PropertyList;
        putS3(value: DefinitionNodeConfigurationRetrievalServiceConfigurationS3Property[] | cdktn.IResolvable): void;
        resetS3(): void;
        get s3Input(): cdktn.IResolvable | DefinitionNodeConfigurationRetrievalServiceConfigurationS3Property[] | undefined;
    }
    class DefinitionNodeConfigurationRetrievalServiceConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: DefinitionNodeConfigurationRetrievalServiceConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DefinitionNodeConfigurationRetrievalServiceConfigurationPropertyOutputReference;
    }
    interface RetrievalProperty {
        /**
        * service_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_flow#service_configuration TfFlow#service_configuration}
        */
        readonly serviceConfiguration?: DefinitionNodeConfigurationRetrievalServiceConfigurationProperty[] | cdktn.IResolvable;
    }
    class RetrievalPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RetrievalProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RetrievalProperty | cdktn.IResolvable | undefined);
        private _serviceConfiguration;
        get serviceConfiguration(): DefinitionNodeConfigurationRetrievalServiceConfigurationPropertyList;
        putServiceConfiguration(value: DefinitionNodeConfigurationRetrievalServiceConfigurationProperty[] | cdktn.IResolvable): void;
        resetServiceConfiguration(): void;
        get serviceConfigurationInput(): cdktn.IResolvable | DefinitionNodeConfigurationRetrievalServiceConfigurationProperty[] | undefined;
    }
    class RetrievalPropertyList extends cdktn.ComplexList {
        internalValue?: RetrievalProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RetrievalPropertyOutputReference;
    }
    interface DefinitionNodeConfigurationStorageServiceConfigurationS3Property {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_flow#bucket_name TfFlow#bucket_name}
        */
        readonly bucketName: string;
    }
    class DefinitionNodeConfigurationStorageServiceConfigurationS3PropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DefinitionNodeConfigurationStorageServiceConfigurationS3Property | cdktn.IResolvable | undefined;
        set internalValue(value: DefinitionNodeConfigurationStorageServiceConfigurationS3Property | cdktn.IResolvable | undefined);
        private _bucketName?;
        get bucketName(): string;
        set bucketName(value: string);
        get bucketNameInput(): string | undefined;
    }
    class DefinitionNodeConfigurationStorageServiceConfigurationS3PropertyList extends cdktn.ComplexList {
        internalValue?: DefinitionNodeConfigurationStorageServiceConfigurationS3Property[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DefinitionNodeConfigurationStorageServiceConfigurationS3PropertyOutputReference;
    }
    interface DefinitionNodeConfigurationStorageServiceConfigurationProperty {
        /**
        * s3 block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_flow#s3 TfFlow#s3}
        */
        readonly s3?: DefinitionNodeConfigurationStorageServiceConfigurationS3Property[] | cdktn.IResolvable;
    }
    class DefinitionNodeConfigurationStorageServiceConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DefinitionNodeConfigurationStorageServiceConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DefinitionNodeConfigurationStorageServiceConfigurationProperty | cdktn.IResolvable | undefined);
        private _s3;
        get s3(): DefinitionNodeConfigurationStorageServiceConfigurationS3PropertyList;
        putS3(value: DefinitionNodeConfigurationStorageServiceConfigurationS3Property[] | cdktn.IResolvable): void;
        resetS3(): void;
        get s3Input(): cdktn.IResolvable | DefinitionNodeConfigurationStorageServiceConfigurationS3Property[] | undefined;
    }
    class DefinitionNodeConfigurationStorageServiceConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: DefinitionNodeConfigurationStorageServiceConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DefinitionNodeConfigurationStorageServiceConfigurationPropertyOutputReference;
    }
    interface StorageProperty {
        /**
        * service_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_flow#service_configuration TfFlow#service_configuration}
        */
        readonly serviceConfiguration?: DefinitionNodeConfigurationStorageServiceConfigurationProperty[] | cdktn.IResolvable;
    }
    class StoragePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): StorageProperty | cdktn.IResolvable | undefined;
        set internalValue(value: StorageProperty | cdktn.IResolvable | undefined);
        private _serviceConfiguration;
        get serviceConfiguration(): DefinitionNodeConfigurationStorageServiceConfigurationPropertyList;
        putServiceConfiguration(value: DefinitionNodeConfigurationStorageServiceConfigurationProperty[] | cdktn.IResolvable): void;
        resetServiceConfiguration(): void;
        get serviceConfigurationInput(): cdktn.IResolvable | DefinitionNodeConfigurationStorageServiceConfigurationProperty[] | undefined;
    }
    class StoragePropertyList extends cdktn.ComplexList {
        internalValue?: StorageProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): StoragePropertyOutputReference;
    }
    interface DefinitionNodeConfigurationProperty {
        /**
        * agent block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_flow#agent TfFlow#agent}
        */
        readonly agent?: AgentProperty[] | cdktn.IResolvable;
        /**
        * collector block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_flow#collector TfFlow#collector}
        */
        readonly collector?: CollectorProperty[] | cdktn.IResolvable;
        /**
        * condition block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_flow#condition TfFlow#condition}
        */
        readonly condition?: DefinitionNodeConfigurationConditionProperty[] | cdktn.IResolvable;
        /**
        * inline_code block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_flow#inline_code TfFlow#inline_code}
        */
        readonly inlineCode?: InlineCodeProperty[] | cdktn.IResolvable;
        /**
        * input block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_flow#input TfFlow#input}
        */
        readonly input?: DefinitionNodeConfigurationInputProperty[] | cdktn.IResolvable;
        /**
        * iterator block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_flow#iterator TfFlow#iterator}
        */
        readonly iterator?: IteratorProperty[] | cdktn.IResolvable;
        /**
        * knowledge_base block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_flow#knowledge_base TfFlow#knowledge_base}
        */
        readonly knowledgeBase?: KnowledgeBaseProperty[] | cdktn.IResolvable;
        /**
        * lambda_function block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_flow#lambda_function TfFlow#lambda_function}
        */
        readonly lambdaFunction?: LambdaFunctionProperty[] | cdktn.IResolvable;
        /**
        * lex block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_flow#lex TfFlow#lex}
        */
        readonly lex?: LexProperty[] | cdktn.IResolvable;
        /**
        * output block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_flow#output TfFlow#output}
        */
        readonly output?: DefinitionNodeConfigurationOutputProperty[] | cdktn.IResolvable;
        /**
        * prompt block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_flow#prompt TfFlow#prompt}
        */
        readonly prompt?: PromptProperty[] | cdktn.IResolvable;
        /**
        * retrieval block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_flow#retrieval TfFlow#retrieval}
        */
        readonly retrieval?: RetrievalProperty[] | cdktn.IResolvable;
        /**
        * storage block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_flow#storage TfFlow#storage}
        */
        readonly storage?: StorageProperty[] | cdktn.IResolvable;
    }
    class DefinitionNodeConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DefinitionNodeConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DefinitionNodeConfigurationProperty | cdktn.IResolvable | undefined);
        private _agent;
        get agent(): AgentPropertyList;
        putAgent(value: AgentProperty[] | cdktn.IResolvable): void;
        resetAgent(): void;
        get agentInput(): cdktn.IResolvable | AgentProperty[] | undefined;
        private _collector;
        get collector(): CollectorPropertyList;
        putCollector(value: CollectorProperty[] | cdktn.IResolvable): void;
        resetCollector(): void;
        get collectorInput(): cdktn.IResolvable | CollectorProperty[] | undefined;
        private _condition;
        get condition(): DefinitionNodeConfigurationConditionPropertyList;
        putCondition(value: DefinitionNodeConfigurationConditionProperty[] | cdktn.IResolvable): void;
        resetCondition(): void;
        get conditionInput(): cdktn.IResolvable | DefinitionNodeConfigurationConditionProperty[] | undefined;
        private _inlineCode;
        get inlineCode(): InlineCodePropertyList;
        putInlineCode(value: InlineCodeProperty[] | cdktn.IResolvable): void;
        resetInlineCode(): void;
        get inlineCodeInput(): cdktn.IResolvable | InlineCodeProperty[] | undefined;
        private _input;
        get input(): DefinitionNodeConfigurationInputPropertyList;
        putInput(value: DefinitionNodeConfigurationInputProperty[] | cdktn.IResolvable): void;
        resetInput(): void;
        get inputInput(): cdktn.IResolvable | DefinitionNodeConfigurationInputProperty[] | undefined;
        private _iterator;
        get iterator(): IteratorPropertyList;
        putIterator(value: IteratorProperty[] | cdktn.IResolvable): void;
        resetIterator(): void;
        get iteratorInput(): cdktn.IResolvable | IteratorProperty[] | undefined;
        private _knowledgeBase;
        get knowledgeBase(): KnowledgeBasePropertyList;
        putKnowledgeBase(value: KnowledgeBaseProperty[] | cdktn.IResolvable): void;
        resetKnowledgeBase(): void;
        get knowledgeBaseInput(): cdktn.IResolvable | KnowledgeBaseProperty[] | undefined;
        private _lambdaFunction;
        get lambdaFunction(): LambdaFunctionPropertyList;
        putLambdaFunction(value: LambdaFunctionProperty[] | cdktn.IResolvable): void;
        resetLambdaFunction(): void;
        get lambdaFunctionInput(): cdktn.IResolvable | LambdaFunctionProperty[] | undefined;
        private _lex;
        get lex(): LexPropertyList;
        putLex(value: LexProperty[] | cdktn.IResolvable): void;
        resetLex(): void;
        get lexInput(): cdktn.IResolvable | LexProperty[] | undefined;
        private _output;
        get output(): DefinitionNodeConfigurationOutputPropertyList;
        putOutput(value: DefinitionNodeConfigurationOutputProperty[] | cdktn.IResolvable): void;
        resetOutput(): void;
        get outputInput(): cdktn.IResolvable | DefinitionNodeConfigurationOutputProperty[] | undefined;
        private _prompt;
        get prompt(): PromptPropertyList;
        putPrompt(value: PromptProperty[] | cdktn.IResolvable): void;
        resetPrompt(): void;
        get promptInput(): cdktn.IResolvable | PromptProperty[] | undefined;
        private _retrieval;
        get retrieval(): RetrievalPropertyList;
        putRetrieval(value: RetrievalProperty[] | cdktn.IResolvable): void;
        resetRetrieval(): void;
        get retrievalInput(): cdktn.IResolvable | RetrievalProperty[] | undefined;
        private _storage;
        get storage(): StoragePropertyList;
        putStorage(value: StorageProperty[] | cdktn.IResolvable): void;
        resetStorage(): void;
        get storageInput(): cdktn.IResolvable | StorageProperty[] | undefined;
    }
    class DefinitionNodeConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: DefinitionNodeConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DefinitionNodeConfigurationPropertyOutputReference;
    }
    interface DefinitionNodeInputProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_flow#category TfFlow#category}
        */
        readonly category?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_flow#expression TfFlow#expression}
        */
        readonly expression: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_flow#name TfFlow#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_flow#type TfFlow#type}
        */
        readonly type: string;
    }
    class DefinitionNodeInputPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DefinitionNodeInputProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DefinitionNodeInputProperty | cdktn.IResolvable | undefined);
        private _category?;
        get category(): string;
        set category(value: string);
        resetCategory(): void;
        get categoryInput(): string | undefined;
        private _expression?;
        get expression(): string;
        set expression(value: string);
        get expressionInput(): string | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
    }
    class DefinitionNodeInputPropertyList extends cdktn.ComplexList {
        internalValue?: DefinitionNodeInputProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DefinitionNodeInputPropertyOutputReference;
    }
    interface DefinitionNodeOutputProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_flow#name TfFlow#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_flow#type TfFlow#type}
        */
        readonly type: string;
    }
    class DefinitionNodeOutputPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DefinitionNodeOutputProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DefinitionNodeOutputProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
    }
    class DefinitionNodeOutputPropertyList extends cdktn.ComplexList {
        internalValue?: DefinitionNodeOutputProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DefinitionNodeOutputPropertyOutputReference;
    }
    interface NodeProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_flow#name TfFlow#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_flow#type TfFlow#type}
        */
        readonly type: string;
        /**
        * configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_flow#configuration TfFlow#configuration}
        */
        readonly configuration?: DefinitionNodeConfigurationProperty[] | cdktn.IResolvable;
        /**
        * input block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_flow#input TfFlow#input}
        */
        readonly input?: DefinitionNodeInputProperty[] | cdktn.IResolvable;
        /**
        * output block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_flow#output TfFlow#output}
        */
        readonly output?: DefinitionNodeOutputProperty[] | cdktn.IResolvable;
    }
    class NodePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): NodeProperty | cdktn.IResolvable | undefined;
        set internalValue(value: NodeProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
        private _configuration;
        get configuration(): DefinitionNodeConfigurationPropertyList;
        putConfiguration(value: DefinitionNodeConfigurationProperty[] | cdktn.IResolvable): void;
        resetConfiguration(): void;
        get configurationInput(): cdktn.IResolvable | DefinitionNodeConfigurationProperty[] | undefined;
        private _input;
        get input(): DefinitionNodeInputPropertyList;
        putInput(value: DefinitionNodeInputProperty[] | cdktn.IResolvable): void;
        resetInput(): void;
        get inputInput(): cdktn.IResolvable | DefinitionNodeInputProperty[] | undefined;
        private _output;
        get output(): DefinitionNodeOutputPropertyList;
        putOutput(value: DefinitionNodeOutputProperty[] | cdktn.IResolvable): void;
        resetOutput(): void;
        get outputInput(): cdktn.IResolvable | DefinitionNodeOutputProperty[] | undefined;
    }
    class NodePropertyList extends cdktn.ComplexList {
        internalValue?: NodeProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): NodePropertyOutputReference;
    }
    interface DefinitionProperty {
        /**
        * connection block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_flow#connection TfFlow#connection}
        */
        readonly connection?: ConnectionProperty[] | cdktn.IResolvable;
        /**
        * node block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_flow#node TfFlow#node}
        */
        readonly nodeAttribute?: NodeProperty[] | cdktn.IResolvable;
    }
    class DefinitionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DefinitionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DefinitionProperty | cdktn.IResolvable | undefined);
        private _connection;
        get connection(): ConnectionPropertyList;
        putConnection(value: ConnectionProperty[] | cdktn.IResolvable): void;
        resetConnection(): void;
        get connectionInput(): cdktn.IResolvable | ConnectionProperty[] | undefined;
        private _node;
        get nodeAttribute(): NodePropertyList;
        putNodeAttribute(value: NodeProperty[] | cdktn.IResolvable): void;
        resetNodeAttribute(): void;
        get nodeAttributeInput(): cdktn.IResolvable | NodeProperty[] | undefined;
    }
    class DefinitionPropertyList extends cdktn.ComplexList {
        internalValue?: DefinitionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DefinitionPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_flow#create TfFlow#create}
        */
        readonly create?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Setting a timeout for a Delete operation is only applicable if changes are saved into state before the destroy operation occurs.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_flow#delete TfFlow#delete}
        */
        readonly delete?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_flow#update TfFlow#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
