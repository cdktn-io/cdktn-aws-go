import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfPromptConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_prompt#customer_encryption_key_arn TfPrompt#customer_encryption_key_arn}
    */
    readonly customerEncryptionKeyArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_prompt#default_variant TfPrompt#default_variant}
    */
    readonly defaultVariant?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_prompt#description TfPrompt#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_prompt#name TfPrompt#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_prompt#region TfPrompt#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_prompt#tags TfPrompt#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * variant block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_prompt#variant TfPrompt#variant}
    */
    readonly variant?: TfPrompt.VariantProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_prompt aws_bedrockagent_prompt}
*/
export declare class TfPrompt extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_bedrockagent_prompt";
    /**
    * Generates CDKTN code for importing a TfPrompt resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfPrompt to import
    * @param importFromId The id of the existing TfPrompt that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_prompt#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfPrompt to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_prompt aws_bedrockagent_prompt} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfPromptConfig
    */
    constructor(scope: Construct, id: string, config: TfPromptConfig);
    get arn(): string;
    get createdAt(): string;
    private _customerEncryptionKeyArn?;
    get customerEncryptionKeyArn(): string;
    set customerEncryptionKeyArn(value: string);
    resetCustomerEncryptionKeyArn(): void;
    get customerEncryptionKeyArnInput(): string | undefined;
    private _defaultVariant?;
    get defaultVariant(): string;
    set defaultVariant(value: string);
    resetDefaultVariant(): void;
    get defaultVariantInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    get updatedAt(): string;
    get version(): string;
    private _variant;
    get variant(): TfPrompt.VariantPropertyList;
    putVariant(value: TfPrompt.VariantProperty[] | cdktn.IResolvable): void;
    resetVariant(): void;
    get variantInput(): cdktn.IResolvable | TfPrompt.VariantProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfPromptAgentPropertyToTerraform(struct?: TfPrompt.AgentProperty | cdktn.IResolvable): any;
export declare function tfPromptAgentPropertyToHclTerraform(struct?: TfPrompt.AgentProperty | cdktn.IResolvable): any;
export declare function tfPromptGenAiResourcePropertyToTerraform(struct?: TfPrompt.GenAiResourceProperty | cdktn.IResolvable): any;
export declare function tfPromptGenAiResourcePropertyToHclTerraform(struct?: TfPrompt.GenAiResourceProperty | cdktn.IResolvable): any;
export declare function tfPromptVariantInferenceConfigurationTextPropertyToTerraform(struct?: TfPrompt.VariantInferenceConfigurationTextProperty | cdktn.IResolvable): any;
export declare function tfPromptVariantInferenceConfigurationTextPropertyToHclTerraform(struct?: TfPrompt.VariantInferenceConfigurationTextProperty | cdktn.IResolvable): any;
export declare function tfPromptInferenceConfigurationPropertyToTerraform(struct?: TfPrompt.InferenceConfigurationProperty | cdktn.IResolvable): any;
export declare function tfPromptInferenceConfigurationPropertyToHclTerraform(struct?: TfPrompt.InferenceConfigurationProperty | cdktn.IResolvable): any;
export declare function tfPromptMetadataPropertyToTerraform(struct?: TfPrompt.MetadataProperty | cdktn.IResolvable): any;
export declare function tfPromptMetadataPropertyToHclTerraform(struct?: TfPrompt.MetadataProperty | cdktn.IResolvable): any;
export declare function tfPromptVariantTemplateConfigurationChatInputVariablePropertyToTerraform(struct?: TfPrompt.VariantTemplateConfigurationChatInputVariableProperty | cdktn.IResolvable): any;
export declare function tfPromptVariantTemplateConfigurationChatInputVariablePropertyToHclTerraform(struct?: TfPrompt.VariantTemplateConfigurationChatInputVariableProperty | cdktn.IResolvable): any;
export declare function tfPromptVariantTemplateConfigurationChatMessageContentCachePointPropertyToTerraform(struct?: TfPrompt.VariantTemplateConfigurationChatMessageContentCachePointProperty | cdktn.IResolvable): any;
export declare function tfPromptVariantTemplateConfigurationChatMessageContentCachePointPropertyToHclTerraform(struct?: TfPrompt.VariantTemplateConfigurationChatMessageContentCachePointProperty | cdktn.IResolvable): any;
export declare function tfPromptContentPropertyToTerraform(struct?: TfPrompt.ContentProperty | cdktn.IResolvable): any;
export declare function tfPromptContentPropertyToHclTerraform(struct?: TfPrompt.ContentProperty | cdktn.IResolvable): any;
export declare function tfPromptMessagePropertyToTerraform(struct?: TfPrompt.MessageProperty | cdktn.IResolvable): any;
export declare function tfPromptMessagePropertyToHclTerraform(struct?: TfPrompt.MessageProperty | cdktn.IResolvable): any;
export declare function tfPromptVariantTemplateConfigurationChatSystemCachePointPropertyToTerraform(struct?: TfPrompt.VariantTemplateConfigurationChatSystemCachePointProperty | cdktn.IResolvable): any;
export declare function tfPromptVariantTemplateConfigurationChatSystemCachePointPropertyToHclTerraform(struct?: TfPrompt.VariantTemplateConfigurationChatSystemCachePointProperty | cdktn.IResolvable): any;
export declare function tfPromptSystemPropertyToTerraform(struct?: TfPrompt.SystemProperty | cdktn.IResolvable): any;
export declare function tfPromptSystemPropertyToHclTerraform(struct?: TfPrompt.SystemProperty | cdktn.IResolvable): any;
export declare function tfPromptVariantTemplateConfigurationChatToolConfigurationToolCachePointPropertyToTerraform(struct?: TfPrompt.VariantTemplateConfigurationChatToolConfigurationToolCachePointProperty | cdktn.IResolvable): any;
export declare function tfPromptVariantTemplateConfigurationChatToolConfigurationToolCachePointPropertyToHclTerraform(struct?: TfPrompt.VariantTemplateConfigurationChatToolConfigurationToolCachePointProperty | cdktn.IResolvable): any;
export declare function tfPromptInputSchemaPropertyToTerraform(struct?: TfPrompt.InputSchemaProperty | cdktn.IResolvable): any;
export declare function tfPromptInputSchemaPropertyToHclTerraform(struct?: TfPrompt.InputSchemaProperty | cdktn.IResolvable): any;
export declare function tfPromptToolSpecPropertyToTerraform(struct?: TfPrompt.ToolSpecProperty | cdktn.IResolvable): any;
export declare function tfPromptToolSpecPropertyToHclTerraform(struct?: TfPrompt.ToolSpecProperty | cdktn.IResolvable): any;
export declare function tfPromptVariantTemplateConfigurationChatToolConfigurationToolPropertyToTerraform(struct?: TfPrompt.VariantTemplateConfigurationChatToolConfigurationToolProperty | cdktn.IResolvable): any;
export declare function tfPromptVariantTemplateConfigurationChatToolConfigurationToolPropertyToHclTerraform(struct?: TfPrompt.VariantTemplateConfigurationChatToolConfigurationToolProperty | cdktn.IResolvable): any;
export declare function tfPromptAnyPropertyToTerraform(struct?: TfPrompt.AnyProperty | cdktn.IResolvable): any;
export declare function tfPromptAnyPropertyToHclTerraform(struct?: TfPrompt.AnyProperty | cdktn.IResolvable): any;
export declare function tfPromptAutoPropertyToTerraform(struct?: TfPrompt.AutoProperty | cdktn.IResolvable): any;
export declare function tfPromptAutoPropertyToHclTerraform(struct?: TfPrompt.AutoProperty | cdktn.IResolvable): any;
export declare function tfPromptVariantTemplateConfigurationChatToolConfigurationToolChoiceToolPropertyToTerraform(struct?: TfPrompt.VariantTemplateConfigurationChatToolConfigurationToolChoiceToolProperty | cdktn.IResolvable): any;
export declare function tfPromptVariantTemplateConfigurationChatToolConfigurationToolChoiceToolPropertyToHclTerraform(struct?: TfPrompt.VariantTemplateConfigurationChatToolConfigurationToolChoiceToolProperty | cdktn.IResolvable): any;
export declare function tfPromptToolChoicePropertyToTerraform(struct?: TfPrompt.ToolChoiceProperty | cdktn.IResolvable): any;
export declare function tfPromptToolChoicePropertyToHclTerraform(struct?: TfPrompt.ToolChoiceProperty | cdktn.IResolvable): any;
export declare function tfPromptToolConfigurationPropertyToTerraform(struct?: TfPrompt.ToolConfigurationProperty | cdktn.IResolvable): any;
export declare function tfPromptToolConfigurationPropertyToHclTerraform(struct?: TfPrompt.ToolConfigurationProperty | cdktn.IResolvable): any;
export declare function tfPromptChatPropertyToTerraform(struct?: TfPrompt.ChatProperty | cdktn.IResolvable): any;
export declare function tfPromptChatPropertyToHclTerraform(struct?: TfPrompt.ChatProperty | cdktn.IResolvable): any;
export declare function tfPromptVariantTemplateConfigurationTextCachePointPropertyToTerraform(struct?: TfPrompt.VariantTemplateConfigurationTextCachePointProperty | cdktn.IResolvable): any;
export declare function tfPromptVariantTemplateConfigurationTextCachePointPropertyToHclTerraform(struct?: TfPrompt.VariantTemplateConfigurationTextCachePointProperty | cdktn.IResolvable): any;
export declare function tfPromptVariantTemplateConfigurationTextInputVariablePropertyToTerraform(struct?: TfPrompt.VariantTemplateConfigurationTextInputVariableProperty | cdktn.IResolvable): any;
export declare function tfPromptVariantTemplateConfigurationTextInputVariablePropertyToHclTerraform(struct?: TfPrompt.VariantTemplateConfigurationTextInputVariableProperty | cdktn.IResolvable): any;
export declare function tfPromptVariantTemplateConfigurationTextPropertyToTerraform(struct?: TfPrompt.VariantTemplateConfigurationTextProperty | cdktn.IResolvable): any;
export declare function tfPromptVariantTemplateConfigurationTextPropertyToHclTerraform(struct?: TfPrompt.VariantTemplateConfigurationTextProperty | cdktn.IResolvable): any;
export declare function tfPromptTemplateConfigurationPropertyToTerraform(struct?: TfPrompt.TemplateConfigurationProperty | cdktn.IResolvable): any;
export declare function tfPromptTemplateConfigurationPropertyToHclTerraform(struct?: TfPrompt.TemplateConfigurationProperty | cdktn.IResolvable): any;
export declare function tfPromptVariantPropertyToTerraform(struct?: TfPrompt.VariantProperty | cdktn.IResolvable): any;
export declare function tfPromptVariantPropertyToHclTerraform(struct?: TfPrompt.VariantProperty | cdktn.IResolvable): any;
export declare namespace TfPrompt {
    interface AgentProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_prompt#agent_identifier TfPrompt#agent_identifier}
        */
        readonly agentIdentifier: string;
    }
    class AgentPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AgentProperty | cdktn.IResolvable | undefined;
        set internalValue(value: AgentProperty | cdktn.IResolvable | undefined);
        private _agentIdentifier?;
        get agentIdentifier(): string;
        set agentIdentifier(value: string);
        get agentIdentifierInput(): string | undefined;
    }
    class AgentPropertyList extends cdktn.ComplexList {
        internalValue?: AgentProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AgentPropertyOutputReference;
    }
    interface GenAiResourceProperty {
        /**
        * agent block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_prompt#agent TfPrompt#agent}
        */
        readonly agent?: AgentProperty[] | cdktn.IResolvable;
    }
    class GenAiResourcePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): GenAiResourceProperty | cdktn.IResolvable | undefined;
        set internalValue(value: GenAiResourceProperty | cdktn.IResolvable | undefined);
        private _agent;
        get agent(): AgentPropertyList;
        putAgent(value: AgentProperty[] | cdktn.IResolvable): void;
        resetAgent(): void;
        get agentInput(): cdktn.IResolvable | AgentProperty[] | undefined;
    }
    class GenAiResourcePropertyList extends cdktn.ComplexList {
        internalValue?: GenAiResourceProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): GenAiResourcePropertyOutputReference;
    }
    interface VariantInferenceConfigurationTextProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_prompt#max_tokens TfPrompt#max_tokens}
        */
        readonly maxTokens?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_prompt#stop_sequences TfPrompt#stop_sequences}
        */
        readonly stopSequences?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_prompt#temperature TfPrompt#temperature}
        */
        readonly temperature?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_prompt#top_p TfPrompt#top_p}
        */
        readonly topP?: number;
    }
    class VariantInferenceConfigurationTextPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): VariantInferenceConfigurationTextProperty | cdktn.IResolvable | undefined;
        set internalValue(value: VariantInferenceConfigurationTextProperty | cdktn.IResolvable | undefined);
        private _maxTokens?;
        get maxTokens(): number;
        set maxTokens(value: number);
        resetMaxTokens(): void;
        get maxTokensInput(): number | undefined;
        private _stopSequences?;
        get stopSequences(): string[];
        set stopSequences(value: string[]);
        resetStopSequences(): void;
        get stopSequencesInput(): string[] | undefined;
        private _temperature?;
        get temperature(): number;
        set temperature(value: number);
        resetTemperature(): void;
        get temperatureInput(): number | undefined;
        private _topP?;
        get topP(): number;
        set topP(value: number);
        resetTopP(): void;
        get topPInput(): number | undefined;
    }
    class VariantInferenceConfigurationTextPropertyList extends cdktn.ComplexList {
        internalValue?: VariantInferenceConfigurationTextProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): VariantInferenceConfigurationTextPropertyOutputReference;
    }
    interface InferenceConfigurationProperty {
        /**
        * text block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_prompt#text TfPrompt#text}
        */
        readonly text?: VariantInferenceConfigurationTextProperty[] | cdktn.IResolvable;
    }
    class InferenceConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): InferenceConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: InferenceConfigurationProperty | cdktn.IResolvable | undefined);
        private _text;
        get text(): VariantInferenceConfigurationTextPropertyList;
        putText(value: VariantInferenceConfigurationTextProperty[] | cdktn.IResolvable): void;
        resetText(): void;
        get textInput(): cdktn.IResolvable | VariantInferenceConfigurationTextProperty[] | undefined;
    }
    class InferenceConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: InferenceConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): InferenceConfigurationPropertyOutputReference;
    }
    interface MetadataProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_prompt#key TfPrompt#key}
        */
        readonly key: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_prompt#value TfPrompt#value}
        */
        readonly value: string;
    }
    class MetadataPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): MetadataProperty | cdktn.IResolvable | undefined;
        set internalValue(value: MetadataProperty | cdktn.IResolvable | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        get keyInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class MetadataPropertyList extends cdktn.ComplexList {
        internalValue?: MetadataProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): MetadataPropertyOutputReference;
    }
    interface VariantTemplateConfigurationChatInputVariableProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_prompt#name TfPrompt#name}
        */
        readonly name: string;
    }
    class VariantTemplateConfigurationChatInputVariablePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): VariantTemplateConfigurationChatInputVariableProperty | cdktn.IResolvable | undefined;
        set internalValue(value: VariantTemplateConfigurationChatInputVariableProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
    }
    class VariantTemplateConfigurationChatInputVariablePropertyList extends cdktn.ComplexList {
        internalValue?: VariantTemplateConfigurationChatInputVariableProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): VariantTemplateConfigurationChatInputVariablePropertyOutputReference;
    }
    interface VariantTemplateConfigurationChatMessageContentCachePointProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_prompt#type TfPrompt#type}
        */
        readonly type: string;
    }
    class VariantTemplateConfigurationChatMessageContentCachePointPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): VariantTemplateConfigurationChatMessageContentCachePointProperty | cdktn.IResolvable | undefined;
        set internalValue(value: VariantTemplateConfigurationChatMessageContentCachePointProperty | cdktn.IResolvable | undefined);
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
    }
    class VariantTemplateConfigurationChatMessageContentCachePointPropertyList extends cdktn.ComplexList {
        internalValue?: VariantTemplateConfigurationChatMessageContentCachePointProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): VariantTemplateConfigurationChatMessageContentCachePointPropertyOutputReference;
    }
    interface ContentProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_prompt#text TfPrompt#text}
        */
        readonly text?: string;
        /**
        * cache_point block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_prompt#cache_point TfPrompt#cache_point}
        */
        readonly cachePoint?: VariantTemplateConfigurationChatMessageContentCachePointProperty[] | cdktn.IResolvable;
    }
    class ContentPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ContentProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ContentProperty | cdktn.IResolvable | undefined);
        private _text?;
        get text(): string;
        set text(value: string);
        resetText(): void;
        get textInput(): string | undefined;
        private _cachePoint;
        get cachePoint(): VariantTemplateConfigurationChatMessageContentCachePointPropertyList;
        putCachePoint(value: VariantTemplateConfigurationChatMessageContentCachePointProperty[] | cdktn.IResolvable): void;
        resetCachePoint(): void;
        get cachePointInput(): cdktn.IResolvable | VariantTemplateConfigurationChatMessageContentCachePointProperty[] | undefined;
    }
    class ContentPropertyList extends cdktn.ComplexList {
        internalValue?: ContentProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ContentPropertyOutputReference;
    }
    interface MessageProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_prompt#role TfPrompt#role}
        */
        readonly role: string;
        /**
        * content block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_prompt#content TfPrompt#content}
        */
        readonly content?: ContentProperty[] | cdktn.IResolvable;
    }
    class MessagePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): MessageProperty | cdktn.IResolvable | undefined;
        set internalValue(value: MessageProperty | cdktn.IResolvable | undefined);
        private _role?;
        get role(): string;
        set role(value: string);
        get roleInput(): string | undefined;
        private _content;
        get content(): ContentPropertyList;
        putContent(value: ContentProperty[] | cdktn.IResolvable): void;
        resetContent(): void;
        get contentInput(): cdktn.IResolvable | ContentProperty[] | undefined;
    }
    class MessagePropertyList extends cdktn.ComplexList {
        internalValue?: MessageProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): MessagePropertyOutputReference;
    }
    interface VariantTemplateConfigurationChatSystemCachePointProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_prompt#type TfPrompt#type}
        */
        readonly type: string;
    }
    class VariantTemplateConfigurationChatSystemCachePointPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): VariantTemplateConfigurationChatSystemCachePointProperty | cdktn.IResolvable | undefined;
        set internalValue(value: VariantTemplateConfigurationChatSystemCachePointProperty | cdktn.IResolvable | undefined);
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
    }
    class VariantTemplateConfigurationChatSystemCachePointPropertyList extends cdktn.ComplexList {
        internalValue?: VariantTemplateConfigurationChatSystemCachePointProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): VariantTemplateConfigurationChatSystemCachePointPropertyOutputReference;
    }
    interface SystemProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_prompt#text TfPrompt#text}
        */
        readonly text?: string;
        /**
        * cache_point block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_prompt#cache_point TfPrompt#cache_point}
        */
        readonly cachePoint?: VariantTemplateConfigurationChatSystemCachePointProperty[] | cdktn.IResolvable;
    }
    class SystemPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SystemProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SystemProperty | cdktn.IResolvable | undefined);
        private _text?;
        get text(): string;
        set text(value: string);
        resetText(): void;
        get textInput(): string | undefined;
        private _cachePoint;
        get cachePoint(): VariantTemplateConfigurationChatSystemCachePointPropertyList;
        putCachePoint(value: VariantTemplateConfigurationChatSystemCachePointProperty[] | cdktn.IResolvable): void;
        resetCachePoint(): void;
        get cachePointInput(): cdktn.IResolvable | VariantTemplateConfigurationChatSystemCachePointProperty[] | undefined;
    }
    class SystemPropertyList extends cdktn.ComplexList {
        internalValue?: SystemProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SystemPropertyOutputReference;
    }
    interface VariantTemplateConfigurationChatToolConfigurationToolCachePointProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_prompt#type TfPrompt#type}
        */
        readonly type: string;
    }
    class VariantTemplateConfigurationChatToolConfigurationToolCachePointPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): VariantTemplateConfigurationChatToolConfigurationToolCachePointProperty | cdktn.IResolvable | undefined;
        set internalValue(value: VariantTemplateConfigurationChatToolConfigurationToolCachePointProperty | cdktn.IResolvable | undefined);
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
    }
    class VariantTemplateConfigurationChatToolConfigurationToolCachePointPropertyList extends cdktn.ComplexList {
        internalValue?: VariantTemplateConfigurationChatToolConfigurationToolCachePointProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): VariantTemplateConfigurationChatToolConfigurationToolCachePointPropertyOutputReference;
    }
    interface InputSchemaProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_prompt#json TfPrompt#json}
        */
        readonly json?: string;
    }
    class InputSchemaPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): InputSchemaProperty | cdktn.IResolvable | undefined;
        set internalValue(value: InputSchemaProperty | cdktn.IResolvable | undefined);
        private _json?;
        get json(): string;
        set json(value: string);
        resetJson(): void;
        get jsonInput(): string | undefined;
    }
    class InputSchemaPropertyList extends cdktn.ComplexList {
        internalValue?: InputSchemaProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): InputSchemaPropertyOutputReference;
    }
    interface ToolSpecProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_prompt#description TfPrompt#description}
        */
        readonly description?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_prompt#name TfPrompt#name}
        */
        readonly name: string;
        /**
        * input_schema block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_prompt#input_schema TfPrompt#input_schema}
        */
        readonly inputSchema?: InputSchemaProperty[] | cdktn.IResolvable;
    }
    class ToolSpecPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ToolSpecProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ToolSpecProperty | cdktn.IResolvable | undefined);
        private _description?;
        get description(): string;
        set description(value: string);
        resetDescription(): void;
        get descriptionInput(): string | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _inputSchema;
        get inputSchema(): InputSchemaPropertyList;
        putInputSchema(value: InputSchemaProperty[] | cdktn.IResolvable): void;
        resetInputSchema(): void;
        get inputSchemaInput(): cdktn.IResolvable | InputSchemaProperty[] | undefined;
    }
    class ToolSpecPropertyList extends cdktn.ComplexList {
        internalValue?: ToolSpecProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ToolSpecPropertyOutputReference;
    }
    interface VariantTemplateConfigurationChatToolConfigurationToolProperty {
        /**
        * cache_point block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_prompt#cache_point TfPrompt#cache_point}
        */
        readonly cachePoint?: VariantTemplateConfigurationChatToolConfigurationToolCachePointProperty[] | cdktn.IResolvable;
        /**
        * tool_spec block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_prompt#tool_spec TfPrompt#tool_spec}
        */
        readonly toolSpec?: ToolSpecProperty[] | cdktn.IResolvable;
    }
    class VariantTemplateConfigurationChatToolConfigurationToolPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): VariantTemplateConfigurationChatToolConfigurationToolProperty | cdktn.IResolvable | undefined;
        set internalValue(value: VariantTemplateConfigurationChatToolConfigurationToolProperty | cdktn.IResolvable | undefined);
        private _cachePoint;
        get cachePoint(): VariantTemplateConfigurationChatToolConfigurationToolCachePointPropertyList;
        putCachePoint(value: VariantTemplateConfigurationChatToolConfigurationToolCachePointProperty[] | cdktn.IResolvable): void;
        resetCachePoint(): void;
        get cachePointInput(): cdktn.IResolvable | VariantTemplateConfigurationChatToolConfigurationToolCachePointProperty[] | undefined;
        private _toolSpec;
        get toolSpec(): ToolSpecPropertyList;
        putToolSpec(value: ToolSpecProperty[] | cdktn.IResolvable): void;
        resetToolSpec(): void;
        get toolSpecInput(): cdktn.IResolvable | ToolSpecProperty[] | undefined;
    }
    class VariantTemplateConfigurationChatToolConfigurationToolPropertyList extends cdktn.ComplexList {
        internalValue?: VariantTemplateConfigurationChatToolConfigurationToolProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): VariantTemplateConfigurationChatToolConfigurationToolPropertyOutputReference;
    }
    interface AnyProperty {
    }
    class AnyPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AnyProperty | cdktn.IResolvable | undefined;
        set internalValue(value: AnyProperty | cdktn.IResolvable | undefined);
    }
    class AnyPropertyList extends cdktn.ComplexList {
        internalValue?: AnyProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AnyPropertyOutputReference;
    }
    interface AutoProperty {
    }
    class AutoPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AutoProperty | cdktn.IResolvable | undefined;
        set internalValue(value: AutoProperty | cdktn.IResolvable | undefined);
    }
    class AutoPropertyList extends cdktn.ComplexList {
        internalValue?: AutoProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AutoPropertyOutputReference;
    }
    interface VariantTemplateConfigurationChatToolConfigurationToolChoiceToolProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_prompt#name TfPrompt#name}
        */
        readonly name: string;
    }
    class VariantTemplateConfigurationChatToolConfigurationToolChoiceToolPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): VariantTemplateConfigurationChatToolConfigurationToolChoiceToolProperty | cdktn.IResolvable | undefined;
        set internalValue(value: VariantTemplateConfigurationChatToolConfigurationToolChoiceToolProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
    }
    class VariantTemplateConfigurationChatToolConfigurationToolChoiceToolPropertyList extends cdktn.ComplexList {
        internalValue?: VariantTemplateConfigurationChatToolConfigurationToolChoiceToolProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): VariantTemplateConfigurationChatToolConfigurationToolChoiceToolPropertyOutputReference;
    }
    interface ToolChoiceProperty {
        /**
        * any block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_prompt#any TfPrompt#any}
        */
        readonly any?: AnyProperty[] | cdktn.IResolvable;
        /**
        * auto block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_prompt#auto TfPrompt#auto}
        */
        readonly auto?: AutoProperty[] | cdktn.IResolvable;
        /**
        * tool block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_prompt#tool TfPrompt#tool}
        */
        readonly tool?: VariantTemplateConfigurationChatToolConfigurationToolChoiceToolProperty[] | cdktn.IResolvable;
    }
    class ToolChoicePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ToolChoiceProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ToolChoiceProperty | cdktn.IResolvable | undefined);
        private _any;
        get any(): AnyPropertyList;
        putAny(value: AnyProperty[] | cdktn.IResolvable): void;
        resetAny(): void;
        get anyInput(): cdktn.IResolvable | AnyProperty[] | undefined;
        private _auto;
        get auto(): AutoPropertyList;
        putAuto(value: AutoProperty[] | cdktn.IResolvable): void;
        resetAuto(): void;
        get autoInput(): cdktn.IResolvable | AutoProperty[] | undefined;
        private _tool;
        get tool(): VariantTemplateConfigurationChatToolConfigurationToolChoiceToolPropertyList;
        putTool(value: VariantTemplateConfigurationChatToolConfigurationToolChoiceToolProperty[] | cdktn.IResolvable): void;
        resetTool(): void;
        get toolInput(): cdktn.IResolvable | VariantTemplateConfigurationChatToolConfigurationToolChoiceToolProperty[] | undefined;
    }
    class ToolChoicePropertyList extends cdktn.ComplexList {
        internalValue?: ToolChoiceProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ToolChoicePropertyOutputReference;
    }
    interface ToolConfigurationProperty {
        /**
        * tool block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_prompt#tool TfPrompt#tool}
        */
        readonly tool?: VariantTemplateConfigurationChatToolConfigurationToolProperty[] | cdktn.IResolvable;
        /**
        * tool_choice block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_prompt#tool_choice TfPrompt#tool_choice}
        */
        readonly toolChoice?: ToolChoiceProperty[] | cdktn.IResolvable;
    }
    class ToolConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ToolConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ToolConfigurationProperty | cdktn.IResolvable | undefined);
        private _tool;
        get tool(): VariantTemplateConfigurationChatToolConfigurationToolPropertyList;
        putTool(value: VariantTemplateConfigurationChatToolConfigurationToolProperty[] | cdktn.IResolvable): void;
        resetTool(): void;
        get toolInput(): cdktn.IResolvable | VariantTemplateConfigurationChatToolConfigurationToolProperty[] | undefined;
        private _toolChoice;
        get toolChoice(): ToolChoicePropertyList;
        putToolChoice(value: ToolChoiceProperty[] | cdktn.IResolvable): void;
        resetToolChoice(): void;
        get toolChoiceInput(): cdktn.IResolvable | ToolChoiceProperty[] | undefined;
    }
    class ToolConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: ToolConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ToolConfigurationPropertyOutputReference;
    }
    interface ChatProperty {
        /**
        * input_variable block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_prompt#input_variable TfPrompt#input_variable}
        */
        readonly inputVariable?: VariantTemplateConfigurationChatInputVariableProperty[] | cdktn.IResolvable;
        /**
        * message block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_prompt#message TfPrompt#message}
        */
        readonly message?: MessageProperty[] | cdktn.IResolvable;
        /**
        * system block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_prompt#system TfPrompt#system}
        */
        readonly systemAttribute?: SystemProperty[] | cdktn.IResolvable;
        /**
        * tool_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_prompt#tool_configuration TfPrompt#tool_configuration}
        */
        readonly toolConfiguration?: ToolConfigurationProperty[] | cdktn.IResolvable;
    }
    class ChatPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ChatProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ChatProperty | cdktn.IResolvable | undefined);
        private _inputVariable;
        get inputVariable(): VariantTemplateConfigurationChatInputVariablePropertyList;
        putInputVariable(value: VariantTemplateConfigurationChatInputVariableProperty[] | cdktn.IResolvable): void;
        resetInputVariable(): void;
        get inputVariableInput(): cdktn.IResolvable | VariantTemplateConfigurationChatInputVariableProperty[] | undefined;
        private _message;
        get message(): MessagePropertyList;
        putMessage(value: MessageProperty[] | cdktn.IResolvable): void;
        resetMessage(): void;
        get messageInput(): cdktn.IResolvable | MessageProperty[] | undefined;
        private _system;
        get systemAttribute(): SystemPropertyList;
        putSystemAttribute(value: SystemProperty[] | cdktn.IResolvable): void;
        resetSystemAttribute(): void;
        get systemAttributeInput(): cdktn.IResolvable | SystemProperty[] | undefined;
        private _toolConfiguration;
        get toolConfiguration(): ToolConfigurationPropertyList;
        putToolConfiguration(value: ToolConfigurationProperty[] | cdktn.IResolvable): void;
        resetToolConfiguration(): void;
        get toolConfigurationInput(): cdktn.IResolvable | ToolConfigurationProperty[] | undefined;
    }
    class ChatPropertyList extends cdktn.ComplexList {
        internalValue?: ChatProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ChatPropertyOutputReference;
    }
    interface VariantTemplateConfigurationTextCachePointProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_prompt#type TfPrompt#type}
        */
        readonly type: string;
    }
    class VariantTemplateConfigurationTextCachePointPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): VariantTemplateConfigurationTextCachePointProperty | cdktn.IResolvable | undefined;
        set internalValue(value: VariantTemplateConfigurationTextCachePointProperty | cdktn.IResolvable | undefined);
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
    }
    class VariantTemplateConfigurationTextCachePointPropertyList extends cdktn.ComplexList {
        internalValue?: VariantTemplateConfigurationTextCachePointProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): VariantTemplateConfigurationTextCachePointPropertyOutputReference;
    }
    interface VariantTemplateConfigurationTextInputVariableProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_prompt#name TfPrompt#name}
        */
        readonly name: string;
    }
    class VariantTemplateConfigurationTextInputVariablePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): VariantTemplateConfigurationTextInputVariableProperty | cdktn.IResolvable | undefined;
        set internalValue(value: VariantTemplateConfigurationTextInputVariableProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
    }
    class VariantTemplateConfigurationTextInputVariablePropertyList extends cdktn.ComplexList {
        internalValue?: VariantTemplateConfigurationTextInputVariableProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): VariantTemplateConfigurationTextInputVariablePropertyOutputReference;
    }
    interface VariantTemplateConfigurationTextProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_prompt#text TfPrompt#text}
        */
        readonly text: string;
        /**
        * cache_point block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_prompt#cache_point TfPrompt#cache_point}
        */
        readonly cachePoint?: VariantTemplateConfigurationTextCachePointProperty[] | cdktn.IResolvable;
        /**
        * input_variable block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_prompt#input_variable TfPrompt#input_variable}
        */
        readonly inputVariable?: VariantTemplateConfigurationTextInputVariableProperty[] | cdktn.IResolvable;
    }
    class VariantTemplateConfigurationTextPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): VariantTemplateConfigurationTextProperty | cdktn.IResolvable | undefined;
        set internalValue(value: VariantTemplateConfigurationTextProperty | cdktn.IResolvable | undefined);
        private _text?;
        get text(): string;
        set text(value: string);
        get textInput(): string | undefined;
        private _cachePoint;
        get cachePoint(): VariantTemplateConfigurationTextCachePointPropertyList;
        putCachePoint(value: VariantTemplateConfigurationTextCachePointProperty[] | cdktn.IResolvable): void;
        resetCachePoint(): void;
        get cachePointInput(): cdktn.IResolvable | VariantTemplateConfigurationTextCachePointProperty[] | undefined;
        private _inputVariable;
        get inputVariable(): VariantTemplateConfigurationTextInputVariablePropertyList;
        putInputVariable(value: VariantTemplateConfigurationTextInputVariableProperty[] | cdktn.IResolvable): void;
        resetInputVariable(): void;
        get inputVariableInput(): cdktn.IResolvable | VariantTemplateConfigurationTextInputVariableProperty[] | undefined;
    }
    class VariantTemplateConfigurationTextPropertyList extends cdktn.ComplexList {
        internalValue?: VariantTemplateConfigurationTextProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): VariantTemplateConfigurationTextPropertyOutputReference;
    }
    interface TemplateConfigurationProperty {
        /**
        * chat block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_prompt#chat TfPrompt#chat}
        */
        readonly chat?: ChatProperty[] | cdktn.IResolvable;
        /**
        * text block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_prompt#text TfPrompt#text}
        */
        readonly text?: VariantTemplateConfigurationTextProperty[] | cdktn.IResolvable;
    }
    class TemplateConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TemplateConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TemplateConfigurationProperty | cdktn.IResolvable | undefined);
        private _chat;
        get chat(): ChatPropertyList;
        putChat(value: ChatProperty[] | cdktn.IResolvable): void;
        resetChat(): void;
        get chatInput(): cdktn.IResolvable | ChatProperty[] | undefined;
        private _text;
        get text(): VariantTemplateConfigurationTextPropertyList;
        putText(value: VariantTemplateConfigurationTextProperty[] | cdktn.IResolvable): void;
        resetText(): void;
        get textInput(): cdktn.IResolvable | VariantTemplateConfigurationTextProperty[] | undefined;
    }
    class TemplateConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: TemplateConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TemplateConfigurationPropertyOutputReference;
    }
    interface VariantProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_prompt#additional_model_request_fields TfPrompt#additional_model_request_fields}
        */
        readonly additionalModelRequestFields?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_prompt#model_id TfPrompt#model_id}
        */
        readonly modelId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_prompt#name TfPrompt#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_prompt#template_type TfPrompt#template_type}
        */
        readonly templateType: string;
        /**
        * gen_ai_resource block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_prompt#gen_ai_resource TfPrompt#gen_ai_resource}
        */
        readonly genAiResource?: GenAiResourceProperty[] | cdktn.IResolvable;
        /**
        * inference_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_prompt#inference_configuration TfPrompt#inference_configuration}
        */
        readonly inferenceConfiguration?: InferenceConfigurationProperty[] | cdktn.IResolvable;
        /**
        * metadata block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_prompt#metadata TfPrompt#metadata}
        */
        readonly metadata?: MetadataProperty[] | cdktn.IResolvable;
        /**
        * template_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_prompt#template_configuration TfPrompt#template_configuration}
        */
        readonly templateConfiguration?: TemplateConfigurationProperty[] | cdktn.IResolvable;
    }
    class VariantPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): VariantProperty | cdktn.IResolvable | undefined;
        set internalValue(value: VariantProperty | cdktn.IResolvable | undefined);
        private _additionalModelRequestFields?;
        get additionalModelRequestFields(): string;
        set additionalModelRequestFields(value: string);
        resetAdditionalModelRequestFields(): void;
        get additionalModelRequestFieldsInput(): string | undefined;
        private _modelId?;
        get modelId(): string;
        set modelId(value: string);
        resetModelId(): void;
        get modelIdInput(): string | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _templateType?;
        get templateType(): string;
        set templateType(value: string);
        get templateTypeInput(): string | undefined;
        private _genAiResource;
        get genAiResource(): GenAiResourcePropertyList;
        putGenAiResource(value: GenAiResourceProperty[] | cdktn.IResolvable): void;
        resetGenAiResource(): void;
        get genAiResourceInput(): cdktn.IResolvable | GenAiResourceProperty[] | undefined;
        private _inferenceConfiguration;
        get inferenceConfiguration(): InferenceConfigurationPropertyList;
        putInferenceConfiguration(value: InferenceConfigurationProperty[] | cdktn.IResolvable): void;
        resetInferenceConfiguration(): void;
        get inferenceConfigurationInput(): cdktn.IResolvable | InferenceConfigurationProperty[] | undefined;
        private _metadata;
        get metadata(): MetadataPropertyList;
        putMetadata(value: MetadataProperty[] | cdktn.IResolvable): void;
        resetMetadata(): void;
        get metadataInput(): cdktn.IResolvable | MetadataProperty[] | undefined;
        private _templateConfiguration;
        get templateConfiguration(): TemplateConfigurationPropertyList;
        putTemplateConfiguration(value: TemplateConfigurationProperty[] | cdktn.IResolvable): void;
        resetTemplateConfiguration(): void;
        get templateConfigurationInput(): cdktn.IResolvable | TemplateConfigurationProperty[] | undefined;
    }
    class VariantPropertyList extends cdktn.ComplexList {
        internalValue?: VariantProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): VariantPropertyOutputReference;
    }
}
