import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsDirectoryConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspaces_directory#directory_id AwsDirectory#directory_id}
    */
    readonly directoryId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspaces_directory#id AwsDirectory#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspaces_directory#ip_group_ids AwsDirectory#ip_group_ids}
    */
    readonly ipGroupIds?: string[];
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspaces_directory#region AwsDirectory#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspaces_directory#subnet_ids AwsDirectory#subnet_ids}
    */
    readonly subnetIds?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspaces_directory#tags AwsDirectory#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspaces_directory#tags_all AwsDirectory#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspaces_directory#tenancy AwsDirectory#tenancy}
    */
    readonly tenancy?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspaces_directory#user_identity_type AwsDirectory#user_identity_type}
    */
    readonly userIdentityType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspaces_directory#workspace_directory_description AwsDirectory#workspace_directory_description}
    */
    readonly workspaceDirectoryDescription?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspaces_directory#workspace_directory_name AwsDirectory#workspace_directory_name}
    */
    readonly workspaceDirectoryName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspaces_directory#workspace_type AwsDirectory#workspace_type}
    */
    readonly workspaceType?: string;
    /**
    * active_directory_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspaces_directory#active_directory_config AwsDirectory#active_directory_config}
    */
    readonly activeDirectoryConfig?: AwsDirectory.ActiveDirectoryConfigProperty;
    /**
    * certificate_based_auth_properties block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspaces_directory#certificate_based_auth_properties AwsDirectory#certificate_based_auth_properties}
    */
    readonly certificateBasedAuthProperties?: AwsDirectory.CertificateBasedAuthPropertiesProperty;
    /**
    * saml_properties block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspaces_directory#saml_properties AwsDirectory#saml_properties}
    */
    readonly samlProperties?: AwsDirectory.SamlPropertiesProperty;
    /**
    * self_service_permissions block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspaces_directory#self_service_permissions AwsDirectory#self_service_permissions}
    */
    readonly selfServicePermissions?: AwsDirectory.SelfServicePermissionsProperty;
    /**
    * workspace_access_properties block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspaces_directory#workspace_access_properties AwsDirectory#workspace_access_properties}
    */
    readonly workspaceAccessProperties?: AwsDirectory.WorkspaceAccessPropertiesProperty;
    /**
    * workspace_creation_properties block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspaces_directory#workspace_creation_properties AwsDirectory#workspace_creation_properties}
    */
    readonly workspaceCreationProperties?: AwsDirectory.WorkspaceCreationPropertiesProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspaces_directory aws_workspaces_directory}
*/
export declare class AwsDirectory extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_workspaces_directory";
    /**
    * Generates CDKTN code for importing a AwsDirectory resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsDirectory to import
    * @param importFromId The id of the existing AwsDirectory that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspaces_directory#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsDirectory to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspaces_directory aws_workspaces_directory} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsDirectoryConfig = {}
    */
    constructor(scope: Construct, id: string, config?: AwsDirectoryConfig);
    get alias(): string;
    get customerUserName(): string;
    private _directoryId?;
    get directoryId(): string;
    set directoryId(value: string);
    resetDirectoryId(): void;
    get directoryIdInput(): string | undefined;
    get directoryName(): string;
    get directoryType(): string;
    get dnsIpAddresses(): string[];
    get iamRoleId(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _ipGroupIds?;
    get ipGroupIds(): string[];
    set ipGroupIds(value: string[]);
    resetIpGroupIds(): void;
    get ipGroupIdsInput(): string[] | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get registrationCode(): string;
    private _subnetIds?;
    get subnetIds(): string[];
    set subnetIds(value: string[]);
    resetSubnetIds(): void;
    get subnetIdsInput(): string[] | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _tenancy?;
    get tenancy(): string;
    set tenancy(value: string);
    resetTenancy(): void;
    get tenancyInput(): string | undefined;
    private _userIdentityType?;
    get userIdentityType(): string;
    set userIdentityType(value: string);
    resetUserIdentityType(): void;
    get userIdentityTypeInput(): string | undefined;
    private _workspaceDirectoryDescription?;
    get workspaceDirectoryDescription(): string;
    set workspaceDirectoryDescription(value: string);
    resetWorkspaceDirectoryDescription(): void;
    get workspaceDirectoryDescriptionInput(): string | undefined;
    private _workspaceDirectoryName?;
    get workspaceDirectoryName(): string;
    set workspaceDirectoryName(value: string);
    resetWorkspaceDirectoryName(): void;
    get workspaceDirectoryNameInput(): string | undefined;
    get workspaceSecurityGroupId(): string;
    private _workspaceType?;
    get workspaceType(): string;
    set workspaceType(value: string);
    resetWorkspaceType(): void;
    get workspaceTypeInput(): string | undefined;
    private _activeDirectoryConfig;
    get activeDirectoryConfig(): AwsDirectory.ActiveDirectoryConfigPropertyOutputReference;
    putActiveDirectoryConfig(value: AwsDirectory.ActiveDirectoryConfigProperty): void;
    resetActiveDirectoryConfig(): void;
    get activeDirectoryConfigInput(): AwsDirectory.ActiveDirectoryConfigProperty | undefined;
    private _certificateBasedAuthProperties;
    get certificateBasedAuthProperties(): AwsDirectory.CertificateBasedAuthPropertiesPropertyOutputReference;
    putCertificateBasedAuthProperties(value: AwsDirectory.CertificateBasedAuthPropertiesProperty): void;
    resetCertificateBasedAuthProperties(): void;
    get certificateBasedAuthPropertiesInput(): AwsDirectory.CertificateBasedAuthPropertiesProperty | undefined;
    private _samlProperties;
    get samlProperties(): AwsDirectory.SamlPropertiesPropertyOutputReference;
    putSamlProperties(value: AwsDirectory.SamlPropertiesProperty): void;
    resetSamlProperties(): void;
    get samlPropertiesInput(): AwsDirectory.SamlPropertiesProperty | undefined;
    private _selfServicePermissions;
    get selfServicePermissions(): AwsDirectory.SelfServicePermissionsPropertyOutputReference;
    putSelfServicePermissions(value: AwsDirectory.SelfServicePermissionsProperty): void;
    resetSelfServicePermissions(): void;
    get selfServicePermissionsInput(): AwsDirectory.SelfServicePermissionsProperty | undefined;
    private _workspaceAccessProperties;
    get workspaceAccessProperties(): AwsDirectory.WorkspaceAccessPropertiesPropertyOutputReference;
    putWorkspaceAccessProperties(value: AwsDirectory.WorkspaceAccessPropertiesProperty): void;
    resetWorkspaceAccessProperties(): void;
    get workspaceAccessPropertiesInput(): AwsDirectory.WorkspaceAccessPropertiesProperty | undefined;
    private _workspaceCreationProperties;
    get workspaceCreationProperties(): AwsDirectory.WorkspaceCreationPropertiesPropertyOutputReference;
    putWorkspaceCreationProperties(value: AwsDirectory.WorkspaceCreationPropertiesProperty): void;
    resetWorkspaceCreationProperties(): void;
    get workspaceCreationPropertiesInput(): AwsDirectory.WorkspaceCreationPropertiesProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsDirectoryActiveDirectoryConfigPropertyToTerraform(struct?: AwsDirectory.ActiveDirectoryConfigPropertyOutputReference | AwsDirectory.ActiveDirectoryConfigProperty): any;
export declare function awsDirectoryActiveDirectoryConfigPropertyToHclTerraform(struct?: AwsDirectory.ActiveDirectoryConfigPropertyOutputReference | AwsDirectory.ActiveDirectoryConfigProperty): any;
export declare function awsDirectoryCertificateBasedAuthPropertiesPropertyToTerraform(struct?: AwsDirectory.CertificateBasedAuthPropertiesPropertyOutputReference | AwsDirectory.CertificateBasedAuthPropertiesProperty): any;
export declare function awsDirectoryCertificateBasedAuthPropertiesPropertyToHclTerraform(struct?: AwsDirectory.CertificateBasedAuthPropertiesPropertyOutputReference | AwsDirectory.CertificateBasedAuthPropertiesProperty): any;
export declare function awsDirectorySamlPropertiesPropertyToTerraform(struct?: AwsDirectory.SamlPropertiesPropertyOutputReference | AwsDirectory.SamlPropertiesProperty): any;
export declare function awsDirectorySamlPropertiesPropertyToHclTerraform(struct?: AwsDirectory.SamlPropertiesPropertyOutputReference | AwsDirectory.SamlPropertiesProperty): any;
export declare function awsDirectorySelfServicePermissionsPropertyToTerraform(struct?: AwsDirectory.SelfServicePermissionsPropertyOutputReference | AwsDirectory.SelfServicePermissionsProperty): any;
export declare function awsDirectorySelfServicePermissionsPropertyToHclTerraform(struct?: AwsDirectory.SelfServicePermissionsPropertyOutputReference | AwsDirectory.SelfServicePermissionsProperty): any;
export declare function awsDirectoryAccessEndpointsPropertyToTerraform(struct?: AwsDirectory.AccessEndpointsProperty | cdktn.IResolvable): any;
export declare function awsDirectoryAccessEndpointsPropertyToHclTerraform(struct?: AwsDirectory.AccessEndpointsProperty | cdktn.IResolvable): any;
export declare function awsDirectoryAccessEndpointConfigPropertyToTerraform(struct?: AwsDirectory.AccessEndpointConfigPropertyOutputReference | AwsDirectory.AccessEndpointConfigProperty): any;
export declare function awsDirectoryAccessEndpointConfigPropertyToHclTerraform(struct?: AwsDirectory.AccessEndpointConfigPropertyOutputReference | AwsDirectory.AccessEndpointConfigProperty): any;
export declare function awsDirectoryWorkspaceAccessPropertiesPropertyToTerraform(struct?: AwsDirectory.WorkspaceAccessPropertiesPropertyOutputReference | AwsDirectory.WorkspaceAccessPropertiesProperty): any;
export declare function awsDirectoryWorkspaceAccessPropertiesPropertyToHclTerraform(struct?: AwsDirectory.WorkspaceAccessPropertiesPropertyOutputReference | AwsDirectory.WorkspaceAccessPropertiesProperty): any;
export declare function awsDirectoryWorkspaceCreationPropertiesPropertyToTerraform(struct?: AwsDirectory.WorkspaceCreationPropertiesPropertyOutputReference | AwsDirectory.WorkspaceCreationPropertiesProperty): any;
export declare function awsDirectoryWorkspaceCreationPropertiesPropertyToHclTerraform(struct?: AwsDirectory.WorkspaceCreationPropertiesPropertyOutputReference | AwsDirectory.WorkspaceCreationPropertiesProperty): any;
export declare namespace AwsDirectory {
    interface ActiveDirectoryConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspaces_directory#domain_name AwsDirectory#domain_name}
        */
        readonly domainName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspaces_directory#service_account_secret_arn AwsDirectory#service_account_secret_arn}
        */
        readonly serviceAccountSecretArn: string;
    }
    class ActiveDirectoryConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ActiveDirectoryConfigProperty | undefined;
        set internalValue(value: ActiveDirectoryConfigProperty | undefined);
        private _domainName?;
        get domainName(): string;
        set domainName(value: string);
        get domainNameInput(): string | undefined;
        private _serviceAccountSecretArn?;
        get serviceAccountSecretArn(): string;
        set serviceAccountSecretArn(value: string);
        get serviceAccountSecretArnInput(): string | undefined;
    }
    interface CertificateBasedAuthPropertiesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspaces_directory#certificate_authority_arn AwsDirectory#certificate_authority_arn}
        */
        readonly certificateAuthorityArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspaces_directory#status AwsDirectory#status}
        */
        readonly status?: string;
    }
    class CertificateBasedAuthPropertiesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CertificateBasedAuthPropertiesProperty | undefined;
        set internalValue(value: CertificateBasedAuthPropertiesProperty | undefined);
        private _certificateAuthorityArn?;
        get certificateAuthorityArn(): string;
        set certificateAuthorityArn(value: string);
        resetCertificateAuthorityArn(): void;
        get certificateAuthorityArnInput(): string | undefined;
        private _status?;
        get status(): string;
        set status(value: string);
        resetStatus(): void;
        get statusInput(): string | undefined;
    }
    interface SamlPropertiesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspaces_directory#relay_state_parameter_name AwsDirectory#relay_state_parameter_name}
        */
        readonly relayStateParameterName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspaces_directory#status AwsDirectory#status}
        */
        readonly status?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspaces_directory#user_access_url AwsDirectory#user_access_url}
        */
        readonly userAccessUrl?: string;
    }
    class SamlPropertiesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SamlPropertiesProperty | undefined;
        set internalValue(value: SamlPropertiesProperty | undefined);
        private _relayStateParameterName?;
        get relayStateParameterName(): string;
        set relayStateParameterName(value: string);
        resetRelayStateParameterName(): void;
        get relayStateParameterNameInput(): string | undefined;
        private _status?;
        get status(): string;
        set status(value: string);
        resetStatus(): void;
        get statusInput(): string | undefined;
        private _userAccessUrl?;
        get userAccessUrl(): string;
        set userAccessUrl(value: string);
        resetUserAccessUrl(): void;
        get userAccessUrlInput(): string | undefined;
    }
    interface SelfServicePermissionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspaces_directory#change_compute_type AwsDirectory#change_compute_type}
        */
        readonly changeComputeType?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspaces_directory#increase_volume_size AwsDirectory#increase_volume_size}
        */
        readonly increaseVolumeSize?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspaces_directory#rebuild_workspace AwsDirectory#rebuild_workspace}
        */
        readonly rebuildWorkspace?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspaces_directory#restart_workspace AwsDirectory#restart_workspace}
        */
        readonly restartWorkspace?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspaces_directory#switch_running_mode AwsDirectory#switch_running_mode}
        */
        readonly switchRunningMode?: boolean | cdktn.IResolvable;
    }
    class SelfServicePermissionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SelfServicePermissionsProperty | undefined;
        set internalValue(value: SelfServicePermissionsProperty | undefined);
        private _changeComputeType?;
        get changeComputeType(): boolean | cdktn.IResolvable;
        set changeComputeType(value: boolean | cdktn.IResolvable);
        resetChangeComputeType(): void;
        get changeComputeTypeInput(): boolean | cdktn.IResolvable | undefined;
        private _increaseVolumeSize?;
        get increaseVolumeSize(): boolean | cdktn.IResolvable;
        set increaseVolumeSize(value: boolean | cdktn.IResolvable);
        resetIncreaseVolumeSize(): void;
        get increaseVolumeSizeInput(): boolean | cdktn.IResolvable | undefined;
        private _rebuildWorkspace?;
        get rebuildWorkspace(): boolean | cdktn.IResolvable;
        set rebuildWorkspace(value: boolean | cdktn.IResolvable);
        resetRebuildWorkspace(): void;
        get rebuildWorkspaceInput(): boolean | cdktn.IResolvable | undefined;
        private _restartWorkspace?;
        get restartWorkspace(): boolean | cdktn.IResolvable;
        set restartWorkspace(value: boolean | cdktn.IResolvable);
        resetRestartWorkspace(): void;
        get restartWorkspaceInput(): boolean | cdktn.IResolvable | undefined;
        private _switchRunningMode?;
        get switchRunningMode(): boolean | cdktn.IResolvable;
        set switchRunningMode(value: boolean | cdktn.IResolvable);
        resetSwitchRunningMode(): void;
        get switchRunningModeInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface AccessEndpointsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspaces_directory#access_endpoint_type AwsDirectory#access_endpoint_type}
        */
        readonly accessEndpointType: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspaces_directory#vpc_endpoint_id AwsDirectory#vpc_endpoint_id}
        */
        readonly vpcEndpointId: string;
    }
    class AccessEndpointsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AccessEndpointsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: AccessEndpointsProperty | cdktn.IResolvable | undefined);
        private _accessEndpointType?;
        get accessEndpointType(): string;
        set accessEndpointType(value: string);
        get accessEndpointTypeInput(): string | undefined;
        private _vpcEndpointId?;
        get vpcEndpointId(): string;
        set vpcEndpointId(value: string);
        get vpcEndpointIdInput(): string | undefined;
    }
    class AccessEndpointsPropertyList extends cdktn.ComplexList {
        internalValue?: AccessEndpointsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AccessEndpointsPropertyOutputReference;
    }
    interface AccessEndpointConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspaces_directory#internet_fallback_protocols AwsDirectory#internet_fallback_protocols}
        */
        readonly internetFallbackProtocols?: string[];
        /**
        * access_endpoints block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspaces_directory#access_endpoints AwsDirectory#access_endpoints}
        */
        readonly accessEndpoints: AccessEndpointsProperty[] | cdktn.IResolvable;
    }
    class AccessEndpointConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AccessEndpointConfigProperty | undefined;
        set internalValue(value: AccessEndpointConfigProperty | undefined);
        private _internetFallbackProtocols?;
        get internetFallbackProtocols(): string[];
        set internetFallbackProtocols(value: string[]);
        resetInternetFallbackProtocols(): void;
        get internetFallbackProtocolsInput(): string[] | undefined;
        private _accessEndpoints;
        get accessEndpoints(): AccessEndpointsPropertyList;
        putAccessEndpoints(value: AccessEndpointsProperty[] | cdktn.IResolvable): void;
        get accessEndpointsInput(): cdktn.IResolvable | AccessEndpointsProperty[] | undefined;
    }
    interface WorkspaceAccessPropertiesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspaces_directory#device_type_android AwsDirectory#device_type_android}
        */
        readonly deviceTypeAndroid?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspaces_directory#device_type_chromeos AwsDirectory#device_type_chromeos}
        */
        readonly deviceTypeChromeos?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspaces_directory#device_type_ios AwsDirectory#device_type_ios}
        */
        readonly deviceTypeIos?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspaces_directory#device_type_linux AwsDirectory#device_type_linux}
        */
        readonly deviceTypeLinux?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspaces_directory#device_type_osx AwsDirectory#device_type_osx}
        */
        readonly deviceTypeOsx?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspaces_directory#device_type_web AwsDirectory#device_type_web}
        */
        readonly deviceTypeWeb?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspaces_directory#device_type_windows AwsDirectory#device_type_windows}
        */
        readonly deviceTypeWindows?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspaces_directory#device_type_zeroclient AwsDirectory#device_type_zeroclient}
        */
        readonly deviceTypeZeroclient?: string;
        /**
        * access_endpoint_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspaces_directory#access_endpoint_config AwsDirectory#access_endpoint_config}
        */
        readonly accessEndpointConfig?: AccessEndpointConfigProperty;
    }
    class WorkspaceAccessPropertiesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): WorkspaceAccessPropertiesProperty | undefined;
        set internalValue(value: WorkspaceAccessPropertiesProperty | undefined);
        private _deviceTypeAndroid?;
        get deviceTypeAndroid(): string;
        set deviceTypeAndroid(value: string);
        resetDeviceTypeAndroid(): void;
        get deviceTypeAndroidInput(): string | undefined;
        private _deviceTypeChromeos?;
        get deviceTypeChromeos(): string;
        set deviceTypeChromeos(value: string);
        resetDeviceTypeChromeos(): void;
        get deviceTypeChromeosInput(): string | undefined;
        private _deviceTypeIos?;
        get deviceTypeIos(): string;
        set deviceTypeIos(value: string);
        resetDeviceTypeIos(): void;
        get deviceTypeIosInput(): string | undefined;
        private _deviceTypeLinux?;
        get deviceTypeLinux(): string;
        set deviceTypeLinux(value: string);
        resetDeviceTypeLinux(): void;
        get deviceTypeLinuxInput(): string | undefined;
        private _deviceTypeOsx?;
        get deviceTypeOsx(): string;
        set deviceTypeOsx(value: string);
        resetDeviceTypeOsx(): void;
        get deviceTypeOsxInput(): string | undefined;
        private _deviceTypeWeb?;
        get deviceTypeWeb(): string;
        set deviceTypeWeb(value: string);
        resetDeviceTypeWeb(): void;
        get deviceTypeWebInput(): string | undefined;
        private _deviceTypeWindows?;
        get deviceTypeWindows(): string;
        set deviceTypeWindows(value: string);
        resetDeviceTypeWindows(): void;
        get deviceTypeWindowsInput(): string | undefined;
        private _deviceTypeZeroclient?;
        get deviceTypeZeroclient(): string;
        set deviceTypeZeroclient(value: string);
        resetDeviceTypeZeroclient(): void;
        get deviceTypeZeroclientInput(): string | undefined;
        private _accessEndpointConfig;
        get accessEndpointConfig(): AccessEndpointConfigPropertyOutputReference;
        putAccessEndpointConfig(value: AccessEndpointConfigProperty): void;
        resetAccessEndpointConfig(): void;
        get accessEndpointConfigInput(): AccessEndpointConfigProperty | undefined;
    }
    interface WorkspaceCreationPropertiesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspaces_directory#custom_security_group_id AwsDirectory#custom_security_group_id}
        */
        readonly customSecurityGroupId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspaces_directory#default_ou AwsDirectory#default_ou}
        */
        readonly defaultOu?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspaces_directory#enable_internet_access AwsDirectory#enable_internet_access}
        */
        readonly enableInternetAccess?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspaces_directory#enable_maintenance_mode AwsDirectory#enable_maintenance_mode}
        */
        readonly enableMaintenanceMode?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspaces_directory#user_enabled_as_local_administrator AwsDirectory#user_enabled_as_local_administrator}
        */
        readonly userEnabledAsLocalAdministrator?: boolean | cdktn.IResolvable;
    }
    class WorkspaceCreationPropertiesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): WorkspaceCreationPropertiesProperty | undefined;
        set internalValue(value: WorkspaceCreationPropertiesProperty | undefined);
        private _customSecurityGroupId?;
        get customSecurityGroupId(): string;
        set customSecurityGroupId(value: string);
        resetCustomSecurityGroupId(): void;
        get customSecurityGroupIdInput(): string | undefined;
        private _defaultOu?;
        get defaultOu(): string;
        set defaultOu(value: string);
        resetDefaultOu(): void;
        get defaultOuInput(): string | undefined;
        private _enableInternetAccess?;
        get enableInternetAccess(): boolean | cdktn.IResolvable;
        set enableInternetAccess(value: boolean | cdktn.IResolvable);
        resetEnableInternetAccess(): void;
        get enableInternetAccessInput(): boolean | cdktn.IResolvable | undefined;
        private _enableMaintenanceMode?;
        get enableMaintenanceMode(): boolean | cdktn.IResolvable;
        set enableMaintenanceMode(value: boolean | cdktn.IResolvable);
        resetEnableMaintenanceMode(): void;
        get enableMaintenanceModeInput(): boolean | cdktn.IResolvable | undefined;
        private _userEnabledAsLocalAdministrator?;
        get userEnabledAsLocalAdministrator(): boolean | cdktn.IResolvable;
        set userEnabledAsLocalAdministrator(value: boolean | cdktn.IResolvable);
        resetUserEnabledAsLocalAdministrator(): void;
        get userEnabledAsLocalAdministratorInput(): boolean | cdktn.IResolvable | undefined;
    }
}
