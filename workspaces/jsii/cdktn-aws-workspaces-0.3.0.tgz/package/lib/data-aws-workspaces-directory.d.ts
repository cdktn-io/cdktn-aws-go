import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsDirectoryConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/workspaces_directory#directory_id DataAwsDirectory#directory_id}
    */
    readonly directoryId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/workspaces_directory#id DataAwsDirectory#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/workspaces_directory#region DataAwsDirectory#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/workspaces_directory#tags DataAwsDirectory#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/workspaces_directory aws_workspaces_directory}
*/
export declare class DataAwsDirectory extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_workspaces_directory";
    /**
    * Generates CDKTN code for importing a DataAwsDirectory resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsDirectory to import
    * @param importFromId The id of the existing DataAwsDirectory that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/workspaces_directory#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsDirectory to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/workspaces_directory aws_workspaces_directory} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsDirectoryConfig
    */
    constructor(scope: Construct, id: string, config: DataAwsDirectoryConfig);
    private _activeDirectoryConfig;
    get activeDirectoryConfig(): DataAwsDirectory.ActiveDirectoryConfigPropertyList;
    get alias(): string;
    private _certificateBasedAuthProperties;
    get certificateBasedAuthProperties(): DataAwsDirectory.CertificateBasedAuthPropertiesPropertyList;
    get customerUserName(): string;
    private _directoryId?;
    get directoryId(): string;
    set directoryId(value: string);
    get directoryIdInput(): string | undefined;
    get directoryName(): string;
    get directoryType(): string;
    get dnsIpAddresses(): string[];
    get iamRoleId(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get ipGroupIds(): string[];
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get registrationCode(): string;
    private _samlProperties;
    get samlProperties(): DataAwsDirectory.SamlPropertiesPropertyList;
    private _selfServicePermissions;
    get selfServicePermissions(): DataAwsDirectory.SelfServicePermissionsPropertyList;
    get subnetIds(): string[];
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    get tenancy(): string;
    get userIdentityType(): string;
    private _workspaceAccessProperties;
    get workspaceAccessProperties(): DataAwsDirectory.WorkspaceAccessPropertiesPropertyList;
    private _workspaceCreationProperties;
    get workspaceCreationProperties(): DataAwsDirectory.WorkspaceCreationPropertiesPropertyList;
    get workspaceDirectoryDescription(): string;
    get workspaceDirectoryName(): string;
    get workspaceSecurityGroupId(): string;
    get workspaceType(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataAwsDirectoryActiveDirectoryConfigPropertyToTerraform(struct?: DataAwsDirectory.ActiveDirectoryConfigProperty): any;
export declare function dataAwsDirectoryActiveDirectoryConfigPropertyToHclTerraform(struct?: DataAwsDirectory.ActiveDirectoryConfigProperty): any;
export declare function dataAwsDirectoryCertificateBasedAuthPropertiesPropertyToTerraform(struct?: DataAwsDirectory.CertificateBasedAuthPropertiesProperty): any;
export declare function dataAwsDirectoryCertificateBasedAuthPropertiesPropertyToHclTerraform(struct?: DataAwsDirectory.CertificateBasedAuthPropertiesProperty): any;
export declare function dataAwsDirectorySamlPropertiesPropertyToTerraform(struct?: DataAwsDirectory.SamlPropertiesProperty): any;
export declare function dataAwsDirectorySamlPropertiesPropertyToHclTerraform(struct?: DataAwsDirectory.SamlPropertiesProperty): any;
export declare function dataAwsDirectorySelfServicePermissionsPropertyToTerraform(struct?: DataAwsDirectory.SelfServicePermissionsProperty): any;
export declare function dataAwsDirectorySelfServicePermissionsPropertyToHclTerraform(struct?: DataAwsDirectory.SelfServicePermissionsProperty): any;
export declare function dataAwsDirectoryWorkspaceAccessPropertiesPropertyToTerraform(struct?: DataAwsDirectory.WorkspaceAccessPropertiesProperty): any;
export declare function dataAwsDirectoryWorkspaceAccessPropertiesPropertyToHclTerraform(struct?: DataAwsDirectory.WorkspaceAccessPropertiesProperty): any;
export declare function dataAwsDirectoryWorkspaceCreationPropertiesPropertyToTerraform(struct?: DataAwsDirectory.WorkspaceCreationPropertiesProperty): any;
export declare function dataAwsDirectoryWorkspaceCreationPropertiesPropertyToHclTerraform(struct?: DataAwsDirectory.WorkspaceCreationPropertiesProperty): any;
export declare namespace DataAwsDirectory {
    interface ActiveDirectoryConfigProperty {
    }
    class ActiveDirectoryConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ActiveDirectoryConfigProperty | undefined;
        set internalValue(value: ActiveDirectoryConfigProperty | undefined);
        get domainName(): string;
        get serviceAccountSecretArn(): string;
    }
    class ActiveDirectoryConfigPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ActiveDirectoryConfigPropertyOutputReference;
    }
    interface CertificateBasedAuthPropertiesProperty {
    }
    class CertificateBasedAuthPropertiesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CertificateBasedAuthPropertiesProperty | undefined;
        set internalValue(value: CertificateBasedAuthPropertiesProperty | undefined);
        get certificateAuthorityArn(): string;
        get status(): string;
    }
    class CertificateBasedAuthPropertiesPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CertificateBasedAuthPropertiesPropertyOutputReference;
    }
    interface SamlPropertiesProperty {
    }
    class SamlPropertiesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SamlPropertiesProperty | undefined;
        set internalValue(value: SamlPropertiesProperty | undefined);
        get relayStateParameterName(): string;
        get status(): string;
        get userAccessUrl(): string;
    }
    class SamlPropertiesPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SamlPropertiesPropertyOutputReference;
    }
    interface SelfServicePermissionsProperty {
    }
    class SelfServicePermissionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SelfServicePermissionsProperty | undefined;
        set internalValue(value: SelfServicePermissionsProperty | undefined);
        get changeComputeType(): cdktn.IResolvable;
        get increaseVolumeSize(): cdktn.IResolvable;
        get rebuildWorkspace(): cdktn.IResolvable;
        get restartWorkspace(): cdktn.IResolvable;
        get switchRunningMode(): cdktn.IResolvable;
    }
    class SelfServicePermissionsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SelfServicePermissionsPropertyOutputReference;
    }
    interface WorkspaceAccessPropertiesProperty {
    }
    class WorkspaceAccessPropertiesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkspaceAccessPropertiesProperty | undefined;
        set internalValue(value: WorkspaceAccessPropertiesProperty | undefined);
        get deviceTypeAndroid(): string;
        get deviceTypeChromeos(): string;
        get deviceTypeIos(): string;
        get deviceTypeLinux(): string;
        get deviceTypeOsx(): string;
        get deviceTypeWeb(): string;
        get deviceTypeWindows(): string;
        get deviceTypeZeroclient(): string;
    }
    class WorkspaceAccessPropertiesPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkspaceAccessPropertiesPropertyOutputReference;
    }
    interface WorkspaceCreationPropertiesProperty {
    }
    class WorkspaceCreationPropertiesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkspaceCreationPropertiesProperty | undefined;
        set internalValue(value: WorkspaceCreationPropertiesProperty | undefined);
        get customSecurityGroupId(): string;
        get defaultOu(): string;
        get enableInternetAccess(): cdktn.IResolvable;
        get enableMaintenanceMode(): cdktn.IResolvable;
        get userEnabledAsLocalAdministrator(): cdktn.IResolvable;
    }
    class WorkspaceCreationPropertiesPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkspaceCreationPropertiesPropertyOutputReference;
    }
}
