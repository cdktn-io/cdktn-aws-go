import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsPoolConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspaces_pool#application_settings AwsPool#application_settings}
    */
    readonly applicationSettings?: AwsPool.ApplicationSettingsProperty[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspaces_pool#bundle_id AwsPool#bundle_id}
    */
    readonly bundleId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspaces_pool#description AwsPool#description}
    */
    readonly description: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspaces_pool#directory_id AwsPool#directory_id}
    */
    readonly directoryId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspaces_pool#pool_name AwsPool#pool_name}
    */
    readonly poolName: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspaces_pool#region AwsPool#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspaces_pool#running_mode AwsPool#running_mode}
    */
    readonly runningMode: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspaces_pool#tags AwsPool#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspaces_pool#timeout_settings AwsPool#timeout_settings}
    */
    readonly timeoutSettings?: AwsPool.TimeoutSettingsProperty[] | cdktn.IResolvable;
    /**
    * capacity block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspaces_pool#capacity AwsPool#capacity}
    */
    readonly capacity?: AwsPool.CapacityProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspaces_pool#timeouts AwsPool#timeouts}
    */
    readonly timeouts?: AwsPool.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspaces_pool aws_workspaces_pool}
*/
export declare class AwsPool extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_workspaces_pool";
    /**
    * Generates CDKTN code for importing a AwsPool resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsPool to import
    * @param importFromId The id of the existing AwsPool that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspaces_pool#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsPool to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspaces_pool aws_workspaces_pool} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsPoolConfig
    */
    constructor(scope: Construct, id: string, config: AwsPoolConfig);
    private _applicationSettings;
    get applicationSettings(): AwsPool.ApplicationSettingsPropertyList;
    putApplicationSettings(value: AwsPool.ApplicationSettingsProperty[] | cdktn.IResolvable): void;
    resetApplicationSettings(): void;
    get applicationSettingsInput(): cdktn.IResolvable | AwsPool.ApplicationSettingsProperty[] | undefined;
    private _bundleId?;
    get bundleId(): string;
    set bundleId(value: string);
    get bundleIdInput(): string | undefined;
    private _capacityStatus;
    get capacityStatus(): AwsPool.CapacityStatusPropertyList;
    get createdAt(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    get descriptionInput(): string | undefined;
    private _directoryId?;
    get directoryId(): string;
    set directoryId(value: string);
    get directoryIdInput(): string | undefined;
    get poolArn(): string;
    get poolId(): string;
    private _poolName?;
    get poolName(): string;
    set poolName(value: string);
    get poolNameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _runningMode?;
    get runningMode(): string;
    set runningMode(value: string);
    get runningModeInput(): string | undefined;
    get s3BucketName(): string;
    get state(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    private _timeoutSettings;
    get timeoutSettings(): AwsPool.TimeoutSettingsPropertyList;
    putTimeoutSettings(value: AwsPool.TimeoutSettingsProperty[] | cdktn.IResolvable): void;
    resetTimeoutSettings(): void;
    get timeoutSettingsInput(): cdktn.IResolvable | AwsPool.TimeoutSettingsProperty[] | undefined;
    private _capacity;
    get capacity(): AwsPool.CapacityPropertyList;
    putCapacity(value: AwsPool.CapacityProperty[] | cdktn.IResolvable): void;
    resetCapacity(): void;
    get capacityInput(): cdktn.IResolvable | AwsPool.CapacityProperty[] | undefined;
    private _timeouts;
    get timeouts(): AwsPool.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsPool.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsPool.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsPoolApplicationSettingsPropertyToTerraform(struct?: AwsPool.ApplicationSettingsProperty | cdktn.IResolvable): any;
export declare function awsPoolApplicationSettingsPropertyToHclTerraform(struct?: AwsPool.ApplicationSettingsProperty | cdktn.IResolvable): any;
export declare function awsPoolCapacityStatusPropertyToTerraform(struct?: AwsPool.CapacityStatusProperty): any;
export declare function awsPoolCapacityStatusPropertyToHclTerraform(struct?: AwsPool.CapacityStatusProperty): any;
export declare function awsPoolTimeoutSettingsPropertyToTerraform(struct?: AwsPool.TimeoutSettingsProperty | cdktn.IResolvable): any;
export declare function awsPoolTimeoutSettingsPropertyToHclTerraform(struct?: AwsPool.TimeoutSettingsProperty | cdktn.IResolvable): any;
export declare function awsPoolCapacityPropertyToTerraform(struct?: AwsPool.CapacityProperty | cdktn.IResolvable): any;
export declare function awsPoolCapacityPropertyToHclTerraform(struct?: AwsPool.CapacityProperty | cdktn.IResolvable): any;
export declare function awsPoolTimeoutsPropertyToTerraform(struct?: AwsPool.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsPoolTimeoutsPropertyToHclTerraform(struct?: AwsPool.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsPool {
    interface ApplicationSettingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspaces_pool#settings_group AwsPool#settings_group}
        */
        readonly settingsGroup?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspaces_pool#status AwsPool#status}
        */
        readonly status?: string;
    }
    class ApplicationSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ApplicationSettingsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ApplicationSettingsProperty | cdktn.IResolvable | undefined);
        private _settingsGroup?;
        get settingsGroup(): string;
        set settingsGroup(value: string);
        resetSettingsGroup(): void;
        get settingsGroupInput(): string | undefined;
        private _status?;
        get status(): string;
        set status(value: string);
        resetStatus(): void;
        get statusInput(): string | undefined;
    }
    class ApplicationSettingsPropertyList extends cdktn.ComplexList {
        internalValue?: ApplicationSettingsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ApplicationSettingsPropertyOutputReference;
    }
    interface CapacityStatusProperty {
    }
    class CapacityStatusPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CapacityStatusProperty | undefined;
        set internalValue(value: CapacityStatusProperty | undefined);
        get activeUserSessions(): number;
        get actualUserSessions(): number;
        get availableUserSessions(): number;
        get desiredUserSessions(): number;
    }
    class CapacityStatusPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CapacityStatusPropertyOutputReference;
    }
    interface TimeoutSettingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspaces_pool#disconnect_timeout_in_seconds AwsPool#disconnect_timeout_in_seconds}
        */
        readonly disconnectTimeoutInSeconds?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspaces_pool#idle_disconnect_timeout_in_seconds AwsPool#idle_disconnect_timeout_in_seconds}
        */
        readonly idleDisconnectTimeoutInSeconds?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspaces_pool#max_user_duration_in_seconds AwsPool#max_user_duration_in_seconds}
        */
        readonly maxUserDurationInSeconds?: number;
    }
    class TimeoutSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TimeoutSettingsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutSettingsProperty | cdktn.IResolvable | undefined);
        private _disconnectTimeoutInSeconds?;
        get disconnectTimeoutInSeconds(): number;
        set disconnectTimeoutInSeconds(value: number);
        resetDisconnectTimeoutInSeconds(): void;
        get disconnectTimeoutInSecondsInput(): number | undefined;
        private _idleDisconnectTimeoutInSeconds?;
        get idleDisconnectTimeoutInSeconds(): number;
        set idleDisconnectTimeoutInSeconds(value: number);
        resetIdleDisconnectTimeoutInSeconds(): void;
        get idleDisconnectTimeoutInSecondsInput(): number | undefined;
        private _maxUserDurationInSeconds?;
        get maxUserDurationInSeconds(): number;
        set maxUserDurationInSeconds(value: number);
        resetMaxUserDurationInSeconds(): void;
        get maxUserDurationInSecondsInput(): number | undefined;
    }
    class TimeoutSettingsPropertyList extends cdktn.ComplexList {
        internalValue?: TimeoutSettingsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TimeoutSettingsPropertyOutputReference;
    }
    interface CapacityProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspaces_pool#desired_user_sessions AwsPool#desired_user_sessions}
        */
        readonly desiredUserSessions: number;
    }
    class CapacityPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CapacityProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CapacityProperty | cdktn.IResolvable | undefined);
        private _desiredUserSessions?;
        get desiredUserSessions(): number;
        set desiredUserSessions(value: number);
        get desiredUserSessionsInput(): number | undefined;
    }
    class CapacityPropertyList extends cdktn.ComplexList {
        internalValue?: CapacityProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CapacityPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspaces_pool#create AwsPool#create}
        */
        readonly create?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Setting a timeout for a Delete operation is only applicable if changes are saved into state before the destroy operation occurs.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspaces_pool#delete AwsPool#delete}
        */
        readonly delete?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspaces_pool#update AwsPool#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
