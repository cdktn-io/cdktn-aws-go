import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsQldbStreamConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/qldb_stream#exclusive_end_time AwsQldbStream#exclusive_end_time}
    */
    readonly exclusiveEndTime?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/qldb_stream#id AwsQldbStream#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/qldb_stream#inclusive_start_time AwsQldbStream#inclusive_start_time}
    */
    readonly inclusiveStartTime: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/qldb_stream#ledger_name AwsQldbStream#ledger_name}
    */
    readonly ledgerName: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/qldb_stream#region AwsQldbStream#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/qldb_stream#role_arn AwsQldbStream#role_arn}
    */
    readonly roleArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/qldb_stream#stream_name AwsQldbStream#stream_name}
    */
    readonly streamName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/qldb_stream#tags AwsQldbStream#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/qldb_stream#tags_all AwsQldbStream#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * kinesis_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/qldb_stream#kinesis_configuration AwsQldbStream#kinesis_configuration}
    */
    readonly kinesisConfiguration: AwsQldbStream.KinesisConfigurationProperty;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/qldb_stream#timeouts AwsQldbStream#timeouts}
    */
    readonly timeouts?: AwsQldbStream.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/qldb_stream aws_qldb_stream}
*/
export declare class AwsQldbStream extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_qldb_stream";
    /**
    * Generates CDKTN code for importing a AwsQldbStream resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsQldbStream to import
    * @param importFromId The id of the existing AwsQldbStream that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/qldb_stream#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsQldbStream to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/qldb_stream aws_qldb_stream} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsQldbStreamConfig
    */
    constructor(scope: Construct, id: string, config: AwsQldbStreamConfig);
    get arn(): string;
    private _exclusiveEndTime?;
    get exclusiveEndTime(): string;
    set exclusiveEndTime(value: string);
    resetExclusiveEndTime(): void;
    get exclusiveEndTimeInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _inclusiveStartTime?;
    get inclusiveStartTime(): string;
    set inclusiveStartTime(value: string);
    get inclusiveStartTimeInput(): string | undefined;
    private _ledgerName?;
    get ledgerName(): string;
    set ledgerName(value: string);
    get ledgerNameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _roleArn?;
    get roleArn(): string;
    set roleArn(value: string);
    get roleArnInput(): string | undefined;
    private _streamName?;
    get streamName(): string;
    set streamName(value: string);
    get streamNameInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _kinesisConfiguration;
    get kinesisConfiguration(): AwsQldbStream.KinesisConfigurationPropertyOutputReference;
    putKinesisConfiguration(value: AwsQldbStream.KinesisConfigurationProperty): void;
    get kinesisConfigurationInput(): AwsQldbStream.KinesisConfigurationProperty | undefined;
    private _timeouts;
    get timeouts(): AwsQldbStream.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsQldbStream.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsQldbStream.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsQldbStreamKinesisConfigurationPropertyToTerraform(struct?: AwsQldbStream.KinesisConfigurationPropertyOutputReference | AwsQldbStream.KinesisConfigurationProperty): any;
export declare function awsQldbStreamKinesisConfigurationPropertyToHclTerraform(struct?: AwsQldbStream.KinesisConfigurationPropertyOutputReference | AwsQldbStream.KinesisConfigurationProperty): any;
export declare function awsQldbStreamTimeoutsPropertyToTerraform(struct?: AwsQldbStream.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsQldbStreamTimeoutsPropertyToHclTerraform(struct?: AwsQldbStream.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsQldbStream {
    interface KinesisConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/qldb_stream#aggregation_enabled AwsQldbStream#aggregation_enabled}
        */
        readonly aggregationEnabled?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/qldb_stream#stream_arn AwsQldbStream#stream_arn}
        */
        readonly streamArn: string;
    }
    class KinesisConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): KinesisConfigurationProperty | undefined;
        set internalValue(value: KinesisConfigurationProperty | undefined);
        private _aggregationEnabled?;
        get aggregationEnabled(): boolean | cdktn.IResolvable;
        set aggregationEnabled(value: boolean | cdktn.IResolvable);
        resetAggregationEnabled(): void;
        get aggregationEnabledInput(): boolean | cdktn.IResolvable | undefined;
        private _streamArn?;
        get streamArn(): string;
        set streamArn(value: string);
        get streamArnInput(): string | undefined;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/qldb_stream#create AwsQldbStream#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/qldb_stream#delete AwsQldbStream#delete}
        */
        readonly delete?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
    }
}
