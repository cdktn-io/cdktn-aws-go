import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsCapacityProviderConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_capacity_provider#capacity_provider_scaling_config AwsCapacityProvider#capacity_provider_scaling_config}
    */
    readonly capacityProviderScalingConfig?: AwsCapacityProvider.CapacityProviderScalingConfigProperty[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_capacity_provider#instance_requirements AwsCapacityProvider#instance_requirements}
    */
    readonly instanceRequirements?: AwsCapacityProvider.InstanceRequirementsProperty[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_capacity_provider#kms_key_arn AwsCapacityProvider#kms_key_arn}
    */
    readonly kmsKeyArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_capacity_provider#name AwsCapacityProvider#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_capacity_provider#region AwsCapacityProvider#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_capacity_provider#tags AwsCapacityProvider#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * permissions_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_capacity_provider#permissions_config AwsCapacityProvider#permissions_config}
    */
    readonly permissionsConfig?: AwsCapacityProvider.PermissionsConfigProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_capacity_provider#timeouts AwsCapacityProvider#timeouts}
    */
    readonly timeouts?: AwsCapacityProvider.TimeoutsProperty;
    /**
    * vpc_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_capacity_provider#vpc_config AwsCapacityProvider#vpc_config}
    */
    readonly vpcConfig?: AwsCapacityProvider.VpcConfigProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_capacity_provider aws_lambda_capacity_provider}
*/
export declare class AwsCapacityProvider extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_lambda_capacity_provider";
    /**
    * Generates CDKTN code for importing a AwsCapacityProvider resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsCapacityProvider to import
    * @param importFromId The id of the existing AwsCapacityProvider that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_capacity_provider#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsCapacityProvider to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_capacity_provider aws_lambda_capacity_provider} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsCapacityProviderConfig
    */
    constructor(scope: Construct, id: string, config: AwsCapacityProviderConfig);
    get arn(): string;
    private _capacityProviderScalingConfig;
    get capacityProviderScalingConfig(): AwsCapacityProvider.CapacityProviderScalingConfigPropertyList;
    putCapacityProviderScalingConfig(value: AwsCapacityProvider.CapacityProviderScalingConfigProperty[] | cdktn.IResolvable): void;
    resetCapacityProviderScalingConfig(): void;
    get capacityProviderScalingConfigInput(): cdktn.IResolvable | AwsCapacityProvider.CapacityProviderScalingConfigProperty[] | undefined;
    private _instanceRequirements;
    get instanceRequirements(): AwsCapacityProvider.InstanceRequirementsPropertyList;
    putInstanceRequirements(value: AwsCapacityProvider.InstanceRequirementsProperty[] | cdktn.IResolvable): void;
    resetInstanceRequirements(): void;
    get instanceRequirementsInput(): cdktn.IResolvable | AwsCapacityProvider.InstanceRequirementsProperty[] | undefined;
    private _kmsKeyArn?;
    get kmsKeyArn(): string;
    set kmsKeyArn(value: string);
    resetKmsKeyArn(): void;
    get kmsKeyArnInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    private _permissionsConfig;
    get permissionsConfig(): AwsCapacityProvider.PermissionsConfigPropertyList;
    putPermissionsConfig(value: AwsCapacityProvider.PermissionsConfigProperty[] | cdktn.IResolvable): void;
    resetPermissionsConfig(): void;
    get permissionsConfigInput(): cdktn.IResolvable | AwsCapacityProvider.PermissionsConfigProperty[] | undefined;
    private _timeouts;
    get timeouts(): AwsCapacityProvider.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsCapacityProvider.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsCapacityProvider.TimeoutsProperty | undefined;
    private _vpcConfig;
    get vpcConfig(): AwsCapacityProvider.VpcConfigPropertyList;
    putVpcConfig(value: AwsCapacityProvider.VpcConfigProperty[] | cdktn.IResolvable): void;
    resetVpcConfig(): void;
    get vpcConfigInput(): cdktn.IResolvable | AwsCapacityProvider.VpcConfigProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsCapacityProviderScalingPoliciesPropertyToTerraform(struct?: AwsCapacityProvider.ScalingPoliciesProperty | cdktn.IResolvable): any;
export declare function awsCapacityProviderScalingPoliciesPropertyToHclTerraform(struct?: AwsCapacityProvider.ScalingPoliciesProperty | cdktn.IResolvable): any;
export declare function awsCapacityProviderCapacityProviderScalingConfigPropertyToTerraform(struct?: AwsCapacityProvider.CapacityProviderScalingConfigProperty | cdktn.IResolvable): any;
export declare function awsCapacityProviderCapacityProviderScalingConfigPropertyToHclTerraform(struct?: AwsCapacityProvider.CapacityProviderScalingConfigProperty | cdktn.IResolvable): any;
export declare function awsCapacityProviderInstanceRequirementsPropertyToTerraform(struct?: AwsCapacityProvider.InstanceRequirementsProperty | cdktn.IResolvable): any;
export declare function awsCapacityProviderInstanceRequirementsPropertyToHclTerraform(struct?: AwsCapacityProvider.InstanceRequirementsProperty | cdktn.IResolvable): any;
export declare function awsCapacityProviderPermissionsConfigPropertyToTerraform(struct?: AwsCapacityProvider.PermissionsConfigProperty | cdktn.IResolvable): any;
export declare function awsCapacityProviderPermissionsConfigPropertyToHclTerraform(struct?: AwsCapacityProvider.PermissionsConfigProperty | cdktn.IResolvable): any;
export declare function awsCapacityProviderTimeoutsPropertyToTerraform(struct?: AwsCapacityProvider.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsCapacityProviderTimeoutsPropertyToHclTerraform(struct?: AwsCapacityProvider.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsCapacityProviderVpcConfigPropertyToTerraform(struct?: AwsCapacityProvider.VpcConfigProperty | cdktn.IResolvable): any;
export declare function awsCapacityProviderVpcConfigPropertyToHclTerraform(struct?: AwsCapacityProvider.VpcConfigProperty | cdktn.IResolvable): any;
export declare namespace AwsCapacityProvider {
    interface ScalingPoliciesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_capacity_provider#predefined_metric_type AwsCapacityProvider#predefined_metric_type}
        */
        readonly predefinedMetricType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_capacity_provider#target_value AwsCapacityProvider#target_value}
        */
        readonly targetValue?: number;
    }
    class ScalingPoliciesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ScalingPoliciesProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ScalingPoliciesProperty | cdktn.IResolvable | undefined);
        private _predefinedMetricType?;
        get predefinedMetricType(): string;
        set predefinedMetricType(value: string);
        resetPredefinedMetricType(): void;
        get predefinedMetricTypeInput(): string | undefined;
        private _targetValue?;
        get targetValue(): number;
        set targetValue(value: number);
        resetTargetValue(): void;
        get targetValueInput(): number | undefined;
    }
    class ScalingPoliciesPropertyList extends cdktn.ComplexList {
        internalValue?: ScalingPoliciesProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ScalingPoliciesPropertyOutputReference;
    }
    interface CapacityProviderScalingConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_capacity_provider#max_vcpu_count AwsCapacityProvider#max_vcpu_count}
        */
        readonly maxVcpuCount?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_capacity_provider#scaling_mode AwsCapacityProvider#scaling_mode}
        */
        readonly scalingMode?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_capacity_provider#scaling_policies AwsCapacityProvider#scaling_policies}
        */
        readonly scalingPolicies?: ScalingPoliciesProperty[] | cdktn.IResolvable;
    }
    class CapacityProviderScalingConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CapacityProviderScalingConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CapacityProviderScalingConfigProperty | cdktn.IResolvable | undefined);
        private _maxVcpuCount?;
        get maxVcpuCount(): number;
        set maxVcpuCount(value: number);
        resetMaxVcpuCount(): void;
        get maxVcpuCountInput(): number | undefined;
        private _scalingMode?;
        get scalingMode(): string;
        set scalingMode(value: string);
        resetScalingMode(): void;
        get scalingModeInput(): string | undefined;
        private _scalingPolicies;
        get scalingPolicies(): ScalingPoliciesPropertyList;
        putScalingPolicies(value: ScalingPoliciesProperty[] | cdktn.IResolvable): void;
        resetScalingPolicies(): void;
        get scalingPoliciesInput(): cdktn.IResolvable | ScalingPoliciesProperty[] | undefined;
    }
    class CapacityProviderScalingConfigPropertyList extends cdktn.ComplexList {
        internalValue?: CapacityProviderScalingConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CapacityProviderScalingConfigPropertyOutputReference;
    }
    interface InstanceRequirementsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_capacity_provider#allowed_instance_types AwsCapacityProvider#allowed_instance_types}
        */
        readonly allowedInstanceTypes?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_capacity_provider#architectures AwsCapacityProvider#architectures}
        */
        readonly architectures?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_capacity_provider#excluded_instance_types AwsCapacityProvider#excluded_instance_types}
        */
        readonly excludedInstanceTypes?: string[];
    }
    class InstanceRequirementsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): InstanceRequirementsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: InstanceRequirementsProperty | cdktn.IResolvable | undefined);
        private _allowedInstanceTypes?;
        get allowedInstanceTypes(): string[];
        set allowedInstanceTypes(value: string[]);
        resetAllowedInstanceTypes(): void;
        get allowedInstanceTypesInput(): string[] | undefined;
        private _architectures?;
        get architectures(): string[];
        set architectures(value: string[]);
        resetArchitectures(): void;
        get architecturesInput(): string[] | undefined;
        private _excludedInstanceTypes?;
        get excludedInstanceTypes(): string[];
        set excludedInstanceTypes(value: string[]);
        resetExcludedInstanceTypes(): void;
        get excludedInstanceTypesInput(): string[] | undefined;
    }
    class InstanceRequirementsPropertyList extends cdktn.ComplexList {
        internalValue?: InstanceRequirementsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): InstanceRequirementsPropertyOutputReference;
    }
    interface PermissionsConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_capacity_provider#capacity_provider_operator_role_arn AwsCapacityProvider#capacity_provider_operator_role_arn}
        */
        readonly capacityProviderOperatorRoleArn: string;
    }
    class PermissionsConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): PermissionsConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: PermissionsConfigProperty | cdktn.IResolvable | undefined);
        private _capacityProviderOperatorRoleArn?;
        get capacityProviderOperatorRoleArn(): string;
        set capacityProviderOperatorRoleArn(value: string);
        get capacityProviderOperatorRoleArnInput(): string | undefined;
    }
    class PermissionsConfigPropertyList extends cdktn.ComplexList {
        internalValue?: PermissionsConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): PermissionsConfigPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_capacity_provider#create AwsCapacityProvider#create}
        */
        readonly create?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Setting a timeout for a Delete operation is only applicable if changes are saved into state before the destroy operation occurs.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_capacity_provider#delete AwsCapacityProvider#delete}
        */
        readonly delete?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_capacity_provider#update AwsCapacityProvider#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
    interface VpcConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_capacity_provider#security_group_ids AwsCapacityProvider#security_group_ids}
        */
        readonly securityGroupIds: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_capacity_provider#subnet_ids AwsCapacityProvider#subnet_ids}
        */
        readonly subnetIds: string[];
    }
    class VpcConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): VpcConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: VpcConfigProperty | cdktn.IResolvable | undefined);
        private _securityGroupIds?;
        get securityGroupIds(): string[];
        set securityGroupIds(value: string[]);
        get securityGroupIdsInput(): string[] | undefined;
        private _subnetIds?;
        get subnetIds(): string[];
        set subnetIds(value: string[]);
        get subnetIdsInput(): string[] | undefined;
    }
    class VpcConfigPropertyList extends cdktn.ComplexList {
        internalValue?: VpcConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): VpcConfigPropertyOutputReference;
    }
}
