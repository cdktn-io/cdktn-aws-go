import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsFunctionRecursionConfigConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function_recursion_config#function_name AwsFunctionRecursionConfig#function_name}
    */
    readonly functionName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function_recursion_config#recursive_loop AwsFunctionRecursionConfig#recursive_loop}
    */
    readonly recursiveLoop: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function_recursion_config#region AwsFunctionRecursionConfig#region}
    */
    readonly region?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function_recursion_config aws_lambda_function_recursion_config}
*/
export declare class AwsFunctionRecursionConfig extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_lambda_function_recursion_config";
    /**
    * Generates CDKTN code for importing a AwsFunctionRecursionConfig resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsFunctionRecursionConfig to import
    * @param importFromId The id of the existing AwsFunctionRecursionConfig that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function_recursion_config#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsFunctionRecursionConfig to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function_recursion_config aws_lambda_function_recursion_config} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsFunctionRecursionConfigConfig
    */
    constructor(scope: Construct, id: string, config: AwsFunctionRecursionConfigConfig);
    private _functionName?;
    get functionName(): string;
    set functionName(value: string);
    get functionNameInput(): string | undefined;
    private _recursiveLoop?;
    get recursiveLoop(): string;
    set recursiveLoop(value: string);
    get recursiveLoopInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
