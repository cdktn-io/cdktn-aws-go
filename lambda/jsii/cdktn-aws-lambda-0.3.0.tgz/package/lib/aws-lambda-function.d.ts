import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsFunctionConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function#architectures AwsFunction#architectures}
    */
    readonly architectures?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function#code_sha256 AwsFunction#code_sha256}
    */
    readonly codeSha256?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function#code_signing_config_arn AwsFunction#code_signing_config_arn}
    */
    readonly codeSigningConfigArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function#description AwsFunction#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function#filename AwsFunction#filename}
    */
    readonly filename?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function#function_name AwsFunction#function_name}
    */
    readonly functionName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function#handler AwsFunction#handler}
    */
    readonly handler?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function#id AwsFunction#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function#image_uri AwsFunction#image_uri}
    */
    readonly imageUri?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function#kms_key_arn AwsFunction#kms_key_arn}
    */
    readonly kmsKeyArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function#layers AwsFunction#layers}
    */
    readonly layers?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function#memory_size AwsFunction#memory_size}
    */
    readonly memorySize?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function#package_type AwsFunction#package_type}
    */
    readonly packageType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function#publish AwsFunction#publish}
    */
    readonly publish?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function#publish_to AwsFunction#publish_to}
    */
    readonly publishTo?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function#region AwsFunction#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function#replace_security_groups_on_destroy AwsFunction#replace_security_groups_on_destroy}
    */
    readonly replaceSecurityGroupsOnDestroy?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function#replacement_security_group_ids AwsFunction#replacement_security_group_ids}
    */
    readonly replacementSecurityGroupIds?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function#reserved_concurrent_executions AwsFunction#reserved_concurrent_executions}
    */
    readonly reservedConcurrentExecutions?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function#role AwsFunction#role}
    */
    readonly role: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function#runtime AwsFunction#runtime}
    */
    readonly runtime?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function#s3_bucket AwsFunction#s3_bucket}
    */
    readonly s3Bucket?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function#s3_key AwsFunction#s3_key}
    */
    readonly s3Key?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function#s3_object_version AwsFunction#s3_object_version}
    */
    readonly s3ObjectVersion?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function#skip_destroy AwsFunction#skip_destroy}
    */
    readonly skipDestroy?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function#source_code_hash AwsFunction#source_code_hash}
    */
    readonly sourceCodeHash?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function#source_kms_key_arn AwsFunction#source_kms_key_arn}
    */
    readonly sourceKmsKeyArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function#tags AwsFunction#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function#tags_all AwsFunction#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function#timeout AwsFunction#timeout}
    */
    readonly timeout?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function#use_resource_timeout_for_propagation AwsFunction#use_resource_timeout_for_propagation}
    */
    readonly useResourceTimeoutForPropagation?: boolean | cdktn.IResolvable;
    /**
    * capacity_provider_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function#capacity_provider_config AwsFunction#capacity_provider_config}
    */
    readonly capacityProviderConfig?: AwsFunction.CapacityProviderConfigProperty;
    /**
    * dead_letter_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function#dead_letter_config AwsFunction#dead_letter_config}
    */
    readonly deadLetterConfig?: AwsFunction.DeadLetterConfigProperty;
    /**
    * durable_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function#durable_config AwsFunction#durable_config}
    */
    readonly durableConfig?: AwsFunction.DurableConfigProperty;
    /**
    * environment block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function#environment AwsFunction#environment}
    */
    readonly environment?: AwsFunction.EnvironmentProperty;
    /**
    * ephemeral_storage block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function#ephemeral_storage AwsFunction#ephemeral_storage}
    */
    readonly ephemeralStorage?: AwsFunction.EphemeralStorageProperty;
    /**
    * file_system_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function#file_system_config AwsFunction#file_system_config}
    */
    readonly fileSystemConfig?: AwsFunction.FileSystemConfigProperty;
    /**
    * image_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function#image_config AwsFunction#image_config}
    */
    readonly imageConfig?: AwsFunction.ImageConfigProperty;
    /**
    * logging_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function#logging_config AwsFunction#logging_config}
    */
    readonly loggingConfig?: AwsFunction.LoggingConfigProperty;
    /**
    * snap_start block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function#snap_start AwsFunction#snap_start}
    */
    readonly snapStart?: AwsFunction.SnapStartProperty;
    /**
    * tenancy_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function#tenancy_config AwsFunction#tenancy_config}
    */
    readonly tenancyConfig?: AwsFunction.TenancyConfigProperty;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function#timeouts AwsFunction#timeouts}
    */
    readonly timeouts?: AwsFunction.TimeoutsProperty;
    /**
    * tracing_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function#tracing_config AwsFunction#tracing_config}
    */
    readonly tracingConfig?: AwsFunction.TracingConfigProperty;
    /**
    * vpc_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function#vpc_config AwsFunction#vpc_config}
    */
    readonly vpcConfig?: AwsFunction.VpcConfigProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function aws_lambda_function}
*/
export declare class AwsFunction extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_lambda_function";
    /**
    * Generates CDKTN code for importing a AwsFunction resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsFunction to import
    * @param importFromId The id of the existing AwsFunction that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsFunction to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function aws_lambda_function} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsFunctionConfig
    */
    constructor(scope: Construct, id: string, config: AwsFunctionConfig);
    private _architectures?;
    get architectures(): string[];
    set architectures(value: string[]);
    resetArchitectures(): void;
    get architecturesInput(): string[] | undefined;
    get arn(): string;
    private _codeSha256?;
    get codeSha256(): string;
    set codeSha256(value: string);
    resetCodeSha256(): void;
    get codeSha256Input(): string | undefined;
    private _codeSigningConfigArn?;
    get codeSigningConfigArn(): string;
    set codeSigningConfigArn(value: string);
    resetCodeSigningConfigArn(): void;
    get codeSigningConfigArnInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _filename?;
    get filename(): string;
    set filename(value: string);
    resetFilename(): void;
    get filenameInput(): string | undefined;
    private _functionName?;
    get functionName(): string;
    set functionName(value: string);
    get functionNameInput(): string | undefined;
    private _handler?;
    get handler(): string;
    set handler(value: string);
    resetHandler(): void;
    get handlerInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _imageUri?;
    get imageUri(): string;
    set imageUri(value: string);
    resetImageUri(): void;
    get imageUriInput(): string | undefined;
    get invokeArn(): string;
    private _kmsKeyArn?;
    get kmsKeyArn(): string;
    set kmsKeyArn(value: string);
    resetKmsKeyArn(): void;
    get kmsKeyArnInput(): string | undefined;
    get lastModified(): string;
    private _layers?;
    get layers(): string[];
    set layers(value: string[]);
    resetLayers(): void;
    get layersInput(): string[] | undefined;
    private _memorySize?;
    get memorySize(): number;
    set memorySize(value: number);
    resetMemorySize(): void;
    get memorySizeInput(): number | undefined;
    private _packageType?;
    get packageType(): string;
    set packageType(value: string);
    resetPackageType(): void;
    get packageTypeInput(): string | undefined;
    private _publish?;
    get publish(): boolean | cdktn.IResolvable;
    set publish(value: boolean | cdktn.IResolvable);
    resetPublish(): void;
    get publishInput(): boolean | cdktn.IResolvable | undefined;
    private _publishTo?;
    get publishTo(): string;
    set publishTo(value: string);
    resetPublishTo(): void;
    get publishToInput(): string | undefined;
    get qualifiedArn(): string;
    get qualifiedInvokeArn(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _replaceSecurityGroupsOnDestroy?;
    get replaceSecurityGroupsOnDestroy(): boolean | cdktn.IResolvable;
    set replaceSecurityGroupsOnDestroy(value: boolean | cdktn.IResolvable);
    resetReplaceSecurityGroupsOnDestroy(): void;
    get replaceSecurityGroupsOnDestroyInput(): boolean | cdktn.IResolvable | undefined;
    private _replacementSecurityGroupIds?;
    get replacementSecurityGroupIds(): string[];
    set replacementSecurityGroupIds(value: string[]);
    resetReplacementSecurityGroupIds(): void;
    get replacementSecurityGroupIdsInput(): string[] | undefined;
    private _reservedConcurrentExecutions?;
    get reservedConcurrentExecutions(): number;
    set reservedConcurrentExecutions(value: number);
    resetReservedConcurrentExecutions(): void;
    get reservedConcurrentExecutionsInput(): number | undefined;
    get responseStreamingInvokeArn(): string;
    private _role?;
    get role(): string;
    set role(value: string);
    get roleInput(): string | undefined;
    private _runtime?;
    get runtime(): string;
    set runtime(value: string);
    resetRuntime(): void;
    get runtimeInput(): string | undefined;
    private _s3Bucket?;
    get s3Bucket(): string;
    set s3Bucket(value: string);
    resetS3Bucket(): void;
    get s3BucketInput(): string | undefined;
    private _s3Key?;
    get s3Key(): string;
    set s3Key(value: string);
    resetS3Key(): void;
    get s3KeyInput(): string | undefined;
    private _s3ObjectVersion?;
    get s3ObjectVersion(): string;
    set s3ObjectVersion(value: string);
    resetS3ObjectVersion(): void;
    get s3ObjectVersionInput(): string | undefined;
    get signingJobArn(): string;
    get signingProfileVersionArn(): string;
    private _skipDestroy?;
    get skipDestroy(): boolean | cdktn.IResolvable;
    set skipDestroy(value: boolean | cdktn.IResolvable);
    resetSkipDestroy(): void;
    get skipDestroyInput(): boolean | cdktn.IResolvable | undefined;
    private _sourceCodeHash?;
    get sourceCodeHash(): string;
    set sourceCodeHash(value: string);
    resetSourceCodeHash(): void;
    get sourceCodeHashInput(): string | undefined;
    get sourceCodeSize(): number;
    private _sourceKmsKeyArn?;
    get sourceKmsKeyArn(): string;
    set sourceKmsKeyArn(value: string);
    resetSourceKmsKeyArn(): void;
    get sourceKmsKeyArnInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _timeout?;
    get timeout(): number;
    set timeout(value: number);
    resetTimeout(): void;
    get timeoutInput(): number | undefined;
    private _useResourceTimeoutForPropagation?;
    get useResourceTimeoutForPropagation(): boolean | cdktn.IResolvable;
    set useResourceTimeoutForPropagation(value: boolean | cdktn.IResolvable);
    resetUseResourceTimeoutForPropagation(): void;
    get useResourceTimeoutForPropagationInput(): boolean | cdktn.IResolvable | undefined;
    get version(): string;
    private _capacityProviderConfig;
    get capacityProviderConfig(): AwsFunction.CapacityProviderConfigPropertyOutputReference;
    putCapacityProviderConfig(value: AwsFunction.CapacityProviderConfigProperty): void;
    resetCapacityProviderConfig(): void;
    get capacityProviderConfigInput(): AwsFunction.CapacityProviderConfigProperty | undefined;
    private _deadLetterConfig;
    get deadLetterConfig(): AwsFunction.DeadLetterConfigPropertyOutputReference;
    putDeadLetterConfig(value: AwsFunction.DeadLetterConfigProperty): void;
    resetDeadLetterConfig(): void;
    get deadLetterConfigInput(): AwsFunction.DeadLetterConfigProperty | undefined;
    private _durableConfig;
    get durableConfig(): AwsFunction.DurableConfigPropertyOutputReference;
    putDurableConfig(value: AwsFunction.DurableConfigProperty): void;
    resetDurableConfig(): void;
    get durableConfigInput(): AwsFunction.DurableConfigProperty | undefined;
    private _environment;
    get environment(): AwsFunction.EnvironmentPropertyOutputReference;
    putEnvironment(value: AwsFunction.EnvironmentProperty): void;
    resetEnvironment(): void;
    get environmentInput(): AwsFunction.EnvironmentProperty | undefined;
    private _ephemeralStorage;
    get ephemeralStorage(): AwsFunction.EphemeralStoragePropertyOutputReference;
    putEphemeralStorage(value: AwsFunction.EphemeralStorageProperty): void;
    resetEphemeralStorage(): void;
    get ephemeralStorageInput(): AwsFunction.EphemeralStorageProperty | undefined;
    private _fileSystemConfig;
    get fileSystemConfig(): AwsFunction.FileSystemConfigPropertyOutputReference;
    putFileSystemConfig(value: AwsFunction.FileSystemConfigProperty): void;
    resetFileSystemConfig(): void;
    get fileSystemConfigInput(): AwsFunction.FileSystemConfigProperty | undefined;
    private _imageConfig;
    get imageConfig(): AwsFunction.ImageConfigPropertyOutputReference;
    putImageConfig(value: AwsFunction.ImageConfigProperty): void;
    resetImageConfig(): void;
    get imageConfigInput(): AwsFunction.ImageConfigProperty | undefined;
    private _loggingConfig;
    get loggingConfig(): AwsFunction.LoggingConfigPropertyOutputReference;
    putLoggingConfig(value: AwsFunction.LoggingConfigProperty): void;
    resetLoggingConfig(): void;
    get loggingConfigInput(): AwsFunction.LoggingConfigProperty | undefined;
    private _snapStart;
    get snapStart(): AwsFunction.SnapStartPropertyOutputReference;
    putSnapStart(value: AwsFunction.SnapStartProperty): void;
    resetSnapStart(): void;
    get snapStartInput(): AwsFunction.SnapStartProperty | undefined;
    private _tenancyConfig;
    get tenancyConfig(): AwsFunction.TenancyConfigPropertyOutputReference;
    putTenancyConfig(value: AwsFunction.TenancyConfigProperty): void;
    resetTenancyConfig(): void;
    get tenancyConfigInput(): AwsFunction.TenancyConfigProperty | undefined;
    private _timeouts;
    get timeouts(): AwsFunction.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsFunction.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsFunction.TimeoutsProperty | undefined;
    private _tracingConfig;
    get tracingConfig(): AwsFunction.TracingConfigPropertyOutputReference;
    putTracingConfig(value: AwsFunction.TracingConfigProperty): void;
    resetTracingConfig(): void;
    get tracingConfigInput(): AwsFunction.TracingConfigProperty | undefined;
    private _vpcConfig;
    get vpcConfig(): AwsFunction.VpcConfigPropertyOutputReference;
    putVpcConfig(value: AwsFunction.VpcConfigProperty): void;
    resetVpcConfig(): void;
    get vpcConfigInput(): AwsFunction.VpcConfigProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsFunctionLambdaManagedInstancesCapacityProviderConfigPropertyToTerraform(struct?: AwsFunction.LambdaManagedInstancesCapacityProviderConfigPropertyOutputReference | AwsFunction.LambdaManagedInstancesCapacityProviderConfigProperty): any;
export declare function awsFunctionLambdaManagedInstancesCapacityProviderConfigPropertyToHclTerraform(struct?: AwsFunction.LambdaManagedInstancesCapacityProviderConfigPropertyOutputReference | AwsFunction.LambdaManagedInstancesCapacityProviderConfigProperty): any;
export declare function awsFunctionCapacityProviderConfigPropertyToTerraform(struct?: AwsFunction.CapacityProviderConfigPropertyOutputReference | AwsFunction.CapacityProviderConfigProperty): any;
export declare function awsFunctionCapacityProviderConfigPropertyToHclTerraform(struct?: AwsFunction.CapacityProviderConfigPropertyOutputReference | AwsFunction.CapacityProviderConfigProperty): any;
export declare function awsFunctionDeadLetterConfigPropertyToTerraform(struct?: AwsFunction.DeadLetterConfigPropertyOutputReference | AwsFunction.DeadLetterConfigProperty): any;
export declare function awsFunctionDeadLetterConfigPropertyToHclTerraform(struct?: AwsFunction.DeadLetterConfigPropertyOutputReference | AwsFunction.DeadLetterConfigProperty): any;
export declare function awsFunctionDurableConfigPropertyToTerraform(struct?: AwsFunction.DurableConfigPropertyOutputReference | AwsFunction.DurableConfigProperty): any;
export declare function awsFunctionDurableConfigPropertyToHclTerraform(struct?: AwsFunction.DurableConfigPropertyOutputReference | AwsFunction.DurableConfigProperty): any;
export declare function awsFunctionEnvironmentPropertyToTerraform(struct?: AwsFunction.EnvironmentPropertyOutputReference | AwsFunction.EnvironmentProperty): any;
export declare function awsFunctionEnvironmentPropertyToHclTerraform(struct?: AwsFunction.EnvironmentPropertyOutputReference | AwsFunction.EnvironmentProperty): any;
export declare function awsFunctionEphemeralStoragePropertyToTerraform(struct?: AwsFunction.EphemeralStoragePropertyOutputReference | AwsFunction.EphemeralStorageProperty): any;
export declare function awsFunctionEphemeralStoragePropertyToHclTerraform(struct?: AwsFunction.EphemeralStoragePropertyOutputReference | AwsFunction.EphemeralStorageProperty): any;
export declare function awsFunctionFileSystemConfigPropertyToTerraform(struct?: AwsFunction.FileSystemConfigPropertyOutputReference | AwsFunction.FileSystemConfigProperty): any;
export declare function awsFunctionFileSystemConfigPropertyToHclTerraform(struct?: AwsFunction.FileSystemConfigPropertyOutputReference | AwsFunction.FileSystemConfigProperty): any;
export declare function awsFunctionImageConfigPropertyToTerraform(struct?: AwsFunction.ImageConfigPropertyOutputReference | AwsFunction.ImageConfigProperty): any;
export declare function awsFunctionImageConfigPropertyToHclTerraform(struct?: AwsFunction.ImageConfigPropertyOutputReference | AwsFunction.ImageConfigProperty): any;
export declare function awsFunctionLoggingConfigPropertyToTerraform(struct?: AwsFunction.LoggingConfigPropertyOutputReference | AwsFunction.LoggingConfigProperty): any;
export declare function awsFunctionLoggingConfigPropertyToHclTerraform(struct?: AwsFunction.LoggingConfigPropertyOutputReference | AwsFunction.LoggingConfigProperty): any;
export declare function awsFunctionSnapStartPropertyToTerraform(struct?: AwsFunction.SnapStartPropertyOutputReference | AwsFunction.SnapStartProperty): any;
export declare function awsFunctionSnapStartPropertyToHclTerraform(struct?: AwsFunction.SnapStartPropertyOutputReference | AwsFunction.SnapStartProperty): any;
export declare function awsFunctionTenancyConfigPropertyToTerraform(struct?: AwsFunction.TenancyConfigPropertyOutputReference | AwsFunction.TenancyConfigProperty): any;
export declare function awsFunctionTenancyConfigPropertyToHclTerraform(struct?: AwsFunction.TenancyConfigPropertyOutputReference | AwsFunction.TenancyConfigProperty): any;
export declare function awsFunctionTimeoutsPropertyToTerraform(struct?: AwsFunction.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsFunctionTimeoutsPropertyToHclTerraform(struct?: AwsFunction.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsFunctionTracingConfigPropertyToTerraform(struct?: AwsFunction.TracingConfigPropertyOutputReference | AwsFunction.TracingConfigProperty): any;
export declare function awsFunctionTracingConfigPropertyToHclTerraform(struct?: AwsFunction.TracingConfigPropertyOutputReference | AwsFunction.TracingConfigProperty): any;
export declare function awsFunctionVpcConfigPropertyToTerraform(struct?: AwsFunction.VpcConfigPropertyOutputReference | AwsFunction.VpcConfigProperty): any;
export declare function awsFunctionVpcConfigPropertyToHclTerraform(struct?: AwsFunction.VpcConfigPropertyOutputReference | AwsFunction.VpcConfigProperty): any;
export declare namespace AwsFunction {
    interface LambdaManagedInstancesCapacityProviderConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function#capacity_provider_arn AwsFunction#capacity_provider_arn}
        */
        readonly capacityProviderArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function#execution_environment_memory_gib_per_vcpu AwsFunction#execution_environment_memory_gib_per_vcpu}
        */
        readonly executionEnvironmentMemoryGibPerVcpu?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function#per_execution_environment_max_concurrency AwsFunction#per_execution_environment_max_concurrency}
        */
        readonly perExecutionEnvironmentMaxConcurrency?: number;
    }
    class LambdaManagedInstancesCapacityProviderConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): LambdaManagedInstancesCapacityProviderConfigProperty | undefined;
        set internalValue(value: LambdaManagedInstancesCapacityProviderConfigProperty | undefined);
        private _capacityProviderArn?;
        get capacityProviderArn(): string;
        set capacityProviderArn(value: string);
        get capacityProviderArnInput(): string | undefined;
        private _executionEnvironmentMemoryGibPerVcpu?;
        get executionEnvironmentMemoryGibPerVcpu(): number;
        set executionEnvironmentMemoryGibPerVcpu(value: number);
        resetExecutionEnvironmentMemoryGibPerVcpu(): void;
        get executionEnvironmentMemoryGibPerVcpuInput(): number | undefined;
        private _perExecutionEnvironmentMaxConcurrency?;
        get perExecutionEnvironmentMaxConcurrency(): number;
        set perExecutionEnvironmentMaxConcurrency(value: number);
        resetPerExecutionEnvironmentMaxConcurrency(): void;
        get perExecutionEnvironmentMaxConcurrencyInput(): number | undefined;
    }
    interface CapacityProviderConfigProperty {
        /**
        * lambda_managed_instances_capacity_provider_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function#lambda_managed_instances_capacity_provider_config AwsFunction#lambda_managed_instances_capacity_provider_config}
        */
        readonly lambdaManagedInstancesCapacityProviderConfig: LambdaManagedInstancesCapacityProviderConfigProperty;
    }
    class CapacityProviderConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CapacityProviderConfigProperty | undefined;
        set internalValue(value: CapacityProviderConfigProperty | undefined);
        private _lambdaManagedInstancesCapacityProviderConfig;
        get lambdaManagedInstancesCapacityProviderConfig(): LambdaManagedInstancesCapacityProviderConfigPropertyOutputReference;
        putLambdaManagedInstancesCapacityProviderConfig(value: LambdaManagedInstancesCapacityProviderConfigProperty): void;
        get lambdaManagedInstancesCapacityProviderConfigInput(): LambdaManagedInstancesCapacityProviderConfigProperty | undefined;
    }
    interface DeadLetterConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function#target_arn AwsFunction#target_arn}
        */
        readonly targetArn: string;
    }
    class DeadLetterConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DeadLetterConfigProperty | undefined;
        set internalValue(value: DeadLetterConfigProperty | undefined);
        private _targetArn?;
        get targetArn(): string;
        set targetArn(value: string);
        get targetArnInput(): string | undefined;
    }
    interface DurableConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function#execution_timeout AwsFunction#execution_timeout}
        */
        readonly executionTimeout: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function#retention_period AwsFunction#retention_period}
        */
        readonly retentionPeriod?: number;
    }
    class DurableConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DurableConfigProperty | undefined;
        set internalValue(value: DurableConfigProperty | undefined);
        private _executionTimeout?;
        get executionTimeout(): number;
        set executionTimeout(value: number);
        get executionTimeoutInput(): number | undefined;
        private _retentionPeriod?;
        get retentionPeriod(): number;
        set retentionPeriod(value: number);
        resetRetentionPeriod(): void;
        get retentionPeriodInput(): number | undefined;
    }
    interface EnvironmentProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function#variables AwsFunction#variables}
        */
        readonly variables?: {
            [key: string]: string;
        };
    }
    class EnvironmentPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): EnvironmentProperty | undefined;
        set internalValue(value: EnvironmentProperty | undefined);
        private _variables?;
        get variables(): {
            [key: string]: string;
        };
        set variables(value: {
            [key: string]: string;
        });
        resetVariables(): void;
        get variablesInput(): {
            [key: string]: string;
        } | undefined;
    }
    interface EphemeralStorageProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function#size AwsFunction#size}
        */
        readonly size?: number;
    }
    class EphemeralStoragePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): EphemeralStorageProperty | undefined;
        set internalValue(value: EphemeralStorageProperty | undefined);
        private _size?;
        get size(): number;
        set size(value: number);
        resetSize(): void;
        get sizeInput(): number | undefined;
    }
    interface FileSystemConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function#arn AwsFunction#arn}
        */
        readonly arn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function#local_mount_path AwsFunction#local_mount_path}
        */
        readonly localMountPath: string;
    }
    class FileSystemConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): FileSystemConfigProperty | undefined;
        set internalValue(value: FileSystemConfigProperty | undefined);
        private _arn?;
        get arn(): string;
        set arn(value: string);
        get arnInput(): string | undefined;
        private _localMountPath?;
        get localMountPath(): string;
        set localMountPath(value: string);
        get localMountPathInput(): string | undefined;
    }
    interface ImageConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function#command AwsFunction#command}
        */
        readonly command?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function#entry_point AwsFunction#entry_point}
        */
        readonly entryPoint?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function#working_directory AwsFunction#working_directory}
        */
        readonly workingDirectory?: string;
    }
    class ImageConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ImageConfigProperty | undefined;
        set internalValue(value: ImageConfigProperty | undefined);
        private _command?;
        get command(): string[];
        set command(value: string[]);
        resetCommand(): void;
        get commandInput(): string[] | undefined;
        private _entryPoint?;
        get entryPoint(): string[];
        set entryPoint(value: string[]);
        resetEntryPoint(): void;
        get entryPointInput(): string[] | undefined;
        private _workingDirectory?;
        get workingDirectory(): string;
        set workingDirectory(value: string);
        resetWorkingDirectory(): void;
        get workingDirectoryInput(): string | undefined;
    }
    interface LoggingConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function#application_log_level AwsFunction#application_log_level}
        */
        readonly applicationLogLevel?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function#log_format AwsFunction#log_format}
        */
        readonly logFormat: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function#log_group AwsFunction#log_group}
        */
        readonly logGroup?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function#system_log_level AwsFunction#system_log_level}
        */
        readonly systemLogLevel?: string;
    }
    class LoggingConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): LoggingConfigProperty | undefined;
        set internalValue(value: LoggingConfigProperty | undefined);
        private _applicationLogLevel?;
        get applicationLogLevel(): string;
        set applicationLogLevel(value: string);
        resetApplicationLogLevel(): void;
        get applicationLogLevelInput(): string | undefined;
        private _logFormat?;
        get logFormat(): string;
        set logFormat(value: string);
        get logFormatInput(): string | undefined;
        private _logGroup?;
        get logGroup(): string;
        set logGroup(value: string);
        resetLogGroup(): void;
        get logGroupInput(): string | undefined;
        private _systemLogLevel?;
        get systemLogLevel(): string;
        set systemLogLevel(value: string);
        resetSystemLogLevel(): void;
        get systemLogLevelInput(): string | undefined;
    }
    interface SnapStartProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function#apply_on AwsFunction#apply_on}
        */
        readonly applyOn: string;
    }
    class SnapStartPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SnapStartProperty | undefined;
        set internalValue(value: SnapStartProperty | undefined);
        private _applyOn?;
        get applyOn(): string;
        set applyOn(value: string);
        get applyOnInput(): string | undefined;
        get optimizationStatus(): string;
    }
    interface TenancyConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function#tenant_isolation_mode AwsFunction#tenant_isolation_mode}
        */
        readonly tenantIsolationMode: string;
    }
    class TenancyConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TenancyConfigProperty | undefined;
        set internalValue(value: TenancyConfigProperty | undefined);
        private _tenantIsolationMode?;
        get tenantIsolationMode(): string;
        set tenantIsolationMode(value: string);
        get tenantIsolationModeInput(): string | undefined;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function#create AwsFunction#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function#delete AwsFunction#delete}
        */
        readonly delete?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function#update AwsFunction#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
    interface TracingConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function#mode AwsFunction#mode}
        */
        readonly mode: string;
    }
    class TracingConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TracingConfigProperty | undefined;
        set internalValue(value: TracingConfigProperty | undefined);
        private _mode?;
        get mode(): string;
        set mode(value: string);
        get modeInput(): string | undefined;
    }
    interface VpcConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function#ipv6_allowed_for_dual_stack AwsFunction#ipv6_allowed_for_dual_stack}
        */
        readonly ipv6AllowedForDualStack?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function#security_group_ids AwsFunction#security_group_ids}
        */
        readonly securityGroupIds: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function#subnet_ids AwsFunction#subnet_ids}
        */
        readonly subnetIds: string[];
    }
    class VpcConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): VpcConfigProperty | undefined;
        set internalValue(value: VpcConfigProperty | undefined);
        private _ipv6AllowedForDualStack?;
        get ipv6AllowedForDualStack(): boolean | cdktn.IResolvable;
        set ipv6AllowedForDualStack(value: boolean | cdktn.IResolvable);
        resetIpv6AllowedForDualStack(): void;
        get ipv6AllowedForDualStackInput(): boolean | cdktn.IResolvable | undefined;
        private _securityGroupIds?;
        get securityGroupIds(): string[];
        set securityGroupIds(value: string[]);
        get securityGroupIdsInput(): string[] | undefined;
        private _subnetIds?;
        get subnetIds(): string[];
        set subnetIds(value: string[]);
        get subnetIdsInput(): string[] | undefined;
        get vpcId(): string;
    }
}
