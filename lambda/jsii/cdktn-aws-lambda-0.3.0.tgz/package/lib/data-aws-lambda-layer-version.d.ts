import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsLayerVersionConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lambda_layer_version#compatible_architecture DataAwsLayerVersion#compatible_architecture}
    */
    readonly compatibleArchitecture?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lambda_layer_version#compatible_runtime DataAwsLayerVersion#compatible_runtime}
    */
    readonly compatibleRuntime?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lambda_layer_version#id DataAwsLayerVersion#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lambda_layer_version#layer_name DataAwsLayerVersion#layer_name}
    */
    readonly layerName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lambda_layer_version#layer_version_arn DataAwsLayerVersion#layer_version_arn}
    */
    readonly layerVersionArn?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lambda_layer_version#region DataAwsLayerVersion#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lambda_layer_version#version DataAwsLayerVersion#version}
    */
    readonly version?: number;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lambda_layer_version aws_lambda_layer_version}
*/
export declare class DataAwsLayerVersion extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_lambda_layer_version";
    /**
    * Generates CDKTN code for importing a DataAwsLayerVersion resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsLayerVersion to import
    * @param importFromId The id of the existing DataAwsLayerVersion that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lambda_layer_version#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsLayerVersion to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lambda_layer_version aws_lambda_layer_version} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsLayerVersionConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataAwsLayerVersionConfig);
    get arn(): string;
    get codeSha256(): string;
    private _compatibleArchitecture?;
    get compatibleArchitecture(): string;
    set compatibleArchitecture(value: string);
    resetCompatibleArchitecture(): void;
    get compatibleArchitectureInput(): string | undefined;
    get compatibleArchitectures(): string[];
    private _compatibleRuntime?;
    get compatibleRuntime(): string;
    set compatibleRuntime(value: string);
    resetCompatibleRuntime(): void;
    get compatibleRuntimeInput(): string | undefined;
    get compatibleRuntimes(): string[];
    get createdDate(): string;
    get description(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get layerArn(): string;
    private _layerName?;
    get layerName(): string;
    set layerName(value: string);
    resetLayerName(): void;
    get layerNameInput(): string | undefined;
    private _layerVersionArn?;
    get layerVersionArn(): string;
    set layerVersionArn(value: string);
    resetLayerVersionArn(): void;
    get layerVersionArnInput(): string | undefined;
    get licenseInfo(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get signingJobArn(): string;
    get signingProfileVersionArn(): string;
    get sourceCodeHash(): string;
    get sourceCodeSize(): number;
    private _version?;
    get version(): number;
    set version(value: number);
    resetVersion(): void;
    get versionInput(): number | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
