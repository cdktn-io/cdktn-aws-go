import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsEventSourceMappingConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_event_source_mapping#batch_size AwsEventSourceMapping#batch_size}
    */
    readonly batchSize?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_event_source_mapping#bisect_batch_on_function_error AwsEventSourceMapping#bisect_batch_on_function_error}
    */
    readonly bisectBatchOnFunctionError?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_event_source_mapping#enabled AwsEventSourceMapping#enabled}
    */
    readonly enabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_event_source_mapping#event_source_arn AwsEventSourceMapping#event_source_arn}
    */
    readonly eventSourceArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_event_source_mapping#function_name AwsEventSourceMapping#function_name}
    */
    readonly functionName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_event_source_mapping#function_response_types AwsEventSourceMapping#function_response_types}
    */
    readonly functionResponseTypes?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_event_source_mapping#id AwsEventSourceMapping#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_event_source_mapping#kms_key_arn AwsEventSourceMapping#kms_key_arn}
    */
    readonly kmsKeyArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_event_source_mapping#maximum_batching_window_in_seconds AwsEventSourceMapping#maximum_batching_window_in_seconds}
    */
    readonly maximumBatchingWindowInSeconds?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_event_source_mapping#maximum_record_age_in_seconds AwsEventSourceMapping#maximum_record_age_in_seconds}
    */
    readonly maximumRecordAgeInSeconds?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_event_source_mapping#maximum_retry_attempts AwsEventSourceMapping#maximum_retry_attempts}
    */
    readonly maximumRetryAttempts?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_event_source_mapping#parallelization_factor AwsEventSourceMapping#parallelization_factor}
    */
    readonly parallelizationFactor?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_event_source_mapping#queues AwsEventSourceMapping#queues}
    */
    readonly queues?: string[];
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_event_source_mapping#region AwsEventSourceMapping#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_event_source_mapping#starting_position AwsEventSourceMapping#starting_position}
    */
    readonly startingPosition?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_event_source_mapping#starting_position_timestamp AwsEventSourceMapping#starting_position_timestamp}
    */
    readonly startingPositionTimestamp?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_event_source_mapping#tags AwsEventSourceMapping#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_event_source_mapping#tags_all AwsEventSourceMapping#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_event_source_mapping#topics AwsEventSourceMapping#topics}
    */
    readonly topics?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_event_source_mapping#tumbling_window_in_seconds AwsEventSourceMapping#tumbling_window_in_seconds}
    */
    readonly tumblingWindowInSeconds?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_event_source_mapping#use_resource_timeout_for_propagation AwsEventSourceMapping#use_resource_timeout_for_propagation}
    */
    readonly useResourceTimeoutForPropagation?: boolean | cdktn.IResolvable;
    /**
    * amazon_managed_kafka_event_source_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_event_source_mapping#amazon_managed_kafka_event_source_config AwsEventSourceMapping#amazon_managed_kafka_event_source_config}
    */
    readonly amazonManagedKafkaEventSourceConfig?: AwsEventSourceMapping.AmazonManagedKafkaEventSourceConfigProperty;
    /**
    * destination_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_event_source_mapping#destination_config AwsEventSourceMapping#destination_config}
    */
    readonly destinationConfig?: AwsEventSourceMapping.DestinationConfigProperty;
    /**
    * document_db_event_source_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_event_source_mapping#document_db_event_source_config AwsEventSourceMapping#document_db_event_source_config}
    */
    readonly documentDbEventSourceConfig?: AwsEventSourceMapping.DocumentDbEventSourceConfigProperty;
    /**
    * filter_criteria block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_event_source_mapping#filter_criteria AwsEventSourceMapping#filter_criteria}
    */
    readonly filterCriteria?: AwsEventSourceMapping.FilterCriteriaProperty;
    /**
    * metrics_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_event_source_mapping#metrics_config AwsEventSourceMapping#metrics_config}
    */
    readonly metricsConfig?: AwsEventSourceMapping.MetricsConfigProperty;
    /**
    * provisioned_poller_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_event_source_mapping#provisioned_poller_config AwsEventSourceMapping#provisioned_poller_config}
    */
    readonly provisionedPollerConfig?: AwsEventSourceMapping.ProvisionedPollerConfigProperty;
    /**
    * scaling_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_event_source_mapping#scaling_config AwsEventSourceMapping#scaling_config}
    */
    readonly scalingConfig?: AwsEventSourceMapping.ScalingConfigProperty;
    /**
    * self_managed_event_source block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_event_source_mapping#self_managed_event_source AwsEventSourceMapping#self_managed_event_source}
    */
    readonly selfManagedEventSource?: AwsEventSourceMapping.SelfManagedEventSourceProperty;
    /**
    * self_managed_kafka_event_source_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_event_source_mapping#self_managed_kafka_event_source_config AwsEventSourceMapping#self_managed_kafka_event_source_config}
    */
    readonly selfManagedKafkaEventSourceConfig?: AwsEventSourceMapping.SelfManagedKafkaEventSourceConfigProperty;
    /**
    * source_access_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_event_source_mapping#source_access_configuration AwsEventSourceMapping#source_access_configuration}
    */
    readonly sourceAccessConfiguration?: AwsEventSourceMapping.SourceAccessConfigurationProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_event_source_mapping#timeouts AwsEventSourceMapping#timeouts}
    */
    readonly timeouts?: AwsEventSourceMapping.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_event_source_mapping aws_lambda_event_source_mapping}
*/
export declare class AwsEventSourceMapping extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_lambda_event_source_mapping";
    /**
    * Generates CDKTN code for importing a AwsEventSourceMapping resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsEventSourceMapping to import
    * @param importFromId The id of the existing AwsEventSourceMapping that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_event_source_mapping#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsEventSourceMapping to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_event_source_mapping aws_lambda_event_source_mapping} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsEventSourceMappingConfig
    */
    constructor(scope: Construct, id: string, config: AwsEventSourceMappingConfig);
    get arn(): string;
    private _batchSize?;
    get batchSize(): number;
    set batchSize(value: number);
    resetBatchSize(): void;
    get batchSizeInput(): number | undefined;
    private _bisectBatchOnFunctionError?;
    get bisectBatchOnFunctionError(): boolean | cdktn.IResolvable;
    set bisectBatchOnFunctionError(value: boolean | cdktn.IResolvable);
    resetBisectBatchOnFunctionError(): void;
    get bisectBatchOnFunctionErrorInput(): boolean | cdktn.IResolvable | undefined;
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    private _eventSourceArn?;
    get eventSourceArn(): string;
    set eventSourceArn(value: string);
    resetEventSourceArn(): void;
    get eventSourceArnInput(): string | undefined;
    get functionArn(): string;
    private _functionName?;
    get functionName(): string;
    set functionName(value: string);
    get functionNameInput(): string | undefined;
    private _functionResponseTypes?;
    get functionResponseTypes(): string[];
    set functionResponseTypes(value: string[]);
    resetFunctionResponseTypes(): void;
    get functionResponseTypesInput(): string[] | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _kmsKeyArn?;
    get kmsKeyArn(): string;
    set kmsKeyArn(value: string);
    resetKmsKeyArn(): void;
    get kmsKeyArnInput(): string | undefined;
    get lastModified(): string;
    get lastProcessingResult(): string;
    private _maximumBatchingWindowInSeconds?;
    get maximumBatchingWindowInSeconds(): number;
    set maximumBatchingWindowInSeconds(value: number);
    resetMaximumBatchingWindowInSeconds(): void;
    get maximumBatchingWindowInSecondsInput(): number | undefined;
    private _maximumRecordAgeInSeconds?;
    get maximumRecordAgeInSeconds(): number;
    set maximumRecordAgeInSeconds(value: number);
    resetMaximumRecordAgeInSeconds(): void;
    get maximumRecordAgeInSecondsInput(): number | undefined;
    private _maximumRetryAttempts?;
    get maximumRetryAttempts(): number;
    set maximumRetryAttempts(value: number);
    resetMaximumRetryAttempts(): void;
    get maximumRetryAttemptsInput(): number | undefined;
    private _parallelizationFactor?;
    get parallelizationFactor(): number;
    set parallelizationFactor(value: number);
    resetParallelizationFactor(): void;
    get parallelizationFactorInput(): number | undefined;
    private _queues?;
    get queues(): string[];
    set queues(value: string[]);
    resetQueues(): void;
    get queuesInput(): string[] | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _startingPosition?;
    get startingPosition(): string;
    set startingPosition(value: string);
    resetStartingPosition(): void;
    get startingPositionInput(): string | undefined;
    private _startingPositionTimestamp?;
    get startingPositionTimestamp(): string;
    set startingPositionTimestamp(value: string);
    resetStartingPositionTimestamp(): void;
    get startingPositionTimestampInput(): string | undefined;
    get state(): string;
    get stateTransitionReason(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _topics?;
    get topics(): string[];
    set topics(value: string[]);
    resetTopics(): void;
    get topicsInput(): string[] | undefined;
    private _tumblingWindowInSeconds?;
    get tumblingWindowInSeconds(): number;
    set tumblingWindowInSeconds(value: number);
    resetTumblingWindowInSeconds(): void;
    get tumblingWindowInSecondsInput(): number | undefined;
    private _useResourceTimeoutForPropagation?;
    get useResourceTimeoutForPropagation(): boolean | cdktn.IResolvable;
    set useResourceTimeoutForPropagation(value: boolean | cdktn.IResolvable);
    resetUseResourceTimeoutForPropagation(): void;
    get useResourceTimeoutForPropagationInput(): boolean | cdktn.IResolvable | undefined;
    get uuid(): string;
    private _amazonManagedKafkaEventSourceConfig;
    get amazonManagedKafkaEventSourceConfig(): AwsEventSourceMapping.AmazonManagedKafkaEventSourceConfigPropertyOutputReference;
    putAmazonManagedKafkaEventSourceConfig(value: AwsEventSourceMapping.AmazonManagedKafkaEventSourceConfigProperty): void;
    resetAmazonManagedKafkaEventSourceConfig(): void;
    get amazonManagedKafkaEventSourceConfigInput(): AwsEventSourceMapping.AmazonManagedKafkaEventSourceConfigProperty | undefined;
    private _destinationConfig;
    get destinationConfig(): AwsEventSourceMapping.DestinationConfigPropertyOutputReference;
    putDestinationConfig(value: AwsEventSourceMapping.DestinationConfigProperty): void;
    resetDestinationConfig(): void;
    get destinationConfigInput(): AwsEventSourceMapping.DestinationConfigProperty | undefined;
    private _documentDbEventSourceConfig;
    get documentDbEventSourceConfig(): AwsEventSourceMapping.DocumentDbEventSourceConfigPropertyOutputReference;
    putDocumentDbEventSourceConfig(value: AwsEventSourceMapping.DocumentDbEventSourceConfigProperty): void;
    resetDocumentDbEventSourceConfig(): void;
    get documentDbEventSourceConfigInput(): AwsEventSourceMapping.DocumentDbEventSourceConfigProperty | undefined;
    private _filterCriteria;
    get filterCriteria(): AwsEventSourceMapping.FilterCriteriaPropertyOutputReference;
    putFilterCriteria(value: AwsEventSourceMapping.FilterCriteriaProperty): void;
    resetFilterCriteria(): void;
    get filterCriteriaInput(): AwsEventSourceMapping.FilterCriteriaProperty | undefined;
    private _metricsConfig;
    get metricsConfig(): AwsEventSourceMapping.MetricsConfigPropertyOutputReference;
    putMetricsConfig(value: AwsEventSourceMapping.MetricsConfigProperty): void;
    resetMetricsConfig(): void;
    get metricsConfigInput(): AwsEventSourceMapping.MetricsConfigProperty | undefined;
    private _provisionedPollerConfig;
    get provisionedPollerConfig(): AwsEventSourceMapping.ProvisionedPollerConfigPropertyOutputReference;
    putProvisionedPollerConfig(value: AwsEventSourceMapping.ProvisionedPollerConfigProperty): void;
    resetProvisionedPollerConfig(): void;
    get provisionedPollerConfigInput(): AwsEventSourceMapping.ProvisionedPollerConfigProperty | undefined;
    private _scalingConfig;
    get scalingConfig(): AwsEventSourceMapping.ScalingConfigPropertyOutputReference;
    putScalingConfig(value: AwsEventSourceMapping.ScalingConfigProperty): void;
    resetScalingConfig(): void;
    get scalingConfigInput(): AwsEventSourceMapping.ScalingConfigProperty | undefined;
    private _selfManagedEventSource;
    get selfManagedEventSource(): AwsEventSourceMapping.SelfManagedEventSourcePropertyOutputReference;
    putSelfManagedEventSource(value: AwsEventSourceMapping.SelfManagedEventSourceProperty): void;
    resetSelfManagedEventSource(): void;
    get selfManagedEventSourceInput(): AwsEventSourceMapping.SelfManagedEventSourceProperty | undefined;
    private _selfManagedKafkaEventSourceConfig;
    get selfManagedKafkaEventSourceConfig(): AwsEventSourceMapping.SelfManagedKafkaEventSourceConfigPropertyOutputReference;
    putSelfManagedKafkaEventSourceConfig(value: AwsEventSourceMapping.SelfManagedKafkaEventSourceConfigProperty): void;
    resetSelfManagedKafkaEventSourceConfig(): void;
    get selfManagedKafkaEventSourceConfigInput(): AwsEventSourceMapping.SelfManagedKafkaEventSourceConfigProperty | undefined;
    private _sourceAccessConfiguration;
    get sourceAccessConfiguration(): AwsEventSourceMapping.SourceAccessConfigurationPropertyList;
    putSourceAccessConfiguration(value: AwsEventSourceMapping.SourceAccessConfigurationProperty[] | cdktn.IResolvable): void;
    resetSourceAccessConfiguration(): void;
    get sourceAccessConfigurationInput(): cdktn.IResolvable | AwsEventSourceMapping.SourceAccessConfigurationProperty[] | undefined;
    private _timeouts;
    get timeouts(): AwsEventSourceMapping.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsEventSourceMapping.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsEventSourceMapping.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsEventSourceMappingAmazonManagedKafkaEventSourceConfigSchemaRegistryConfigAccessConfigPropertyToTerraform(struct?: AwsEventSourceMapping.AmazonManagedKafkaEventSourceConfigSchemaRegistryConfigAccessConfigProperty | cdktn.IResolvable): any;
export declare function awsEventSourceMappingAmazonManagedKafkaEventSourceConfigSchemaRegistryConfigAccessConfigPropertyToHclTerraform(struct?: AwsEventSourceMapping.AmazonManagedKafkaEventSourceConfigSchemaRegistryConfigAccessConfigProperty | cdktn.IResolvable): any;
export declare function awsEventSourceMappingAmazonManagedKafkaEventSourceConfigSchemaRegistryConfigSchemaValidationConfigPropertyToTerraform(struct?: AwsEventSourceMapping.AmazonManagedKafkaEventSourceConfigSchemaRegistryConfigSchemaValidationConfigProperty | cdktn.IResolvable): any;
export declare function awsEventSourceMappingAmazonManagedKafkaEventSourceConfigSchemaRegistryConfigSchemaValidationConfigPropertyToHclTerraform(struct?: AwsEventSourceMapping.AmazonManagedKafkaEventSourceConfigSchemaRegistryConfigSchemaValidationConfigProperty | cdktn.IResolvable): any;
export declare function awsEventSourceMappingAmazonManagedKafkaEventSourceConfigSchemaRegistryConfigPropertyToTerraform(struct?: AwsEventSourceMapping.AmazonManagedKafkaEventSourceConfigSchemaRegistryConfigPropertyOutputReference | AwsEventSourceMapping.AmazonManagedKafkaEventSourceConfigSchemaRegistryConfigProperty): any;
export declare function awsEventSourceMappingAmazonManagedKafkaEventSourceConfigSchemaRegistryConfigPropertyToHclTerraform(struct?: AwsEventSourceMapping.AmazonManagedKafkaEventSourceConfigSchemaRegistryConfigPropertyOutputReference | AwsEventSourceMapping.AmazonManagedKafkaEventSourceConfigSchemaRegistryConfigProperty): any;
export declare function awsEventSourceMappingAmazonManagedKafkaEventSourceConfigPropertyToTerraform(struct?: AwsEventSourceMapping.AmazonManagedKafkaEventSourceConfigPropertyOutputReference | AwsEventSourceMapping.AmazonManagedKafkaEventSourceConfigProperty): any;
export declare function awsEventSourceMappingAmazonManagedKafkaEventSourceConfigPropertyToHclTerraform(struct?: AwsEventSourceMapping.AmazonManagedKafkaEventSourceConfigPropertyOutputReference | AwsEventSourceMapping.AmazonManagedKafkaEventSourceConfigProperty): any;
export declare function awsEventSourceMappingOnFailurePropertyToTerraform(struct?: AwsEventSourceMapping.OnFailurePropertyOutputReference | AwsEventSourceMapping.OnFailureProperty): any;
export declare function awsEventSourceMappingOnFailurePropertyToHclTerraform(struct?: AwsEventSourceMapping.OnFailurePropertyOutputReference | AwsEventSourceMapping.OnFailureProperty): any;
export declare function awsEventSourceMappingDestinationConfigPropertyToTerraform(struct?: AwsEventSourceMapping.DestinationConfigPropertyOutputReference | AwsEventSourceMapping.DestinationConfigProperty): any;
export declare function awsEventSourceMappingDestinationConfigPropertyToHclTerraform(struct?: AwsEventSourceMapping.DestinationConfigPropertyOutputReference | AwsEventSourceMapping.DestinationConfigProperty): any;
export declare function awsEventSourceMappingDocumentDbEventSourceConfigPropertyToTerraform(struct?: AwsEventSourceMapping.DocumentDbEventSourceConfigPropertyOutputReference | AwsEventSourceMapping.DocumentDbEventSourceConfigProperty): any;
export declare function awsEventSourceMappingDocumentDbEventSourceConfigPropertyToHclTerraform(struct?: AwsEventSourceMapping.DocumentDbEventSourceConfigPropertyOutputReference | AwsEventSourceMapping.DocumentDbEventSourceConfigProperty): any;
export declare function awsEventSourceMappingFilterPropertyToTerraform(struct?: AwsEventSourceMapping.FilterProperty | cdktn.IResolvable): any;
export declare function awsEventSourceMappingFilterPropertyToHclTerraform(struct?: AwsEventSourceMapping.FilterProperty | cdktn.IResolvable): any;
export declare function awsEventSourceMappingFilterCriteriaPropertyToTerraform(struct?: AwsEventSourceMapping.FilterCriteriaPropertyOutputReference | AwsEventSourceMapping.FilterCriteriaProperty): any;
export declare function awsEventSourceMappingFilterCriteriaPropertyToHclTerraform(struct?: AwsEventSourceMapping.FilterCriteriaPropertyOutputReference | AwsEventSourceMapping.FilterCriteriaProperty): any;
export declare function awsEventSourceMappingMetricsConfigPropertyToTerraform(struct?: AwsEventSourceMapping.MetricsConfigPropertyOutputReference | AwsEventSourceMapping.MetricsConfigProperty): any;
export declare function awsEventSourceMappingMetricsConfigPropertyToHclTerraform(struct?: AwsEventSourceMapping.MetricsConfigPropertyOutputReference | AwsEventSourceMapping.MetricsConfigProperty): any;
export declare function awsEventSourceMappingProvisionedPollerConfigPropertyToTerraform(struct?: AwsEventSourceMapping.ProvisionedPollerConfigPropertyOutputReference | AwsEventSourceMapping.ProvisionedPollerConfigProperty): any;
export declare function awsEventSourceMappingProvisionedPollerConfigPropertyToHclTerraform(struct?: AwsEventSourceMapping.ProvisionedPollerConfigPropertyOutputReference | AwsEventSourceMapping.ProvisionedPollerConfigProperty): any;
export declare function awsEventSourceMappingScalingConfigPropertyToTerraform(struct?: AwsEventSourceMapping.ScalingConfigPropertyOutputReference | AwsEventSourceMapping.ScalingConfigProperty): any;
export declare function awsEventSourceMappingScalingConfigPropertyToHclTerraform(struct?: AwsEventSourceMapping.ScalingConfigPropertyOutputReference | AwsEventSourceMapping.ScalingConfigProperty): any;
export declare function awsEventSourceMappingSelfManagedEventSourcePropertyToTerraform(struct?: AwsEventSourceMapping.SelfManagedEventSourcePropertyOutputReference | AwsEventSourceMapping.SelfManagedEventSourceProperty): any;
export declare function awsEventSourceMappingSelfManagedEventSourcePropertyToHclTerraform(struct?: AwsEventSourceMapping.SelfManagedEventSourcePropertyOutputReference | AwsEventSourceMapping.SelfManagedEventSourceProperty): any;
export declare function awsEventSourceMappingSelfManagedKafkaEventSourceConfigSchemaRegistryConfigAccessConfigPropertyToTerraform(struct?: AwsEventSourceMapping.SelfManagedKafkaEventSourceConfigSchemaRegistryConfigAccessConfigProperty | cdktn.IResolvable): any;
export declare function awsEventSourceMappingSelfManagedKafkaEventSourceConfigSchemaRegistryConfigAccessConfigPropertyToHclTerraform(struct?: AwsEventSourceMapping.SelfManagedKafkaEventSourceConfigSchemaRegistryConfigAccessConfigProperty | cdktn.IResolvable): any;
export declare function awsEventSourceMappingSelfManagedKafkaEventSourceConfigSchemaRegistryConfigSchemaValidationConfigPropertyToTerraform(struct?: AwsEventSourceMapping.SelfManagedKafkaEventSourceConfigSchemaRegistryConfigSchemaValidationConfigProperty | cdktn.IResolvable): any;
export declare function awsEventSourceMappingSelfManagedKafkaEventSourceConfigSchemaRegistryConfigSchemaValidationConfigPropertyToHclTerraform(struct?: AwsEventSourceMapping.SelfManagedKafkaEventSourceConfigSchemaRegistryConfigSchemaValidationConfigProperty | cdktn.IResolvable): any;
export declare function awsEventSourceMappingSelfManagedKafkaEventSourceConfigSchemaRegistryConfigPropertyToTerraform(struct?: AwsEventSourceMapping.SelfManagedKafkaEventSourceConfigSchemaRegistryConfigPropertyOutputReference | AwsEventSourceMapping.SelfManagedKafkaEventSourceConfigSchemaRegistryConfigProperty): any;
export declare function awsEventSourceMappingSelfManagedKafkaEventSourceConfigSchemaRegistryConfigPropertyToHclTerraform(struct?: AwsEventSourceMapping.SelfManagedKafkaEventSourceConfigSchemaRegistryConfigPropertyOutputReference | AwsEventSourceMapping.SelfManagedKafkaEventSourceConfigSchemaRegistryConfigProperty): any;
export declare function awsEventSourceMappingSelfManagedKafkaEventSourceConfigPropertyToTerraform(struct?: AwsEventSourceMapping.SelfManagedKafkaEventSourceConfigPropertyOutputReference | AwsEventSourceMapping.SelfManagedKafkaEventSourceConfigProperty): any;
export declare function awsEventSourceMappingSelfManagedKafkaEventSourceConfigPropertyToHclTerraform(struct?: AwsEventSourceMapping.SelfManagedKafkaEventSourceConfigPropertyOutputReference | AwsEventSourceMapping.SelfManagedKafkaEventSourceConfigProperty): any;
export declare function awsEventSourceMappingSourceAccessConfigurationPropertyToTerraform(struct?: AwsEventSourceMapping.SourceAccessConfigurationProperty | cdktn.IResolvable): any;
export declare function awsEventSourceMappingSourceAccessConfigurationPropertyToHclTerraform(struct?: AwsEventSourceMapping.SourceAccessConfigurationProperty | cdktn.IResolvable): any;
export declare function awsEventSourceMappingTimeoutsPropertyToTerraform(struct?: AwsEventSourceMapping.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsEventSourceMappingTimeoutsPropertyToHclTerraform(struct?: AwsEventSourceMapping.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsEventSourceMapping {
    interface AmazonManagedKafkaEventSourceConfigSchemaRegistryConfigAccessConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_event_source_mapping#type AwsEventSourceMapping#type}
        */
        readonly type?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_event_source_mapping#uri AwsEventSourceMapping#uri}
        */
        readonly uri?: string;
    }
    class AmazonManagedKafkaEventSourceConfigSchemaRegistryConfigAccessConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AmazonManagedKafkaEventSourceConfigSchemaRegistryConfigAccessConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: AmazonManagedKafkaEventSourceConfigSchemaRegistryConfigAccessConfigProperty | cdktn.IResolvable | undefined);
        private _type?;
        get type(): string;
        set type(value: string);
        resetType(): void;
        get typeInput(): string | undefined;
        private _uri?;
        get uri(): string;
        set uri(value: string);
        resetUri(): void;
        get uriInput(): string | undefined;
    }
    class AmazonManagedKafkaEventSourceConfigSchemaRegistryConfigAccessConfigPropertyList extends cdktn.ComplexList {
        internalValue?: AmazonManagedKafkaEventSourceConfigSchemaRegistryConfigAccessConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AmazonManagedKafkaEventSourceConfigSchemaRegistryConfigAccessConfigPropertyOutputReference;
    }
    interface AmazonManagedKafkaEventSourceConfigSchemaRegistryConfigSchemaValidationConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_event_source_mapping#attribute AwsEventSourceMapping#attribute}
        */
        readonly attribute?: string;
    }
    class AmazonManagedKafkaEventSourceConfigSchemaRegistryConfigSchemaValidationConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AmazonManagedKafkaEventSourceConfigSchemaRegistryConfigSchemaValidationConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: AmazonManagedKafkaEventSourceConfigSchemaRegistryConfigSchemaValidationConfigProperty | cdktn.IResolvable | undefined);
        private _attribute?;
        get attribute(): string;
        set attribute(value: string);
        resetAttribute(): void;
        get attributeInput(): string | undefined;
    }
    class AmazonManagedKafkaEventSourceConfigSchemaRegistryConfigSchemaValidationConfigPropertyList extends cdktn.ComplexList {
        internalValue?: AmazonManagedKafkaEventSourceConfigSchemaRegistryConfigSchemaValidationConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AmazonManagedKafkaEventSourceConfigSchemaRegistryConfigSchemaValidationConfigPropertyOutputReference;
    }
    interface AmazonManagedKafkaEventSourceConfigSchemaRegistryConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_event_source_mapping#event_record_format AwsEventSourceMapping#event_record_format}
        */
        readonly eventRecordFormat?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_event_source_mapping#schema_registry_uri AwsEventSourceMapping#schema_registry_uri}
        */
        readonly schemaRegistryUri?: string;
        /**
        * access_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_event_source_mapping#access_config AwsEventSourceMapping#access_config}
        */
        readonly accessConfig?: AmazonManagedKafkaEventSourceConfigSchemaRegistryConfigAccessConfigProperty[] | cdktn.IResolvable;
        /**
        * schema_validation_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_event_source_mapping#schema_validation_config AwsEventSourceMapping#schema_validation_config}
        */
        readonly schemaValidationConfig?: AmazonManagedKafkaEventSourceConfigSchemaRegistryConfigSchemaValidationConfigProperty[] | cdktn.IResolvable;
    }
    class AmazonManagedKafkaEventSourceConfigSchemaRegistryConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AmazonManagedKafkaEventSourceConfigSchemaRegistryConfigProperty | undefined;
        set internalValue(value: AmazonManagedKafkaEventSourceConfigSchemaRegistryConfigProperty | undefined);
        private _eventRecordFormat?;
        get eventRecordFormat(): string;
        set eventRecordFormat(value: string);
        resetEventRecordFormat(): void;
        get eventRecordFormatInput(): string | undefined;
        private _schemaRegistryUri?;
        get schemaRegistryUri(): string;
        set schemaRegistryUri(value: string);
        resetSchemaRegistryUri(): void;
        get schemaRegistryUriInput(): string | undefined;
        private _accessConfig;
        get accessConfig(): AmazonManagedKafkaEventSourceConfigSchemaRegistryConfigAccessConfigPropertyList;
        putAccessConfig(value: AmazonManagedKafkaEventSourceConfigSchemaRegistryConfigAccessConfigProperty[] | cdktn.IResolvable): void;
        resetAccessConfig(): void;
        get accessConfigInput(): cdktn.IResolvable | AmazonManagedKafkaEventSourceConfigSchemaRegistryConfigAccessConfigProperty[] | undefined;
        private _schemaValidationConfig;
        get schemaValidationConfig(): AmazonManagedKafkaEventSourceConfigSchemaRegistryConfigSchemaValidationConfigPropertyList;
        putSchemaValidationConfig(value: AmazonManagedKafkaEventSourceConfigSchemaRegistryConfigSchemaValidationConfigProperty[] | cdktn.IResolvable): void;
        resetSchemaValidationConfig(): void;
        get schemaValidationConfigInput(): cdktn.IResolvable | AmazonManagedKafkaEventSourceConfigSchemaRegistryConfigSchemaValidationConfigProperty[] | undefined;
    }
    interface AmazonManagedKafkaEventSourceConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_event_source_mapping#consumer_group_id AwsEventSourceMapping#consumer_group_id}
        */
        readonly consumerGroupId?: string;
        /**
        * schema_registry_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_event_source_mapping#schema_registry_config AwsEventSourceMapping#schema_registry_config}
        */
        readonly schemaRegistryConfig?: AmazonManagedKafkaEventSourceConfigSchemaRegistryConfigProperty;
    }
    class AmazonManagedKafkaEventSourceConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AmazonManagedKafkaEventSourceConfigProperty | undefined;
        set internalValue(value: AmazonManagedKafkaEventSourceConfigProperty | undefined);
        private _consumerGroupId?;
        get consumerGroupId(): string;
        set consumerGroupId(value: string);
        resetConsumerGroupId(): void;
        get consumerGroupIdInput(): string | undefined;
        private _schemaRegistryConfig;
        get schemaRegistryConfig(): AmazonManagedKafkaEventSourceConfigSchemaRegistryConfigPropertyOutputReference;
        putSchemaRegistryConfig(value: AmazonManagedKafkaEventSourceConfigSchemaRegistryConfigProperty): void;
        resetSchemaRegistryConfig(): void;
        get schemaRegistryConfigInput(): AmazonManagedKafkaEventSourceConfigSchemaRegistryConfigProperty | undefined;
    }
    interface OnFailureProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_event_source_mapping#destination_arn AwsEventSourceMapping#destination_arn}
        */
        readonly destinationArn: string;
    }
    class OnFailurePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): OnFailureProperty | undefined;
        set internalValue(value: OnFailureProperty | undefined);
        private _destinationArn?;
        get destinationArn(): string;
        set destinationArn(value: string);
        get destinationArnInput(): string | undefined;
    }
    interface DestinationConfigProperty {
        /**
        * on_failure block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_event_source_mapping#on_failure AwsEventSourceMapping#on_failure}
        */
        readonly onFailure?: OnFailureProperty;
    }
    class DestinationConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DestinationConfigProperty | undefined;
        set internalValue(value: DestinationConfigProperty | undefined);
        private _onFailure;
        get onFailure(): OnFailurePropertyOutputReference;
        putOnFailure(value: OnFailureProperty): void;
        resetOnFailure(): void;
        get onFailureInput(): OnFailureProperty | undefined;
    }
    interface DocumentDbEventSourceConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_event_source_mapping#collection_name AwsEventSourceMapping#collection_name}
        */
        readonly collectionName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_event_source_mapping#database_name AwsEventSourceMapping#database_name}
        */
        readonly databaseName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_event_source_mapping#full_document AwsEventSourceMapping#full_document}
        */
        readonly fullDocument?: string;
    }
    class DocumentDbEventSourceConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DocumentDbEventSourceConfigProperty | undefined;
        set internalValue(value: DocumentDbEventSourceConfigProperty | undefined);
        private _collectionName?;
        get collectionName(): string;
        set collectionName(value: string);
        resetCollectionName(): void;
        get collectionNameInput(): string | undefined;
        private _databaseName?;
        get databaseName(): string;
        set databaseName(value: string);
        get databaseNameInput(): string | undefined;
        private _fullDocument?;
        get fullDocument(): string;
        set fullDocument(value: string);
        resetFullDocument(): void;
        get fullDocumentInput(): string | undefined;
    }
    interface FilterProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_event_source_mapping#pattern AwsEventSourceMapping#pattern}
        */
        readonly pattern?: string;
    }
    class FilterPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): FilterProperty | cdktn.IResolvable | undefined;
        set internalValue(value: FilterProperty | cdktn.IResolvable | undefined);
        private _pattern?;
        get pattern(): string;
        set pattern(value: string);
        resetPattern(): void;
        get patternInput(): string | undefined;
    }
    class FilterPropertyList extends cdktn.ComplexList {
        internalValue?: FilterProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): FilterPropertyOutputReference;
    }
    interface FilterCriteriaProperty {
        /**
        * filter block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_event_source_mapping#filter AwsEventSourceMapping#filter}
        */
        readonly filter?: FilterProperty[] | cdktn.IResolvable;
    }
    class FilterCriteriaPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): FilterCriteriaProperty | undefined;
        set internalValue(value: FilterCriteriaProperty | undefined);
        private _filter;
        get filter(): FilterPropertyList;
        putFilter(value: FilterProperty[] | cdktn.IResolvable): void;
        resetFilter(): void;
        get filterInput(): cdktn.IResolvable | FilterProperty[] | undefined;
    }
    interface MetricsConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_event_source_mapping#metrics AwsEventSourceMapping#metrics}
        */
        readonly metrics: string[];
    }
    class MetricsConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): MetricsConfigProperty | undefined;
        set internalValue(value: MetricsConfigProperty | undefined);
        private _metrics?;
        get metrics(): string[];
        set metrics(value: string[]);
        get metricsInput(): string[] | undefined;
    }
    interface ProvisionedPollerConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_event_source_mapping#maximum_pollers AwsEventSourceMapping#maximum_pollers}
        */
        readonly maximumPollers?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_event_source_mapping#minimum_pollers AwsEventSourceMapping#minimum_pollers}
        */
        readonly minimumPollers?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_event_source_mapping#poller_group_name AwsEventSourceMapping#poller_group_name}
        */
        readonly pollerGroupName?: string;
    }
    class ProvisionedPollerConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ProvisionedPollerConfigProperty | undefined;
        set internalValue(value: ProvisionedPollerConfigProperty | undefined);
        private _maximumPollers?;
        get maximumPollers(): number;
        set maximumPollers(value: number);
        resetMaximumPollers(): void;
        get maximumPollersInput(): number | undefined;
        private _minimumPollers?;
        get minimumPollers(): number;
        set minimumPollers(value: number);
        resetMinimumPollers(): void;
        get minimumPollersInput(): number | undefined;
        private _pollerGroupName?;
        get pollerGroupName(): string;
        set pollerGroupName(value: string);
        resetPollerGroupName(): void;
        get pollerGroupNameInput(): string | undefined;
    }
    interface ScalingConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_event_source_mapping#maximum_concurrency AwsEventSourceMapping#maximum_concurrency}
        */
        readonly maximumConcurrency?: number;
    }
    class ScalingConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ScalingConfigProperty | undefined;
        set internalValue(value: ScalingConfigProperty | undefined);
        private _maximumConcurrency?;
        get maximumConcurrency(): number;
        set maximumConcurrency(value: number);
        resetMaximumConcurrency(): void;
        get maximumConcurrencyInput(): number | undefined;
    }
    interface SelfManagedEventSourceProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_event_source_mapping#endpoints AwsEventSourceMapping#endpoints}
        */
        readonly endpoints: {
            [key: string]: string;
        };
    }
    class SelfManagedEventSourcePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SelfManagedEventSourceProperty | undefined;
        set internalValue(value: SelfManagedEventSourceProperty | undefined);
        private _endpoints?;
        get endpoints(): {
            [key: string]: string;
        };
        set endpoints(value: {
            [key: string]: string;
        });
        get endpointsInput(): {
            [key: string]: string;
        } | undefined;
    }
    interface SelfManagedKafkaEventSourceConfigSchemaRegistryConfigAccessConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_event_source_mapping#type AwsEventSourceMapping#type}
        */
        readonly type?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_event_source_mapping#uri AwsEventSourceMapping#uri}
        */
        readonly uri?: string;
    }
    class SelfManagedKafkaEventSourceConfigSchemaRegistryConfigAccessConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SelfManagedKafkaEventSourceConfigSchemaRegistryConfigAccessConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SelfManagedKafkaEventSourceConfigSchemaRegistryConfigAccessConfigProperty | cdktn.IResolvable | undefined);
        private _type?;
        get type(): string;
        set type(value: string);
        resetType(): void;
        get typeInput(): string | undefined;
        private _uri?;
        get uri(): string;
        set uri(value: string);
        resetUri(): void;
        get uriInput(): string | undefined;
    }
    class SelfManagedKafkaEventSourceConfigSchemaRegistryConfigAccessConfigPropertyList extends cdktn.ComplexList {
        internalValue?: SelfManagedKafkaEventSourceConfigSchemaRegistryConfigAccessConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SelfManagedKafkaEventSourceConfigSchemaRegistryConfigAccessConfigPropertyOutputReference;
    }
    interface SelfManagedKafkaEventSourceConfigSchemaRegistryConfigSchemaValidationConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_event_source_mapping#attribute AwsEventSourceMapping#attribute}
        */
        readonly attribute?: string;
    }
    class SelfManagedKafkaEventSourceConfigSchemaRegistryConfigSchemaValidationConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SelfManagedKafkaEventSourceConfigSchemaRegistryConfigSchemaValidationConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SelfManagedKafkaEventSourceConfigSchemaRegistryConfigSchemaValidationConfigProperty | cdktn.IResolvable | undefined);
        private _attribute?;
        get attribute(): string;
        set attribute(value: string);
        resetAttribute(): void;
        get attributeInput(): string | undefined;
    }
    class SelfManagedKafkaEventSourceConfigSchemaRegistryConfigSchemaValidationConfigPropertyList extends cdktn.ComplexList {
        internalValue?: SelfManagedKafkaEventSourceConfigSchemaRegistryConfigSchemaValidationConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SelfManagedKafkaEventSourceConfigSchemaRegistryConfigSchemaValidationConfigPropertyOutputReference;
    }
    interface SelfManagedKafkaEventSourceConfigSchemaRegistryConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_event_source_mapping#event_record_format AwsEventSourceMapping#event_record_format}
        */
        readonly eventRecordFormat?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_event_source_mapping#schema_registry_uri AwsEventSourceMapping#schema_registry_uri}
        */
        readonly schemaRegistryUri?: string;
        /**
        * access_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_event_source_mapping#access_config AwsEventSourceMapping#access_config}
        */
        readonly accessConfig?: SelfManagedKafkaEventSourceConfigSchemaRegistryConfigAccessConfigProperty[] | cdktn.IResolvable;
        /**
        * schema_validation_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_event_source_mapping#schema_validation_config AwsEventSourceMapping#schema_validation_config}
        */
        readonly schemaValidationConfig?: SelfManagedKafkaEventSourceConfigSchemaRegistryConfigSchemaValidationConfigProperty[] | cdktn.IResolvable;
    }
    class SelfManagedKafkaEventSourceConfigSchemaRegistryConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SelfManagedKafkaEventSourceConfigSchemaRegistryConfigProperty | undefined;
        set internalValue(value: SelfManagedKafkaEventSourceConfigSchemaRegistryConfigProperty | undefined);
        private _eventRecordFormat?;
        get eventRecordFormat(): string;
        set eventRecordFormat(value: string);
        resetEventRecordFormat(): void;
        get eventRecordFormatInput(): string | undefined;
        private _schemaRegistryUri?;
        get schemaRegistryUri(): string;
        set schemaRegistryUri(value: string);
        resetSchemaRegistryUri(): void;
        get schemaRegistryUriInput(): string | undefined;
        private _accessConfig;
        get accessConfig(): SelfManagedKafkaEventSourceConfigSchemaRegistryConfigAccessConfigPropertyList;
        putAccessConfig(value: SelfManagedKafkaEventSourceConfigSchemaRegistryConfigAccessConfigProperty[] | cdktn.IResolvable): void;
        resetAccessConfig(): void;
        get accessConfigInput(): cdktn.IResolvable | SelfManagedKafkaEventSourceConfigSchemaRegistryConfigAccessConfigProperty[] | undefined;
        private _schemaValidationConfig;
        get schemaValidationConfig(): SelfManagedKafkaEventSourceConfigSchemaRegistryConfigSchemaValidationConfigPropertyList;
        putSchemaValidationConfig(value: SelfManagedKafkaEventSourceConfigSchemaRegistryConfigSchemaValidationConfigProperty[] | cdktn.IResolvable): void;
        resetSchemaValidationConfig(): void;
        get schemaValidationConfigInput(): cdktn.IResolvable | SelfManagedKafkaEventSourceConfigSchemaRegistryConfigSchemaValidationConfigProperty[] | undefined;
    }
    interface SelfManagedKafkaEventSourceConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_event_source_mapping#consumer_group_id AwsEventSourceMapping#consumer_group_id}
        */
        readonly consumerGroupId?: string;
        /**
        * schema_registry_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_event_source_mapping#schema_registry_config AwsEventSourceMapping#schema_registry_config}
        */
        readonly schemaRegistryConfig?: SelfManagedKafkaEventSourceConfigSchemaRegistryConfigProperty;
    }
    class SelfManagedKafkaEventSourceConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SelfManagedKafkaEventSourceConfigProperty | undefined;
        set internalValue(value: SelfManagedKafkaEventSourceConfigProperty | undefined);
        private _consumerGroupId?;
        get consumerGroupId(): string;
        set consumerGroupId(value: string);
        resetConsumerGroupId(): void;
        get consumerGroupIdInput(): string | undefined;
        private _schemaRegistryConfig;
        get schemaRegistryConfig(): SelfManagedKafkaEventSourceConfigSchemaRegistryConfigPropertyOutputReference;
        putSchemaRegistryConfig(value: SelfManagedKafkaEventSourceConfigSchemaRegistryConfigProperty): void;
        resetSchemaRegistryConfig(): void;
        get schemaRegistryConfigInput(): SelfManagedKafkaEventSourceConfigSchemaRegistryConfigProperty | undefined;
    }
    interface SourceAccessConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_event_source_mapping#type AwsEventSourceMapping#type}
        */
        readonly type: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_event_source_mapping#uri AwsEventSourceMapping#uri}
        */
        readonly uri: string;
    }
    class SourceAccessConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SourceAccessConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SourceAccessConfigurationProperty | cdktn.IResolvable | undefined);
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
        private _uri?;
        get uri(): string;
        set uri(value: string);
        get uriInput(): string | undefined;
    }
    class SourceAccessConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: SourceAccessConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SourceAccessConfigurationPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_event_source_mapping#create AwsEventSourceMapping#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_event_source_mapping#delete AwsEventSourceMapping#delete}
        */
        readonly delete?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_event_source_mapping#update AwsEventSourceMapping#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
