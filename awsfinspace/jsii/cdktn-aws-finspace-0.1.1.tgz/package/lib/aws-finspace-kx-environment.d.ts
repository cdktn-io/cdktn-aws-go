import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsFinspaceKxEnvironmentConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/finspace_kx_environment#description AwsFinspaceKxEnvironment#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/finspace_kx_environment#kms_key_id AwsFinspaceKxEnvironment#kms_key_id}
    */
    readonly kmsKeyId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/finspace_kx_environment#name AwsFinspaceKxEnvironment#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/finspace_kx_environment#region AwsFinspaceKxEnvironment#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/finspace_kx_environment#tags AwsFinspaceKxEnvironment#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/finspace_kx_environment#tags_all AwsFinspaceKxEnvironment#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * custom_dns_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/finspace_kx_environment#custom_dns_configuration AwsFinspaceKxEnvironment#custom_dns_configuration}
    */
    readonly customDnsConfiguration?: AwsFinspaceKxEnvironment.CustomDnsConfigurationProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/finspace_kx_environment#timeouts AwsFinspaceKxEnvironment#timeouts}
    */
    readonly timeouts?: AwsFinspaceKxEnvironment.TimeoutsProperty;
    /**
    * transit_gateway_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/finspace_kx_environment#transit_gateway_configuration AwsFinspaceKxEnvironment#transit_gateway_configuration}
    */
    readonly transitGatewayConfiguration?: AwsFinspaceKxEnvironment.TransitGatewayConfigurationProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/finspace_kx_environment aws_finspace_kx_environment}
*/
export declare class AwsFinspaceKxEnvironment extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_finspace_kx_environment";
    /**
    * Generates CDKTN code for importing a AwsFinspaceKxEnvironment resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsFinspaceKxEnvironment to import
    * @param importFromId The id of the existing AwsFinspaceKxEnvironment that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/finspace_kx_environment#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsFinspaceKxEnvironment to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/finspace_kx_environment aws_finspace_kx_environment} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsFinspaceKxEnvironmentConfig
    */
    constructor(scope: Construct, id: string, config: AwsFinspaceKxEnvironmentConfig);
    get arn(): string;
    get availabilityZones(): string[];
    get createdTimestamp(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get id(): string;
    get infrastructureAccountId(): string;
    private _kmsKeyId?;
    get kmsKeyId(): string;
    set kmsKeyId(value: string);
    get kmsKeyIdInput(): string | undefined;
    get lastModifiedTimestamp(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get status(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _customDnsConfiguration;
    get customDnsConfiguration(): AwsFinspaceKxEnvironment.CustomDnsConfigurationPropertyList;
    putCustomDnsConfiguration(value: AwsFinspaceKxEnvironment.CustomDnsConfigurationProperty[] | cdktn.IResolvable): void;
    resetCustomDnsConfiguration(): void;
    get customDnsConfigurationInput(): cdktn.IResolvable | AwsFinspaceKxEnvironment.CustomDnsConfigurationProperty[] | undefined;
    private _timeouts;
    get timeouts(): AwsFinspaceKxEnvironment.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsFinspaceKxEnvironment.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsFinspaceKxEnvironment.TimeoutsProperty | undefined;
    private _transitGatewayConfiguration;
    get transitGatewayConfiguration(): AwsFinspaceKxEnvironment.TransitGatewayConfigurationPropertyOutputReference;
    putTransitGatewayConfiguration(value: AwsFinspaceKxEnvironment.TransitGatewayConfigurationProperty): void;
    resetTransitGatewayConfiguration(): void;
    get transitGatewayConfigurationInput(): AwsFinspaceKxEnvironment.TransitGatewayConfigurationProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsFinspaceKxEnvironmentCustomDnsConfigurationPropertyToTerraform(struct?: AwsFinspaceKxEnvironment.CustomDnsConfigurationProperty | cdktn.IResolvable): any;
export declare function awsFinspaceKxEnvironmentCustomDnsConfigurationPropertyToHclTerraform(struct?: AwsFinspaceKxEnvironment.CustomDnsConfigurationProperty | cdktn.IResolvable): any;
export declare function awsFinspaceKxEnvironmentTimeoutsPropertyToTerraform(struct?: AwsFinspaceKxEnvironment.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsFinspaceKxEnvironmentTimeoutsPropertyToHclTerraform(struct?: AwsFinspaceKxEnvironment.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsFinspaceKxEnvironmentIcmpTypeCodePropertyToTerraform(struct?: AwsFinspaceKxEnvironment.IcmpTypeCodePropertyOutputReference | AwsFinspaceKxEnvironment.IcmpTypeCodeProperty): any;
export declare function awsFinspaceKxEnvironmentIcmpTypeCodePropertyToHclTerraform(struct?: AwsFinspaceKxEnvironment.IcmpTypeCodePropertyOutputReference | AwsFinspaceKxEnvironment.IcmpTypeCodeProperty): any;
export declare function awsFinspaceKxEnvironmentPortRangePropertyToTerraform(struct?: AwsFinspaceKxEnvironment.PortRangePropertyOutputReference | AwsFinspaceKxEnvironment.PortRangeProperty): any;
export declare function awsFinspaceKxEnvironmentPortRangePropertyToHclTerraform(struct?: AwsFinspaceKxEnvironment.PortRangePropertyOutputReference | AwsFinspaceKxEnvironment.PortRangeProperty): any;
export declare function awsFinspaceKxEnvironmentAttachmentNetworkAclConfigurationPropertyToTerraform(struct?: AwsFinspaceKxEnvironment.AttachmentNetworkAclConfigurationProperty | cdktn.IResolvable): any;
export declare function awsFinspaceKxEnvironmentAttachmentNetworkAclConfigurationPropertyToHclTerraform(struct?: AwsFinspaceKxEnvironment.AttachmentNetworkAclConfigurationProperty | cdktn.IResolvable): any;
export declare function awsFinspaceKxEnvironmentTransitGatewayConfigurationPropertyToTerraform(struct?: AwsFinspaceKxEnvironment.TransitGatewayConfigurationPropertyOutputReference | AwsFinspaceKxEnvironment.TransitGatewayConfigurationProperty): any;
export declare function awsFinspaceKxEnvironmentTransitGatewayConfigurationPropertyToHclTerraform(struct?: AwsFinspaceKxEnvironment.TransitGatewayConfigurationPropertyOutputReference | AwsFinspaceKxEnvironment.TransitGatewayConfigurationProperty): any;
export declare namespace AwsFinspaceKxEnvironment {
    interface CustomDnsConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/finspace_kx_environment#custom_dns_server_ip AwsFinspaceKxEnvironment#custom_dns_server_ip}
        */
        readonly customDnsServerIp: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/finspace_kx_environment#custom_dns_server_name AwsFinspaceKxEnvironment#custom_dns_server_name}
        */
        readonly customDnsServerName: string;
    }
    class CustomDnsConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CustomDnsConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CustomDnsConfigurationProperty | cdktn.IResolvable | undefined);
        private _customDnsServerIp?;
        get customDnsServerIp(): string;
        set customDnsServerIp(value: string);
        get customDnsServerIpInput(): string | undefined;
        private _customDnsServerName?;
        get customDnsServerName(): string;
        set customDnsServerName(value: string);
        get customDnsServerNameInput(): string | undefined;
    }
    class CustomDnsConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: CustomDnsConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CustomDnsConfigurationPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/finspace_kx_environment#create AwsFinspaceKxEnvironment#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/finspace_kx_environment#delete AwsFinspaceKxEnvironment#delete}
        */
        readonly delete?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/finspace_kx_environment#update AwsFinspaceKxEnvironment#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
    interface IcmpTypeCodeProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/finspace_kx_environment#code AwsFinspaceKxEnvironment#code}
        */
        readonly code: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/finspace_kx_environment#type AwsFinspaceKxEnvironment#type}
        */
        readonly type: number;
    }
    class IcmpTypeCodePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): IcmpTypeCodeProperty | undefined;
        set internalValue(value: IcmpTypeCodeProperty | undefined);
        private _code?;
        get code(): number;
        set code(value: number);
        get codeInput(): number | undefined;
        private _type?;
        get type(): number;
        set type(value: number);
        get typeInput(): number | undefined;
    }
    interface PortRangeProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/finspace_kx_environment#from AwsFinspaceKxEnvironment#from}
        */
        readonly from: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/finspace_kx_environment#to AwsFinspaceKxEnvironment#to}
        */
        readonly to: number;
    }
    class PortRangePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): PortRangeProperty | undefined;
        set internalValue(value: PortRangeProperty | undefined);
        private _from?;
        get from(): number;
        set from(value: number);
        get fromInput(): number | undefined;
        private _to?;
        get to(): number;
        set to(value: number);
        get toInput(): number | undefined;
    }
    interface AttachmentNetworkAclConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/finspace_kx_environment#cidr_block AwsFinspaceKxEnvironment#cidr_block}
        */
        readonly cidrBlock: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/finspace_kx_environment#protocol AwsFinspaceKxEnvironment#protocol}
        */
        readonly protocol: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/finspace_kx_environment#rule_action AwsFinspaceKxEnvironment#rule_action}
        */
        readonly ruleAction: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/finspace_kx_environment#rule_number AwsFinspaceKxEnvironment#rule_number}
        */
        readonly ruleNumber: number;
        /**
        * icmp_type_code block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/finspace_kx_environment#icmp_type_code AwsFinspaceKxEnvironment#icmp_type_code}
        */
        readonly icmpTypeCode?: IcmpTypeCodeProperty;
        /**
        * port_range block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/finspace_kx_environment#port_range AwsFinspaceKxEnvironment#port_range}
        */
        readonly portRange?: PortRangeProperty;
    }
    class AttachmentNetworkAclConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AttachmentNetworkAclConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: AttachmentNetworkAclConfigurationProperty | cdktn.IResolvable | undefined);
        private _cidrBlock?;
        get cidrBlock(): string;
        set cidrBlock(value: string);
        get cidrBlockInput(): string | undefined;
        private _protocol?;
        get protocol(): string;
        set protocol(value: string);
        get protocolInput(): string | undefined;
        private _ruleAction?;
        get ruleAction(): string;
        set ruleAction(value: string);
        get ruleActionInput(): string | undefined;
        private _ruleNumber?;
        get ruleNumber(): number;
        set ruleNumber(value: number);
        get ruleNumberInput(): number | undefined;
        private _icmpTypeCode;
        get icmpTypeCode(): IcmpTypeCodePropertyOutputReference;
        putIcmpTypeCode(value: IcmpTypeCodeProperty): void;
        resetIcmpTypeCode(): void;
        get icmpTypeCodeInput(): IcmpTypeCodeProperty | undefined;
        private _portRange;
        get portRange(): PortRangePropertyOutputReference;
        putPortRange(value: PortRangeProperty): void;
        resetPortRange(): void;
        get portRangeInput(): PortRangeProperty | undefined;
    }
    class AttachmentNetworkAclConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: AttachmentNetworkAclConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AttachmentNetworkAclConfigurationPropertyOutputReference;
    }
    interface TransitGatewayConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/finspace_kx_environment#routable_cidr_space AwsFinspaceKxEnvironment#routable_cidr_space}
        */
        readonly routableCidrSpace: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/finspace_kx_environment#transit_gateway_id AwsFinspaceKxEnvironment#transit_gateway_id}
        */
        readonly transitGatewayId: string;
        /**
        * attachment_network_acl_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/finspace_kx_environment#attachment_network_acl_configuration AwsFinspaceKxEnvironment#attachment_network_acl_configuration}
        */
        readonly attachmentNetworkAclConfiguration?: AttachmentNetworkAclConfigurationProperty[] | cdktn.IResolvable;
    }
    class TransitGatewayConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TransitGatewayConfigurationProperty | undefined;
        set internalValue(value: TransitGatewayConfigurationProperty | undefined);
        private _routableCidrSpace?;
        get routableCidrSpace(): string;
        set routableCidrSpace(value: string);
        get routableCidrSpaceInput(): string | undefined;
        private _transitGatewayId?;
        get transitGatewayId(): string;
        set transitGatewayId(value: string);
        get transitGatewayIdInput(): string | undefined;
        private _attachmentNetworkAclConfiguration;
        get attachmentNetworkAclConfiguration(): AttachmentNetworkAclConfigurationPropertyList;
        putAttachmentNetworkAclConfiguration(value: AttachmentNetworkAclConfigurationProperty[] | cdktn.IResolvable): void;
        resetAttachmentNetworkAclConfiguration(): void;
        get attachmentNetworkAclConfigurationInput(): cdktn.IResolvable | AttachmentNetworkAclConfigurationProperty[] | undefined;
    }
}
