import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsFinspaceKxDataviewConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/finspace_kx_dataview#auto_update AwsFinspaceKxDataview#auto_update}
    */
    readonly autoUpdate: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/finspace_kx_dataview#availability_zone_id AwsFinspaceKxDataview#availability_zone_id}
    */
    readonly availabilityZoneId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/finspace_kx_dataview#az_mode AwsFinspaceKxDataview#az_mode}
    */
    readonly azMode: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/finspace_kx_dataview#changeset_id AwsFinspaceKxDataview#changeset_id}
    */
    readonly changesetId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/finspace_kx_dataview#database_name AwsFinspaceKxDataview#database_name}
    */
    readonly databaseName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/finspace_kx_dataview#description AwsFinspaceKxDataview#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/finspace_kx_dataview#environment_id AwsFinspaceKxDataview#environment_id}
    */
    readonly environmentId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/finspace_kx_dataview#id AwsFinspaceKxDataview#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/finspace_kx_dataview#name AwsFinspaceKxDataview#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/finspace_kx_dataview#read_write AwsFinspaceKxDataview#read_write}
    */
    readonly readWrite?: boolean | cdktn.IResolvable;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/finspace_kx_dataview#region AwsFinspaceKxDataview#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/finspace_kx_dataview#tags AwsFinspaceKxDataview#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/finspace_kx_dataview#tags_all AwsFinspaceKxDataview#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * segment_configurations block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/finspace_kx_dataview#segment_configurations AwsFinspaceKxDataview#segment_configurations}
    */
    readonly segmentConfigurations?: AwsFinspaceKxDataview.SegmentConfigurationsProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/finspace_kx_dataview#timeouts AwsFinspaceKxDataview#timeouts}
    */
    readonly timeouts?: AwsFinspaceKxDataview.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/finspace_kx_dataview aws_finspace_kx_dataview}
*/
export declare class AwsFinspaceKxDataview extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_finspace_kx_dataview";
    /**
    * Generates CDKTN code for importing a AwsFinspaceKxDataview resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsFinspaceKxDataview to import
    * @param importFromId The id of the existing AwsFinspaceKxDataview that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/finspace_kx_dataview#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsFinspaceKxDataview to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/finspace_kx_dataview aws_finspace_kx_dataview} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsFinspaceKxDataviewConfig
    */
    constructor(scope: Construct, id: string, config: AwsFinspaceKxDataviewConfig);
    get arn(): string;
    private _autoUpdate?;
    get autoUpdate(): boolean | cdktn.IResolvable;
    set autoUpdate(value: boolean | cdktn.IResolvable);
    get autoUpdateInput(): boolean | cdktn.IResolvable | undefined;
    private _availabilityZoneId?;
    get availabilityZoneId(): string;
    set availabilityZoneId(value: string);
    resetAvailabilityZoneId(): void;
    get availabilityZoneIdInput(): string | undefined;
    private _azMode?;
    get azMode(): string;
    set azMode(value: string);
    get azModeInput(): string | undefined;
    private _changesetId?;
    get changesetId(): string;
    set changesetId(value: string);
    resetChangesetId(): void;
    get changesetIdInput(): string | undefined;
    get createdTimestamp(): string;
    private _databaseName?;
    get databaseName(): string;
    set databaseName(value: string);
    get databaseNameInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _environmentId?;
    get environmentId(): string;
    set environmentId(value: string);
    get environmentIdInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get lastModifiedTimestamp(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _readWrite?;
    get readWrite(): boolean | cdktn.IResolvable;
    set readWrite(value: boolean | cdktn.IResolvable);
    resetReadWrite(): void;
    get readWriteInput(): boolean | cdktn.IResolvable | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get status(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _segmentConfigurations;
    get segmentConfigurations(): AwsFinspaceKxDataview.SegmentConfigurationsPropertyList;
    putSegmentConfigurations(value: AwsFinspaceKxDataview.SegmentConfigurationsProperty[] | cdktn.IResolvable): void;
    resetSegmentConfigurations(): void;
    get segmentConfigurationsInput(): cdktn.IResolvable | AwsFinspaceKxDataview.SegmentConfigurationsProperty[] | undefined;
    private _timeouts;
    get timeouts(): AwsFinspaceKxDataview.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsFinspaceKxDataview.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsFinspaceKxDataview.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsFinspaceKxDataviewSegmentConfigurationsPropertyToTerraform(struct?: AwsFinspaceKxDataview.SegmentConfigurationsProperty | cdktn.IResolvable): any;
export declare function awsFinspaceKxDataviewSegmentConfigurationsPropertyToHclTerraform(struct?: AwsFinspaceKxDataview.SegmentConfigurationsProperty | cdktn.IResolvable): any;
export declare function awsFinspaceKxDataviewTimeoutsPropertyToTerraform(struct?: AwsFinspaceKxDataview.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsFinspaceKxDataviewTimeoutsPropertyToHclTerraform(struct?: AwsFinspaceKxDataview.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsFinspaceKxDataview {
    interface SegmentConfigurationsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/finspace_kx_dataview#db_paths AwsFinspaceKxDataview#db_paths}
        */
        readonly dbPaths: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/finspace_kx_dataview#on_demand AwsFinspaceKxDataview#on_demand}
        */
        readonly onDemand?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/finspace_kx_dataview#volume_name AwsFinspaceKxDataview#volume_name}
        */
        readonly volumeName: string;
    }
    class SegmentConfigurationsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SegmentConfigurationsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SegmentConfigurationsProperty | cdktn.IResolvable | undefined);
        private _dbPaths?;
        get dbPaths(): string[];
        set dbPaths(value: string[]);
        get dbPathsInput(): string[] | undefined;
        private _onDemand?;
        get onDemand(): boolean | cdktn.IResolvable;
        set onDemand(value: boolean | cdktn.IResolvable);
        resetOnDemand(): void;
        get onDemandInput(): boolean | cdktn.IResolvable | undefined;
        private _volumeName?;
        get volumeName(): string;
        set volumeName(value: string);
        get volumeNameInput(): string | undefined;
    }
    class SegmentConfigurationsPropertyList extends cdktn.ComplexList {
        internalValue?: SegmentConfigurationsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SegmentConfigurationsPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/finspace_kx_dataview#create AwsFinspaceKxDataview#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/finspace_kx_dataview#delete AwsFinspaceKxDataview#delete}
        */
        readonly delete?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/finspace_kx_dataview#update AwsFinspaceKxDataview#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
