import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfKxClusterConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/finspace_kx_cluster#availability_zone_id TfKxCluster#availability_zone_id}
    */
    readonly availabilityZoneId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/finspace_kx_cluster#az_mode TfKxCluster#az_mode}
    */
    readonly azMode: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/finspace_kx_cluster#command_line_arguments TfKxCluster#command_line_arguments}
    */
    readonly commandLineArguments?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/finspace_kx_cluster#description TfKxCluster#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/finspace_kx_cluster#environment_id TfKxCluster#environment_id}
    */
    readonly environmentId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/finspace_kx_cluster#execution_role TfKxCluster#execution_role}
    */
    readonly executionRole?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/finspace_kx_cluster#id TfKxCluster#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/finspace_kx_cluster#initialization_script TfKxCluster#initialization_script}
    */
    readonly initializationScript?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/finspace_kx_cluster#name TfKxCluster#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/finspace_kx_cluster#region TfKxCluster#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/finspace_kx_cluster#release_label TfKxCluster#release_label}
    */
    readonly releaseLabel: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/finspace_kx_cluster#tags TfKxCluster#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/finspace_kx_cluster#tags_all TfKxCluster#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/finspace_kx_cluster#type TfKxCluster#type}
    */
    readonly type: string;
    /**
    * auto_scaling_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/finspace_kx_cluster#auto_scaling_configuration TfKxCluster#auto_scaling_configuration}
    */
    readonly autoScalingConfiguration?: TfKxCluster.AutoScalingConfigurationProperty;
    /**
    * cache_storage_configurations block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/finspace_kx_cluster#cache_storage_configurations TfKxCluster#cache_storage_configurations}
    */
    readonly cacheStorageConfigurations?: TfKxCluster.CacheStorageConfigurationsProperty[] | cdktn.IResolvable;
    /**
    * capacity_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/finspace_kx_cluster#capacity_configuration TfKxCluster#capacity_configuration}
    */
    readonly capacityConfiguration?: TfKxCluster.CapacityConfigurationProperty;
    /**
    * code block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/finspace_kx_cluster#code TfKxCluster#code}
    */
    readonly code?: TfKxCluster.CodeProperty;
    /**
    * database block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/finspace_kx_cluster#database TfKxCluster#database}
    */
    readonly database?: TfKxCluster.DatabaseProperty[] | cdktn.IResolvable;
    /**
    * savedown_storage_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/finspace_kx_cluster#savedown_storage_configuration TfKxCluster#savedown_storage_configuration}
    */
    readonly savedownStorageConfiguration?: TfKxCluster.SavedownStorageConfigurationProperty;
    /**
    * scaling_group_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/finspace_kx_cluster#scaling_group_configuration TfKxCluster#scaling_group_configuration}
    */
    readonly scalingGroupConfiguration?: TfKxCluster.ScalingGroupConfigurationProperty;
    /**
    * tickerplant_log_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/finspace_kx_cluster#tickerplant_log_configuration TfKxCluster#tickerplant_log_configuration}
    */
    readonly tickerplantLogConfiguration?: TfKxCluster.TickerplantLogConfigurationProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/finspace_kx_cluster#timeouts TfKxCluster#timeouts}
    */
    readonly timeouts?: TfKxCluster.TimeoutsProperty;
    /**
    * vpc_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/finspace_kx_cluster#vpc_configuration TfKxCluster#vpc_configuration}
    */
    readonly vpcConfiguration: TfKxCluster.VpcConfigurationProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/finspace_kx_cluster aws_finspace_kx_cluster}
*/
export declare class TfKxCluster extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_finspace_kx_cluster";
    /**
    * Generates CDKTN code for importing a TfKxCluster resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfKxCluster to import
    * @param importFromId The id of the existing TfKxCluster that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/finspace_kx_cluster#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfKxCluster to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/finspace_kx_cluster aws_finspace_kx_cluster} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfKxClusterConfig
    */
    constructor(scope: Construct, id: string, config: TfKxClusterConfig);
    get arn(): string;
    private _availabilityZoneId?;
    get availabilityZoneId(): string;
    set availabilityZoneId(value: string);
    resetAvailabilityZoneId(): void;
    get availabilityZoneIdInput(): string | undefined;
    private _azMode?;
    get azMode(): string;
    set azMode(value: string);
    get azModeInput(): string | undefined;
    private _commandLineArguments?;
    get commandLineArguments(): {
        [key: string]: string;
    };
    set commandLineArguments(value: {
        [key: string]: string;
    });
    resetCommandLineArguments(): void;
    get commandLineArgumentsInput(): {
        [key: string]: string;
    } | undefined;
    get createdTimestamp(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _environmentId?;
    get environmentId(): string;
    set environmentId(value: string);
    get environmentIdInput(): string | undefined;
    private _executionRole?;
    get executionRole(): string;
    set executionRole(value: string);
    resetExecutionRole(): void;
    get executionRoleInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _initializationScript?;
    get initializationScript(): string;
    set initializationScript(value: string);
    resetInitializationScript(): void;
    get initializationScriptInput(): string | undefined;
    get lastModifiedTimestamp(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _releaseLabel?;
    get releaseLabel(): string;
    set releaseLabel(value: string);
    get releaseLabelInput(): string | undefined;
    get status(): string;
    get statusReason(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _autoScalingConfiguration;
    get autoScalingConfiguration(): TfKxCluster.AutoScalingConfigurationPropertyOutputReference;
    putAutoScalingConfiguration(value: TfKxCluster.AutoScalingConfigurationProperty): void;
    resetAutoScalingConfiguration(): void;
    get autoScalingConfigurationInput(): TfKxCluster.AutoScalingConfigurationProperty | undefined;
    private _cacheStorageConfigurations;
    get cacheStorageConfigurations(): TfKxCluster.CacheStorageConfigurationsPropertyList;
    putCacheStorageConfigurations(value: TfKxCluster.CacheStorageConfigurationsProperty[] | cdktn.IResolvable): void;
    resetCacheStorageConfigurations(): void;
    get cacheStorageConfigurationsInput(): cdktn.IResolvable | TfKxCluster.CacheStorageConfigurationsProperty[] | undefined;
    private _capacityConfiguration;
    get capacityConfiguration(): TfKxCluster.CapacityConfigurationPropertyOutputReference;
    putCapacityConfiguration(value: TfKxCluster.CapacityConfigurationProperty): void;
    resetCapacityConfiguration(): void;
    get capacityConfigurationInput(): TfKxCluster.CapacityConfigurationProperty | undefined;
    private _code;
    get code(): TfKxCluster.CodePropertyOutputReference;
    putCode(value: TfKxCluster.CodeProperty): void;
    resetCode(): void;
    get codeInput(): TfKxCluster.CodeProperty | undefined;
    private _database;
    get database(): TfKxCluster.DatabasePropertyList;
    putDatabase(value: TfKxCluster.DatabaseProperty[] | cdktn.IResolvable): void;
    resetDatabase(): void;
    get databaseInput(): cdktn.IResolvable | TfKxCluster.DatabaseProperty[] | undefined;
    private _savedownStorageConfiguration;
    get savedownStorageConfiguration(): TfKxCluster.SavedownStorageConfigurationPropertyOutputReference;
    putSavedownStorageConfiguration(value: TfKxCluster.SavedownStorageConfigurationProperty): void;
    resetSavedownStorageConfiguration(): void;
    get savedownStorageConfigurationInput(): TfKxCluster.SavedownStorageConfigurationProperty | undefined;
    private _scalingGroupConfiguration;
    get scalingGroupConfiguration(): TfKxCluster.ScalingGroupConfigurationPropertyOutputReference;
    putScalingGroupConfiguration(value: TfKxCluster.ScalingGroupConfigurationProperty): void;
    resetScalingGroupConfiguration(): void;
    get scalingGroupConfigurationInput(): TfKxCluster.ScalingGroupConfigurationProperty | undefined;
    private _tickerplantLogConfiguration;
    get tickerplantLogConfiguration(): TfKxCluster.TickerplantLogConfigurationPropertyList;
    putTickerplantLogConfiguration(value: TfKxCluster.TickerplantLogConfigurationProperty[] | cdktn.IResolvable): void;
    resetTickerplantLogConfiguration(): void;
    get tickerplantLogConfigurationInput(): cdktn.IResolvable | TfKxCluster.TickerplantLogConfigurationProperty[] | undefined;
    private _timeouts;
    get timeouts(): TfKxCluster.TimeoutsPropertyOutputReference;
    putTimeouts(value: TfKxCluster.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | TfKxCluster.TimeoutsProperty | undefined;
    private _vpcConfiguration;
    get vpcConfiguration(): TfKxCluster.VpcConfigurationPropertyOutputReference;
    putVpcConfiguration(value: TfKxCluster.VpcConfigurationProperty): void;
    get vpcConfigurationInput(): TfKxCluster.VpcConfigurationProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfKxClusterAutoScalingConfigurationPropertyToTerraform(struct?: TfKxCluster.AutoScalingConfigurationPropertyOutputReference | TfKxCluster.AutoScalingConfigurationProperty): any;
export declare function tfKxClusterAutoScalingConfigurationPropertyToHclTerraform(struct?: TfKxCluster.AutoScalingConfigurationPropertyOutputReference | TfKxCluster.AutoScalingConfigurationProperty): any;
export declare function tfKxClusterCacheStorageConfigurationsPropertyToTerraform(struct?: TfKxCluster.CacheStorageConfigurationsProperty | cdktn.IResolvable): any;
export declare function tfKxClusterCacheStorageConfigurationsPropertyToHclTerraform(struct?: TfKxCluster.CacheStorageConfigurationsProperty | cdktn.IResolvable): any;
export declare function tfKxClusterCapacityConfigurationPropertyToTerraform(struct?: TfKxCluster.CapacityConfigurationPropertyOutputReference | TfKxCluster.CapacityConfigurationProperty): any;
export declare function tfKxClusterCapacityConfigurationPropertyToHclTerraform(struct?: TfKxCluster.CapacityConfigurationPropertyOutputReference | TfKxCluster.CapacityConfigurationProperty): any;
export declare function tfKxClusterCodePropertyToTerraform(struct?: TfKxCluster.CodePropertyOutputReference | TfKxCluster.CodeProperty): any;
export declare function tfKxClusterCodePropertyToHclTerraform(struct?: TfKxCluster.CodePropertyOutputReference | TfKxCluster.CodeProperty): any;
export declare function tfKxClusterCacheConfigurationsPropertyToTerraform(struct?: TfKxCluster.CacheConfigurationsProperty | cdktn.IResolvable): any;
export declare function tfKxClusterCacheConfigurationsPropertyToHclTerraform(struct?: TfKxCluster.CacheConfigurationsProperty | cdktn.IResolvable): any;
export declare function tfKxClusterDatabasePropertyToTerraform(struct?: TfKxCluster.DatabaseProperty | cdktn.IResolvable): any;
export declare function tfKxClusterDatabasePropertyToHclTerraform(struct?: TfKxCluster.DatabaseProperty | cdktn.IResolvable): any;
export declare function tfKxClusterSavedownStorageConfigurationPropertyToTerraform(struct?: TfKxCluster.SavedownStorageConfigurationPropertyOutputReference | TfKxCluster.SavedownStorageConfigurationProperty): any;
export declare function tfKxClusterSavedownStorageConfigurationPropertyToHclTerraform(struct?: TfKxCluster.SavedownStorageConfigurationPropertyOutputReference | TfKxCluster.SavedownStorageConfigurationProperty): any;
export declare function tfKxClusterScalingGroupConfigurationPropertyToTerraform(struct?: TfKxCluster.ScalingGroupConfigurationPropertyOutputReference | TfKxCluster.ScalingGroupConfigurationProperty): any;
export declare function tfKxClusterScalingGroupConfigurationPropertyToHclTerraform(struct?: TfKxCluster.ScalingGroupConfigurationPropertyOutputReference | TfKxCluster.ScalingGroupConfigurationProperty): any;
export declare function tfKxClusterTickerplantLogConfigurationPropertyToTerraform(struct?: TfKxCluster.TickerplantLogConfigurationProperty | cdktn.IResolvable): any;
export declare function tfKxClusterTickerplantLogConfigurationPropertyToHclTerraform(struct?: TfKxCluster.TickerplantLogConfigurationProperty | cdktn.IResolvable): any;
export declare function tfKxClusterTimeoutsPropertyToTerraform(struct?: TfKxCluster.TimeoutsProperty | cdktn.IResolvable): any;
export declare function tfKxClusterTimeoutsPropertyToHclTerraform(struct?: TfKxCluster.TimeoutsProperty | cdktn.IResolvable): any;
export declare function tfKxClusterVpcConfigurationPropertyToTerraform(struct?: TfKxCluster.VpcConfigurationPropertyOutputReference | TfKxCluster.VpcConfigurationProperty): any;
export declare function tfKxClusterVpcConfigurationPropertyToHclTerraform(struct?: TfKxCluster.VpcConfigurationPropertyOutputReference | TfKxCluster.VpcConfigurationProperty): any;
export declare namespace TfKxCluster {
    interface AutoScalingConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/finspace_kx_cluster#auto_scaling_metric TfKxCluster#auto_scaling_metric}
        */
        readonly autoScalingMetric: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/finspace_kx_cluster#max_node_count TfKxCluster#max_node_count}
        */
        readonly maxNodeCount: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/finspace_kx_cluster#metric_target TfKxCluster#metric_target}
        */
        readonly metricTarget: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/finspace_kx_cluster#min_node_count TfKxCluster#min_node_count}
        */
        readonly minNodeCount: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/finspace_kx_cluster#scale_in_cooldown_seconds TfKxCluster#scale_in_cooldown_seconds}
        */
        readonly scaleInCooldownSeconds: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/finspace_kx_cluster#scale_out_cooldown_seconds TfKxCluster#scale_out_cooldown_seconds}
        */
        readonly scaleOutCooldownSeconds: number;
    }
    class AutoScalingConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AutoScalingConfigurationProperty | undefined;
        set internalValue(value: AutoScalingConfigurationProperty | undefined);
        private _autoScalingMetric?;
        get autoScalingMetric(): string;
        set autoScalingMetric(value: string);
        get autoScalingMetricInput(): string | undefined;
        private _maxNodeCount?;
        get maxNodeCount(): number;
        set maxNodeCount(value: number);
        get maxNodeCountInput(): number | undefined;
        private _metricTarget?;
        get metricTarget(): number;
        set metricTarget(value: number);
        get metricTargetInput(): number | undefined;
        private _minNodeCount?;
        get minNodeCount(): number;
        set minNodeCount(value: number);
        get minNodeCountInput(): number | undefined;
        private _scaleInCooldownSeconds?;
        get scaleInCooldownSeconds(): number;
        set scaleInCooldownSeconds(value: number);
        get scaleInCooldownSecondsInput(): number | undefined;
        private _scaleOutCooldownSeconds?;
        get scaleOutCooldownSeconds(): number;
        set scaleOutCooldownSeconds(value: number);
        get scaleOutCooldownSecondsInput(): number | undefined;
    }
    interface CacheStorageConfigurationsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/finspace_kx_cluster#size TfKxCluster#size}
        */
        readonly size: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/finspace_kx_cluster#type TfKxCluster#type}
        */
        readonly type: string;
    }
    class CacheStorageConfigurationsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CacheStorageConfigurationsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CacheStorageConfigurationsProperty | cdktn.IResolvable | undefined);
        private _size?;
        get size(): number;
        set size(value: number);
        get sizeInput(): number | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
    }
    class CacheStorageConfigurationsPropertyList extends cdktn.ComplexList {
        internalValue?: CacheStorageConfigurationsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CacheStorageConfigurationsPropertyOutputReference;
    }
    interface CapacityConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/finspace_kx_cluster#node_count TfKxCluster#node_count}
        */
        readonly nodeCount: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/finspace_kx_cluster#node_type TfKxCluster#node_type}
        */
        readonly nodeType: string;
    }
    class CapacityConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CapacityConfigurationProperty | undefined;
        set internalValue(value: CapacityConfigurationProperty | undefined);
        private _nodeCount?;
        get nodeCount(): number;
        set nodeCount(value: number);
        get nodeCountInput(): number | undefined;
        private _nodeType?;
        get nodeType(): string;
        set nodeType(value: string);
        get nodeTypeInput(): string | undefined;
    }
    interface CodeProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/finspace_kx_cluster#s3_bucket TfKxCluster#s3_bucket}
        */
        readonly s3Bucket: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/finspace_kx_cluster#s3_key TfKxCluster#s3_key}
        */
        readonly s3Key: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/finspace_kx_cluster#s3_object_version TfKxCluster#s3_object_version}
        */
        readonly s3ObjectVersion?: string;
    }
    class CodePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CodeProperty | undefined;
        set internalValue(value: CodeProperty | undefined);
        private _s3Bucket?;
        get s3Bucket(): string;
        set s3Bucket(value: string);
        get s3BucketInput(): string | undefined;
        private _s3Key?;
        get s3Key(): string;
        set s3Key(value: string);
        get s3KeyInput(): string | undefined;
        private _s3ObjectVersion?;
        get s3ObjectVersion(): string;
        set s3ObjectVersion(value: string);
        resetS3ObjectVersion(): void;
        get s3ObjectVersionInput(): string | undefined;
    }
    interface CacheConfigurationsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/finspace_kx_cluster#cache_type TfKxCluster#cache_type}
        */
        readonly cacheType: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/finspace_kx_cluster#db_paths TfKxCluster#db_paths}
        */
        readonly dbPaths?: string[];
    }
    class CacheConfigurationsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CacheConfigurationsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CacheConfigurationsProperty | cdktn.IResolvable | undefined);
        private _cacheType?;
        get cacheType(): string;
        set cacheType(value: string);
        get cacheTypeInput(): string | undefined;
        private _dbPaths?;
        get dbPaths(): string[];
        set dbPaths(value: string[]);
        resetDbPaths(): void;
        get dbPathsInput(): string[] | undefined;
    }
    class CacheConfigurationsPropertyList extends cdktn.ComplexList {
        internalValue?: CacheConfigurationsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CacheConfigurationsPropertyOutputReference;
    }
    interface DatabaseProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/finspace_kx_cluster#changeset_id TfKxCluster#changeset_id}
        */
        readonly changesetId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/finspace_kx_cluster#database_name TfKxCluster#database_name}
        */
        readonly databaseName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/finspace_kx_cluster#dataview_name TfKxCluster#dataview_name}
        */
        readonly dataviewName?: string;
        /**
        * cache_configurations block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/finspace_kx_cluster#cache_configurations TfKxCluster#cache_configurations}
        */
        readonly cacheConfigurations?: CacheConfigurationsProperty[] | cdktn.IResolvable;
    }
    class DatabasePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DatabaseProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DatabaseProperty | cdktn.IResolvable | undefined);
        private _changesetId?;
        get changesetId(): string;
        set changesetId(value: string);
        resetChangesetId(): void;
        get changesetIdInput(): string | undefined;
        private _databaseName?;
        get databaseName(): string;
        set databaseName(value: string);
        get databaseNameInput(): string | undefined;
        private _dataviewName?;
        get dataviewName(): string;
        set dataviewName(value: string);
        resetDataviewName(): void;
        get dataviewNameInput(): string | undefined;
        private _cacheConfigurations;
        get cacheConfigurations(): CacheConfigurationsPropertyList;
        putCacheConfigurations(value: CacheConfigurationsProperty[] | cdktn.IResolvable): void;
        resetCacheConfigurations(): void;
        get cacheConfigurationsInput(): cdktn.IResolvable | CacheConfigurationsProperty[] | undefined;
    }
    class DatabasePropertyList extends cdktn.ComplexList {
        internalValue?: DatabaseProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DatabasePropertyOutputReference;
    }
    interface SavedownStorageConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/finspace_kx_cluster#size TfKxCluster#size}
        */
        readonly size?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/finspace_kx_cluster#type TfKxCluster#type}
        */
        readonly type?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/finspace_kx_cluster#volume_name TfKxCluster#volume_name}
        */
        readonly volumeName?: string;
    }
    class SavedownStorageConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SavedownStorageConfigurationProperty | undefined;
        set internalValue(value: SavedownStorageConfigurationProperty | undefined);
        private _size?;
        get size(): number;
        set size(value: number);
        resetSize(): void;
        get sizeInput(): number | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        resetType(): void;
        get typeInput(): string | undefined;
        private _volumeName?;
        get volumeName(): string;
        set volumeName(value: string);
        resetVolumeName(): void;
        get volumeNameInput(): string | undefined;
    }
    interface ScalingGroupConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/finspace_kx_cluster#cpu TfKxCluster#cpu}
        */
        readonly cpu?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/finspace_kx_cluster#memory_limit TfKxCluster#memory_limit}
        */
        readonly memoryLimit?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/finspace_kx_cluster#memory_reservation TfKxCluster#memory_reservation}
        */
        readonly memoryReservation: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/finspace_kx_cluster#node_count TfKxCluster#node_count}
        */
        readonly nodeCount: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/finspace_kx_cluster#scaling_group_name TfKxCluster#scaling_group_name}
        */
        readonly scalingGroupName: string;
    }
    class ScalingGroupConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ScalingGroupConfigurationProperty | undefined;
        set internalValue(value: ScalingGroupConfigurationProperty | undefined);
        private _cpu?;
        get cpu(): number;
        set cpu(value: number);
        resetCpu(): void;
        get cpuInput(): number | undefined;
        private _memoryLimit?;
        get memoryLimit(): number;
        set memoryLimit(value: number);
        resetMemoryLimit(): void;
        get memoryLimitInput(): number | undefined;
        private _memoryReservation?;
        get memoryReservation(): number;
        set memoryReservation(value: number);
        get memoryReservationInput(): number | undefined;
        private _nodeCount?;
        get nodeCount(): number;
        set nodeCount(value: number);
        get nodeCountInput(): number | undefined;
        private _scalingGroupName?;
        get scalingGroupName(): string;
        set scalingGroupName(value: string);
        get scalingGroupNameInput(): string | undefined;
    }
    interface TickerplantLogConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/finspace_kx_cluster#tickerplant_log_volumes TfKxCluster#tickerplant_log_volumes}
        */
        readonly tickerplantLogVolumes: string[];
    }
    class TickerplantLogConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TickerplantLogConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TickerplantLogConfigurationProperty | cdktn.IResolvable | undefined);
        private _tickerplantLogVolumes?;
        get tickerplantLogVolumes(): string[];
        set tickerplantLogVolumes(value: string[]);
        get tickerplantLogVolumesInput(): string[] | undefined;
    }
    class TickerplantLogConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: TickerplantLogConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TickerplantLogConfigurationPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/finspace_kx_cluster#create TfKxCluster#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/finspace_kx_cluster#delete TfKxCluster#delete}
        */
        readonly delete?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/finspace_kx_cluster#update TfKxCluster#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
    interface VpcConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/finspace_kx_cluster#ip_address_type TfKxCluster#ip_address_type}
        */
        readonly ipAddressType: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/finspace_kx_cluster#security_group_ids TfKxCluster#security_group_ids}
        */
        readonly securityGroupIds: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/finspace_kx_cluster#subnet_ids TfKxCluster#subnet_ids}
        */
        readonly subnetIds: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/finspace_kx_cluster#vpc_id TfKxCluster#vpc_id}
        */
        readonly vpcId: string;
    }
    class VpcConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): VpcConfigurationProperty | undefined;
        set internalValue(value: VpcConfigurationProperty | undefined);
        private _ipAddressType?;
        get ipAddressType(): string;
        set ipAddressType(value: string);
        get ipAddressTypeInput(): string | undefined;
        private _securityGroupIds?;
        get securityGroupIds(): string[];
        set securityGroupIds(value: string[]);
        get securityGroupIdsInput(): string[] | undefined;
        private _subnetIds?;
        get subnetIds(): string[];
        set subnetIds(value: string[]);
        get subnetIdsInput(): string[] | undefined;
        private _vpcId?;
        get vpcId(): string;
        set vpcId(value: string);
        get vpcIdInput(): string | undefined;
    }
}
