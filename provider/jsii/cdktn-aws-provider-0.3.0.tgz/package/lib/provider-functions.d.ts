import * as cdktn from 'cdktn';
/**
* Provider-defined functions of the aws provider.
*/
export declare class AwsProviderFunctions {
    private readonly providerLocalName;
    /**
    * @param providerLocalName The local name of the provider in required_providers; defaults to the registry short name. Override when the provider is declared under a different local name — aliases do not change the namespace, local names do.
    */
    constructor(providerLocalName: string);
    /**
    * Builds an ARN from its constituent parts
    * @param {string} partition - Partition in which the resource is located
    * @param {string} service - Service namespace
    * @param {string} region - Region code
    * @param {string} accountId - AWS account identifier
    * @param {string} resource - Resource section, typically composed of a resource type and identifier
    * @returns {string}
    */
    arnBuild(partition: string, service: string, region: string, accountId: string, resource: string): string;
    /**
    * Parses an ARN into its constituent parts
    * @param {string} arn - ARN (Amazon Resource Name) to parse
    * @returns {object}
    */
    arnParse(arn: string): cdktn.IResolvable;
    /**
    * Trims the path prefix from an IAM role Amazon Resource Name (ARN). This function can be used when services require role ARNs to be passed without a path.
    * @param {string} arn - IAM role Amazon Resource Name (ARN)
    * @returns {string}
    */
    trimIamRolePath(arn: string): string;
    /**
    * Formats a User-Agent product for use with the user_agent argument in the provider or provider_meta block.
    * @param {string} productName - Product name.
    * @param {string} productVersion - Product version.
    * @param {string} comment - Comment describing any additional product details.
    * @returns {string}
    */
    userAgent(productName: string, productVersion: string, comment: string): string;
}
