import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsTypeConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudformation_type#execution_role_arn AwsType#execution_role_arn}
    */
    readonly executionRoleArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudformation_type#id AwsType#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudformation_type#region AwsType#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudformation_type#schema_handler_package AwsType#schema_handler_package}
    */
    readonly schemaHandlerPackage: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudformation_type#type AwsType#type}
    */
    readonly type?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudformation_type#type_name AwsType#type_name}
    */
    readonly typeName: string;
    /**
    * logging_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudformation_type#logging_config AwsType#logging_config}
    */
    readonly loggingConfig?: AwsType.LoggingConfigProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudformation_type aws_cloudformation_type}
*/
export declare class AwsType extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_cloudformation_type";
    /**
    * Generates CDKTN code for importing a AwsType resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsType to import
    * @param importFromId The id of the existing AwsType that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudformation_type#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsType to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudformation_type aws_cloudformation_type} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsTypeConfig
    */
    constructor(scope: Construct, id: string, config: AwsTypeConfig);
    get arn(): string;
    get defaultVersionId(): string;
    get deprecatedStatus(): string;
    get description(): string;
    get documentationUrl(): string;
    private _executionRoleArn?;
    get executionRoleArn(): string;
    set executionRoleArn(value: string);
    resetExecutionRoleArn(): void;
    get executionRoleArnInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get isDefaultVersion(): cdktn.IResolvable;
    get provisioningType(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get schema(): string;
    private _schemaHandlerPackage?;
    get schemaHandlerPackage(): string;
    set schemaHandlerPackage(value: string);
    get schemaHandlerPackageInput(): string | undefined;
    get sourceUrl(): string;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
    get typeArn(): string;
    private _typeName?;
    get typeName(): string;
    set typeName(value: string);
    get typeNameInput(): string | undefined;
    get versionId(): string;
    get visibility(): string;
    private _loggingConfig;
    get loggingConfig(): AwsType.LoggingConfigPropertyOutputReference;
    putLoggingConfig(value: AwsType.LoggingConfigProperty): void;
    resetLoggingConfig(): void;
    get loggingConfigInput(): AwsType.LoggingConfigProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsTypeLoggingConfigPropertyToTerraform(struct?: AwsType.LoggingConfigPropertyOutputReference | AwsType.LoggingConfigProperty): any;
export declare function awsTypeLoggingConfigPropertyToHclTerraform(struct?: AwsType.LoggingConfigPropertyOutputReference | AwsType.LoggingConfigProperty): any;
export declare namespace AwsType {
    interface LoggingConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudformation_type#log_group_name AwsType#log_group_name}
        */
        readonly logGroupName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudformation_type#log_role_arn AwsType#log_role_arn}
        */
        readonly logRoleArn: string;
    }
    class LoggingConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): LoggingConfigProperty | undefined;
        set internalValue(value: LoggingConfigProperty | undefined);
        private _logGroupName?;
        get logGroupName(): string;
        set logGroupName(value: string);
        get logGroupNameInput(): string | undefined;
        private _logRoleArn?;
        get logRoleArn(): string;
        set logRoleArn(value: string);
        get logRoleArnInput(): string | undefined;
    }
}
