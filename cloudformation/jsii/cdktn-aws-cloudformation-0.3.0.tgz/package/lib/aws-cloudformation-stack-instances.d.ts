import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsStackInstancesConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudformation_stack_instances#accounts AwsStackInstances#accounts}
    */
    readonly accounts?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudformation_stack_instances#call_as AwsStackInstances#call_as}
    */
    readonly callAs?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudformation_stack_instances#id AwsStackInstances#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudformation_stack_instances#parameter_overrides AwsStackInstances#parameter_overrides}
    */
    readonly parameterOverrides?: {
        [key: string]: string;
    };
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudformation_stack_instances#region AwsStackInstances#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudformation_stack_instances#regions AwsStackInstances#regions}
    */
    readonly regions?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudformation_stack_instances#retain_stacks AwsStackInstances#retain_stacks}
    */
    readonly retainStacks?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudformation_stack_instances#stack_set_name AwsStackInstances#stack_set_name}
    */
    readonly stackSetName: string;
    /**
    * deployment_targets block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudformation_stack_instances#deployment_targets AwsStackInstances#deployment_targets}
    */
    readonly deploymentTargets?: AwsStackInstances.DeploymentTargetsProperty;
    /**
    * operation_preferences block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudformation_stack_instances#operation_preferences AwsStackInstances#operation_preferences}
    */
    readonly operationPreferences?: AwsStackInstances.OperationPreferencesProperty;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudformation_stack_instances#timeouts AwsStackInstances#timeouts}
    */
    readonly timeouts?: AwsStackInstances.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudformation_stack_instances aws_cloudformation_stack_instances}
*/
export declare class AwsStackInstances extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_cloudformation_stack_instances";
    /**
    * Generates CDKTN code for importing a AwsStackInstances resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsStackInstances to import
    * @param importFromId The id of the existing AwsStackInstances that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudformation_stack_instances#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsStackInstances to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudformation_stack_instances aws_cloudformation_stack_instances} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsStackInstancesConfig
    */
    constructor(scope: Construct, id: string, config: AwsStackInstancesConfig);
    private _accounts?;
    get accounts(): string[];
    set accounts(value: string[]);
    resetAccounts(): void;
    get accountsInput(): string[] | undefined;
    private _callAs?;
    get callAs(): string;
    set callAs(value: string);
    resetCallAs(): void;
    get callAsInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _parameterOverrides?;
    get parameterOverrides(): {
        [key: string]: string;
    };
    set parameterOverrides(value: {
        [key: string]: string;
    });
    resetParameterOverrides(): void;
    get parameterOverridesInput(): {
        [key: string]: string;
    } | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _regions?;
    get regions(): string[];
    set regions(value: string[]);
    resetRegions(): void;
    get regionsInput(): string[] | undefined;
    private _retainStacks?;
    get retainStacks(): boolean | cdktn.IResolvable;
    set retainStacks(value: boolean | cdktn.IResolvable);
    resetRetainStacks(): void;
    get retainStacksInput(): boolean | cdktn.IResolvable | undefined;
    private _stackInstanceSummaries;
    get stackInstanceSummaries(): AwsStackInstances.StackInstanceSummariesPropertyList;
    get stackSetId(): string;
    private _stackSetName?;
    get stackSetName(): string;
    set stackSetName(value: string);
    get stackSetNameInput(): string | undefined;
    private _deploymentTargets;
    get deploymentTargets(): AwsStackInstances.DeploymentTargetsPropertyOutputReference;
    putDeploymentTargets(value: AwsStackInstances.DeploymentTargetsProperty): void;
    resetDeploymentTargets(): void;
    get deploymentTargetsInput(): AwsStackInstances.DeploymentTargetsProperty | undefined;
    private _operationPreferences;
    get operationPreferences(): AwsStackInstances.OperationPreferencesPropertyOutputReference;
    putOperationPreferences(value: AwsStackInstances.OperationPreferencesProperty): void;
    resetOperationPreferences(): void;
    get operationPreferencesInput(): AwsStackInstances.OperationPreferencesProperty | undefined;
    private _timeouts;
    get timeouts(): AwsStackInstances.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsStackInstances.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsStackInstances.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsStackInstancesStackInstanceSummariesPropertyToTerraform(struct?: AwsStackInstances.StackInstanceSummariesProperty): any;
export declare function awsStackInstancesStackInstanceSummariesPropertyToHclTerraform(struct?: AwsStackInstances.StackInstanceSummariesProperty): any;
export declare function awsStackInstancesDeploymentTargetsPropertyToTerraform(struct?: AwsStackInstances.DeploymentTargetsPropertyOutputReference | AwsStackInstances.DeploymentTargetsProperty): any;
export declare function awsStackInstancesDeploymentTargetsPropertyToHclTerraform(struct?: AwsStackInstances.DeploymentTargetsPropertyOutputReference | AwsStackInstances.DeploymentTargetsProperty): any;
export declare function awsStackInstancesOperationPreferencesPropertyToTerraform(struct?: AwsStackInstances.OperationPreferencesPropertyOutputReference | AwsStackInstances.OperationPreferencesProperty): any;
export declare function awsStackInstancesOperationPreferencesPropertyToHclTerraform(struct?: AwsStackInstances.OperationPreferencesPropertyOutputReference | AwsStackInstances.OperationPreferencesProperty): any;
export declare function awsStackInstancesTimeoutsPropertyToTerraform(struct?: AwsStackInstances.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsStackInstancesTimeoutsPropertyToHclTerraform(struct?: AwsStackInstances.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsStackInstances {
    interface StackInstanceSummariesProperty {
    }
    class StackInstanceSummariesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): StackInstanceSummariesProperty | undefined;
        set internalValue(value: StackInstanceSummariesProperty | undefined);
        get accountId(): string;
        get detailedStatus(): string;
        get driftStatus(): string;
        get organizationalUnitId(): string;
        get region(): string;
        get stackId(): string;
        get stackSetId(): string;
        get status(): string;
        get statusReason(): string;
    }
    class StackInstanceSummariesPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): StackInstanceSummariesPropertyOutputReference;
    }
    interface DeploymentTargetsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudformation_stack_instances#account_filter_type AwsStackInstances#account_filter_type}
        */
        readonly accountFilterType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudformation_stack_instances#accounts AwsStackInstances#accounts}
        */
        readonly accounts?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudformation_stack_instances#accounts_url AwsStackInstances#accounts_url}
        */
        readonly accountsUrl?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudformation_stack_instances#organizational_unit_ids AwsStackInstances#organizational_unit_ids}
        */
        readonly organizationalUnitIds?: string[];
    }
    class DeploymentTargetsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DeploymentTargetsProperty | undefined;
        set internalValue(value: DeploymentTargetsProperty | undefined);
        private _accountFilterType?;
        get accountFilterType(): string;
        set accountFilterType(value: string);
        resetAccountFilterType(): void;
        get accountFilterTypeInput(): string | undefined;
        private _accounts?;
        get accounts(): string[];
        set accounts(value: string[]);
        resetAccounts(): void;
        get accountsInput(): string[] | undefined;
        private _accountsUrl?;
        get accountsUrl(): string;
        set accountsUrl(value: string);
        resetAccountsUrl(): void;
        get accountsUrlInput(): string | undefined;
        private _organizationalUnitIds?;
        get organizationalUnitIds(): string[];
        set organizationalUnitIds(value: string[]);
        resetOrganizationalUnitIds(): void;
        get organizationalUnitIdsInput(): string[] | undefined;
    }
    interface OperationPreferencesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudformation_stack_instances#concurrency_mode AwsStackInstances#concurrency_mode}
        */
        readonly concurrencyMode?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudformation_stack_instances#failure_tolerance_count AwsStackInstances#failure_tolerance_count}
        */
        readonly failureToleranceCount?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudformation_stack_instances#failure_tolerance_percentage AwsStackInstances#failure_tolerance_percentage}
        */
        readonly failureTolerancePercentage?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudformation_stack_instances#max_concurrent_count AwsStackInstances#max_concurrent_count}
        */
        readonly maxConcurrentCount?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudformation_stack_instances#max_concurrent_percentage AwsStackInstances#max_concurrent_percentage}
        */
        readonly maxConcurrentPercentage?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudformation_stack_instances#region_concurrency_type AwsStackInstances#region_concurrency_type}
        */
        readonly regionConcurrencyType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudformation_stack_instances#region_order AwsStackInstances#region_order}
        */
        readonly regionOrder?: string[];
    }
    class OperationPreferencesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): OperationPreferencesProperty | undefined;
        set internalValue(value: OperationPreferencesProperty | undefined);
        private _concurrencyMode?;
        get concurrencyMode(): string;
        set concurrencyMode(value: string);
        resetConcurrencyMode(): void;
        get concurrencyModeInput(): string | undefined;
        private _failureToleranceCount?;
        get failureToleranceCount(): number;
        set failureToleranceCount(value: number);
        resetFailureToleranceCount(): void;
        get failureToleranceCountInput(): number | undefined;
        private _failureTolerancePercentage?;
        get failureTolerancePercentage(): number;
        set failureTolerancePercentage(value: number);
        resetFailureTolerancePercentage(): void;
        get failureTolerancePercentageInput(): number | undefined;
        private _maxConcurrentCount?;
        get maxConcurrentCount(): number;
        set maxConcurrentCount(value: number);
        resetMaxConcurrentCount(): void;
        get maxConcurrentCountInput(): number | undefined;
        private _maxConcurrentPercentage?;
        get maxConcurrentPercentage(): number;
        set maxConcurrentPercentage(value: number);
        resetMaxConcurrentPercentage(): void;
        get maxConcurrentPercentageInput(): number | undefined;
        private _regionConcurrencyType?;
        get regionConcurrencyType(): string;
        set regionConcurrencyType(value: string);
        resetRegionConcurrencyType(): void;
        get regionConcurrencyTypeInput(): string | undefined;
        private _regionOrder?;
        get regionOrder(): string[];
        set regionOrder(value: string[]);
        resetRegionOrder(): void;
        get regionOrderInput(): string[] | undefined;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudformation_stack_instances#create AwsStackInstances#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudformation_stack_instances#delete AwsStackInstances#delete}
        */
        readonly delete?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudformation_stack_instances#update AwsStackInstances#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
