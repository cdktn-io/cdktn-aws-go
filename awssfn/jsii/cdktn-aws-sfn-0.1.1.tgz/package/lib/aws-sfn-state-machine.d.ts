import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsSfnStateMachineConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sfn_state_machine#definition AwsSfnStateMachine#definition}
    */
    readonly definition: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sfn_state_machine#id AwsSfnStateMachine#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sfn_state_machine#name AwsSfnStateMachine#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sfn_state_machine#name_prefix AwsSfnStateMachine#name_prefix}
    */
    readonly namePrefix?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sfn_state_machine#publish AwsSfnStateMachine#publish}
    */
    readonly publish?: boolean | cdktn.IResolvable;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sfn_state_machine#region AwsSfnStateMachine#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sfn_state_machine#role_arn AwsSfnStateMachine#role_arn}
    */
    readonly roleArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sfn_state_machine#tags AwsSfnStateMachine#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sfn_state_machine#tags_all AwsSfnStateMachine#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sfn_state_machine#type AwsSfnStateMachine#type}
    */
    readonly type?: string;
    /**
    * encryption_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sfn_state_machine#encryption_configuration AwsSfnStateMachine#encryption_configuration}
    */
    readonly encryptionConfiguration?: AwsSfnStateMachine.EncryptionConfigurationProperty;
    /**
    * logging_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sfn_state_machine#logging_configuration AwsSfnStateMachine#logging_configuration}
    */
    readonly loggingConfiguration?: AwsSfnStateMachine.LoggingConfigurationProperty;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sfn_state_machine#timeouts AwsSfnStateMachine#timeouts}
    */
    readonly timeouts?: AwsSfnStateMachine.TimeoutsProperty;
    /**
    * tracing_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sfn_state_machine#tracing_configuration AwsSfnStateMachine#tracing_configuration}
    */
    readonly tracingConfiguration?: AwsSfnStateMachine.TracingConfigurationProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sfn_state_machine aws_sfn_state_machine}
*/
export declare class AwsSfnStateMachine extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_sfn_state_machine";
    /**
    * Generates CDKTN code for importing a AwsSfnStateMachine resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsSfnStateMachine to import
    * @param importFromId The id of the existing AwsSfnStateMachine that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sfn_state_machine#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsSfnStateMachine to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sfn_state_machine aws_sfn_state_machine} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsSfnStateMachineConfig
    */
    constructor(scope: Construct, id: string, config: AwsSfnStateMachineConfig);
    get arn(): string;
    get creationDate(): string;
    private _definition?;
    get definition(): string;
    set definition(value: string);
    get definitionInput(): string | undefined;
    get description(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _namePrefix?;
    get namePrefix(): string;
    set namePrefix(value: string);
    resetNamePrefix(): void;
    get namePrefixInput(): string | undefined;
    private _publish?;
    get publish(): boolean | cdktn.IResolvable;
    set publish(value: boolean | cdktn.IResolvable);
    resetPublish(): void;
    get publishInput(): boolean | cdktn.IResolvable | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get revisionId(): string;
    private _roleArn?;
    get roleArn(): string;
    set roleArn(value: string);
    get roleArnInput(): string | undefined;
    get stateMachineVersionArn(): string;
    get status(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
    get versionDescription(): string;
    private _encryptionConfiguration;
    get encryptionConfiguration(): AwsSfnStateMachine.EncryptionConfigurationPropertyOutputReference;
    putEncryptionConfiguration(value: AwsSfnStateMachine.EncryptionConfigurationProperty): void;
    resetEncryptionConfiguration(): void;
    get encryptionConfigurationInput(): AwsSfnStateMachine.EncryptionConfigurationProperty | undefined;
    private _loggingConfiguration;
    get loggingConfiguration(): AwsSfnStateMachine.LoggingConfigurationPropertyOutputReference;
    putLoggingConfiguration(value: AwsSfnStateMachine.LoggingConfigurationProperty): void;
    resetLoggingConfiguration(): void;
    get loggingConfigurationInput(): AwsSfnStateMachine.LoggingConfigurationProperty | undefined;
    private _timeouts;
    get timeouts(): AwsSfnStateMachine.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsSfnStateMachine.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsSfnStateMachine.TimeoutsProperty | undefined;
    private _tracingConfiguration;
    get tracingConfiguration(): AwsSfnStateMachine.TracingConfigurationPropertyOutputReference;
    putTracingConfiguration(value: AwsSfnStateMachine.TracingConfigurationProperty): void;
    resetTracingConfiguration(): void;
    get tracingConfigurationInput(): AwsSfnStateMachine.TracingConfigurationProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsSfnStateMachineEncryptionConfigurationPropertyToTerraform(struct?: AwsSfnStateMachine.EncryptionConfigurationPropertyOutputReference | AwsSfnStateMachine.EncryptionConfigurationProperty): any;
export declare function awsSfnStateMachineEncryptionConfigurationPropertyToHclTerraform(struct?: AwsSfnStateMachine.EncryptionConfigurationPropertyOutputReference | AwsSfnStateMachine.EncryptionConfigurationProperty): any;
export declare function awsSfnStateMachineLoggingConfigurationPropertyToTerraform(struct?: AwsSfnStateMachine.LoggingConfigurationPropertyOutputReference | AwsSfnStateMachine.LoggingConfigurationProperty): any;
export declare function awsSfnStateMachineLoggingConfigurationPropertyToHclTerraform(struct?: AwsSfnStateMachine.LoggingConfigurationPropertyOutputReference | AwsSfnStateMachine.LoggingConfigurationProperty): any;
export declare function awsSfnStateMachineTimeoutsPropertyToTerraform(struct?: AwsSfnStateMachine.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsSfnStateMachineTimeoutsPropertyToHclTerraform(struct?: AwsSfnStateMachine.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsSfnStateMachineTracingConfigurationPropertyToTerraform(struct?: AwsSfnStateMachine.TracingConfigurationPropertyOutputReference | AwsSfnStateMachine.TracingConfigurationProperty): any;
export declare function awsSfnStateMachineTracingConfigurationPropertyToHclTerraform(struct?: AwsSfnStateMachine.TracingConfigurationPropertyOutputReference | AwsSfnStateMachine.TracingConfigurationProperty): any;
export declare namespace AwsSfnStateMachine {
    interface EncryptionConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sfn_state_machine#kms_data_key_reuse_period_seconds AwsSfnStateMachine#kms_data_key_reuse_period_seconds}
        */
        readonly kmsDataKeyReusePeriodSeconds?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sfn_state_machine#kms_key_id AwsSfnStateMachine#kms_key_id}
        */
        readonly kmsKeyId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sfn_state_machine#type AwsSfnStateMachine#type}
        */
        readonly type?: string;
    }
    class EncryptionConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): EncryptionConfigurationProperty | undefined;
        set internalValue(value: EncryptionConfigurationProperty | undefined);
        private _kmsDataKeyReusePeriodSeconds?;
        get kmsDataKeyReusePeriodSeconds(): number;
        set kmsDataKeyReusePeriodSeconds(value: number);
        resetKmsDataKeyReusePeriodSeconds(): void;
        get kmsDataKeyReusePeriodSecondsInput(): number | undefined;
        private _kmsKeyId?;
        get kmsKeyId(): string;
        set kmsKeyId(value: string);
        resetKmsKeyId(): void;
        get kmsKeyIdInput(): string | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        resetType(): void;
        get typeInput(): string | undefined;
    }
    interface LoggingConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sfn_state_machine#include_execution_data AwsSfnStateMachine#include_execution_data}
        */
        readonly includeExecutionData?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sfn_state_machine#level AwsSfnStateMachine#level}
        */
        readonly level?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sfn_state_machine#log_destination AwsSfnStateMachine#log_destination}
        */
        readonly logDestination?: string;
    }
    class LoggingConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): LoggingConfigurationProperty | undefined;
        set internalValue(value: LoggingConfigurationProperty | undefined);
        private _includeExecutionData?;
        get includeExecutionData(): boolean | cdktn.IResolvable;
        set includeExecutionData(value: boolean | cdktn.IResolvable);
        resetIncludeExecutionData(): void;
        get includeExecutionDataInput(): boolean | cdktn.IResolvable | undefined;
        private _level?;
        get level(): string;
        set level(value: string);
        resetLevel(): void;
        get levelInput(): string | undefined;
        private _logDestination?;
        get logDestination(): string;
        set logDestination(value: string);
        resetLogDestination(): void;
        get logDestinationInput(): string | undefined;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sfn_state_machine#create AwsSfnStateMachine#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sfn_state_machine#delete AwsSfnStateMachine#delete}
        */
        readonly delete?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sfn_state_machine#update AwsSfnStateMachine#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
    interface TracingConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sfn_state_machine#enabled AwsSfnStateMachine#enabled}
        */
        readonly enabled?: boolean | cdktn.IResolvable;
    }
    class TracingConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TracingConfigurationProperty | undefined;
        set internalValue(value: TracingConfigurationProperty | undefined);
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        resetEnabled(): void;
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
    }
}
