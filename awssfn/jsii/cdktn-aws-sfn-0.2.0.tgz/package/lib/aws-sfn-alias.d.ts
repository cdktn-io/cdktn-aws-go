import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfAliasConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sfn_alias#description TfAlias#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sfn_alias#id TfAlias#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sfn_alias#name TfAlias#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sfn_alias#region TfAlias#region}
    */
    readonly region?: string;
    /**
    * routing_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sfn_alias#routing_configuration TfAlias#routing_configuration}
    */
    readonly routingConfiguration: TfAlias.RoutingConfigurationProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sfn_alias#timeouts TfAlias#timeouts}
    */
    readonly timeouts?: TfAlias.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sfn_alias aws_sfn_alias}
*/
export declare class TfAlias extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_sfn_alias";
    /**
    * Generates CDKTN code for importing a TfAlias resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfAlias to import
    * @param importFromId The id of the existing TfAlias that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sfn_alias#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfAlias to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sfn_alias aws_sfn_alias} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfAliasConfig
    */
    constructor(scope: Construct, id: string, config: TfAliasConfig);
    get arn(): string;
    get creationDate(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _routingConfiguration;
    get routingConfiguration(): TfAlias.RoutingConfigurationPropertyList;
    putRoutingConfiguration(value: TfAlias.RoutingConfigurationProperty[] | cdktn.IResolvable): void;
    get routingConfigurationInput(): cdktn.IResolvable | TfAlias.RoutingConfigurationProperty[] | undefined;
    private _timeouts;
    get timeouts(): TfAlias.TimeoutsPropertyOutputReference;
    putTimeouts(value: TfAlias.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | TfAlias.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfAliasRoutingConfigurationPropertyToTerraform(struct?: TfAlias.RoutingConfigurationProperty | cdktn.IResolvable): any;
export declare function tfAliasRoutingConfigurationPropertyToHclTerraform(struct?: TfAlias.RoutingConfigurationProperty | cdktn.IResolvable): any;
export declare function tfAliasTimeoutsPropertyToTerraform(struct?: TfAlias.TimeoutsProperty | cdktn.IResolvable): any;
export declare function tfAliasTimeoutsPropertyToHclTerraform(struct?: TfAlias.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace TfAlias {
    interface RoutingConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sfn_alias#state_machine_version_arn TfAlias#state_machine_version_arn}
        */
        readonly stateMachineVersionArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sfn_alias#weight TfAlias#weight}
        */
        readonly weight: number;
    }
    class RoutingConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RoutingConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RoutingConfigurationProperty | cdktn.IResolvable | undefined);
        private _stateMachineVersionArn?;
        get stateMachineVersionArn(): string;
        set stateMachineVersionArn(value: string);
        get stateMachineVersionArnInput(): string | undefined;
        private _weight?;
        get weight(): number;
        set weight(value: number);
        get weightInput(): number | undefined;
    }
    class RoutingConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: RoutingConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RoutingConfigurationPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sfn_alias#create TfAlias#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sfn_alias#delete TfAlias#delete}
        */
        readonly delete?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sfn_alias#update TfAlias#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
