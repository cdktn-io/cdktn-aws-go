import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataTfStateMachineVersionsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/sfn_state_machine_versions#id DataTfStateMachineVersions#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/sfn_state_machine_versions#region DataTfStateMachineVersions#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/sfn_state_machine_versions#statemachine_arn DataTfStateMachineVersions#statemachine_arn}
    */
    readonly statemachineArn: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/sfn_state_machine_versions aws_sfn_state_machine_versions}
*/
export declare class DataTfStateMachineVersions extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_sfn_state_machine_versions";
    /**
    * Generates CDKTN code for importing a DataTfStateMachineVersions resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataTfStateMachineVersions to import
    * @param importFromId The id of the existing DataTfStateMachineVersions that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/sfn_state_machine_versions#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataTfStateMachineVersions to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/sfn_state_machine_versions aws_sfn_state_machine_versions} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataTfStateMachineVersionsConfig
    */
    constructor(scope: Construct, id: string, config: DataTfStateMachineVersionsConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _statemachineArn?;
    get statemachineArn(): string;
    set statemachineArn(value: string);
    get statemachineArnInput(): string | undefined;
    get statemachineVersions(): string[];
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
