import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsNotificationChannelConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/devopsguru_notification_channel#id DataAwsNotificationChannel#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/devopsguru_notification_channel#region DataAwsNotificationChannel#region}
    */
    readonly region?: string;
    /**
    * filters block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/devopsguru_notification_channel#filters DataAwsNotificationChannel#filters}
    */
    readonly filters?: DataAwsNotificationChannel.FiltersProperty[] | cdktn.IResolvable;
    /**
    * sns block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/devopsguru_notification_channel#sns DataAwsNotificationChannel#sns}
    */
    readonly sns?: DataAwsNotificationChannel.SnsProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/devopsguru_notification_channel aws_devopsguru_notification_channel}
*/
export declare class DataAwsNotificationChannel extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_devopsguru_notification_channel";
    /**
    * Generates CDKTN code for importing a DataAwsNotificationChannel resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsNotificationChannel to import
    * @param importFromId The id of the existing DataAwsNotificationChannel that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/devopsguru_notification_channel#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsNotificationChannel to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/devopsguru_notification_channel aws_devopsguru_notification_channel} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsNotificationChannelConfig
    */
    constructor(scope: Construct, id: string, config: DataAwsNotificationChannelConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _filters;
    get filters(): DataAwsNotificationChannel.FiltersPropertyList;
    putFilters(value: DataAwsNotificationChannel.FiltersProperty[] | cdktn.IResolvable): void;
    resetFilters(): void;
    get filtersInput(): cdktn.IResolvable | DataAwsNotificationChannel.FiltersProperty[] | undefined;
    private _sns;
    get sns(): DataAwsNotificationChannel.SnsPropertyList;
    putSns(value: DataAwsNotificationChannel.SnsProperty[] | cdktn.IResolvable): void;
    resetSns(): void;
    get snsInput(): cdktn.IResolvable | DataAwsNotificationChannel.SnsProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataAwsNotificationChannelFiltersPropertyToTerraform(struct?: DataAwsNotificationChannel.FiltersProperty | cdktn.IResolvable): any;
export declare function dataAwsNotificationChannelFiltersPropertyToHclTerraform(struct?: DataAwsNotificationChannel.FiltersProperty | cdktn.IResolvable): any;
export declare function dataAwsNotificationChannelSnsPropertyToTerraform(struct?: DataAwsNotificationChannel.SnsProperty | cdktn.IResolvable): any;
export declare function dataAwsNotificationChannelSnsPropertyToHclTerraform(struct?: DataAwsNotificationChannel.SnsProperty | cdktn.IResolvable): any;
export declare namespace DataAwsNotificationChannel {
    interface FiltersProperty {
    }
    class FiltersPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): FiltersProperty | cdktn.IResolvable | undefined;
        set internalValue(value: FiltersProperty | cdktn.IResolvable | undefined);
        get messageTypes(): string[];
        get severities(): string[];
    }
    class FiltersPropertyList extends cdktn.ComplexList {
        internalValue?: FiltersProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): FiltersPropertyOutputReference;
    }
    interface SnsProperty {
    }
    class SnsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SnsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SnsProperty | cdktn.IResolvable | undefined);
        get topicArn(): string;
    }
    class SnsPropertyList extends cdktn.ComplexList {
        internalValue?: SnsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SnsPropertyOutputReference;
    }
}
