import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsResourceCollectionConfig extends cdktn.TerraformMetaArguments {
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/devopsguru_resource_collection#region DataAwsResourceCollection#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/devopsguru_resource_collection#type DataAwsResourceCollection#type}
    */
    readonly type: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/devopsguru_resource_collection aws_devopsguru_resource_collection}
*/
export declare class DataAwsResourceCollection extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_devopsguru_resource_collection";
    /**
    * Generates CDKTN code for importing a DataAwsResourceCollection resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsResourceCollection to import
    * @param importFromId The id of the existing DataAwsResourceCollection that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/devopsguru_resource_collection#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsResourceCollection to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/devopsguru_resource_collection aws_devopsguru_resource_collection} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsResourceCollectionConfig
    */
    constructor(scope: Construct, id: string, config: DataAwsResourceCollectionConfig);
    private _cloudformation;
    get cloudformation(): DataAwsResourceCollection.CloudformationPropertyList;
    get id(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags;
    get tags(): DataAwsResourceCollection.TagsPropertyList;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataAwsResourceCollectionCloudformationPropertyToTerraform(struct?: DataAwsResourceCollection.CloudformationProperty): any;
export declare function dataAwsResourceCollectionCloudformationPropertyToHclTerraform(struct?: DataAwsResourceCollection.CloudformationProperty): any;
export declare function dataAwsResourceCollectionTagsPropertyToTerraform(struct?: DataAwsResourceCollection.TagsProperty): any;
export declare function dataAwsResourceCollectionTagsPropertyToHclTerraform(struct?: DataAwsResourceCollection.TagsProperty): any;
export declare namespace DataAwsResourceCollection {
    interface CloudformationProperty {
    }
    class CloudformationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CloudformationProperty | undefined;
        set internalValue(value: CloudformationProperty | undefined);
        get stackNames(): string[];
    }
    class CloudformationPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CloudformationPropertyOutputReference;
    }
    interface TagsProperty {
    }
    class TagsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TagsProperty | undefined;
        set internalValue(value: TagsProperty | undefined);
        get appBoundaryKey(): string;
        get tagValues(): string[];
    }
    class TagsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TagsPropertyOutputReference;
    }
}
