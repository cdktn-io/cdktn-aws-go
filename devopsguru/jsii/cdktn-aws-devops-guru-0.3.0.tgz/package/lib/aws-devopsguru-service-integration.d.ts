import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsServiceIntegrationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/devopsguru_service_integration#region AwsServiceIntegration#region}
    */
    readonly region?: string;
    /**
    * kms_server_side_encryption block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/devopsguru_service_integration#kms_server_side_encryption AwsServiceIntegration#kms_server_side_encryption}
    */
    readonly kmsServerSideEncryption?: AwsServiceIntegration.KmsServerSideEncryptionProperty[] | cdktn.IResolvable;
    /**
    * logs_anomaly_detection block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/devopsguru_service_integration#logs_anomaly_detection AwsServiceIntegration#logs_anomaly_detection}
    */
    readonly logsAnomalyDetection?: AwsServiceIntegration.LogsAnomalyDetectionProperty[] | cdktn.IResolvable;
    /**
    * ops_center block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/devopsguru_service_integration#ops_center AwsServiceIntegration#ops_center}
    */
    readonly opsCenter?: AwsServiceIntegration.OpsCenterProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/devopsguru_service_integration aws_devopsguru_service_integration}
*/
export declare class AwsServiceIntegration extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_devopsguru_service_integration";
    /**
    * Generates CDKTN code for importing a AwsServiceIntegration resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsServiceIntegration to import
    * @param importFromId The id of the existing AwsServiceIntegration that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/devopsguru_service_integration#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsServiceIntegration to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/devopsguru_service_integration aws_devopsguru_service_integration} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsServiceIntegrationConfig = {}
    */
    constructor(scope: Construct, id: string, config?: AwsServiceIntegrationConfig);
    get id(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _kmsServerSideEncryption;
    get kmsServerSideEncryption(): AwsServiceIntegration.KmsServerSideEncryptionPropertyList;
    putKmsServerSideEncryption(value: AwsServiceIntegration.KmsServerSideEncryptionProperty[] | cdktn.IResolvable): void;
    resetKmsServerSideEncryption(): void;
    get kmsServerSideEncryptionInput(): cdktn.IResolvable | AwsServiceIntegration.KmsServerSideEncryptionProperty[] | undefined;
    private _logsAnomalyDetection;
    get logsAnomalyDetection(): AwsServiceIntegration.LogsAnomalyDetectionPropertyList;
    putLogsAnomalyDetection(value: AwsServiceIntegration.LogsAnomalyDetectionProperty[] | cdktn.IResolvable): void;
    resetLogsAnomalyDetection(): void;
    get logsAnomalyDetectionInput(): cdktn.IResolvable | AwsServiceIntegration.LogsAnomalyDetectionProperty[] | undefined;
    private _opsCenter;
    get opsCenter(): AwsServiceIntegration.OpsCenterPropertyList;
    putOpsCenter(value: AwsServiceIntegration.OpsCenterProperty[] | cdktn.IResolvable): void;
    resetOpsCenter(): void;
    get opsCenterInput(): cdktn.IResolvable | AwsServiceIntegration.OpsCenterProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsServiceIntegrationKmsServerSideEncryptionPropertyToTerraform(struct?: AwsServiceIntegration.KmsServerSideEncryptionProperty | cdktn.IResolvable): any;
export declare function awsServiceIntegrationKmsServerSideEncryptionPropertyToHclTerraform(struct?: AwsServiceIntegration.KmsServerSideEncryptionProperty | cdktn.IResolvable): any;
export declare function awsServiceIntegrationLogsAnomalyDetectionPropertyToTerraform(struct?: AwsServiceIntegration.LogsAnomalyDetectionProperty | cdktn.IResolvable): any;
export declare function awsServiceIntegrationLogsAnomalyDetectionPropertyToHclTerraform(struct?: AwsServiceIntegration.LogsAnomalyDetectionProperty | cdktn.IResolvable): any;
export declare function awsServiceIntegrationOpsCenterPropertyToTerraform(struct?: AwsServiceIntegration.OpsCenterProperty | cdktn.IResolvable): any;
export declare function awsServiceIntegrationOpsCenterPropertyToHclTerraform(struct?: AwsServiceIntegration.OpsCenterProperty | cdktn.IResolvable): any;
export declare namespace AwsServiceIntegration {
    interface KmsServerSideEncryptionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/devopsguru_service_integration#kms_key_id AwsServiceIntegration#kms_key_id}
        */
        readonly kmsKeyId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/devopsguru_service_integration#opt_in_status AwsServiceIntegration#opt_in_status}
        */
        readonly optInStatus?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/devopsguru_service_integration#type AwsServiceIntegration#type}
        */
        readonly type?: string;
    }
    class KmsServerSideEncryptionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): KmsServerSideEncryptionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: KmsServerSideEncryptionProperty | cdktn.IResolvable | undefined);
        private _kmsKeyId?;
        get kmsKeyId(): string;
        set kmsKeyId(value: string);
        resetKmsKeyId(): void;
        get kmsKeyIdInput(): string | undefined;
        private _optInStatus?;
        get optInStatus(): string;
        set optInStatus(value: string);
        resetOptInStatus(): void;
        get optInStatusInput(): string | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        resetType(): void;
        get typeInput(): string | undefined;
    }
    class KmsServerSideEncryptionPropertyList extends cdktn.ComplexList {
        internalValue?: KmsServerSideEncryptionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): KmsServerSideEncryptionPropertyOutputReference;
    }
    interface LogsAnomalyDetectionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/devopsguru_service_integration#opt_in_status AwsServiceIntegration#opt_in_status}
        */
        readonly optInStatus?: string;
    }
    class LogsAnomalyDetectionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): LogsAnomalyDetectionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: LogsAnomalyDetectionProperty | cdktn.IResolvable | undefined);
        private _optInStatus?;
        get optInStatus(): string;
        set optInStatus(value: string);
        resetOptInStatus(): void;
        get optInStatusInput(): string | undefined;
    }
    class LogsAnomalyDetectionPropertyList extends cdktn.ComplexList {
        internalValue?: LogsAnomalyDetectionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): LogsAnomalyDetectionPropertyOutputReference;
    }
    interface OpsCenterProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/devopsguru_service_integration#opt_in_status AwsServiceIntegration#opt_in_status}
        */
        readonly optInStatus?: string;
    }
    class OpsCenterPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): OpsCenterProperty | cdktn.IResolvable | undefined;
        set internalValue(value: OpsCenterProperty | cdktn.IResolvable | undefined);
        private _optInStatus?;
        get optInStatus(): string;
        set optInStatus(value: string);
        resetOptInStatus(): void;
        get optInStatusInput(): string | undefined;
    }
    class OpsCenterPropertyList extends cdktn.ComplexList {
        internalValue?: OpsCenterProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): OpsCenterPropertyOutputReference;
    }
}
