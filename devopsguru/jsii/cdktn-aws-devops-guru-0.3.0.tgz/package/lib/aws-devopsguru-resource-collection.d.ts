import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsResourceCollectionConfig extends cdktn.TerraformMetaArguments {
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/devopsguru_resource_collection#region AwsResourceCollection#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/devopsguru_resource_collection#type AwsResourceCollection#type}
    */
    readonly type: string;
    /**
    * cloudformation block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/devopsguru_resource_collection#cloudformation AwsResourceCollection#cloudformation}
    */
    readonly cloudformation?: AwsResourceCollection.CloudformationProperty[] | cdktn.IResolvable;
    /**
    * tags block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/devopsguru_resource_collection#tags AwsResourceCollection#tags}
    */
    readonly tags?: AwsResourceCollection.TagsProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/devopsguru_resource_collection aws_devopsguru_resource_collection}
*/
export declare class AwsResourceCollection extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_devopsguru_resource_collection";
    /**
    * Generates CDKTN code for importing a AwsResourceCollection resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsResourceCollection to import
    * @param importFromId The id of the existing AwsResourceCollection that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/devopsguru_resource_collection#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsResourceCollection to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/devopsguru_resource_collection aws_devopsguru_resource_collection} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsResourceCollectionConfig
    */
    constructor(scope: Construct, id: string, config: AwsResourceCollectionConfig);
    get id(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _cloudformation;
    get cloudformation(): AwsResourceCollection.CloudformationPropertyList;
    putCloudformation(value: AwsResourceCollection.CloudformationProperty[] | cdktn.IResolvable): void;
    resetCloudformation(): void;
    get cloudformationInput(): cdktn.IResolvable | AwsResourceCollection.CloudformationProperty[] | undefined;
    private _tags;
    get tags(): AwsResourceCollection.TagsPropertyList;
    putTags(value: AwsResourceCollection.TagsProperty[] | cdktn.IResolvable): void;
    resetTags(): void;
    get tagsInput(): cdktn.IResolvable | AwsResourceCollection.TagsProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsResourceCollectionCloudformationPropertyToTerraform(struct?: AwsResourceCollection.CloudformationProperty | cdktn.IResolvable): any;
export declare function awsResourceCollectionCloudformationPropertyToHclTerraform(struct?: AwsResourceCollection.CloudformationProperty | cdktn.IResolvable): any;
export declare function awsResourceCollectionTagsPropertyToTerraform(struct?: AwsResourceCollection.TagsProperty | cdktn.IResolvable): any;
export declare function awsResourceCollectionTagsPropertyToHclTerraform(struct?: AwsResourceCollection.TagsProperty | cdktn.IResolvable): any;
export declare namespace AwsResourceCollection {
    interface CloudformationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/devopsguru_resource_collection#stack_names AwsResourceCollection#stack_names}
        */
        readonly stackNames: string[];
    }
    class CloudformationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CloudformationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CloudformationProperty | cdktn.IResolvable | undefined);
        private _stackNames?;
        get stackNames(): string[];
        set stackNames(value: string[]);
        get stackNamesInput(): string[] | undefined;
    }
    class CloudformationPropertyList extends cdktn.ComplexList {
        internalValue?: CloudformationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CloudformationPropertyOutputReference;
    }
    interface TagsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/devopsguru_resource_collection#app_boundary_key AwsResourceCollection#app_boundary_key}
        */
        readonly appBoundaryKey: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/devopsguru_resource_collection#tag_values AwsResourceCollection#tag_values}
        */
        readonly tagValues: string[];
    }
    class TagsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TagsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TagsProperty | cdktn.IResolvable | undefined);
        private _appBoundaryKey?;
        get appBoundaryKey(): string;
        set appBoundaryKey(value: string);
        get appBoundaryKeyInput(): string | undefined;
        private _tagValues?;
        get tagValues(): string[];
        set tagValues(value: string[]);
        get tagValuesInput(): string[] | undefined;
    }
    class TagsPropertyList extends cdktn.ComplexList {
        internalValue?: TagsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TagsPropertyOutputReference;
    }
}
