import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataTfBootstrapBrokersConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/msk_bootstrap_brokers#cluster_arn DataTfBootstrapBrokers#cluster_arn}
    */
    readonly clusterArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/msk_bootstrap_brokers#id DataTfBootstrapBrokers#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/msk_bootstrap_brokers#region DataTfBootstrapBrokers#region}
    */
    readonly region?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/msk_bootstrap_brokers aws_msk_bootstrap_brokers}
*/
export declare class DataTfBootstrapBrokers extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_msk_bootstrap_brokers";
    /**
    * Generates CDKTN code for importing a DataTfBootstrapBrokers resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataTfBootstrapBrokers to import
    * @param importFromId The id of the existing DataTfBootstrapBrokers that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/msk_bootstrap_brokers#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataTfBootstrapBrokers to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/msk_bootstrap_brokers aws_msk_bootstrap_brokers} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataTfBootstrapBrokersConfig
    */
    constructor(scope: Construct, id: string, config: DataTfBootstrapBrokersConfig);
    get bootstrapBrokers(): string;
    get bootstrapBrokersIpv6(): string;
    get bootstrapBrokersPublicSaslIam(): string;
    get bootstrapBrokersPublicSaslScram(): string;
    get bootstrapBrokersPublicTls(): string;
    get bootstrapBrokersSaslIam(): string;
    get bootstrapBrokersSaslIamIpv6(): string;
    get bootstrapBrokersSaslScram(): string;
    get bootstrapBrokersSaslScramIpv6(): string;
    get bootstrapBrokersTls(): string;
    get bootstrapBrokersTlsIpv6(): string;
    get bootstrapBrokersVpcConnectivitySaslIam(): string;
    get bootstrapBrokersVpcConnectivitySaslScram(): string;
    get bootstrapBrokersVpcConnectivityTls(): string;
    private _clusterArn?;
    get clusterArn(): string;
    set clusterArn(value: string);
    get clusterArnInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
