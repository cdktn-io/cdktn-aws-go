import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfReplicatorConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_replicator#description TfReplicator#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_replicator#id TfReplicator#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_replicator#region TfReplicator#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_replicator#replicator_name TfReplicator#replicator_name}
    */
    readonly replicatorName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_replicator#service_execution_role_arn TfReplicator#service_execution_role_arn}
    */
    readonly serviceExecutionRoleArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_replicator#tags TfReplicator#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_replicator#tags_all TfReplicator#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * kafka_cluster block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_replicator#kafka_cluster TfReplicator#kafka_cluster}
    */
    readonly kafkaCluster: TfReplicator.KafkaClusterProperty[] | cdktn.IResolvable;
    /**
    * log_delivery block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_replicator#log_delivery TfReplicator#log_delivery}
    */
    readonly logDelivery?: TfReplicator.LogDeliveryProperty;
    /**
    * replication_info_list block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_replicator#replication_info_list TfReplicator#replication_info_list}
    */
    readonly replicationInfoList: TfReplicator.ReplicationInfoListProperty;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_replicator#timeouts TfReplicator#timeouts}
    */
    readonly timeouts?: TfReplicator.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_replicator aws_msk_replicator}
*/
export declare class TfReplicator extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_msk_replicator";
    /**
    * Generates CDKTN code for importing a TfReplicator resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfReplicator to import
    * @param importFromId The id of the existing TfReplicator that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_replicator#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfReplicator to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_replicator aws_msk_replicator} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfReplicatorConfig
    */
    constructor(scope: Construct, id: string, config: TfReplicatorConfig);
    get arn(): string;
    get currentVersion(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _replicatorName?;
    get replicatorName(): string;
    set replicatorName(value: string);
    get replicatorNameInput(): string | undefined;
    private _serviceExecutionRoleArn?;
    get serviceExecutionRoleArn(): string;
    set serviceExecutionRoleArn(value: string);
    get serviceExecutionRoleArnInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _kafkaCluster;
    get kafkaCluster(): TfReplicator.KafkaClusterPropertyList;
    putKafkaCluster(value: TfReplicator.KafkaClusterProperty[] | cdktn.IResolvable): void;
    get kafkaClusterInput(): cdktn.IResolvable | TfReplicator.KafkaClusterProperty[] | undefined;
    private _logDelivery;
    get logDelivery(): TfReplicator.LogDeliveryPropertyOutputReference;
    putLogDelivery(value: TfReplicator.LogDeliveryProperty): void;
    resetLogDelivery(): void;
    get logDeliveryInput(): TfReplicator.LogDeliveryProperty | undefined;
    private _replicationInfoList;
    get replicationInfoList(): TfReplicator.ReplicationInfoListPropertyOutputReference;
    putReplicationInfoList(value: TfReplicator.ReplicationInfoListProperty): void;
    get replicationInfoListInput(): TfReplicator.ReplicationInfoListProperty | undefined;
    private _timeouts;
    get timeouts(): TfReplicator.TimeoutsPropertyOutputReference;
    putTimeouts(value: TfReplicator.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | TfReplicator.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfReplicatorAmazonMskClusterPropertyToTerraform(struct?: TfReplicator.AmazonMskClusterPropertyOutputReference | TfReplicator.AmazonMskClusterProperty): any;
export declare function tfReplicatorAmazonMskClusterPropertyToHclTerraform(struct?: TfReplicator.AmazonMskClusterPropertyOutputReference | TfReplicator.AmazonMskClusterProperty): any;
export declare function tfReplicatorVpcConfigPropertyToTerraform(struct?: TfReplicator.VpcConfigPropertyOutputReference | TfReplicator.VpcConfigProperty): any;
export declare function tfReplicatorVpcConfigPropertyToHclTerraform(struct?: TfReplicator.VpcConfigPropertyOutputReference | TfReplicator.VpcConfigProperty): any;
export declare function tfReplicatorKafkaClusterPropertyToTerraform(struct?: TfReplicator.KafkaClusterProperty | cdktn.IResolvable): any;
export declare function tfReplicatorKafkaClusterPropertyToHclTerraform(struct?: TfReplicator.KafkaClusterProperty | cdktn.IResolvable): any;
export declare function tfReplicatorCloudwatchLogsPropertyToTerraform(struct?: TfReplicator.CloudwatchLogsPropertyOutputReference | TfReplicator.CloudwatchLogsProperty): any;
export declare function tfReplicatorCloudwatchLogsPropertyToHclTerraform(struct?: TfReplicator.CloudwatchLogsPropertyOutputReference | TfReplicator.CloudwatchLogsProperty): any;
export declare function tfReplicatorFirehosePropertyToTerraform(struct?: TfReplicator.FirehosePropertyOutputReference | TfReplicator.FirehoseProperty): any;
export declare function tfReplicatorFirehosePropertyToHclTerraform(struct?: TfReplicator.FirehosePropertyOutputReference | TfReplicator.FirehoseProperty): any;
export declare function tfReplicatorS3PropertyToTerraform(struct?: TfReplicator.S3PropertyOutputReference | TfReplicator.S3Property): any;
export declare function tfReplicatorS3PropertyToHclTerraform(struct?: TfReplicator.S3PropertyOutputReference | TfReplicator.S3Property): any;
export declare function tfReplicatorReplicatorLogDeliveryPropertyToTerraform(struct?: TfReplicator.ReplicatorLogDeliveryPropertyOutputReference | TfReplicator.ReplicatorLogDeliveryProperty): any;
export declare function tfReplicatorReplicatorLogDeliveryPropertyToHclTerraform(struct?: TfReplicator.ReplicatorLogDeliveryPropertyOutputReference | TfReplicator.ReplicatorLogDeliveryProperty): any;
export declare function tfReplicatorLogDeliveryPropertyToTerraform(struct?: TfReplicator.LogDeliveryPropertyOutputReference | TfReplicator.LogDeliveryProperty): any;
export declare function tfReplicatorLogDeliveryPropertyToHclTerraform(struct?: TfReplicator.LogDeliveryPropertyOutputReference | TfReplicator.LogDeliveryProperty): any;
export declare function tfReplicatorConsumerGroupReplicationPropertyToTerraform(struct?: TfReplicator.ConsumerGroupReplicationProperty | cdktn.IResolvable): any;
export declare function tfReplicatorConsumerGroupReplicationPropertyToHclTerraform(struct?: TfReplicator.ConsumerGroupReplicationProperty | cdktn.IResolvable): any;
export declare function tfReplicatorStartingPositionPropertyToTerraform(struct?: TfReplicator.StartingPositionPropertyOutputReference | TfReplicator.StartingPositionProperty): any;
export declare function tfReplicatorStartingPositionPropertyToHclTerraform(struct?: TfReplicator.StartingPositionPropertyOutputReference | TfReplicator.StartingPositionProperty): any;
export declare function tfReplicatorTopicNameConfigurationPropertyToTerraform(struct?: TfReplicator.TopicNameConfigurationPropertyOutputReference | TfReplicator.TopicNameConfigurationProperty): any;
export declare function tfReplicatorTopicNameConfigurationPropertyToHclTerraform(struct?: TfReplicator.TopicNameConfigurationPropertyOutputReference | TfReplicator.TopicNameConfigurationProperty): any;
export declare function tfReplicatorTopicReplicationPropertyToTerraform(struct?: TfReplicator.TopicReplicationProperty | cdktn.IResolvable): any;
export declare function tfReplicatorTopicReplicationPropertyToHclTerraform(struct?: TfReplicator.TopicReplicationProperty | cdktn.IResolvable): any;
export declare function tfReplicatorReplicationInfoListPropertyToTerraform(struct?: TfReplicator.ReplicationInfoListPropertyOutputReference | TfReplicator.ReplicationInfoListProperty): any;
export declare function tfReplicatorReplicationInfoListPropertyToHclTerraform(struct?: TfReplicator.ReplicationInfoListPropertyOutputReference | TfReplicator.ReplicationInfoListProperty): any;
export declare function tfReplicatorTimeoutsPropertyToTerraform(struct?: TfReplicator.TimeoutsProperty | cdktn.IResolvable): any;
export declare function tfReplicatorTimeoutsPropertyToHclTerraform(struct?: TfReplicator.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace TfReplicator {
    interface AmazonMskClusterProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_replicator#msk_cluster_arn TfReplicator#msk_cluster_arn}
        */
        readonly mskClusterArn: string;
    }
    class AmazonMskClusterPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AmazonMskClusterProperty | undefined;
        set internalValue(value: AmazonMskClusterProperty | undefined);
        private _mskClusterArn?;
        get mskClusterArn(): string;
        set mskClusterArn(value: string);
        get mskClusterArnInput(): string | undefined;
    }
    interface VpcConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_replicator#security_groups_ids TfReplicator#security_groups_ids}
        */
        readonly securityGroupsIds?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_replicator#subnet_ids TfReplicator#subnet_ids}
        */
        readonly subnetIds: string[];
    }
    class VpcConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): VpcConfigProperty | undefined;
        set internalValue(value: VpcConfigProperty | undefined);
        private _securityGroupsIds?;
        get securityGroupsIds(): string[];
        set securityGroupsIds(value: string[]);
        resetSecurityGroupsIds(): void;
        get securityGroupsIdsInput(): string[] | undefined;
        private _subnetIds?;
        get subnetIds(): string[];
        set subnetIds(value: string[]);
        get subnetIdsInput(): string[] | undefined;
    }
    interface KafkaClusterProperty {
        /**
        * amazon_msk_cluster block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_replicator#amazon_msk_cluster TfReplicator#amazon_msk_cluster}
        */
        readonly amazonMskCluster: AmazonMskClusterProperty;
        /**
        * vpc_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_replicator#vpc_config TfReplicator#vpc_config}
        */
        readonly vpcConfig: VpcConfigProperty;
    }
    class KafkaClusterPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): KafkaClusterProperty | cdktn.IResolvable | undefined;
        set internalValue(value: KafkaClusterProperty | cdktn.IResolvable | undefined);
        private _amazonMskCluster;
        get amazonMskCluster(): AmazonMskClusterPropertyOutputReference;
        putAmazonMskCluster(value: AmazonMskClusterProperty): void;
        get amazonMskClusterInput(): AmazonMskClusterProperty | undefined;
        private _vpcConfig;
        get vpcConfig(): VpcConfigPropertyOutputReference;
        putVpcConfig(value: VpcConfigProperty): void;
        get vpcConfigInput(): VpcConfigProperty | undefined;
    }
    class KafkaClusterPropertyList extends cdktn.ComplexList {
        internalValue?: KafkaClusterProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): KafkaClusterPropertyOutputReference;
    }
    interface CloudwatchLogsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_replicator#enabled TfReplicator#enabled}
        */
        readonly enabled: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_replicator#log_group TfReplicator#log_group}
        */
        readonly logGroup?: string;
    }
    class CloudwatchLogsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CloudwatchLogsProperty | undefined;
        set internalValue(value: CloudwatchLogsProperty | undefined);
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
        private _logGroup?;
        get logGroup(): string;
        set logGroup(value: string);
        resetLogGroup(): void;
        get logGroupInput(): string | undefined;
    }
    interface FirehoseProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_replicator#delivery_stream TfReplicator#delivery_stream}
        */
        readonly deliveryStream?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_replicator#enabled TfReplicator#enabled}
        */
        readonly enabled: boolean | cdktn.IResolvable;
    }
    class FirehosePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): FirehoseProperty | undefined;
        set internalValue(value: FirehoseProperty | undefined);
        private _deliveryStream?;
        get deliveryStream(): string;
        set deliveryStream(value: string);
        resetDeliveryStream(): void;
        get deliveryStreamInput(): string | undefined;
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface S3Property {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_replicator#bucket TfReplicator#bucket}
        */
        readonly bucket?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_replicator#enabled TfReplicator#enabled}
        */
        readonly enabled: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_replicator#prefix TfReplicator#prefix}
        */
        readonly prefix?: string;
    }
    class S3PropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): S3Property | undefined;
        set internalValue(value: S3Property | undefined);
        private _bucket?;
        get bucket(): string;
        set bucket(value: string);
        resetBucket(): void;
        get bucketInput(): string | undefined;
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
        private _prefix?;
        get prefix(): string;
        set prefix(value: string);
        resetPrefix(): void;
        get prefixInput(): string | undefined;
    }
    interface ReplicatorLogDeliveryProperty {
        /**
        * cloudwatch_logs block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_replicator#cloudwatch_logs TfReplicator#cloudwatch_logs}
        */
        readonly cloudwatchLogs?: CloudwatchLogsProperty;
        /**
        * firehose block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_replicator#firehose TfReplicator#firehose}
        */
        readonly firehose?: FirehoseProperty;
        /**
        * s3 block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_replicator#s3 TfReplicator#s3}
        */
        readonly s3?: S3Property;
    }
    class ReplicatorLogDeliveryPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ReplicatorLogDeliveryProperty | undefined;
        set internalValue(value: ReplicatorLogDeliveryProperty | undefined);
        private _cloudwatchLogs;
        get cloudwatchLogs(): CloudwatchLogsPropertyOutputReference;
        putCloudwatchLogs(value: CloudwatchLogsProperty): void;
        resetCloudwatchLogs(): void;
        get cloudwatchLogsInput(): CloudwatchLogsProperty | undefined;
        private _firehose;
        get firehose(): FirehosePropertyOutputReference;
        putFirehose(value: FirehoseProperty): void;
        resetFirehose(): void;
        get firehoseInput(): FirehoseProperty | undefined;
        private _s3;
        get s3(): S3PropertyOutputReference;
        putS3(value: S3Property): void;
        resetS3(): void;
        get s3Input(): S3Property | undefined;
    }
    interface LogDeliveryProperty {
        /**
        * replicator_log_delivery block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_replicator#replicator_log_delivery TfReplicator#replicator_log_delivery}
        */
        readonly replicatorLogDelivery?: ReplicatorLogDeliveryProperty;
    }
    class LogDeliveryPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): LogDeliveryProperty | undefined;
        set internalValue(value: LogDeliveryProperty | undefined);
        private _replicatorLogDelivery;
        get replicatorLogDelivery(): ReplicatorLogDeliveryPropertyOutputReference;
        putReplicatorLogDelivery(value: ReplicatorLogDeliveryProperty): void;
        resetReplicatorLogDelivery(): void;
        get replicatorLogDeliveryInput(): ReplicatorLogDeliveryProperty | undefined;
    }
    interface ConsumerGroupReplicationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_replicator#consumer_group_offset_sync_mode TfReplicator#consumer_group_offset_sync_mode}
        */
        readonly consumerGroupOffsetSyncMode?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_replicator#consumer_groups_to_exclude TfReplicator#consumer_groups_to_exclude}
        */
        readonly consumerGroupsToExclude?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_replicator#consumer_groups_to_replicate TfReplicator#consumer_groups_to_replicate}
        */
        readonly consumerGroupsToReplicate: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_replicator#detect_and_copy_new_consumer_groups TfReplicator#detect_and_copy_new_consumer_groups}
        */
        readonly detectAndCopyNewConsumerGroups?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_replicator#synchronise_consumer_group_offsets TfReplicator#synchronise_consumer_group_offsets}
        */
        readonly synchroniseConsumerGroupOffsets?: boolean | cdktn.IResolvable;
    }
    class ConsumerGroupReplicationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ConsumerGroupReplicationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ConsumerGroupReplicationProperty | cdktn.IResolvable | undefined);
        private _consumerGroupOffsetSyncMode?;
        get consumerGroupOffsetSyncMode(): string;
        set consumerGroupOffsetSyncMode(value: string);
        resetConsumerGroupOffsetSyncMode(): void;
        get consumerGroupOffsetSyncModeInput(): string | undefined;
        private _consumerGroupsToExclude?;
        get consumerGroupsToExclude(): string[];
        set consumerGroupsToExclude(value: string[]);
        resetConsumerGroupsToExclude(): void;
        get consumerGroupsToExcludeInput(): string[] | undefined;
        private _consumerGroupsToReplicate?;
        get consumerGroupsToReplicate(): string[];
        set consumerGroupsToReplicate(value: string[]);
        get consumerGroupsToReplicateInput(): string[] | undefined;
        private _detectAndCopyNewConsumerGroups?;
        get detectAndCopyNewConsumerGroups(): boolean | cdktn.IResolvable;
        set detectAndCopyNewConsumerGroups(value: boolean | cdktn.IResolvable);
        resetDetectAndCopyNewConsumerGroups(): void;
        get detectAndCopyNewConsumerGroupsInput(): boolean | cdktn.IResolvable | undefined;
        private _synchroniseConsumerGroupOffsets?;
        get synchroniseConsumerGroupOffsets(): boolean | cdktn.IResolvable;
        set synchroniseConsumerGroupOffsets(value: boolean | cdktn.IResolvable);
        resetSynchroniseConsumerGroupOffsets(): void;
        get synchroniseConsumerGroupOffsetsInput(): boolean | cdktn.IResolvable | undefined;
    }
    class ConsumerGroupReplicationPropertyList extends cdktn.ComplexList {
        internalValue?: ConsumerGroupReplicationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ConsumerGroupReplicationPropertyOutputReference;
    }
    interface StartingPositionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_replicator#type TfReplicator#type}
        */
        readonly type?: string;
    }
    class StartingPositionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): StartingPositionProperty | undefined;
        set internalValue(value: StartingPositionProperty | undefined);
        private _type?;
        get type(): string;
        set type(value: string);
        resetType(): void;
        get typeInput(): string | undefined;
    }
    interface TopicNameConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_replicator#type TfReplicator#type}
        */
        readonly type?: string;
    }
    class TopicNameConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TopicNameConfigurationProperty | undefined;
        set internalValue(value: TopicNameConfigurationProperty | undefined);
        private _type?;
        get type(): string;
        set type(value: string);
        resetType(): void;
        get typeInput(): string | undefined;
    }
    interface TopicReplicationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_replicator#copy_access_control_lists_for_topics TfReplicator#copy_access_control_lists_for_topics}
        */
        readonly copyAccessControlListsForTopics?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_replicator#copy_topic_configurations TfReplicator#copy_topic_configurations}
        */
        readonly copyTopicConfigurations?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_replicator#detect_and_copy_new_topics TfReplicator#detect_and_copy_new_topics}
        */
        readonly detectAndCopyNewTopics?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_replicator#topics_to_exclude TfReplicator#topics_to_exclude}
        */
        readonly topicsToExclude?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_replicator#topics_to_replicate TfReplicator#topics_to_replicate}
        */
        readonly topicsToReplicate: string[];
        /**
        * starting_position block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_replicator#starting_position TfReplicator#starting_position}
        */
        readonly startingPosition?: StartingPositionProperty;
        /**
        * topic_name_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_replicator#topic_name_configuration TfReplicator#topic_name_configuration}
        */
        readonly topicNameConfiguration?: TopicNameConfigurationProperty;
    }
    class TopicReplicationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TopicReplicationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TopicReplicationProperty | cdktn.IResolvable | undefined);
        private _copyAccessControlListsForTopics?;
        get copyAccessControlListsForTopics(): boolean | cdktn.IResolvable;
        set copyAccessControlListsForTopics(value: boolean | cdktn.IResolvable);
        resetCopyAccessControlListsForTopics(): void;
        get copyAccessControlListsForTopicsInput(): boolean | cdktn.IResolvable | undefined;
        private _copyTopicConfigurations?;
        get copyTopicConfigurations(): boolean | cdktn.IResolvable;
        set copyTopicConfigurations(value: boolean | cdktn.IResolvable);
        resetCopyTopicConfigurations(): void;
        get copyTopicConfigurationsInput(): boolean | cdktn.IResolvable | undefined;
        private _detectAndCopyNewTopics?;
        get detectAndCopyNewTopics(): boolean | cdktn.IResolvable;
        set detectAndCopyNewTopics(value: boolean | cdktn.IResolvable);
        resetDetectAndCopyNewTopics(): void;
        get detectAndCopyNewTopicsInput(): boolean | cdktn.IResolvable | undefined;
        private _topicsToExclude?;
        get topicsToExclude(): string[];
        set topicsToExclude(value: string[]);
        resetTopicsToExclude(): void;
        get topicsToExcludeInput(): string[] | undefined;
        private _topicsToReplicate?;
        get topicsToReplicate(): string[];
        set topicsToReplicate(value: string[]);
        get topicsToReplicateInput(): string[] | undefined;
        private _startingPosition;
        get startingPosition(): StartingPositionPropertyOutputReference;
        putStartingPosition(value: StartingPositionProperty): void;
        resetStartingPosition(): void;
        get startingPositionInput(): StartingPositionProperty | undefined;
        private _topicNameConfiguration;
        get topicNameConfiguration(): TopicNameConfigurationPropertyOutputReference;
        putTopicNameConfiguration(value: TopicNameConfigurationProperty): void;
        resetTopicNameConfiguration(): void;
        get topicNameConfigurationInput(): TopicNameConfigurationProperty | undefined;
    }
    class TopicReplicationPropertyList extends cdktn.ComplexList {
        internalValue?: TopicReplicationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TopicReplicationPropertyOutputReference;
    }
    interface ReplicationInfoListProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_replicator#source_kafka_cluster_arn TfReplicator#source_kafka_cluster_arn}
        */
        readonly sourceKafkaClusterArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_replicator#target_compression_type TfReplicator#target_compression_type}
        */
        readonly targetCompressionType: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_replicator#target_kafka_cluster_arn TfReplicator#target_kafka_cluster_arn}
        */
        readonly targetKafkaClusterArn: string;
        /**
        * consumer_group_replication block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_replicator#consumer_group_replication TfReplicator#consumer_group_replication}
        */
        readonly consumerGroupReplication: ConsumerGroupReplicationProperty[] | cdktn.IResolvable;
        /**
        * topic_replication block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_replicator#topic_replication TfReplicator#topic_replication}
        */
        readonly topicReplication: TopicReplicationProperty[] | cdktn.IResolvable;
    }
    class ReplicationInfoListPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ReplicationInfoListProperty | undefined;
        set internalValue(value: ReplicationInfoListProperty | undefined);
        get sourceKafkaClusterAlias(): string;
        private _sourceKafkaClusterArn?;
        get sourceKafkaClusterArn(): string;
        set sourceKafkaClusterArn(value: string);
        get sourceKafkaClusterArnInput(): string | undefined;
        private _targetCompressionType?;
        get targetCompressionType(): string;
        set targetCompressionType(value: string);
        get targetCompressionTypeInput(): string | undefined;
        get targetKafkaClusterAlias(): string;
        private _targetKafkaClusterArn?;
        get targetKafkaClusterArn(): string;
        set targetKafkaClusterArn(value: string);
        get targetKafkaClusterArnInput(): string | undefined;
        private _consumerGroupReplication;
        get consumerGroupReplication(): ConsumerGroupReplicationPropertyList;
        putConsumerGroupReplication(value: ConsumerGroupReplicationProperty[] | cdktn.IResolvable): void;
        get consumerGroupReplicationInput(): cdktn.IResolvable | ConsumerGroupReplicationProperty[] | undefined;
        private _topicReplication;
        get topicReplication(): TopicReplicationPropertyList;
        putTopicReplication(value: TopicReplicationProperty[] | cdktn.IResolvable): void;
        get topicReplicationInput(): cdktn.IResolvable | TopicReplicationProperty[] | undefined;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_replicator#create TfReplicator#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_replicator#delete TfReplicator#delete}
        */
        readonly delete?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_replicator#update TfReplicator#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
