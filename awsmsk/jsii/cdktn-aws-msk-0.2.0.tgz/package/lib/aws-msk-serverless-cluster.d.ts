import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfServerlessClusterConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_serverless_cluster#cluster_name TfServerlessCluster#cluster_name}
    */
    readonly clusterName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_serverless_cluster#id TfServerlessCluster#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_serverless_cluster#region TfServerlessCluster#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_serverless_cluster#tags TfServerlessCluster#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_serverless_cluster#tags_all TfServerlessCluster#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * client_authentication block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_serverless_cluster#client_authentication TfServerlessCluster#client_authentication}
    */
    readonly clientAuthentication: TfServerlessCluster.ClientAuthenticationProperty;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_serverless_cluster#timeouts TfServerlessCluster#timeouts}
    */
    readonly timeouts?: TfServerlessCluster.TimeoutsProperty;
    /**
    * vpc_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_serverless_cluster#vpc_config TfServerlessCluster#vpc_config}
    */
    readonly vpcConfig: TfServerlessCluster.VpcConfigProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_serverless_cluster aws_msk_serverless_cluster}
*/
export declare class TfServerlessCluster extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_msk_serverless_cluster";
    /**
    * Generates CDKTN code for importing a TfServerlessCluster resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfServerlessCluster to import
    * @param importFromId The id of the existing TfServerlessCluster that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_serverless_cluster#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfServerlessCluster to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_serverless_cluster aws_msk_serverless_cluster} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfServerlessClusterConfig
    */
    constructor(scope: Construct, id: string, config: TfServerlessClusterConfig);
    get arn(): string;
    get bootstrapBrokersSaslIam(): string;
    private _clusterName?;
    get clusterName(): string;
    set clusterName(value: string);
    get clusterNameInput(): string | undefined;
    get clusterUuid(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _clientAuthentication;
    get clientAuthentication(): TfServerlessCluster.ClientAuthenticationPropertyOutputReference;
    putClientAuthentication(value: TfServerlessCluster.ClientAuthenticationProperty): void;
    get clientAuthenticationInput(): TfServerlessCluster.ClientAuthenticationProperty | undefined;
    private _timeouts;
    get timeouts(): TfServerlessCluster.TimeoutsPropertyOutputReference;
    putTimeouts(value: TfServerlessCluster.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | TfServerlessCluster.TimeoutsProperty | undefined;
    private _vpcConfig;
    get vpcConfig(): TfServerlessCluster.VpcConfigPropertyList;
    putVpcConfig(value: TfServerlessCluster.VpcConfigProperty[] | cdktn.IResolvable): void;
    get vpcConfigInput(): cdktn.IResolvable | TfServerlessCluster.VpcConfigProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfServerlessClusterIamPropertyToTerraform(struct?: TfServerlessCluster.IamPropertyOutputReference | TfServerlessCluster.IamProperty): any;
export declare function tfServerlessClusterIamPropertyToHclTerraform(struct?: TfServerlessCluster.IamPropertyOutputReference | TfServerlessCluster.IamProperty): any;
export declare function tfServerlessClusterSaslPropertyToTerraform(struct?: TfServerlessCluster.SaslPropertyOutputReference | TfServerlessCluster.SaslProperty): any;
export declare function tfServerlessClusterSaslPropertyToHclTerraform(struct?: TfServerlessCluster.SaslPropertyOutputReference | TfServerlessCluster.SaslProperty): any;
export declare function tfServerlessClusterClientAuthenticationPropertyToTerraform(struct?: TfServerlessCluster.ClientAuthenticationPropertyOutputReference | TfServerlessCluster.ClientAuthenticationProperty): any;
export declare function tfServerlessClusterClientAuthenticationPropertyToHclTerraform(struct?: TfServerlessCluster.ClientAuthenticationPropertyOutputReference | TfServerlessCluster.ClientAuthenticationProperty): any;
export declare function tfServerlessClusterTimeoutsPropertyToTerraform(struct?: TfServerlessCluster.TimeoutsProperty | cdktn.IResolvable): any;
export declare function tfServerlessClusterTimeoutsPropertyToHclTerraform(struct?: TfServerlessCluster.TimeoutsProperty | cdktn.IResolvable): any;
export declare function tfServerlessClusterVpcConfigPropertyToTerraform(struct?: TfServerlessCluster.VpcConfigProperty | cdktn.IResolvable): any;
export declare function tfServerlessClusterVpcConfigPropertyToHclTerraform(struct?: TfServerlessCluster.VpcConfigProperty | cdktn.IResolvable): any;
export declare namespace TfServerlessCluster {
    interface IamProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_serverless_cluster#enabled TfServerlessCluster#enabled}
        */
        readonly enabled: boolean | cdktn.IResolvable;
    }
    class IamPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): IamProperty | undefined;
        set internalValue(value: IamProperty | undefined);
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface SaslProperty {
        /**
        * iam block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_serverless_cluster#iam TfServerlessCluster#iam}
        */
        readonly iam: IamProperty;
    }
    class SaslPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SaslProperty | undefined;
        set internalValue(value: SaslProperty | undefined);
        private _iam;
        get iam(): IamPropertyOutputReference;
        putIam(value: IamProperty): void;
        get iamInput(): IamProperty | undefined;
    }
    interface ClientAuthenticationProperty {
        /**
        * sasl block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_serverless_cluster#sasl TfServerlessCluster#sasl}
        */
        readonly sasl: SaslProperty;
    }
    class ClientAuthenticationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ClientAuthenticationProperty | undefined;
        set internalValue(value: ClientAuthenticationProperty | undefined);
        private _sasl;
        get sasl(): SaslPropertyOutputReference;
        putSasl(value: SaslProperty): void;
        get saslInput(): SaslProperty | undefined;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_serverless_cluster#create TfServerlessCluster#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_serverless_cluster#delete TfServerlessCluster#delete}
        */
        readonly delete?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
    }
    interface VpcConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_serverless_cluster#security_group_ids TfServerlessCluster#security_group_ids}
        */
        readonly securityGroupIds?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_serverless_cluster#subnet_ids TfServerlessCluster#subnet_ids}
        */
        readonly subnetIds: string[];
    }
    class VpcConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): VpcConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: VpcConfigProperty | cdktn.IResolvable | undefined);
        private _securityGroupIds?;
        get securityGroupIds(): string[];
        set securityGroupIds(value: string[]);
        resetSecurityGroupIds(): void;
        get securityGroupIdsInput(): string[] | undefined;
        private _subnetIds?;
        get subnetIds(): string[];
        set subnetIds(value: string[]);
        get subnetIdsInput(): string[] | undefined;
    }
    class VpcConfigPropertyList extends cdktn.ComplexList {
        internalValue?: VpcConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): VpcConfigPropertyOutputReference;
    }
}
