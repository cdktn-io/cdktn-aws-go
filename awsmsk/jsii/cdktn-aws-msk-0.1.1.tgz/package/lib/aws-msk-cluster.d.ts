import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsMskClusterConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_cluster#cluster_name AwsMskCluster#cluster_name}
    */
    readonly clusterName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_cluster#enhanced_monitoring AwsMskCluster#enhanced_monitoring}
    */
    readonly enhancedMonitoring?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_cluster#id AwsMskCluster#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_cluster#kafka_version AwsMskCluster#kafka_version}
    */
    readonly kafkaVersion: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_cluster#number_of_broker_nodes AwsMskCluster#number_of_broker_nodes}
    */
    readonly numberOfBrokerNodes: number;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_cluster#region AwsMskCluster#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_cluster#storage_mode AwsMskCluster#storage_mode}
    */
    readonly storageMode?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_cluster#tags AwsMskCluster#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_cluster#tags_all AwsMskCluster#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * broker_node_group_info block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_cluster#broker_node_group_info AwsMskCluster#broker_node_group_info}
    */
    readonly brokerNodeGroupInfo: AwsMskCluster.BrokerNodeGroupInfoProperty;
    /**
    * client_authentication block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_cluster#client_authentication AwsMskCluster#client_authentication}
    */
    readonly clientAuthentication?: AwsMskCluster.ClientAuthenticationProperty;
    /**
    * configuration_info block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_cluster#configuration_info AwsMskCluster#configuration_info}
    */
    readonly configurationInfo?: AwsMskCluster.ConfigurationInfoProperty;
    /**
    * encryption_info block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_cluster#encryption_info AwsMskCluster#encryption_info}
    */
    readonly encryptionInfo?: AwsMskCluster.EncryptionInfoProperty;
    /**
    * logging_info block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_cluster#logging_info AwsMskCluster#logging_info}
    */
    readonly loggingInfo?: AwsMskCluster.LoggingInfoProperty;
    /**
    * open_monitoring block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_cluster#open_monitoring AwsMskCluster#open_monitoring}
    */
    readonly openMonitoring?: AwsMskCluster.OpenMonitoringProperty;
    /**
    * rebalancing block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_cluster#rebalancing AwsMskCluster#rebalancing}
    */
    readonly rebalancing?: AwsMskCluster.RebalancingProperty;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_cluster#timeouts AwsMskCluster#timeouts}
    */
    readonly timeouts?: AwsMskCluster.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_cluster aws_msk_cluster}
*/
export declare class AwsMskCluster extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_msk_cluster";
    /**
    * Generates CDKTN code for importing a AwsMskCluster resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsMskCluster to import
    * @param importFromId The id of the existing AwsMskCluster that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_cluster#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsMskCluster to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_cluster aws_msk_cluster} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsMskClusterConfig
    */
    constructor(scope: Construct, id: string, config: AwsMskClusterConfig);
    get arn(): string;
    get bootstrapBrokers(): string;
    get bootstrapBrokersIpv6(): string;
    get bootstrapBrokersPublicSaslIam(): string;
    get bootstrapBrokersPublicSaslScram(): string;
    get bootstrapBrokersPublicTls(): string;
    get bootstrapBrokersSaslIam(): string;
    get bootstrapBrokersSaslIamIpv6(): string;
    get bootstrapBrokersSaslScram(): string;
    get bootstrapBrokersSaslScramIpv6(): string;
    get bootstrapBrokersTls(): string;
    get bootstrapBrokersTlsIpv6(): string;
    get bootstrapBrokersVpcConnectivitySaslIam(): string;
    get bootstrapBrokersVpcConnectivitySaslScram(): string;
    get bootstrapBrokersVpcConnectivityTls(): string;
    private _clusterName?;
    get clusterName(): string;
    set clusterName(value: string);
    get clusterNameInput(): string | undefined;
    get clusterUuid(): string;
    get currentVersion(): string;
    get customerActionStatus(): string;
    private _enhancedMonitoring?;
    get enhancedMonitoring(): string;
    set enhancedMonitoring(value: string);
    resetEnhancedMonitoring(): void;
    get enhancedMonitoringInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _kafkaVersion?;
    get kafkaVersion(): string;
    set kafkaVersion(value: string);
    get kafkaVersionInput(): string | undefined;
    private _numberOfBrokerNodes?;
    get numberOfBrokerNodes(): number;
    set numberOfBrokerNodes(value: number);
    get numberOfBrokerNodesInput(): number | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _storageMode?;
    get storageMode(): string;
    set storageMode(value: string);
    resetStorageMode(): void;
    get storageModeInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    get zookeeperConnectString(): string;
    get zookeeperConnectStringTls(): string;
    private _brokerNodeGroupInfo;
    get brokerNodeGroupInfo(): AwsMskCluster.BrokerNodeGroupInfoPropertyOutputReference;
    putBrokerNodeGroupInfo(value: AwsMskCluster.BrokerNodeGroupInfoProperty): void;
    get brokerNodeGroupInfoInput(): AwsMskCluster.BrokerNodeGroupInfoProperty | undefined;
    private _clientAuthentication;
    get clientAuthentication(): AwsMskCluster.ClientAuthenticationPropertyOutputReference;
    putClientAuthentication(value: AwsMskCluster.ClientAuthenticationProperty): void;
    resetClientAuthentication(): void;
    get clientAuthenticationInput(): AwsMskCluster.ClientAuthenticationProperty | undefined;
    private _configurationInfo;
    get configurationInfo(): AwsMskCluster.ConfigurationInfoPropertyOutputReference;
    putConfigurationInfo(value: AwsMskCluster.ConfigurationInfoProperty): void;
    resetConfigurationInfo(): void;
    get configurationInfoInput(): AwsMskCluster.ConfigurationInfoProperty | undefined;
    private _encryptionInfo;
    get encryptionInfo(): AwsMskCluster.EncryptionInfoPropertyOutputReference;
    putEncryptionInfo(value: AwsMskCluster.EncryptionInfoProperty): void;
    resetEncryptionInfo(): void;
    get encryptionInfoInput(): AwsMskCluster.EncryptionInfoProperty | undefined;
    private _loggingInfo;
    get loggingInfo(): AwsMskCluster.LoggingInfoPropertyOutputReference;
    putLoggingInfo(value: AwsMskCluster.LoggingInfoProperty): void;
    resetLoggingInfo(): void;
    get loggingInfoInput(): AwsMskCluster.LoggingInfoProperty | undefined;
    private _openMonitoring;
    get openMonitoring(): AwsMskCluster.OpenMonitoringPropertyOutputReference;
    putOpenMonitoring(value: AwsMskCluster.OpenMonitoringProperty): void;
    resetOpenMonitoring(): void;
    get openMonitoringInput(): AwsMskCluster.OpenMonitoringProperty | undefined;
    private _rebalancing;
    get rebalancing(): AwsMskCluster.RebalancingPropertyOutputReference;
    putRebalancing(value: AwsMskCluster.RebalancingProperty): void;
    resetRebalancing(): void;
    get rebalancingInput(): AwsMskCluster.RebalancingProperty | undefined;
    private _timeouts;
    get timeouts(): AwsMskCluster.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsMskCluster.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): AwsMskCluster.TimeoutsProperty | cdktn.IResolvable | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsMskClusterPublicAccessPropertyToTerraform(struct?: AwsMskCluster.PublicAccessPropertyOutputReference | AwsMskCluster.PublicAccessProperty): any;
export declare function awsMskClusterPublicAccessPropertyToHclTerraform(struct?: AwsMskCluster.PublicAccessPropertyOutputReference | AwsMskCluster.PublicAccessProperty): any;
export declare function awsMskClusterBrokerNodeGroupInfoConnectivityInfoVpcConnectivityClientAuthenticationSaslPropertyToTerraform(struct?: AwsMskCluster.BrokerNodeGroupInfoConnectivityInfoVpcConnectivityClientAuthenticationSaslPropertyOutputReference | AwsMskCluster.BrokerNodeGroupInfoConnectivityInfoVpcConnectivityClientAuthenticationSaslProperty): any;
export declare function awsMskClusterBrokerNodeGroupInfoConnectivityInfoVpcConnectivityClientAuthenticationSaslPropertyToHclTerraform(struct?: AwsMskCluster.BrokerNodeGroupInfoConnectivityInfoVpcConnectivityClientAuthenticationSaslPropertyOutputReference | AwsMskCluster.BrokerNodeGroupInfoConnectivityInfoVpcConnectivityClientAuthenticationSaslProperty): any;
export declare function awsMskClusterBrokerNodeGroupInfoConnectivityInfoVpcConnectivityClientAuthenticationPropertyToTerraform(struct?: AwsMskCluster.BrokerNodeGroupInfoConnectivityInfoVpcConnectivityClientAuthenticationPropertyOutputReference | AwsMskCluster.BrokerNodeGroupInfoConnectivityInfoVpcConnectivityClientAuthenticationProperty): any;
export declare function awsMskClusterBrokerNodeGroupInfoConnectivityInfoVpcConnectivityClientAuthenticationPropertyToHclTerraform(struct?: AwsMskCluster.BrokerNodeGroupInfoConnectivityInfoVpcConnectivityClientAuthenticationPropertyOutputReference | AwsMskCluster.BrokerNodeGroupInfoConnectivityInfoVpcConnectivityClientAuthenticationProperty): any;
export declare function awsMskClusterVpcConnectivityPropertyToTerraform(struct?: AwsMskCluster.VpcConnectivityPropertyOutputReference | AwsMskCluster.VpcConnectivityProperty): any;
export declare function awsMskClusterVpcConnectivityPropertyToHclTerraform(struct?: AwsMskCluster.VpcConnectivityPropertyOutputReference | AwsMskCluster.VpcConnectivityProperty): any;
export declare function awsMskClusterConnectivityInfoPropertyToTerraform(struct?: AwsMskCluster.ConnectivityInfoPropertyOutputReference | AwsMskCluster.ConnectivityInfoProperty): any;
export declare function awsMskClusterConnectivityInfoPropertyToHclTerraform(struct?: AwsMskCluster.ConnectivityInfoPropertyOutputReference | AwsMskCluster.ConnectivityInfoProperty): any;
export declare function awsMskClusterProvisionedThroughputPropertyToTerraform(struct?: AwsMskCluster.ProvisionedThroughputPropertyOutputReference | AwsMskCluster.ProvisionedThroughputProperty): any;
export declare function awsMskClusterProvisionedThroughputPropertyToHclTerraform(struct?: AwsMskCluster.ProvisionedThroughputPropertyOutputReference | AwsMskCluster.ProvisionedThroughputProperty): any;
export declare function awsMskClusterEbsStorageInfoPropertyToTerraform(struct?: AwsMskCluster.EbsStorageInfoPropertyOutputReference | AwsMskCluster.EbsStorageInfoProperty): any;
export declare function awsMskClusterEbsStorageInfoPropertyToHclTerraform(struct?: AwsMskCluster.EbsStorageInfoPropertyOutputReference | AwsMskCluster.EbsStorageInfoProperty): any;
export declare function awsMskClusterStorageInfoPropertyToTerraform(struct?: AwsMskCluster.StorageInfoPropertyOutputReference | AwsMskCluster.StorageInfoProperty): any;
export declare function awsMskClusterStorageInfoPropertyToHclTerraform(struct?: AwsMskCluster.StorageInfoPropertyOutputReference | AwsMskCluster.StorageInfoProperty): any;
export declare function awsMskClusterBrokerNodeGroupInfoPropertyToTerraform(struct?: AwsMskCluster.BrokerNodeGroupInfoPropertyOutputReference | AwsMskCluster.BrokerNodeGroupInfoProperty): any;
export declare function awsMskClusterBrokerNodeGroupInfoPropertyToHclTerraform(struct?: AwsMskCluster.BrokerNodeGroupInfoPropertyOutputReference | AwsMskCluster.BrokerNodeGroupInfoProperty): any;
export declare function awsMskClusterClientAuthenticationSaslPropertyToTerraform(struct?: AwsMskCluster.ClientAuthenticationSaslPropertyOutputReference | AwsMskCluster.ClientAuthenticationSaslProperty): any;
export declare function awsMskClusterClientAuthenticationSaslPropertyToHclTerraform(struct?: AwsMskCluster.ClientAuthenticationSaslPropertyOutputReference | AwsMskCluster.ClientAuthenticationSaslProperty): any;
export declare function awsMskClusterTlsPropertyToTerraform(struct?: AwsMskCluster.TlsPropertyOutputReference | AwsMskCluster.TlsProperty): any;
export declare function awsMskClusterTlsPropertyToHclTerraform(struct?: AwsMskCluster.TlsPropertyOutputReference | AwsMskCluster.TlsProperty): any;
export declare function awsMskClusterClientAuthenticationPropertyToTerraform(struct?: AwsMskCluster.ClientAuthenticationPropertyOutputReference | AwsMskCluster.ClientAuthenticationProperty): any;
export declare function awsMskClusterClientAuthenticationPropertyToHclTerraform(struct?: AwsMskCluster.ClientAuthenticationPropertyOutputReference | AwsMskCluster.ClientAuthenticationProperty): any;
export declare function awsMskClusterConfigurationInfoPropertyToTerraform(struct?: AwsMskCluster.ConfigurationInfoPropertyOutputReference | AwsMskCluster.ConfigurationInfoProperty): any;
export declare function awsMskClusterConfigurationInfoPropertyToHclTerraform(struct?: AwsMskCluster.ConfigurationInfoPropertyOutputReference | AwsMskCluster.ConfigurationInfoProperty): any;
export declare function awsMskClusterEncryptionInTransitPropertyToTerraform(struct?: AwsMskCluster.EncryptionInTransitPropertyOutputReference | AwsMskCluster.EncryptionInTransitProperty): any;
export declare function awsMskClusterEncryptionInTransitPropertyToHclTerraform(struct?: AwsMskCluster.EncryptionInTransitPropertyOutputReference | AwsMskCluster.EncryptionInTransitProperty): any;
export declare function awsMskClusterEncryptionInfoPropertyToTerraform(struct?: AwsMskCluster.EncryptionInfoPropertyOutputReference | AwsMskCluster.EncryptionInfoProperty): any;
export declare function awsMskClusterEncryptionInfoPropertyToHclTerraform(struct?: AwsMskCluster.EncryptionInfoPropertyOutputReference | AwsMskCluster.EncryptionInfoProperty): any;
export declare function awsMskClusterCloudwatchLogsPropertyToTerraform(struct?: AwsMskCluster.CloudwatchLogsPropertyOutputReference | AwsMskCluster.CloudwatchLogsProperty): any;
export declare function awsMskClusterCloudwatchLogsPropertyToHclTerraform(struct?: AwsMskCluster.CloudwatchLogsPropertyOutputReference | AwsMskCluster.CloudwatchLogsProperty): any;
export declare function awsMskClusterFirehosePropertyToTerraform(struct?: AwsMskCluster.FirehosePropertyOutputReference | AwsMskCluster.FirehoseProperty): any;
export declare function awsMskClusterFirehosePropertyToHclTerraform(struct?: AwsMskCluster.FirehosePropertyOutputReference | AwsMskCluster.FirehoseProperty): any;
export declare function awsMskClusterS3PropertyToTerraform(struct?: AwsMskCluster.S3PropertyOutputReference | AwsMskCluster.S3Property): any;
export declare function awsMskClusterS3PropertyToHclTerraform(struct?: AwsMskCluster.S3PropertyOutputReference | AwsMskCluster.S3Property): any;
export declare function awsMskClusterBrokerLogsPropertyToTerraform(struct?: AwsMskCluster.BrokerLogsPropertyOutputReference | AwsMskCluster.BrokerLogsProperty): any;
export declare function awsMskClusterBrokerLogsPropertyToHclTerraform(struct?: AwsMskCluster.BrokerLogsPropertyOutputReference | AwsMskCluster.BrokerLogsProperty): any;
export declare function awsMskClusterLoggingInfoPropertyToTerraform(struct?: AwsMskCluster.LoggingInfoPropertyOutputReference | AwsMskCluster.LoggingInfoProperty): any;
export declare function awsMskClusterLoggingInfoPropertyToHclTerraform(struct?: AwsMskCluster.LoggingInfoPropertyOutputReference | AwsMskCluster.LoggingInfoProperty): any;
export declare function awsMskClusterJmxExporterPropertyToTerraform(struct?: AwsMskCluster.JmxExporterPropertyOutputReference | AwsMskCluster.JmxExporterProperty): any;
export declare function awsMskClusterJmxExporterPropertyToHclTerraform(struct?: AwsMskCluster.JmxExporterPropertyOutputReference | AwsMskCluster.JmxExporterProperty): any;
export declare function awsMskClusterNodeExporterPropertyToTerraform(struct?: AwsMskCluster.NodeExporterPropertyOutputReference | AwsMskCluster.NodeExporterProperty): any;
export declare function awsMskClusterNodeExporterPropertyToHclTerraform(struct?: AwsMskCluster.NodeExporterPropertyOutputReference | AwsMskCluster.NodeExporterProperty): any;
export declare function awsMskClusterPrometheusPropertyToTerraform(struct?: AwsMskCluster.PrometheusPropertyOutputReference | AwsMskCluster.PrometheusProperty): any;
export declare function awsMskClusterPrometheusPropertyToHclTerraform(struct?: AwsMskCluster.PrometheusPropertyOutputReference | AwsMskCluster.PrometheusProperty): any;
export declare function awsMskClusterOpenMonitoringPropertyToTerraform(struct?: AwsMskCluster.OpenMonitoringPropertyOutputReference | AwsMskCluster.OpenMonitoringProperty): any;
export declare function awsMskClusterOpenMonitoringPropertyToHclTerraform(struct?: AwsMskCluster.OpenMonitoringPropertyOutputReference | AwsMskCluster.OpenMonitoringProperty): any;
export declare function awsMskClusterRebalancingPropertyToTerraform(struct?: AwsMskCluster.RebalancingPropertyOutputReference | AwsMskCluster.RebalancingProperty): any;
export declare function awsMskClusterRebalancingPropertyToHclTerraform(struct?: AwsMskCluster.RebalancingPropertyOutputReference | AwsMskCluster.RebalancingProperty): any;
export declare function awsMskClusterTimeoutsPropertyToTerraform(struct?: AwsMskCluster.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsMskClusterTimeoutsPropertyToHclTerraform(struct?: AwsMskCluster.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsMskCluster {
    interface PublicAccessProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_cluster#type AwsMskCluster#type}
        */
        readonly type?: string;
    }
    class PublicAccessPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): PublicAccessProperty | undefined;
        set internalValue(value: PublicAccessProperty | undefined);
        private _type?;
        get type(): string;
        set type(value: string);
        resetType(): void;
        get typeInput(): string | undefined;
    }
    interface BrokerNodeGroupInfoConnectivityInfoVpcConnectivityClientAuthenticationSaslProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_cluster#iam AwsMskCluster#iam}
        */
        readonly iam?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_cluster#scram AwsMskCluster#scram}
        */
        readonly scram?: boolean | cdktn.IResolvable;
    }
    class BrokerNodeGroupInfoConnectivityInfoVpcConnectivityClientAuthenticationSaslPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): BrokerNodeGroupInfoConnectivityInfoVpcConnectivityClientAuthenticationSaslProperty | undefined;
        set internalValue(value: BrokerNodeGroupInfoConnectivityInfoVpcConnectivityClientAuthenticationSaslProperty | undefined);
        private _iam?;
        get iam(): boolean | cdktn.IResolvable;
        set iam(value: boolean | cdktn.IResolvable);
        resetIam(): void;
        get iamInput(): boolean | cdktn.IResolvable | undefined;
        private _scram?;
        get scram(): boolean | cdktn.IResolvable;
        set scram(value: boolean | cdktn.IResolvable);
        resetScram(): void;
        get scramInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface BrokerNodeGroupInfoConnectivityInfoVpcConnectivityClientAuthenticationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_cluster#tls AwsMskCluster#tls}
        */
        readonly tls?: boolean | cdktn.IResolvable;
        /**
        * sasl block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_cluster#sasl AwsMskCluster#sasl}
        */
        readonly sasl?: BrokerNodeGroupInfoConnectivityInfoVpcConnectivityClientAuthenticationSaslProperty;
    }
    class BrokerNodeGroupInfoConnectivityInfoVpcConnectivityClientAuthenticationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): BrokerNodeGroupInfoConnectivityInfoVpcConnectivityClientAuthenticationProperty | undefined;
        set internalValue(value: BrokerNodeGroupInfoConnectivityInfoVpcConnectivityClientAuthenticationProperty | undefined);
        private _tls?;
        get tls(): boolean | cdktn.IResolvable;
        set tls(value: boolean | cdktn.IResolvable);
        resetTls(): void;
        get tlsInput(): boolean | cdktn.IResolvable | undefined;
        private _sasl;
        get sasl(): BrokerNodeGroupInfoConnectivityInfoVpcConnectivityClientAuthenticationSaslPropertyOutputReference;
        putSasl(value: BrokerNodeGroupInfoConnectivityInfoVpcConnectivityClientAuthenticationSaslProperty): void;
        resetSasl(): void;
        get saslInput(): BrokerNodeGroupInfoConnectivityInfoVpcConnectivityClientAuthenticationSaslProperty | undefined;
    }
    interface VpcConnectivityProperty {
        /**
        * client_authentication block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_cluster#client_authentication AwsMskCluster#client_authentication}
        */
        readonly clientAuthentication?: BrokerNodeGroupInfoConnectivityInfoVpcConnectivityClientAuthenticationProperty;
    }
    class VpcConnectivityPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): VpcConnectivityProperty | undefined;
        set internalValue(value: VpcConnectivityProperty | undefined);
        private _clientAuthentication;
        get clientAuthentication(): BrokerNodeGroupInfoConnectivityInfoVpcConnectivityClientAuthenticationPropertyOutputReference;
        putClientAuthentication(value: BrokerNodeGroupInfoConnectivityInfoVpcConnectivityClientAuthenticationProperty): void;
        resetClientAuthentication(): void;
        get clientAuthenticationInput(): BrokerNodeGroupInfoConnectivityInfoVpcConnectivityClientAuthenticationProperty | undefined;
    }
    interface ConnectivityInfoProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_cluster#network_type AwsMskCluster#network_type}
        */
        readonly networkType?: string;
        /**
        * public_access block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_cluster#public_access AwsMskCluster#public_access}
        */
        readonly publicAccess?: PublicAccessProperty;
        /**
        * vpc_connectivity block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_cluster#vpc_connectivity AwsMskCluster#vpc_connectivity}
        */
        readonly vpcConnectivity?: VpcConnectivityProperty;
    }
    class ConnectivityInfoPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ConnectivityInfoProperty | undefined;
        set internalValue(value: ConnectivityInfoProperty | undefined);
        private _networkType?;
        get networkType(): string;
        set networkType(value: string);
        resetNetworkType(): void;
        get networkTypeInput(): string | undefined;
        private _publicAccess;
        get publicAccess(): PublicAccessPropertyOutputReference;
        putPublicAccess(value: PublicAccessProperty): void;
        resetPublicAccess(): void;
        get publicAccessInput(): PublicAccessProperty | undefined;
        private _vpcConnectivity;
        get vpcConnectivity(): VpcConnectivityPropertyOutputReference;
        putVpcConnectivity(value: VpcConnectivityProperty): void;
        resetVpcConnectivity(): void;
        get vpcConnectivityInput(): VpcConnectivityProperty | undefined;
    }
    interface ProvisionedThroughputProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_cluster#enabled AwsMskCluster#enabled}
        */
        readonly enabled?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_cluster#volume_throughput AwsMskCluster#volume_throughput}
        */
        readonly volumeThroughput?: number;
    }
    class ProvisionedThroughputPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ProvisionedThroughputProperty | undefined;
        set internalValue(value: ProvisionedThroughputProperty | undefined);
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        resetEnabled(): void;
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
        private _volumeThroughput?;
        get volumeThroughput(): number;
        set volumeThroughput(value: number);
        resetVolumeThroughput(): void;
        get volumeThroughputInput(): number | undefined;
    }
    interface EbsStorageInfoProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_cluster#volume_size AwsMskCluster#volume_size}
        */
        readonly volumeSize?: number;
        /**
        * provisioned_throughput block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_cluster#provisioned_throughput AwsMskCluster#provisioned_throughput}
        */
        readonly provisionedThroughput?: ProvisionedThroughputProperty;
    }
    class EbsStorageInfoPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): EbsStorageInfoProperty | undefined;
        set internalValue(value: EbsStorageInfoProperty | undefined);
        private _volumeSize?;
        get volumeSize(): number;
        set volumeSize(value: number);
        resetVolumeSize(): void;
        get volumeSizeInput(): number | undefined;
        private _provisionedThroughput;
        get provisionedThroughput(): ProvisionedThroughputPropertyOutputReference;
        putProvisionedThroughput(value: ProvisionedThroughputProperty): void;
        resetProvisionedThroughput(): void;
        get provisionedThroughputInput(): ProvisionedThroughputProperty | undefined;
    }
    interface StorageInfoProperty {
        /**
        * ebs_storage_info block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_cluster#ebs_storage_info AwsMskCluster#ebs_storage_info}
        */
        readonly ebsStorageInfo?: EbsStorageInfoProperty;
    }
    class StorageInfoPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): StorageInfoProperty | undefined;
        set internalValue(value: StorageInfoProperty | undefined);
        private _ebsStorageInfo;
        get ebsStorageInfo(): EbsStorageInfoPropertyOutputReference;
        putEbsStorageInfo(value: EbsStorageInfoProperty): void;
        resetEbsStorageInfo(): void;
        get ebsStorageInfoInput(): EbsStorageInfoProperty | undefined;
    }
    interface BrokerNodeGroupInfoProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_cluster#az_distribution AwsMskCluster#az_distribution}
        */
        readonly azDistribution?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_cluster#client_subnets AwsMskCluster#client_subnets}
        */
        readonly clientSubnets: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_cluster#instance_type AwsMskCluster#instance_type}
        */
        readonly instanceType: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_cluster#security_groups AwsMskCluster#security_groups}
        */
        readonly securityGroups: string[];
        /**
        * connectivity_info block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_cluster#connectivity_info AwsMskCluster#connectivity_info}
        */
        readonly connectivityInfo?: ConnectivityInfoProperty;
        /**
        * storage_info block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_cluster#storage_info AwsMskCluster#storage_info}
        */
        readonly storageInfo?: StorageInfoProperty;
    }
    class BrokerNodeGroupInfoPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): BrokerNodeGroupInfoProperty | undefined;
        set internalValue(value: BrokerNodeGroupInfoProperty | undefined);
        private _azDistribution?;
        get azDistribution(): string;
        set azDistribution(value: string);
        resetAzDistribution(): void;
        get azDistributionInput(): string | undefined;
        private _clientSubnets?;
        get clientSubnets(): string[];
        set clientSubnets(value: string[]);
        get clientSubnetsInput(): string[] | undefined;
        private _instanceType?;
        get instanceType(): string;
        set instanceType(value: string);
        get instanceTypeInput(): string | undefined;
        private _securityGroups?;
        get securityGroups(): string[];
        set securityGroups(value: string[]);
        get securityGroupsInput(): string[] | undefined;
        private _connectivityInfo;
        get connectivityInfo(): ConnectivityInfoPropertyOutputReference;
        putConnectivityInfo(value: ConnectivityInfoProperty): void;
        resetConnectivityInfo(): void;
        get connectivityInfoInput(): ConnectivityInfoProperty | undefined;
        private _storageInfo;
        get storageInfo(): StorageInfoPropertyOutputReference;
        putStorageInfo(value: StorageInfoProperty): void;
        resetStorageInfo(): void;
        get storageInfoInput(): StorageInfoProperty | undefined;
    }
    interface ClientAuthenticationSaslProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_cluster#iam AwsMskCluster#iam}
        */
        readonly iam?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_cluster#scram AwsMskCluster#scram}
        */
        readonly scram?: boolean | cdktn.IResolvable;
    }
    class ClientAuthenticationSaslPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ClientAuthenticationSaslProperty | undefined;
        set internalValue(value: ClientAuthenticationSaslProperty | undefined);
        private _iam?;
        get iam(): boolean | cdktn.IResolvable;
        set iam(value: boolean | cdktn.IResolvable);
        resetIam(): void;
        get iamInput(): boolean | cdktn.IResolvable | undefined;
        private _scram?;
        get scram(): boolean | cdktn.IResolvable;
        set scram(value: boolean | cdktn.IResolvable);
        resetScram(): void;
        get scramInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface TlsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_cluster#certificate_authority_arns AwsMskCluster#certificate_authority_arns}
        */
        readonly certificateAuthorityArns?: string[];
    }
    class TlsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TlsProperty | undefined;
        set internalValue(value: TlsProperty | undefined);
        private _certificateAuthorityArns?;
        get certificateAuthorityArns(): string[];
        set certificateAuthorityArns(value: string[]);
        resetCertificateAuthorityArns(): void;
        get certificateAuthorityArnsInput(): string[] | undefined;
    }
    interface ClientAuthenticationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_cluster#unauthenticated AwsMskCluster#unauthenticated}
        */
        readonly unauthenticated?: boolean | cdktn.IResolvable;
        /**
        * sasl block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_cluster#sasl AwsMskCluster#sasl}
        */
        readonly sasl?: ClientAuthenticationSaslProperty;
        /**
        * tls block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_cluster#tls AwsMskCluster#tls}
        */
        readonly tls?: TlsProperty;
    }
    class ClientAuthenticationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ClientAuthenticationProperty | undefined;
        set internalValue(value: ClientAuthenticationProperty | undefined);
        private _unauthenticated?;
        get unauthenticated(): boolean | cdktn.IResolvable;
        set unauthenticated(value: boolean | cdktn.IResolvable);
        resetUnauthenticated(): void;
        get unauthenticatedInput(): boolean | cdktn.IResolvable | undefined;
        private _sasl;
        get sasl(): ClientAuthenticationSaslPropertyOutputReference;
        putSasl(value: ClientAuthenticationSaslProperty): void;
        resetSasl(): void;
        get saslInput(): ClientAuthenticationSaslProperty | undefined;
        private _tls;
        get tls(): TlsPropertyOutputReference;
        putTls(value: TlsProperty): void;
        resetTls(): void;
        get tlsInput(): TlsProperty | undefined;
    }
    interface ConfigurationInfoProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_cluster#arn AwsMskCluster#arn}
        */
        readonly arn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_cluster#revision AwsMskCluster#revision}
        */
        readonly revision: number;
    }
    class ConfigurationInfoPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ConfigurationInfoProperty | undefined;
        set internalValue(value: ConfigurationInfoProperty | undefined);
        private _arn?;
        get arn(): string;
        set arn(value: string);
        get arnInput(): string | undefined;
        private _revision?;
        get revision(): number;
        set revision(value: number);
        get revisionInput(): number | undefined;
    }
    interface EncryptionInTransitProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_cluster#client_broker AwsMskCluster#client_broker}
        */
        readonly clientBroker?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_cluster#in_cluster AwsMskCluster#in_cluster}
        */
        readonly inCluster?: boolean | cdktn.IResolvable;
    }
    class EncryptionInTransitPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): EncryptionInTransitProperty | undefined;
        set internalValue(value: EncryptionInTransitProperty | undefined);
        private _clientBroker?;
        get clientBroker(): string;
        set clientBroker(value: string);
        resetClientBroker(): void;
        get clientBrokerInput(): string | undefined;
        private _inCluster?;
        get inCluster(): boolean | cdktn.IResolvable;
        set inCluster(value: boolean | cdktn.IResolvable);
        resetInCluster(): void;
        get inClusterInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface EncryptionInfoProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_cluster#encryption_at_rest_kms_key_arn AwsMskCluster#encryption_at_rest_kms_key_arn}
        */
        readonly encryptionAtRestKmsKeyArn?: string;
        /**
        * encryption_in_transit block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_cluster#encryption_in_transit AwsMskCluster#encryption_in_transit}
        */
        readonly encryptionInTransit?: EncryptionInTransitProperty;
    }
    class EncryptionInfoPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): EncryptionInfoProperty | undefined;
        set internalValue(value: EncryptionInfoProperty | undefined);
        private _encryptionAtRestKmsKeyArn?;
        get encryptionAtRestKmsKeyArn(): string;
        set encryptionAtRestKmsKeyArn(value: string);
        resetEncryptionAtRestKmsKeyArn(): void;
        get encryptionAtRestKmsKeyArnInput(): string | undefined;
        private _encryptionInTransit;
        get encryptionInTransit(): EncryptionInTransitPropertyOutputReference;
        putEncryptionInTransit(value: EncryptionInTransitProperty): void;
        resetEncryptionInTransit(): void;
        get encryptionInTransitInput(): EncryptionInTransitProperty | undefined;
    }
    interface CloudwatchLogsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_cluster#enabled AwsMskCluster#enabled}
        */
        readonly enabled: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_cluster#log_group AwsMskCluster#log_group}
        */
        readonly logGroup?: string;
    }
    class CloudwatchLogsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CloudwatchLogsProperty | undefined;
        set internalValue(value: CloudwatchLogsProperty | undefined);
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
        private _logGroup?;
        get logGroup(): string;
        set logGroup(value: string);
        resetLogGroup(): void;
        get logGroupInput(): string | undefined;
    }
    interface FirehoseProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_cluster#delivery_stream AwsMskCluster#delivery_stream}
        */
        readonly deliveryStream?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_cluster#enabled AwsMskCluster#enabled}
        */
        readonly enabled: boolean | cdktn.IResolvable;
    }
    class FirehosePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): FirehoseProperty | undefined;
        set internalValue(value: FirehoseProperty | undefined);
        private _deliveryStream?;
        get deliveryStream(): string;
        set deliveryStream(value: string);
        resetDeliveryStream(): void;
        get deliveryStreamInput(): string | undefined;
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface S3Property {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_cluster#bucket AwsMskCluster#bucket}
        */
        readonly bucket?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_cluster#enabled AwsMskCluster#enabled}
        */
        readonly enabled: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_cluster#prefix AwsMskCluster#prefix}
        */
        readonly prefix?: string;
    }
    class S3PropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): S3Property | undefined;
        set internalValue(value: S3Property | undefined);
        private _bucket?;
        get bucket(): string;
        set bucket(value: string);
        resetBucket(): void;
        get bucketInput(): string | undefined;
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
        private _prefix?;
        get prefix(): string;
        set prefix(value: string);
        resetPrefix(): void;
        get prefixInput(): string | undefined;
    }
    interface BrokerLogsProperty {
        /**
        * cloudwatch_logs block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_cluster#cloudwatch_logs AwsMskCluster#cloudwatch_logs}
        */
        readonly cloudwatchLogs?: CloudwatchLogsProperty;
        /**
        * firehose block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_cluster#firehose AwsMskCluster#firehose}
        */
        readonly firehose?: FirehoseProperty;
        /**
        * s3 block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_cluster#s3 AwsMskCluster#s3}
        */
        readonly s3?: S3Property;
    }
    class BrokerLogsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): BrokerLogsProperty | undefined;
        set internalValue(value: BrokerLogsProperty | undefined);
        private _cloudwatchLogs;
        get cloudwatchLogs(): CloudwatchLogsPropertyOutputReference;
        putCloudwatchLogs(value: CloudwatchLogsProperty): void;
        resetCloudwatchLogs(): void;
        get cloudwatchLogsInput(): CloudwatchLogsProperty | undefined;
        private _firehose;
        get firehose(): FirehosePropertyOutputReference;
        putFirehose(value: FirehoseProperty): void;
        resetFirehose(): void;
        get firehoseInput(): FirehoseProperty | undefined;
        private _s3;
        get s3(): S3PropertyOutputReference;
        putS3(value: S3Property): void;
        resetS3(): void;
        get s3Input(): S3Property | undefined;
    }
    interface LoggingInfoProperty {
        /**
        * broker_logs block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_cluster#broker_logs AwsMskCluster#broker_logs}
        */
        readonly brokerLogs: BrokerLogsProperty;
    }
    class LoggingInfoPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): LoggingInfoProperty | undefined;
        set internalValue(value: LoggingInfoProperty | undefined);
        private _brokerLogs;
        get brokerLogs(): BrokerLogsPropertyOutputReference;
        putBrokerLogs(value: BrokerLogsProperty): void;
        get brokerLogsInput(): BrokerLogsProperty | undefined;
    }
    interface JmxExporterProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_cluster#enabled_in_broker AwsMskCluster#enabled_in_broker}
        */
        readonly enabledInBroker: boolean | cdktn.IResolvable;
    }
    class JmxExporterPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): JmxExporterProperty | undefined;
        set internalValue(value: JmxExporterProperty | undefined);
        private _enabledInBroker?;
        get enabledInBroker(): boolean | cdktn.IResolvable;
        set enabledInBroker(value: boolean | cdktn.IResolvable);
        get enabledInBrokerInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface NodeExporterProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_cluster#enabled_in_broker AwsMskCluster#enabled_in_broker}
        */
        readonly enabledInBroker: boolean | cdktn.IResolvable;
    }
    class NodeExporterPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): NodeExporterProperty | undefined;
        set internalValue(value: NodeExporterProperty | undefined);
        private _enabledInBroker?;
        get enabledInBroker(): boolean | cdktn.IResolvable;
        set enabledInBroker(value: boolean | cdktn.IResolvable);
        get enabledInBrokerInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface PrometheusProperty {
        /**
        * jmx_exporter block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_cluster#jmx_exporter AwsMskCluster#jmx_exporter}
        */
        readonly jmxExporter?: JmxExporterProperty;
        /**
        * node_exporter block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_cluster#node_exporter AwsMskCluster#node_exporter}
        */
        readonly nodeExporter?: NodeExporterProperty;
    }
    class PrometheusPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): PrometheusProperty | undefined;
        set internalValue(value: PrometheusProperty | undefined);
        private _jmxExporter;
        get jmxExporter(): JmxExporterPropertyOutputReference;
        putJmxExporter(value: JmxExporterProperty): void;
        resetJmxExporter(): void;
        get jmxExporterInput(): JmxExporterProperty | undefined;
        private _nodeExporter;
        get nodeExporter(): NodeExporterPropertyOutputReference;
        putNodeExporter(value: NodeExporterProperty): void;
        resetNodeExporter(): void;
        get nodeExporterInput(): NodeExporterProperty | undefined;
    }
    interface OpenMonitoringProperty {
        /**
        * prometheus block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_cluster#prometheus AwsMskCluster#prometheus}
        */
        readonly prometheus: PrometheusProperty;
    }
    class OpenMonitoringPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): OpenMonitoringProperty | undefined;
        set internalValue(value: OpenMonitoringProperty | undefined);
        private _prometheus;
        get prometheus(): PrometheusPropertyOutputReference;
        putPrometheus(value: PrometheusProperty): void;
        get prometheusInput(): PrometheusProperty | undefined;
    }
    interface RebalancingProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_cluster#status AwsMskCluster#status}
        */
        readonly status: string;
    }
    class RebalancingPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RebalancingProperty | undefined;
        set internalValue(value: RebalancingProperty | undefined);
        private _status?;
        get status(): string;
        set status(value: string);
        get statusInput(): string | undefined;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_cluster#create AwsMskCluster#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_cluster#delete AwsMskCluster#delete}
        */
        readonly delete?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_cluster#update AwsMskCluster#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
