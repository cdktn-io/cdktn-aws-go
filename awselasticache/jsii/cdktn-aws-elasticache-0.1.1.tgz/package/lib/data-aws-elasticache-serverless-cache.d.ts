import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsElasticacheServerlessCacheConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/elasticache_serverless_cache#name DataAwsElasticacheServerlessCache#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/elasticache_serverless_cache#region DataAwsElasticacheServerlessCache#region}
    */
    readonly region?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/elasticache_serverless_cache aws_elasticache_serverless_cache}
*/
export declare class DataAwsElasticacheServerlessCache extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_elasticache_serverless_cache";
    /**
    * Generates CDKTN code for importing a DataAwsElasticacheServerlessCache resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsElasticacheServerlessCache to import
    * @param importFromId The id of the existing DataAwsElasticacheServerlessCache that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/elasticache_serverless_cache#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsElasticacheServerlessCache to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/elasticache_serverless_cache aws_elasticache_serverless_cache} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsElasticacheServerlessCacheConfig
    */
    constructor(scope: Construct, id: string, config: DataAwsElasticacheServerlessCacheConfig);
    get arn(): string;
    private _cacheUsageLimits;
    get cacheUsageLimits(): DataAwsElasticacheServerlessCache.CacheUsageLimitsPropertyOutputReference;
    get createTime(): string;
    get dailySnapshotTime(): string;
    get description(): string;
    private _endpoint;
    get endpoint(): DataAwsElasticacheServerlessCache.EndpointPropertyOutputReference;
    get engine(): string;
    get fullEngineVersion(): string;
    get kmsKeyId(): string;
    get majorEngineVersion(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _readerEndpoint;
    get readerEndpoint(): DataAwsElasticacheServerlessCache.ReaderEndpointPropertyOutputReference;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get securityGroupIds(): string[];
    get snapshotRetentionLimit(): number;
    get status(): string;
    get subnetIds(): string[];
    get userGroupId(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataAwsElasticacheServerlessCacheDataStoragePropertyToTerraform(struct?: DataAwsElasticacheServerlessCache.DataStorageProperty): any;
export declare function dataAwsElasticacheServerlessCacheDataStoragePropertyToHclTerraform(struct?: DataAwsElasticacheServerlessCache.DataStorageProperty): any;
export declare function dataAwsElasticacheServerlessCacheEcpuPerSecondPropertyToTerraform(struct?: DataAwsElasticacheServerlessCache.EcpuPerSecondProperty): any;
export declare function dataAwsElasticacheServerlessCacheEcpuPerSecondPropertyToHclTerraform(struct?: DataAwsElasticacheServerlessCache.EcpuPerSecondProperty): any;
export declare function dataAwsElasticacheServerlessCacheCacheUsageLimitsPropertyToTerraform(struct?: DataAwsElasticacheServerlessCache.CacheUsageLimitsProperty): any;
export declare function dataAwsElasticacheServerlessCacheCacheUsageLimitsPropertyToHclTerraform(struct?: DataAwsElasticacheServerlessCache.CacheUsageLimitsProperty): any;
export declare function dataAwsElasticacheServerlessCacheEndpointPropertyToTerraform(struct?: DataAwsElasticacheServerlessCache.EndpointProperty): any;
export declare function dataAwsElasticacheServerlessCacheEndpointPropertyToHclTerraform(struct?: DataAwsElasticacheServerlessCache.EndpointProperty): any;
export declare function dataAwsElasticacheServerlessCacheReaderEndpointPropertyToTerraform(struct?: DataAwsElasticacheServerlessCache.ReaderEndpointProperty): any;
export declare function dataAwsElasticacheServerlessCacheReaderEndpointPropertyToHclTerraform(struct?: DataAwsElasticacheServerlessCache.ReaderEndpointProperty): any;
export declare namespace DataAwsElasticacheServerlessCache {
    interface DataStorageProperty {
    }
    class DataStoragePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DataStorageProperty | undefined;
        set internalValue(value: DataStorageProperty | undefined);
        get maximum(): number;
        get minimum(): number;
        get unit(): string;
    }
    interface EcpuPerSecondProperty {
    }
    class EcpuPerSecondPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): EcpuPerSecondProperty | undefined;
        set internalValue(value: EcpuPerSecondProperty | undefined);
        get maximum(): number;
        get minimum(): number;
    }
    interface CacheUsageLimitsProperty {
    }
    class CacheUsageLimitsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CacheUsageLimitsProperty | undefined;
        set internalValue(value: CacheUsageLimitsProperty | undefined);
        private _dataStorage;
        get dataStorage(): DataStoragePropertyOutputReference;
        private _ecpuPerSecond;
        get ecpuPerSecond(): EcpuPerSecondPropertyOutputReference;
    }
    interface EndpointProperty {
    }
    class EndpointPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): EndpointProperty | undefined;
        set internalValue(value: EndpointProperty | undefined);
        get address(): string;
        get port(): number;
    }
    interface ReaderEndpointProperty {
    }
    class ReaderEndpointPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ReaderEndpointProperty | undefined;
        set internalValue(value: ReaderEndpointProperty | undefined);
        get address(): string;
        get port(): number;
    }
}
