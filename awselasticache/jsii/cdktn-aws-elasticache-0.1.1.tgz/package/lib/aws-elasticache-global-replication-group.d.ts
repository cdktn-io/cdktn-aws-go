import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsElasticacheGlobalReplicationGroupConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticache_global_replication_group#automatic_failover_enabled AwsElasticacheGlobalReplicationGroup#automatic_failover_enabled}
    */
    readonly automaticFailoverEnabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticache_global_replication_group#cache_node_type AwsElasticacheGlobalReplicationGroup#cache_node_type}
    */
    readonly cacheNodeType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticache_global_replication_group#engine AwsElasticacheGlobalReplicationGroup#engine}
    */
    readonly engine?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticache_global_replication_group#engine_version AwsElasticacheGlobalReplicationGroup#engine_version}
    */
    readonly engineVersion?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticache_global_replication_group#global_replication_group_description AwsElasticacheGlobalReplicationGroup#global_replication_group_description}
    */
    readonly globalReplicationGroupDescription?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticache_global_replication_group#global_replication_group_id_suffix AwsElasticacheGlobalReplicationGroup#global_replication_group_id_suffix}
    */
    readonly globalReplicationGroupIdSuffix: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticache_global_replication_group#id AwsElasticacheGlobalReplicationGroup#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticache_global_replication_group#num_node_groups AwsElasticacheGlobalReplicationGroup#num_node_groups}
    */
    readonly numNodeGroups?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticache_global_replication_group#parameter_group_name AwsElasticacheGlobalReplicationGroup#parameter_group_name}
    */
    readonly parameterGroupName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticache_global_replication_group#primary_replication_group_id AwsElasticacheGlobalReplicationGroup#primary_replication_group_id}
    */
    readonly primaryReplicationGroupId: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticache_global_replication_group#region AwsElasticacheGlobalReplicationGroup#region}
    */
    readonly region?: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticache_global_replication_group#timeouts AwsElasticacheGlobalReplicationGroup#timeouts}
    */
    readonly timeouts?: AwsElasticacheGlobalReplicationGroup.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticache_global_replication_group aws_elasticache_global_replication_group}
*/
export declare class AwsElasticacheGlobalReplicationGroup extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_elasticache_global_replication_group";
    /**
    * Generates CDKTN code for importing a AwsElasticacheGlobalReplicationGroup resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsElasticacheGlobalReplicationGroup to import
    * @param importFromId The id of the existing AwsElasticacheGlobalReplicationGroup that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticache_global_replication_group#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsElasticacheGlobalReplicationGroup to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticache_global_replication_group aws_elasticache_global_replication_group} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsElasticacheGlobalReplicationGroupConfig
    */
    constructor(scope: Construct, id: string, config: AwsElasticacheGlobalReplicationGroupConfig);
    get arn(): string;
    get atRestEncryptionEnabled(): cdktn.IResolvable;
    get authTokenEnabled(): cdktn.IResolvable;
    private _automaticFailoverEnabled?;
    get automaticFailoverEnabled(): boolean | cdktn.IResolvable;
    set automaticFailoverEnabled(value: boolean | cdktn.IResolvable);
    resetAutomaticFailoverEnabled(): void;
    get automaticFailoverEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _cacheNodeType?;
    get cacheNodeType(): string;
    set cacheNodeType(value: string);
    resetCacheNodeType(): void;
    get cacheNodeTypeInput(): string | undefined;
    get clusterEnabled(): cdktn.IResolvable;
    private _engine?;
    get engine(): string;
    set engine(value: string);
    resetEngine(): void;
    get engineInput(): string | undefined;
    private _engineVersion?;
    get engineVersion(): string;
    set engineVersion(value: string);
    resetEngineVersion(): void;
    get engineVersionInput(): string | undefined;
    get engineVersionActual(): string;
    private _globalNodeGroups;
    get globalNodeGroups(): AwsElasticacheGlobalReplicationGroup.GlobalNodeGroupsPropertyList;
    private _globalReplicationGroupDescription?;
    get globalReplicationGroupDescription(): string;
    set globalReplicationGroupDescription(value: string);
    resetGlobalReplicationGroupDescription(): void;
    get globalReplicationGroupDescriptionInput(): string | undefined;
    get globalReplicationGroupId(): string;
    private _globalReplicationGroupIdSuffix?;
    get globalReplicationGroupIdSuffix(): string;
    set globalReplicationGroupIdSuffix(value: string);
    get globalReplicationGroupIdSuffixInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _numNodeGroups?;
    get numNodeGroups(): number;
    set numNodeGroups(value: number);
    resetNumNodeGroups(): void;
    get numNodeGroupsInput(): number | undefined;
    private _parameterGroupName?;
    get parameterGroupName(): string;
    set parameterGroupName(value: string);
    resetParameterGroupName(): void;
    get parameterGroupNameInput(): string | undefined;
    private _primaryReplicationGroupId?;
    get primaryReplicationGroupId(): string;
    set primaryReplicationGroupId(value: string);
    get primaryReplicationGroupIdInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get transitEncryptionEnabled(): cdktn.IResolvable;
    private _timeouts;
    get timeouts(): AwsElasticacheGlobalReplicationGroup.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsElasticacheGlobalReplicationGroup.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsElasticacheGlobalReplicationGroup.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsElasticacheGlobalReplicationGroupGlobalNodeGroupsPropertyToTerraform(struct?: AwsElasticacheGlobalReplicationGroup.GlobalNodeGroupsProperty): any;
export declare function awsElasticacheGlobalReplicationGroupGlobalNodeGroupsPropertyToHclTerraform(struct?: AwsElasticacheGlobalReplicationGroup.GlobalNodeGroupsProperty): any;
export declare function awsElasticacheGlobalReplicationGroupTimeoutsPropertyToTerraform(struct?: AwsElasticacheGlobalReplicationGroup.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsElasticacheGlobalReplicationGroupTimeoutsPropertyToHclTerraform(struct?: AwsElasticacheGlobalReplicationGroup.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsElasticacheGlobalReplicationGroup {
    interface GlobalNodeGroupsProperty {
    }
    class GlobalNodeGroupsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): GlobalNodeGroupsProperty | undefined;
        set internalValue(value: GlobalNodeGroupsProperty | undefined);
        get globalNodeGroupId(): string;
        get slots(): string;
    }
    class GlobalNodeGroupsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): GlobalNodeGroupsPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticache_global_replication_group#create AwsElasticacheGlobalReplicationGroup#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticache_global_replication_group#delete AwsElasticacheGlobalReplicationGroup#delete}
        */
        readonly delete?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticache_global_replication_group#update AwsElasticacheGlobalReplicationGroup#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
