import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataTfUserConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/elasticache_user#access_string DataTfUser#access_string}
    */
    readonly accessString?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/elasticache_user#engine DataTfUser#engine}
    */
    readonly engine?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/elasticache_user#id DataTfUser#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/elasticache_user#no_password_required DataTfUser#no_password_required}
    */
    readonly noPasswordRequired?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/elasticache_user#passwords DataTfUser#passwords}
    */
    readonly passwords?: string[];
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/elasticache_user#region DataTfUser#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/elasticache_user#user_id DataTfUser#user_id}
    */
    readonly userId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/elasticache_user#user_name DataTfUser#user_name}
    */
    readonly userName?: string;
    /**
    * authentication_mode block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/elasticache_user#authentication_mode DataTfUser#authentication_mode}
    */
    readonly authenticationMode?: DataTfUser.AuthenticationModeProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/elasticache_user aws_elasticache_user}
*/
export declare class DataTfUser extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_elasticache_user";
    /**
    * Generates CDKTN code for importing a DataTfUser resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataTfUser to import
    * @param importFromId The id of the existing DataTfUser that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/elasticache_user#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataTfUser to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/elasticache_user aws_elasticache_user} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataTfUserConfig
    */
    constructor(scope: Construct, id: string, config: DataTfUserConfig);
    private _accessString?;
    get accessString(): string;
    set accessString(value: string);
    resetAccessString(): void;
    get accessStringInput(): string | undefined;
    private _engine?;
    get engine(): string;
    set engine(value: string);
    resetEngine(): void;
    get engineInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _noPasswordRequired?;
    get noPasswordRequired(): boolean | cdktn.IResolvable;
    set noPasswordRequired(value: boolean | cdktn.IResolvable);
    resetNoPasswordRequired(): void;
    get noPasswordRequiredInput(): boolean | cdktn.IResolvable | undefined;
    private _passwords?;
    get passwords(): string[];
    set passwords(value: string[]);
    resetPasswords(): void;
    get passwordsInput(): string[] | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _userId?;
    get userId(): string;
    set userId(value: string);
    get userIdInput(): string | undefined;
    private _userName?;
    get userName(): string;
    set userName(value: string);
    resetUserName(): void;
    get userNameInput(): string | undefined;
    private _authenticationMode;
    get authenticationMode(): DataTfUser.AuthenticationModePropertyList;
    putAuthenticationMode(value: DataTfUser.AuthenticationModeProperty[] | cdktn.IResolvable): void;
    resetAuthenticationMode(): void;
    get authenticationModeInput(): cdktn.IResolvable | DataTfUser.AuthenticationModeProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataTfUserAuthenticationModePropertyToTerraform(struct?: DataTfUser.AuthenticationModeProperty | cdktn.IResolvable): any;
export declare function dataTfUserAuthenticationModePropertyToHclTerraform(struct?: DataTfUser.AuthenticationModeProperty | cdktn.IResolvable): any;
export declare namespace DataTfUser {
    interface AuthenticationModeProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/elasticache_user#password_count DataTfUser#password_count}
        */
        readonly passwordCount?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/elasticache_user#type DataTfUser#type}
        */
        readonly type?: string;
    }
    class AuthenticationModePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AuthenticationModeProperty | cdktn.IResolvable | undefined;
        set internalValue(value: AuthenticationModeProperty | cdktn.IResolvable | undefined);
        private _passwordCount?;
        get passwordCount(): number;
        set passwordCount(value: number);
        resetPasswordCount(): void;
        get passwordCountInput(): number | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        resetType(): void;
        get typeInput(): string | undefined;
    }
    class AuthenticationModePropertyList extends cdktn.ComplexList {
        internalValue?: AuthenticationModeProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AuthenticationModePropertyOutputReference;
    }
}
