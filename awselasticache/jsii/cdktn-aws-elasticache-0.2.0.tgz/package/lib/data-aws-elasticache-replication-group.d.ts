import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataTfReplicationGroupConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/elasticache_replication_group#id DataTfReplicationGroup#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/elasticache_replication_group#region DataTfReplicationGroup#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/elasticache_replication_group#replication_group_id DataTfReplicationGroup#replication_group_id}
    */
    readonly replicationGroupId: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/elasticache_replication_group aws_elasticache_replication_group}
*/
export declare class DataTfReplicationGroup extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_elasticache_replication_group";
    /**
    * Generates CDKTN code for importing a DataTfReplicationGroup resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataTfReplicationGroup to import
    * @param importFromId The id of the existing DataTfReplicationGroup that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/elasticache_replication_group#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataTfReplicationGroup to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/elasticache_replication_group aws_elasticache_replication_group} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataTfReplicationGroupConfig
    */
    constructor(scope: Construct, id: string, config: DataTfReplicationGroupConfig);
    get arn(): string;
    get authTokenEnabled(): cdktn.IResolvable;
    get automaticFailoverEnabled(): cdktn.IResolvable;
    get clusterMode(): string;
    get configurationEndpointAddress(): string;
    get description(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _logDeliveryConfiguration;
    get logDeliveryConfiguration(): DataTfReplicationGroup.LogDeliveryConfigurationPropertyList;
    get memberClusters(): string[];
    get multiAzEnabled(): cdktn.IResolvable;
    private _nodeGroupConfiguration;
    get nodeGroupConfiguration(): DataTfReplicationGroup.NodeGroupConfigurationPropertyList;
    get nodeType(): string;
    get numCacheClusters(): number;
    get numNodeGroups(): number;
    get port(): number;
    get primaryEndpointAddress(): string;
    get readerEndpointAddress(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get replicasPerNodeGroup(): number;
    private _replicationGroupId?;
    get replicationGroupId(): string;
    set replicationGroupId(value: string);
    get replicationGroupIdInput(): string | undefined;
    get snapshotRetentionLimit(): number;
    get snapshotWindow(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataTfReplicationGroupLogDeliveryConfigurationPropertyToTerraform(struct?: DataTfReplicationGroup.LogDeliveryConfigurationProperty): any;
export declare function dataTfReplicationGroupLogDeliveryConfigurationPropertyToHclTerraform(struct?: DataTfReplicationGroup.LogDeliveryConfigurationProperty): any;
export declare function dataTfReplicationGroupNodeGroupConfigurationPropertyToTerraform(struct?: DataTfReplicationGroup.NodeGroupConfigurationProperty): any;
export declare function dataTfReplicationGroupNodeGroupConfigurationPropertyToHclTerraform(struct?: DataTfReplicationGroup.NodeGroupConfigurationProperty): any;
export declare namespace DataTfReplicationGroup {
    interface LogDeliveryConfigurationProperty {
    }
    class LogDeliveryConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): LogDeliveryConfigurationProperty | undefined;
        set internalValue(value: LogDeliveryConfigurationProperty | undefined);
        get destination(): string;
        get destinationType(): string;
        get logFormat(): string;
        get logType(): string;
    }
    class LogDeliveryConfigurationPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): LogDeliveryConfigurationPropertyOutputReference;
    }
    interface NodeGroupConfigurationProperty {
    }
    class NodeGroupConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): NodeGroupConfigurationProperty | undefined;
        set internalValue(value: NodeGroupConfigurationProperty | undefined);
        get nodeGroupId(): string;
        get primaryAvailabilityZone(): string;
        get primaryOutpostArn(): string;
        get replicaAvailabilityZones(): string[];
        get replicaCount(): number;
        get replicaOutpostArns(): string[];
        get slots(): string;
    }
    class NodeGroupConfigurationPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): NodeGroupConfigurationPropertyOutputReference;
    }
}
