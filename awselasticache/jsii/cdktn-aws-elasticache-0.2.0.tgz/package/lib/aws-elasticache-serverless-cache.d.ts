import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfServerlessCacheConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticache_serverless_cache#daily_snapshot_time TfServerlessCache#daily_snapshot_time}
    */
    readonly dailySnapshotTime?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticache_serverless_cache#description TfServerlessCache#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticache_serverless_cache#engine TfServerlessCache#engine}
    */
    readonly engine: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticache_serverless_cache#kms_key_id TfServerlessCache#kms_key_id}
    */
    readonly kmsKeyId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticache_serverless_cache#major_engine_version TfServerlessCache#major_engine_version}
    */
    readonly majorEngineVersion?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticache_serverless_cache#name TfServerlessCache#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticache_serverless_cache#network_type TfServerlessCache#network_type}
    */
    readonly networkType?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticache_serverless_cache#region TfServerlessCache#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticache_serverless_cache#security_group_ids TfServerlessCache#security_group_ids}
    */
    readonly securityGroupIds?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticache_serverless_cache#snapshot_arns_to_restore TfServerlessCache#snapshot_arns_to_restore}
    */
    readonly snapshotArnsToRestore?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticache_serverless_cache#snapshot_retention_limit TfServerlessCache#snapshot_retention_limit}
    */
    readonly snapshotRetentionLimit?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticache_serverless_cache#subnet_ids TfServerlessCache#subnet_ids}
    */
    readonly subnetIds?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticache_serverless_cache#tags TfServerlessCache#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticache_serverless_cache#user_group_id TfServerlessCache#user_group_id}
    */
    readonly userGroupId?: string;
    /**
    * cache_usage_limits block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticache_serverless_cache#cache_usage_limits TfServerlessCache#cache_usage_limits}
    */
    readonly cacheUsageLimits?: TfServerlessCache.CacheUsageLimitsProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticache_serverless_cache#timeouts TfServerlessCache#timeouts}
    */
    readonly timeouts?: TfServerlessCache.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticache_serverless_cache aws_elasticache_serverless_cache}
*/
export declare class TfServerlessCache extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_elasticache_serverless_cache";
    /**
    * Generates CDKTN code for importing a TfServerlessCache resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfServerlessCache to import
    * @param importFromId The id of the existing TfServerlessCache that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticache_serverless_cache#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfServerlessCache to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticache_serverless_cache aws_elasticache_serverless_cache} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfServerlessCacheConfig
    */
    constructor(scope: Construct, id: string, config: TfServerlessCacheConfig);
    get arn(): string;
    get createTime(): string;
    private _dailySnapshotTime?;
    get dailySnapshotTime(): string;
    set dailySnapshotTime(value: string);
    resetDailySnapshotTime(): void;
    get dailySnapshotTimeInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _endpoint;
    get endpoint(): TfServerlessCache.EndpointPropertyList;
    private _engine?;
    get engine(): string;
    set engine(value: string);
    get engineInput(): string | undefined;
    get fullEngineVersion(): string;
    get id(): string;
    private _kmsKeyId?;
    get kmsKeyId(): string;
    set kmsKeyId(value: string);
    resetKmsKeyId(): void;
    get kmsKeyIdInput(): string | undefined;
    private _majorEngineVersion?;
    get majorEngineVersion(): string;
    set majorEngineVersion(value: string);
    resetMajorEngineVersion(): void;
    get majorEngineVersionInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _networkType?;
    get networkType(): string;
    set networkType(value: string);
    resetNetworkType(): void;
    get networkTypeInput(): string | undefined;
    private _readerEndpoint;
    get readerEndpoint(): TfServerlessCache.ReaderEndpointPropertyList;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _securityGroupIds?;
    get securityGroupIds(): string[];
    set securityGroupIds(value: string[]);
    resetSecurityGroupIds(): void;
    get securityGroupIdsInput(): string[] | undefined;
    private _snapshotArnsToRestore?;
    get snapshotArnsToRestore(): string[];
    set snapshotArnsToRestore(value: string[]);
    resetSnapshotArnsToRestore(): void;
    get snapshotArnsToRestoreInput(): string[] | undefined;
    private _snapshotRetentionLimit?;
    get snapshotRetentionLimit(): number;
    set snapshotRetentionLimit(value: number);
    resetSnapshotRetentionLimit(): void;
    get snapshotRetentionLimitInput(): number | undefined;
    get status(): string;
    private _subnetIds?;
    get subnetIds(): string[];
    set subnetIds(value: string[]);
    resetSubnetIds(): void;
    get subnetIdsInput(): string[] | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    private _userGroupId?;
    get userGroupId(): string;
    set userGroupId(value: string);
    resetUserGroupId(): void;
    get userGroupIdInput(): string | undefined;
    private _cacheUsageLimits;
    get cacheUsageLimits(): TfServerlessCache.CacheUsageLimitsPropertyList;
    putCacheUsageLimits(value: TfServerlessCache.CacheUsageLimitsProperty[] | cdktn.IResolvable): void;
    resetCacheUsageLimits(): void;
    get cacheUsageLimitsInput(): cdktn.IResolvable | TfServerlessCache.CacheUsageLimitsProperty[] | undefined;
    private _timeouts;
    get timeouts(): TfServerlessCache.TimeoutsPropertyOutputReference;
    putTimeouts(value: TfServerlessCache.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | TfServerlessCache.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfServerlessCacheEndpointPropertyToTerraform(struct?: TfServerlessCache.EndpointProperty): any;
export declare function tfServerlessCacheEndpointPropertyToHclTerraform(struct?: TfServerlessCache.EndpointProperty): any;
export declare function tfServerlessCacheReaderEndpointPropertyToTerraform(struct?: TfServerlessCache.ReaderEndpointProperty): any;
export declare function tfServerlessCacheReaderEndpointPropertyToHclTerraform(struct?: TfServerlessCache.ReaderEndpointProperty): any;
export declare function tfServerlessCacheDataStoragePropertyToTerraform(struct?: TfServerlessCache.DataStorageProperty | cdktn.IResolvable): any;
export declare function tfServerlessCacheDataStoragePropertyToHclTerraform(struct?: TfServerlessCache.DataStorageProperty | cdktn.IResolvable): any;
export declare function tfServerlessCacheEcpuPerSecondPropertyToTerraform(struct?: TfServerlessCache.EcpuPerSecondProperty | cdktn.IResolvable): any;
export declare function tfServerlessCacheEcpuPerSecondPropertyToHclTerraform(struct?: TfServerlessCache.EcpuPerSecondProperty | cdktn.IResolvable): any;
export declare function tfServerlessCacheCacheUsageLimitsPropertyToTerraform(struct?: TfServerlessCache.CacheUsageLimitsProperty | cdktn.IResolvable): any;
export declare function tfServerlessCacheCacheUsageLimitsPropertyToHclTerraform(struct?: TfServerlessCache.CacheUsageLimitsProperty | cdktn.IResolvable): any;
export declare function tfServerlessCacheTimeoutsPropertyToTerraform(struct?: TfServerlessCache.TimeoutsProperty | cdktn.IResolvable): any;
export declare function tfServerlessCacheTimeoutsPropertyToHclTerraform(struct?: TfServerlessCache.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace TfServerlessCache {
    interface EndpointProperty {
    }
    class EndpointPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EndpointProperty | undefined;
        set internalValue(value: EndpointProperty | undefined);
        get address(): string;
        get port(): number;
    }
    class EndpointPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EndpointPropertyOutputReference;
    }
    interface ReaderEndpointProperty {
    }
    class ReaderEndpointPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ReaderEndpointProperty | undefined;
        set internalValue(value: ReaderEndpointProperty | undefined);
        get address(): string;
        get port(): number;
    }
    class ReaderEndpointPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ReaderEndpointPropertyOutputReference;
    }
    interface DataStorageProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticache_serverless_cache#maximum TfServerlessCache#maximum}
        */
        readonly maximum?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticache_serverless_cache#minimum TfServerlessCache#minimum}
        */
        readonly minimum?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticache_serverless_cache#unit TfServerlessCache#unit}
        */
        readonly unit: string;
    }
    class DataStoragePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DataStorageProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DataStorageProperty | cdktn.IResolvable | undefined);
        private _maximum?;
        get maximum(): number;
        set maximum(value: number);
        resetMaximum(): void;
        get maximumInput(): number | undefined;
        private _minimum?;
        get minimum(): number;
        set minimum(value: number);
        resetMinimum(): void;
        get minimumInput(): number | undefined;
        private _unit?;
        get unit(): string;
        set unit(value: string);
        get unitInput(): string | undefined;
    }
    class DataStoragePropertyList extends cdktn.ComplexList {
        internalValue?: DataStorageProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DataStoragePropertyOutputReference;
    }
    interface EcpuPerSecondProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticache_serverless_cache#maximum TfServerlessCache#maximum}
        */
        readonly maximum?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticache_serverless_cache#minimum TfServerlessCache#minimum}
        */
        readonly minimum?: number;
    }
    class EcpuPerSecondPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EcpuPerSecondProperty | cdktn.IResolvable | undefined;
        set internalValue(value: EcpuPerSecondProperty | cdktn.IResolvable | undefined);
        private _maximum?;
        get maximum(): number;
        set maximum(value: number);
        resetMaximum(): void;
        get maximumInput(): number | undefined;
        private _minimum?;
        get minimum(): number;
        set minimum(value: number);
        resetMinimum(): void;
        get minimumInput(): number | undefined;
    }
    class EcpuPerSecondPropertyList extends cdktn.ComplexList {
        internalValue?: EcpuPerSecondProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EcpuPerSecondPropertyOutputReference;
    }
    interface CacheUsageLimitsProperty {
        /**
        * data_storage block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticache_serverless_cache#data_storage TfServerlessCache#data_storage}
        */
        readonly dataStorage?: DataStorageProperty[] | cdktn.IResolvable;
        /**
        * ecpu_per_second block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticache_serverless_cache#ecpu_per_second TfServerlessCache#ecpu_per_second}
        */
        readonly ecpuPerSecond?: EcpuPerSecondProperty[] | cdktn.IResolvable;
    }
    class CacheUsageLimitsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CacheUsageLimitsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CacheUsageLimitsProperty | cdktn.IResolvable | undefined);
        private _dataStorage;
        get dataStorage(): DataStoragePropertyList;
        putDataStorage(value: DataStorageProperty[] | cdktn.IResolvable): void;
        resetDataStorage(): void;
        get dataStorageInput(): cdktn.IResolvable | DataStorageProperty[] | undefined;
        private _ecpuPerSecond;
        get ecpuPerSecond(): EcpuPerSecondPropertyList;
        putEcpuPerSecond(value: EcpuPerSecondProperty[] | cdktn.IResolvable): void;
        resetEcpuPerSecond(): void;
        get ecpuPerSecondInput(): cdktn.IResolvable | EcpuPerSecondProperty[] | undefined;
    }
    class CacheUsageLimitsPropertyList extends cdktn.ComplexList {
        internalValue?: CacheUsageLimitsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CacheUsageLimitsPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticache_serverless_cache#create TfServerlessCache#create}
        */
        readonly create?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Setting a timeout for a Delete operation is only applicable if changes are saved into state before the destroy operation occurs.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticache_serverless_cache#delete TfServerlessCache#delete}
        */
        readonly delete?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticache_serverless_cache#update TfServerlessCache#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
