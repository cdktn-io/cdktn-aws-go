import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsAppstreamStackConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appstream_stack#description AwsAppstreamStack#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appstream_stack#display_name AwsAppstreamStack#display_name}
    */
    readonly displayName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appstream_stack#embed_host_domains AwsAppstreamStack#embed_host_domains}
    */
    readonly embedHostDomains?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appstream_stack#feedback_url AwsAppstreamStack#feedback_url}
    */
    readonly feedbackUrl?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appstream_stack#id AwsAppstreamStack#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appstream_stack#name AwsAppstreamStack#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appstream_stack#redirect_url AwsAppstreamStack#redirect_url}
    */
    readonly redirectUrl?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appstream_stack#region AwsAppstreamStack#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appstream_stack#tags AwsAppstreamStack#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appstream_stack#tags_all AwsAppstreamStack#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * access_endpoints block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appstream_stack#access_endpoints AwsAppstreamStack#access_endpoints}
    */
    readonly accessEndpoints?: AwsAppstreamStack.AccessEndpointsProperty[] | cdktn.IResolvable;
    /**
    * application_settings block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appstream_stack#application_settings AwsAppstreamStack#application_settings}
    */
    readonly applicationSettings?: AwsAppstreamStack.ApplicationSettingsProperty;
    /**
    * storage_connectors block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appstream_stack#storage_connectors AwsAppstreamStack#storage_connectors}
    */
    readonly storageConnectors?: AwsAppstreamStack.StorageConnectorsProperty[] | cdktn.IResolvable;
    /**
    * streaming_experience_settings block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appstream_stack#streaming_experience_settings AwsAppstreamStack#streaming_experience_settings}
    */
    readonly streamingExperienceSettings?: AwsAppstreamStack.StreamingExperienceSettingsProperty;
    /**
    * user_settings block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appstream_stack#user_settings AwsAppstreamStack#user_settings}
    */
    readonly userSettings?: AwsAppstreamStack.UserSettingsProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appstream_stack aws_appstream_stack}
*/
export declare class AwsAppstreamStack extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_appstream_stack";
    /**
    * Generates CDKTN code for importing a AwsAppstreamStack resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsAppstreamStack to import
    * @param importFromId The id of the existing AwsAppstreamStack that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appstream_stack#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsAppstreamStack to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appstream_stack aws_appstream_stack} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsAppstreamStackConfig
    */
    constructor(scope: Construct, id: string, config: AwsAppstreamStackConfig);
    get arn(): string;
    get createdTime(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    resetDisplayName(): void;
    get displayNameInput(): string | undefined;
    private _embedHostDomains?;
    get embedHostDomains(): string[];
    set embedHostDomains(value: string[]);
    resetEmbedHostDomains(): void;
    get embedHostDomainsInput(): string[] | undefined;
    private _feedbackUrl?;
    get feedbackUrl(): string;
    set feedbackUrl(value: string);
    resetFeedbackUrl(): void;
    get feedbackUrlInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _redirectUrl?;
    get redirectUrl(): string;
    set redirectUrl(value: string);
    resetRedirectUrl(): void;
    get redirectUrlInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _accessEndpoints;
    get accessEndpoints(): AwsAppstreamStack.AccessEndpointsPropertyList;
    putAccessEndpoints(value: AwsAppstreamStack.AccessEndpointsProperty[] | cdktn.IResolvable): void;
    resetAccessEndpoints(): void;
    get accessEndpointsInput(): cdktn.IResolvable | AwsAppstreamStack.AccessEndpointsProperty[] | undefined;
    private _applicationSettings;
    get applicationSettings(): AwsAppstreamStack.ApplicationSettingsPropertyOutputReference;
    putApplicationSettings(value: AwsAppstreamStack.ApplicationSettingsProperty): void;
    resetApplicationSettings(): void;
    get applicationSettingsInput(): AwsAppstreamStack.ApplicationSettingsProperty | undefined;
    private _storageConnectors;
    get storageConnectors(): AwsAppstreamStack.StorageConnectorsPropertyList;
    putStorageConnectors(value: AwsAppstreamStack.StorageConnectorsProperty[] | cdktn.IResolvable): void;
    resetStorageConnectors(): void;
    get storageConnectorsInput(): cdktn.IResolvable | AwsAppstreamStack.StorageConnectorsProperty[] | undefined;
    private _streamingExperienceSettings;
    get streamingExperienceSettings(): AwsAppstreamStack.StreamingExperienceSettingsPropertyOutputReference;
    putStreamingExperienceSettings(value: AwsAppstreamStack.StreamingExperienceSettingsProperty): void;
    resetStreamingExperienceSettings(): void;
    get streamingExperienceSettingsInput(): AwsAppstreamStack.StreamingExperienceSettingsProperty | undefined;
    private _userSettings;
    get userSettings(): AwsAppstreamStack.UserSettingsPropertyList;
    putUserSettings(value: AwsAppstreamStack.UserSettingsProperty[] | cdktn.IResolvable): void;
    resetUserSettings(): void;
    get userSettingsInput(): cdktn.IResolvable | AwsAppstreamStack.UserSettingsProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsAppstreamStackAccessEndpointsPropertyToTerraform(struct?: AwsAppstreamStack.AccessEndpointsProperty | cdktn.IResolvable): any;
export declare function awsAppstreamStackAccessEndpointsPropertyToHclTerraform(struct?: AwsAppstreamStack.AccessEndpointsProperty | cdktn.IResolvable): any;
export declare function awsAppstreamStackApplicationSettingsPropertyToTerraform(struct?: AwsAppstreamStack.ApplicationSettingsPropertyOutputReference | AwsAppstreamStack.ApplicationSettingsProperty): any;
export declare function awsAppstreamStackApplicationSettingsPropertyToHclTerraform(struct?: AwsAppstreamStack.ApplicationSettingsPropertyOutputReference | AwsAppstreamStack.ApplicationSettingsProperty): any;
export declare function awsAppstreamStackStorageConnectorsPropertyToTerraform(struct?: AwsAppstreamStack.StorageConnectorsProperty | cdktn.IResolvable): any;
export declare function awsAppstreamStackStorageConnectorsPropertyToHclTerraform(struct?: AwsAppstreamStack.StorageConnectorsProperty | cdktn.IResolvable): any;
export declare function awsAppstreamStackStreamingExperienceSettingsPropertyToTerraform(struct?: AwsAppstreamStack.StreamingExperienceSettingsPropertyOutputReference | AwsAppstreamStack.StreamingExperienceSettingsProperty): any;
export declare function awsAppstreamStackStreamingExperienceSettingsPropertyToHclTerraform(struct?: AwsAppstreamStack.StreamingExperienceSettingsPropertyOutputReference | AwsAppstreamStack.StreamingExperienceSettingsProperty): any;
export declare function awsAppstreamStackUserSettingsPropertyToTerraform(struct?: AwsAppstreamStack.UserSettingsProperty | cdktn.IResolvable): any;
export declare function awsAppstreamStackUserSettingsPropertyToHclTerraform(struct?: AwsAppstreamStack.UserSettingsProperty | cdktn.IResolvable): any;
export declare namespace AwsAppstreamStack {
    interface AccessEndpointsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appstream_stack#endpoint_type AwsAppstreamStack#endpoint_type}
        */
        readonly endpointType: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appstream_stack#vpce_id AwsAppstreamStack#vpce_id}
        */
        readonly vpceId?: string;
    }
    class AccessEndpointsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AccessEndpointsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: AccessEndpointsProperty | cdktn.IResolvable | undefined);
        private _endpointType?;
        get endpointType(): string;
        set endpointType(value: string);
        get endpointTypeInput(): string | undefined;
        private _vpceId?;
        get vpceId(): string;
        set vpceId(value: string);
        resetVpceId(): void;
        get vpceIdInput(): string | undefined;
    }
    class AccessEndpointsPropertyList extends cdktn.ComplexList {
        internalValue?: AccessEndpointsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AccessEndpointsPropertyOutputReference;
    }
    interface ApplicationSettingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appstream_stack#enabled AwsAppstreamStack#enabled}
        */
        readonly enabled: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appstream_stack#settings_group AwsAppstreamStack#settings_group}
        */
        readonly settingsGroup?: string;
    }
    class ApplicationSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ApplicationSettingsProperty | undefined;
        set internalValue(value: ApplicationSettingsProperty | undefined);
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
        private _settingsGroup?;
        get settingsGroup(): string;
        set settingsGroup(value: string);
        resetSettingsGroup(): void;
        get settingsGroupInput(): string | undefined;
    }
    interface StorageConnectorsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appstream_stack#connector_type AwsAppstreamStack#connector_type}
        */
        readonly connectorType: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appstream_stack#domains AwsAppstreamStack#domains}
        */
        readonly domains?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appstream_stack#resource_identifier AwsAppstreamStack#resource_identifier}
        */
        readonly resourceIdentifier?: string;
    }
    class StorageConnectorsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): StorageConnectorsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: StorageConnectorsProperty | cdktn.IResolvable | undefined);
        private _connectorType?;
        get connectorType(): string;
        set connectorType(value: string);
        get connectorTypeInput(): string | undefined;
        private _domains?;
        get domains(): string[];
        set domains(value: string[]);
        resetDomains(): void;
        get domainsInput(): string[] | undefined;
        private _resourceIdentifier?;
        get resourceIdentifier(): string;
        set resourceIdentifier(value: string);
        resetResourceIdentifier(): void;
        get resourceIdentifierInput(): string | undefined;
    }
    class StorageConnectorsPropertyList extends cdktn.ComplexList {
        internalValue?: StorageConnectorsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): StorageConnectorsPropertyOutputReference;
    }
    interface StreamingExperienceSettingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appstream_stack#preferred_protocol AwsAppstreamStack#preferred_protocol}
        */
        readonly preferredProtocol?: string;
    }
    class StreamingExperienceSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): StreamingExperienceSettingsProperty | undefined;
        set internalValue(value: StreamingExperienceSettingsProperty | undefined);
        private _preferredProtocol?;
        get preferredProtocol(): string;
        set preferredProtocol(value: string);
        resetPreferredProtocol(): void;
        get preferredProtocolInput(): string | undefined;
    }
    interface UserSettingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appstream_stack#action AwsAppstreamStack#action}
        */
        readonly action: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appstream_stack#permission AwsAppstreamStack#permission}
        */
        readonly permission: string;
    }
    class UserSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): UserSettingsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: UserSettingsProperty | cdktn.IResolvable | undefined);
        private _action?;
        get action(): string;
        set action(value: string);
        get actionInput(): string | undefined;
        private _permission?;
        get permission(): string;
        set permission(value: string);
        get permissionInput(): string | undefined;
    }
    class UserSettingsPropertyList extends cdktn.ComplexList {
        internalValue?: UserSettingsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): UserSettingsPropertyOutputReference;
    }
}
