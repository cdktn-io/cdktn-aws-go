import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsAppstreamImageBuilderConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appstream_image_builder#appstream_agent_version AwsAppstreamImageBuilder#appstream_agent_version}
    */
    readonly appstreamAgentVersion?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appstream_image_builder#description AwsAppstreamImageBuilder#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appstream_image_builder#display_name AwsAppstreamImageBuilder#display_name}
    */
    readonly displayName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appstream_image_builder#enable_default_internet_access AwsAppstreamImageBuilder#enable_default_internet_access}
    */
    readonly enableDefaultInternetAccess?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appstream_image_builder#iam_role_arn AwsAppstreamImageBuilder#iam_role_arn}
    */
    readonly iamRoleArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appstream_image_builder#id AwsAppstreamImageBuilder#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appstream_image_builder#image_arn AwsAppstreamImageBuilder#image_arn}
    */
    readonly imageArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appstream_image_builder#image_name AwsAppstreamImageBuilder#image_name}
    */
    readonly imageName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appstream_image_builder#instance_type AwsAppstreamImageBuilder#instance_type}
    */
    readonly instanceType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appstream_image_builder#name AwsAppstreamImageBuilder#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appstream_image_builder#region AwsAppstreamImageBuilder#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appstream_image_builder#tags AwsAppstreamImageBuilder#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appstream_image_builder#tags_all AwsAppstreamImageBuilder#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * access_endpoint block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appstream_image_builder#access_endpoint AwsAppstreamImageBuilder#access_endpoint}
    */
    readonly accessEndpoint?: AwsAppstreamImageBuilder.AccessEndpointProperty[] | cdktn.IResolvable;
    /**
    * domain_join_info block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appstream_image_builder#domain_join_info AwsAppstreamImageBuilder#domain_join_info}
    */
    readonly domainJoinInfo?: AwsAppstreamImageBuilder.DomainJoinInfoProperty;
    /**
    * vpc_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appstream_image_builder#vpc_config AwsAppstreamImageBuilder#vpc_config}
    */
    readonly vpcConfig?: AwsAppstreamImageBuilder.VpcConfigProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appstream_image_builder aws_appstream_image_builder}
*/
export declare class AwsAppstreamImageBuilder extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_appstream_image_builder";
    /**
    * Generates CDKTN code for importing a AwsAppstreamImageBuilder resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsAppstreamImageBuilder to import
    * @param importFromId The id of the existing AwsAppstreamImageBuilder that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appstream_image_builder#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsAppstreamImageBuilder to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appstream_image_builder aws_appstream_image_builder} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsAppstreamImageBuilderConfig
    */
    constructor(scope: Construct, id: string, config: AwsAppstreamImageBuilderConfig);
    private _appstreamAgentVersion?;
    get appstreamAgentVersion(): string;
    set appstreamAgentVersion(value: string);
    resetAppstreamAgentVersion(): void;
    get appstreamAgentVersionInput(): string | undefined;
    get arn(): string;
    get createdTime(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    resetDisplayName(): void;
    get displayNameInput(): string | undefined;
    private _enableDefaultInternetAccess?;
    get enableDefaultInternetAccess(): boolean | cdktn.IResolvable;
    set enableDefaultInternetAccess(value: boolean | cdktn.IResolvable);
    resetEnableDefaultInternetAccess(): void;
    get enableDefaultInternetAccessInput(): boolean | cdktn.IResolvable | undefined;
    private _iamRoleArn?;
    get iamRoleArn(): string;
    set iamRoleArn(value: string);
    resetIamRoleArn(): void;
    get iamRoleArnInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _imageArn?;
    get imageArn(): string;
    set imageArn(value: string);
    resetImageArn(): void;
    get imageArnInput(): string | undefined;
    private _imageName?;
    get imageName(): string;
    set imageName(value: string);
    resetImageName(): void;
    get imageNameInput(): string | undefined;
    private _instanceType?;
    get instanceType(): string;
    set instanceType(value: string);
    get instanceTypeInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get state(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _accessEndpoint;
    get accessEndpoint(): AwsAppstreamImageBuilder.AccessEndpointPropertyList;
    putAccessEndpoint(value: AwsAppstreamImageBuilder.AccessEndpointProperty[] | cdktn.IResolvable): void;
    resetAccessEndpoint(): void;
    get accessEndpointInput(): cdktn.IResolvable | AwsAppstreamImageBuilder.AccessEndpointProperty[] | undefined;
    private _domainJoinInfo;
    get domainJoinInfo(): AwsAppstreamImageBuilder.DomainJoinInfoPropertyOutputReference;
    putDomainJoinInfo(value: AwsAppstreamImageBuilder.DomainJoinInfoProperty): void;
    resetDomainJoinInfo(): void;
    get domainJoinInfoInput(): AwsAppstreamImageBuilder.DomainJoinInfoProperty | undefined;
    private _vpcConfig;
    get vpcConfig(): AwsAppstreamImageBuilder.VpcConfigPropertyOutputReference;
    putVpcConfig(value: AwsAppstreamImageBuilder.VpcConfigProperty): void;
    resetVpcConfig(): void;
    get vpcConfigInput(): AwsAppstreamImageBuilder.VpcConfigProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsAppstreamImageBuilderAccessEndpointPropertyToTerraform(struct?: AwsAppstreamImageBuilder.AccessEndpointProperty | cdktn.IResolvable): any;
export declare function awsAppstreamImageBuilderAccessEndpointPropertyToHclTerraform(struct?: AwsAppstreamImageBuilder.AccessEndpointProperty | cdktn.IResolvable): any;
export declare function awsAppstreamImageBuilderDomainJoinInfoPropertyToTerraform(struct?: AwsAppstreamImageBuilder.DomainJoinInfoPropertyOutputReference | AwsAppstreamImageBuilder.DomainJoinInfoProperty): any;
export declare function awsAppstreamImageBuilderDomainJoinInfoPropertyToHclTerraform(struct?: AwsAppstreamImageBuilder.DomainJoinInfoPropertyOutputReference | AwsAppstreamImageBuilder.DomainJoinInfoProperty): any;
export declare function awsAppstreamImageBuilderVpcConfigPropertyToTerraform(struct?: AwsAppstreamImageBuilder.VpcConfigPropertyOutputReference | AwsAppstreamImageBuilder.VpcConfigProperty): any;
export declare function awsAppstreamImageBuilderVpcConfigPropertyToHclTerraform(struct?: AwsAppstreamImageBuilder.VpcConfigPropertyOutputReference | AwsAppstreamImageBuilder.VpcConfigProperty): any;
export declare namespace AwsAppstreamImageBuilder {
    interface AccessEndpointProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appstream_image_builder#endpoint_type AwsAppstreamImageBuilder#endpoint_type}
        */
        readonly endpointType: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appstream_image_builder#vpce_id AwsAppstreamImageBuilder#vpce_id}
        */
        readonly vpceId?: string;
    }
    class AccessEndpointPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AccessEndpointProperty | cdktn.IResolvable | undefined;
        set internalValue(value: AccessEndpointProperty | cdktn.IResolvable | undefined);
        private _endpointType?;
        get endpointType(): string;
        set endpointType(value: string);
        get endpointTypeInput(): string | undefined;
        private _vpceId?;
        get vpceId(): string;
        set vpceId(value: string);
        resetVpceId(): void;
        get vpceIdInput(): string | undefined;
    }
    class AccessEndpointPropertyList extends cdktn.ComplexList {
        internalValue?: AccessEndpointProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AccessEndpointPropertyOutputReference;
    }
    interface DomainJoinInfoProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appstream_image_builder#directory_name AwsAppstreamImageBuilder#directory_name}
        */
        readonly directoryName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appstream_image_builder#organizational_unit_distinguished_name AwsAppstreamImageBuilder#organizational_unit_distinguished_name}
        */
        readonly organizationalUnitDistinguishedName?: string;
    }
    class DomainJoinInfoPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DomainJoinInfoProperty | undefined;
        set internalValue(value: DomainJoinInfoProperty | undefined);
        private _directoryName?;
        get directoryName(): string;
        set directoryName(value: string);
        resetDirectoryName(): void;
        get directoryNameInput(): string | undefined;
        private _organizationalUnitDistinguishedName?;
        get organizationalUnitDistinguishedName(): string;
        set organizationalUnitDistinguishedName(value: string);
        resetOrganizationalUnitDistinguishedName(): void;
        get organizationalUnitDistinguishedNameInput(): string | undefined;
    }
    interface VpcConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appstream_image_builder#security_group_ids AwsAppstreamImageBuilder#security_group_ids}
        */
        readonly securityGroupIds?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appstream_image_builder#subnet_ids AwsAppstreamImageBuilder#subnet_ids}
        */
        readonly subnetIds?: string[];
    }
    class VpcConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): VpcConfigProperty | undefined;
        set internalValue(value: VpcConfigProperty | undefined);
        private _securityGroupIds?;
        get securityGroupIds(): string[];
        set securityGroupIds(value: string[]);
        resetSecurityGroupIds(): void;
        get securityGroupIdsInput(): string[] | undefined;
        private _subnetIds?;
        get subnetIds(): string[];
        set subnetIds(value: string[]);
        resetSubnetIds(): void;
        get subnetIdsInput(): string[] | undefined;
    }
}
