import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsAppstreamDirectoryConfigConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appstream_directory_config#directory_name AwsAppstreamDirectoryConfig#directory_name}
    */
    readonly directoryName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appstream_directory_config#id AwsAppstreamDirectoryConfig#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appstream_directory_config#organizational_unit_distinguished_names AwsAppstreamDirectoryConfig#organizational_unit_distinguished_names}
    */
    readonly organizationalUnitDistinguishedNames: string[];
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appstream_directory_config#region AwsAppstreamDirectoryConfig#region}
    */
    readonly region?: string;
    /**
    * certificate_based_auth_properties block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appstream_directory_config#certificate_based_auth_properties AwsAppstreamDirectoryConfig#certificate_based_auth_properties}
    */
    readonly certificateBasedAuthProperties?: AwsAppstreamDirectoryConfig.CertificateBasedAuthPropertiesProperty;
    /**
    * service_account_credentials block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appstream_directory_config#service_account_credentials AwsAppstreamDirectoryConfig#service_account_credentials}
    */
    readonly serviceAccountCredentials: AwsAppstreamDirectoryConfig.ServiceAccountCredentialsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appstream_directory_config aws_appstream_directory_config}
*/
export declare class AwsAppstreamDirectoryConfig extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_appstream_directory_config";
    /**
    * Generates CDKTN code for importing a AwsAppstreamDirectoryConfig resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsAppstreamDirectoryConfig to import
    * @param importFromId The id of the existing AwsAppstreamDirectoryConfig that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appstream_directory_config#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsAppstreamDirectoryConfig to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appstream_directory_config aws_appstream_directory_config} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsAppstreamDirectoryConfigConfig
    */
    constructor(scope: Construct, id: string, config: AwsAppstreamDirectoryConfigConfig);
    get createdTime(): string;
    private _directoryName?;
    get directoryName(): string;
    set directoryName(value: string);
    get directoryNameInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _organizationalUnitDistinguishedNames?;
    get organizationalUnitDistinguishedNames(): string[];
    set organizationalUnitDistinguishedNames(value: string[]);
    get organizationalUnitDistinguishedNamesInput(): string[] | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _certificateBasedAuthProperties;
    get certificateBasedAuthProperties(): AwsAppstreamDirectoryConfig.CertificateBasedAuthPropertiesPropertyOutputReference;
    putCertificateBasedAuthProperties(value: AwsAppstreamDirectoryConfig.CertificateBasedAuthPropertiesProperty): void;
    resetCertificateBasedAuthProperties(): void;
    get certificateBasedAuthPropertiesInput(): AwsAppstreamDirectoryConfig.CertificateBasedAuthPropertiesProperty | undefined;
    private _serviceAccountCredentials;
    get serviceAccountCredentials(): AwsAppstreamDirectoryConfig.ServiceAccountCredentialsPropertyOutputReference;
    putServiceAccountCredentials(value: AwsAppstreamDirectoryConfig.ServiceAccountCredentialsProperty): void;
    get serviceAccountCredentialsInput(): AwsAppstreamDirectoryConfig.ServiceAccountCredentialsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsAppstreamDirectoryConfigCertificateBasedAuthPropertiesPropertyToTerraform(struct?: AwsAppstreamDirectoryConfig.CertificateBasedAuthPropertiesPropertyOutputReference | AwsAppstreamDirectoryConfig.CertificateBasedAuthPropertiesProperty): any;
export declare function awsAppstreamDirectoryConfigCertificateBasedAuthPropertiesPropertyToHclTerraform(struct?: AwsAppstreamDirectoryConfig.CertificateBasedAuthPropertiesPropertyOutputReference | AwsAppstreamDirectoryConfig.CertificateBasedAuthPropertiesProperty): any;
export declare function awsAppstreamDirectoryConfigServiceAccountCredentialsPropertyToTerraform(struct?: AwsAppstreamDirectoryConfig.ServiceAccountCredentialsPropertyOutputReference | AwsAppstreamDirectoryConfig.ServiceAccountCredentialsProperty): any;
export declare function awsAppstreamDirectoryConfigServiceAccountCredentialsPropertyToHclTerraform(struct?: AwsAppstreamDirectoryConfig.ServiceAccountCredentialsPropertyOutputReference | AwsAppstreamDirectoryConfig.ServiceAccountCredentialsProperty): any;
export declare namespace AwsAppstreamDirectoryConfig {
    interface CertificateBasedAuthPropertiesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appstream_directory_config#certificate_authority_arn AwsAppstreamDirectoryConfig#certificate_authority_arn}
        */
        readonly certificateAuthorityArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appstream_directory_config#status AwsAppstreamDirectoryConfig#status}
        */
        readonly status?: string;
    }
    class CertificateBasedAuthPropertiesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CertificateBasedAuthPropertiesProperty | undefined;
        set internalValue(value: CertificateBasedAuthPropertiesProperty | undefined);
        private _certificateAuthorityArn?;
        get certificateAuthorityArn(): string;
        set certificateAuthorityArn(value: string);
        resetCertificateAuthorityArn(): void;
        get certificateAuthorityArnInput(): string | undefined;
        private _status?;
        get status(): string;
        set status(value: string);
        resetStatus(): void;
        get statusInput(): string | undefined;
    }
    interface ServiceAccountCredentialsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appstream_directory_config#account_name AwsAppstreamDirectoryConfig#account_name}
        */
        readonly accountName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appstream_directory_config#account_password AwsAppstreamDirectoryConfig#account_password}
        */
        readonly accountPassword: string;
    }
    class ServiceAccountCredentialsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ServiceAccountCredentialsProperty | undefined;
        set internalValue(value: ServiceAccountCredentialsProperty | undefined);
        private _accountName?;
        get accountName(): string;
        set accountName(value: string);
        get accountNameInput(): string | undefined;
        private _accountPassword?;
        get accountPassword(): string;
        set accountPassword(value: string);
        get accountPasswordInput(): string | undefined;
    }
}
