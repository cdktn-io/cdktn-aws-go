import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfFleetConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appstream_fleet#description TfFleet#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appstream_fleet#disconnect_timeout_in_seconds TfFleet#disconnect_timeout_in_seconds}
    */
    readonly disconnectTimeoutInSeconds?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appstream_fleet#display_name TfFleet#display_name}
    */
    readonly displayName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appstream_fleet#enable_default_internet_access TfFleet#enable_default_internet_access}
    */
    readonly enableDefaultInternetAccess?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appstream_fleet#fleet_type TfFleet#fleet_type}
    */
    readonly fleetType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appstream_fleet#iam_role_arn TfFleet#iam_role_arn}
    */
    readonly iamRoleArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appstream_fleet#id TfFleet#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appstream_fleet#idle_disconnect_timeout_in_seconds TfFleet#idle_disconnect_timeout_in_seconds}
    */
    readonly idleDisconnectTimeoutInSeconds?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appstream_fleet#image_arn TfFleet#image_arn}
    */
    readonly imageArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appstream_fleet#image_name TfFleet#image_name}
    */
    readonly imageName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appstream_fleet#instance_type TfFleet#instance_type}
    */
    readonly instanceType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appstream_fleet#max_sessions_per_instance TfFleet#max_sessions_per_instance}
    */
    readonly maxSessionsPerInstance?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appstream_fleet#max_user_duration_in_seconds TfFleet#max_user_duration_in_seconds}
    */
    readonly maxUserDurationInSeconds?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appstream_fleet#name TfFleet#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appstream_fleet#region TfFleet#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appstream_fleet#stream_view TfFleet#stream_view}
    */
    readonly streamView?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appstream_fleet#tags TfFleet#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appstream_fleet#tags_all TfFleet#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * compute_capacity block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appstream_fleet#compute_capacity TfFleet#compute_capacity}
    */
    readonly computeCapacity: TfFleet.ComputeCapacityProperty;
    /**
    * domain_join_info block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appstream_fleet#domain_join_info TfFleet#domain_join_info}
    */
    readonly domainJoinInfo?: TfFleet.DomainJoinInfoProperty;
    /**
    * vpc_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appstream_fleet#vpc_config TfFleet#vpc_config}
    */
    readonly vpcConfig?: TfFleet.VpcConfigProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appstream_fleet aws_appstream_fleet}
*/
export declare class TfFleet extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_appstream_fleet";
    /**
    * Generates CDKTN code for importing a TfFleet resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfFleet to import
    * @param importFromId The id of the existing TfFleet that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appstream_fleet#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfFleet to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appstream_fleet aws_appstream_fleet} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfFleetConfig
    */
    constructor(scope: Construct, id: string, config: TfFleetConfig);
    get arn(): string;
    get createdTime(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _disconnectTimeoutInSeconds?;
    get disconnectTimeoutInSeconds(): number;
    set disconnectTimeoutInSeconds(value: number);
    resetDisconnectTimeoutInSeconds(): void;
    get disconnectTimeoutInSecondsInput(): number | undefined;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    resetDisplayName(): void;
    get displayNameInput(): string | undefined;
    private _enableDefaultInternetAccess?;
    get enableDefaultInternetAccess(): boolean | cdktn.IResolvable;
    set enableDefaultInternetAccess(value: boolean | cdktn.IResolvable);
    resetEnableDefaultInternetAccess(): void;
    get enableDefaultInternetAccessInput(): boolean | cdktn.IResolvable | undefined;
    private _fleetType?;
    get fleetType(): string;
    set fleetType(value: string);
    resetFleetType(): void;
    get fleetTypeInput(): string | undefined;
    private _iamRoleArn?;
    get iamRoleArn(): string;
    set iamRoleArn(value: string);
    resetIamRoleArn(): void;
    get iamRoleArnInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _idleDisconnectTimeoutInSeconds?;
    get idleDisconnectTimeoutInSeconds(): number;
    set idleDisconnectTimeoutInSeconds(value: number);
    resetIdleDisconnectTimeoutInSeconds(): void;
    get idleDisconnectTimeoutInSecondsInput(): number | undefined;
    private _imageArn?;
    get imageArn(): string;
    set imageArn(value: string);
    resetImageArn(): void;
    get imageArnInput(): string | undefined;
    private _imageName?;
    get imageName(): string;
    set imageName(value: string);
    resetImageName(): void;
    get imageNameInput(): string | undefined;
    private _instanceType?;
    get instanceType(): string;
    set instanceType(value: string);
    get instanceTypeInput(): string | undefined;
    private _maxSessionsPerInstance?;
    get maxSessionsPerInstance(): number;
    set maxSessionsPerInstance(value: number);
    resetMaxSessionsPerInstance(): void;
    get maxSessionsPerInstanceInput(): number | undefined;
    private _maxUserDurationInSeconds?;
    get maxUserDurationInSeconds(): number;
    set maxUserDurationInSeconds(value: number);
    resetMaxUserDurationInSeconds(): void;
    get maxUserDurationInSecondsInput(): number | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get state(): string;
    private _streamView?;
    get streamView(): string;
    set streamView(value: string);
    resetStreamView(): void;
    get streamViewInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _computeCapacity;
    get computeCapacity(): TfFleet.ComputeCapacityPropertyOutputReference;
    putComputeCapacity(value: TfFleet.ComputeCapacityProperty): void;
    get computeCapacityInput(): TfFleet.ComputeCapacityProperty | undefined;
    private _domainJoinInfo;
    get domainJoinInfo(): TfFleet.DomainJoinInfoPropertyOutputReference;
    putDomainJoinInfo(value: TfFleet.DomainJoinInfoProperty): void;
    resetDomainJoinInfo(): void;
    get domainJoinInfoInput(): TfFleet.DomainJoinInfoProperty | undefined;
    private _vpcConfig;
    get vpcConfig(): TfFleet.VpcConfigPropertyOutputReference;
    putVpcConfig(value: TfFleet.VpcConfigProperty): void;
    resetVpcConfig(): void;
    get vpcConfigInput(): TfFleet.VpcConfigProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfFleetComputeCapacityPropertyToTerraform(struct?: TfFleet.ComputeCapacityPropertyOutputReference | TfFleet.ComputeCapacityProperty): any;
export declare function tfFleetComputeCapacityPropertyToHclTerraform(struct?: TfFleet.ComputeCapacityPropertyOutputReference | TfFleet.ComputeCapacityProperty): any;
export declare function tfFleetDomainJoinInfoPropertyToTerraform(struct?: TfFleet.DomainJoinInfoPropertyOutputReference | TfFleet.DomainJoinInfoProperty): any;
export declare function tfFleetDomainJoinInfoPropertyToHclTerraform(struct?: TfFleet.DomainJoinInfoPropertyOutputReference | TfFleet.DomainJoinInfoProperty): any;
export declare function tfFleetVpcConfigPropertyToTerraform(struct?: TfFleet.VpcConfigPropertyOutputReference | TfFleet.VpcConfigProperty): any;
export declare function tfFleetVpcConfigPropertyToHclTerraform(struct?: TfFleet.VpcConfigPropertyOutputReference | TfFleet.VpcConfigProperty): any;
export declare namespace TfFleet {
    interface ComputeCapacityProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appstream_fleet#desired_instances TfFleet#desired_instances}
        */
        readonly desiredInstances?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appstream_fleet#desired_sessions TfFleet#desired_sessions}
        */
        readonly desiredSessions?: number;
    }
    class ComputeCapacityPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ComputeCapacityProperty | undefined;
        set internalValue(value: ComputeCapacityProperty | undefined);
        get available(): number;
        private _desiredInstances?;
        get desiredInstances(): number;
        set desiredInstances(value: number);
        resetDesiredInstances(): void;
        get desiredInstancesInput(): number | undefined;
        private _desiredSessions?;
        get desiredSessions(): number;
        set desiredSessions(value: number);
        resetDesiredSessions(): void;
        get desiredSessionsInput(): number | undefined;
        get inUse(): number;
        get running(): number;
    }
    interface DomainJoinInfoProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appstream_fleet#directory_name TfFleet#directory_name}
        */
        readonly directoryName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appstream_fleet#organizational_unit_distinguished_name TfFleet#organizational_unit_distinguished_name}
        */
        readonly organizationalUnitDistinguishedName?: string;
    }
    class DomainJoinInfoPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DomainJoinInfoProperty | undefined;
        set internalValue(value: DomainJoinInfoProperty | undefined);
        private _directoryName?;
        get directoryName(): string;
        set directoryName(value: string);
        resetDirectoryName(): void;
        get directoryNameInput(): string | undefined;
        private _organizationalUnitDistinguishedName?;
        get organizationalUnitDistinguishedName(): string;
        set organizationalUnitDistinguishedName(value: string);
        resetOrganizationalUnitDistinguishedName(): void;
        get organizationalUnitDistinguishedNameInput(): string | undefined;
    }
    interface VpcConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appstream_fleet#security_group_ids TfFleet#security_group_ids}
        */
        readonly securityGroupIds?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appstream_fleet#subnet_ids TfFleet#subnet_ids}
        */
        readonly subnetIds?: string[];
    }
    class VpcConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): VpcConfigProperty | undefined;
        set internalValue(value: VpcConfigProperty | undefined);
        private _securityGroupIds?;
        get securityGroupIds(): string[];
        set securityGroupIds(value: string[]);
        resetSecurityGroupIds(): void;
        get securityGroupIdsInput(): string[] | undefined;
        private _subnetIds?;
        get subnetIds(): string[];
        set subnetIds(value: string[]);
        resetSubnetIds(): void;
        get subnetIdsInput(): string[] | undefined;
    }
}
