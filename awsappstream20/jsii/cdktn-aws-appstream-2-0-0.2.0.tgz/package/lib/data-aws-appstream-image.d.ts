import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataTfImageConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/appstream_image#arn DataTfImage#arn}
    */
    readonly arn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/appstream_image#most_recent DataTfImage#most_recent}
    */
    readonly mostRecent?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/appstream_image#name DataTfImage#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/appstream_image#name_regex DataTfImage#name_regex}
    */
    readonly nameRegex?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/appstream_image#region DataTfImage#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/appstream_image#type DataTfImage#type}
    */
    readonly type?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/appstream_image aws_appstream_image}
*/
export declare class DataTfImage extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_appstream_image";
    /**
    * Generates CDKTN code for importing a DataTfImage resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataTfImage to import
    * @param importFromId The id of the existing DataTfImage that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/appstream_image#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataTfImage to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/appstream_image aws_appstream_image} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataTfImageConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataTfImageConfig);
    private _applications;
    get applications(): DataTfImage.ApplicationsPropertyList;
    get appstreamAgentVersion(): string;
    private _arn?;
    get arn(): string;
    set arn(value: string);
    resetArn(): void;
    get arnInput(): string | undefined;
    get baseImageArn(): string;
    get createdTime(): string;
    get description(): string;
    get displayName(): string;
    get imageBuilderName(): string;
    get imageBuilderSupported(): cdktn.IResolvable;
    private _imagePermissions;
    get imagePermissions(): DataTfImage.ImagePermissionsPropertyList;
    private _mostRecent?;
    get mostRecent(): boolean | cdktn.IResolvable;
    set mostRecent(value: boolean | cdktn.IResolvable);
    resetMostRecent(): void;
    get mostRecentInput(): boolean | cdktn.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _nameRegex?;
    get nameRegex(): string;
    set nameRegex(value: string);
    resetNameRegex(): void;
    get nameRegexInput(): string | undefined;
    get platform(): string;
    get publicBaseImageReleasedDate(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get state(): string;
    private _stateChangeReason;
    get stateChangeReason(): DataTfImage.StateChangeReasonPropertyList;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataTfImageIconS3LocationPropertyToTerraform(struct?: DataTfImage.IconS3LocationProperty): any;
export declare function dataTfImageIconS3LocationPropertyToHclTerraform(struct?: DataTfImage.IconS3LocationProperty): any;
export declare function dataTfImageApplicationsPropertyToTerraform(struct?: DataTfImage.ApplicationsProperty): any;
export declare function dataTfImageApplicationsPropertyToHclTerraform(struct?: DataTfImage.ApplicationsProperty): any;
export declare function dataTfImageImagePermissionsPropertyToTerraform(struct?: DataTfImage.ImagePermissionsProperty): any;
export declare function dataTfImageImagePermissionsPropertyToHclTerraform(struct?: DataTfImage.ImagePermissionsProperty): any;
export declare function dataTfImageStateChangeReasonPropertyToTerraform(struct?: DataTfImage.StateChangeReasonProperty): any;
export declare function dataTfImageStateChangeReasonPropertyToHclTerraform(struct?: DataTfImage.StateChangeReasonProperty): any;
export declare namespace DataTfImage {
    interface IconS3LocationProperty {
    }
    class IconS3LocationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): IconS3LocationProperty | undefined;
        set internalValue(value: IconS3LocationProperty | undefined);
        get s3Bucket(): string;
        get s3Key(): string;
    }
    class IconS3LocationPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): IconS3LocationPropertyOutputReference;
    }
    interface ApplicationsProperty {
    }
    class ApplicationsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ApplicationsProperty | undefined;
        set internalValue(value: ApplicationsProperty | undefined);
        get appBlockArn(): string;
        get arn(): string;
        get createdTime(): string;
        get description(): string;
        get displayName(): string;
        get enabled(): cdktn.IResolvable;
        private _iconS3Location;
        get iconS3Location(): IconS3LocationPropertyList;
        get iconUrl(): string;
        get instanceFamilies(): string[];
        get launchParameters(): string;
        get launchPath(): string;
        private _metadata;
        get metadata(): cdktn.StringMap;
        get name(): string;
        get platforms(): string[];
        get workingDirectory(): string;
    }
    class ApplicationsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ApplicationsPropertyOutputReference;
    }
    interface ImagePermissionsProperty {
    }
    class ImagePermissionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ImagePermissionsProperty | undefined;
        set internalValue(value: ImagePermissionsProperty | undefined);
        get allowFleet(): cdktn.IResolvable;
        get allowImageBuilder(): cdktn.IResolvable;
    }
    class ImagePermissionsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ImagePermissionsPropertyOutputReference;
    }
    interface StateChangeReasonProperty {
    }
    class StateChangeReasonPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): StateChangeReasonProperty | undefined;
        set internalValue(value: StateChangeReasonProperty | undefined);
        get code(): string;
        get message(): string;
    }
    class StateChangeReasonPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): StateChangeReasonPropertyOutputReference;
    }
}
