import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfStackConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appstream_stack#description TfStack#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appstream_stack#display_name TfStack#display_name}
    */
    readonly displayName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appstream_stack#embed_host_domains TfStack#embed_host_domains}
    */
    readonly embedHostDomains?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appstream_stack#feedback_url TfStack#feedback_url}
    */
    readonly feedbackUrl?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appstream_stack#id TfStack#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appstream_stack#name TfStack#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appstream_stack#redirect_url TfStack#redirect_url}
    */
    readonly redirectUrl?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appstream_stack#region TfStack#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appstream_stack#tags TfStack#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appstream_stack#tags_all TfStack#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * access_endpoints block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appstream_stack#access_endpoints TfStack#access_endpoints}
    */
    readonly accessEndpoints?: TfStack.AccessEndpointsProperty[] | cdktn.IResolvable;
    /**
    * application_settings block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appstream_stack#application_settings TfStack#application_settings}
    */
    readonly applicationSettings?: TfStack.ApplicationSettingsProperty;
    /**
    * storage_connectors block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appstream_stack#storage_connectors TfStack#storage_connectors}
    */
    readonly storageConnectors?: TfStack.StorageConnectorsProperty[] | cdktn.IResolvable;
    /**
    * streaming_experience_settings block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appstream_stack#streaming_experience_settings TfStack#streaming_experience_settings}
    */
    readonly streamingExperienceSettings?: TfStack.StreamingExperienceSettingsProperty;
    /**
    * user_settings block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appstream_stack#user_settings TfStack#user_settings}
    */
    readonly userSettings?: TfStack.UserSettingsProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appstream_stack aws_appstream_stack}
*/
export declare class TfStack extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_appstream_stack";
    /**
    * Generates CDKTN code for importing a TfStack resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfStack to import
    * @param importFromId The id of the existing TfStack that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appstream_stack#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfStack to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appstream_stack aws_appstream_stack} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfStackConfig
    */
    constructor(scope: Construct, id: string, config: TfStackConfig);
    get arn(): string;
    get createdTime(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    resetDisplayName(): void;
    get displayNameInput(): string | undefined;
    private _embedHostDomains?;
    get embedHostDomains(): string[];
    set embedHostDomains(value: string[]);
    resetEmbedHostDomains(): void;
    get embedHostDomainsInput(): string[] | undefined;
    private _feedbackUrl?;
    get feedbackUrl(): string;
    set feedbackUrl(value: string);
    resetFeedbackUrl(): void;
    get feedbackUrlInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _redirectUrl?;
    get redirectUrl(): string;
    set redirectUrl(value: string);
    resetRedirectUrl(): void;
    get redirectUrlInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _accessEndpoints;
    get accessEndpoints(): TfStack.AccessEndpointsPropertyList;
    putAccessEndpoints(value: TfStack.AccessEndpointsProperty[] | cdktn.IResolvable): void;
    resetAccessEndpoints(): void;
    get accessEndpointsInput(): cdktn.IResolvable | TfStack.AccessEndpointsProperty[] | undefined;
    private _applicationSettings;
    get applicationSettings(): TfStack.ApplicationSettingsPropertyOutputReference;
    putApplicationSettings(value: TfStack.ApplicationSettingsProperty): void;
    resetApplicationSettings(): void;
    get applicationSettingsInput(): TfStack.ApplicationSettingsProperty | undefined;
    private _storageConnectors;
    get storageConnectors(): TfStack.StorageConnectorsPropertyList;
    putStorageConnectors(value: TfStack.StorageConnectorsProperty[] | cdktn.IResolvable): void;
    resetStorageConnectors(): void;
    get storageConnectorsInput(): cdktn.IResolvable | TfStack.StorageConnectorsProperty[] | undefined;
    private _streamingExperienceSettings;
    get streamingExperienceSettings(): TfStack.StreamingExperienceSettingsPropertyOutputReference;
    putStreamingExperienceSettings(value: TfStack.StreamingExperienceSettingsProperty): void;
    resetStreamingExperienceSettings(): void;
    get streamingExperienceSettingsInput(): TfStack.StreamingExperienceSettingsProperty | undefined;
    private _userSettings;
    get userSettings(): TfStack.UserSettingsPropertyList;
    putUserSettings(value: TfStack.UserSettingsProperty[] | cdktn.IResolvable): void;
    resetUserSettings(): void;
    get userSettingsInput(): cdktn.IResolvable | TfStack.UserSettingsProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfStackAccessEndpointsPropertyToTerraform(struct?: TfStack.AccessEndpointsProperty | cdktn.IResolvable): any;
export declare function tfStackAccessEndpointsPropertyToHclTerraform(struct?: TfStack.AccessEndpointsProperty | cdktn.IResolvable): any;
export declare function tfStackApplicationSettingsPropertyToTerraform(struct?: TfStack.ApplicationSettingsPropertyOutputReference | TfStack.ApplicationSettingsProperty): any;
export declare function tfStackApplicationSettingsPropertyToHclTerraform(struct?: TfStack.ApplicationSettingsPropertyOutputReference | TfStack.ApplicationSettingsProperty): any;
export declare function tfStackStorageConnectorsPropertyToTerraform(struct?: TfStack.StorageConnectorsProperty | cdktn.IResolvable): any;
export declare function tfStackStorageConnectorsPropertyToHclTerraform(struct?: TfStack.StorageConnectorsProperty | cdktn.IResolvable): any;
export declare function tfStackStreamingExperienceSettingsPropertyToTerraform(struct?: TfStack.StreamingExperienceSettingsPropertyOutputReference | TfStack.StreamingExperienceSettingsProperty): any;
export declare function tfStackStreamingExperienceSettingsPropertyToHclTerraform(struct?: TfStack.StreamingExperienceSettingsPropertyOutputReference | TfStack.StreamingExperienceSettingsProperty): any;
export declare function tfStackUserSettingsPropertyToTerraform(struct?: TfStack.UserSettingsProperty | cdktn.IResolvable): any;
export declare function tfStackUserSettingsPropertyToHclTerraform(struct?: TfStack.UserSettingsProperty | cdktn.IResolvable): any;
export declare namespace TfStack {
    interface AccessEndpointsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appstream_stack#endpoint_type TfStack#endpoint_type}
        */
        readonly endpointType: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appstream_stack#vpce_id TfStack#vpce_id}
        */
        readonly vpceId?: string;
    }
    class AccessEndpointsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AccessEndpointsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: AccessEndpointsProperty | cdktn.IResolvable | undefined);
        private _endpointType?;
        get endpointType(): string;
        set endpointType(value: string);
        get endpointTypeInput(): string | undefined;
        private _vpceId?;
        get vpceId(): string;
        set vpceId(value: string);
        resetVpceId(): void;
        get vpceIdInput(): string | undefined;
    }
    class AccessEndpointsPropertyList extends cdktn.ComplexList {
        internalValue?: AccessEndpointsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AccessEndpointsPropertyOutputReference;
    }
    interface ApplicationSettingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appstream_stack#enabled TfStack#enabled}
        */
        readonly enabled: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appstream_stack#settings_group TfStack#settings_group}
        */
        readonly settingsGroup?: string;
    }
    class ApplicationSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ApplicationSettingsProperty | undefined;
        set internalValue(value: ApplicationSettingsProperty | undefined);
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
        private _settingsGroup?;
        get settingsGroup(): string;
        set settingsGroup(value: string);
        resetSettingsGroup(): void;
        get settingsGroupInput(): string | undefined;
    }
    interface StorageConnectorsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appstream_stack#connector_type TfStack#connector_type}
        */
        readonly connectorType: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appstream_stack#domains TfStack#domains}
        */
        readonly domains?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appstream_stack#resource_identifier TfStack#resource_identifier}
        */
        readonly resourceIdentifier?: string;
    }
    class StorageConnectorsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): StorageConnectorsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: StorageConnectorsProperty | cdktn.IResolvable | undefined);
        private _connectorType?;
        get connectorType(): string;
        set connectorType(value: string);
        get connectorTypeInput(): string | undefined;
        private _domains?;
        get domains(): string[];
        set domains(value: string[]);
        resetDomains(): void;
        get domainsInput(): string[] | undefined;
        private _resourceIdentifier?;
        get resourceIdentifier(): string;
        set resourceIdentifier(value: string);
        resetResourceIdentifier(): void;
        get resourceIdentifierInput(): string | undefined;
    }
    class StorageConnectorsPropertyList extends cdktn.ComplexList {
        internalValue?: StorageConnectorsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): StorageConnectorsPropertyOutputReference;
    }
    interface StreamingExperienceSettingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appstream_stack#preferred_protocol TfStack#preferred_protocol}
        */
        readonly preferredProtocol?: string;
    }
    class StreamingExperienceSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): StreamingExperienceSettingsProperty | undefined;
        set internalValue(value: StreamingExperienceSettingsProperty | undefined);
        private _preferredProtocol?;
        get preferredProtocol(): string;
        set preferredProtocol(value: string);
        resetPreferredProtocol(): void;
        get preferredProtocolInput(): string | undefined;
    }
    interface UserSettingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appstream_stack#action TfStack#action}
        */
        readonly action: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appstream_stack#permission TfStack#permission}
        */
        readonly permission: string;
    }
    class UserSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): UserSettingsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: UserSettingsProperty | cdktn.IResolvable | undefined);
        private _action?;
        get action(): string;
        set action(value: string);
        get actionInput(): string | undefined;
        private _permission?;
        get permission(): string;
        set permission(value: string);
        get permissionInput(): string | undefined;
    }
    class UserSettingsPropertyList extends cdktn.ComplexList {
        internalValue?: UserSettingsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): UserSettingsPropertyOutputReference;
    }
}
