import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsFileCacheConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_file_cache#copy_tags_to_data_repository_associations AwsFileCache#copy_tags_to_data_repository_associations}
    */
    readonly copyTagsToDataRepositoryAssociations?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_file_cache#file_cache_type AwsFileCache#file_cache_type}
    */
    readonly fileCacheType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_file_cache#file_cache_type_version AwsFileCache#file_cache_type_version}
    */
    readonly fileCacheTypeVersion: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_file_cache#id AwsFileCache#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_file_cache#kms_key_id AwsFileCache#kms_key_id}
    */
    readonly kmsKeyId?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_file_cache#region AwsFileCache#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_file_cache#security_group_ids AwsFileCache#security_group_ids}
    */
    readonly securityGroupIds?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_file_cache#storage_capacity AwsFileCache#storage_capacity}
    */
    readonly storageCapacity: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_file_cache#subnet_ids AwsFileCache#subnet_ids}
    */
    readonly subnetIds: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_file_cache#tags AwsFileCache#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_file_cache#tags_all AwsFileCache#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * data_repository_association block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_file_cache#data_repository_association AwsFileCache#data_repository_association}
    */
    readonly dataRepositoryAssociation?: AwsFileCache.DataRepositoryAssociationProperty[] | cdktn.IResolvable;
    /**
    * lustre_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_file_cache#lustre_configuration AwsFileCache#lustre_configuration}
    */
    readonly lustreConfiguration?: AwsFileCache.LustreConfigurationProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_file_cache#timeouts AwsFileCache#timeouts}
    */
    readonly timeouts?: AwsFileCache.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_file_cache aws_fsx_file_cache}
*/
export declare class AwsFileCache extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_fsx_file_cache";
    /**
    * Generates CDKTN code for importing a AwsFileCache resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsFileCache to import
    * @param importFromId The id of the existing AwsFileCache that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_file_cache#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsFileCache to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_file_cache aws_fsx_file_cache} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsFileCacheConfig
    */
    constructor(scope: Construct, id: string, config: AwsFileCacheConfig);
    get arn(): string;
    private _copyTagsToDataRepositoryAssociations?;
    get copyTagsToDataRepositoryAssociations(): boolean | cdktn.IResolvable;
    set copyTagsToDataRepositoryAssociations(value: boolean | cdktn.IResolvable);
    resetCopyTagsToDataRepositoryAssociations(): void;
    get copyTagsToDataRepositoryAssociationsInput(): boolean | cdktn.IResolvable | undefined;
    get dataRepositoryAssociationIds(): string[];
    get dnsName(): string;
    get fileCacheId(): string;
    private _fileCacheType?;
    get fileCacheType(): string;
    set fileCacheType(value: string);
    get fileCacheTypeInput(): string | undefined;
    private _fileCacheTypeVersion?;
    get fileCacheTypeVersion(): string;
    set fileCacheTypeVersion(value: string);
    get fileCacheTypeVersionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _kmsKeyId?;
    get kmsKeyId(): string;
    set kmsKeyId(value: string);
    resetKmsKeyId(): void;
    get kmsKeyIdInput(): string | undefined;
    get networkInterfaceIds(): string[];
    get ownerId(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _securityGroupIds?;
    get securityGroupIds(): string[];
    set securityGroupIds(value: string[]);
    resetSecurityGroupIds(): void;
    get securityGroupIdsInput(): string[] | undefined;
    private _storageCapacity?;
    get storageCapacity(): number;
    set storageCapacity(value: number);
    get storageCapacityInput(): number | undefined;
    private _subnetIds?;
    get subnetIds(): string[];
    set subnetIds(value: string[]);
    get subnetIdsInput(): string[] | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    get vpcId(): string;
    private _dataRepositoryAssociation;
    get dataRepositoryAssociation(): AwsFileCache.DataRepositoryAssociationPropertyList;
    putDataRepositoryAssociation(value: AwsFileCache.DataRepositoryAssociationProperty[] | cdktn.IResolvable): void;
    resetDataRepositoryAssociation(): void;
    get dataRepositoryAssociationInput(): cdktn.IResolvable | AwsFileCache.DataRepositoryAssociationProperty[] | undefined;
    private _lustreConfiguration;
    get lustreConfiguration(): AwsFileCache.LustreConfigurationPropertyList;
    putLustreConfiguration(value: AwsFileCache.LustreConfigurationProperty[] | cdktn.IResolvable): void;
    resetLustreConfiguration(): void;
    get lustreConfigurationInput(): cdktn.IResolvable | AwsFileCache.LustreConfigurationProperty[] | undefined;
    private _timeouts;
    get timeouts(): AwsFileCache.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsFileCache.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsFileCache.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsFileCacheNfsPropertyToTerraform(struct?: AwsFileCache.NfsProperty | cdktn.IResolvable): any;
export declare function awsFileCacheNfsPropertyToHclTerraform(struct?: AwsFileCache.NfsProperty | cdktn.IResolvable): any;
export declare function awsFileCacheDataRepositoryAssociationPropertyToTerraform(struct?: AwsFileCache.DataRepositoryAssociationProperty | cdktn.IResolvable): any;
export declare function awsFileCacheDataRepositoryAssociationPropertyToHclTerraform(struct?: AwsFileCache.DataRepositoryAssociationProperty | cdktn.IResolvable): any;
export declare function awsFileCacheLogConfigurationPropertyToTerraform(struct?: AwsFileCache.LogConfigurationProperty): any;
export declare function awsFileCacheLogConfigurationPropertyToHclTerraform(struct?: AwsFileCache.LogConfigurationProperty): any;
export declare function awsFileCacheMetadataConfigurationPropertyToTerraform(struct?: AwsFileCache.MetadataConfigurationProperty | cdktn.IResolvable): any;
export declare function awsFileCacheMetadataConfigurationPropertyToHclTerraform(struct?: AwsFileCache.MetadataConfigurationProperty | cdktn.IResolvable): any;
export declare function awsFileCacheLustreConfigurationPropertyToTerraform(struct?: AwsFileCache.LustreConfigurationProperty | cdktn.IResolvable): any;
export declare function awsFileCacheLustreConfigurationPropertyToHclTerraform(struct?: AwsFileCache.LustreConfigurationProperty | cdktn.IResolvable): any;
export declare function awsFileCacheTimeoutsPropertyToTerraform(struct?: AwsFileCache.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsFileCacheTimeoutsPropertyToHclTerraform(struct?: AwsFileCache.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsFileCache {
    interface NfsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_file_cache#dns_ips AwsFileCache#dns_ips}
        */
        readonly dnsIps?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_file_cache#version AwsFileCache#version}
        */
        readonly version: string;
    }
    class NfsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): NfsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: NfsProperty | cdktn.IResolvable | undefined);
        private _dnsIps?;
        get dnsIps(): string[];
        set dnsIps(value: string[]);
        resetDnsIps(): void;
        get dnsIpsInput(): string[] | undefined;
        private _version?;
        get version(): string;
        set version(value: string);
        get versionInput(): string | undefined;
    }
    class NfsPropertyList extends cdktn.ComplexList {
        internalValue?: NfsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): NfsPropertyOutputReference;
    }
    interface DataRepositoryAssociationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_file_cache#data_repository_path AwsFileCache#data_repository_path}
        */
        readonly dataRepositoryPath: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_file_cache#data_repository_subdirectories AwsFileCache#data_repository_subdirectories}
        */
        readonly dataRepositorySubdirectories?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_file_cache#file_cache_path AwsFileCache#file_cache_path}
        */
        readonly fileCachePath: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_file_cache#tags AwsFileCache#tags}
        */
        readonly tags?: {
            [key: string]: string;
        };
        /**
        * nfs block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_file_cache#nfs AwsFileCache#nfs}
        */
        readonly nfs?: NfsProperty[] | cdktn.IResolvable;
    }
    class DataRepositoryAssociationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DataRepositoryAssociationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DataRepositoryAssociationProperty | cdktn.IResolvable | undefined);
        get associationId(): string;
        private _dataRepositoryPath?;
        get dataRepositoryPath(): string;
        set dataRepositoryPath(value: string);
        get dataRepositoryPathInput(): string | undefined;
        private _dataRepositorySubdirectories?;
        get dataRepositorySubdirectories(): string[];
        set dataRepositorySubdirectories(value: string[]);
        resetDataRepositorySubdirectories(): void;
        get dataRepositorySubdirectoriesInput(): string[] | undefined;
        get fileCacheId(): string;
        private _fileCachePath?;
        get fileCachePath(): string;
        set fileCachePath(value: string);
        get fileCachePathInput(): string | undefined;
        get fileSystemId(): string;
        get fileSystemPath(): string;
        get importedFileChunkSize(): number;
        get resourceArn(): string;
        private _tags?;
        get tags(): {
            [key: string]: string;
        };
        set tags(value: {
            [key: string]: string;
        });
        resetTags(): void;
        get tagsInput(): {
            [key: string]: string;
        } | undefined;
        private _nfs;
        get nfs(): NfsPropertyList;
        putNfs(value: NfsProperty[] | cdktn.IResolvable): void;
        resetNfs(): void;
        get nfsInput(): cdktn.IResolvable | NfsProperty[] | undefined;
    }
    class DataRepositoryAssociationPropertyList extends cdktn.ComplexList {
        internalValue?: DataRepositoryAssociationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DataRepositoryAssociationPropertyOutputReference;
    }
    interface LogConfigurationProperty {
    }
    class LogConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): LogConfigurationProperty | undefined;
        set internalValue(value: LogConfigurationProperty | undefined);
        get destination(): string;
        get level(): string;
    }
    class LogConfigurationPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): LogConfigurationPropertyOutputReference;
    }
    interface MetadataConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_file_cache#storage_capacity AwsFileCache#storage_capacity}
        */
        readonly storageCapacity: number;
    }
    class MetadataConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): MetadataConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: MetadataConfigurationProperty | cdktn.IResolvable | undefined);
        private _storageCapacity?;
        get storageCapacity(): number;
        set storageCapacity(value: number);
        get storageCapacityInput(): number | undefined;
    }
    class MetadataConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: MetadataConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): MetadataConfigurationPropertyOutputReference;
    }
    interface LustreConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_file_cache#deployment_type AwsFileCache#deployment_type}
        */
        readonly deploymentType: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_file_cache#per_unit_storage_throughput AwsFileCache#per_unit_storage_throughput}
        */
        readonly perUnitStorageThroughput: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_file_cache#weekly_maintenance_start_time AwsFileCache#weekly_maintenance_start_time}
        */
        readonly weeklyMaintenanceStartTime?: string;
        /**
        * metadata_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_file_cache#metadata_configuration AwsFileCache#metadata_configuration}
        */
        readonly metadataConfiguration: MetadataConfigurationProperty[] | cdktn.IResolvable;
    }
    class LustreConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): LustreConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: LustreConfigurationProperty | cdktn.IResolvable | undefined);
        private _deploymentType?;
        get deploymentType(): string;
        set deploymentType(value: string);
        get deploymentTypeInput(): string | undefined;
        private _logConfiguration;
        get logConfiguration(): LogConfigurationPropertyList;
        get mountName(): string;
        private _perUnitStorageThroughput?;
        get perUnitStorageThroughput(): number;
        set perUnitStorageThroughput(value: number);
        get perUnitStorageThroughputInput(): number | undefined;
        private _weeklyMaintenanceStartTime?;
        get weeklyMaintenanceStartTime(): string;
        set weeklyMaintenanceStartTime(value: string);
        resetWeeklyMaintenanceStartTime(): void;
        get weeklyMaintenanceStartTimeInput(): string | undefined;
        private _metadataConfiguration;
        get metadataConfiguration(): MetadataConfigurationPropertyList;
        putMetadataConfiguration(value: MetadataConfigurationProperty[] | cdktn.IResolvable): void;
        get metadataConfigurationInput(): cdktn.IResolvable | MetadataConfigurationProperty[] | undefined;
    }
    class LustreConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: LustreConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): LustreConfigurationPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_file_cache#create AwsFileCache#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_file_cache#delete AwsFileCache#delete}
        */
        readonly delete?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_file_cache#update AwsFileCache#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
