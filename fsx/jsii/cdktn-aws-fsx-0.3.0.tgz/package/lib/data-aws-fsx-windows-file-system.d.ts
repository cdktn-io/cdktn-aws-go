import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsWindowsFileSystemConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/fsx_windows_file_system#id DataAwsWindowsFileSystem#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/fsx_windows_file_system#region DataAwsWindowsFileSystem#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/fsx_windows_file_system#tags DataAwsWindowsFileSystem#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/fsx_windows_file_system aws_fsx_windows_file_system}
*/
export declare class DataAwsWindowsFileSystem extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_fsx_windows_file_system";
    /**
    * Generates CDKTN code for importing a DataAwsWindowsFileSystem resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsWindowsFileSystem to import
    * @param importFromId The id of the existing DataAwsWindowsFileSystem that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/fsx_windows_file_system#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsWindowsFileSystem to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/fsx_windows_file_system aws_fsx_windows_file_system} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsWindowsFileSystemConfig
    */
    constructor(scope: Construct, id: string, config: DataAwsWindowsFileSystemConfig);
    get activeDirectoryId(): string;
    get aliases(): string[];
    get arn(): string;
    private _auditLogConfiguration;
    get auditLogConfiguration(): DataAwsWindowsFileSystem.AuditLogConfigurationPropertyList;
    get automaticBackupRetentionDays(): number;
    get backupId(): string;
    get copyTagsToBackups(): cdktn.IResolvable;
    get dailyAutomaticBackupStartTime(): string;
    get deploymentType(): string;
    private _diskIopsConfiguration;
    get diskIopsConfiguration(): DataAwsWindowsFileSystem.DiskIopsConfigurationPropertyList;
    get dnsName(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    get kmsKeyId(): string;
    get networkInterfaceIds(): string[];
    get networkType(): string;
    get ownerId(): string;
    get preferredFileServerIp(): string;
    get preferredSubnetId(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get securityGroupIds(): string[];
    get skipFinalBackup(): cdktn.IResolvable;
    get storageCapacity(): number;
    get storageType(): string;
    get subnetIds(): string[];
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    get throughputCapacity(): number;
    get vpcId(): string;
    get weeklyMaintenanceStartTime(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataAwsWindowsFileSystemAuditLogConfigurationPropertyToTerraform(struct?: DataAwsWindowsFileSystem.AuditLogConfigurationProperty): any;
export declare function dataAwsWindowsFileSystemAuditLogConfigurationPropertyToHclTerraform(struct?: DataAwsWindowsFileSystem.AuditLogConfigurationProperty): any;
export declare function dataAwsWindowsFileSystemDiskIopsConfigurationPropertyToTerraform(struct?: DataAwsWindowsFileSystem.DiskIopsConfigurationProperty): any;
export declare function dataAwsWindowsFileSystemDiskIopsConfigurationPropertyToHclTerraform(struct?: DataAwsWindowsFileSystem.DiskIopsConfigurationProperty): any;
export declare namespace DataAwsWindowsFileSystem {
    interface AuditLogConfigurationProperty {
    }
    class AuditLogConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AuditLogConfigurationProperty | undefined;
        set internalValue(value: AuditLogConfigurationProperty | undefined);
        get auditLogDestination(): string;
        get fileAccessAuditLogLevel(): string;
        get fileShareAccessAuditLogLevel(): string;
    }
    class AuditLogConfigurationPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AuditLogConfigurationPropertyOutputReference;
    }
    interface DiskIopsConfigurationProperty {
    }
    class DiskIopsConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DiskIopsConfigurationProperty | undefined;
        set internalValue(value: DiskIopsConfigurationProperty | undefined);
        get iops(): number;
        get mode(): string;
    }
    class DiskIopsConfigurationPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DiskIopsConfigurationPropertyOutputReference;
    }
}
