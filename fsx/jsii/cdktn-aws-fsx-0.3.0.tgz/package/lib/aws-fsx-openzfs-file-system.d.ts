import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsOpenzfsFileSystemConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_openzfs_file_system#automatic_backup_retention_days AwsOpenzfsFileSystem#automatic_backup_retention_days}
    */
    readonly automaticBackupRetentionDays?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_openzfs_file_system#backup_id AwsOpenzfsFileSystem#backup_id}
    */
    readonly backupId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_openzfs_file_system#copy_tags_to_backups AwsOpenzfsFileSystem#copy_tags_to_backups}
    */
    readonly copyTagsToBackups?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_openzfs_file_system#copy_tags_to_volumes AwsOpenzfsFileSystem#copy_tags_to_volumes}
    */
    readonly copyTagsToVolumes?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_openzfs_file_system#daily_automatic_backup_start_time AwsOpenzfsFileSystem#daily_automatic_backup_start_time}
    */
    readonly dailyAutomaticBackupStartTime?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_openzfs_file_system#delete_options AwsOpenzfsFileSystem#delete_options}
    */
    readonly deleteOptions?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_openzfs_file_system#deployment_type AwsOpenzfsFileSystem#deployment_type}
    */
    readonly deploymentType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_openzfs_file_system#endpoint_ip_address_range AwsOpenzfsFileSystem#endpoint_ip_address_range}
    */
    readonly endpointIpAddressRange?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_openzfs_file_system#final_backup_tags AwsOpenzfsFileSystem#final_backup_tags}
    */
    readonly finalBackupTags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_openzfs_file_system#id AwsOpenzfsFileSystem#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_openzfs_file_system#kms_key_id AwsOpenzfsFileSystem#kms_key_id}
    */
    readonly kmsKeyId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_openzfs_file_system#network_type AwsOpenzfsFileSystem#network_type}
    */
    readonly networkType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_openzfs_file_system#preferred_subnet_id AwsOpenzfsFileSystem#preferred_subnet_id}
    */
    readonly preferredSubnetId?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_openzfs_file_system#region AwsOpenzfsFileSystem#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_openzfs_file_system#route_table_ids AwsOpenzfsFileSystem#route_table_ids}
    */
    readonly routeTableIds?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_openzfs_file_system#security_group_ids AwsOpenzfsFileSystem#security_group_ids}
    */
    readonly securityGroupIds?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_openzfs_file_system#skip_final_backup AwsOpenzfsFileSystem#skip_final_backup}
    */
    readonly skipFinalBackup?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_openzfs_file_system#storage_capacity AwsOpenzfsFileSystem#storage_capacity}
    */
    readonly storageCapacity?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_openzfs_file_system#storage_type AwsOpenzfsFileSystem#storage_type}
    */
    readonly storageType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_openzfs_file_system#subnet_ids AwsOpenzfsFileSystem#subnet_ids}
    */
    readonly subnetIds: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_openzfs_file_system#tags AwsOpenzfsFileSystem#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_openzfs_file_system#tags_all AwsOpenzfsFileSystem#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_openzfs_file_system#throughput_capacity AwsOpenzfsFileSystem#throughput_capacity}
    */
    readonly throughputCapacity: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_openzfs_file_system#weekly_maintenance_start_time AwsOpenzfsFileSystem#weekly_maintenance_start_time}
    */
    readonly weeklyMaintenanceStartTime?: string;
    /**
    * disk_iops_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_openzfs_file_system#disk_iops_configuration AwsOpenzfsFileSystem#disk_iops_configuration}
    */
    readonly diskIopsConfiguration?: AwsOpenzfsFileSystem.DiskIopsConfigurationProperty;
    /**
    * read_cache_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_openzfs_file_system#read_cache_configuration AwsOpenzfsFileSystem#read_cache_configuration}
    */
    readonly readCacheConfiguration?: AwsOpenzfsFileSystem.ReadCacheConfigurationProperty;
    /**
    * root_volume_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_openzfs_file_system#root_volume_configuration AwsOpenzfsFileSystem#root_volume_configuration}
    */
    readonly rootVolumeConfiguration?: AwsOpenzfsFileSystem.RootVolumeConfigurationProperty;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_openzfs_file_system#timeouts AwsOpenzfsFileSystem#timeouts}
    */
    readonly timeouts?: AwsOpenzfsFileSystem.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_openzfs_file_system aws_fsx_openzfs_file_system}
*/
export declare class AwsOpenzfsFileSystem extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_fsx_openzfs_file_system";
    /**
    * Generates CDKTN code for importing a AwsOpenzfsFileSystem resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsOpenzfsFileSystem to import
    * @param importFromId The id of the existing AwsOpenzfsFileSystem that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_openzfs_file_system#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsOpenzfsFileSystem to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_openzfs_file_system aws_fsx_openzfs_file_system} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsOpenzfsFileSystemConfig
    */
    constructor(scope: Construct, id: string, config: AwsOpenzfsFileSystemConfig);
    get arn(): string;
    private _automaticBackupRetentionDays?;
    get automaticBackupRetentionDays(): number;
    set automaticBackupRetentionDays(value: number);
    resetAutomaticBackupRetentionDays(): void;
    get automaticBackupRetentionDaysInput(): number | undefined;
    private _backupId?;
    get backupId(): string;
    set backupId(value: string);
    resetBackupId(): void;
    get backupIdInput(): string | undefined;
    private _copyTagsToBackups?;
    get copyTagsToBackups(): boolean | cdktn.IResolvable;
    set copyTagsToBackups(value: boolean | cdktn.IResolvable);
    resetCopyTagsToBackups(): void;
    get copyTagsToBackupsInput(): boolean | cdktn.IResolvable | undefined;
    private _copyTagsToVolumes?;
    get copyTagsToVolumes(): boolean | cdktn.IResolvable;
    set copyTagsToVolumes(value: boolean | cdktn.IResolvable);
    resetCopyTagsToVolumes(): void;
    get copyTagsToVolumesInput(): boolean | cdktn.IResolvable | undefined;
    private _dailyAutomaticBackupStartTime?;
    get dailyAutomaticBackupStartTime(): string;
    set dailyAutomaticBackupStartTime(value: string);
    resetDailyAutomaticBackupStartTime(): void;
    get dailyAutomaticBackupStartTimeInput(): string | undefined;
    private _deleteOptions?;
    get deleteOptions(): string[];
    set deleteOptions(value: string[]);
    resetDeleteOptions(): void;
    get deleteOptionsInput(): string[] | undefined;
    private _deploymentType?;
    get deploymentType(): string;
    set deploymentType(value: string);
    get deploymentTypeInput(): string | undefined;
    get dnsName(): string;
    get endpointIpAddress(): string;
    private _endpointIpAddressRange?;
    get endpointIpAddressRange(): string;
    set endpointIpAddressRange(value: string);
    resetEndpointIpAddressRange(): void;
    get endpointIpAddressRangeInput(): string | undefined;
    private _finalBackupTags?;
    get finalBackupTags(): {
        [key: string]: string;
    };
    set finalBackupTags(value: {
        [key: string]: string;
    });
    resetFinalBackupTags(): void;
    get finalBackupTagsInput(): {
        [key: string]: string;
    } | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _kmsKeyId?;
    get kmsKeyId(): string;
    set kmsKeyId(value: string);
    resetKmsKeyId(): void;
    get kmsKeyIdInput(): string | undefined;
    get networkInterfaceIds(): string[];
    private _networkType?;
    get networkType(): string;
    set networkType(value: string);
    resetNetworkType(): void;
    get networkTypeInput(): string | undefined;
    get ownerId(): string;
    private _preferredSubnetId?;
    get preferredSubnetId(): string;
    set preferredSubnetId(value: string);
    resetPreferredSubnetId(): void;
    get preferredSubnetIdInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get rootVolumeId(): string;
    private _routeTableIds?;
    get routeTableIds(): string[];
    set routeTableIds(value: string[]);
    resetRouteTableIds(): void;
    get routeTableIdsInput(): string[] | undefined;
    private _securityGroupIds?;
    get securityGroupIds(): string[];
    set securityGroupIds(value: string[]);
    resetSecurityGroupIds(): void;
    get securityGroupIdsInput(): string[] | undefined;
    private _skipFinalBackup?;
    get skipFinalBackup(): boolean | cdktn.IResolvable;
    set skipFinalBackup(value: boolean | cdktn.IResolvable);
    resetSkipFinalBackup(): void;
    get skipFinalBackupInput(): boolean | cdktn.IResolvable | undefined;
    private _storageCapacity?;
    get storageCapacity(): number;
    set storageCapacity(value: number);
    resetStorageCapacity(): void;
    get storageCapacityInput(): number | undefined;
    private _storageType?;
    get storageType(): string;
    set storageType(value: string);
    resetStorageType(): void;
    get storageTypeInput(): string | undefined;
    private _subnetIds?;
    get subnetIds(): string[];
    set subnetIds(value: string[]);
    get subnetIdsInput(): string[] | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _throughputCapacity?;
    get throughputCapacity(): number;
    set throughputCapacity(value: number);
    get throughputCapacityInput(): number | undefined;
    get vpcId(): string;
    private _weeklyMaintenanceStartTime?;
    get weeklyMaintenanceStartTime(): string;
    set weeklyMaintenanceStartTime(value: string);
    resetWeeklyMaintenanceStartTime(): void;
    get weeklyMaintenanceStartTimeInput(): string | undefined;
    private _diskIopsConfiguration;
    get diskIopsConfiguration(): AwsOpenzfsFileSystem.DiskIopsConfigurationPropertyOutputReference;
    putDiskIopsConfiguration(value: AwsOpenzfsFileSystem.DiskIopsConfigurationProperty): void;
    resetDiskIopsConfiguration(): void;
    get diskIopsConfigurationInput(): AwsOpenzfsFileSystem.DiskIopsConfigurationProperty | undefined;
    private _readCacheConfiguration;
    get readCacheConfiguration(): AwsOpenzfsFileSystem.ReadCacheConfigurationPropertyOutputReference;
    putReadCacheConfiguration(value: AwsOpenzfsFileSystem.ReadCacheConfigurationProperty): void;
    resetReadCacheConfiguration(): void;
    get readCacheConfigurationInput(): AwsOpenzfsFileSystem.ReadCacheConfigurationProperty | undefined;
    private _rootVolumeConfiguration;
    get rootVolumeConfiguration(): AwsOpenzfsFileSystem.RootVolumeConfigurationPropertyOutputReference;
    putRootVolumeConfiguration(value: AwsOpenzfsFileSystem.RootVolumeConfigurationProperty): void;
    resetRootVolumeConfiguration(): void;
    get rootVolumeConfigurationInput(): AwsOpenzfsFileSystem.RootVolumeConfigurationProperty | undefined;
    private _timeouts;
    get timeouts(): AwsOpenzfsFileSystem.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsOpenzfsFileSystem.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsOpenzfsFileSystem.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsOpenzfsFileSystemDiskIopsConfigurationPropertyToTerraform(struct?: AwsOpenzfsFileSystem.DiskIopsConfigurationPropertyOutputReference | AwsOpenzfsFileSystem.DiskIopsConfigurationProperty): any;
export declare function awsOpenzfsFileSystemDiskIopsConfigurationPropertyToHclTerraform(struct?: AwsOpenzfsFileSystem.DiskIopsConfigurationPropertyOutputReference | AwsOpenzfsFileSystem.DiskIopsConfigurationProperty): any;
export declare function awsOpenzfsFileSystemReadCacheConfigurationPropertyToTerraform(struct?: AwsOpenzfsFileSystem.ReadCacheConfigurationPropertyOutputReference | AwsOpenzfsFileSystem.ReadCacheConfigurationProperty): any;
export declare function awsOpenzfsFileSystemReadCacheConfigurationPropertyToHclTerraform(struct?: AwsOpenzfsFileSystem.ReadCacheConfigurationPropertyOutputReference | AwsOpenzfsFileSystem.ReadCacheConfigurationProperty): any;
export declare function awsOpenzfsFileSystemClientConfigurationsPropertyToTerraform(struct?: AwsOpenzfsFileSystem.ClientConfigurationsProperty | cdktn.IResolvable): any;
export declare function awsOpenzfsFileSystemClientConfigurationsPropertyToHclTerraform(struct?: AwsOpenzfsFileSystem.ClientConfigurationsProperty | cdktn.IResolvable): any;
export declare function awsOpenzfsFileSystemNfsExportsPropertyToTerraform(struct?: AwsOpenzfsFileSystem.NfsExportsPropertyOutputReference | AwsOpenzfsFileSystem.NfsExportsProperty): any;
export declare function awsOpenzfsFileSystemNfsExportsPropertyToHclTerraform(struct?: AwsOpenzfsFileSystem.NfsExportsPropertyOutputReference | AwsOpenzfsFileSystem.NfsExportsProperty): any;
export declare function awsOpenzfsFileSystemUserAndGroupQuotasPropertyToTerraform(struct?: AwsOpenzfsFileSystem.UserAndGroupQuotasProperty | cdktn.IResolvable): any;
export declare function awsOpenzfsFileSystemUserAndGroupQuotasPropertyToHclTerraform(struct?: AwsOpenzfsFileSystem.UserAndGroupQuotasProperty | cdktn.IResolvable): any;
export declare function awsOpenzfsFileSystemRootVolumeConfigurationPropertyToTerraform(struct?: AwsOpenzfsFileSystem.RootVolumeConfigurationPropertyOutputReference | AwsOpenzfsFileSystem.RootVolumeConfigurationProperty): any;
export declare function awsOpenzfsFileSystemRootVolumeConfigurationPropertyToHclTerraform(struct?: AwsOpenzfsFileSystem.RootVolumeConfigurationPropertyOutputReference | AwsOpenzfsFileSystem.RootVolumeConfigurationProperty): any;
export declare function awsOpenzfsFileSystemTimeoutsPropertyToTerraform(struct?: AwsOpenzfsFileSystem.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsOpenzfsFileSystemTimeoutsPropertyToHclTerraform(struct?: AwsOpenzfsFileSystem.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsOpenzfsFileSystem {
    interface DiskIopsConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_openzfs_file_system#iops AwsOpenzfsFileSystem#iops}
        */
        readonly iops?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_openzfs_file_system#mode AwsOpenzfsFileSystem#mode}
        */
        readonly mode?: string;
    }
    class DiskIopsConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DiskIopsConfigurationProperty | undefined;
        set internalValue(value: DiskIopsConfigurationProperty | undefined);
        private _iops?;
        get iops(): number;
        set iops(value: number);
        resetIops(): void;
        get iopsInput(): number | undefined;
        private _mode?;
        get mode(): string;
        set mode(value: string);
        resetMode(): void;
        get modeInput(): string | undefined;
    }
    interface ReadCacheConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_openzfs_file_system#size AwsOpenzfsFileSystem#size}
        */
        readonly size?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_openzfs_file_system#sizing_mode AwsOpenzfsFileSystem#sizing_mode}
        */
        readonly sizingMode?: string;
    }
    class ReadCacheConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ReadCacheConfigurationProperty | undefined;
        set internalValue(value: ReadCacheConfigurationProperty | undefined);
        private _size?;
        get size(): number;
        set size(value: number);
        resetSize(): void;
        get sizeInput(): number | undefined;
        private _sizingMode?;
        get sizingMode(): string;
        set sizingMode(value: string);
        resetSizingMode(): void;
        get sizingModeInput(): string | undefined;
    }
    interface ClientConfigurationsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_openzfs_file_system#clients AwsOpenzfsFileSystem#clients}
        */
        readonly clients: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_openzfs_file_system#options AwsOpenzfsFileSystem#options}
        */
        readonly options: string[];
    }
    class ClientConfigurationsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ClientConfigurationsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ClientConfigurationsProperty | cdktn.IResolvable | undefined);
        private _clients?;
        get clients(): string;
        set clients(value: string);
        get clientsInput(): string | undefined;
        private _options?;
        get options(): string[];
        set options(value: string[]);
        get optionsInput(): string[] | undefined;
    }
    class ClientConfigurationsPropertyList extends cdktn.ComplexList {
        internalValue?: ClientConfigurationsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ClientConfigurationsPropertyOutputReference;
    }
    interface NfsExportsProperty {
        /**
        * client_configurations block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_openzfs_file_system#client_configurations AwsOpenzfsFileSystem#client_configurations}
        */
        readonly clientConfigurations: ClientConfigurationsProperty[] | cdktn.IResolvable;
    }
    class NfsExportsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): NfsExportsProperty | undefined;
        set internalValue(value: NfsExportsProperty | undefined);
        private _clientConfigurations;
        get clientConfigurations(): ClientConfigurationsPropertyList;
        putClientConfigurations(value: ClientConfigurationsProperty[] | cdktn.IResolvable): void;
        get clientConfigurationsInput(): cdktn.IResolvable | ClientConfigurationsProperty[] | undefined;
    }
    interface UserAndGroupQuotasProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_openzfs_file_system#id AwsOpenzfsFileSystem#id}
        *
        * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
        * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
        */
        readonly id: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_openzfs_file_system#storage_capacity_quota_gib AwsOpenzfsFileSystem#storage_capacity_quota_gib}
        */
        readonly storageCapacityQuotaGib: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_openzfs_file_system#type AwsOpenzfsFileSystem#type}
        */
        readonly type: string;
    }
    class UserAndGroupQuotasPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): UserAndGroupQuotasProperty | cdktn.IResolvable | undefined;
        set internalValue(value: UserAndGroupQuotasProperty | cdktn.IResolvable | undefined);
        private _id?;
        get id(): number;
        set id(value: number);
        get idInput(): number | undefined;
        private _storageCapacityQuotaGib?;
        get storageCapacityQuotaGib(): number;
        set storageCapacityQuotaGib(value: number);
        get storageCapacityQuotaGibInput(): number | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
    }
    class UserAndGroupQuotasPropertyList extends cdktn.ComplexList {
        internalValue?: UserAndGroupQuotasProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): UserAndGroupQuotasPropertyOutputReference;
    }
    interface RootVolumeConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_openzfs_file_system#copy_tags_to_snapshots AwsOpenzfsFileSystem#copy_tags_to_snapshots}
        */
        readonly copyTagsToSnapshots?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_openzfs_file_system#data_compression_type AwsOpenzfsFileSystem#data_compression_type}
        */
        readonly dataCompressionType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_openzfs_file_system#read_only AwsOpenzfsFileSystem#read_only}
        */
        readonly readOnly?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_openzfs_file_system#record_size_kib AwsOpenzfsFileSystem#record_size_kib}
        */
        readonly recordSizeKib?: number;
        /**
        * nfs_exports block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_openzfs_file_system#nfs_exports AwsOpenzfsFileSystem#nfs_exports}
        */
        readonly nfsExports?: NfsExportsProperty;
        /**
        * user_and_group_quotas block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_openzfs_file_system#user_and_group_quotas AwsOpenzfsFileSystem#user_and_group_quotas}
        */
        readonly userAndGroupQuotas?: UserAndGroupQuotasProperty[] | cdktn.IResolvable;
    }
    class RootVolumeConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RootVolumeConfigurationProperty | undefined;
        set internalValue(value: RootVolumeConfigurationProperty | undefined);
        private _copyTagsToSnapshots?;
        get copyTagsToSnapshots(): boolean | cdktn.IResolvable;
        set copyTagsToSnapshots(value: boolean | cdktn.IResolvable);
        resetCopyTagsToSnapshots(): void;
        get copyTagsToSnapshotsInput(): boolean | cdktn.IResolvable | undefined;
        private _dataCompressionType?;
        get dataCompressionType(): string;
        set dataCompressionType(value: string);
        resetDataCompressionType(): void;
        get dataCompressionTypeInput(): string | undefined;
        private _readOnly?;
        get readOnly(): boolean | cdktn.IResolvable;
        set readOnly(value: boolean | cdktn.IResolvable);
        resetReadOnly(): void;
        get readOnlyInput(): boolean | cdktn.IResolvable | undefined;
        private _recordSizeKib?;
        get recordSizeKib(): number;
        set recordSizeKib(value: number);
        resetRecordSizeKib(): void;
        get recordSizeKibInput(): number | undefined;
        private _nfsExports;
        get nfsExports(): NfsExportsPropertyOutputReference;
        putNfsExports(value: NfsExportsProperty): void;
        resetNfsExports(): void;
        get nfsExportsInput(): NfsExportsProperty | undefined;
        private _userAndGroupQuotas;
        get userAndGroupQuotas(): UserAndGroupQuotasPropertyList;
        putUserAndGroupQuotas(value: UserAndGroupQuotasProperty[] | cdktn.IResolvable): void;
        resetUserAndGroupQuotas(): void;
        get userAndGroupQuotasInput(): cdktn.IResolvable | UserAndGroupQuotasProperty[] | undefined;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_openzfs_file_system#create AwsOpenzfsFileSystem#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_openzfs_file_system#delete AwsOpenzfsFileSystem#delete}
        */
        readonly delete?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_openzfs_file_system#update AwsOpenzfsFileSystem#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
