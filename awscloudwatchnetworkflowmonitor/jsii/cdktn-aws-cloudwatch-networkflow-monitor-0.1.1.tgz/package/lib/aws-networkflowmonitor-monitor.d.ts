import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsNetworkflowmonitorMonitorConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkflowmonitor_monitor#monitor_name AwsNetworkflowmonitorMonitor#monitor_name}
    */
    readonly monitorName: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkflowmonitor_monitor#region AwsNetworkflowmonitorMonitor#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkflowmonitor_monitor#scope_arn AwsNetworkflowmonitorMonitor#scope_arn}
    */
    readonly scopeArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkflowmonitor_monitor#tags AwsNetworkflowmonitorMonitor#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * local_resource block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkflowmonitor_monitor#local_resource AwsNetworkflowmonitorMonitor#local_resource}
    */
    readonly localResource?: AwsNetworkflowmonitorMonitor.LocalResourceProperty[] | cdktn.IResolvable;
    /**
    * remote_resource block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkflowmonitor_monitor#remote_resource AwsNetworkflowmonitorMonitor#remote_resource}
    */
    readonly remoteResource?: AwsNetworkflowmonitorMonitor.RemoteResourceProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkflowmonitor_monitor#timeouts AwsNetworkflowmonitorMonitor#timeouts}
    */
    readonly timeouts?: AwsNetworkflowmonitorMonitor.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkflowmonitor_monitor aws_networkflowmonitor_monitor}
*/
export declare class AwsNetworkflowmonitorMonitor extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_networkflowmonitor_monitor";
    /**
    * Generates CDKTN code for importing a AwsNetworkflowmonitorMonitor resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsNetworkflowmonitorMonitor to import
    * @param importFromId The id of the existing AwsNetworkflowmonitorMonitor that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkflowmonitor_monitor#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsNetworkflowmonitorMonitor to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkflowmonitor_monitor aws_networkflowmonitor_monitor} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsNetworkflowmonitorMonitorConfig
    */
    constructor(scope: Construct, id: string, config: AwsNetworkflowmonitorMonitorConfig);
    get monitorArn(): string;
    private _monitorName?;
    get monitorName(): string;
    set monitorName(value: string);
    get monitorNameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _scopeArn?;
    get scopeArn(): string;
    set scopeArn(value: string);
    get scopeArnInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    private _localResource;
    get localResource(): AwsNetworkflowmonitorMonitor.LocalResourcePropertyList;
    putLocalResource(value: AwsNetworkflowmonitorMonitor.LocalResourceProperty[] | cdktn.IResolvable): void;
    resetLocalResource(): void;
    get localResourceInput(): cdktn.IResolvable | AwsNetworkflowmonitorMonitor.LocalResourceProperty[] | undefined;
    private _remoteResource;
    get remoteResource(): AwsNetworkflowmonitorMonitor.RemoteResourcePropertyList;
    putRemoteResource(value: AwsNetworkflowmonitorMonitor.RemoteResourceProperty[] | cdktn.IResolvable): void;
    resetRemoteResource(): void;
    get remoteResourceInput(): cdktn.IResolvable | AwsNetworkflowmonitorMonitor.RemoteResourceProperty[] | undefined;
    private _timeouts;
    get timeouts(): AwsNetworkflowmonitorMonitor.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsNetworkflowmonitorMonitor.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsNetworkflowmonitorMonitor.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsNetworkflowmonitorMonitorLocalResourcePropertyToTerraform(struct?: AwsNetworkflowmonitorMonitor.LocalResourceProperty | cdktn.IResolvable): any;
export declare function awsNetworkflowmonitorMonitorLocalResourcePropertyToHclTerraform(struct?: AwsNetworkflowmonitorMonitor.LocalResourceProperty | cdktn.IResolvable): any;
export declare function awsNetworkflowmonitorMonitorRemoteResourcePropertyToTerraform(struct?: AwsNetworkflowmonitorMonitor.RemoteResourceProperty | cdktn.IResolvable): any;
export declare function awsNetworkflowmonitorMonitorRemoteResourcePropertyToHclTerraform(struct?: AwsNetworkflowmonitorMonitor.RemoteResourceProperty | cdktn.IResolvable): any;
export declare function awsNetworkflowmonitorMonitorTimeoutsPropertyToTerraform(struct?: AwsNetworkflowmonitorMonitor.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsNetworkflowmonitorMonitorTimeoutsPropertyToHclTerraform(struct?: AwsNetworkflowmonitorMonitor.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsNetworkflowmonitorMonitor {
    interface LocalResourceProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkflowmonitor_monitor#identifier AwsNetworkflowmonitorMonitor#identifier}
        */
        readonly identifier: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkflowmonitor_monitor#type AwsNetworkflowmonitorMonitor#type}
        */
        readonly type: string;
    }
    class LocalResourcePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): LocalResourceProperty | cdktn.IResolvable | undefined;
        set internalValue(value: LocalResourceProperty | cdktn.IResolvable | undefined);
        private _identifier?;
        get identifier(): string;
        set identifier(value: string);
        get identifierInput(): string | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
    }
    class LocalResourcePropertyList extends cdktn.ComplexList {
        internalValue?: LocalResourceProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): LocalResourcePropertyOutputReference;
    }
    interface RemoteResourceProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkflowmonitor_monitor#identifier AwsNetworkflowmonitorMonitor#identifier}
        */
        readonly identifier: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkflowmonitor_monitor#type AwsNetworkflowmonitorMonitor#type}
        */
        readonly type: string;
    }
    class RemoteResourcePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RemoteResourceProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RemoteResourceProperty | cdktn.IResolvable | undefined);
        private _identifier?;
        get identifier(): string;
        set identifier(value: string);
        get identifierInput(): string | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
    }
    class RemoteResourcePropertyList extends cdktn.ComplexList {
        internalValue?: RemoteResourceProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RemoteResourcePropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkflowmonitor_monitor#create AwsNetworkflowmonitorMonitor#create}
        */
        readonly create?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Setting a timeout for a Delete operation is only applicable if changes are saved into state before the destroy operation occurs.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkflowmonitor_monitor#delete AwsNetworkflowmonitorMonitor#delete}
        */
        readonly delete?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkflowmonitor_monitor#update AwsNetworkflowmonitorMonitor#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
