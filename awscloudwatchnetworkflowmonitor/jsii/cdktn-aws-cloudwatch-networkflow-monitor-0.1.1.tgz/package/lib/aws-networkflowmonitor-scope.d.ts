import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsNetworkflowmonitorScopeConfig extends cdktn.TerraformMetaArguments {
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkflowmonitor_scope#region AwsNetworkflowmonitorScope#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkflowmonitor_scope#tags AwsNetworkflowmonitorScope#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * target block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkflowmonitor_scope#target AwsNetworkflowmonitorScope#target}
    */
    readonly target?: AwsNetworkflowmonitorScope.TargetProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkflowmonitor_scope#timeouts AwsNetworkflowmonitorScope#timeouts}
    */
    readonly timeouts?: AwsNetworkflowmonitorScope.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkflowmonitor_scope aws_networkflowmonitor_scope}
*/
export declare class AwsNetworkflowmonitorScope extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_networkflowmonitor_scope";
    /**
    * Generates CDKTN code for importing a AwsNetworkflowmonitorScope resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsNetworkflowmonitorScope to import
    * @param importFromId The id of the existing AwsNetworkflowmonitorScope that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkflowmonitor_scope#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsNetworkflowmonitorScope to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkflowmonitor_scope aws_networkflowmonitor_scope} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsNetworkflowmonitorScopeConfig = {}
    */
    constructor(scope: Construct, id: string, config?: AwsNetworkflowmonitorScopeConfig);
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get scopeArn(): string;
    get scopeId(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    private _target;
    get target(): AwsNetworkflowmonitorScope.TargetPropertyList;
    putTarget(value: AwsNetworkflowmonitorScope.TargetProperty[] | cdktn.IResolvable): void;
    resetTarget(): void;
    get targetInput(): cdktn.IResolvable | AwsNetworkflowmonitorScope.TargetProperty[] | undefined;
    private _timeouts;
    get timeouts(): AwsNetworkflowmonitorScope.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsNetworkflowmonitorScope.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsNetworkflowmonitorScope.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsNetworkflowmonitorScopeTargetIdPropertyToTerraform(struct?: AwsNetworkflowmonitorScope.TargetIdProperty | cdktn.IResolvable): any;
export declare function awsNetworkflowmonitorScopeTargetIdPropertyToHclTerraform(struct?: AwsNetworkflowmonitorScope.TargetIdProperty | cdktn.IResolvable): any;
export declare function awsNetworkflowmonitorScopeTargetIdentifierPropertyToTerraform(struct?: AwsNetworkflowmonitorScope.TargetIdentifierProperty | cdktn.IResolvable): any;
export declare function awsNetworkflowmonitorScopeTargetIdentifierPropertyToHclTerraform(struct?: AwsNetworkflowmonitorScope.TargetIdentifierProperty | cdktn.IResolvable): any;
export declare function awsNetworkflowmonitorScopeTargetPropertyToTerraform(struct?: AwsNetworkflowmonitorScope.TargetProperty | cdktn.IResolvable): any;
export declare function awsNetworkflowmonitorScopeTargetPropertyToHclTerraform(struct?: AwsNetworkflowmonitorScope.TargetProperty | cdktn.IResolvable): any;
export declare function awsNetworkflowmonitorScopeTimeoutsPropertyToTerraform(struct?: AwsNetworkflowmonitorScope.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsNetworkflowmonitorScopeTimeoutsPropertyToHclTerraform(struct?: AwsNetworkflowmonitorScope.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsNetworkflowmonitorScope {
    interface TargetIdProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkflowmonitor_scope#account_id AwsNetworkflowmonitorScope#account_id}
        */
        readonly accountId: string;
    }
    class TargetIdPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TargetIdProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TargetIdProperty | cdktn.IResolvable | undefined);
        private _accountId?;
        get accountId(): string;
        set accountId(value: string);
        get accountIdInput(): string | undefined;
    }
    class TargetIdPropertyList extends cdktn.ComplexList {
        internalValue?: TargetIdProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TargetIdPropertyOutputReference;
    }
    interface TargetIdentifierProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkflowmonitor_scope#target_type AwsNetworkflowmonitorScope#target_type}
        */
        readonly targetType: string;
        /**
        * target_id block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkflowmonitor_scope#target_id AwsNetworkflowmonitorScope#target_id}
        */
        readonly targetId?: TargetIdProperty[] | cdktn.IResolvable;
    }
    class TargetIdentifierPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TargetIdentifierProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TargetIdentifierProperty | cdktn.IResolvable | undefined);
        private _targetType?;
        get targetType(): string;
        set targetType(value: string);
        get targetTypeInput(): string | undefined;
        private _targetId;
        get targetId(): TargetIdPropertyList;
        putTargetId(value: TargetIdProperty[] | cdktn.IResolvable): void;
        resetTargetId(): void;
        get targetIdInput(): cdktn.IResolvable | TargetIdProperty[] | undefined;
    }
    class TargetIdentifierPropertyList extends cdktn.ComplexList {
        internalValue?: TargetIdentifierProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TargetIdentifierPropertyOutputReference;
    }
    interface TargetProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkflowmonitor_scope#region AwsNetworkflowmonitorScope#region}
        */
        readonly region: string;
        /**
        * target_identifier block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkflowmonitor_scope#target_identifier AwsNetworkflowmonitorScope#target_identifier}
        */
        readonly targetIdentifier?: TargetIdentifierProperty[] | cdktn.IResolvable;
    }
    class TargetPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TargetProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TargetProperty | cdktn.IResolvable | undefined);
        private _region?;
        get region(): string;
        set region(value: string);
        get regionInput(): string | undefined;
        private _targetIdentifier;
        get targetIdentifier(): TargetIdentifierPropertyList;
        putTargetIdentifier(value: TargetIdentifierProperty[] | cdktn.IResolvable): void;
        resetTargetIdentifier(): void;
        get targetIdentifierInput(): cdktn.IResolvable | TargetIdentifierProperty[] | undefined;
    }
    class TargetPropertyList extends cdktn.ComplexList {
        internalValue?: TargetProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TargetPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkflowmonitor_scope#create AwsNetworkflowmonitorScope#create}
        */
        readonly create?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Setting a timeout for a Delete operation is only applicable if changes are saved into state before the destroy operation occurs.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkflowmonitor_scope#delete AwsNetworkflowmonitorScope#delete}
        */
        readonly delete?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkflowmonitor_scope#update AwsNetworkflowmonitorScope#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
