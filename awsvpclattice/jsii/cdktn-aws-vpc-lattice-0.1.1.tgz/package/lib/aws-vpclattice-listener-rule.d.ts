import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsVpclatticeListenerRuleConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpclattice_listener_rule#id AwsVpclatticeListenerRule#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpclattice_listener_rule#listener_identifier AwsVpclatticeListenerRule#listener_identifier}
    */
    readonly listenerIdentifier: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpclattice_listener_rule#name AwsVpclatticeListenerRule#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpclattice_listener_rule#priority AwsVpclatticeListenerRule#priority}
    */
    readonly priority: number;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpclattice_listener_rule#region AwsVpclatticeListenerRule#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpclattice_listener_rule#service_identifier AwsVpclatticeListenerRule#service_identifier}
    */
    readonly serviceIdentifier: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpclattice_listener_rule#tags AwsVpclatticeListenerRule#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpclattice_listener_rule#tags_all AwsVpclatticeListenerRule#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * action block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpclattice_listener_rule#action AwsVpclatticeListenerRule#action}
    */
    readonly action: AwsVpclatticeListenerRule.ActionProperty;
    /**
    * match block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpclattice_listener_rule#match AwsVpclatticeListenerRule#match}
    */
    readonly match: AwsVpclatticeListenerRule.MatchProperty;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpclattice_listener_rule#timeouts AwsVpclatticeListenerRule#timeouts}
    */
    readonly timeouts?: AwsVpclatticeListenerRule.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpclattice_listener_rule aws_vpclattice_listener_rule}
*/
export declare class AwsVpclatticeListenerRule extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_vpclattice_listener_rule";
    /**
    * Generates CDKTN code for importing a AwsVpclatticeListenerRule resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsVpclatticeListenerRule to import
    * @param importFromId The id of the existing AwsVpclatticeListenerRule that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpclattice_listener_rule#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsVpclatticeListenerRule to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpclattice_listener_rule aws_vpclattice_listener_rule} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsVpclatticeListenerRuleConfig
    */
    constructor(scope: Construct, id: string, config: AwsVpclatticeListenerRuleConfig);
    get arn(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _listenerIdentifier?;
    get listenerIdentifier(): string;
    set listenerIdentifier(value: string);
    get listenerIdentifierInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _priority?;
    get priority(): number;
    set priority(value: number);
    get priorityInput(): number | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get ruleId(): string;
    private _serviceIdentifier?;
    get serviceIdentifier(): string;
    set serviceIdentifier(value: string);
    get serviceIdentifierInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _action;
    get action(): AwsVpclatticeListenerRule.ActionPropertyOutputReference;
    putAction(value: AwsVpclatticeListenerRule.ActionProperty): void;
    get actionInput(): AwsVpclatticeListenerRule.ActionProperty | undefined;
    private _match;
    get match(): AwsVpclatticeListenerRule.MatchPropertyOutputReference;
    putMatch(value: AwsVpclatticeListenerRule.MatchProperty): void;
    get matchInput(): AwsVpclatticeListenerRule.MatchProperty | undefined;
    private _timeouts;
    get timeouts(): AwsVpclatticeListenerRule.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsVpclatticeListenerRule.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsVpclatticeListenerRule.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsVpclatticeListenerRuleFixedResponsePropertyToTerraform(struct?: AwsVpclatticeListenerRule.FixedResponsePropertyOutputReference | AwsVpclatticeListenerRule.FixedResponseProperty): any;
export declare function awsVpclatticeListenerRuleFixedResponsePropertyToHclTerraform(struct?: AwsVpclatticeListenerRule.FixedResponsePropertyOutputReference | AwsVpclatticeListenerRule.FixedResponseProperty): any;
export declare function awsVpclatticeListenerRuleTargetGroupsPropertyToTerraform(struct?: AwsVpclatticeListenerRule.TargetGroupsProperty | cdktn.IResolvable): any;
export declare function awsVpclatticeListenerRuleTargetGroupsPropertyToHclTerraform(struct?: AwsVpclatticeListenerRule.TargetGroupsProperty | cdktn.IResolvable): any;
export declare function awsVpclatticeListenerRuleForwardPropertyToTerraform(struct?: AwsVpclatticeListenerRule.ForwardPropertyOutputReference | AwsVpclatticeListenerRule.ForwardProperty): any;
export declare function awsVpclatticeListenerRuleForwardPropertyToHclTerraform(struct?: AwsVpclatticeListenerRule.ForwardPropertyOutputReference | AwsVpclatticeListenerRule.ForwardProperty): any;
export declare function awsVpclatticeListenerRuleActionPropertyToTerraform(struct?: AwsVpclatticeListenerRule.ActionPropertyOutputReference | AwsVpclatticeListenerRule.ActionProperty): any;
export declare function awsVpclatticeListenerRuleActionPropertyToHclTerraform(struct?: AwsVpclatticeListenerRule.ActionPropertyOutputReference | AwsVpclatticeListenerRule.ActionProperty): any;
export declare function awsVpclatticeListenerRuleMatchHttpMatchHeaderMatchesMatchPropertyToTerraform(struct?: AwsVpclatticeListenerRule.MatchHttpMatchHeaderMatchesMatchPropertyOutputReference | AwsVpclatticeListenerRule.MatchHttpMatchHeaderMatchesMatchProperty): any;
export declare function awsVpclatticeListenerRuleMatchHttpMatchHeaderMatchesMatchPropertyToHclTerraform(struct?: AwsVpclatticeListenerRule.MatchHttpMatchHeaderMatchesMatchPropertyOutputReference | AwsVpclatticeListenerRule.MatchHttpMatchHeaderMatchesMatchProperty): any;
export declare function awsVpclatticeListenerRuleHeaderMatchesPropertyToTerraform(struct?: AwsVpclatticeListenerRule.HeaderMatchesProperty | cdktn.IResolvable): any;
export declare function awsVpclatticeListenerRuleHeaderMatchesPropertyToHclTerraform(struct?: AwsVpclatticeListenerRule.HeaderMatchesProperty | cdktn.IResolvable): any;
export declare function awsVpclatticeListenerRuleMatchHttpMatchPathMatchMatchPropertyToTerraform(struct?: AwsVpclatticeListenerRule.MatchHttpMatchPathMatchMatchPropertyOutputReference | AwsVpclatticeListenerRule.MatchHttpMatchPathMatchMatchProperty): any;
export declare function awsVpclatticeListenerRuleMatchHttpMatchPathMatchMatchPropertyToHclTerraform(struct?: AwsVpclatticeListenerRule.MatchHttpMatchPathMatchMatchPropertyOutputReference | AwsVpclatticeListenerRule.MatchHttpMatchPathMatchMatchProperty): any;
export declare function awsVpclatticeListenerRulePathMatchPropertyToTerraform(struct?: AwsVpclatticeListenerRule.PathMatchPropertyOutputReference | AwsVpclatticeListenerRule.PathMatchProperty): any;
export declare function awsVpclatticeListenerRulePathMatchPropertyToHclTerraform(struct?: AwsVpclatticeListenerRule.PathMatchPropertyOutputReference | AwsVpclatticeListenerRule.PathMatchProperty): any;
export declare function awsVpclatticeListenerRuleHttpMatchPropertyToTerraform(struct?: AwsVpclatticeListenerRule.HttpMatchPropertyOutputReference | AwsVpclatticeListenerRule.HttpMatchProperty): any;
export declare function awsVpclatticeListenerRuleHttpMatchPropertyToHclTerraform(struct?: AwsVpclatticeListenerRule.HttpMatchPropertyOutputReference | AwsVpclatticeListenerRule.HttpMatchProperty): any;
export declare function awsVpclatticeListenerRuleMatchPropertyToTerraform(struct?: AwsVpclatticeListenerRule.MatchPropertyOutputReference | AwsVpclatticeListenerRule.MatchProperty): any;
export declare function awsVpclatticeListenerRuleMatchPropertyToHclTerraform(struct?: AwsVpclatticeListenerRule.MatchPropertyOutputReference | AwsVpclatticeListenerRule.MatchProperty): any;
export declare function awsVpclatticeListenerRuleTimeoutsPropertyToTerraform(struct?: AwsVpclatticeListenerRule.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsVpclatticeListenerRuleTimeoutsPropertyToHclTerraform(struct?: AwsVpclatticeListenerRule.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsVpclatticeListenerRule {
    interface FixedResponseProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpclattice_listener_rule#status_code AwsVpclatticeListenerRule#status_code}
        */
        readonly statusCode: number;
    }
    class FixedResponsePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): FixedResponseProperty | undefined;
        set internalValue(value: FixedResponseProperty | undefined);
        private _statusCode?;
        get statusCode(): number;
        set statusCode(value: number);
        get statusCodeInput(): number | undefined;
    }
    interface TargetGroupsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpclattice_listener_rule#target_group_identifier AwsVpclatticeListenerRule#target_group_identifier}
        */
        readonly targetGroupIdentifier: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpclattice_listener_rule#weight AwsVpclatticeListenerRule#weight}
        */
        readonly weight?: number;
    }
    class TargetGroupsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TargetGroupsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TargetGroupsProperty | cdktn.IResolvable | undefined);
        private _targetGroupIdentifier?;
        get targetGroupIdentifier(): string;
        set targetGroupIdentifier(value: string);
        get targetGroupIdentifierInput(): string | undefined;
        private _weight?;
        get weight(): number;
        set weight(value: number);
        resetWeight(): void;
        get weightInput(): number | undefined;
    }
    class TargetGroupsPropertyList extends cdktn.ComplexList {
        internalValue?: TargetGroupsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TargetGroupsPropertyOutputReference;
    }
    interface ForwardProperty {
        /**
        * target_groups block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpclattice_listener_rule#target_groups AwsVpclatticeListenerRule#target_groups}
        */
        readonly targetGroups: TargetGroupsProperty[] | cdktn.IResolvable;
    }
    class ForwardPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ForwardProperty | undefined;
        set internalValue(value: ForwardProperty | undefined);
        private _targetGroups;
        get targetGroups(): TargetGroupsPropertyList;
        putTargetGroups(value: TargetGroupsProperty[] | cdktn.IResolvable): void;
        get targetGroupsInput(): cdktn.IResolvable | TargetGroupsProperty[] | undefined;
    }
    interface ActionProperty {
        /**
        * fixed_response block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpclattice_listener_rule#fixed_response AwsVpclatticeListenerRule#fixed_response}
        */
        readonly fixedResponse?: FixedResponseProperty;
        /**
        * forward block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpclattice_listener_rule#forward AwsVpclatticeListenerRule#forward}
        */
        readonly forward?: ForwardProperty;
    }
    class ActionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ActionProperty | undefined;
        set internalValue(value: ActionProperty | undefined);
        private _fixedResponse;
        get fixedResponse(): FixedResponsePropertyOutputReference;
        putFixedResponse(value: FixedResponseProperty): void;
        resetFixedResponse(): void;
        get fixedResponseInput(): FixedResponseProperty | undefined;
        private _forward;
        get forward(): ForwardPropertyOutputReference;
        putForward(value: ForwardProperty): void;
        resetForward(): void;
        get forwardInput(): ForwardProperty | undefined;
    }
    interface MatchHttpMatchHeaderMatchesMatchProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpclattice_listener_rule#contains AwsVpclatticeListenerRule#contains}
        */
        readonly contains?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpclattice_listener_rule#exact AwsVpclatticeListenerRule#exact}
        */
        readonly exact?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpclattice_listener_rule#prefix AwsVpclatticeListenerRule#prefix}
        */
        readonly prefix?: string;
    }
    class MatchHttpMatchHeaderMatchesMatchPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): MatchHttpMatchHeaderMatchesMatchProperty | undefined;
        set internalValue(value: MatchHttpMatchHeaderMatchesMatchProperty | undefined);
        private _contains?;
        get contains(): string;
        set contains(value: string);
        resetContains(): void;
        get containsInput(): string | undefined;
        private _exact?;
        get exact(): string;
        set exact(value: string);
        resetExact(): void;
        get exactInput(): string | undefined;
        private _prefix?;
        get prefix(): string;
        set prefix(value: string);
        resetPrefix(): void;
        get prefixInput(): string | undefined;
    }
    interface HeaderMatchesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpclattice_listener_rule#case_sensitive AwsVpclatticeListenerRule#case_sensitive}
        */
        readonly caseSensitive?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpclattice_listener_rule#name AwsVpclatticeListenerRule#name}
        */
        readonly name: string;
        /**
        * match block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpclattice_listener_rule#match AwsVpclatticeListenerRule#match}
        */
        readonly match: MatchHttpMatchHeaderMatchesMatchProperty;
    }
    class HeaderMatchesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): HeaderMatchesProperty | cdktn.IResolvable | undefined;
        set internalValue(value: HeaderMatchesProperty | cdktn.IResolvable | undefined);
        private _caseSensitive?;
        get caseSensitive(): boolean | cdktn.IResolvable;
        set caseSensitive(value: boolean | cdktn.IResolvable);
        resetCaseSensitive(): void;
        get caseSensitiveInput(): boolean | cdktn.IResolvable | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _match;
        get match(): MatchHttpMatchHeaderMatchesMatchPropertyOutputReference;
        putMatch(value: MatchHttpMatchHeaderMatchesMatchProperty): void;
        get matchInput(): MatchHttpMatchHeaderMatchesMatchProperty | undefined;
    }
    class HeaderMatchesPropertyList extends cdktn.ComplexList {
        internalValue?: HeaderMatchesProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): HeaderMatchesPropertyOutputReference;
    }
    interface MatchHttpMatchPathMatchMatchProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpclattice_listener_rule#exact AwsVpclatticeListenerRule#exact}
        */
        readonly exact?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpclattice_listener_rule#prefix AwsVpclatticeListenerRule#prefix}
        */
        readonly prefix?: string;
    }
    class MatchHttpMatchPathMatchMatchPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): MatchHttpMatchPathMatchMatchProperty | undefined;
        set internalValue(value: MatchHttpMatchPathMatchMatchProperty | undefined);
        private _exact?;
        get exact(): string;
        set exact(value: string);
        resetExact(): void;
        get exactInput(): string | undefined;
        private _prefix?;
        get prefix(): string;
        set prefix(value: string);
        resetPrefix(): void;
        get prefixInput(): string | undefined;
    }
    interface PathMatchProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpclattice_listener_rule#case_sensitive AwsVpclatticeListenerRule#case_sensitive}
        */
        readonly caseSensitive?: boolean | cdktn.IResolvable;
        /**
        * match block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpclattice_listener_rule#match AwsVpclatticeListenerRule#match}
        */
        readonly match: MatchHttpMatchPathMatchMatchProperty;
    }
    class PathMatchPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): PathMatchProperty | undefined;
        set internalValue(value: PathMatchProperty | undefined);
        private _caseSensitive?;
        get caseSensitive(): boolean | cdktn.IResolvable;
        set caseSensitive(value: boolean | cdktn.IResolvable);
        resetCaseSensitive(): void;
        get caseSensitiveInput(): boolean | cdktn.IResolvable | undefined;
        private _match;
        get match(): MatchHttpMatchPathMatchMatchPropertyOutputReference;
        putMatch(value: MatchHttpMatchPathMatchMatchProperty): void;
        get matchInput(): MatchHttpMatchPathMatchMatchProperty | undefined;
    }
    interface HttpMatchProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpclattice_listener_rule#method AwsVpclatticeListenerRule#method}
        */
        readonly method?: string;
        /**
        * header_matches block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpclattice_listener_rule#header_matches AwsVpclatticeListenerRule#header_matches}
        */
        readonly headerMatches?: HeaderMatchesProperty[] | cdktn.IResolvable;
        /**
        * path_match block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpclattice_listener_rule#path_match AwsVpclatticeListenerRule#path_match}
        */
        readonly pathMatch?: PathMatchProperty;
    }
    class HttpMatchPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): HttpMatchProperty | undefined;
        set internalValue(value: HttpMatchProperty | undefined);
        private _method?;
        get method(): string;
        set method(value: string);
        resetMethod(): void;
        get methodInput(): string | undefined;
        private _headerMatches;
        get headerMatches(): HeaderMatchesPropertyList;
        putHeaderMatches(value: HeaderMatchesProperty[] | cdktn.IResolvable): void;
        resetHeaderMatches(): void;
        get headerMatchesInput(): cdktn.IResolvable | HeaderMatchesProperty[] | undefined;
        private _pathMatch;
        get pathMatch(): PathMatchPropertyOutputReference;
        putPathMatch(value: PathMatchProperty): void;
        resetPathMatch(): void;
        get pathMatchInput(): PathMatchProperty | undefined;
    }
    interface MatchProperty {
        /**
        * http_match block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpclattice_listener_rule#http_match AwsVpclatticeListenerRule#http_match}
        */
        readonly httpMatch: HttpMatchProperty;
    }
    class MatchPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): MatchProperty | undefined;
        set internalValue(value: MatchProperty | undefined);
        private _httpMatch;
        get httpMatch(): HttpMatchPropertyOutputReference;
        putHttpMatch(value: HttpMatchProperty): void;
        get httpMatchInput(): HttpMatchProperty | undefined;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpclattice_listener_rule#create AwsVpclatticeListenerRule#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpclattice_listener_rule#delete AwsVpclatticeListenerRule#delete}
        */
        readonly delete?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpclattice_listener_rule#update AwsVpclatticeListenerRule#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
