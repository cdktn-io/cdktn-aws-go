import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsVpclatticeTargetGroupConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpclattice_target_group#id AwsVpclatticeTargetGroup#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpclattice_target_group#name AwsVpclatticeTargetGroup#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpclattice_target_group#region AwsVpclatticeTargetGroup#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpclattice_target_group#tags AwsVpclatticeTargetGroup#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpclattice_target_group#tags_all AwsVpclatticeTargetGroup#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpclattice_target_group#type AwsVpclatticeTargetGroup#type}
    */
    readonly type: string;
    /**
    * config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpclattice_target_group#config AwsVpclatticeTargetGroup#config}
    */
    readonly config?: AwsVpclatticeTargetGroup.ConfigProperty;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpclattice_target_group#timeouts AwsVpclatticeTargetGroup#timeouts}
    */
    readonly timeouts?: AwsVpclatticeTargetGroup.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpclattice_target_group aws_vpclattice_target_group}
*/
export declare class AwsVpclatticeTargetGroup extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_vpclattice_target_group";
    /**
    * Generates CDKTN code for importing a AwsVpclatticeTargetGroup resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsVpclatticeTargetGroup to import
    * @param importFromId The id of the existing AwsVpclatticeTargetGroup that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpclattice_target_group#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsVpclatticeTargetGroup to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpclattice_target_group aws_vpclattice_target_group} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsVpclatticeTargetGroupConfig
    */
    constructor(scope: Construct, id: string, config: AwsVpclatticeTargetGroupConfig);
    get arn(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get status(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _config;
    get config(): AwsVpclatticeTargetGroup.ConfigPropertyOutputReference;
    putConfig(value: AwsVpclatticeTargetGroup.ConfigProperty): void;
    resetConfig(): void;
    get configInput(): AwsVpclatticeTargetGroup.ConfigProperty | undefined;
    private _timeouts;
    get timeouts(): AwsVpclatticeTargetGroup.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsVpclatticeTargetGroup.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsVpclatticeTargetGroup.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsVpclatticeTargetGroupMatcherPropertyToTerraform(struct?: AwsVpclatticeTargetGroup.MatcherPropertyOutputReference | AwsVpclatticeTargetGroup.MatcherProperty): any;
export declare function awsVpclatticeTargetGroupMatcherPropertyToHclTerraform(struct?: AwsVpclatticeTargetGroup.MatcherPropertyOutputReference | AwsVpclatticeTargetGroup.MatcherProperty): any;
export declare function awsVpclatticeTargetGroupHealthCheckPropertyToTerraform(struct?: AwsVpclatticeTargetGroup.HealthCheckPropertyOutputReference | AwsVpclatticeTargetGroup.HealthCheckProperty): any;
export declare function awsVpclatticeTargetGroupHealthCheckPropertyToHclTerraform(struct?: AwsVpclatticeTargetGroup.HealthCheckPropertyOutputReference | AwsVpclatticeTargetGroup.HealthCheckProperty): any;
export declare function awsVpclatticeTargetGroupConfigPropertyToTerraform(struct?: AwsVpclatticeTargetGroup.ConfigPropertyOutputReference | AwsVpclatticeTargetGroup.ConfigProperty): any;
export declare function awsVpclatticeTargetGroupConfigPropertyToHclTerraform(struct?: AwsVpclatticeTargetGroup.ConfigPropertyOutputReference | AwsVpclatticeTargetGroup.ConfigProperty): any;
export declare function awsVpclatticeTargetGroupTimeoutsPropertyToTerraform(struct?: AwsVpclatticeTargetGroup.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsVpclatticeTargetGroupTimeoutsPropertyToHclTerraform(struct?: AwsVpclatticeTargetGroup.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsVpclatticeTargetGroup {
    interface MatcherProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpclattice_target_group#value AwsVpclatticeTargetGroup#value}
        */
        readonly value?: string;
    }
    class MatcherPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): MatcherProperty | undefined;
        set internalValue(value: MatcherProperty | undefined);
        private _value?;
        get value(): string;
        set value(value: string);
        resetValue(): void;
        get valueInput(): string | undefined;
    }
    interface HealthCheckProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpclattice_target_group#enabled AwsVpclatticeTargetGroup#enabled}
        */
        readonly enabled?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpclattice_target_group#health_check_interval_seconds AwsVpclatticeTargetGroup#health_check_interval_seconds}
        */
        readonly healthCheckIntervalSeconds?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpclattice_target_group#health_check_timeout_seconds AwsVpclatticeTargetGroup#health_check_timeout_seconds}
        */
        readonly healthCheckTimeoutSeconds?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpclattice_target_group#healthy_threshold_count AwsVpclatticeTargetGroup#healthy_threshold_count}
        */
        readonly healthyThresholdCount?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpclattice_target_group#path AwsVpclatticeTargetGroup#path}
        */
        readonly path?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpclattice_target_group#port AwsVpclatticeTargetGroup#port}
        */
        readonly port?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpclattice_target_group#protocol AwsVpclatticeTargetGroup#protocol}
        */
        readonly protocol?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpclattice_target_group#protocol_version AwsVpclatticeTargetGroup#protocol_version}
        */
        readonly protocolVersion?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpclattice_target_group#unhealthy_threshold_count AwsVpclatticeTargetGroup#unhealthy_threshold_count}
        */
        readonly unhealthyThresholdCount?: number;
        /**
        * matcher block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpclattice_target_group#matcher AwsVpclatticeTargetGroup#matcher}
        */
        readonly matcher?: MatcherProperty;
    }
    class HealthCheckPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): HealthCheckProperty | undefined;
        set internalValue(value: HealthCheckProperty | undefined);
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        resetEnabled(): void;
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
        private _healthCheckIntervalSeconds?;
        get healthCheckIntervalSeconds(): number;
        set healthCheckIntervalSeconds(value: number);
        resetHealthCheckIntervalSeconds(): void;
        get healthCheckIntervalSecondsInput(): number | undefined;
        private _healthCheckTimeoutSeconds?;
        get healthCheckTimeoutSeconds(): number;
        set healthCheckTimeoutSeconds(value: number);
        resetHealthCheckTimeoutSeconds(): void;
        get healthCheckTimeoutSecondsInput(): number | undefined;
        private _healthyThresholdCount?;
        get healthyThresholdCount(): number;
        set healthyThresholdCount(value: number);
        resetHealthyThresholdCount(): void;
        get healthyThresholdCountInput(): number | undefined;
        private _path?;
        get path(): string;
        set path(value: string);
        resetPath(): void;
        get pathInput(): string | undefined;
        private _port?;
        get port(): number;
        set port(value: number);
        resetPort(): void;
        get portInput(): number | undefined;
        private _protocol?;
        get protocol(): string;
        set protocol(value: string);
        resetProtocol(): void;
        get protocolInput(): string | undefined;
        private _protocolVersion?;
        get protocolVersion(): string;
        set protocolVersion(value: string);
        resetProtocolVersion(): void;
        get protocolVersionInput(): string | undefined;
        private _unhealthyThresholdCount?;
        get unhealthyThresholdCount(): number;
        set unhealthyThresholdCount(value: number);
        resetUnhealthyThresholdCount(): void;
        get unhealthyThresholdCountInput(): number | undefined;
        private _matcher;
        get matcher(): MatcherPropertyOutputReference;
        putMatcher(value: MatcherProperty): void;
        resetMatcher(): void;
        get matcherInput(): MatcherProperty | undefined;
    }
    interface ConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpclattice_target_group#ip_address_type AwsVpclatticeTargetGroup#ip_address_type}
        */
        readonly ipAddressType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpclattice_target_group#lambda_event_structure_version AwsVpclatticeTargetGroup#lambda_event_structure_version}
        */
        readonly lambdaEventStructureVersion?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpclattice_target_group#port AwsVpclatticeTargetGroup#port}
        */
        readonly port?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpclattice_target_group#protocol AwsVpclatticeTargetGroup#protocol}
        */
        readonly protocol?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpclattice_target_group#protocol_version AwsVpclatticeTargetGroup#protocol_version}
        */
        readonly protocolVersion?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpclattice_target_group#vpc_identifier AwsVpclatticeTargetGroup#vpc_identifier}
        */
        readonly vpcIdentifier?: string;
        /**
        * health_check block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpclattice_target_group#health_check AwsVpclatticeTargetGroup#health_check}
        */
        readonly healthCheck?: HealthCheckProperty;
    }
    class ConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ConfigProperty | undefined;
        set internalValue(value: ConfigProperty | undefined);
        private _ipAddressType?;
        get ipAddressType(): string;
        set ipAddressType(value: string);
        resetIpAddressType(): void;
        get ipAddressTypeInput(): string | undefined;
        private _lambdaEventStructureVersion?;
        get lambdaEventStructureVersion(): string;
        set lambdaEventStructureVersion(value: string);
        resetLambdaEventStructureVersion(): void;
        get lambdaEventStructureVersionInput(): string | undefined;
        private _port?;
        get port(): number;
        set port(value: number);
        resetPort(): void;
        get portInput(): number | undefined;
        private _protocol?;
        get protocol(): string;
        set protocol(value: string);
        resetProtocol(): void;
        get protocolInput(): string | undefined;
        private _protocolVersion?;
        get protocolVersion(): string;
        set protocolVersion(value: string);
        resetProtocolVersion(): void;
        get protocolVersionInput(): string | undefined;
        private _vpcIdentifier?;
        get vpcIdentifier(): string;
        set vpcIdentifier(value: string);
        resetVpcIdentifier(): void;
        get vpcIdentifierInput(): string | undefined;
        private _healthCheck;
        get healthCheck(): HealthCheckPropertyOutputReference;
        putHealthCheck(value: HealthCheckProperty): void;
        resetHealthCheck(): void;
        get healthCheckInput(): HealthCheckProperty | undefined;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpclattice_target_group#create AwsVpclatticeTargetGroup#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpclattice_target_group#delete AwsVpclatticeTargetGroup#delete}
        */
        readonly delete?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpclattice_target_group#update AwsVpclatticeTargetGroup#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
