import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsVpclatticeDomainVerificationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpclattice_domain_verification#domain_name AwsVpclatticeDomainVerification#domain_name}
    */
    readonly domainName: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpclattice_domain_verification#region AwsVpclatticeDomainVerification#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpclattice_domain_verification#tags AwsVpclatticeDomainVerification#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpclattice_domain_verification aws_vpclattice_domain_verification}
*/
export declare class AwsVpclatticeDomainVerification extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_vpclattice_domain_verification";
    /**
    * Generates CDKTN code for importing a AwsVpclatticeDomainVerification resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsVpclatticeDomainVerification to import
    * @param importFromId The id of the existing AwsVpclatticeDomainVerification that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpclattice_domain_verification#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsVpclatticeDomainVerification to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpclattice_domain_verification aws_vpclattice_domain_verification} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsVpclatticeDomainVerificationConfig
    */
    constructor(scope: Construct, id: string, config: AwsVpclatticeDomainVerificationConfig);
    get arn(): string;
    get createdAt(): string;
    private _domainName?;
    get domainName(): string;
    set domainName(value: string);
    get domainNameInput(): string | undefined;
    get id(): string;
    get lastVerifiedTime(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get status(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    get txtRecordName(): string;
    get txtRecordValue(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
