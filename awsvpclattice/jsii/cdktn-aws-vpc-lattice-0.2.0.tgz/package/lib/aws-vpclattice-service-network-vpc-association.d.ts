import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfServiceNetworkVpcAssociationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpclattice_service_network_vpc_association#id TfServiceNetworkVpcAssociation#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpclattice_service_network_vpc_association#private_dns_enabled TfServiceNetworkVpcAssociation#private_dns_enabled}
    */
    readonly privateDnsEnabled?: boolean | cdktn.IResolvable;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpclattice_service_network_vpc_association#region TfServiceNetworkVpcAssociation#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpclattice_service_network_vpc_association#security_group_ids TfServiceNetworkVpcAssociation#security_group_ids}
    */
    readonly securityGroupIds?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpclattice_service_network_vpc_association#service_network_identifier TfServiceNetworkVpcAssociation#service_network_identifier}
    */
    readonly serviceNetworkIdentifier: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpclattice_service_network_vpc_association#tags TfServiceNetworkVpcAssociation#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpclattice_service_network_vpc_association#tags_all TfServiceNetworkVpcAssociation#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpclattice_service_network_vpc_association#vpc_identifier TfServiceNetworkVpcAssociation#vpc_identifier}
    */
    readonly vpcIdentifier: string;
    /**
    * dns_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpclattice_service_network_vpc_association#dns_options TfServiceNetworkVpcAssociation#dns_options}
    */
    readonly dnsOptions?: TfServiceNetworkVpcAssociation.DnsOptionsProperty;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpclattice_service_network_vpc_association#timeouts TfServiceNetworkVpcAssociation#timeouts}
    */
    readonly timeouts?: TfServiceNetworkVpcAssociation.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpclattice_service_network_vpc_association aws_vpclattice_service_network_vpc_association}
*/
export declare class TfServiceNetworkVpcAssociation extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_vpclattice_service_network_vpc_association";
    /**
    * Generates CDKTN code for importing a TfServiceNetworkVpcAssociation resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfServiceNetworkVpcAssociation to import
    * @param importFromId The id of the existing TfServiceNetworkVpcAssociation that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpclattice_service_network_vpc_association#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfServiceNetworkVpcAssociation to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpclattice_service_network_vpc_association aws_vpclattice_service_network_vpc_association} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfServiceNetworkVpcAssociationConfig
    */
    constructor(scope: Construct, id: string, config: TfServiceNetworkVpcAssociationConfig);
    get arn(): string;
    get createdBy(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _privateDnsEnabled?;
    get privateDnsEnabled(): boolean | cdktn.IResolvable;
    set privateDnsEnabled(value: boolean | cdktn.IResolvable);
    resetPrivateDnsEnabled(): void;
    get privateDnsEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _securityGroupIds?;
    get securityGroupIds(): string[];
    set securityGroupIds(value: string[]);
    resetSecurityGroupIds(): void;
    get securityGroupIdsInput(): string[] | undefined;
    private _serviceNetworkIdentifier?;
    get serviceNetworkIdentifier(): string;
    set serviceNetworkIdentifier(value: string);
    get serviceNetworkIdentifierInput(): string | undefined;
    get status(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _vpcIdentifier?;
    get vpcIdentifier(): string;
    set vpcIdentifier(value: string);
    get vpcIdentifierInput(): string | undefined;
    private _dnsOptions;
    get dnsOptions(): TfServiceNetworkVpcAssociation.DnsOptionsPropertyOutputReference;
    putDnsOptions(value: TfServiceNetworkVpcAssociation.DnsOptionsProperty): void;
    resetDnsOptions(): void;
    get dnsOptionsInput(): TfServiceNetworkVpcAssociation.DnsOptionsProperty | undefined;
    private _timeouts;
    get timeouts(): TfServiceNetworkVpcAssociation.TimeoutsPropertyOutputReference;
    putTimeouts(value: TfServiceNetworkVpcAssociation.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | TfServiceNetworkVpcAssociation.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfServiceNetworkVpcAssociationDnsOptionsPropertyToTerraform(struct?: TfServiceNetworkVpcAssociation.DnsOptionsPropertyOutputReference | TfServiceNetworkVpcAssociation.DnsOptionsProperty): any;
export declare function tfServiceNetworkVpcAssociationDnsOptionsPropertyToHclTerraform(struct?: TfServiceNetworkVpcAssociation.DnsOptionsPropertyOutputReference | TfServiceNetworkVpcAssociation.DnsOptionsProperty): any;
export declare function tfServiceNetworkVpcAssociationTimeoutsPropertyToTerraform(struct?: TfServiceNetworkVpcAssociation.TimeoutsProperty | cdktn.IResolvable): any;
export declare function tfServiceNetworkVpcAssociationTimeoutsPropertyToHclTerraform(struct?: TfServiceNetworkVpcAssociation.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace TfServiceNetworkVpcAssociation {
    interface DnsOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpclattice_service_network_vpc_association#private_dns_preference TfServiceNetworkVpcAssociation#private_dns_preference}
        */
        readonly privateDnsPreference?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpclattice_service_network_vpc_association#private_dns_specified_domains TfServiceNetworkVpcAssociation#private_dns_specified_domains}
        */
        readonly privateDnsSpecifiedDomains?: string[];
    }
    class DnsOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DnsOptionsProperty | undefined;
        set internalValue(value: DnsOptionsProperty | undefined);
        private _privateDnsPreference?;
        get privateDnsPreference(): string;
        set privateDnsPreference(value: string);
        resetPrivateDnsPreference(): void;
        get privateDnsPreferenceInput(): string | undefined;
        private _privateDnsSpecifiedDomains?;
        get privateDnsSpecifiedDomains(): string[];
        set privateDnsSpecifiedDomains(value: string[]);
        resetPrivateDnsSpecifiedDomains(): void;
        get privateDnsSpecifiedDomainsInput(): string[] | undefined;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpclattice_service_network_vpc_association#create TfServiceNetworkVpcAssociation#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpclattice_service_network_vpc_association#delete TfServiceNetworkVpcAssociation#delete}
        */
        readonly delete?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpclattice_service_network_vpc_association#update TfServiceNetworkVpcAssociation#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
