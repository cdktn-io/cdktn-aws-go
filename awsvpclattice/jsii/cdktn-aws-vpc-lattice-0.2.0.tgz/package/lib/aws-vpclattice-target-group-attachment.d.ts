import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfTargetGroupAttachmentConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpclattice_target_group_attachment#id TfTargetGroupAttachment#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpclattice_target_group_attachment#region TfTargetGroupAttachment#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpclattice_target_group_attachment#target_group_identifier TfTargetGroupAttachment#target_group_identifier}
    */
    readonly targetGroupIdentifier: string;
    /**
    * target block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpclattice_target_group_attachment#target TfTargetGroupAttachment#target}
    */
    readonly target: TfTargetGroupAttachment.TargetProperty;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpclattice_target_group_attachment#timeouts TfTargetGroupAttachment#timeouts}
    */
    readonly timeouts?: TfTargetGroupAttachment.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpclattice_target_group_attachment aws_vpclattice_target_group_attachment}
*/
export declare class TfTargetGroupAttachment extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_vpclattice_target_group_attachment";
    /**
    * Generates CDKTN code for importing a TfTargetGroupAttachment resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfTargetGroupAttachment to import
    * @param importFromId The id of the existing TfTargetGroupAttachment that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpclattice_target_group_attachment#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfTargetGroupAttachment to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpclattice_target_group_attachment aws_vpclattice_target_group_attachment} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfTargetGroupAttachmentConfig
    */
    constructor(scope: Construct, id: string, config: TfTargetGroupAttachmentConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _targetGroupIdentifier?;
    get targetGroupIdentifier(): string;
    set targetGroupIdentifier(value: string);
    get targetGroupIdentifierInput(): string | undefined;
    private _target;
    get target(): TfTargetGroupAttachment.TargetPropertyOutputReference;
    putTarget(value: TfTargetGroupAttachment.TargetProperty): void;
    get targetInput(): TfTargetGroupAttachment.TargetProperty | undefined;
    private _timeouts;
    get timeouts(): TfTargetGroupAttachment.TimeoutsPropertyOutputReference;
    putTimeouts(value: TfTargetGroupAttachment.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | TfTargetGroupAttachment.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfTargetGroupAttachmentTargetPropertyToTerraform(struct?: TfTargetGroupAttachment.TargetPropertyOutputReference | TfTargetGroupAttachment.TargetProperty): any;
export declare function tfTargetGroupAttachmentTargetPropertyToHclTerraform(struct?: TfTargetGroupAttachment.TargetPropertyOutputReference | TfTargetGroupAttachment.TargetProperty): any;
export declare function tfTargetGroupAttachmentTimeoutsPropertyToTerraform(struct?: TfTargetGroupAttachment.TimeoutsProperty | cdktn.IResolvable): any;
export declare function tfTargetGroupAttachmentTimeoutsPropertyToHclTerraform(struct?: TfTargetGroupAttachment.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace TfTargetGroupAttachment {
    interface TargetProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpclattice_target_group_attachment#id TfTargetGroupAttachment#id}
        *
        * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
        * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
        */
        readonly id: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpclattice_target_group_attachment#port TfTargetGroupAttachment#port}
        */
        readonly port?: number;
    }
    class TargetPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TargetProperty | undefined;
        set internalValue(value: TargetProperty | undefined);
        private _id?;
        get id(): string;
        set id(value: string);
        get idInput(): string | undefined;
        private _port?;
        get port(): number;
        set port(value: number);
        resetPort(): void;
        get portInput(): number | undefined;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpclattice_target_group_attachment#create TfTargetGroupAttachment#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpclattice_target_group_attachment#delete TfTargetGroupAttachment#delete}
        */
        readonly delete?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
    }
}
