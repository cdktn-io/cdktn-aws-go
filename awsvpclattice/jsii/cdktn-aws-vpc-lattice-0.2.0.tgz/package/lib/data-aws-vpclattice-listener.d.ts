import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataTfListenerConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/vpclattice_listener#id DataTfListener#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/vpclattice_listener#listener_identifier DataTfListener#listener_identifier}
    */
    readonly listenerIdentifier: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/vpclattice_listener#region DataTfListener#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/vpclattice_listener#service_identifier DataTfListener#service_identifier}
    */
    readonly serviceIdentifier: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/vpclattice_listener#tags DataTfListener#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/vpclattice_listener aws_vpclattice_listener}
*/
export declare class DataTfListener extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_vpclattice_listener";
    /**
    * Generates CDKTN code for importing a DataTfListener resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataTfListener to import
    * @param importFromId The id of the existing DataTfListener that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/vpclattice_listener#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataTfListener to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/vpclattice_listener aws_vpclattice_listener} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataTfListenerConfig
    */
    constructor(scope: Construct, id: string, config: DataTfListenerConfig);
    get arn(): string;
    get createdAt(): string;
    private _defaultAction;
    get defaultAction(): DataTfListener.DefaultActionPropertyList;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get lastUpdatedAt(): string;
    get listenerId(): string;
    private _listenerIdentifier?;
    get listenerIdentifier(): string;
    set listenerIdentifier(value: string);
    get listenerIdentifierInput(): string | undefined;
    get name(): string;
    get port(): number;
    get protocol(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get serviceArn(): string;
    get serviceId(): string;
    private _serviceIdentifier?;
    get serviceIdentifier(): string;
    set serviceIdentifier(value: string);
    get serviceIdentifierInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataTfListenerFixedResponsePropertyToTerraform(struct?: DataTfListener.FixedResponseProperty): any;
export declare function dataTfListenerFixedResponsePropertyToHclTerraform(struct?: DataTfListener.FixedResponseProperty): any;
export declare function dataTfListenerTargetGroupsPropertyToTerraform(struct?: DataTfListener.TargetGroupsProperty): any;
export declare function dataTfListenerTargetGroupsPropertyToHclTerraform(struct?: DataTfListener.TargetGroupsProperty): any;
export declare function dataTfListenerForwardPropertyToTerraform(struct?: DataTfListener.ForwardProperty): any;
export declare function dataTfListenerForwardPropertyToHclTerraform(struct?: DataTfListener.ForwardProperty): any;
export declare function dataTfListenerDefaultActionPropertyToTerraform(struct?: DataTfListener.DefaultActionProperty): any;
export declare function dataTfListenerDefaultActionPropertyToHclTerraform(struct?: DataTfListener.DefaultActionProperty): any;
export declare namespace DataTfListener {
    interface FixedResponseProperty {
    }
    class FixedResponsePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): FixedResponseProperty | undefined;
        set internalValue(value: FixedResponseProperty | undefined);
        get statusCode(): number;
    }
    class FixedResponsePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): FixedResponsePropertyOutputReference;
    }
    interface TargetGroupsProperty {
    }
    class TargetGroupsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TargetGroupsProperty | undefined;
        set internalValue(value: TargetGroupsProperty | undefined);
        get targetGroupIdentifier(): string;
        get weight(): number;
    }
    class TargetGroupsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TargetGroupsPropertyOutputReference;
    }
    interface ForwardProperty {
    }
    class ForwardPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ForwardProperty | undefined;
        set internalValue(value: ForwardProperty | undefined);
        private _targetGroups;
        get targetGroups(): TargetGroupsPropertyList;
    }
    class ForwardPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ForwardPropertyOutputReference;
    }
    interface DefaultActionProperty {
    }
    class DefaultActionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DefaultActionProperty | undefined;
        set internalValue(value: DefaultActionProperty | undefined);
        private _fixedResponse;
        get fixedResponse(): FixedResponsePropertyList;
        private _forward;
        get forward(): ForwardPropertyList;
    }
    class DefaultActionPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DefaultActionPropertyOutputReference;
    }
}
