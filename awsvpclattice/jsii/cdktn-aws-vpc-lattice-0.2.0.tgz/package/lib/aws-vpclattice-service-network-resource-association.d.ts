import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfServiceNetworkResourceAssociationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpclattice_service_network_resource_association#private_dns_enabled TfServiceNetworkResourceAssociation#private_dns_enabled}
    */
    readonly privateDnsEnabled?: boolean | cdktn.IResolvable;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpclattice_service_network_resource_association#region TfServiceNetworkResourceAssociation#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpclattice_service_network_resource_association#resource_configuration_identifier TfServiceNetworkResourceAssociation#resource_configuration_identifier}
    */
    readonly resourceConfigurationIdentifier: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpclattice_service_network_resource_association#service_network_identifier TfServiceNetworkResourceAssociation#service_network_identifier}
    */
    readonly serviceNetworkIdentifier: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpclattice_service_network_resource_association#tags TfServiceNetworkResourceAssociation#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpclattice_service_network_resource_association#timeouts TfServiceNetworkResourceAssociation#timeouts}
    */
    readonly timeouts?: TfServiceNetworkResourceAssociation.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpclattice_service_network_resource_association aws_vpclattice_service_network_resource_association}
*/
export declare class TfServiceNetworkResourceAssociation extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_vpclattice_service_network_resource_association";
    /**
    * Generates CDKTN code for importing a TfServiceNetworkResourceAssociation resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfServiceNetworkResourceAssociation to import
    * @param importFromId The id of the existing TfServiceNetworkResourceAssociation that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpclattice_service_network_resource_association#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfServiceNetworkResourceAssociation to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpclattice_service_network_resource_association aws_vpclattice_service_network_resource_association} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfServiceNetworkResourceAssociationConfig
    */
    constructor(scope: Construct, id: string, config: TfServiceNetworkResourceAssociationConfig);
    get arn(): string;
    private _dnsEntry;
    get dnsEntry(): TfServiceNetworkResourceAssociation.DnsEntryPropertyList;
    get id(): string;
    private _privateDnsEnabled?;
    get privateDnsEnabled(): boolean | cdktn.IResolvable;
    set privateDnsEnabled(value: boolean | cdktn.IResolvable);
    resetPrivateDnsEnabled(): void;
    get privateDnsEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _resourceConfigurationIdentifier?;
    get resourceConfigurationIdentifier(): string;
    set resourceConfigurationIdentifier(value: string);
    get resourceConfigurationIdentifierInput(): string | undefined;
    private _serviceNetworkIdentifier?;
    get serviceNetworkIdentifier(): string;
    set serviceNetworkIdentifier(value: string);
    get serviceNetworkIdentifierInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    private _timeouts;
    get timeouts(): TfServiceNetworkResourceAssociation.TimeoutsPropertyOutputReference;
    putTimeouts(value: TfServiceNetworkResourceAssociation.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | TfServiceNetworkResourceAssociation.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfServiceNetworkResourceAssociationDnsEntryPropertyToTerraform(struct?: TfServiceNetworkResourceAssociation.DnsEntryProperty): any;
export declare function tfServiceNetworkResourceAssociationDnsEntryPropertyToHclTerraform(struct?: TfServiceNetworkResourceAssociation.DnsEntryProperty): any;
export declare function tfServiceNetworkResourceAssociationTimeoutsPropertyToTerraform(struct?: TfServiceNetworkResourceAssociation.TimeoutsProperty | cdktn.IResolvable): any;
export declare function tfServiceNetworkResourceAssociationTimeoutsPropertyToHclTerraform(struct?: TfServiceNetworkResourceAssociation.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace TfServiceNetworkResourceAssociation {
    interface DnsEntryProperty {
    }
    class DnsEntryPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DnsEntryProperty | undefined;
        set internalValue(value: DnsEntryProperty | undefined);
        get domainName(): string;
        get hostedZoneId(): string;
    }
    class DnsEntryPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DnsEntryPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpclattice_service_network_resource_association#create TfServiceNetworkResourceAssociation#create}
        */
        readonly create?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Setting a timeout for a Delete operation is only applicable if changes are saved into state before the destroy operation occurs.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpclattice_service_network_resource_association#delete TfServiceNetworkResourceAssociation#delete}
        */
        readonly delete?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
    }
}
