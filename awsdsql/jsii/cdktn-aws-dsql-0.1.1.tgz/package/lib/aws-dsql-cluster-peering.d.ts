import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsDsqlClusterPeeringConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dsql_cluster_peering#clusters AwsDsqlClusterPeering#clusters}
    */
    readonly clusters: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dsql_cluster_peering#identifier AwsDsqlClusterPeering#identifier}
    */
    readonly identifier: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dsql_cluster_peering#region AwsDsqlClusterPeering#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dsql_cluster_peering#witness_region AwsDsqlClusterPeering#witness_region}
    */
    readonly witnessRegion: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dsql_cluster_peering#timeouts AwsDsqlClusterPeering#timeouts}
    */
    readonly timeouts?: AwsDsqlClusterPeering.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dsql_cluster_peering aws_dsql_cluster_peering}
*/
export declare class AwsDsqlClusterPeering extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_dsql_cluster_peering";
    /**
    * Generates CDKTN code for importing a AwsDsqlClusterPeering resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsDsqlClusterPeering to import
    * @param importFromId The id of the existing AwsDsqlClusterPeering that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dsql_cluster_peering#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsDsqlClusterPeering to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dsql_cluster_peering aws_dsql_cluster_peering} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsDsqlClusterPeeringConfig
    */
    constructor(scope: Construct, id: string, config: AwsDsqlClusterPeeringConfig);
    private _clusters?;
    get clusters(): string[];
    set clusters(value: string[]);
    get clustersInput(): string[] | undefined;
    private _identifier?;
    get identifier(): string;
    set identifier(value: string);
    get identifierInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _witnessRegion?;
    get witnessRegion(): string;
    set witnessRegion(value: string);
    get witnessRegionInput(): string | undefined;
    private _timeouts;
    get timeouts(): AwsDsqlClusterPeering.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsDsqlClusterPeering.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): AwsDsqlClusterPeering.TimeoutsProperty | cdktn.IResolvable | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsDsqlClusterPeeringTimeoutsPropertyToTerraform(struct?: AwsDsqlClusterPeering.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsDsqlClusterPeeringTimeoutsPropertyToHclTerraform(struct?: AwsDsqlClusterPeering.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsDsqlClusterPeering {
    interface TimeoutsProperty {
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dsql_cluster_peering#create AwsDsqlClusterPeering#create}
        */
        readonly create?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
    }
}
