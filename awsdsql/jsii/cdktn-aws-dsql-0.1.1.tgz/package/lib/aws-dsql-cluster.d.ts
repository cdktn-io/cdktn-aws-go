import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsDsqlClusterConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dsql_cluster#deletion_protection_enabled AwsDsqlCluster#deletion_protection_enabled}
    */
    readonly deletionProtectionEnabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dsql_cluster#force_destroy AwsDsqlCluster#force_destroy}
    */
    readonly forceDestroy?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dsql_cluster#kms_encryption_key AwsDsqlCluster#kms_encryption_key}
    */
    readonly kmsEncryptionKey?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dsql_cluster#region AwsDsqlCluster#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dsql_cluster#tags AwsDsqlCluster#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * multi_region_properties block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dsql_cluster#multi_region_properties AwsDsqlCluster#multi_region_properties}
    */
    readonly multiRegionProperties?: AwsDsqlCluster.MultiRegionPropertiesProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dsql_cluster#timeouts AwsDsqlCluster#timeouts}
    */
    readonly timeouts?: AwsDsqlCluster.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dsql_cluster aws_dsql_cluster}
*/
export declare class AwsDsqlCluster extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_dsql_cluster";
    /**
    * Generates CDKTN code for importing a AwsDsqlCluster resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsDsqlCluster to import
    * @param importFromId The id of the existing AwsDsqlCluster that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dsql_cluster#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsDsqlCluster to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dsql_cluster aws_dsql_cluster} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsDsqlClusterConfig = {}
    */
    constructor(scope: Construct, id: string, config?: AwsDsqlClusterConfig);
    get arn(): string;
    private _deletionProtectionEnabled?;
    get deletionProtectionEnabled(): boolean | cdktn.IResolvable;
    set deletionProtectionEnabled(value: boolean | cdktn.IResolvable);
    resetDeletionProtectionEnabled(): void;
    get deletionProtectionEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _encryptionDetails;
    get encryptionDetails(): AwsDsqlCluster.EncryptionDetailsPropertyList;
    private _forceDestroy?;
    get forceDestroy(): boolean | cdktn.IResolvable;
    set forceDestroy(value: boolean | cdktn.IResolvable);
    resetForceDestroy(): void;
    get forceDestroyInput(): boolean | cdktn.IResolvable | undefined;
    get identifier(): string;
    private _kmsEncryptionKey?;
    get kmsEncryptionKey(): string;
    set kmsEncryptionKey(value: string);
    resetKmsEncryptionKey(): void;
    get kmsEncryptionKeyInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    get vpcEndpointServiceName(): string;
    private _multiRegionProperties;
    get multiRegionProperties(): AwsDsqlCluster.MultiRegionPropertiesPropertyList;
    putMultiRegionProperties(value: AwsDsqlCluster.MultiRegionPropertiesProperty[] | cdktn.IResolvable): void;
    resetMultiRegionProperties(): void;
    get multiRegionPropertiesInput(): cdktn.IResolvable | AwsDsqlCluster.MultiRegionPropertiesProperty[] | undefined;
    private _timeouts;
    get timeouts(): AwsDsqlCluster.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsDsqlCluster.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsDsqlCluster.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsDsqlClusterEncryptionDetailsPropertyToTerraform(struct?: AwsDsqlCluster.EncryptionDetailsProperty): any;
export declare function awsDsqlClusterEncryptionDetailsPropertyToHclTerraform(struct?: AwsDsqlCluster.EncryptionDetailsProperty): any;
export declare function awsDsqlClusterMultiRegionPropertiesPropertyToTerraform(struct?: AwsDsqlCluster.MultiRegionPropertiesProperty | cdktn.IResolvable): any;
export declare function awsDsqlClusterMultiRegionPropertiesPropertyToHclTerraform(struct?: AwsDsqlCluster.MultiRegionPropertiesProperty | cdktn.IResolvable): any;
export declare function awsDsqlClusterTimeoutsPropertyToTerraform(struct?: AwsDsqlCluster.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsDsqlClusterTimeoutsPropertyToHclTerraform(struct?: AwsDsqlCluster.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsDsqlCluster {
    interface EncryptionDetailsProperty {
    }
    class EncryptionDetailsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EncryptionDetailsProperty | undefined;
        set internalValue(value: EncryptionDetailsProperty | undefined);
        get encryptionStatus(): string;
        get encryptionType(): string;
    }
    class EncryptionDetailsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EncryptionDetailsPropertyOutputReference;
    }
    interface MultiRegionPropertiesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dsql_cluster#clusters AwsDsqlCluster#clusters}
        */
        readonly clusters?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dsql_cluster#witness_region AwsDsqlCluster#witness_region}
        */
        readonly witnessRegion?: string;
    }
    class MultiRegionPropertiesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): MultiRegionPropertiesProperty | cdktn.IResolvable | undefined;
        set internalValue(value: MultiRegionPropertiesProperty | cdktn.IResolvable | undefined);
        private _clusters?;
        get clusters(): string[];
        set clusters(value: string[]);
        resetClusters(): void;
        get clustersInput(): string[] | undefined;
        private _witnessRegion?;
        get witnessRegion(): string;
        set witnessRegion(value: string);
        resetWitnessRegion(): void;
        get witnessRegionInput(): string | undefined;
    }
    class MultiRegionPropertiesPropertyList extends cdktn.ComplexList {
        internalValue?: MultiRegionPropertiesProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): MultiRegionPropertiesPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dsql_cluster#create AwsDsqlCluster#create}
        */
        readonly create?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Setting a timeout for a Delete operation is only applicable if changes are saved into state before the destroy operation occurs.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dsql_cluster#delete AwsDsqlCluster#delete}
        */
        readonly delete?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dsql_cluster#update AwsDsqlCluster#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
