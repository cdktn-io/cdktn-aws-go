import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfClusterPeeringConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dsql_cluster_peering#clusters TfClusterPeering#clusters}
    */
    readonly clusters: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dsql_cluster_peering#identifier TfClusterPeering#identifier}
    */
    readonly identifier: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dsql_cluster_peering#region TfClusterPeering#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dsql_cluster_peering#witness_region TfClusterPeering#witness_region}
    */
    readonly witnessRegion: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dsql_cluster_peering#timeouts TfClusterPeering#timeouts}
    */
    readonly timeouts?: TfClusterPeering.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dsql_cluster_peering aws_dsql_cluster_peering}
*/
export declare class TfClusterPeering extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_dsql_cluster_peering";
    /**
    * Generates CDKTN code for importing a TfClusterPeering resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfClusterPeering to import
    * @param importFromId The id of the existing TfClusterPeering that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dsql_cluster_peering#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfClusterPeering to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dsql_cluster_peering aws_dsql_cluster_peering} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfClusterPeeringConfig
    */
    constructor(scope: Construct, id: string, config: TfClusterPeeringConfig);
    private _clusters?;
    get clusters(): string[];
    set clusters(value: string[]);
    get clustersInput(): string[] | undefined;
    private _identifier?;
    get identifier(): string;
    set identifier(value: string);
    get identifierInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _witnessRegion?;
    get witnessRegion(): string;
    set witnessRegion(value: string);
    get witnessRegionInput(): string | undefined;
    private _timeouts;
    get timeouts(): TfClusterPeering.TimeoutsPropertyOutputReference;
    putTimeouts(value: TfClusterPeering.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): TfClusterPeering.TimeoutsProperty | cdktn.IResolvable | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfClusterPeeringTimeoutsPropertyToTerraform(struct?: TfClusterPeering.TimeoutsProperty | cdktn.IResolvable): any;
export declare function tfClusterPeeringTimeoutsPropertyToHclTerraform(struct?: TfClusterPeering.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace TfClusterPeering {
    interface TimeoutsProperty {
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dsql_cluster_peering#create TfClusterPeering#create}
        */
        readonly create?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
    }
}
