import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataTfInfrastructureConfigurationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/imagebuilder_infrastructure_configuration#arn DataTfInfrastructureConfiguration#arn}
    */
    readonly arn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/imagebuilder_infrastructure_configuration#id DataTfInfrastructureConfiguration#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/imagebuilder_infrastructure_configuration#region DataTfInfrastructureConfiguration#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/imagebuilder_infrastructure_configuration#resource_tags DataTfInfrastructureConfiguration#resource_tags}
    */
    readonly resourceTags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/imagebuilder_infrastructure_configuration#tags DataTfInfrastructureConfiguration#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/imagebuilder_infrastructure_configuration aws_imagebuilder_infrastructure_configuration}
*/
export declare class DataTfInfrastructureConfiguration extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_imagebuilder_infrastructure_configuration";
    /**
    * Generates CDKTN code for importing a DataTfInfrastructureConfiguration resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataTfInfrastructureConfiguration to import
    * @param importFromId The id of the existing DataTfInfrastructureConfiguration that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/imagebuilder_infrastructure_configuration#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataTfInfrastructureConfiguration to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/imagebuilder_infrastructure_configuration aws_imagebuilder_infrastructure_configuration} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataTfInfrastructureConfigurationConfig
    */
    constructor(scope: Construct, id: string, config: DataTfInfrastructureConfigurationConfig);
    private _arn?;
    get arn(): string;
    set arn(value: string);
    get arnInput(): string | undefined;
    get dateCreated(): string;
    get dateUpdated(): string;
    get description(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _instanceMetadataOptions;
    get instanceMetadataOptions(): DataTfInfrastructureConfiguration.InstanceMetadataOptionsPropertyList;
    get instanceProfileName(): string;
    get instanceTypes(): string[];
    get keyPair(): string;
    private _logging;
    get logging(): DataTfInfrastructureConfiguration.LoggingPropertyList;
    get name(): string;
    private _placement;
    get placement(): DataTfInfrastructureConfiguration.PlacementPropertyList;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _resourceTags?;
    get resourceTags(): {
        [key: string]: string;
    };
    set resourceTags(value: {
        [key: string]: string;
    });
    resetResourceTags(): void;
    get resourceTagsInput(): {
        [key: string]: string;
    } | undefined;
    get securityGroupIds(): string[];
    get snsTopicArn(): string;
    get subnetId(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    get terminateInstanceOnFailure(): cdktn.IResolvable;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataTfInfrastructureConfigurationInstanceMetadataOptionsPropertyToTerraform(struct?: DataTfInfrastructureConfiguration.InstanceMetadataOptionsProperty): any;
export declare function dataTfInfrastructureConfigurationInstanceMetadataOptionsPropertyToHclTerraform(struct?: DataTfInfrastructureConfiguration.InstanceMetadataOptionsProperty): any;
export declare function dataTfInfrastructureConfigurationS3LogsPropertyToTerraform(struct?: DataTfInfrastructureConfiguration.S3LogsProperty): any;
export declare function dataTfInfrastructureConfigurationS3LogsPropertyToHclTerraform(struct?: DataTfInfrastructureConfiguration.S3LogsProperty): any;
export declare function dataTfInfrastructureConfigurationLoggingPropertyToTerraform(struct?: DataTfInfrastructureConfiguration.LoggingProperty): any;
export declare function dataTfInfrastructureConfigurationLoggingPropertyToHclTerraform(struct?: DataTfInfrastructureConfiguration.LoggingProperty): any;
export declare function dataTfInfrastructureConfigurationPlacementPropertyToTerraform(struct?: DataTfInfrastructureConfiguration.PlacementProperty): any;
export declare function dataTfInfrastructureConfigurationPlacementPropertyToHclTerraform(struct?: DataTfInfrastructureConfiguration.PlacementProperty): any;
export declare namespace DataTfInfrastructureConfiguration {
    interface InstanceMetadataOptionsProperty {
    }
    class InstanceMetadataOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): InstanceMetadataOptionsProperty | undefined;
        set internalValue(value: InstanceMetadataOptionsProperty | undefined);
        get httpPutResponseHopLimit(): number;
        get httpTokens(): string;
    }
    class InstanceMetadataOptionsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): InstanceMetadataOptionsPropertyOutputReference;
    }
    interface S3LogsProperty {
    }
    class S3LogsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): S3LogsProperty | undefined;
        set internalValue(value: S3LogsProperty | undefined);
        get s3BucketName(): string;
        get s3KeyPrefix(): string;
    }
    class S3LogsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): S3LogsPropertyOutputReference;
    }
    interface LoggingProperty {
    }
    class LoggingPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): LoggingProperty | undefined;
        set internalValue(value: LoggingProperty | undefined);
        private _s3Logs;
        get s3Logs(): S3LogsPropertyList;
    }
    class LoggingPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): LoggingPropertyOutputReference;
    }
    interface PlacementProperty {
    }
    class PlacementPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): PlacementProperty | undefined;
        set internalValue(value: PlacementProperty | undefined);
        get availabilityZone(): string;
        get hostId(): string;
        get hostResourceGroupArn(): string;
        get tenancy(): string;
    }
    class PlacementPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): PlacementPropertyOutputReference;
    }
}
