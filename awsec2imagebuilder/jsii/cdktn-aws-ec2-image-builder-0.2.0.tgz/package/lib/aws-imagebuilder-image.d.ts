import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfImageConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_image#container_recipe_arn TfImage#container_recipe_arn}
    */
    readonly containerRecipeArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_image#distribution_configuration_arn TfImage#distribution_configuration_arn}
    */
    readonly distributionConfigurationArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_image#enhanced_image_metadata_enabled TfImage#enhanced_image_metadata_enabled}
    */
    readonly enhancedImageMetadataEnabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_image#execution_role TfImage#execution_role}
    */
    readonly executionRole?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_image#id TfImage#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_image#image_recipe_arn TfImage#image_recipe_arn}
    */
    readonly imageRecipeArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_image#infrastructure_configuration_arn TfImage#infrastructure_configuration_arn}
    */
    readonly infrastructureConfigurationArn: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_image#region TfImage#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_image#tags TfImage#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_image#tags_all TfImage#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * image_scanning_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_image#image_scanning_configuration TfImage#image_scanning_configuration}
    */
    readonly imageScanningConfiguration?: TfImage.ImageScanningConfigurationProperty;
    /**
    * image_tests_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_image#image_tests_configuration TfImage#image_tests_configuration}
    */
    readonly imageTestsConfiguration?: TfImage.ImageTestsConfigurationProperty;
    /**
    * logging_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_image#logging_configuration TfImage#logging_configuration}
    */
    readonly loggingConfiguration?: TfImage.LoggingConfigurationProperty;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_image#timeouts TfImage#timeouts}
    */
    readonly timeouts?: TfImage.TimeoutsProperty;
    /**
    * workflow block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_image#workflow TfImage#workflow}
    */
    readonly workflow?: TfImage.WorkflowProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_image aws_imagebuilder_image}
*/
export declare class TfImage extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_imagebuilder_image";
    /**
    * Generates CDKTN code for importing a TfImage resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfImage to import
    * @param importFromId The id of the existing TfImage that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_image#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfImage to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_image aws_imagebuilder_image} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfImageConfig
    */
    constructor(scope: Construct, id: string, config: TfImageConfig);
    get arn(): string;
    private _containerRecipeArn?;
    get containerRecipeArn(): string;
    set containerRecipeArn(value: string);
    resetContainerRecipeArn(): void;
    get containerRecipeArnInput(): string | undefined;
    get dateCreated(): string;
    private _distributionConfigurationArn?;
    get distributionConfigurationArn(): string;
    set distributionConfigurationArn(value: string);
    resetDistributionConfigurationArn(): void;
    get distributionConfigurationArnInput(): string | undefined;
    private _enhancedImageMetadataEnabled?;
    get enhancedImageMetadataEnabled(): boolean | cdktn.IResolvable;
    set enhancedImageMetadataEnabled(value: boolean | cdktn.IResolvable);
    resetEnhancedImageMetadataEnabled(): void;
    get enhancedImageMetadataEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _executionRole?;
    get executionRole(): string;
    set executionRole(value: string);
    resetExecutionRole(): void;
    get executionRoleInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _imageRecipeArn?;
    get imageRecipeArn(): string;
    set imageRecipeArn(value: string);
    resetImageRecipeArn(): void;
    get imageRecipeArnInput(): string | undefined;
    private _infrastructureConfigurationArn?;
    get infrastructureConfigurationArn(): string;
    set infrastructureConfigurationArn(value: string);
    get infrastructureConfigurationArnInput(): string | undefined;
    get name(): string;
    get osVersion(): string;
    private _outputResources;
    get outputResources(): TfImage.OutputResourcesPropertyList;
    get platform(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    get version(): string;
    private _imageScanningConfiguration;
    get imageScanningConfiguration(): TfImage.ImageScanningConfigurationPropertyOutputReference;
    putImageScanningConfiguration(value: TfImage.ImageScanningConfigurationProperty): void;
    resetImageScanningConfiguration(): void;
    get imageScanningConfigurationInput(): TfImage.ImageScanningConfigurationProperty | undefined;
    private _imageTestsConfiguration;
    get imageTestsConfiguration(): TfImage.ImageTestsConfigurationPropertyOutputReference;
    putImageTestsConfiguration(value: TfImage.ImageTestsConfigurationProperty): void;
    resetImageTestsConfiguration(): void;
    get imageTestsConfigurationInput(): TfImage.ImageTestsConfigurationProperty | undefined;
    private _loggingConfiguration;
    get loggingConfiguration(): TfImage.LoggingConfigurationPropertyOutputReference;
    putLoggingConfiguration(value: TfImage.LoggingConfigurationProperty): void;
    resetLoggingConfiguration(): void;
    get loggingConfigurationInput(): TfImage.LoggingConfigurationProperty | undefined;
    private _timeouts;
    get timeouts(): TfImage.TimeoutsPropertyOutputReference;
    putTimeouts(value: TfImage.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | TfImage.TimeoutsProperty | undefined;
    private _workflow;
    get workflow(): TfImage.WorkflowPropertyList;
    putWorkflow(value: TfImage.WorkflowProperty[] | cdktn.IResolvable): void;
    resetWorkflow(): void;
    get workflowInput(): cdktn.IResolvable | TfImage.WorkflowProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfImageAmisPropertyToTerraform(struct?: TfImage.AmisProperty): any;
export declare function tfImageAmisPropertyToHclTerraform(struct?: TfImage.AmisProperty): any;
export declare function tfImageContainersPropertyToTerraform(struct?: TfImage.ContainersProperty): any;
export declare function tfImageContainersPropertyToHclTerraform(struct?: TfImage.ContainersProperty): any;
export declare function tfImageOutputResourcesPropertyToTerraform(struct?: TfImage.OutputResourcesProperty): any;
export declare function tfImageOutputResourcesPropertyToHclTerraform(struct?: TfImage.OutputResourcesProperty): any;
export declare function tfImageEcrConfigurationPropertyToTerraform(struct?: TfImage.EcrConfigurationPropertyOutputReference | TfImage.EcrConfigurationProperty): any;
export declare function tfImageEcrConfigurationPropertyToHclTerraform(struct?: TfImage.EcrConfigurationPropertyOutputReference | TfImage.EcrConfigurationProperty): any;
export declare function tfImageImageScanningConfigurationPropertyToTerraform(struct?: TfImage.ImageScanningConfigurationPropertyOutputReference | TfImage.ImageScanningConfigurationProperty): any;
export declare function tfImageImageScanningConfigurationPropertyToHclTerraform(struct?: TfImage.ImageScanningConfigurationPropertyOutputReference | TfImage.ImageScanningConfigurationProperty): any;
export declare function tfImageImageTestsConfigurationPropertyToTerraform(struct?: TfImage.ImageTestsConfigurationPropertyOutputReference | TfImage.ImageTestsConfigurationProperty): any;
export declare function tfImageImageTestsConfigurationPropertyToHclTerraform(struct?: TfImage.ImageTestsConfigurationPropertyOutputReference | TfImage.ImageTestsConfigurationProperty): any;
export declare function tfImageLoggingConfigurationPropertyToTerraform(struct?: TfImage.LoggingConfigurationPropertyOutputReference | TfImage.LoggingConfigurationProperty): any;
export declare function tfImageLoggingConfigurationPropertyToHclTerraform(struct?: TfImage.LoggingConfigurationPropertyOutputReference | TfImage.LoggingConfigurationProperty): any;
export declare function tfImageTimeoutsPropertyToTerraform(struct?: TfImage.TimeoutsProperty | cdktn.IResolvable): any;
export declare function tfImageTimeoutsPropertyToHclTerraform(struct?: TfImage.TimeoutsProperty | cdktn.IResolvable): any;
export declare function tfImageParameterPropertyToTerraform(struct?: TfImage.ParameterProperty | cdktn.IResolvable): any;
export declare function tfImageParameterPropertyToHclTerraform(struct?: TfImage.ParameterProperty | cdktn.IResolvable): any;
export declare function tfImageWorkflowPropertyToTerraform(struct?: TfImage.WorkflowProperty | cdktn.IResolvable): any;
export declare function tfImageWorkflowPropertyToHclTerraform(struct?: TfImage.WorkflowProperty | cdktn.IResolvable): any;
export declare namespace TfImage {
    interface AmisProperty {
    }
    class AmisPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AmisProperty | undefined;
        set internalValue(value: AmisProperty | undefined);
        get accountId(): string;
        get description(): string;
        get image(): string;
        get name(): string;
        get region(): string;
    }
    class AmisPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AmisPropertyOutputReference;
    }
    interface ContainersProperty {
    }
    class ContainersPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ContainersProperty | undefined;
        set internalValue(value: ContainersProperty | undefined);
        get imageUris(): string[];
        get region(): string;
    }
    class ContainersPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ContainersPropertyOutputReference;
    }
    interface OutputResourcesProperty {
    }
    class OutputResourcesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): OutputResourcesProperty | undefined;
        set internalValue(value: OutputResourcesProperty | undefined);
        private _amis;
        get amis(): AmisPropertyList;
        private _containers;
        get containers(): ContainersPropertyList;
    }
    class OutputResourcesPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): OutputResourcesPropertyOutputReference;
    }
    interface EcrConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_image#container_tags TfImage#container_tags}
        */
        readonly containerTags?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_image#repository_name TfImage#repository_name}
        */
        readonly repositoryName?: string;
    }
    class EcrConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): EcrConfigurationProperty | undefined;
        set internalValue(value: EcrConfigurationProperty | undefined);
        private _containerTags?;
        get containerTags(): string[];
        set containerTags(value: string[]);
        resetContainerTags(): void;
        get containerTagsInput(): string[] | undefined;
        private _repositoryName?;
        get repositoryName(): string;
        set repositoryName(value: string);
        resetRepositoryName(): void;
        get repositoryNameInput(): string | undefined;
    }
    interface ImageScanningConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_image#image_scanning_enabled TfImage#image_scanning_enabled}
        */
        readonly imageScanningEnabled?: boolean | cdktn.IResolvable;
        /**
        * ecr_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_image#ecr_configuration TfImage#ecr_configuration}
        */
        readonly ecrConfiguration?: EcrConfigurationProperty;
    }
    class ImageScanningConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ImageScanningConfigurationProperty | undefined;
        set internalValue(value: ImageScanningConfigurationProperty | undefined);
        private _imageScanningEnabled?;
        get imageScanningEnabled(): boolean | cdktn.IResolvable;
        set imageScanningEnabled(value: boolean | cdktn.IResolvable);
        resetImageScanningEnabled(): void;
        get imageScanningEnabledInput(): boolean | cdktn.IResolvable | undefined;
        private _ecrConfiguration;
        get ecrConfiguration(): EcrConfigurationPropertyOutputReference;
        putEcrConfiguration(value: EcrConfigurationProperty): void;
        resetEcrConfiguration(): void;
        get ecrConfigurationInput(): EcrConfigurationProperty | undefined;
    }
    interface ImageTestsConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_image#image_tests_enabled TfImage#image_tests_enabled}
        */
        readonly imageTestsEnabled?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_image#timeout_minutes TfImage#timeout_minutes}
        */
        readonly timeoutMinutes?: number;
    }
    class ImageTestsConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ImageTestsConfigurationProperty | undefined;
        set internalValue(value: ImageTestsConfigurationProperty | undefined);
        private _imageTestsEnabled?;
        get imageTestsEnabled(): boolean | cdktn.IResolvable;
        set imageTestsEnabled(value: boolean | cdktn.IResolvable);
        resetImageTestsEnabled(): void;
        get imageTestsEnabledInput(): boolean | cdktn.IResolvable | undefined;
        private _timeoutMinutes?;
        get timeoutMinutes(): number;
        set timeoutMinutes(value: number);
        resetTimeoutMinutes(): void;
        get timeoutMinutesInput(): number | undefined;
    }
    interface LoggingConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_image#log_group_name TfImage#log_group_name}
        */
        readonly logGroupName: string;
    }
    class LoggingConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): LoggingConfigurationProperty | undefined;
        set internalValue(value: LoggingConfigurationProperty | undefined);
        private _logGroupName?;
        get logGroupName(): string;
        set logGroupName(value: string);
        get logGroupNameInput(): string | undefined;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_image#create TfImage#create}
        */
        readonly create?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
    }
    interface ParameterProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_image#name TfImage#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_image#value TfImage#value}
        */
        readonly value: string;
    }
    class ParameterPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ParameterProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ParameterProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class ParameterPropertyList extends cdktn.ComplexList {
        internalValue?: ParameterProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ParameterPropertyOutputReference;
    }
    interface WorkflowProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_image#on_failure TfImage#on_failure}
        */
        readonly onFailure?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_image#parallel_group TfImage#parallel_group}
        */
        readonly parallelGroup?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_image#workflow_arn TfImage#workflow_arn}
        */
        readonly workflowArn: string;
        /**
        * parameter block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_image#parameter TfImage#parameter}
        */
        readonly parameter?: ParameterProperty[] | cdktn.IResolvable;
    }
    class WorkflowPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowProperty | cdktn.IResolvable | undefined);
        private _onFailure?;
        get onFailure(): string;
        set onFailure(value: string);
        resetOnFailure(): void;
        get onFailureInput(): string | undefined;
        private _parallelGroup?;
        get parallelGroup(): string;
        set parallelGroup(value: string);
        resetParallelGroup(): void;
        get parallelGroupInput(): string | undefined;
        private _workflowArn?;
        get workflowArn(): string;
        set workflowArn(value: string);
        get workflowArnInput(): string | undefined;
        private _parameter;
        get parameter(): ParameterPropertyList;
        putParameter(value: ParameterProperty[] | cdktn.IResolvable): void;
        resetParameter(): void;
        get parameterInput(): cdktn.IResolvable | ParameterProperty[] | undefined;
    }
    class WorkflowPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowPropertyOutputReference;
    }
}
