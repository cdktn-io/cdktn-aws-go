import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsImagebuilderImageConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/imagebuilder_image#arn DataAwsImagebuilderImage#arn}
    */
    readonly arn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/imagebuilder_image#id DataAwsImagebuilderImage#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/imagebuilder_image#region DataAwsImagebuilderImage#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/imagebuilder_image#tags DataAwsImagebuilderImage#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/imagebuilder_image aws_imagebuilder_image}
*/
export declare class DataAwsImagebuilderImage extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_imagebuilder_image";
    /**
    * Generates CDKTN code for importing a DataAwsImagebuilderImage resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsImagebuilderImage to import
    * @param importFromId The id of the existing DataAwsImagebuilderImage that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/imagebuilder_image#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsImagebuilderImage to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/imagebuilder_image aws_imagebuilder_image} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsImagebuilderImageConfig
    */
    constructor(scope: Construct, id: string, config: DataAwsImagebuilderImageConfig);
    private _arn?;
    get arn(): string;
    set arn(value: string);
    get arnInput(): string | undefined;
    get buildVersionArn(): string;
    get containerRecipeArn(): string;
    get dateCreated(): string;
    get distributionConfigurationArn(): string;
    get enhancedImageMetadataEnabled(): cdktn.IResolvable;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get imageRecipeArn(): string;
    private _imageScanningConfiguration;
    get imageScanningConfiguration(): DataAwsImagebuilderImage.ImageScanningConfigurationPropertyList;
    private _imageTestsConfiguration;
    get imageTestsConfiguration(): DataAwsImagebuilderImage.ImageTestsConfigurationPropertyList;
    get infrastructureConfigurationArn(): string;
    get name(): string;
    get osVersion(): string;
    private _outputResources;
    get outputResources(): DataAwsImagebuilderImage.OutputResourcesPropertyList;
    get platform(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    get version(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataAwsImagebuilderImageEcrConfigurationPropertyToTerraform(struct?: DataAwsImagebuilderImage.EcrConfigurationProperty): any;
export declare function dataAwsImagebuilderImageEcrConfigurationPropertyToHclTerraform(struct?: DataAwsImagebuilderImage.EcrConfigurationProperty): any;
export declare function dataAwsImagebuilderImageImageScanningConfigurationPropertyToTerraform(struct?: DataAwsImagebuilderImage.ImageScanningConfigurationProperty): any;
export declare function dataAwsImagebuilderImageImageScanningConfigurationPropertyToHclTerraform(struct?: DataAwsImagebuilderImage.ImageScanningConfigurationProperty): any;
export declare function dataAwsImagebuilderImageImageTestsConfigurationPropertyToTerraform(struct?: DataAwsImagebuilderImage.ImageTestsConfigurationProperty): any;
export declare function dataAwsImagebuilderImageImageTestsConfigurationPropertyToHclTerraform(struct?: DataAwsImagebuilderImage.ImageTestsConfigurationProperty): any;
export declare function dataAwsImagebuilderImageAmisPropertyToTerraform(struct?: DataAwsImagebuilderImage.AmisProperty): any;
export declare function dataAwsImagebuilderImageAmisPropertyToHclTerraform(struct?: DataAwsImagebuilderImage.AmisProperty): any;
export declare function dataAwsImagebuilderImageContainersPropertyToTerraform(struct?: DataAwsImagebuilderImage.ContainersProperty): any;
export declare function dataAwsImagebuilderImageContainersPropertyToHclTerraform(struct?: DataAwsImagebuilderImage.ContainersProperty): any;
export declare function dataAwsImagebuilderImageOutputResourcesPropertyToTerraform(struct?: DataAwsImagebuilderImage.OutputResourcesProperty): any;
export declare function dataAwsImagebuilderImageOutputResourcesPropertyToHclTerraform(struct?: DataAwsImagebuilderImage.OutputResourcesProperty): any;
export declare namespace DataAwsImagebuilderImage {
    interface EcrConfigurationProperty {
    }
    class EcrConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EcrConfigurationProperty | undefined;
        set internalValue(value: EcrConfigurationProperty | undefined);
        get containerTags(): string[];
        get repositoryName(): string;
    }
    class EcrConfigurationPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EcrConfigurationPropertyOutputReference;
    }
    interface ImageScanningConfigurationProperty {
    }
    class ImageScanningConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ImageScanningConfigurationProperty | undefined;
        set internalValue(value: ImageScanningConfigurationProperty | undefined);
        private _ecrConfiguration;
        get ecrConfiguration(): EcrConfigurationPropertyList;
        get imageScanningEnabled(): cdktn.IResolvable;
    }
    class ImageScanningConfigurationPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ImageScanningConfigurationPropertyOutputReference;
    }
    interface ImageTestsConfigurationProperty {
    }
    class ImageTestsConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ImageTestsConfigurationProperty | undefined;
        set internalValue(value: ImageTestsConfigurationProperty | undefined);
        get imageTestsEnabled(): cdktn.IResolvable;
        get timeoutMinutes(): number;
    }
    class ImageTestsConfigurationPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ImageTestsConfigurationPropertyOutputReference;
    }
    interface AmisProperty {
    }
    class AmisPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AmisProperty | undefined;
        set internalValue(value: AmisProperty | undefined);
        get accountId(): string;
        get description(): string;
        get image(): string;
        get name(): string;
        get region(): string;
    }
    class AmisPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AmisPropertyOutputReference;
    }
    interface ContainersProperty {
    }
    class ContainersPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ContainersProperty | undefined;
        set internalValue(value: ContainersProperty | undefined);
        get imageUris(): string[];
        get region(): string;
    }
    class ContainersPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ContainersPropertyOutputReference;
    }
    interface OutputResourcesProperty {
    }
    class OutputResourcesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): OutputResourcesProperty | undefined;
        set internalValue(value: OutputResourcesProperty | undefined);
        private _amis;
        get amis(): AmisPropertyList;
        private _containers;
        get containers(): ContainersPropertyList;
    }
    class OutputResourcesPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): OutputResourcesPropertyOutputReference;
    }
}
