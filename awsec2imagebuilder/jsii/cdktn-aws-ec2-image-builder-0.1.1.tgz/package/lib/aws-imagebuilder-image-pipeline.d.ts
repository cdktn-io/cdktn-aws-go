import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsImagebuilderImagePipelineConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_image_pipeline#container_recipe_arn AwsImagebuilderImagePipeline#container_recipe_arn}
    */
    readonly containerRecipeArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_image_pipeline#description AwsImagebuilderImagePipeline#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_image_pipeline#distribution_configuration_arn AwsImagebuilderImagePipeline#distribution_configuration_arn}
    */
    readonly distributionConfigurationArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_image_pipeline#enhanced_image_metadata_enabled AwsImagebuilderImagePipeline#enhanced_image_metadata_enabled}
    */
    readonly enhancedImageMetadataEnabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_image_pipeline#execution_role AwsImagebuilderImagePipeline#execution_role}
    */
    readonly executionRole?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_image_pipeline#id AwsImagebuilderImagePipeline#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_image_pipeline#image_recipe_arn AwsImagebuilderImagePipeline#image_recipe_arn}
    */
    readonly imageRecipeArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_image_pipeline#infrastructure_configuration_arn AwsImagebuilderImagePipeline#infrastructure_configuration_arn}
    */
    readonly infrastructureConfigurationArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_image_pipeline#name AwsImagebuilderImagePipeline#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_image_pipeline#region AwsImagebuilderImagePipeline#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_image_pipeline#status AwsImagebuilderImagePipeline#status}
    */
    readonly status?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_image_pipeline#tags AwsImagebuilderImagePipeline#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_image_pipeline#tags_all AwsImagebuilderImagePipeline#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * image_scanning_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_image_pipeline#image_scanning_configuration AwsImagebuilderImagePipeline#image_scanning_configuration}
    */
    readonly imageScanningConfiguration?: AwsImagebuilderImagePipeline.ImageScanningConfigurationProperty;
    /**
    * image_tests_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_image_pipeline#image_tests_configuration AwsImagebuilderImagePipeline#image_tests_configuration}
    */
    readonly imageTestsConfiguration?: AwsImagebuilderImagePipeline.ImageTestsConfigurationProperty;
    /**
    * logging_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_image_pipeline#logging_configuration AwsImagebuilderImagePipeline#logging_configuration}
    */
    readonly loggingConfiguration?: AwsImagebuilderImagePipeline.LoggingConfigurationProperty;
    /**
    * schedule block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_image_pipeline#schedule AwsImagebuilderImagePipeline#schedule}
    */
    readonly schedule?: AwsImagebuilderImagePipeline.ScheduleProperty;
    /**
    * workflow block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_image_pipeline#workflow AwsImagebuilderImagePipeline#workflow}
    */
    readonly workflow?: AwsImagebuilderImagePipeline.WorkflowProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_image_pipeline aws_imagebuilder_image_pipeline}
*/
export declare class AwsImagebuilderImagePipeline extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_imagebuilder_image_pipeline";
    /**
    * Generates CDKTN code for importing a AwsImagebuilderImagePipeline resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsImagebuilderImagePipeline to import
    * @param importFromId The id of the existing AwsImagebuilderImagePipeline that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_image_pipeline#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsImagebuilderImagePipeline to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_image_pipeline aws_imagebuilder_image_pipeline} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsImagebuilderImagePipelineConfig
    */
    constructor(scope: Construct, id: string, config: AwsImagebuilderImagePipelineConfig);
    get arn(): string;
    private _containerRecipeArn?;
    get containerRecipeArn(): string;
    set containerRecipeArn(value: string);
    resetContainerRecipeArn(): void;
    get containerRecipeArnInput(): string | undefined;
    get dateCreated(): string;
    get dateLastRun(): string;
    get dateNextRun(): string;
    get dateUpdated(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _distributionConfigurationArn?;
    get distributionConfigurationArn(): string;
    set distributionConfigurationArn(value: string);
    resetDistributionConfigurationArn(): void;
    get distributionConfigurationArnInput(): string | undefined;
    private _enhancedImageMetadataEnabled?;
    get enhancedImageMetadataEnabled(): boolean | cdktn.IResolvable;
    set enhancedImageMetadataEnabled(value: boolean | cdktn.IResolvable);
    resetEnhancedImageMetadataEnabled(): void;
    get enhancedImageMetadataEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _executionRole?;
    get executionRole(): string;
    set executionRole(value: string);
    resetExecutionRole(): void;
    get executionRoleInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _imageRecipeArn?;
    get imageRecipeArn(): string;
    set imageRecipeArn(value: string);
    resetImageRecipeArn(): void;
    get imageRecipeArnInput(): string | undefined;
    private _infrastructureConfigurationArn?;
    get infrastructureConfigurationArn(): string;
    set infrastructureConfigurationArn(value: string);
    get infrastructureConfigurationArnInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get platform(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _status?;
    get status(): string;
    set status(value: string);
    resetStatus(): void;
    get statusInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _imageScanningConfiguration;
    get imageScanningConfiguration(): AwsImagebuilderImagePipeline.ImageScanningConfigurationPropertyOutputReference;
    putImageScanningConfiguration(value: AwsImagebuilderImagePipeline.ImageScanningConfigurationProperty): void;
    resetImageScanningConfiguration(): void;
    get imageScanningConfigurationInput(): AwsImagebuilderImagePipeline.ImageScanningConfigurationProperty | undefined;
    private _imageTestsConfiguration;
    get imageTestsConfiguration(): AwsImagebuilderImagePipeline.ImageTestsConfigurationPropertyOutputReference;
    putImageTestsConfiguration(value: AwsImagebuilderImagePipeline.ImageTestsConfigurationProperty): void;
    resetImageTestsConfiguration(): void;
    get imageTestsConfigurationInput(): AwsImagebuilderImagePipeline.ImageTestsConfigurationProperty | undefined;
    private _loggingConfiguration;
    get loggingConfiguration(): AwsImagebuilderImagePipeline.LoggingConfigurationPropertyOutputReference;
    putLoggingConfiguration(value: AwsImagebuilderImagePipeline.LoggingConfigurationProperty): void;
    resetLoggingConfiguration(): void;
    get loggingConfigurationInput(): AwsImagebuilderImagePipeline.LoggingConfigurationProperty | undefined;
    private _schedule;
    get schedule(): AwsImagebuilderImagePipeline.SchedulePropertyOutputReference;
    putSchedule(value: AwsImagebuilderImagePipeline.ScheduleProperty): void;
    resetSchedule(): void;
    get scheduleInput(): AwsImagebuilderImagePipeline.ScheduleProperty | undefined;
    private _workflow;
    get workflow(): AwsImagebuilderImagePipeline.WorkflowPropertyList;
    putWorkflow(value: AwsImagebuilderImagePipeline.WorkflowProperty[] | cdktn.IResolvable): void;
    resetWorkflow(): void;
    get workflowInput(): cdktn.IResolvable | AwsImagebuilderImagePipeline.WorkflowProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsImagebuilderImagePipelineEcrConfigurationPropertyToTerraform(struct?: AwsImagebuilderImagePipeline.EcrConfigurationPropertyOutputReference | AwsImagebuilderImagePipeline.EcrConfigurationProperty): any;
export declare function awsImagebuilderImagePipelineEcrConfigurationPropertyToHclTerraform(struct?: AwsImagebuilderImagePipeline.EcrConfigurationPropertyOutputReference | AwsImagebuilderImagePipeline.EcrConfigurationProperty): any;
export declare function awsImagebuilderImagePipelineImageScanningConfigurationPropertyToTerraform(struct?: AwsImagebuilderImagePipeline.ImageScanningConfigurationPropertyOutputReference | AwsImagebuilderImagePipeline.ImageScanningConfigurationProperty): any;
export declare function awsImagebuilderImagePipelineImageScanningConfigurationPropertyToHclTerraform(struct?: AwsImagebuilderImagePipeline.ImageScanningConfigurationPropertyOutputReference | AwsImagebuilderImagePipeline.ImageScanningConfigurationProperty): any;
export declare function awsImagebuilderImagePipelineImageTestsConfigurationPropertyToTerraform(struct?: AwsImagebuilderImagePipeline.ImageTestsConfigurationPropertyOutputReference | AwsImagebuilderImagePipeline.ImageTestsConfigurationProperty): any;
export declare function awsImagebuilderImagePipelineImageTestsConfigurationPropertyToHclTerraform(struct?: AwsImagebuilderImagePipeline.ImageTestsConfigurationPropertyOutputReference | AwsImagebuilderImagePipeline.ImageTestsConfigurationProperty): any;
export declare function awsImagebuilderImagePipelineLoggingConfigurationPropertyToTerraform(struct?: AwsImagebuilderImagePipeline.LoggingConfigurationPropertyOutputReference | AwsImagebuilderImagePipeline.LoggingConfigurationProperty): any;
export declare function awsImagebuilderImagePipelineLoggingConfigurationPropertyToHclTerraform(struct?: AwsImagebuilderImagePipeline.LoggingConfigurationPropertyOutputReference | AwsImagebuilderImagePipeline.LoggingConfigurationProperty): any;
export declare function awsImagebuilderImagePipelineSchedulePropertyToTerraform(struct?: AwsImagebuilderImagePipeline.SchedulePropertyOutputReference | AwsImagebuilderImagePipeline.ScheduleProperty): any;
export declare function awsImagebuilderImagePipelineSchedulePropertyToHclTerraform(struct?: AwsImagebuilderImagePipeline.SchedulePropertyOutputReference | AwsImagebuilderImagePipeline.ScheduleProperty): any;
export declare function awsImagebuilderImagePipelineParameterPropertyToTerraform(struct?: AwsImagebuilderImagePipeline.ParameterProperty | cdktn.IResolvable): any;
export declare function awsImagebuilderImagePipelineParameterPropertyToHclTerraform(struct?: AwsImagebuilderImagePipeline.ParameterProperty | cdktn.IResolvable): any;
export declare function awsImagebuilderImagePipelineWorkflowPropertyToTerraform(struct?: AwsImagebuilderImagePipeline.WorkflowProperty | cdktn.IResolvable): any;
export declare function awsImagebuilderImagePipelineWorkflowPropertyToHclTerraform(struct?: AwsImagebuilderImagePipeline.WorkflowProperty | cdktn.IResolvable): any;
export declare namespace AwsImagebuilderImagePipeline {
    interface EcrConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_image_pipeline#container_tags AwsImagebuilderImagePipeline#container_tags}
        */
        readonly containerTags?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_image_pipeline#repository_name AwsImagebuilderImagePipeline#repository_name}
        */
        readonly repositoryName?: string;
    }
    class EcrConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): EcrConfigurationProperty | undefined;
        set internalValue(value: EcrConfigurationProperty | undefined);
        private _containerTags?;
        get containerTags(): string[];
        set containerTags(value: string[]);
        resetContainerTags(): void;
        get containerTagsInput(): string[] | undefined;
        private _repositoryName?;
        get repositoryName(): string;
        set repositoryName(value: string);
        resetRepositoryName(): void;
        get repositoryNameInput(): string | undefined;
    }
    interface ImageScanningConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_image_pipeline#image_scanning_enabled AwsImagebuilderImagePipeline#image_scanning_enabled}
        */
        readonly imageScanningEnabled?: boolean | cdktn.IResolvable;
        /**
        * ecr_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_image_pipeline#ecr_configuration AwsImagebuilderImagePipeline#ecr_configuration}
        */
        readonly ecrConfiguration?: EcrConfigurationProperty;
    }
    class ImageScanningConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ImageScanningConfigurationProperty | undefined;
        set internalValue(value: ImageScanningConfigurationProperty | undefined);
        private _imageScanningEnabled?;
        get imageScanningEnabled(): boolean | cdktn.IResolvable;
        set imageScanningEnabled(value: boolean | cdktn.IResolvable);
        resetImageScanningEnabled(): void;
        get imageScanningEnabledInput(): boolean | cdktn.IResolvable | undefined;
        private _ecrConfiguration;
        get ecrConfiguration(): EcrConfigurationPropertyOutputReference;
        putEcrConfiguration(value: EcrConfigurationProperty): void;
        resetEcrConfiguration(): void;
        get ecrConfigurationInput(): EcrConfigurationProperty | undefined;
    }
    interface ImageTestsConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_image_pipeline#image_tests_enabled AwsImagebuilderImagePipeline#image_tests_enabled}
        */
        readonly imageTestsEnabled?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_image_pipeline#timeout_minutes AwsImagebuilderImagePipeline#timeout_minutes}
        */
        readonly timeoutMinutes?: number;
    }
    class ImageTestsConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ImageTestsConfigurationProperty | undefined;
        set internalValue(value: ImageTestsConfigurationProperty | undefined);
        private _imageTestsEnabled?;
        get imageTestsEnabled(): boolean | cdktn.IResolvable;
        set imageTestsEnabled(value: boolean | cdktn.IResolvable);
        resetImageTestsEnabled(): void;
        get imageTestsEnabledInput(): boolean | cdktn.IResolvable | undefined;
        private _timeoutMinutes?;
        get timeoutMinutes(): number;
        set timeoutMinutes(value: number);
        resetTimeoutMinutes(): void;
        get timeoutMinutesInput(): number | undefined;
    }
    interface LoggingConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_image_pipeline#image_log_group_name AwsImagebuilderImagePipeline#image_log_group_name}
        */
        readonly imageLogGroupName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_image_pipeline#pipeline_log_group_name AwsImagebuilderImagePipeline#pipeline_log_group_name}
        */
        readonly pipelineLogGroupName?: string;
    }
    class LoggingConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): LoggingConfigurationProperty | undefined;
        set internalValue(value: LoggingConfigurationProperty | undefined);
        private _imageLogGroupName?;
        get imageLogGroupName(): string;
        set imageLogGroupName(value: string);
        resetImageLogGroupName(): void;
        get imageLogGroupNameInput(): string | undefined;
        private _pipelineLogGroupName?;
        get pipelineLogGroupName(): string;
        set pipelineLogGroupName(value: string);
        resetPipelineLogGroupName(): void;
        get pipelineLogGroupNameInput(): string | undefined;
    }
    interface ScheduleProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_image_pipeline#pipeline_execution_start_condition AwsImagebuilderImagePipeline#pipeline_execution_start_condition}
        */
        readonly pipelineExecutionStartCondition?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_image_pipeline#schedule_expression AwsImagebuilderImagePipeline#schedule_expression}
        */
        readonly scheduleExpression: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_image_pipeline#timezone AwsImagebuilderImagePipeline#timezone}
        */
        readonly timezone?: string;
    }
    class SchedulePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ScheduleProperty | undefined;
        set internalValue(value: ScheduleProperty | undefined);
        private _pipelineExecutionStartCondition?;
        get pipelineExecutionStartCondition(): string;
        set pipelineExecutionStartCondition(value: string);
        resetPipelineExecutionStartCondition(): void;
        get pipelineExecutionStartConditionInput(): string | undefined;
        private _scheduleExpression?;
        get scheduleExpression(): string;
        set scheduleExpression(value: string);
        get scheduleExpressionInput(): string | undefined;
        private _timezone?;
        get timezone(): string;
        set timezone(value: string);
        resetTimezone(): void;
        get timezoneInput(): string | undefined;
    }
    interface ParameterProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_image_pipeline#name AwsImagebuilderImagePipeline#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_image_pipeline#value AwsImagebuilderImagePipeline#value}
        */
        readonly value: string;
    }
    class ParameterPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ParameterProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ParameterProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class ParameterPropertyList extends cdktn.ComplexList {
        internalValue?: ParameterProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ParameterPropertyOutputReference;
    }
    interface WorkflowProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_image_pipeline#on_failure AwsImagebuilderImagePipeline#on_failure}
        */
        readonly onFailure?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_image_pipeline#parallel_group AwsImagebuilderImagePipeline#parallel_group}
        */
        readonly parallelGroup?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_image_pipeline#workflow_arn AwsImagebuilderImagePipeline#workflow_arn}
        */
        readonly workflowArn: string;
        /**
        * parameter block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_image_pipeline#parameter AwsImagebuilderImagePipeline#parameter}
        */
        readonly parameter?: ParameterProperty[] | cdktn.IResolvable;
    }
    class WorkflowPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowProperty | cdktn.IResolvable | undefined);
        private _onFailure?;
        get onFailure(): string;
        set onFailure(value: string);
        resetOnFailure(): void;
        get onFailureInput(): string | undefined;
        private _parallelGroup?;
        get parallelGroup(): string;
        set parallelGroup(value: string);
        resetParallelGroup(): void;
        get parallelGroupInput(): string | undefined;
        private _workflowArn?;
        get workflowArn(): string;
        set workflowArn(value: string);
        get workflowArnInput(): string | undefined;
        private _parameter;
        get parameter(): ParameterPropertyList;
        putParameter(value: ParameterProperty[] | cdktn.IResolvable): void;
        resetParameter(): void;
        get parameterInput(): cdktn.IResolvable | ParameterProperty[] | undefined;
    }
    class WorkflowPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowPropertyOutputReference;
    }
}
