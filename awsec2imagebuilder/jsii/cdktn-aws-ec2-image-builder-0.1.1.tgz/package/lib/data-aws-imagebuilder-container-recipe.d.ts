import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsImagebuilderContainerRecipeConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/imagebuilder_container_recipe#arn DataAwsImagebuilderContainerRecipe#arn}
    */
    readonly arn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/imagebuilder_container_recipe#id DataAwsImagebuilderContainerRecipe#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/imagebuilder_container_recipe#region DataAwsImagebuilderContainerRecipe#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/imagebuilder_container_recipe#tags DataAwsImagebuilderContainerRecipe#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/imagebuilder_container_recipe aws_imagebuilder_container_recipe}
*/
export declare class DataAwsImagebuilderContainerRecipe extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_imagebuilder_container_recipe";
    /**
    * Generates CDKTN code for importing a DataAwsImagebuilderContainerRecipe resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsImagebuilderContainerRecipe to import
    * @param importFromId The id of the existing DataAwsImagebuilderContainerRecipe that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/imagebuilder_container_recipe#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsImagebuilderContainerRecipe to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/imagebuilder_container_recipe aws_imagebuilder_container_recipe} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsImagebuilderContainerRecipeConfig
    */
    constructor(scope: Construct, id: string, config: DataAwsImagebuilderContainerRecipeConfig);
    private _arn?;
    get arn(): string;
    set arn(value: string);
    get arnInput(): string | undefined;
    private _component;
    get component(): DataAwsImagebuilderContainerRecipe.ComponentPropertyList;
    get containerType(): string;
    get dateCreated(): string;
    get description(): string;
    get dockerfileTemplateData(): string;
    get encrypted(): cdktn.IResolvable;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _instanceConfiguration;
    get instanceConfiguration(): DataAwsImagebuilderContainerRecipe.InstanceConfigurationPropertyList;
    get kmsKeyId(): string;
    get name(): string;
    get owner(): string;
    get parentImage(): string;
    get platform(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _targetRepository;
    get targetRepository(): DataAwsImagebuilderContainerRecipe.TargetRepositoryPropertyList;
    get version(): string;
    get workingDirectory(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataAwsImagebuilderContainerRecipeParameterPropertyToTerraform(struct?: DataAwsImagebuilderContainerRecipe.ParameterProperty): any;
export declare function dataAwsImagebuilderContainerRecipeParameterPropertyToHclTerraform(struct?: DataAwsImagebuilderContainerRecipe.ParameterProperty): any;
export declare function dataAwsImagebuilderContainerRecipeComponentPropertyToTerraform(struct?: DataAwsImagebuilderContainerRecipe.ComponentProperty): any;
export declare function dataAwsImagebuilderContainerRecipeComponentPropertyToHclTerraform(struct?: DataAwsImagebuilderContainerRecipe.ComponentProperty): any;
export declare function dataAwsImagebuilderContainerRecipeEbsPropertyToTerraform(struct?: DataAwsImagebuilderContainerRecipe.EbsProperty): any;
export declare function dataAwsImagebuilderContainerRecipeEbsPropertyToHclTerraform(struct?: DataAwsImagebuilderContainerRecipe.EbsProperty): any;
export declare function dataAwsImagebuilderContainerRecipeBlockDeviceMappingPropertyToTerraform(struct?: DataAwsImagebuilderContainerRecipe.BlockDeviceMappingProperty): any;
export declare function dataAwsImagebuilderContainerRecipeBlockDeviceMappingPropertyToHclTerraform(struct?: DataAwsImagebuilderContainerRecipe.BlockDeviceMappingProperty): any;
export declare function dataAwsImagebuilderContainerRecipeInstanceConfigurationPropertyToTerraform(struct?: DataAwsImagebuilderContainerRecipe.InstanceConfigurationProperty): any;
export declare function dataAwsImagebuilderContainerRecipeInstanceConfigurationPropertyToHclTerraform(struct?: DataAwsImagebuilderContainerRecipe.InstanceConfigurationProperty): any;
export declare function dataAwsImagebuilderContainerRecipeTargetRepositoryPropertyToTerraform(struct?: DataAwsImagebuilderContainerRecipe.TargetRepositoryProperty): any;
export declare function dataAwsImagebuilderContainerRecipeTargetRepositoryPropertyToHclTerraform(struct?: DataAwsImagebuilderContainerRecipe.TargetRepositoryProperty): any;
export declare namespace DataAwsImagebuilderContainerRecipe {
    interface ParameterProperty {
    }
    class ParameterPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ParameterProperty | undefined;
        set internalValue(value: ParameterProperty | undefined);
        get name(): string;
        get value(): string;
    }
    class ParameterPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ParameterPropertyOutputReference;
    }
    interface ComponentProperty {
    }
    class ComponentPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ComponentProperty | undefined;
        set internalValue(value: ComponentProperty | undefined);
        get componentArn(): string;
        private _parameter;
        get parameter(): ParameterPropertyList;
    }
    class ComponentPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ComponentPropertyOutputReference;
    }
    interface EbsProperty {
    }
    class EbsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EbsProperty | undefined;
        set internalValue(value: EbsProperty | undefined);
        get deleteOnTermination(): cdktn.IResolvable;
        get encrypted(): cdktn.IResolvable;
        get iops(): number;
        get kmsKeyId(): string;
        get snapshotId(): string;
        get throughput(): number;
        get volumeSize(): number;
        get volumeType(): string;
    }
    class EbsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EbsPropertyOutputReference;
    }
    interface BlockDeviceMappingProperty {
    }
    class BlockDeviceMappingPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): BlockDeviceMappingProperty | undefined;
        set internalValue(value: BlockDeviceMappingProperty | undefined);
        get deviceName(): string;
        private _ebs;
        get ebs(): EbsPropertyList;
        get noDevice(): string;
        get virtualName(): string;
    }
    class BlockDeviceMappingPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): BlockDeviceMappingPropertyOutputReference;
    }
    interface InstanceConfigurationProperty {
    }
    class InstanceConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): InstanceConfigurationProperty | undefined;
        set internalValue(value: InstanceConfigurationProperty | undefined);
        private _blockDeviceMapping;
        get blockDeviceMapping(): BlockDeviceMappingPropertyList;
        get image(): string;
    }
    class InstanceConfigurationPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): InstanceConfigurationPropertyOutputReference;
    }
    interface TargetRepositoryProperty {
    }
    class TargetRepositoryPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TargetRepositoryProperty | undefined;
        set internalValue(value: TargetRepositoryProperty | undefined);
        get repositoryName(): string;
        get service(): string;
    }
    class TargetRepositoryPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TargetRepositoryPropertyOutputReference;
    }
}
