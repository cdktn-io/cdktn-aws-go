import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsImagebuilderImageRecipeConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/imagebuilder_image_recipe#arn DataAwsImagebuilderImageRecipe#arn}
    */
    readonly arn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/imagebuilder_image_recipe#id DataAwsImagebuilderImageRecipe#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/imagebuilder_image_recipe#region DataAwsImagebuilderImageRecipe#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/imagebuilder_image_recipe#tags DataAwsImagebuilderImageRecipe#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/imagebuilder_image_recipe aws_imagebuilder_image_recipe}
*/
export declare class DataAwsImagebuilderImageRecipe extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_imagebuilder_image_recipe";
    /**
    * Generates CDKTN code for importing a DataAwsImagebuilderImageRecipe resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsImagebuilderImageRecipe to import
    * @param importFromId The id of the existing DataAwsImagebuilderImageRecipe that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/imagebuilder_image_recipe#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsImagebuilderImageRecipe to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/imagebuilder_image_recipe aws_imagebuilder_image_recipe} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsImagebuilderImageRecipeConfig
    */
    constructor(scope: Construct, id: string, config: DataAwsImagebuilderImageRecipeConfig);
    private _amiTags;
    get amiTags(): cdktn.StringMap;
    private _arn?;
    get arn(): string;
    set arn(value: string);
    get arnInput(): string | undefined;
    private _blockDeviceMapping;
    get blockDeviceMapping(): DataAwsImagebuilderImageRecipe.BlockDeviceMappingPropertyList;
    private _component;
    get component(): DataAwsImagebuilderImageRecipe.ComponentPropertyList;
    get dateCreated(): string;
    get description(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get name(): string;
    get owner(): string;
    get parentImage(): string;
    get platform(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    get userDataBase64(): string;
    get version(): string;
    get workingDirectory(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataAwsImagebuilderImageRecipeEbsPropertyToTerraform(struct?: DataAwsImagebuilderImageRecipe.EbsProperty): any;
export declare function dataAwsImagebuilderImageRecipeEbsPropertyToHclTerraform(struct?: DataAwsImagebuilderImageRecipe.EbsProperty): any;
export declare function dataAwsImagebuilderImageRecipeBlockDeviceMappingPropertyToTerraform(struct?: DataAwsImagebuilderImageRecipe.BlockDeviceMappingProperty): any;
export declare function dataAwsImagebuilderImageRecipeBlockDeviceMappingPropertyToHclTerraform(struct?: DataAwsImagebuilderImageRecipe.BlockDeviceMappingProperty): any;
export declare function dataAwsImagebuilderImageRecipeParameterPropertyToTerraform(struct?: DataAwsImagebuilderImageRecipe.ParameterProperty): any;
export declare function dataAwsImagebuilderImageRecipeParameterPropertyToHclTerraform(struct?: DataAwsImagebuilderImageRecipe.ParameterProperty): any;
export declare function dataAwsImagebuilderImageRecipeComponentPropertyToTerraform(struct?: DataAwsImagebuilderImageRecipe.ComponentProperty): any;
export declare function dataAwsImagebuilderImageRecipeComponentPropertyToHclTerraform(struct?: DataAwsImagebuilderImageRecipe.ComponentProperty): any;
export declare namespace DataAwsImagebuilderImageRecipe {
    interface EbsProperty {
    }
    class EbsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EbsProperty | undefined;
        set internalValue(value: EbsProperty | undefined);
        get deleteOnTermination(): string;
        get encrypted(): string;
        get iops(): number;
        get kmsKeyId(): string;
        get snapshotId(): string;
        get throughput(): number;
        get volumeSize(): number;
        get volumeType(): string;
    }
    class EbsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EbsPropertyOutputReference;
    }
    interface BlockDeviceMappingProperty {
    }
    class BlockDeviceMappingPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): BlockDeviceMappingProperty | undefined;
        set internalValue(value: BlockDeviceMappingProperty | undefined);
        get deviceName(): string;
        private _ebs;
        get ebs(): EbsPropertyList;
        get noDevice(): string;
        get virtualName(): string;
    }
    class BlockDeviceMappingPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): BlockDeviceMappingPropertyOutputReference;
    }
    interface ParameterProperty {
    }
    class ParameterPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ParameterProperty | undefined;
        set internalValue(value: ParameterProperty | undefined);
        get name(): string;
        get value(): string;
    }
    class ParameterPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ParameterPropertyOutputReference;
    }
    interface ComponentProperty {
    }
    class ComponentPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ComponentProperty | undefined;
        set internalValue(value: ComponentProperty | undefined);
        get componentArn(): string;
        private _parameter;
        get parameter(): ParameterPropertyList;
    }
    class ComponentPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ComponentPropertyOutputReference;
    }
}
