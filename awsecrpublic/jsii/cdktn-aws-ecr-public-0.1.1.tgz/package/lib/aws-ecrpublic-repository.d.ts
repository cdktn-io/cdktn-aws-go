import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsEcrpublicRepositoryConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecrpublic_repository#force_destroy AwsEcrpublicRepository#force_destroy}
    */
    readonly forceDestroy?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecrpublic_repository#id AwsEcrpublicRepository#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecrpublic_repository#region AwsEcrpublicRepository#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecrpublic_repository#repository_name AwsEcrpublicRepository#repository_name}
    */
    readonly repositoryName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecrpublic_repository#tags AwsEcrpublicRepository#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecrpublic_repository#tags_all AwsEcrpublicRepository#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * catalog_data block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecrpublic_repository#catalog_data AwsEcrpublicRepository#catalog_data}
    */
    readonly catalogData?: AwsEcrpublicRepository.CatalogDataProperty;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecrpublic_repository#timeouts AwsEcrpublicRepository#timeouts}
    */
    readonly timeouts?: AwsEcrpublicRepository.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecrpublic_repository aws_ecrpublic_repository}
*/
export declare class AwsEcrpublicRepository extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_ecrpublic_repository";
    /**
    * Generates CDKTN code for importing a AwsEcrpublicRepository resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsEcrpublicRepository to import
    * @param importFromId The id of the existing AwsEcrpublicRepository that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecrpublic_repository#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsEcrpublicRepository to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecrpublic_repository aws_ecrpublic_repository} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsEcrpublicRepositoryConfig
    */
    constructor(scope: Construct, id: string, config: AwsEcrpublicRepositoryConfig);
    get arn(): string;
    private _forceDestroy?;
    get forceDestroy(): boolean | cdktn.IResolvable;
    set forceDestroy(value: boolean | cdktn.IResolvable);
    resetForceDestroy(): void;
    get forceDestroyInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get registryId(): string;
    private _repositoryName?;
    get repositoryName(): string;
    set repositoryName(value: string);
    get repositoryNameInput(): string | undefined;
    get repositoryUri(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _catalogData;
    get catalogData(): AwsEcrpublicRepository.CatalogDataPropertyOutputReference;
    putCatalogData(value: AwsEcrpublicRepository.CatalogDataProperty): void;
    resetCatalogData(): void;
    get catalogDataInput(): AwsEcrpublicRepository.CatalogDataProperty | undefined;
    private _timeouts;
    get timeouts(): AwsEcrpublicRepository.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsEcrpublicRepository.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsEcrpublicRepository.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsEcrpublicRepositoryCatalogDataPropertyToTerraform(struct?: AwsEcrpublicRepository.CatalogDataPropertyOutputReference | AwsEcrpublicRepository.CatalogDataProperty): any;
export declare function awsEcrpublicRepositoryCatalogDataPropertyToHclTerraform(struct?: AwsEcrpublicRepository.CatalogDataPropertyOutputReference | AwsEcrpublicRepository.CatalogDataProperty): any;
export declare function awsEcrpublicRepositoryTimeoutsPropertyToTerraform(struct?: AwsEcrpublicRepository.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsEcrpublicRepositoryTimeoutsPropertyToHclTerraform(struct?: AwsEcrpublicRepository.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsEcrpublicRepository {
    interface CatalogDataProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecrpublic_repository#about_text AwsEcrpublicRepository#about_text}
        */
        readonly aboutText?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecrpublic_repository#architectures AwsEcrpublicRepository#architectures}
        */
        readonly architectures?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecrpublic_repository#description AwsEcrpublicRepository#description}
        */
        readonly description?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecrpublic_repository#logo_image_blob AwsEcrpublicRepository#logo_image_blob}
        */
        readonly logoImageBlob?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecrpublic_repository#operating_systems AwsEcrpublicRepository#operating_systems}
        */
        readonly operatingSystems?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecrpublic_repository#usage_text AwsEcrpublicRepository#usage_text}
        */
        readonly usageText?: string;
    }
    class CatalogDataPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CatalogDataProperty | undefined;
        set internalValue(value: CatalogDataProperty | undefined);
        private _aboutText?;
        get aboutText(): string;
        set aboutText(value: string);
        resetAboutText(): void;
        get aboutTextInput(): string | undefined;
        private _architectures?;
        get architectures(): string[];
        set architectures(value: string[]);
        resetArchitectures(): void;
        get architecturesInput(): string[] | undefined;
        private _description?;
        get description(): string;
        set description(value: string);
        resetDescription(): void;
        get descriptionInput(): string | undefined;
        private _logoImageBlob?;
        get logoImageBlob(): string;
        set logoImageBlob(value: string);
        resetLogoImageBlob(): void;
        get logoImageBlobInput(): string | undefined;
        private _operatingSystems?;
        get operatingSystems(): string[];
        set operatingSystems(value: string[]);
        resetOperatingSystems(): void;
        get operatingSystemsInput(): string[] | undefined;
        private _usageText?;
        get usageText(): string;
        set usageText(value: string);
        resetUsageText(): void;
        get usageTextInput(): string | undefined;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecrpublic_repository#delete AwsEcrpublicRepository#delete}
        */
        readonly delete?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
    }
}
