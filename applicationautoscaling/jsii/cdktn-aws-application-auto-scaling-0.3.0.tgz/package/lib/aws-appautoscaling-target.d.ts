import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsTargetConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appautoscaling_target#id AwsTarget#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appautoscaling_target#max_capacity AwsTarget#max_capacity}
    */
    readonly maxCapacity: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appautoscaling_target#min_capacity AwsTarget#min_capacity}
    */
    readonly minCapacity: number;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appautoscaling_target#region AwsTarget#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appautoscaling_target#resource_id AwsTarget#resource_id}
    */
    readonly resourceId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appautoscaling_target#role_arn AwsTarget#role_arn}
    */
    readonly roleArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appautoscaling_target#scalable_dimension AwsTarget#scalable_dimension}
    */
    readonly scalableDimension: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appautoscaling_target#service_namespace AwsTarget#service_namespace}
    */
    readonly serviceNamespace: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appautoscaling_target#tags AwsTarget#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appautoscaling_target#tags_all AwsTarget#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * suspended_state block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appautoscaling_target#suspended_state AwsTarget#suspended_state}
    */
    readonly suspendedState?: AwsTarget.SuspendedStateProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appautoscaling_target aws_appautoscaling_target}
*/
export declare class AwsTarget extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_appautoscaling_target";
    /**
    * Generates CDKTN code for importing a AwsTarget resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsTarget to import
    * @param importFromId The id of the existing AwsTarget that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appautoscaling_target#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsTarget to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appautoscaling_target aws_appautoscaling_target} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsTargetConfig
    */
    constructor(scope: Construct, id: string, config: AwsTargetConfig);
    get arn(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _maxCapacity?;
    get maxCapacity(): number;
    set maxCapacity(value: number);
    get maxCapacityInput(): number | undefined;
    private _minCapacity?;
    get minCapacity(): number;
    set minCapacity(value: number);
    get minCapacityInput(): number | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _resourceId?;
    get resourceId(): string;
    set resourceId(value: string);
    get resourceIdInput(): string | undefined;
    private _roleArn?;
    get roleArn(): string;
    set roleArn(value: string);
    resetRoleArn(): void;
    get roleArnInput(): string | undefined;
    private _scalableDimension?;
    get scalableDimension(): string;
    set scalableDimension(value: string);
    get scalableDimensionInput(): string | undefined;
    private _serviceNamespace?;
    get serviceNamespace(): string;
    set serviceNamespace(value: string);
    get serviceNamespaceInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _suspendedState;
    get suspendedState(): AwsTarget.SuspendedStatePropertyOutputReference;
    putSuspendedState(value: AwsTarget.SuspendedStateProperty): void;
    resetSuspendedState(): void;
    get suspendedStateInput(): AwsTarget.SuspendedStateProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsTargetSuspendedStatePropertyToTerraform(struct?: AwsTarget.SuspendedStatePropertyOutputReference | AwsTarget.SuspendedStateProperty): any;
export declare function awsTargetSuspendedStatePropertyToHclTerraform(struct?: AwsTarget.SuspendedStatePropertyOutputReference | AwsTarget.SuspendedStateProperty): any;
export declare namespace AwsTarget {
    interface SuspendedStateProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appautoscaling_target#dynamic_scaling_in_suspended AwsTarget#dynamic_scaling_in_suspended}
        */
        readonly dynamicScalingInSuspended?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appautoscaling_target#dynamic_scaling_out_suspended AwsTarget#dynamic_scaling_out_suspended}
        */
        readonly dynamicScalingOutSuspended?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appautoscaling_target#scheduled_scaling_suspended AwsTarget#scheduled_scaling_suspended}
        */
        readonly scheduledScalingSuspended?: boolean | cdktn.IResolvable;
    }
    class SuspendedStatePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SuspendedStateProperty | undefined;
        set internalValue(value: SuspendedStateProperty | undefined);
        private _dynamicScalingInSuspended?;
        get dynamicScalingInSuspended(): boolean | cdktn.IResolvable;
        set dynamicScalingInSuspended(value: boolean | cdktn.IResolvable);
        resetDynamicScalingInSuspended(): void;
        get dynamicScalingInSuspendedInput(): boolean | cdktn.IResolvable | undefined;
        private _dynamicScalingOutSuspended?;
        get dynamicScalingOutSuspended(): boolean | cdktn.IResolvable;
        set dynamicScalingOutSuspended(value: boolean | cdktn.IResolvable);
        resetDynamicScalingOutSuspended(): void;
        get dynamicScalingOutSuspendedInput(): boolean | cdktn.IResolvable | undefined;
        private _scheduledScalingSuspended?;
        get scheduledScalingSuspended(): boolean | cdktn.IResolvable;
        set scheduledScalingSuspended(value: boolean | cdktn.IResolvable);
        resetScheduledScalingSuspended(): void;
        get scheduledScalingSuspendedInput(): boolean | cdktn.IResolvable | undefined;
    }
}
