import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsDirectoryServiceSharedDirectoryConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/directory_service_shared_directory#directory_id AwsDirectoryServiceSharedDirectory#directory_id}
    */
    readonly directoryId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/directory_service_shared_directory#id AwsDirectoryServiceSharedDirectory#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/directory_service_shared_directory#method AwsDirectoryServiceSharedDirectory#method}
    */
    readonly method?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/directory_service_shared_directory#notes AwsDirectoryServiceSharedDirectory#notes}
    */
    readonly notes?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/directory_service_shared_directory#region AwsDirectoryServiceSharedDirectory#region}
    */
    readonly region?: string;
    /**
    * target block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/directory_service_shared_directory#target AwsDirectoryServiceSharedDirectory#target}
    */
    readonly target: AwsDirectoryServiceSharedDirectory.TargetProperty;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/directory_service_shared_directory#timeouts AwsDirectoryServiceSharedDirectory#timeouts}
    */
    readonly timeouts?: AwsDirectoryServiceSharedDirectory.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/directory_service_shared_directory aws_directory_service_shared_directory}
*/
export declare class AwsDirectoryServiceSharedDirectory extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_directory_service_shared_directory";
    /**
    * Generates CDKTN code for importing a AwsDirectoryServiceSharedDirectory resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsDirectoryServiceSharedDirectory to import
    * @param importFromId The id of the existing AwsDirectoryServiceSharedDirectory that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/directory_service_shared_directory#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsDirectoryServiceSharedDirectory to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/directory_service_shared_directory aws_directory_service_shared_directory} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsDirectoryServiceSharedDirectoryConfig
    */
    constructor(scope: Construct, id: string, config: AwsDirectoryServiceSharedDirectoryConfig);
    private _directoryId?;
    get directoryId(): string;
    set directoryId(value: string);
    get directoryIdInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _method?;
    get method(): string;
    set method(value: string);
    resetMethod(): void;
    get methodInput(): string | undefined;
    private _notes?;
    get notes(): string;
    set notes(value: string);
    resetNotes(): void;
    get notesInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get sharedDirectoryId(): string;
    private _target;
    get target(): AwsDirectoryServiceSharedDirectory.TargetPropertyOutputReference;
    putTarget(value: AwsDirectoryServiceSharedDirectory.TargetProperty): void;
    get targetInput(): AwsDirectoryServiceSharedDirectory.TargetProperty | undefined;
    private _timeouts;
    get timeouts(): AwsDirectoryServiceSharedDirectory.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsDirectoryServiceSharedDirectory.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsDirectoryServiceSharedDirectory.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsDirectoryServiceSharedDirectoryTargetPropertyToTerraform(struct?: AwsDirectoryServiceSharedDirectory.TargetPropertyOutputReference | AwsDirectoryServiceSharedDirectory.TargetProperty): any;
export declare function awsDirectoryServiceSharedDirectoryTargetPropertyToHclTerraform(struct?: AwsDirectoryServiceSharedDirectory.TargetPropertyOutputReference | AwsDirectoryServiceSharedDirectory.TargetProperty): any;
export declare function awsDirectoryServiceSharedDirectoryTimeoutsPropertyToTerraform(struct?: AwsDirectoryServiceSharedDirectory.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsDirectoryServiceSharedDirectoryTimeoutsPropertyToHclTerraform(struct?: AwsDirectoryServiceSharedDirectory.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsDirectoryServiceSharedDirectory {
    interface TargetProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/directory_service_shared_directory#id AwsDirectoryServiceSharedDirectory#id}
        *
        * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
        * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
        */
        readonly id: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/directory_service_shared_directory#type AwsDirectoryServiceSharedDirectory#type}
        */
        readonly type?: string;
    }
    class TargetPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TargetProperty | undefined;
        set internalValue(value: TargetProperty | undefined);
        private _id?;
        get id(): string;
        set id(value: string);
        get idInput(): string | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        resetType(): void;
        get typeInput(): string | undefined;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/directory_service_shared_directory#delete AwsDirectoryServiceSharedDirectory#delete}
        */
        readonly delete?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
    }
}
