import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsDirectoryServiceDirectoryConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/directory_service_directory#alias AwsDirectoryServiceDirectory#alias}
    */
    readonly alias?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/directory_service_directory#description AwsDirectoryServiceDirectory#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/directory_service_directory#desired_number_of_domain_controllers AwsDirectoryServiceDirectory#desired_number_of_domain_controllers}
    */
    readonly desiredNumberOfDomainControllers?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/directory_service_directory#edition AwsDirectoryServiceDirectory#edition}
    */
    readonly edition?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/directory_service_directory#enable_directory_data_access AwsDirectoryServiceDirectory#enable_directory_data_access}
    */
    readonly enableDirectoryDataAccess?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/directory_service_directory#enable_sso AwsDirectoryServiceDirectory#enable_sso}
    */
    readonly enableSso?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/directory_service_directory#id AwsDirectoryServiceDirectory#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/directory_service_directory#name AwsDirectoryServiceDirectory#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/directory_service_directory#password AwsDirectoryServiceDirectory#password}
    */
    readonly password: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/directory_service_directory#region AwsDirectoryServiceDirectory#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/directory_service_directory#short_name AwsDirectoryServiceDirectory#short_name}
    */
    readonly shortName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/directory_service_directory#size AwsDirectoryServiceDirectory#size}
    */
    readonly size?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/directory_service_directory#tags AwsDirectoryServiceDirectory#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/directory_service_directory#tags_all AwsDirectoryServiceDirectory#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/directory_service_directory#type AwsDirectoryServiceDirectory#type}
    */
    readonly type?: string;
    /**
    * connect_settings block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/directory_service_directory#connect_settings AwsDirectoryServiceDirectory#connect_settings}
    */
    readonly connectSettings?: AwsDirectoryServiceDirectory.ConnectSettingsProperty;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/directory_service_directory#timeouts AwsDirectoryServiceDirectory#timeouts}
    */
    readonly timeouts?: AwsDirectoryServiceDirectory.TimeoutsProperty;
    /**
    * vpc_settings block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/directory_service_directory#vpc_settings AwsDirectoryServiceDirectory#vpc_settings}
    */
    readonly vpcSettings?: AwsDirectoryServiceDirectory.VpcSettingsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/directory_service_directory aws_directory_service_directory}
*/
export declare class AwsDirectoryServiceDirectory extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_directory_service_directory";
    /**
    * Generates CDKTN code for importing a AwsDirectoryServiceDirectory resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsDirectoryServiceDirectory to import
    * @param importFromId The id of the existing AwsDirectoryServiceDirectory that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/directory_service_directory#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsDirectoryServiceDirectory to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/directory_service_directory aws_directory_service_directory} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsDirectoryServiceDirectoryConfig
    */
    constructor(scope: Construct, id: string, config: AwsDirectoryServiceDirectoryConfig);
    get accessUrl(): string;
    private _alias?;
    get alias(): string;
    set alias(value: string);
    resetAlias(): void;
    get aliasInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _desiredNumberOfDomainControllers?;
    get desiredNumberOfDomainControllers(): number;
    set desiredNumberOfDomainControllers(value: number);
    resetDesiredNumberOfDomainControllers(): void;
    get desiredNumberOfDomainControllersInput(): number | undefined;
    get dnsIpAddresses(): string[];
    private _edition?;
    get edition(): string;
    set edition(value: string);
    resetEdition(): void;
    get editionInput(): string | undefined;
    private _enableDirectoryDataAccess?;
    get enableDirectoryDataAccess(): boolean | cdktn.IResolvable;
    set enableDirectoryDataAccess(value: boolean | cdktn.IResolvable);
    resetEnableDirectoryDataAccess(): void;
    get enableDirectoryDataAccessInput(): boolean | cdktn.IResolvable | undefined;
    private _enableSso?;
    get enableSso(): boolean | cdktn.IResolvable;
    set enableSso(value: boolean | cdktn.IResolvable);
    resetEnableSso(): void;
    get enableSsoInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _password?;
    get password(): string;
    set password(value: string);
    get passwordInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get securityGroupId(): string;
    private _shortName?;
    get shortName(): string;
    set shortName(value: string);
    resetShortName(): void;
    get shortNameInput(): string | undefined;
    private _size?;
    get size(): string;
    set size(value: string);
    resetSize(): void;
    get sizeInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
    private _connectSettings;
    get connectSettings(): AwsDirectoryServiceDirectory.ConnectSettingsPropertyOutputReference;
    putConnectSettings(value: AwsDirectoryServiceDirectory.ConnectSettingsProperty): void;
    resetConnectSettings(): void;
    get connectSettingsInput(): AwsDirectoryServiceDirectory.ConnectSettingsProperty | undefined;
    private _timeouts;
    get timeouts(): AwsDirectoryServiceDirectory.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsDirectoryServiceDirectory.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsDirectoryServiceDirectory.TimeoutsProperty | undefined;
    private _vpcSettings;
    get vpcSettings(): AwsDirectoryServiceDirectory.VpcSettingsPropertyOutputReference;
    putVpcSettings(value: AwsDirectoryServiceDirectory.VpcSettingsProperty): void;
    resetVpcSettings(): void;
    get vpcSettingsInput(): AwsDirectoryServiceDirectory.VpcSettingsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsDirectoryServiceDirectoryConnectSettingsPropertyToTerraform(struct?: AwsDirectoryServiceDirectory.ConnectSettingsPropertyOutputReference | AwsDirectoryServiceDirectory.ConnectSettingsProperty): any;
export declare function awsDirectoryServiceDirectoryConnectSettingsPropertyToHclTerraform(struct?: AwsDirectoryServiceDirectory.ConnectSettingsPropertyOutputReference | AwsDirectoryServiceDirectory.ConnectSettingsProperty): any;
export declare function awsDirectoryServiceDirectoryTimeoutsPropertyToTerraform(struct?: AwsDirectoryServiceDirectory.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsDirectoryServiceDirectoryTimeoutsPropertyToHclTerraform(struct?: AwsDirectoryServiceDirectory.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsDirectoryServiceDirectoryVpcSettingsPropertyToTerraform(struct?: AwsDirectoryServiceDirectory.VpcSettingsPropertyOutputReference | AwsDirectoryServiceDirectory.VpcSettingsProperty): any;
export declare function awsDirectoryServiceDirectoryVpcSettingsPropertyToHclTerraform(struct?: AwsDirectoryServiceDirectory.VpcSettingsPropertyOutputReference | AwsDirectoryServiceDirectory.VpcSettingsProperty): any;
export declare namespace AwsDirectoryServiceDirectory {
    interface ConnectSettingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/directory_service_directory#customer_dns_ips AwsDirectoryServiceDirectory#customer_dns_ips}
        */
        readonly customerDnsIps: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/directory_service_directory#customer_username AwsDirectoryServiceDirectory#customer_username}
        */
        readonly customerUsername: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/directory_service_directory#subnet_ids AwsDirectoryServiceDirectory#subnet_ids}
        */
        readonly subnetIds: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/directory_service_directory#vpc_id AwsDirectoryServiceDirectory#vpc_id}
        */
        readonly vpcId: string;
    }
    class ConnectSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ConnectSettingsProperty | undefined;
        set internalValue(value: ConnectSettingsProperty | undefined);
        get availabilityZones(): string[];
        get connectIps(): string[];
        private _customerDnsIps?;
        get customerDnsIps(): string[];
        set customerDnsIps(value: string[]);
        get customerDnsIpsInput(): string[] | undefined;
        private _customerUsername?;
        get customerUsername(): string;
        set customerUsername(value: string);
        get customerUsernameInput(): string | undefined;
        private _subnetIds?;
        get subnetIds(): string[];
        set subnetIds(value: string[]);
        get subnetIdsInput(): string[] | undefined;
        private _vpcId?;
        get vpcId(): string;
        set vpcId(value: string);
        get vpcIdInput(): string | undefined;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/directory_service_directory#create AwsDirectoryServiceDirectory#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/directory_service_directory#delete AwsDirectoryServiceDirectory#delete}
        */
        readonly delete?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/directory_service_directory#update AwsDirectoryServiceDirectory#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
    interface VpcSettingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/directory_service_directory#subnet_ids AwsDirectoryServiceDirectory#subnet_ids}
        */
        readonly subnetIds: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/directory_service_directory#vpc_id AwsDirectoryServiceDirectory#vpc_id}
        */
        readonly vpcId: string;
    }
    class VpcSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): VpcSettingsProperty | undefined;
        set internalValue(value: VpcSettingsProperty | undefined);
        get availabilityZones(): string[];
        private _subnetIds?;
        get subnetIds(): string[];
        set subnetIds(value: string[]);
        get subnetIdsInput(): string[] | undefined;
        private _vpcId?;
        get vpcId(): string;
        set vpcId(value: string);
        get vpcIdInput(): string | undefined;
    }
}
