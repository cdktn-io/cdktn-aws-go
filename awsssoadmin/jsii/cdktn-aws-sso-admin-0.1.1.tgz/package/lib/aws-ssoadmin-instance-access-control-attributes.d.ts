import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsSsoadminInstanceAccessControlAttributesConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssoadmin_instance_access_control_attributes#id AwsSsoadminInstanceAccessControlAttributes#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssoadmin_instance_access_control_attributes#instance_arn AwsSsoadminInstanceAccessControlAttributes#instance_arn}
    */
    readonly instanceArn: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssoadmin_instance_access_control_attributes#region AwsSsoadminInstanceAccessControlAttributes#region}
    */
    readonly region?: string;
    /**
    * attribute block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssoadmin_instance_access_control_attributes#attribute AwsSsoadminInstanceAccessControlAttributes#attribute}
    */
    readonly attribute: AwsSsoadminInstanceAccessControlAttributes.AttributeProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssoadmin_instance_access_control_attributes aws_ssoadmin_instance_access_control_attributes}
*/
export declare class AwsSsoadminInstanceAccessControlAttributes extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_ssoadmin_instance_access_control_attributes";
    /**
    * Generates CDKTN code for importing a AwsSsoadminInstanceAccessControlAttributes resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsSsoadminInstanceAccessControlAttributes to import
    * @param importFromId The id of the existing AwsSsoadminInstanceAccessControlAttributes that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssoadmin_instance_access_control_attributes#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsSsoadminInstanceAccessControlAttributes to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssoadmin_instance_access_control_attributes aws_ssoadmin_instance_access_control_attributes} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsSsoadminInstanceAccessControlAttributesConfig
    */
    constructor(scope: Construct, id: string, config: AwsSsoadminInstanceAccessControlAttributesConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _instanceArn?;
    get instanceArn(): string;
    set instanceArn(value: string);
    get instanceArnInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get status(): string;
    get statusReason(): string;
    private _attribute;
    get attribute(): AwsSsoadminInstanceAccessControlAttributes.AttributePropertyList;
    putAttribute(value: AwsSsoadminInstanceAccessControlAttributes.AttributeProperty[] | cdktn.IResolvable): void;
    get attributeInput(): cdktn.IResolvable | AwsSsoadminInstanceAccessControlAttributes.AttributeProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsSsoadminInstanceAccessControlAttributesValuePropertyToTerraform(struct?: AwsSsoadminInstanceAccessControlAttributes.ValueProperty | cdktn.IResolvable): any;
export declare function awsSsoadminInstanceAccessControlAttributesValuePropertyToHclTerraform(struct?: AwsSsoadminInstanceAccessControlAttributes.ValueProperty | cdktn.IResolvable): any;
export declare function awsSsoadminInstanceAccessControlAttributesAttributePropertyToTerraform(struct?: AwsSsoadminInstanceAccessControlAttributes.AttributeProperty | cdktn.IResolvable): any;
export declare function awsSsoadminInstanceAccessControlAttributesAttributePropertyToHclTerraform(struct?: AwsSsoadminInstanceAccessControlAttributes.AttributeProperty | cdktn.IResolvable): any;
export declare namespace AwsSsoadminInstanceAccessControlAttributes {
    interface ValueProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssoadmin_instance_access_control_attributes#source AwsSsoadminInstanceAccessControlAttributes#source}
        */
        readonly source: string[];
    }
    class ValuePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ValueProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ValueProperty | cdktn.IResolvable | undefined);
        private _source?;
        get source(): string[];
        set source(value: string[]);
        get sourceInput(): string[] | undefined;
    }
    class ValuePropertyList extends cdktn.ComplexList {
        internalValue?: ValueProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ValuePropertyOutputReference;
    }
    interface AttributeProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssoadmin_instance_access_control_attributes#key AwsSsoadminInstanceAccessControlAttributes#key}
        */
        readonly key: string;
        /**
        * value block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssoadmin_instance_access_control_attributes#value AwsSsoadminInstanceAccessControlAttributes#value}
        */
        readonly value: ValueProperty[] | cdktn.IResolvable;
    }
    class AttributePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AttributeProperty | cdktn.IResolvable | undefined;
        set internalValue(value: AttributeProperty | cdktn.IResolvable | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        get keyInput(): string | undefined;
        private _value;
        get value(): ValuePropertyList;
        putValue(value: ValueProperty[] | cdktn.IResolvable): void;
        get valueInput(): cdktn.IResolvable | ValueProperty[] | undefined;
    }
    class AttributePropertyList extends cdktn.ComplexList {
        internalValue?: AttributeProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AttributePropertyOutputReference;
    }
}
