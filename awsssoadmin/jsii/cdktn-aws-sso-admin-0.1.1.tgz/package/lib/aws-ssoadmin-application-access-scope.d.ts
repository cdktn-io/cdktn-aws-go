import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsSsoadminApplicationAccessScopeConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssoadmin_application_access_scope#application_arn AwsSsoadminApplicationAccessScope#application_arn}
    */
    readonly applicationArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssoadmin_application_access_scope#authorized_targets AwsSsoadminApplicationAccessScope#authorized_targets}
    */
    readonly authorizedTargets?: string[];
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssoadmin_application_access_scope#region AwsSsoadminApplicationAccessScope#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssoadmin_application_access_scope#scope AwsSsoadminApplicationAccessScope#scope}
    */
    readonly scope: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssoadmin_application_access_scope aws_ssoadmin_application_access_scope}
*/
export declare class AwsSsoadminApplicationAccessScope extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_ssoadmin_application_access_scope";
    /**
    * Generates CDKTN code for importing a AwsSsoadminApplicationAccessScope resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsSsoadminApplicationAccessScope to import
    * @param importFromId The id of the existing AwsSsoadminApplicationAccessScope that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssoadmin_application_access_scope#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsSsoadminApplicationAccessScope to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssoadmin_application_access_scope aws_ssoadmin_application_access_scope} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsSsoadminApplicationAccessScopeConfig
    */
    constructor(scope: Construct, id: string, config: AwsSsoadminApplicationAccessScopeConfig);
    private _applicationArn?;
    get applicationArn(): string;
    set applicationArn(value: string);
    get applicationArnInput(): string | undefined;
    private _authorizedTargets?;
    get authorizedTargets(): string[];
    set authorizedTargets(value: string[]);
    resetAuthorizedTargets(): void;
    get authorizedTargetsInput(): string[] | undefined;
    get id(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _scope?;
    get scope(): string;
    set scope(value: string);
    get scopeInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
