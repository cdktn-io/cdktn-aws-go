import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsSsoadminPermissionsBoundaryAttachmentConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssoadmin_permissions_boundary_attachment#id AwsSsoadminPermissionsBoundaryAttachment#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssoadmin_permissions_boundary_attachment#instance_arn AwsSsoadminPermissionsBoundaryAttachment#instance_arn}
    */
    readonly instanceArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssoadmin_permissions_boundary_attachment#permission_set_arn AwsSsoadminPermissionsBoundaryAttachment#permission_set_arn}
    */
    readonly permissionSetArn: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssoadmin_permissions_boundary_attachment#region AwsSsoadminPermissionsBoundaryAttachment#region}
    */
    readonly region?: string;
    /**
    * permissions_boundary block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssoadmin_permissions_boundary_attachment#permissions_boundary AwsSsoadminPermissionsBoundaryAttachment#permissions_boundary}
    */
    readonly permissionsBoundary: AwsSsoadminPermissionsBoundaryAttachment.PermissionsBoundaryProperty;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssoadmin_permissions_boundary_attachment#timeouts AwsSsoadminPermissionsBoundaryAttachment#timeouts}
    */
    readonly timeouts?: AwsSsoadminPermissionsBoundaryAttachment.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssoadmin_permissions_boundary_attachment aws_ssoadmin_permissions_boundary_attachment}
*/
export declare class AwsSsoadminPermissionsBoundaryAttachment extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_ssoadmin_permissions_boundary_attachment";
    /**
    * Generates CDKTN code for importing a AwsSsoadminPermissionsBoundaryAttachment resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsSsoadminPermissionsBoundaryAttachment to import
    * @param importFromId The id of the existing AwsSsoadminPermissionsBoundaryAttachment that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssoadmin_permissions_boundary_attachment#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsSsoadminPermissionsBoundaryAttachment to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssoadmin_permissions_boundary_attachment aws_ssoadmin_permissions_boundary_attachment} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsSsoadminPermissionsBoundaryAttachmentConfig
    */
    constructor(scope: Construct, id: string, config: AwsSsoadminPermissionsBoundaryAttachmentConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _instanceArn?;
    get instanceArn(): string;
    set instanceArn(value: string);
    get instanceArnInput(): string | undefined;
    private _permissionSetArn?;
    get permissionSetArn(): string;
    set permissionSetArn(value: string);
    get permissionSetArnInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _permissionsBoundary;
    get permissionsBoundary(): AwsSsoadminPermissionsBoundaryAttachment.PermissionsBoundaryPropertyOutputReference;
    putPermissionsBoundary(value: AwsSsoadminPermissionsBoundaryAttachment.PermissionsBoundaryProperty): void;
    get permissionsBoundaryInput(): AwsSsoadminPermissionsBoundaryAttachment.PermissionsBoundaryProperty | undefined;
    private _timeouts;
    get timeouts(): AwsSsoadminPermissionsBoundaryAttachment.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsSsoadminPermissionsBoundaryAttachment.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsSsoadminPermissionsBoundaryAttachment.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsSsoadminPermissionsBoundaryAttachmentCustomerManagedPolicyReferencePropertyToTerraform(struct?: AwsSsoadminPermissionsBoundaryAttachment.CustomerManagedPolicyReferencePropertyOutputReference | AwsSsoadminPermissionsBoundaryAttachment.CustomerManagedPolicyReferenceProperty): any;
export declare function awsSsoadminPermissionsBoundaryAttachmentCustomerManagedPolicyReferencePropertyToHclTerraform(struct?: AwsSsoadminPermissionsBoundaryAttachment.CustomerManagedPolicyReferencePropertyOutputReference | AwsSsoadminPermissionsBoundaryAttachment.CustomerManagedPolicyReferenceProperty): any;
export declare function awsSsoadminPermissionsBoundaryAttachmentPermissionsBoundaryPropertyToTerraform(struct?: AwsSsoadminPermissionsBoundaryAttachment.PermissionsBoundaryPropertyOutputReference | AwsSsoadminPermissionsBoundaryAttachment.PermissionsBoundaryProperty): any;
export declare function awsSsoadminPermissionsBoundaryAttachmentPermissionsBoundaryPropertyToHclTerraform(struct?: AwsSsoadminPermissionsBoundaryAttachment.PermissionsBoundaryPropertyOutputReference | AwsSsoadminPermissionsBoundaryAttachment.PermissionsBoundaryProperty): any;
export declare function awsSsoadminPermissionsBoundaryAttachmentTimeoutsPropertyToTerraform(struct?: AwsSsoadminPermissionsBoundaryAttachment.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsSsoadminPermissionsBoundaryAttachmentTimeoutsPropertyToHclTerraform(struct?: AwsSsoadminPermissionsBoundaryAttachment.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsSsoadminPermissionsBoundaryAttachment {
    interface CustomerManagedPolicyReferenceProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssoadmin_permissions_boundary_attachment#name AwsSsoadminPermissionsBoundaryAttachment#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssoadmin_permissions_boundary_attachment#path AwsSsoadminPermissionsBoundaryAttachment#path}
        */
        readonly path?: string;
    }
    class CustomerManagedPolicyReferencePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CustomerManagedPolicyReferenceProperty | undefined;
        set internalValue(value: CustomerManagedPolicyReferenceProperty | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _path?;
        get path(): string;
        set path(value: string);
        resetPath(): void;
        get pathInput(): string | undefined;
    }
    interface PermissionsBoundaryProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssoadmin_permissions_boundary_attachment#managed_policy_arn AwsSsoadminPermissionsBoundaryAttachment#managed_policy_arn}
        */
        readonly managedPolicyArn?: string;
        /**
        * customer_managed_policy_reference block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssoadmin_permissions_boundary_attachment#customer_managed_policy_reference AwsSsoadminPermissionsBoundaryAttachment#customer_managed_policy_reference}
        */
        readonly customerManagedPolicyReference?: CustomerManagedPolicyReferenceProperty;
    }
    class PermissionsBoundaryPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): PermissionsBoundaryProperty | undefined;
        set internalValue(value: PermissionsBoundaryProperty | undefined);
        private _managedPolicyArn?;
        get managedPolicyArn(): string;
        set managedPolicyArn(value: string);
        resetManagedPolicyArn(): void;
        get managedPolicyArnInput(): string | undefined;
        private _customerManagedPolicyReference;
        get customerManagedPolicyReference(): CustomerManagedPolicyReferencePropertyOutputReference;
        putCustomerManagedPolicyReference(value: CustomerManagedPolicyReferenceProperty): void;
        resetCustomerManagedPolicyReference(): void;
        get customerManagedPolicyReferenceInput(): CustomerManagedPolicyReferenceProperty | undefined;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssoadmin_permissions_boundary_attachment#create AwsSsoadminPermissionsBoundaryAttachment#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssoadmin_permissions_boundary_attachment#delete AwsSsoadminPermissionsBoundaryAttachment#delete}
        */
        readonly delete?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
    }
}
