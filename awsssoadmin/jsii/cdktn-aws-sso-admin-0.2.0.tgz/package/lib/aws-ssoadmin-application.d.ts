import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfApplicationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssoadmin_application#application_provider_arn TfApplication#application_provider_arn}
    */
    readonly applicationProviderArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssoadmin_application#client_token TfApplication#client_token}
    */
    readonly clientToken?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssoadmin_application#description TfApplication#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssoadmin_application#instance_arn TfApplication#instance_arn}
    */
    readonly instanceArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssoadmin_application#name TfApplication#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssoadmin_application#region TfApplication#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssoadmin_application#status TfApplication#status}
    */
    readonly status?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssoadmin_application#tags TfApplication#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * portal_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssoadmin_application#portal_options TfApplication#portal_options}
    */
    readonly portalOptions?: TfApplication.PortalOptionsProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssoadmin_application aws_ssoadmin_application}
*/
export declare class TfApplication extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_ssoadmin_application";
    /**
    * Generates CDKTN code for importing a TfApplication resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfApplication to import
    * @param importFromId The id of the existing TfApplication that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssoadmin_application#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfApplication to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssoadmin_application aws_ssoadmin_application} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfApplicationConfig
    */
    constructor(scope: Construct, id: string, config: TfApplicationConfig);
    get applicationAccount(): string;
    get applicationArn(): string;
    private _applicationProviderArn?;
    get applicationProviderArn(): string;
    set applicationProviderArn(value: string);
    get applicationProviderArnInput(): string | undefined;
    get arn(): string;
    private _clientToken?;
    get clientToken(): string;
    set clientToken(value: string);
    resetClientToken(): void;
    get clientTokenInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get id(): string;
    private _instanceArn?;
    get instanceArn(): string;
    set instanceArn(value: string);
    get instanceArnInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _status?;
    get status(): string;
    set status(value: string);
    resetStatus(): void;
    get statusInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    private _portalOptions;
    get portalOptions(): TfApplication.PortalOptionsPropertyList;
    putPortalOptions(value: TfApplication.PortalOptionsProperty[] | cdktn.IResolvable): void;
    resetPortalOptions(): void;
    get portalOptionsInput(): cdktn.IResolvable | TfApplication.PortalOptionsProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfApplicationSignInOptionsPropertyToTerraform(struct?: TfApplication.SignInOptionsProperty | cdktn.IResolvable): any;
export declare function tfApplicationSignInOptionsPropertyToHclTerraform(struct?: TfApplication.SignInOptionsProperty | cdktn.IResolvable): any;
export declare function tfApplicationPortalOptionsPropertyToTerraform(struct?: TfApplication.PortalOptionsProperty | cdktn.IResolvable): any;
export declare function tfApplicationPortalOptionsPropertyToHclTerraform(struct?: TfApplication.PortalOptionsProperty | cdktn.IResolvable): any;
export declare namespace TfApplication {
    interface SignInOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssoadmin_application#application_url TfApplication#application_url}
        */
        readonly applicationUrl?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssoadmin_application#origin TfApplication#origin}
        */
        readonly origin: string;
    }
    class SignInOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SignInOptionsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SignInOptionsProperty | cdktn.IResolvable | undefined);
        private _applicationUrl?;
        get applicationUrl(): string;
        set applicationUrl(value: string);
        resetApplicationUrl(): void;
        get applicationUrlInput(): string | undefined;
        private _origin?;
        get origin(): string;
        set origin(value: string);
        get originInput(): string | undefined;
    }
    class SignInOptionsPropertyList extends cdktn.ComplexList {
        internalValue?: SignInOptionsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SignInOptionsPropertyOutputReference;
    }
    interface PortalOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssoadmin_application#visibility TfApplication#visibility}
        */
        readonly visibility?: string;
        /**
        * sign_in_options block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssoadmin_application#sign_in_options TfApplication#sign_in_options}
        */
        readonly signInOptions?: SignInOptionsProperty[] | cdktn.IResolvable;
    }
    class PortalOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): PortalOptionsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: PortalOptionsProperty | cdktn.IResolvable | undefined);
        private _visibility?;
        get visibility(): string;
        set visibility(value: string);
        resetVisibility(): void;
        get visibilityInput(): string | undefined;
        private _signInOptions;
        get signInOptions(): SignInOptionsPropertyList;
        putSignInOptions(value: SignInOptionsProperty[] | cdktn.IResolvable): void;
        resetSignInOptions(): void;
        get signInOptionsInput(): cdktn.IResolvable | SignInOptionsProperty[] | undefined;
    }
    class PortalOptionsPropertyList extends cdktn.ComplexList {
        internalValue?: PortalOptionsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): PortalOptionsPropertyOutputReference;
    }
}
