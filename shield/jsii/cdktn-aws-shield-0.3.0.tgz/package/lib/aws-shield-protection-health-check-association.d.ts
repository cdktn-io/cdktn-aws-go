import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsProtectionHealthCheckAssociationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/shield_protection_health_check_association#health_check_arn AwsProtectionHealthCheckAssociation#health_check_arn}
    */
    readonly healthCheckArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/shield_protection_health_check_association#id AwsProtectionHealthCheckAssociation#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/shield_protection_health_check_association#shield_protection_id AwsProtectionHealthCheckAssociation#shield_protection_id}
    */
    readonly shieldProtectionId: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/shield_protection_health_check_association aws_shield_protection_health_check_association}
*/
export declare class AwsProtectionHealthCheckAssociation extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_shield_protection_health_check_association";
    /**
    * Generates CDKTN code for importing a AwsProtectionHealthCheckAssociation resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsProtectionHealthCheckAssociation to import
    * @param importFromId The id of the existing AwsProtectionHealthCheckAssociation that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/shield_protection_health_check_association#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsProtectionHealthCheckAssociation to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/shield_protection_health_check_association aws_shield_protection_health_check_association} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsProtectionHealthCheckAssociationConfig
    */
    constructor(scope: Construct, id: string, config: AwsProtectionHealthCheckAssociationConfig);
    private _healthCheckArn?;
    get healthCheckArn(): string;
    set healthCheckArn(value: string);
    get healthCheckArnInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _shieldProtectionId?;
    get shieldProtectionId(): string;
    set shieldProtectionId(value: string);
    get shieldProtectionIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
