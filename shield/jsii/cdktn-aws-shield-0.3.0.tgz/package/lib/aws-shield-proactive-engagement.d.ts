import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsProactiveEngagementConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/shield_proactive_engagement#enabled AwsProactiveEngagement#enabled}
    */
    readonly enabled: boolean | cdktn.IResolvable;
    /**
    * emergency_contact block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/shield_proactive_engagement#emergency_contact AwsProactiveEngagement#emergency_contact}
    */
    readonly emergencyContact?: AwsProactiveEngagement.EmergencyContactProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/shield_proactive_engagement aws_shield_proactive_engagement}
*/
export declare class AwsProactiveEngagement extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_shield_proactive_engagement";
    /**
    * Generates CDKTN code for importing a AwsProactiveEngagement resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsProactiveEngagement to import
    * @param importFromId The id of the existing AwsProactiveEngagement that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/shield_proactive_engagement#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsProactiveEngagement to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/shield_proactive_engagement aws_shield_proactive_engagement} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsProactiveEngagementConfig
    */
    constructor(scope: Construct, id: string, config: AwsProactiveEngagementConfig);
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    get id(): string;
    private _emergencyContact;
    get emergencyContact(): AwsProactiveEngagement.EmergencyContactPropertyList;
    putEmergencyContact(value: AwsProactiveEngagement.EmergencyContactProperty[] | cdktn.IResolvable): void;
    resetEmergencyContact(): void;
    get emergencyContactInput(): cdktn.IResolvable | AwsProactiveEngagement.EmergencyContactProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsProactiveEngagementEmergencyContactPropertyToTerraform(struct?: AwsProactiveEngagement.EmergencyContactProperty | cdktn.IResolvable): any;
export declare function awsProactiveEngagementEmergencyContactPropertyToHclTerraform(struct?: AwsProactiveEngagement.EmergencyContactProperty | cdktn.IResolvable): any;
export declare namespace AwsProactiveEngagement {
    interface EmergencyContactProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/shield_proactive_engagement#contact_notes AwsProactiveEngagement#contact_notes}
        */
        readonly contactNotes?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/shield_proactive_engagement#email_address AwsProactiveEngagement#email_address}
        */
        readonly emailAddress: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/shield_proactive_engagement#phone_number AwsProactiveEngagement#phone_number}
        */
        readonly phoneNumber?: string;
    }
    class EmergencyContactPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EmergencyContactProperty | cdktn.IResolvable | undefined;
        set internalValue(value: EmergencyContactProperty | cdktn.IResolvable | undefined);
        private _contactNotes?;
        get contactNotes(): string;
        set contactNotes(value: string);
        resetContactNotes(): void;
        get contactNotesInput(): string | undefined;
        private _emailAddress?;
        get emailAddress(): string;
        set emailAddress(value: string);
        get emailAddressInput(): string | undefined;
        private _phoneNumber?;
        get phoneNumber(): string;
        set phoneNumber(value: string);
        resetPhoneNumber(): void;
        get phoneNumberInput(): string | undefined;
    }
    class EmergencyContactPropertyList extends cdktn.ComplexList {
        internalValue?: EmergencyContactProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EmergencyContactPropertyOutputReference;
    }
}
