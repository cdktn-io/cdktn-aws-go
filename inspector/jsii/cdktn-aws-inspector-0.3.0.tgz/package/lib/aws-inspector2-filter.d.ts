import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsFilterConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_filter#action AwsFilter#action}
    */
    readonly action: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_filter#description AwsFilter#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_filter#name AwsFilter#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_filter#reason AwsFilter#reason}
    */
    readonly reason?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_filter#region AwsFilter#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_filter#tags AwsFilter#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * filter_criteria block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_filter#filter_criteria AwsFilter#filter_criteria}
    */
    readonly filterCriteria?: AwsFilter.FilterCriteriaProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_filter aws_inspector2_filter}
*/
export declare class AwsFilter extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_inspector2_filter";
    /**
    * Generates CDKTN code for importing a AwsFilter resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsFilter to import
    * @param importFromId The id of the existing AwsFilter that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_filter#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsFilter to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_filter aws_inspector2_filter} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsFilterConfig
    */
    constructor(scope: Construct, id: string, config: AwsFilterConfig);
    private _action?;
    get action(): string;
    set action(value: string);
    get actionInput(): string | undefined;
    get arn(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _reason?;
    get reason(): string;
    set reason(value: string);
    resetReason(): void;
    get reasonInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    private _filterCriteria;
    get filterCriteria(): AwsFilter.FilterCriteriaPropertyList;
    putFilterCriteria(value: AwsFilter.FilterCriteriaProperty[] | cdktn.IResolvable): void;
    resetFilterCriteria(): void;
    get filterCriteriaInput(): cdktn.IResolvable | AwsFilter.FilterCriteriaProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsFilterAwsAccountIdPropertyToTerraform(struct?: AwsFilter.AwsAccountIdProperty | cdktn.IResolvable): any;
export declare function awsFilterAwsAccountIdPropertyToHclTerraform(struct?: AwsFilter.AwsAccountIdProperty | cdktn.IResolvable): any;
export declare function awsFilterCodeRepositoryProjectNamePropertyToTerraform(struct?: AwsFilter.CodeRepositoryProjectNameProperty | cdktn.IResolvable): any;
export declare function awsFilterCodeRepositoryProjectNamePropertyToHclTerraform(struct?: AwsFilter.CodeRepositoryProjectNameProperty | cdktn.IResolvable): any;
export declare function awsFilterCodeRepositoryProviderTypePropertyToTerraform(struct?: AwsFilter.CodeRepositoryProviderTypeProperty | cdktn.IResolvable): any;
export declare function awsFilterCodeRepositoryProviderTypePropertyToHclTerraform(struct?: AwsFilter.CodeRepositoryProviderTypeProperty | cdktn.IResolvable): any;
export declare function awsFilterCodeVulnerabilityDetectorNamePropertyToTerraform(struct?: AwsFilter.CodeVulnerabilityDetectorNameProperty | cdktn.IResolvable): any;
export declare function awsFilterCodeVulnerabilityDetectorNamePropertyToHclTerraform(struct?: AwsFilter.CodeVulnerabilityDetectorNameProperty | cdktn.IResolvable): any;
export declare function awsFilterCodeVulnerabilityDetectorTagsPropertyToTerraform(struct?: AwsFilter.CodeVulnerabilityDetectorTagsProperty | cdktn.IResolvable): any;
export declare function awsFilterCodeVulnerabilityDetectorTagsPropertyToHclTerraform(struct?: AwsFilter.CodeVulnerabilityDetectorTagsProperty | cdktn.IResolvable): any;
export declare function awsFilterCodeVulnerabilityFilePathPropertyToTerraform(struct?: AwsFilter.CodeVulnerabilityFilePathProperty | cdktn.IResolvable): any;
export declare function awsFilterCodeVulnerabilityFilePathPropertyToHclTerraform(struct?: AwsFilter.CodeVulnerabilityFilePathProperty | cdktn.IResolvable): any;
export declare function awsFilterComponentIdPropertyToTerraform(struct?: AwsFilter.ComponentIdProperty | cdktn.IResolvable): any;
export declare function awsFilterComponentIdPropertyToHclTerraform(struct?: AwsFilter.ComponentIdProperty | cdktn.IResolvable): any;
export declare function awsFilterComponentTypePropertyToTerraform(struct?: AwsFilter.ComponentTypeProperty | cdktn.IResolvable): any;
export declare function awsFilterComponentTypePropertyToHclTerraform(struct?: AwsFilter.ComponentTypeProperty | cdktn.IResolvable): any;
export declare function awsFilterEc2InstanceImageIdPropertyToTerraform(struct?: AwsFilter.Ec2InstanceImageIdProperty | cdktn.IResolvable): any;
export declare function awsFilterEc2InstanceImageIdPropertyToHclTerraform(struct?: AwsFilter.Ec2InstanceImageIdProperty | cdktn.IResolvable): any;
export declare function awsFilterEc2InstanceSubnetIdPropertyToTerraform(struct?: AwsFilter.Ec2InstanceSubnetIdProperty | cdktn.IResolvable): any;
export declare function awsFilterEc2InstanceSubnetIdPropertyToHclTerraform(struct?: AwsFilter.Ec2InstanceSubnetIdProperty | cdktn.IResolvable): any;
export declare function awsFilterEc2InstanceVpcIdPropertyToTerraform(struct?: AwsFilter.Ec2InstanceVpcIdProperty | cdktn.IResolvable): any;
export declare function awsFilterEc2InstanceVpcIdPropertyToHclTerraform(struct?: AwsFilter.Ec2InstanceVpcIdProperty | cdktn.IResolvable): any;
export declare function awsFilterEcrImageArchitecturePropertyToTerraform(struct?: AwsFilter.EcrImageArchitectureProperty | cdktn.IResolvable): any;
export declare function awsFilterEcrImageArchitecturePropertyToHclTerraform(struct?: AwsFilter.EcrImageArchitectureProperty | cdktn.IResolvable): any;
export declare function awsFilterEcrImageHashPropertyToTerraform(struct?: AwsFilter.EcrImageHashProperty | cdktn.IResolvable): any;
export declare function awsFilterEcrImageHashPropertyToHclTerraform(struct?: AwsFilter.EcrImageHashProperty | cdktn.IResolvable): any;
export declare function awsFilterEcrImageInUseCountPropertyToTerraform(struct?: AwsFilter.EcrImageInUseCountProperty | cdktn.IResolvable): any;
export declare function awsFilterEcrImageInUseCountPropertyToHclTerraform(struct?: AwsFilter.EcrImageInUseCountProperty | cdktn.IResolvable): any;
export declare function awsFilterEcrImageLastInUseAtPropertyToTerraform(struct?: AwsFilter.EcrImageLastInUseAtProperty | cdktn.IResolvable): any;
export declare function awsFilterEcrImageLastInUseAtPropertyToHclTerraform(struct?: AwsFilter.EcrImageLastInUseAtProperty | cdktn.IResolvable): any;
export declare function awsFilterEcrImagePushedAtPropertyToTerraform(struct?: AwsFilter.EcrImagePushedAtProperty | cdktn.IResolvable): any;
export declare function awsFilterEcrImagePushedAtPropertyToHclTerraform(struct?: AwsFilter.EcrImagePushedAtProperty | cdktn.IResolvable): any;
export declare function awsFilterEcrImageRegistryPropertyToTerraform(struct?: AwsFilter.EcrImageRegistryProperty | cdktn.IResolvable): any;
export declare function awsFilterEcrImageRegistryPropertyToHclTerraform(struct?: AwsFilter.EcrImageRegistryProperty | cdktn.IResolvable): any;
export declare function awsFilterEcrImageRepositoryNamePropertyToTerraform(struct?: AwsFilter.EcrImageRepositoryNameProperty | cdktn.IResolvable): any;
export declare function awsFilterEcrImageRepositoryNamePropertyToHclTerraform(struct?: AwsFilter.EcrImageRepositoryNameProperty | cdktn.IResolvable): any;
export declare function awsFilterEcrImageTagsPropertyToTerraform(struct?: AwsFilter.EcrImageTagsProperty | cdktn.IResolvable): any;
export declare function awsFilterEcrImageTagsPropertyToHclTerraform(struct?: AwsFilter.EcrImageTagsProperty | cdktn.IResolvable): any;
export declare function awsFilterEpssScorePropertyToTerraform(struct?: AwsFilter.EpssScoreProperty | cdktn.IResolvable): any;
export declare function awsFilterEpssScorePropertyToHclTerraform(struct?: AwsFilter.EpssScoreProperty | cdktn.IResolvable): any;
export declare function awsFilterExploitAvailablePropertyToTerraform(struct?: AwsFilter.ExploitAvailableProperty | cdktn.IResolvable): any;
export declare function awsFilterExploitAvailablePropertyToHclTerraform(struct?: AwsFilter.ExploitAvailableProperty | cdktn.IResolvable): any;
export declare function awsFilterFindingArnPropertyToTerraform(struct?: AwsFilter.FindingArnProperty | cdktn.IResolvable): any;
export declare function awsFilterFindingArnPropertyToHclTerraform(struct?: AwsFilter.FindingArnProperty | cdktn.IResolvable): any;
export declare function awsFilterFindingStatusPropertyToTerraform(struct?: AwsFilter.FindingStatusProperty | cdktn.IResolvable): any;
export declare function awsFilterFindingStatusPropertyToHclTerraform(struct?: AwsFilter.FindingStatusProperty | cdktn.IResolvable): any;
export declare function awsFilterFindingTypePropertyToTerraform(struct?: AwsFilter.FindingTypeProperty | cdktn.IResolvable): any;
export declare function awsFilterFindingTypePropertyToHclTerraform(struct?: AwsFilter.FindingTypeProperty | cdktn.IResolvable): any;
export declare function awsFilterFirstObservedAtPropertyToTerraform(struct?: AwsFilter.FirstObservedAtProperty | cdktn.IResolvable): any;
export declare function awsFilterFirstObservedAtPropertyToHclTerraform(struct?: AwsFilter.FirstObservedAtProperty | cdktn.IResolvable): any;
export declare function awsFilterFixAvailablePropertyToTerraform(struct?: AwsFilter.FixAvailableProperty | cdktn.IResolvable): any;
export declare function awsFilterFixAvailablePropertyToHclTerraform(struct?: AwsFilter.FixAvailableProperty | cdktn.IResolvable): any;
export declare function awsFilterInspectorScorePropertyToTerraform(struct?: AwsFilter.InspectorScoreProperty | cdktn.IResolvable): any;
export declare function awsFilterInspectorScorePropertyToHclTerraform(struct?: AwsFilter.InspectorScoreProperty | cdktn.IResolvable): any;
export declare function awsFilterLambdaFunctionExecutionRoleArnPropertyToTerraform(struct?: AwsFilter.LambdaFunctionExecutionRoleArnProperty | cdktn.IResolvable): any;
export declare function awsFilterLambdaFunctionExecutionRoleArnPropertyToHclTerraform(struct?: AwsFilter.LambdaFunctionExecutionRoleArnProperty | cdktn.IResolvable): any;
export declare function awsFilterLambdaFunctionLastModifiedAtPropertyToTerraform(struct?: AwsFilter.LambdaFunctionLastModifiedAtProperty | cdktn.IResolvable): any;
export declare function awsFilterLambdaFunctionLastModifiedAtPropertyToHclTerraform(struct?: AwsFilter.LambdaFunctionLastModifiedAtProperty | cdktn.IResolvable): any;
export declare function awsFilterLambdaFunctionLayersPropertyToTerraform(struct?: AwsFilter.LambdaFunctionLayersProperty | cdktn.IResolvable): any;
export declare function awsFilterLambdaFunctionLayersPropertyToHclTerraform(struct?: AwsFilter.LambdaFunctionLayersProperty | cdktn.IResolvable): any;
export declare function awsFilterLambdaFunctionNamePropertyToTerraform(struct?: AwsFilter.LambdaFunctionNameProperty | cdktn.IResolvable): any;
export declare function awsFilterLambdaFunctionNamePropertyToHclTerraform(struct?: AwsFilter.LambdaFunctionNameProperty | cdktn.IResolvable): any;
export declare function awsFilterLambdaFunctionRuntimePropertyToTerraform(struct?: AwsFilter.LambdaFunctionRuntimeProperty | cdktn.IResolvable): any;
export declare function awsFilterLambdaFunctionRuntimePropertyToHclTerraform(struct?: AwsFilter.LambdaFunctionRuntimeProperty | cdktn.IResolvable): any;
export declare function awsFilterLastObservedAtPropertyToTerraform(struct?: AwsFilter.LastObservedAtProperty | cdktn.IResolvable): any;
export declare function awsFilterLastObservedAtPropertyToHclTerraform(struct?: AwsFilter.LastObservedAtProperty | cdktn.IResolvable): any;
export declare function awsFilterNetworkProtocolPropertyToTerraform(struct?: AwsFilter.NetworkProtocolProperty | cdktn.IResolvable): any;
export declare function awsFilterNetworkProtocolPropertyToHclTerraform(struct?: AwsFilter.NetworkProtocolProperty | cdktn.IResolvable): any;
export declare function awsFilterPortRangePropertyToTerraform(struct?: AwsFilter.PortRangeProperty | cdktn.IResolvable): any;
export declare function awsFilterPortRangePropertyToHclTerraform(struct?: AwsFilter.PortRangeProperty | cdktn.IResolvable): any;
export declare function awsFilterRelatedVulnerabilitiesPropertyToTerraform(struct?: AwsFilter.RelatedVulnerabilitiesProperty | cdktn.IResolvable): any;
export declare function awsFilterRelatedVulnerabilitiesPropertyToHclTerraform(struct?: AwsFilter.RelatedVulnerabilitiesProperty | cdktn.IResolvable): any;
export declare function awsFilterResourceIdPropertyToTerraform(struct?: AwsFilter.ResourceIdProperty | cdktn.IResolvable): any;
export declare function awsFilterResourceIdPropertyToHclTerraform(struct?: AwsFilter.ResourceIdProperty | cdktn.IResolvable): any;
export declare function awsFilterResourceTagsPropertyToTerraform(struct?: AwsFilter.ResourceTagsProperty | cdktn.IResolvable): any;
export declare function awsFilterResourceTagsPropertyToHclTerraform(struct?: AwsFilter.ResourceTagsProperty | cdktn.IResolvable): any;
export declare function awsFilterResourceTypePropertyToTerraform(struct?: AwsFilter.ResourceTypeProperty | cdktn.IResolvable): any;
export declare function awsFilterResourceTypePropertyToHclTerraform(struct?: AwsFilter.ResourceTypeProperty | cdktn.IResolvable): any;
export declare function awsFilterSeverityPropertyToTerraform(struct?: AwsFilter.SeverityProperty | cdktn.IResolvable): any;
export declare function awsFilterSeverityPropertyToHclTerraform(struct?: AwsFilter.SeverityProperty | cdktn.IResolvable): any;
export declare function awsFilterTitlePropertyToTerraform(struct?: AwsFilter.TitleProperty | cdktn.IResolvable): any;
export declare function awsFilterTitlePropertyToHclTerraform(struct?: AwsFilter.TitleProperty | cdktn.IResolvable): any;
export declare function awsFilterUpdatedAtPropertyToTerraform(struct?: AwsFilter.UpdatedAtProperty | cdktn.IResolvable): any;
export declare function awsFilterUpdatedAtPropertyToHclTerraform(struct?: AwsFilter.UpdatedAtProperty | cdktn.IResolvable): any;
export declare function awsFilterVendorSeverityPropertyToTerraform(struct?: AwsFilter.VendorSeverityProperty | cdktn.IResolvable): any;
export declare function awsFilterVendorSeverityPropertyToHclTerraform(struct?: AwsFilter.VendorSeverityProperty | cdktn.IResolvable): any;
export declare function awsFilterVulnerabilityIdPropertyToTerraform(struct?: AwsFilter.VulnerabilityIdProperty | cdktn.IResolvable): any;
export declare function awsFilterVulnerabilityIdPropertyToHclTerraform(struct?: AwsFilter.VulnerabilityIdProperty | cdktn.IResolvable): any;
export declare function awsFilterVulnerabilitySourcePropertyToTerraform(struct?: AwsFilter.VulnerabilitySourceProperty | cdktn.IResolvable): any;
export declare function awsFilterVulnerabilitySourcePropertyToHclTerraform(struct?: AwsFilter.VulnerabilitySourceProperty | cdktn.IResolvable): any;
export declare function awsFilterArchitecturePropertyToTerraform(struct?: AwsFilter.ArchitectureProperty | cdktn.IResolvable): any;
export declare function awsFilterArchitecturePropertyToHclTerraform(struct?: AwsFilter.ArchitectureProperty | cdktn.IResolvable): any;
export declare function awsFilterEpochPropertyToTerraform(struct?: AwsFilter.EpochProperty | cdktn.IResolvable): any;
export declare function awsFilterEpochPropertyToHclTerraform(struct?: AwsFilter.EpochProperty | cdktn.IResolvable): any;
export declare function awsFilterFilePathPropertyToTerraform(struct?: AwsFilter.FilePathProperty | cdktn.IResolvable): any;
export declare function awsFilterFilePathPropertyToHclTerraform(struct?: AwsFilter.FilePathProperty | cdktn.IResolvable): any;
export declare function awsFilterNamePropertyToTerraform(struct?: AwsFilter.NameProperty | cdktn.IResolvable): any;
export declare function awsFilterNamePropertyToHclTerraform(struct?: AwsFilter.NameProperty | cdktn.IResolvable): any;
export declare function awsFilterReleasePropertyToTerraform(struct?: AwsFilter.ReleaseProperty | cdktn.IResolvable): any;
export declare function awsFilterReleasePropertyToHclTerraform(struct?: AwsFilter.ReleaseProperty | cdktn.IResolvable): any;
export declare function awsFilterSourceLambdaLayerArnPropertyToTerraform(struct?: AwsFilter.SourceLambdaLayerArnProperty | cdktn.IResolvable): any;
export declare function awsFilterSourceLambdaLayerArnPropertyToHclTerraform(struct?: AwsFilter.SourceLambdaLayerArnProperty | cdktn.IResolvable): any;
export declare function awsFilterSourceLayerHashPropertyToTerraform(struct?: AwsFilter.SourceLayerHashProperty | cdktn.IResolvable): any;
export declare function awsFilterSourceLayerHashPropertyToHclTerraform(struct?: AwsFilter.SourceLayerHashProperty | cdktn.IResolvable): any;
export declare function awsFilterVersionPropertyToTerraform(struct?: AwsFilter.VersionProperty | cdktn.IResolvable): any;
export declare function awsFilterVersionPropertyToHclTerraform(struct?: AwsFilter.VersionProperty | cdktn.IResolvable): any;
export declare function awsFilterVulnerablePackagesPropertyToTerraform(struct?: AwsFilter.VulnerablePackagesProperty | cdktn.IResolvable): any;
export declare function awsFilterVulnerablePackagesPropertyToHclTerraform(struct?: AwsFilter.VulnerablePackagesProperty | cdktn.IResolvable): any;
export declare function awsFilterFilterCriteriaPropertyToTerraform(struct?: AwsFilter.FilterCriteriaProperty | cdktn.IResolvable): any;
export declare function awsFilterFilterCriteriaPropertyToHclTerraform(struct?: AwsFilter.FilterCriteriaProperty | cdktn.IResolvable): any;
export declare namespace AwsFilter {
    interface AwsAccountIdProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_filter#comparison AwsFilter#comparison}
        */
        readonly comparison: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_filter#value AwsFilter#value}
        */
        readonly value: string;
    }
    class AwsAccountIdPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AwsAccountIdProperty | cdktn.IResolvable | undefined;
        set internalValue(value: AwsAccountIdProperty | cdktn.IResolvable | undefined);
        private _comparison?;
        get comparison(): string;
        set comparison(value: string);
        get comparisonInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class AwsAccountIdPropertyList extends cdktn.ComplexList {
        internalValue?: AwsAccountIdProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AwsAccountIdPropertyOutputReference;
    }
    interface CodeRepositoryProjectNameProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_filter#comparison AwsFilter#comparison}
        */
        readonly comparison: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_filter#value AwsFilter#value}
        */
        readonly value: string;
    }
    class CodeRepositoryProjectNamePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CodeRepositoryProjectNameProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CodeRepositoryProjectNameProperty | cdktn.IResolvable | undefined);
        private _comparison?;
        get comparison(): string;
        set comparison(value: string);
        get comparisonInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class CodeRepositoryProjectNamePropertyList extends cdktn.ComplexList {
        internalValue?: CodeRepositoryProjectNameProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CodeRepositoryProjectNamePropertyOutputReference;
    }
    interface CodeRepositoryProviderTypeProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_filter#comparison AwsFilter#comparison}
        */
        readonly comparison: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_filter#value AwsFilter#value}
        */
        readonly value: string;
    }
    class CodeRepositoryProviderTypePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CodeRepositoryProviderTypeProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CodeRepositoryProviderTypeProperty | cdktn.IResolvable | undefined);
        private _comparison?;
        get comparison(): string;
        set comparison(value: string);
        get comparisonInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class CodeRepositoryProviderTypePropertyList extends cdktn.ComplexList {
        internalValue?: CodeRepositoryProviderTypeProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CodeRepositoryProviderTypePropertyOutputReference;
    }
    interface CodeVulnerabilityDetectorNameProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_filter#comparison AwsFilter#comparison}
        */
        readonly comparison: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_filter#value AwsFilter#value}
        */
        readonly value: string;
    }
    class CodeVulnerabilityDetectorNamePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CodeVulnerabilityDetectorNameProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CodeVulnerabilityDetectorNameProperty | cdktn.IResolvable | undefined);
        private _comparison?;
        get comparison(): string;
        set comparison(value: string);
        get comparisonInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class CodeVulnerabilityDetectorNamePropertyList extends cdktn.ComplexList {
        internalValue?: CodeVulnerabilityDetectorNameProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CodeVulnerabilityDetectorNamePropertyOutputReference;
    }
    interface CodeVulnerabilityDetectorTagsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_filter#comparison AwsFilter#comparison}
        */
        readonly comparison: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_filter#value AwsFilter#value}
        */
        readonly value: string;
    }
    class CodeVulnerabilityDetectorTagsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CodeVulnerabilityDetectorTagsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CodeVulnerabilityDetectorTagsProperty | cdktn.IResolvable | undefined);
        private _comparison?;
        get comparison(): string;
        set comparison(value: string);
        get comparisonInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class CodeVulnerabilityDetectorTagsPropertyList extends cdktn.ComplexList {
        internalValue?: CodeVulnerabilityDetectorTagsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CodeVulnerabilityDetectorTagsPropertyOutputReference;
    }
    interface CodeVulnerabilityFilePathProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_filter#comparison AwsFilter#comparison}
        */
        readonly comparison: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_filter#value AwsFilter#value}
        */
        readonly value: string;
    }
    class CodeVulnerabilityFilePathPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CodeVulnerabilityFilePathProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CodeVulnerabilityFilePathProperty | cdktn.IResolvable | undefined);
        private _comparison?;
        get comparison(): string;
        set comparison(value: string);
        get comparisonInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class CodeVulnerabilityFilePathPropertyList extends cdktn.ComplexList {
        internalValue?: CodeVulnerabilityFilePathProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CodeVulnerabilityFilePathPropertyOutputReference;
    }
    interface ComponentIdProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_filter#comparison AwsFilter#comparison}
        */
        readonly comparison: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_filter#value AwsFilter#value}
        */
        readonly value: string;
    }
    class ComponentIdPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ComponentIdProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ComponentIdProperty | cdktn.IResolvable | undefined);
        private _comparison?;
        get comparison(): string;
        set comparison(value: string);
        get comparisonInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class ComponentIdPropertyList extends cdktn.ComplexList {
        internalValue?: ComponentIdProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ComponentIdPropertyOutputReference;
    }
    interface ComponentTypeProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_filter#comparison AwsFilter#comparison}
        */
        readonly comparison: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_filter#value AwsFilter#value}
        */
        readonly value: string;
    }
    class ComponentTypePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ComponentTypeProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ComponentTypeProperty | cdktn.IResolvable | undefined);
        private _comparison?;
        get comparison(): string;
        set comparison(value: string);
        get comparisonInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class ComponentTypePropertyList extends cdktn.ComplexList {
        internalValue?: ComponentTypeProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ComponentTypePropertyOutputReference;
    }
    interface Ec2InstanceImageIdProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_filter#comparison AwsFilter#comparison}
        */
        readonly comparison: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_filter#value AwsFilter#value}
        */
        readonly value: string;
    }
    class Ec2InstanceImageIdPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): Ec2InstanceImageIdProperty | cdktn.IResolvable | undefined;
        set internalValue(value: Ec2InstanceImageIdProperty | cdktn.IResolvable | undefined);
        private _comparison?;
        get comparison(): string;
        set comparison(value: string);
        get comparisonInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class Ec2InstanceImageIdPropertyList extends cdktn.ComplexList {
        internalValue?: Ec2InstanceImageIdProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): Ec2InstanceImageIdPropertyOutputReference;
    }
    interface Ec2InstanceSubnetIdProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_filter#comparison AwsFilter#comparison}
        */
        readonly comparison: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_filter#value AwsFilter#value}
        */
        readonly value: string;
    }
    class Ec2InstanceSubnetIdPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): Ec2InstanceSubnetIdProperty | cdktn.IResolvable | undefined;
        set internalValue(value: Ec2InstanceSubnetIdProperty | cdktn.IResolvable | undefined);
        private _comparison?;
        get comparison(): string;
        set comparison(value: string);
        get comparisonInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class Ec2InstanceSubnetIdPropertyList extends cdktn.ComplexList {
        internalValue?: Ec2InstanceSubnetIdProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): Ec2InstanceSubnetIdPropertyOutputReference;
    }
    interface Ec2InstanceVpcIdProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_filter#comparison AwsFilter#comparison}
        */
        readonly comparison: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_filter#value AwsFilter#value}
        */
        readonly value: string;
    }
    class Ec2InstanceVpcIdPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): Ec2InstanceVpcIdProperty | cdktn.IResolvable | undefined;
        set internalValue(value: Ec2InstanceVpcIdProperty | cdktn.IResolvable | undefined);
        private _comparison?;
        get comparison(): string;
        set comparison(value: string);
        get comparisonInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class Ec2InstanceVpcIdPropertyList extends cdktn.ComplexList {
        internalValue?: Ec2InstanceVpcIdProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): Ec2InstanceVpcIdPropertyOutputReference;
    }
    interface EcrImageArchitectureProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_filter#comparison AwsFilter#comparison}
        */
        readonly comparison: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_filter#value AwsFilter#value}
        */
        readonly value: string;
    }
    class EcrImageArchitecturePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EcrImageArchitectureProperty | cdktn.IResolvable | undefined;
        set internalValue(value: EcrImageArchitectureProperty | cdktn.IResolvable | undefined);
        private _comparison?;
        get comparison(): string;
        set comparison(value: string);
        get comparisonInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class EcrImageArchitecturePropertyList extends cdktn.ComplexList {
        internalValue?: EcrImageArchitectureProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EcrImageArchitecturePropertyOutputReference;
    }
    interface EcrImageHashProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_filter#comparison AwsFilter#comparison}
        */
        readonly comparison: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_filter#value AwsFilter#value}
        */
        readonly value: string;
    }
    class EcrImageHashPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EcrImageHashProperty | cdktn.IResolvable | undefined;
        set internalValue(value: EcrImageHashProperty | cdktn.IResolvable | undefined);
        private _comparison?;
        get comparison(): string;
        set comparison(value: string);
        get comparisonInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class EcrImageHashPropertyList extends cdktn.ComplexList {
        internalValue?: EcrImageHashProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EcrImageHashPropertyOutputReference;
    }
    interface EcrImageInUseCountProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_filter#lower_inclusive AwsFilter#lower_inclusive}
        */
        readonly lowerInclusive: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_filter#upper_inclusive AwsFilter#upper_inclusive}
        */
        readonly upperInclusive: number;
    }
    class EcrImageInUseCountPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EcrImageInUseCountProperty | cdktn.IResolvable | undefined;
        set internalValue(value: EcrImageInUseCountProperty | cdktn.IResolvable | undefined);
        private _lowerInclusive?;
        get lowerInclusive(): number;
        set lowerInclusive(value: number);
        get lowerInclusiveInput(): number | undefined;
        private _upperInclusive?;
        get upperInclusive(): number;
        set upperInclusive(value: number);
        get upperInclusiveInput(): number | undefined;
    }
    class EcrImageInUseCountPropertyList extends cdktn.ComplexList {
        internalValue?: EcrImageInUseCountProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EcrImageInUseCountPropertyOutputReference;
    }
    interface EcrImageLastInUseAtProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_filter#end_inclusive AwsFilter#end_inclusive}
        */
        readonly endInclusive?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_filter#start_inclusive AwsFilter#start_inclusive}
        */
        readonly startInclusive?: string;
    }
    class EcrImageLastInUseAtPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EcrImageLastInUseAtProperty | cdktn.IResolvable | undefined;
        set internalValue(value: EcrImageLastInUseAtProperty | cdktn.IResolvable | undefined);
        private _endInclusive?;
        get endInclusive(): string;
        set endInclusive(value: string);
        resetEndInclusive(): void;
        get endInclusiveInput(): string | undefined;
        private _startInclusive?;
        get startInclusive(): string;
        set startInclusive(value: string);
        resetStartInclusive(): void;
        get startInclusiveInput(): string | undefined;
    }
    class EcrImageLastInUseAtPropertyList extends cdktn.ComplexList {
        internalValue?: EcrImageLastInUseAtProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EcrImageLastInUseAtPropertyOutputReference;
    }
    interface EcrImagePushedAtProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_filter#end_inclusive AwsFilter#end_inclusive}
        */
        readonly endInclusive?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_filter#start_inclusive AwsFilter#start_inclusive}
        */
        readonly startInclusive?: string;
    }
    class EcrImagePushedAtPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EcrImagePushedAtProperty | cdktn.IResolvable | undefined;
        set internalValue(value: EcrImagePushedAtProperty | cdktn.IResolvable | undefined);
        private _endInclusive?;
        get endInclusive(): string;
        set endInclusive(value: string);
        resetEndInclusive(): void;
        get endInclusiveInput(): string | undefined;
        private _startInclusive?;
        get startInclusive(): string;
        set startInclusive(value: string);
        resetStartInclusive(): void;
        get startInclusiveInput(): string | undefined;
    }
    class EcrImagePushedAtPropertyList extends cdktn.ComplexList {
        internalValue?: EcrImagePushedAtProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EcrImagePushedAtPropertyOutputReference;
    }
    interface EcrImageRegistryProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_filter#comparison AwsFilter#comparison}
        */
        readonly comparison: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_filter#value AwsFilter#value}
        */
        readonly value: string;
    }
    class EcrImageRegistryPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EcrImageRegistryProperty | cdktn.IResolvable | undefined;
        set internalValue(value: EcrImageRegistryProperty | cdktn.IResolvable | undefined);
        private _comparison?;
        get comparison(): string;
        set comparison(value: string);
        get comparisonInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class EcrImageRegistryPropertyList extends cdktn.ComplexList {
        internalValue?: EcrImageRegistryProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EcrImageRegistryPropertyOutputReference;
    }
    interface EcrImageRepositoryNameProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_filter#comparison AwsFilter#comparison}
        */
        readonly comparison: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_filter#value AwsFilter#value}
        */
        readonly value: string;
    }
    class EcrImageRepositoryNamePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EcrImageRepositoryNameProperty | cdktn.IResolvable | undefined;
        set internalValue(value: EcrImageRepositoryNameProperty | cdktn.IResolvable | undefined);
        private _comparison?;
        get comparison(): string;
        set comparison(value: string);
        get comparisonInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class EcrImageRepositoryNamePropertyList extends cdktn.ComplexList {
        internalValue?: EcrImageRepositoryNameProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EcrImageRepositoryNamePropertyOutputReference;
    }
    interface EcrImageTagsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_filter#comparison AwsFilter#comparison}
        */
        readonly comparison: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_filter#value AwsFilter#value}
        */
        readonly value: string;
    }
    class EcrImageTagsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EcrImageTagsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: EcrImageTagsProperty | cdktn.IResolvable | undefined);
        private _comparison?;
        get comparison(): string;
        set comparison(value: string);
        get comparisonInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class EcrImageTagsPropertyList extends cdktn.ComplexList {
        internalValue?: EcrImageTagsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EcrImageTagsPropertyOutputReference;
    }
    interface EpssScoreProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_filter#lower_inclusive AwsFilter#lower_inclusive}
        */
        readonly lowerInclusive: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_filter#upper_inclusive AwsFilter#upper_inclusive}
        */
        readonly upperInclusive: number;
    }
    class EpssScorePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EpssScoreProperty | cdktn.IResolvable | undefined;
        set internalValue(value: EpssScoreProperty | cdktn.IResolvable | undefined);
        private _lowerInclusive?;
        get lowerInclusive(): number;
        set lowerInclusive(value: number);
        get lowerInclusiveInput(): number | undefined;
        private _upperInclusive?;
        get upperInclusive(): number;
        set upperInclusive(value: number);
        get upperInclusiveInput(): number | undefined;
    }
    class EpssScorePropertyList extends cdktn.ComplexList {
        internalValue?: EpssScoreProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EpssScorePropertyOutputReference;
    }
    interface ExploitAvailableProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_filter#comparison AwsFilter#comparison}
        */
        readonly comparison: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_filter#value AwsFilter#value}
        */
        readonly value: string;
    }
    class ExploitAvailablePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ExploitAvailableProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ExploitAvailableProperty | cdktn.IResolvable | undefined);
        private _comparison?;
        get comparison(): string;
        set comparison(value: string);
        get comparisonInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class ExploitAvailablePropertyList extends cdktn.ComplexList {
        internalValue?: ExploitAvailableProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ExploitAvailablePropertyOutputReference;
    }
    interface FindingArnProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_filter#comparison AwsFilter#comparison}
        */
        readonly comparison: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_filter#value AwsFilter#value}
        */
        readonly value: string;
    }
    class FindingArnPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): FindingArnProperty | cdktn.IResolvable | undefined;
        set internalValue(value: FindingArnProperty | cdktn.IResolvable | undefined);
        private _comparison?;
        get comparison(): string;
        set comparison(value: string);
        get comparisonInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class FindingArnPropertyList extends cdktn.ComplexList {
        internalValue?: FindingArnProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): FindingArnPropertyOutputReference;
    }
    interface FindingStatusProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_filter#comparison AwsFilter#comparison}
        */
        readonly comparison: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_filter#value AwsFilter#value}
        */
        readonly value: string;
    }
    class FindingStatusPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): FindingStatusProperty | cdktn.IResolvable | undefined;
        set internalValue(value: FindingStatusProperty | cdktn.IResolvable | undefined);
        private _comparison?;
        get comparison(): string;
        set comparison(value: string);
        get comparisonInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class FindingStatusPropertyList extends cdktn.ComplexList {
        internalValue?: FindingStatusProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): FindingStatusPropertyOutputReference;
    }
    interface FindingTypeProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_filter#comparison AwsFilter#comparison}
        */
        readonly comparison: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_filter#value AwsFilter#value}
        */
        readonly value: string;
    }
    class FindingTypePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): FindingTypeProperty | cdktn.IResolvable | undefined;
        set internalValue(value: FindingTypeProperty | cdktn.IResolvable | undefined);
        private _comparison?;
        get comparison(): string;
        set comparison(value: string);
        get comparisonInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class FindingTypePropertyList extends cdktn.ComplexList {
        internalValue?: FindingTypeProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): FindingTypePropertyOutputReference;
    }
    interface FirstObservedAtProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_filter#end_inclusive AwsFilter#end_inclusive}
        */
        readonly endInclusive?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_filter#start_inclusive AwsFilter#start_inclusive}
        */
        readonly startInclusive?: string;
    }
    class FirstObservedAtPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): FirstObservedAtProperty | cdktn.IResolvable | undefined;
        set internalValue(value: FirstObservedAtProperty | cdktn.IResolvable | undefined);
        private _endInclusive?;
        get endInclusive(): string;
        set endInclusive(value: string);
        resetEndInclusive(): void;
        get endInclusiveInput(): string | undefined;
        private _startInclusive?;
        get startInclusive(): string;
        set startInclusive(value: string);
        resetStartInclusive(): void;
        get startInclusiveInput(): string | undefined;
    }
    class FirstObservedAtPropertyList extends cdktn.ComplexList {
        internalValue?: FirstObservedAtProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): FirstObservedAtPropertyOutputReference;
    }
    interface FixAvailableProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_filter#comparison AwsFilter#comparison}
        */
        readonly comparison: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_filter#value AwsFilter#value}
        */
        readonly value: string;
    }
    class FixAvailablePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): FixAvailableProperty | cdktn.IResolvable | undefined;
        set internalValue(value: FixAvailableProperty | cdktn.IResolvable | undefined);
        private _comparison?;
        get comparison(): string;
        set comparison(value: string);
        get comparisonInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class FixAvailablePropertyList extends cdktn.ComplexList {
        internalValue?: FixAvailableProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): FixAvailablePropertyOutputReference;
    }
    interface InspectorScoreProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_filter#lower_inclusive AwsFilter#lower_inclusive}
        */
        readonly lowerInclusive: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_filter#upper_inclusive AwsFilter#upper_inclusive}
        */
        readonly upperInclusive: number;
    }
    class InspectorScorePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): InspectorScoreProperty | cdktn.IResolvable | undefined;
        set internalValue(value: InspectorScoreProperty | cdktn.IResolvable | undefined);
        private _lowerInclusive?;
        get lowerInclusive(): number;
        set lowerInclusive(value: number);
        get lowerInclusiveInput(): number | undefined;
        private _upperInclusive?;
        get upperInclusive(): number;
        set upperInclusive(value: number);
        get upperInclusiveInput(): number | undefined;
    }
    class InspectorScorePropertyList extends cdktn.ComplexList {
        internalValue?: InspectorScoreProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): InspectorScorePropertyOutputReference;
    }
    interface LambdaFunctionExecutionRoleArnProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_filter#comparison AwsFilter#comparison}
        */
        readonly comparison: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_filter#value AwsFilter#value}
        */
        readonly value: string;
    }
    class LambdaFunctionExecutionRoleArnPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): LambdaFunctionExecutionRoleArnProperty | cdktn.IResolvable | undefined;
        set internalValue(value: LambdaFunctionExecutionRoleArnProperty | cdktn.IResolvable | undefined);
        private _comparison?;
        get comparison(): string;
        set comparison(value: string);
        get comparisonInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class LambdaFunctionExecutionRoleArnPropertyList extends cdktn.ComplexList {
        internalValue?: LambdaFunctionExecutionRoleArnProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): LambdaFunctionExecutionRoleArnPropertyOutputReference;
    }
    interface LambdaFunctionLastModifiedAtProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_filter#end_inclusive AwsFilter#end_inclusive}
        */
        readonly endInclusive?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_filter#start_inclusive AwsFilter#start_inclusive}
        */
        readonly startInclusive?: string;
    }
    class LambdaFunctionLastModifiedAtPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): LambdaFunctionLastModifiedAtProperty | cdktn.IResolvable | undefined;
        set internalValue(value: LambdaFunctionLastModifiedAtProperty | cdktn.IResolvable | undefined);
        private _endInclusive?;
        get endInclusive(): string;
        set endInclusive(value: string);
        resetEndInclusive(): void;
        get endInclusiveInput(): string | undefined;
        private _startInclusive?;
        get startInclusive(): string;
        set startInclusive(value: string);
        resetStartInclusive(): void;
        get startInclusiveInput(): string | undefined;
    }
    class LambdaFunctionLastModifiedAtPropertyList extends cdktn.ComplexList {
        internalValue?: LambdaFunctionLastModifiedAtProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): LambdaFunctionLastModifiedAtPropertyOutputReference;
    }
    interface LambdaFunctionLayersProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_filter#comparison AwsFilter#comparison}
        */
        readonly comparison: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_filter#value AwsFilter#value}
        */
        readonly value: string;
    }
    class LambdaFunctionLayersPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): LambdaFunctionLayersProperty | cdktn.IResolvable | undefined;
        set internalValue(value: LambdaFunctionLayersProperty | cdktn.IResolvable | undefined);
        private _comparison?;
        get comparison(): string;
        set comparison(value: string);
        get comparisonInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class LambdaFunctionLayersPropertyList extends cdktn.ComplexList {
        internalValue?: LambdaFunctionLayersProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): LambdaFunctionLayersPropertyOutputReference;
    }
    interface LambdaFunctionNameProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_filter#comparison AwsFilter#comparison}
        */
        readonly comparison: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_filter#value AwsFilter#value}
        */
        readonly value: string;
    }
    class LambdaFunctionNamePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): LambdaFunctionNameProperty | cdktn.IResolvable | undefined;
        set internalValue(value: LambdaFunctionNameProperty | cdktn.IResolvable | undefined);
        private _comparison?;
        get comparison(): string;
        set comparison(value: string);
        get comparisonInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class LambdaFunctionNamePropertyList extends cdktn.ComplexList {
        internalValue?: LambdaFunctionNameProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): LambdaFunctionNamePropertyOutputReference;
    }
    interface LambdaFunctionRuntimeProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_filter#comparison AwsFilter#comparison}
        */
        readonly comparison: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_filter#value AwsFilter#value}
        */
        readonly value: string;
    }
    class LambdaFunctionRuntimePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): LambdaFunctionRuntimeProperty | cdktn.IResolvable | undefined;
        set internalValue(value: LambdaFunctionRuntimeProperty | cdktn.IResolvable | undefined);
        private _comparison?;
        get comparison(): string;
        set comparison(value: string);
        get comparisonInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class LambdaFunctionRuntimePropertyList extends cdktn.ComplexList {
        internalValue?: LambdaFunctionRuntimeProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): LambdaFunctionRuntimePropertyOutputReference;
    }
    interface LastObservedAtProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_filter#end_inclusive AwsFilter#end_inclusive}
        */
        readonly endInclusive?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_filter#start_inclusive AwsFilter#start_inclusive}
        */
        readonly startInclusive?: string;
    }
    class LastObservedAtPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): LastObservedAtProperty | cdktn.IResolvable | undefined;
        set internalValue(value: LastObservedAtProperty | cdktn.IResolvable | undefined);
        private _endInclusive?;
        get endInclusive(): string;
        set endInclusive(value: string);
        resetEndInclusive(): void;
        get endInclusiveInput(): string | undefined;
        private _startInclusive?;
        get startInclusive(): string;
        set startInclusive(value: string);
        resetStartInclusive(): void;
        get startInclusiveInput(): string | undefined;
    }
    class LastObservedAtPropertyList extends cdktn.ComplexList {
        internalValue?: LastObservedAtProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): LastObservedAtPropertyOutputReference;
    }
    interface NetworkProtocolProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_filter#comparison AwsFilter#comparison}
        */
        readonly comparison: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_filter#value AwsFilter#value}
        */
        readonly value: string;
    }
    class NetworkProtocolPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): NetworkProtocolProperty | cdktn.IResolvable | undefined;
        set internalValue(value: NetworkProtocolProperty | cdktn.IResolvable | undefined);
        private _comparison?;
        get comparison(): string;
        set comparison(value: string);
        get comparisonInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class NetworkProtocolPropertyList extends cdktn.ComplexList {
        internalValue?: NetworkProtocolProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): NetworkProtocolPropertyOutputReference;
    }
    interface PortRangeProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_filter#begin_inclusive AwsFilter#begin_inclusive}
        */
        readonly beginInclusive: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_filter#end_inclusive AwsFilter#end_inclusive}
        */
        readonly endInclusive: number;
    }
    class PortRangePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): PortRangeProperty | cdktn.IResolvable | undefined;
        set internalValue(value: PortRangeProperty | cdktn.IResolvable | undefined);
        private _beginInclusive?;
        get beginInclusive(): number;
        set beginInclusive(value: number);
        get beginInclusiveInput(): number | undefined;
        private _endInclusive?;
        get endInclusive(): number;
        set endInclusive(value: number);
        get endInclusiveInput(): number | undefined;
    }
    class PortRangePropertyList extends cdktn.ComplexList {
        internalValue?: PortRangeProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): PortRangePropertyOutputReference;
    }
    interface RelatedVulnerabilitiesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_filter#comparison AwsFilter#comparison}
        */
        readonly comparison: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_filter#value AwsFilter#value}
        */
        readonly value: string;
    }
    class RelatedVulnerabilitiesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RelatedVulnerabilitiesProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RelatedVulnerabilitiesProperty | cdktn.IResolvable | undefined);
        private _comparison?;
        get comparison(): string;
        set comparison(value: string);
        get comparisonInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class RelatedVulnerabilitiesPropertyList extends cdktn.ComplexList {
        internalValue?: RelatedVulnerabilitiesProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RelatedVulnerabilitiesPropertyOutputReference;
    }
    interface ResourceIdProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_filter#comparison AwsFilter#comparison}
        */
        readonly comparison: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_filter#value AwsFilter#value}
        */
        readonly value: string;
    }
    class ResourceIdPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ResourceIdProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ResourceIdProperty | cdktn.IResolvable | undefined);
        private _comparison?;
        get comparison(): string;
        set comparison(value: string);
        get comparisonInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class ResourceIdPropertyList extends cdktn.ComplexList {
        internalValue?: ResourceIdProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ResourceIdPropertyOutputReference;
    }
    interface ResourceTagsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_filter#comparison AwsFilter#comparison}
        */
        readonly comparison: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_filter#key AwsFilter#key}
        */
        readonly key: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_filter#value AwsFilter#value}
        */
        readonly value: string;
    }
    class ResourceTagsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ResourceTagsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ResourceTagsProperty | cdktn.IResolvable | undefined);
        private _comparison?;
        get comparison(): string;
        set comparison(value: string);
        get comparisonInput(): string | undefined;
        private _key?;
        get key(): string;
        set key(value: string);
        get keyInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class ResourceTagsPropertyList extends cdktn.ComplexList {
        internalValue?: ResourceTagsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ResourceTagsPropertyOutputReference;
    }
    interface ResourceTypeProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_filter#comparison AwsFilter#comparison}
        */
        readonly comparison: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_filter#value AwsFilter#value}
        */
        readonly value: string;
    }
    class ResourceTypePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ResourceTypeProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ResourceTypeProperty | cdktn.IResolvable | undefined);
        private _comparison?;
        get comparison(): string;
        set comparison(value: string);
        get comparisonInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class ResourceTypePropertyList extends cdktn.ComplexList {
        internalValue?: ResourceTypeProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ResourceTypePropertyOutputReference;
    }
    interface SeverityProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_filter#comparison AwsFilter#comparison}
        */
        readonly comparison: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_filter#value AwsFilter#value}
        */
        readonly value: string;
    }
    class SeverityPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SeverityProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SeverityProperty | cdktn.IResolvable | undefined);
        private _comparison?;
        get comparison(): string;
        set comparison(value: string);
        get comparisonInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class SeverityPropertyList extends cdktn.ComplexList {
        internalValue?: SeverityProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SeverityPropertyOutputReference;
    }
    interface TitleProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_filter#comparison AwsFilter#comparison}
        */
        readonly comparison: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_filter#value AwsFilter#value}
        */
        readonly value: string;
    }
    class TitlePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TitleProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TitleProperty | cdktn.IResolvable | undefined);
        private _comparison?;
        get comparison(): string;
        set comparison(value: string);
        get comparisonInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class TitlePropertyList extends cdktn.ComplexList {
        internalValue?: TitleProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TitlePropertyOutputReference;
    }
    interface UpdatedAtProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_filter#end_inclusive AwsFilter#end_inclusive}
        */
        readonly endInclusive?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_filter#start_inclusive AwsFilter#start_inclusive}
        */
        readonly startInclusive?: string;
    }
    class UpdatedAtPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): UpdatedAtProperty | cdktn.IResolvable | undefined;
        set internalValue(value: UpdatedAtProperty | cdktn.IResolvable | undefined);
        private _endInclusive?;
        get endInclusive(): string;
        set endInclusive(value: string);
        resetEndInclusive(): void;
        get endInclusiveInput(): string | undefined;
        private _startInclusive?;
        get startInclusive(): string;
        set startInclusive(value: string);
        resetStartInclusive(): void;
        get startInclusiveInput(): string | undefined;
    }
    class UpdatedAtPropertyList extends cdktn.ComplexList {
        internalValue?: UpdatedAtProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): UpdatedAtPropertyOutputReference;
    }
    interface VendorSeverityProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_filter#comparison AwsFilter#comparison}
        */
        readonly comparison: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_filter#value AwsFilter#value}
        */
        readonly value: string;
    }
    class VendorSeverityPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): VendorSeverityProperty | cdktn.IResolvable | undefined;
        set internalValue(value: VendorSeverityProperty | cdktn.IResolvable | undefined);
        private _comparison?;
        get comparison(): string;
        set comparison(value: string);
        get comparisonInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class VendorSeverityPropertyList extends cdktn.ComplexList {
        internalValue?: VendorSeverityProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): VendorSeverityPropertyOutputReference;
    }
    interface VulnerabilityIdProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_filter#comparison AwsFilter#comparison}
        */
        readonly comparison: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_filter#value AwsFilter#value}
        */
        readonly value: string;
    }
    class VulnerabilityIdPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): VulnerabilityIdProperty | cdktn.IResolvable | undefined;
        set internalValue(value: VulnerabilityIdProperty | cdktn.IResolvable | undefined);
        private _comparison?;
        get comparison(): string;
        set comparison(value: string);
        get comparisonInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class VulnerabilityIdPropertyList extends cdktn.ComplexList {
        internalValue?: VulnerabilityIdProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): VulnerabilityIdPropertyOutputReference;
    }
    interface VulnerabilitySourceProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_filter#comparison AwsFilter#comparison}
        */
        readonly comparison: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_filter#value AwsFilter#value}
        */
        readonly value: string;
    }
    class VulnerabilitySourcePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): VulnerabilitySourceProperty | cdktn.IResolvable | undefined;
        set internalValue(value: VulnerabilitySourceProperty | cdktn.IResolvable | undefined);
        private _comparison?;
        get comparison(): string;
        set comparison(value: string);
        get comparisonInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class VulnerabilitySourcePropertyList extends cdktn.ComplexList {
        internalValue?: VulnerabilitySourceProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): VulnerabilitySourcePropertyOutputReference;
    }
    interface ArchitectureProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_filter#comparison AwsFilter#comparison}
        */
        readonly comparison: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_filter#value AwsFilter#value}
        */
        readonly value: string;
    }
    class ArchitecturePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ArchitectureProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ArchitectureProperty | cdktn.IResolvable | undefined);
        private _comparison?;
        get comparison(): string;
        set comparison(value: string);
        get comparisonInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class ArchitecturePropertyList extends cdktn.ComplexList {
        internalValue?: ArchitectureProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ArchitecturePropertyOutputReference;
    }
    interface EpochProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_filter#lower_inclusive AwsFilter#lower_inclusive}
        */
        readonly lowerInclusive: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_filter#upper_inclusive AwsFilter#upper_inclusive}
        */
        readonly upperInclusive: number;
    }
    class EpochPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EpochProperty | cdktn.IResolvable | undefined;
        set internalValue(value: EpochProperty | cdktn.IResolvable | undefined);
        private _lowerInclusive?;
        get lowerInclusive(): number;
        set lowerInclusive(value: number);
        get lowerInclusiveInput(): number | undefined;
        private _upperInclusive?;
        get upperInclusive(): number;
        set upperInclusive(value: number);
        get upperInclusiveInput(): number | undefined;
    }
    class EpochPropertyList extends cdktn.ComplexList {
        internalValue?: EpochProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EpochPropertyOutputReference;
    }
    interface FilePathProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_filter#comparison AwsFilter#comparison}
        */
        readonly comparison: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_filter#value AwsFilter#value}
        */
        readonly value: string;
    }
    class FilePathPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): FilePathProperty | cdktn.IResolvable | undefined;
        set internalValue(value: FilePathProperty | cdktn.IResolvable | undefined);
        private _comparison?;
        get comparison(): string;
        set comparison(value: string);
        get comparisonInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class FilePathPropertyList extends cdktn.ComplexList {
        internalValue?: FilePathProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): FilePathPropertyOutputReference;
    }
    interface NameProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_filter#comparison AwsFilter#comparison}
        */
        readonly comparison: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_filter#value AwsFilter#value}
        */
        readonly value: string;
    }
    class NamePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): NameProperty | cdktn.IResolvable | undefined;
        set internalValue(value: NameProperty | cdktn.IResolvable | undefined);
        private _comparison?;
        get comparison(): string;
        set comparison(value: string);
        get comparisonInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class NamePropertyList extends cdktn.ComplexList {
        internalValue?: NameProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): NamePropertyOutputReference;
    }
    interface ReleaseProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_filter#comparison AwsFilter#comparison}
        */
        readonly comparison: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_filter#value AwsFilter#value}
        */
        readonly value: string;
    }
    class ReleasePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ReleaseProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ReleaseProperty | cdktn.IResolvable | undefined);
        private _comparison?;
        get comparison(): string;
        set comparison(value: string);
        get comparisonInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class ReleasePropertyList extends cdktn.ComplexList {
        internalValue?: ReleaseProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ReleasePropertyOutputReference;
    }
    interface SourceLambdaLayerArnProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_filter#comparison AwsFilter#comparison}
        */
        readonly comparison: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_filter#value AwsFilter#value}
        */
        readonly value: string;
    }
    class SourceLambdaLayerArnPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SourceLambdaLayerArnProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SourceLambdaLayerArnProperty | cdktn.IResolvable | undefined);
        private _comparison?;
        get comparison(): string;
        set comparison(value: string);
        get comparisonInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class SourceLambdaLayerArnPropertyList extends cdktn.ComplexList {
        internalValue?: SourceLambdaLayerArnProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SourceLambdaLayerArnPropertyOutputReference;
    }
    interface SourceLayerHashProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_filter#comparison AwsFilter#comparison}
        */
        readonly comparison: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_filter#value AwsFilter#value}
        */
        readonly value: string;
    }
    class SourceLayerHashPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SourceLayerHashProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SourceLayerHashProperty | cdktn.IResolvable | undefined);
        private _comparison?;
        get comparison(): string;
        set comparison(value: string);
        get comparisonInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class SourceLayerHashPropertyList extends cdktn.ComplexList {
        internalValue?: SourceLayerHashProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SourceLayerHashPropertyOutputReference;
    }
    interface VersionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_filter#comparison AwsFilter#comparison}
        */
        readonly comparison: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_filter#value AwsFilter#value}
        */
        readonly value: string;
    }
    class VersionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): VersionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: VersionProperty | cdktn.IResolvable | undefined);
        private _comparison?;
        get comparison(): string;
        set comparison(value: string);
        get comparisonInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class VersionPropertyList extends cdktn.ComplexList {
        internalValue?: VersionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): VersionPropertyOutputReference;
    }
    interface VulnerablePackagesProperty {
        /**
        * architecture block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_filter#architecture AwsFilter#architecture}
        */
        readonly architecture?: ArchitectureProperty[] | cdktn.IResolvable;
        /**
        * epoch block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_filter#epoch AwsFilter#epoch}
        */
        readonly epoch?: EpochProperty[] | cdktn.IResolvable;
        /**
        * file_path block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_filter#file_path AwsFilter#file_path}
        */
        readonly filePath?: FilePathProperty[] | cdktn.IResolvable;
        /**
        * name block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_filter#name AwsFilter#name}
        */
        readonly name?: NameProperty[] | cdktn.IResolvable;
        /**
        * release block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_filter#release AwsFilter#release}
        */
        readonly release?: ReleaseProperty[] | cdktn.IResolvable;
        /**
        * source_lambda_layer_arn block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_filter#source_lambda_layer_arn AwsFilter#source_lambda_layer_arn}
        */
        readonly sourceLambdaLayerArn?: SourceLambdaLayerArnProperty[] | cdktn.IResolvable;
        /**
        * source_layer_hash block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_filter#source_layer_hash AwsFilter#source_layer_hash}
        */
        readonly sourceLayerHash?: SourceLayerHashProperty[] | cdktn.IResolvable;
        /**
        * version block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_filter#version AwsFilter#version}
        */
        readonly version?: VersionProperty[] | cdktn.IResolvable;
    }
    class VulnerablePackagesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): VulnerablePackagesProperty | cdktn.IResolvable | undefined;
        set internalValue(value: VulnerablePackagesProperty | cdktn.IResolvable | undefined);
        private _architecture;
        get architecture(): ArchitecturePropertyList;
        putArchitecture(value: ArchitectureProperty[] | cdktn.IResolvable): void;
        resetArchitecture(): void;
        get architectureInput(): cdktn.IResolvable | ArchitectureProperty[] | undefined;
        private _epoch;
        get epoch(): EpochPropertyList;
        putEpoch(value: EpochProperty[] | cdktn.IResolvable): void;
        resetEpoch(): void;
        get epochInput(): cdktn.IResolvable | EpochProperty[] | undefined;
        private _filePath;
        get filePath(): FilePathPropertyList;
        putFilePath(value: FilePathProperty[] | cdktn.IResolvable): void;
        resetFilePath(): void;
        get filePathInput(): cdktn.IResolvable | FilePathProperty[] | undefined;
        private _name;
        get name(): NamePropertyList;
        putName(value: NameProperty[] | cdktn.IResolvable): void;
        resetName(): void;
        get nameInput(): cdktn.IResolvable | NameProperty[] | undefined;
        private _release;
        get release(): ReleasePropertyList;
        putRelease(value: ReleaseProperty[] | cdktn.IResolvable): void;
        resetRelease(): void;
        get releaseInput(): cdktn.IResolvable | ReleaseProperty[] | undefined;
        private _sourceLambdaLayerArn;
        get sourceLambdaLayerArn(): SourceLambdaLayerArnPropertyList;
        putSourceLambdaLayerArn(value: SourceLambdaLayerArnProperty[] | cdktn.IResolvable): void;
        resetSourceLambdaLayerArn(): void;
        get sourceLambdaLayerArnInput(): cdktn.IResolvable | SourceLambdaLayerArnProperty[] | undefined;
        private _sourceLayerHash;
        get sourceLayerHash(): SourceLayerHashPropertyList;
        putSourceLayerHash(value: SourceLayerHashProperty[] | cdktn.IResolvable): void;
        resetSourceLayerHash(): void;
        get sourceLayerHashInput(): cdktn.IResolvable | SourceLayerHashProperty[] | undefined;
        private _version;
        get version(): VersionPropertyList;
        putVersion(value: VersionProperty[] | cdktn.IResolvable): void;
        resetVersion(): void;
        get versionInput(): cdktn.IResolvable | VersionProperty[] | undefined;
    }
    class VulnerablePackagesPropertyList extends cdktn.ComplexList {
        internalValue?: VulnerablePackagesProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): VulnerablePackagesPropertyOutputReference;
    }
    interface FilterCriteriaProperty {
        /**
        * aws_account_id block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_filter#aws_account_id AwsFilter#aws_account_id}
        */
        readonly awsAccountId?: AwsAccountIdProperty[] | cdktn.IResolvable;
        /**
        * code_repository_project_name block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_filter#code_repository_project_name AwsFilter#code_repository_project_name}
        */
        readonly codeRepositoryProjectName?: CodeRepositoryProjectNameProperty[] | cdktn.IResolvable;
        /**
        * code_repository_provider_type block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_filter#code_repository_provider_type AwsFilter#code_repository_provider_type}
        */
        readonly codeRepositoryProviderType?: CodeRepositoryProviderTypeProperty[] | cdktn.IResolvable;
        /**
        * code_vulnerability_detector_name block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_filter#code_vulnerability_detector_name AwsFilter#code_vulnerability_detector_name}
        */
        readonly codeVulnerabilityDetectorName?: CodeVulnerabilityDetectorNameProperty[] | cdktn.IResolvable;
        /**
        * code_vulnerability_detector_tags block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_filter#code_vulnerability_detector_tags AwsFilter#code_vulnerability_detector_tags}
        */
        readonly codeVulnerabilityDetectorTags?: CodeVulnerabilityDetectorTagsProperty[] | cdktn.IResolvable;
        /**
        * code_vulnerability_file_path block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_filter#code_vulnerability_file_path AwsFilter#code_vulnerability_file_path}
        */
        readonly codeVulnerabilityFilePath?: CodeVulnerabilityFilePathProperty[] | cdktn.IResolvable;
        /**
        * component_id block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_filter#component_id AwsFilter#component_id}
        */
        readonly componentId?: ComponentIdProperty[] | cdktn.IResolvable;
        /**
        * component_type block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_filter#component_type AwsFilter#component_type}
        */
        readonly componentType?: ComponentTypeProperty[] | cdktn.IResolvable;
        /**
        * ec2_instance_image_id block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_filter#ec2_instance_image_id AwsFilter#ec2_instance_image_id}
        */
        readonly ec2InstanceImageId?: Ec2InstanceImageIdProperty[] | cdktn.IResolvable;
        /**
        * ec2_instance_subnet_id block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_filter#ec2_instance_subnet_id AwsFilter#ec2_instance_subnet_id}
        */
        readonly ec2InstanceSubnetId?: Ec2InstanceSubnetIdProperty[] | cdktn.IResolvable;
        /**
        * ec2_instance_vpc_id block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_filter#ec2_instance_vpc_id AwsFilter#ec2_instance_vpc_id}
        */
        readonly ec2InstanceVpcId?: Ec2InstanceVpcIdProperty[] | cdktn.IResolvable;
        /**
        * ecr_image_architecture block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_filter#ecr_image_architecture AwsFilter#ecr_image_architecture}
        */
        readonly ecrImageArchitecture?: EcrImageArchitectureProperty[] | cdktn.IResolvable;
        /**
        * ecr_image_hash block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_filter#ecr_image_hash AwsFilter#ecr_image_hash}
        */
        readonly ecrImageHash?: EcrImageHashProperty[] | cdktn.IResolvable;
        /**
        * ecr_image_in_use_count block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_filter#ecr_image_in_use_count AwsFilter#ecr_image_in_use_count}
        */
        readonly ecrImageInUseCount?: EcrImageInUseCountProperty[] | cdktn.IResolvable;
        /**
        * ecr_image_last_in_use_at block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_filter#ecr_image_last_in_use_at AwsFilter#ecr_image_last_in_use_at}
        */
        readonly ecrImageLastInUseAt?: EcrImageLastInUseAtProperty[] | cdktn.IResolvable;
        /**
        * ecr_image_pushed_at block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_filter#ecr_image_pushed_at AwsFilter#ecr_image_pushed_at}
        */
        readonly ecrImagePushedAt?: EcrImagePushedAtProperty[] | cdktn.IResolvable;
        /**
        * ecr_image_registry block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_filter#ecr_image_registry AwsFilter#ecr_image_registry}
        */
        readonly ecrImageRegistry?: EcrImageRegistryProperty[] | cdktn.IResolvable;
        /**
        * ecr_image_repository_name block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_filter#ecr_image_repository_name AwsFilter#ecr_image_repository_name}
        */
        readonly ecrImageRepositoryName?: EcrImageRepositoryNameProperty[] | cdktn.IResolvable;
        /**
        * ecr_image_tags block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_filter#ecr_image_tags AwsFilter#ecr_image_tags}
        */
        readonly ecrImageTags?: EcrImageTagsProperty[] | cdktn.IResolvable;
        /**
        * epss_score block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_filter#epss_score AwsFilter#epss_score}
        */
        readonly epssScore?: EpssScoreProperty[] | cdktn.IResolvable;
        /**
        * exploit_available block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_filter#exploit_available AwsFilter#exploit_available}
        */
        readonly exploitAvailable?: ExploitAvailableProperty[] | cdktn.IResolvable;
        /**
        * finding_arn block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_filter#finding_arn AwsFilter#finding_arn}
        */
        readonly findingArn?: FindingArnProperty[] | cdktn.IResolvable;
        /**
        * finding_status block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_filter#finding_status AwsFilter#finding_status}
        */
        readonly findingStatus?: FindingStatusProperty[] | cdktn.IResolvable;
        /**
        * finding_type block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_filter#finding_type AwsFilter#finding_type}
        */
        readonly findingType?: FindingTypeProperty[] | cdktn.IResolvable;
        /**
        * first_observed_at block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_filter#first_observed_at AwsFilter#first_observed_at}
        */
        readonly firstObservedAt?: FirstObservedAtProperty[] | cdktn.IResolvable;
        /**
        * fix_available block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_filter#fix_available AwsFilter#fix_available}
        */
        readonly fixAvailable?: FixAvailableProperty[] | cdktn.IResolvable;
        /**
        * inspector_score block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_filter#inspector_score AwsFilter#inspector_score}
        */
        readonly inspectorScore?: InspectorScoreProperty[] | cdktn.IResolvable;
        /**
        * lambda_function_execution_role_arn block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_filter#lambda_function_execution_role_arn AwsFilter#lambda_function_execution_role_arn}
        */
        readonly lambdaFunctionExecutionRoleArn?: LambdaFunctionExecutionRoleArnProperty[] | cdktn.IResolvable;
        /**
        * lambda_function_last_modified_at block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_filter#lambda_function_last_modified_at AwsFilter#lambda_function_last_modified_at}
        */
        readonly lambdaFunctionLastModifiedAt?: LambdaFunctionLastModifiedAtProperty[] | cdktn.IResolvable;
        /**
        * lambda_function_layers block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_filter#lambda_function_layers AwsFilter#lambda_function_layers}
        */
        readonly lambdaFunctionLayers?: LambdaFunctionLayersProperty[] | cdktn.IResolvable;
        /**
        * lambda_function_name block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_filter#lambda_function_name AwsFilter#lambda_function_name}
        */
        readonly lambdaFunctionName?: LambdaFunctionNameProperty[] | cdktn.IResolvable;
        /**
        * lambda_function_runtime block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_filter#lambda_function_runtime AwsFilter#lambda_function_runtime}
        */
        readonly lambdaFunctionRuntime?: LambdaFunctionRuntimeProperty[] | cdktn.IResolvable;
        /**
        * last_observed_at block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_filter#last_observed_at AwsFilter#last_observed_at}
        */
        readonly lastObservedAt?: LastObservedAtProperty[] | cdktn.IResolvable;
        /**
        * network_protocol block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_filter#network_protocol AwsFilter#network_protocol}
        */
        readonly networkProtocol?: NetworkProtocolProperty[] | cdktn.IResolvable;
        /**
        * port_range block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_filter#port_range AwsFilter#port_range}
        */
        readonly portRange?: PortRangeProperty[] | cdktn.IResolvable;
        /**
        * related_vulnerabilities block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_filter#related_vulnerabilities AwsFilter#related_vulnerabilities}
        */
        readonly relatedVulnerabilities?: RelatedVulnerabilitiesProperty[] | cdktn.IResolvable;
        /**
        * resource_id block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_filter#resource_id AwsFilter#resource_id}
        */
        readonly resourceId?: ResourceIdProperty[] | cdktn.IResolvable;
        /**
        * resource_tags block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_filter#resource_tags AwsFilter#resource_tags}
        */
        readonly resourceTags?: ResourceTagsProperty[] | cdktn.IResolvable;
        /**
        * resource_type block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_filter#resource_type AwsFilter#resource_type}
        */
        readonly resourceType?: ResourceTypeProperty[] | cdktn.IResolvable;
        /**
        * severity block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_filter#severity AwsFilter#severity}
        */
        readonly severity?: SeverityProperty[] | cdktn.IResolvable;
        /**
        * title block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_filter#title AwsFilter#title}
        */
        readonly title?: TitleProperty[] | cdktn.IResolvable;
        /**
        * updated_at block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_filter#updated_at AwsFilter#updated_at}
        */
        readonly updatedAt?: UpdatedAtProperty[] | cdktn.IResolvable;
        /**
        * vendor_severity block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_filter#vendor_severity AwsFilter#vendor_severity}
        */
        readonly vendorSeverity?: VendorSeverityProperty[] | cdktn.IResolvable;
        /**
        * vulnerability_id block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_filter#vulnerability_id AwsFilter#vulnerability_id}
        */
        readonly vulnerabilityId?: VulnerabilityIdProperty[] | cdktn.IResolvable;
        /**
        * vulnerability_source block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_filter#vulnerability_source AwsFilter#vulnerability_source}
        */
        readonly vulnerabilitySource?: VulnerabilitySourceProperty[] | cdktn.IResolvable;
        /**
        * vulnerable_packages block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_filter#vulnerable_packages AwsFilter#vulnerable_packages}
        */
        readonly vulnerablePackages?: VulnerablePackagesProperty[] | cdktn.IResolvable;
    }
    class FilterCriteriaPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): FilterCriteriaProperty | cdktn.IResolvable | undefined;
        set internalValue(value: FilterCriteriaProperty | cdktn.IResolvable | undefined);
        private _awsAccountId;
        get awsAccountId(): AwsAccountIdPropertyList;
        putAwsAccountId(value: AwsAccountIdProperty[] | cdktn.IResolvable): void;
        resetAwsAccountId(): void;
        get awsAccountIdInput(): cdktn.IResolvable | AwsAccountIdProperty[] | undefined;
        private _codeRepositoryProjectName;
        get codeRepositoryProjectName(): CodeRepositoryProjectNamePropertyList;
        putCodeRepositoryProjectName(value: CodeRepositoryProjectNameProperty[] | cdktn.IResolvable): void;
        resetCodeRepositoryProjectName(): void;
        get codeRepositoryProjectNameInput(): cdktn.IResolvable | CodeRepositoryProjectNameProperty[] | undefined;
        private _codeRepositoryProviderType;
        get codeRepositoryProviderType(): CodeRepositoryProviderTypePropertyList;
        putCodeRepositoryProviderType(value: CodeRepositoryProviderTypeProperty[] | cdktn.IResolvable): void;
        resetCodeRepositoryProviderType(): void;
        get codeRepositoryProviderTypeInput(): cdktn.IResolvable | CodeRepositoryProviderTypeProperty[] | undefined;
        private _codeVulnerabilityDetectorName;
        get codeVulnerabilityDetectorName(): CodeVulnerabilityDetectorNamePropertyList;
        putCodeVulnerabilityDetectorName(value: CodeVulnerabilityDetectorNameProperty[] | cdktn.IResolvable): void;
        resetCodeVulnerabilityDetectorName(): void;
        get codeVulnerabilityDetectorNameInput(): cdktn.IResolvable | CodeVulnerabilityDetectorNameProperty[] | undefined;
        private _codeVulnerabilityDetectorTags;
        get codeVulnerabilityDetectorTags(): CodeVulnerabilityDetectorTagsPropertyList;
        putCodeVulnerabilityDetectorTags(value: CodeVulnerabilityDetectorTagsProperty[] | cdktn.IResolvable): void;
        resetCodeVulnerabilityDetectorTags(): void;
        get codeVulnerabilityDetectorTagsInput(): cdktn.IResolvable | CodeVulnerabilityDetectorTagsProperty[] | undefined;
        private _codeVulnerabilityFilePath;
        get codeVulnerabilityFilePath(): CodeVulnerabilityFilePathPropertyList;
        putCodeVulnerabilityFilePath(value: CodeVulnerabilityFilePathProperty[] | cdktn.IResolvable): void;
        resetCodeVulnerabilityFilePath(): void;
        get codeVulnerabilityFilePathInput(): cdktn.IResolvable | CodeVulnerabilityFilePathProperty[] | undefined;
        private _componentId;
        get componentId(): ComponentIdPropertyList;
        putComponentId(value: ComponentIdProperty[] | cdktn.IResolvable): void;
        resetComponentId(): void;
        get componentIdInput(): cdktn.IResolvable | ComponentIdProperty[] | undefined;
        private _componentType;
        get componentType(): ComponentTypePropertyList;
        putComponentType(value: ComponentTypeProperty[] | cdktn.IResolvable): void;
        resetComponentType(): void;
        get componentTypeInput(): cdktn.IResolvable | ComponentTypeProperty[] | undefined;
        private _ec2InstanceImageId;
        get ec2InstanceImageId(): Ec2InstanceImageIdPropertyList;
        putEc2InstanceImageId(value: Ec2InstanceImageIdProperty[] | cdktn.IResolvable): void;
        resetEc2InstanceImageId(): void;
        get ec2InstanceImageIdInput(): cdktn.IResolvable | Ec2InstanceImageIdProperty[] | undefined;
        private _ec2InstanceSubnetId;
        get ec2InstanceSubnetId(): Ec2InstanceSubnetIdPropertyList;
        putEc2InstanceSubnetId(value: Ec2InstanceSubnetIdProperty[] | cdktn.IResolvable): void;
        resetEc2InstanceSubnetId(): void;
        get ec2InstanceSubnetIdInput(): cdktn.IResolvable | Ec2InstanceSubnetIdProperty[] | undefined;
        private _ec2InstanceVpcId;
        get ec2InstanceVpcId(): Ec2InstanceVpcIdPropertyList;
        putEc2InstanceVpcId(value: Ec2InstanceVpcIdProperty[] | cdktn.IResolvable): void;
        resetEc2InstanceVpcId(): void;
        get ec2InstanceVpcIdInput(): cdktn.IResolvable | Ec2InstanceVpcIdProperty[] | undefined;
        private _ecrImageArchitecture;
        get ecrImageArchitecture(): EcrImageArchitecturePropertyList;
        putEcrImageArchitecture(value: EcrImageArchitectureProperty[] | cdktn.IResolvable): void;
        resetEcrImageArchitecture(): void;
        get ecrImageArchitectureInput(): cdktn.IResolvable | EcrImageArchitectureProperty[] | undefined;
        private _ecrImageHash;
        get ecrImageHash(): EcrImageHashPropertyList;
        putEcrImageHash(value: EcrImageHashProperty[] | cdktn.IResolvable): void;
        resetEcrImageHash(): void;
        get ecrImageHashInput(): cdktn.IResolvable | EcrImageHashProperty[] | undefined;
        private _ecrImageInUseCount;
        get ecrImageInUseCount(): EcrImageInUseCountPropertyList;
        putEcrImageInUseCount(value: EcrImageInUseCountProperty[] | cdktn.IResolvable): void;
        resetEcrImageInUseCount(): void;
        get ecrImageInUseCountInput(): cdktn.IResolvable | EcrImageInUseCountProperty[] | undefined;
        private _ecrImageLastInUseAt;
        get ecrImageLastInUseAt(): EcrImageLastInUseAtPropertyList;
        putEcrImageLastInUseAt(value: EcrImageLastInUseAtProperty[] | cdktn.IResolvable): void;
        resetEcrImageLastInUseAt(): void;
        get ecrImageLastInUseAtInput(): cdktn.IResolvable | EcrImageLastInUseAtProperty[] | undefined;
        private _ecrImagePushedAt;
        get ecrImagePushedAt(): EcrImagePushedAtPropertyList;
        putEcrImagePushedAt(value: EcrImagePushedAtProperty[] | cdktn.IResolvable): void;
        resetEcrImagePushedAt(): void;
        get ecrImagePushedAtInput(): cdktn.IResolvable | EcrImagePushedAtProperty[] | undefined;
        private _ecrImageRegistry;
        get ecrImageRegistry(): EcrImageRegistryPropertyList;
        putEcrImageRegistry(value: EcrImageRegistryProperty[] | cdktn.IResolvable): void;
        resetEcrImageRegistry(): void;
        get ecrImageRegistryInput(): cdktn.IResolvable | EcrImageRegistryProperty[] | undefined;
        private _ecrImageRepositoryName;
        get ecrImageRepositoryName(): EcrImageRepositoryNamePropertyList;
        putEcrImageRepositoryName(value: EcrImageRepositoryNameProperty[] | cdktn.IResolvable): void;
        resetEcrImageRepositoryName(): void;
        get ecrImageRepositoryNameInput(): cdktn.IResolvable | EcrImageRepositoryNameProperty[] | undefined;
        private _ecrImageTags;
        get ecrImageTags(): EcrImageTagsPropertyList;
        putEcrImageTags(value: EcrImageTagsProperty[] | cdktn.IResolvable): void;
        resetEcrImageTags(): void;
        get ecrImageTagsInput(): cdktn.IResolvable | EcrImageTagsProperty[] | undefined;
        private _epssScore;
        get epssScore(): EpssScorePropertyList;
        putEpssScore(value: EpssScoreProperty[] | cdktn.IResolvable): void;
        resetEpssScore(): void;
        get epssScoreInput(): cdktn.IResolvable | EpssScoreProperty[] | undefined;
        private _exploitAvailable;
        get exploitAvailable(): ExploitAvailablePropertyList;
        putExploitAvailable(value: ExploitAvailableProperty[] | cdktn.IResolvable): void;
        resetExploitAvailable(): void;
        get exploitAvailableInput(): cdktn.IResolvable | ExploitAvailableProperty[] | undefined;
        private _findingArn;
        get findingArn(): FindingArnPropertyList;
        putFindingArn(value: FindingArnProperty[] | cdktn.IResolvable): void;
        resetFindingArn(): void;
        get findingArnInput(): cdktn.IResolvable | FindingArnProperty[] | undefined;
        private _findingStatus;
        get findingStatus(): FindingStatusPropertyList;
        putFindingStatus(value: FindingStatusProperty[] | cdktn.IResolvable): void;
        resetFindingStatus(): void;
        get findingStatusInput(): cdktn.IResolvable | FindingStatusProperty[] | undefined;
        private _findingType;
        get findingType(): FindingTypePropertyList;
        putFindingType(value: FindingTypeProperty[] | cdktn.IResolvable): void;
        resetFindingType(): void;
        get findingTypeInput(): cdktn.IResolvable | FindingTypeProperty[] | undefined;
        private _firstObservedAt;
        get firstObservedAt(): FirstObservedAtPropertyList;
        putFirstObservedAt(value: FirstObservedAtProperty[] | cdktn.IResolvable): void;
        resetFirstObservedAt(): void;
        get firstObservedAtInput(): cdktn.IResolvable | FirstObservedAtProperty[] | undefined;
        private _fixAvailable;
        get fixAvailable(): FixAvailablePropertyList;
        putFixAvailable(value: FixAvailableProperty[] | cdktn.IResolvable): void;
        resetFixAvailable(): void;
        get fixAvailableInput(): cdktn.IResolvable | FixAvailableProperty[] | undefined;
        private _inspectorScore;
        get inspectorScore(): InspectorScorePropertyList;
        putInspectorScore(value: InspectorScoreProperty[] | cdktn.IResolvable): void;
        resetInspectorScore(): void;
        get inspectorScoreInput(): cdktn.IResolvable | InspectorScoreProperty[] | undefined;
        private _lambdaFunctionExecutionRoleArn;
        get lambdaFunctionExecutionRoleArn(): LambdaFunctionExecutionRoleArnPropertyList;
        putLambdaFunctionExecutionRoleArn(value: LambdaFunctionExecutionRoleArnProperty[] | cdktn.IResolvable): void;
        resetLambdaFunctionExecutionRoleArn(): void;
        get lambdaFunctionExecutionRoleArnInput(): cdktn.IResolvable | LambdaFunctionExecutionRoleArnProperty[] | undefined;
        private _lambdaFunctionLastModifiedAt;
        get lambdaFunctionLastModifiedAt(): LambdaFunctionLastModifiedAtPropertyList;
        putLambdaFunctionLastModifiedAt(value: LambdaFunctionLastModifiedAtProperty[] | cdktn.IResolvable): void;
        resetLambdaFunctionLastModifiedAt(): void;
        get lambdaFunctionLastModifiedAtInput(): cdktn.IResolvable | LambdaFunctionLastModifiedAtProperty[] | undefined;
        private _lambdaFunctionLayers;
        get lambdaFunctionLayers(): LambdaFunctionLayersPropertyList;
        putLambdaFunctionLayers(value: LambdaFunctionLayersProperty[] | cdktn.IResolvable): void;
        resetLambdaFunctionLayers(): void;
        get lambdaFunctionLayersInput(): cdktn.IResolvable | LambdaFunctionLayersProperty[] | undefined;
        private _lambdaFunctionName;
        get lambdaFunctionName(): LambdaFunctionNamePropertyList;
        putLambdaFunctionName(value: LambdaFunctionNameProperty[] | cdktn.IResolvable): void;
        resetLambdaFunctionName(): void;
        get lambdaFunctionNameInput(): cdktn.IResolvable | LambdaFunctionNameProperty[] | undefined;
        private _lambdaFunctionRuntime;
        get lambdaFunctionRuntime(): LambdaFunctionRuntimePropertyList;
        putLambdaFunctionRuntime(value: LambdaFunctionRuntimeProperty[] | cdktn.IResolvable): void;
        resetLambdaFunctionRuntime(): void;
        get lambdaFunctionRuntimeInput(): cdktn.IResolvable | LambdaFunctionRuntimeProperty[] | undefined;
        private _lastObservedAt;
        get lastObservedAt(): LastObservedAtPropertyList;
        putLastObservedAt(value: LastObservedAtProperty[] | cdktn.IResolvable): void;
        resetLastObservedAt(): void;
        get lastObservedAtInput(): cdktn.IResolvable | LastObservedAtProperty[] | undefined;
        private _networkProtocol;
        get networkProtocol(): NetworkProtocolPropertyList;
        putNetworkProtocol(value: NetworkProtocolProperty[] | cdktn.IResolvable): void;
        resetNetworkProtocol(): void;
        get networkProtocolInput(): cdktn.IResolvable | NetworkProtocolProperty[] | undefined;
        private _portRange;
        get portRange(): PortRangePropertyList;
        putPortRange(value: PortRangeProperty[] | cdktn.IResolvable): void;
        resetPortRange(): void;
        get portRangeInput(): cdktn.IResolvable | PortRangeProperty[] | undefined;
        private _relatedVulnerabilities;
        get relatedVulnerabilities(): RelatedVulnerabilitiesPropertyList;
        putRelatedVulnerabilities(value: RelatedVulnerabilitiesProperty[] | cdktn.IResolvable): void;
        resetRelatedVulnerabilities(): void;
        get relatedVulnerabilitiesInput(): cdktn.IResolvable | RelatedVulnerabilitiesProperty[] | undefined;
        private _resourceId;
        get resourceId(): ResourceIdPropertyList;
        putResourceId(value: ResourceIdProperty[] | cdktn.IResolvable): void;
        resetResourceId(): void;
        get resourceIdInput(): cdktn.IResolvable | ResourceIdProperty[] | undefined;
        private _resourceTags;
        get resourceTags(): ResourceTagsPropertyList;
        putResourceTags(value: ResourceTagsProperty[] | cdktn.IResolvable): void;
        resetResourceTags(): void;
        get resourceTagsInput(): cdktn.IResolvable | ResourceTagsProperty[] | undefined;
        private _resourceType;
        get resourceType(): ResourceTypePropertyList;
        putResourceType(value: ResourceTypeProperty[] | cdktn.IResolvable): void;
        resetResourceType(): void;
        get resourceTypeInput(): cdktn.IResolvable | ResourceTypeProperty[] | undefined;
        private _severity;
        get severity(): SeverityPropertyList;
        putSeverity(value: SeverityProperty[] | cdktn.IResolvable): void;
        resetSeverity(): void;
        get severityInput(): cdktn.IResolvable | SeverityProperty[] | undefined;
        private _title;
        get title(): TitlePropertyList;
        putTitle(value: TitleProperty[] | cdktn.IResolvable): void;
        resetTitle(): void;
        get titleInput(): cdktn.IResolvable | TitleProperty[] | undefined;
        private _updatedAt;
        get updatedAt(): UpdatedAtPropertyList;
        putUpdatedAt(value: UpdatedAtProperty[] | cdktn.IResolvable): void;
        resetUpdatedAt(): void;
        get updatedAtInput(): cdktn.IResolvable | UpdatedAtProperty[] | undefined;
        private _vendorSeverity;
        get vendorSeverity(): VendorSeverityPropertyList;
        putVendorSeverity(value: VendorSeverityProperty[] | cdktn.IResolvable): void;
        resetVendorSeverity(): void;
        get vendorSeverityInput(): cdktn.IResolvable | VendorSeverityProperty[] | undefined;
        private _vulnerabilityId;
        get vulnerabilityId(): VulnerabilityIdPropertyList;
        putVulnerabilityId(value: VulnerabilityIdProperty[] | cdktn.IResolvable): void;
        resetVulnerabilityId(): void;
        get vulnerabilityIdInput(): cdktn.IResolvable | VulnerabilityIdProperty[] | undefined;
        private _vulnerabilitySource;
        get vulnerabilitySource(): VulnerabilitySourcePropertyList;
        putVulnerabilitySource(value: VulnerabilitySourceProperty[] | cdktn.IResolvable): void;
        resetVulnerabilitySource(): void;
        get vulnerabilitySourceInput(): cdktn.IResolvable | VulnerabilitySourceProperty[] | undefined;
        private _vulnerablePackages;
        get vulnerablePackages(): VulnerablePackagesPropertyList;
        putVulnerablePackages(value: VulnerablePackagesProperty[] | cdktn.IResolvable): void;
        resetVulnerablePackages(): void;
        get vulnerablePackagesInput(): cdktn.IResolvable | VulnerablePackagesProperty[] | undefined;
    }
    class FilterCriteriaPropertyList extends cdktn.ComplexList {
        internalValue?: FilterCriteriaProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): FilterCriteriaPropertyOutputReference;
    }
}
