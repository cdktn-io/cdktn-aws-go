import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsOrganizationConfigurationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_organization_configuration#id AwsOrganizationConfiguration#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_organization_configuration#region AwsOrganizationConfiguration#region}
    */
    readonly region?: string;
    /**
    * auto_enable block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_organization_configuration#auto_enable AwsOrganizationConfiguration#auto_enable}
    */
    readonly autoEnable: AwsOrganizationConfiguration.AutoEnableProperty;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_organization_configuration#timeouts AwsOrganizationConfiguration#timeouts}
    */
    readonly timeouts?: AwsOrganizationConfiguration.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_organization_configuration aws_inspector2_organization_configuration}
*/
export declare class AwsOrganizationConfiguration extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_inspector2_organization_configuration";
    /**
    * Generates CDKTN code for importing a AwsOrganizationConfiguration resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsOrganizationConfiguration to import
    * @param importFromId The id of the existing AwsOrganizationConfiguration that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_organization_configuration#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsOrganizationConfiguration to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_organization_configuration aws_inspector2_organization_configuration} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsOrganizationConfigurationConfig
    */
    constructor(scope: Construct, id: string, config: AwsOrganizationConfigurationConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get maxAccountLimitReached(): cdktn.IResolvable;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _autoEnable;
    get autoEnable(): AwsOrganizationConfiguration.AutoEnablePropertyOutputReference;
    putAutoEnable(value: AwsOrganizationConfiguration.AutoEnableProperty): void;
    get autoEnableInput(): AwsOrganizationConfiguration.AutoEnableProperty | undefined;
    private _timeouts;
    get timeouts(): AwsOrganizationConfiguration.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsOrganizationConfiguration.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsOrganizationConfiguration.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsOrganizationConfigurationAutoEnablePropertyToTerraform(struct?: AwsOrganizationConfiguration.AutoEnablePropertyOutputReference | AwsOrganizationConfiguration.AutoEnableProperty): any;
export declare function awsOrganizationConfigurationAutoEnablePropertyToHclTerraform(struct?: AwsOrganizationConfiguration.AutoEnablePropertyOutputReference | AwsOrganizationConfiguration.AutoEnableProperty): any;
export declare function awsOrganizationConfigurationTimeoutsPropertyToTerraform(struct?: AwsOrganizationConfiguration.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsOrganizationConfigurationTimeoutsPropertyToHclTerraform(struct?: AwsOrganizationConfiguration.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsOrganizationConfiguration {
    interface AutoEnableProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_organization_configuration#code_repository AwsOrganizationConfiguration#code_repository}
        */
        readonly codeRepository?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_organization_configuration#ec2 AwsOrganizationConfiguration#ec2}
        */
        readonly ec2: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_organization_configuration#ecr AwsOrganizationConfiguration#ecr}
        */
        readonly ecr: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_organization_configuration#lambda AwsOrganizationConfiguration#lambda}
        */
        readonly lambda?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_organization_configuration#lambda_code AwsOrganizationConfiguration#lambda_code}
        */
        readonly lambdaCode?: boolean | cdktn.IResolvable;
    }
    class AutoEnablePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AutoEnableProperty | undefined;
        set internalValue(value: AutoEnableProperty | undefined);
        private _codeRepository?;
        get codeRepository(): boolean | cdktn.IResolvable;
        set codeRepository(value: boolean | cdktn.IResolvable);
        resetCodeRepository(): void;
        get codeRepositoryInput(): boolean | cdktn.IResolvable | undefined;
        private _ec2?;
        get ec2(): boolean | cdktn.IResolvable;
        set ec2(value: boolean | cdktn.IResolvable);
        get ec2Input(): boolean | cdktn.IResolvable | undefined;
        private _ecr?;
        get ecr(): boolean | cdktn.IResolvable;
        set ecr(value: boolean | cdktn.IResolvable);
        get ecrInput(): boolean | cdktn.IResolvable | undefined;
        private _lambda?;
        get lambda(): boolean | cdktn.IResolvable;
        set lambda(value: boolean | cdktn.IResolvable);
        resetLambda(): void;
        get lambdaInput(): boolean | cdktn.IResolvable | undefined;
        private _lambdaCode?;
        get lambdaCode(): boolean | cdktn.IResolvable;
        set lambdaCode(value: boolean | cdktn.IResolvable);
        resetLambdaCode(): void;
        get lambdaCodeInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_organization_configuration#create AwsOrganizationConfiguration#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_organization_configuration#delete AwsOrganizationConfiguration#delete}
        */
        readonly delete?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_organization_configuration#update AwsOrganizationConfiguration#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
