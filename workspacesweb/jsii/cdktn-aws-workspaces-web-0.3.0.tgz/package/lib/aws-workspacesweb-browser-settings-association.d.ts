import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsBrowserSettingsAssociationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspacesweb_browser_settings_association#browser_settings_arn AwsBrowserSettingsAssociation#browser_settings_arn}
    */
    readonly browserSettingsArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspacesweb_browser_settings_association#portal_arn AwsBrowserSettingsAssociation#portal_arn}
    */
    readonly portalArn: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspacesweb_browser_settings_association#region AwsBrowserSettingsAssociation#region}
    */
    readonly region?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspacesweb_browser_settings_association aws_workspacesweb_browser_settings_association}
*/
export declare class AwsBrowserSettingsAssociation extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_workspacesweb_browser_settings_association";
    /**
    * Generates CDKTN code for importing a AwsBrowserSettingsAssociation resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsBrowserSettingsAssociation to import
    * @param importFromId The id of the existing AwsBrowserSettingsAssociation that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspacesweb_browser_settings_association#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsBrowserSettingsAssociation to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspacesweb_browser_settings_association aws_workspacesweb_browser_settings_association} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsBrowserSettingsAssociationConfig
    */
    constructor(scope: Construct, id: string, config: AwsBrowserSettingsAssociationConfig);
    private _browserSettingsArn?;
    get browserSettingsArn(): string;
    set browserSettingsArn(value: string);
    get browserSettingsArnInput(): string | undefined;
    private _portalArn?;
    get portalArn(): string;
    set portalArn(value: string);
    get portalArnInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
