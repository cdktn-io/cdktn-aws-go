import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsTrustStoreConfig extends cdktn.TerraformMetaArguments {
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspacesweb_trust_store#region AwsTrustStore#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspacesweb_trust_store#tags AwsTrustStore#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * certificate block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspacesweb_trust_store#certificate AwsTrustStore#certificate}
    */
    readonly certificate?: AwsTrustStore.CertificateProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspacesweb_trust_store aws_workspacesweb_trust_store}
*/
export declare class AwsTrustStore extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_workspacesweb_trust_store";
    /**
    * Generates CDKTN code for importing a AwsTrustStore resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsTrustStore to import
    * @param importFromId The id of the existing AwsTrustStore that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspacesweb_trust_store#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsTrustStore to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspacesweb_trust_store aws_workspacesweb_trust_store} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsTrustStoreConfig = {}
    */
    constructor(scope: Construct, id: string, config?: AwsTrustStoreConfig);
    get associatedPortalArns(): string[];
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    get trustStoreArn(): string;
    private _certificate;
    get certificate(): AwsTrustStore.CertificatePropertyList;
    putCertificate(value: AwsTrustStore.CertificateProperty[] | cdktn.IResolvable): void;
    resetCertificate(): void;
    get certificateInput(): cdktn.IResolvable | AwsTrustStore.CertificateProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsTrustStoreCertificatePropertyToTerraform(struct?: AwsTrustStore.CertificateProperty | cdktn.IResolvable): any;
export declare function awsTrustStoreCertificatePropertyToHclTerraform(struct?: AwsTrustStore.CertificateProperty | cdktn.IResolvable): any;
export declare namespace AwsTrustStore {
    interface CertificateProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspacesweb_trust_store#body AwsTrustStore#body}
        */
        readonly body: string;
    }
    class CertificatePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CertificateProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CertificateProperty | cdktn.IResolvable | undefined);
        private _body?;
        get body(): string;
        set body(value: string);
        get bodyInput(): string | undefined;
        get issuer(): string;
        get notValidAfter(): string;
        get notValidBefore(): string;
        get subject(): string;
        get thumbprint(): string;
    }
    class CertificatePropertyList extends cdktn.ComplexList {
        internalValue?: CertificateProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CertificatePropertyOutputReference;
    }
}
