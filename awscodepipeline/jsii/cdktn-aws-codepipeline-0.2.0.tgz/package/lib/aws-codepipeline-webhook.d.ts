import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfWebhookConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline_webhook#authentication TfWebhook#authentication}
    */
    readonly authentication: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline_webhook#id TfWebhook#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline_webhook#name TfWebhook#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline_webhook#region TfWebhook#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline_webhook#tags TfWebhook#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline_webhook#tags_all TfWebhook#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline_webhook#target_action TfWebhook#target_action}
    */
    readonly targetAction: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline_webhook#target_pipeline TfWebhook#target_pipeline}
    */
    readonly targetPipeline: string;
    /**
    * authentication_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline_webhook#authentication_configuration TfWebhook#authentication_configuration}
    */
    readonly authenticationConfiguration?: TfWebhook.AuthenticationConfigurationProperty;
    /**
    * filter block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline_webhook#filter TfWebhook#filter}
    */
    readonly filter: TfWebhook.FilterProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline_webhook aws_codepipeline_webhook}
*/
export declare class TfWebhook extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_codepipeline_webhook";
    /**
    * Generates CDKTN code for importing a TfWebhook resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfWebhook to import
    * @param importFromId The id of the existing TfWebhook that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline_webhook#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfWebhook to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline_webhook aws_codepipeline_webhook} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfWebhookConfig
    */
    constructor(scope: Construct, id: string, config: TfWebhookConfig);
    get arn(): string;
    private _authentication?;
    get authentication(): string;
    set authentication(value: string);
    get authenticationInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _targetAction?;
    get targetAction(): string;
    set targetAction(value: string);
    get targetActionInput(): string | undefined;
    private _targetPipeline?;
    get targetPipeline(): string;
    set targetPipeline(value: string);
    get targetPipelineInput(): string | undefined;
    get url(): string;
    private _authenticationConfiguration;
    get authenticationConfiguration(): TfWebhook.AuthenticationConfigurationPropertyOutputReference;
    putAuthenticationConfiguration(value: TfWebhook.AuthenticationConfigurationProperty): void;
    resetAuthenticationConfiguration(): void;
    get authenticationConfigurationInput(): TfWebhook.AuthenticationConfigurationProperty | undefined;
    private _filter;
    get filter(): TfWebhook.FilterPropertyList;
    putFilter(value: TfWebhook.FilterProperty[] | cdktn.IResolvable): void;
    get filterInput(): cdktn.IResolvable | TfWebhook.FilterProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfWebhookAuthenticationConfigurationPropertyToTerraform(struct?: TfWebhook.AuthenticationConfigurationPropertyOutputReference | TfWebhook.AuthenticationConfigurationProperty): any;
export declare function tfWebhookAuthenticationConfigurationPropertyToHclTerraform(struct?: TfWebhook.AuthenticationConfigurationPropertyOutputReference | TfWebhook.AuthenticationConfigurationProperty): any;
export declare function tfWebhookFilterPropertyToTerraform(struct?: TfWebhook.FilterProperty | cdktn.IResolvable): any;
export declare function tfWebhookFilterPropertyToHclTerraform(struct?: TfWebhook.FilterProperty | cdktn.IResolvable): any;
export declare namespace TfWebhook {
    interface AuthenticationConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline_webhook#allowed_ip_range TfWebhook#allowed_ip_range}
        */
        readonly allowedIpRange?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline_webhook#secret_token TfWebhook#secret_token}
        */
        readonly secretToken?: string;
    }
    class AuthenticationConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AuthenticationConfigurationProperty | undefined;
        set internalValue(value: AuthenticationConfigurationProperty | undefined);
        private _allowedIpRange?;
        get allowedIpRange(): string;
        set allowedIpRange(value: string);
        resetAllowedIpRange(): void;
        get allowedIpRangeInput(): string | undefined;
        private _secretToken?;
        get secretToken(): string;
        set secretToken(value: string);
        resetSecretToken(): void;
        get secretTokenInput(): string | undefined;
    }
    interface FilterProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline_webhook#json_path TfWebhook#json_path}
        */
        readonly jsonPath: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline_webhook#match_equals TfWebhook#match_equals}
        */
        readonly matchEquals: string;
    }
    class FilterPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): FilterProperty | cdktn.IResolvable | undefined;
        set internalValue(value: FilterProperty | cdktn.IResolvable | undefined);
        private _jsonPath?;
        get jsonPath(): string;
        set jsonPath(value: string);
        get jsonPathInput(): string | undefined;
        private _matchEquals?;
        get matchEquals(): string;
        set matchEquals(value: string);
        get matchEqualsInput(): string | undefined;
    }
    class FilterPropertyList extends cdktn.ComplexList {
        internalValue?: FilterProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): FilterPropertyOutputReference;
    }
}
