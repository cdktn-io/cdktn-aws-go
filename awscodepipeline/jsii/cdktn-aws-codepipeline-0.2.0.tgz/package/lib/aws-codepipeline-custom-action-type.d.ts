import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfCustomActionTypeConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline_custom_action_type#category TfCustomActionType#category}
    */
    readonly category: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline_custom_action_type#id TfCustomActionType#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline_custom_action_type#provider_name TfCustomActionType#provider_name}
    */
    readonly providerName: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline_custom_action_type#region TfCustomActionType#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline_custom_action_type#tags TfCustomActionType#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline_custom_action_type#tags_all TfCustomActionType#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline_custom_action_type#version TfCustomActionType#version}
    */
    readonly version: string;
    /**
    * configuration_property block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline_custom_action_type#configuration_property TfCustomActionType#configuration_property}
    */
    readonly configurationProperty?: TfCustomActionType.ConfigurationPropertyProperty[] | cdktn.IResolvable;
    /**
    * input_artifact_details block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline_custom_action_type#input_artifact_details TfCustomActionType#input_artifact_details}
    */
    readonly inputArtifactDetails: TfCustomActionType.InputArtifactDetailsProperty;
    /**
    * output_artifact_details block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline_custom_action_type#output_artifact_details TfCustomActionType#output_artifact_details}
    */
    readonly outputArtifactDetails: TfCustomActionType.OutputArtifactDetailsProperty;
    /**
    * settings block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline_custom_action_type#settings TfCustomActionType#settings}
    */
    readonly settings?: TfCustomActionType.SettingsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline_custom_action_type aws_codepipeline_custom_action_type}
*/
export declare class TfCustomActionType extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_codepipeline_custom_action_type";
    /**
    * Generates CDKTN code for importing a TfCustomActionType resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfCustomActionType to import
    * @param importFromId The id of the existing TfCustomActionType that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline_custom_action_type#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfCustomActionType to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline_custom_action_type aws_codepipeline_custom_action_type} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfCustomActionTypeConfig
    */
    constructor(scope: Construct, id: string, config: TfCustomActionTypeConfig);
    get arn(): string;
    private _category?;
    get category(): string;
    set category(value: string);
    get categoryInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get owner(): string;
    private _providerName?;
    get providerName(): string;
    set providerName(value: string);
    get providerNameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _version?;
    get version(): string;
    set version(value: string);
    get versionInput(): string | undefined;
    private _configurationProperty;
    get configurationProperty(): TfCustomActionType.ConfigurationPropertyPropertyList;
    putConfigurationProperty(value: TfCustomActionType.ConfigurationPropertyProperty[] | cdktn.IResolvable): void;
    resetConfigurationProperty(): void;
    get configurationPropertyInput(): cdktn.IResolvable | TfCustomActionType.ConfigurationPropertyProperty[] | undefined;
    private _inputArtifactDetails;
    get inputArtifactDetails(): TfCustomActionType.InputArtifactDetailsPropertyOutputReference;
    putInputArtifactDetails(value: TfCustomActionType.InputArtifactDetailsProperty): void;
    get inputArtifactDetailsInput(): TfCustomActionType.InputArtifactDetailsProperty | undefined;
    private _outputArtifactDetails;
    get outputArtifactDetails(): TfCustomActionType.OutputArtifactDetailsPropertyOutputReference;
    putOutputArtifactDetails(value: TfCustomActionType.OutputArtifactDetailsProperty): void;
    get outputArtifactDetailsInput(): TfCustomActionType.OutputArtifactDetailsProperty | undefined;
    private _settings;
    get settings(): TfCustomActionType.SettingsPropertyOutputReference;
    putSettings(value: TfCustomActionType.SettingsProperty): void;
    resetSettings(): void;
    get settingsInput(): TfCustomActionType.SettingsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfCustomActionTypeConfigurationPropertyPropertyToTerraform(struct?: TfCustomActionType.ConfigurationPropertyProperty | cdktn.IResolvable): any;
export declare function tfCustomActionTypeConfigurationPropertyPropertyToHclTerraform(struct?: TfCustomActionType.ConfigurationPropertyProperty | cdktn.IResolvable): any;
export declare function tfCustomActionTypeInputArtifactDetailsPropertyToTerraform(struct?: TfCustomActionType.InputArtifactDetailsPropertyOutputReference | TfCustomActionType.InputArtifactDetailsProperty): any;
export declare function tfCustomActionTypeInputArtifactDetailsPropertyToHclTerraform(struct?: TfCustomActionType.InputArtifactDetailsPropertyOutputReference | TfCustomActionType.InputArtifactDetailsProperty): any;
export declare function tfCustomActionTypeOutputArtifactDetailsPropertyToTerraform(struct?: TfCustomActionType.OutputArtifactDetailsPropertyOutputReference | TfCustomActionType.OutputArtifactDetailsProperty): any;
export declare function tfCustomActionTypeOutputArtifactDetailsPropertyToHclTerraform(struct?: TfCustomActionType.OutputArtifactDetailsPropertyOutputReference | TfCustomActionType.OutputArtifactDetailsProperty): any;
export declare function tfCustomActionTypeSettingsPropertyToTerraform(struct?: TfCustomActionType.SettingsPropertyOutputReference | TfCustomActionType.SettingsProperty): any;
export declare function tfCustomActionTypeSettingsPropertyToHclTerraform(struct?: TfCustomActionType.SettingsPropertyOutputReference | TfCustomActionType.SettingsProperty): any;
export declare namespace TfCustomActionType {
    interface ConfigurationPropertyProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline_custom_action_type#description TfCustomActionType#description}
        */
        readonly description?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline_custom_action_type#key TfCustomActionType#key}
        */
        readonly key: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline_custom_action_type#name TfCustomActionType#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline_custom_action_type#queryable TfCustomActionType#queryable}
        */
        readonly queryable?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline_custom_action_type#required TfCustomActionType#required}
        */
        readonly required: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline_custom_action_type#secret TfCustomActionType#secret}
        */
        readonly secret: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline_custom_action_type#type TfCustomActionType#type}
        */
        readonly type?: string;
    }
    class ConfigurationPropertyPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ConfigurationPropertyProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ConfigurationPropertyProperty | cdktn.IResolvable | undefined);
        private _description?;
        get description(): string;
        set description(value: string);
        resetDescription(): void;
        get descriptionInput(): string | undefined;
        private _key?;
        get key(): boolean | cdktn.IResolvable;
        set key(value: boolean | cdktn.IResolvable);
        get keyInput(): boolean | cdktn.IResolvable | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _queryable?;
        get queryable(): boolean | cdktn.IResolvable;
        set queryable(value: boolean | cdktn.IResolvable);
        resetQueryable(): void;
        get queryableInput(): boolean | cdktn.IResolvable | undefined;
        private _required?;
        get required(): boolean | cdktn.IResolvable;
        set required(value: boolean | cdktn.IResolvable);
        get requiredInput(): boolean | cdktn.IResolvable | undefined;
        private _secret?;
        get secret(): boolean | cdktn.IResolvable;
        set secret(value: boolean | cdktn.IResolvable);
        get secretInput(): boolean | cdktn.IResolvable | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        resetType(): void;
        get typeInput(): string | undefined;
    }
    class ConfigurationPropertyPropertyList extends cdktn.ComplexList {
        internalValue?: ConfigurationPropertyProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ConfigurationPropertyPropertyOutputReference;
    }
    interface InputArtifactDetailsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline_custom_action_type#maximum_count TfCustomActionType#maximum_count}
        */
        readonly maximumCount: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline_custom_action_type#minimum_count TfCustomActionType#minimum_count}
        */
        readonly minimumCount: number;
    }
    class InputArtifactDetailsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): InputArtifactDetailsProperty | undefined;
        set internalValue(value: InputArtifactDetailsProperty | undefined);
        private _maximumCount?;
        get maximumCount(): number;
        set maximumCount(value: number);
        get maximumCountInput(): number | undefined;
        private _minimumCount?;
        get minimumCount(): number;
        set minimumCount(value: number);
        get minimumCountInput(): number | undefined;
    }
    interface OutputArtifactDetailsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline_custom_action_type#maximum_count TfCustomActionType#maximum_count}
        */
        readonly maximumCount: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline_custom_action_type#minimum_count TfCustomActionType#minimum_count}
        */
        readonly minimumCount: number;
    }
    class OutputArtifactDetailsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): OutputArtifactDetailsProperty | undefined;
        set internalValue(value: OutputArtifactDetailsProperty | undefined);
        private _maximumCount?;
        get maximumCount(): number;
        set maximumCount(value: number);
        get maximumCountInput(): number | undefined;
        private _minimumCount?;
        get minimumCount(): number;
        set minimumCount(value: number);
        get minimumCountInput(): number | undefined;
    }
    interface SettingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline_custom_action_type#entity_url_template TfCustomActionType#entity_url_template}
        */
        readonly entityUrlTemplate?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline_custom_action_type#execution_url_template TfCustomActionType#execution_url_template}
        */
        readonly executionUrlTemplate?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline_custom_action_type#revision_url_template TfCustomActionType#revision_url_template}
        */
        readonly revisionUrlTemplate?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline_custom_action_type#third_party_configuration_url TfCustomActionType#third_party_configuration_url}
        */
        readonly thirdPartyConfigurationUrl?: string;
    }
    class SettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SettingsProperty | undefined;
        set internalValue(value: SettingsProperty | undefined);
        private _entityUrlTemplate?;
        get entityUrlTemplate(): string;
        set entityUrlTemplate(value: string);
        resetEntityUrlTemplate(): void;
        get entityUrlTemplateInput(): string | undefined;
        private _executionUrlTemplate?;
        get executionUrlTemplate(): string;
        set executionUrlTemplate(value: string);
        resetExecutionUrlTemplate(): void;
        get executionUrlTemplateInput(): string | undefined;
        private _revisionUrlTemplate?;
        get revisionUrlTemplate(): string;
        set revisionUrlTemplate(value: string);
        resetRevisionUrlTemplate(): void;
        get revisionUrlTemplateInput(): string | undefined;
        private _thirdPartyConfigurationUrl?;
        get thirdPartyConfigurationUrl(): string;
        set thirdPartyConfigurationUrl(value: string);
        resetThirdPartyConfigurationUrl(): void;
        get thirdPartyConfigurationUrlInput(): string | undefined;
    }
}
