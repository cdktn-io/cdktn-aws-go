import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfCodepipelineConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#execution_mode TfCodepipeline#execution_mode}
    */
    readonly executionMode?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#id TfCodepipeline#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#name TfCodepipeline#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#pipeline_type TfCodepipeline#pipeline_type}
    */
    readonly pipelineType?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#region TfCodepipeline#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#role_arn TfCodepipeline#role_arn}
    */
    readonly roleArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#tags TfCodepipeline#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#tags_all TfCodepipeline#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * artifact_store block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#artifact_store TfCodepipeline#artifact_store}
    */
    readonly artifactStore: TfCodepipeline.ArtifactStoreProperty[] | cdktn.IResolvable;
    /**
    * stage block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#stage TfCodepipeline#stage}
    */
    readonly stage: TfCodepipeline.StageProperty[] | cdktn.IResolvable;
    /**
    * trigger block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#trigger TfCodepipeline#trigger}
    */
    readonly trigger?: TfCodepipeline.TriggerProperty[] | cdktn.IResolvable;
    /**
    * variable block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#variable TfCodepipeline#variable}
    */
    readonly variable?: TfCodepipeline.VariableProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline aws_codepipeline}
*/
export declare class TfCodepipeline extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_codepipeline";
    /**
    * Generates CDKTN code for importing a TfCodepipeline resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfCodepipeline to import
    * @param importFromId The id of the existing TfCodepipeline that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfCodepipeline to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline aws_codepipeline} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfCodepipelineConfig
    */
    constructor(scope: Construct, id: string, config: TfCodepipelineConfig);
    get arn(): string;
    private _executionMode?;
    get executionMode(): string;
    set executionMode(value: string);
    resetExecutionMode(): void;
    get executionModeInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _pipelineType?;
    get pipelineType(): string;
    set pipelineType(value: string);
    resetPipelineType(): void;
    get pipelineTypeInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _roleArn?;
    get roleArn(): string;
    set roleArn(value: string);
    get roleArnInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _triggerAll;
    get triggerAll(): TfCodepipeline.TriggerAllPropertyList;
    private _artifactStore;
    get artifactStore(): TfCodepipeline.ArtifactStorePropertyList;
    putArtifactStore(value: TfCodepipeline.ArtifactStoreProperty[] | cdktn.IResolvable): void;
    get artifactStoreInput(): cdktn.IResolvable | TfCodepipeline.ArtifactStoreProperty[] | undefined;
    private _stage;
    get stage(): TfCodepipeline.StagePropertyList;
    putStage(value: TfCodepipeline.StageProperty[] | cdktn.IResolvable): void;
    get stageInput(): cdktn.IResolvable | TfCodepipeline.StageProperty[] | undefined;
    private _trigger;
    get trigger(): TfCodepipeline.TriggerPropertyList;
    putTrigger(value: TfCodepipeline.TriggerProperty[] | cdktn.IResolvable): void;
    resetTrigger(): void;
    get triggerInput(): cdktn.IResolvable | TfCodepipeline.TriggerProperty[] | undefined;
    private _variable;
    get variable(): TfCodepipeline.VariablePropertyList;
    putVariable(value: TfCodepipeline.VariableProperty[] | cdktn.IResolvable): void;
    resetVariable(): void;
    get variableInput(): cdktn.IResolvable | TfCodepipeline.VariableProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfCodepipelineTriggerAllGitConfigurationPullRequestBranchesPropertyToTerraform(struct?: TfCodepipeline.TriggerAllGitConfigurationPullRequestBranchesProperty): any;
export declare function tfCodepipelineTriggerAllGitConfigurationPullRequestBranchesPropertyToHclTerraform(struct?: TfCodepipeline.TriggerAllGitConfigurationPullRequestBranchesProperty): any;
export declare function tfCodepipelineTriggerAllGitConfigurationPullRequestFilePathsPropertyToTerraform(struct?: TfCodepipeline.TriggerAllGitConfigurationPullRequestFilePathsProperty): any;
export declare function tfCodepipelineTriggerAllGitConfigurationPullRequestFilePathsPropertyToHclTerraform(struct?: TfCodepipeline.TriggerAllGitConfigurationPullRequestFilePathsProperty): any;
export declare function tfCodepipelineTriggerAllGitConfigurationPullRequestPropertyToTerraform(struct?: TfCodepipeline.TriggerAllGitConfigurationPullRequestProperty): any;
export declare function tfCodepipelineTriggerAllGitConfigurationPullRequestPropertyToHclTerraform(struct?: TfCodepipeline.TriggerAllGitConfigurationPullRequestProperty): any;
export declare function tfCodepipelineTriggerAllGitConfigurationPushBranchesPropertyToTerraform(struct?: TfCodepipeline.TriggerAllGitConfigurationPushBranchesProperty): any;
export declare function tfCodepipelineTriggerAllGitConfigurationPushBranchesPropertyToHclTerraform(struct?: TfCodepipeline.TriggerAllGitConfigurationPushBranchesProperty): any;
export declare function tfCodepipelineTriggerAllGitConfigurationPushFilePathsPropertyToTerraform(struct?: TfCodepipeline.TriggerAllGitConfigurationPushFilePathsProperty): any;
export declare function tfCodepipelineTriggerAllGitConfigurationPushFilePathsPropertyToHclTerraform(struct?: TfCodepipeline.TriggerAllGitConfigurationPushFilePathsProperty): any;
export declare function tfCodepipelineTriggerAllGitConfigurationPushTagsPropertyToTerraform(struct?: TfCodepipeline.TriggerAllGitConfigurationPushTagsProperty): any;
export declare function tfCodepipelineTriggerAllGitConfigurationPushTagsPropertyToHclTerraform(struct?: TfCodepipeline.TriggerAllGitConfigurationPushTagsProperty): any;
export declare function tfCodepipelineTriggerAllGitConfigurationPushPropertyToTerraform(struct?: TfCodepipeline.TriggerAllGitConfigurationPushProperty): any;
export declare function tfCodepipelineTriggerAllGitConfigurationPushPropertyToHclTerraform(struct?: TfCodepipeline.TriggerAllGitConfigurationPushProperty): any;
export declare function tfCodepipelineTriggerAllGitConfigurationPropertyToTerraform(struct?: TfCodepipeline.TriggerAllGitConfigurationProperty): any;
export declare function tfCodepipelineTriggerAllGitConfigurationPropertyToHclTerraform(struct?: TfCodepipeline.TriggerAllGitConfigurationProperty): any;
export declare function tfCodepipelineTriggerAllPropertyToTerraform(struct?: TfCodepipeline.TriggerAllProperty): any;
export declare function tfCodepipelineTriggerAllPropertyToHclTerraform(struct?: TfCodepipeline.TriggerAllProperty): any;
export declare function tfCodepipelineEncryptionKeyPropertyToTerraform(struct?: TfCodepipeline.EncryptionKeyPropertyOutputReference | TfCodepipeline.EncryptionKeyProperty): any;
export declare function tfCodepipelineEncryptionKeyPropertyToHclTerraform(struct?: TfCodepipeline.EncryptionKeyPropertyOutputReference | TfCodepipeline.EncryptionKeyProperty): any;
export declare function tfCodepipelineArtifactStorePropertyToTerraform(struct?: TfCodepipeline.ArtifactStoreProperty | cdktn.IResolvable): any;
export declare function tfCodepipelineArtifactStorePropertyToHclTerraform(struct?: TfCodepipeline.ArtifactStoreProperty | cdktn.IResolvable): any;
export declare function tfCodepipelineOutputArtifactsForComputeActionPropertyToTerraform(struct?: TfCodepipeline.OutputArtifactsForComputeActionProperty | cdktn.IResolvable): any;
export declare function tfCodepipelineOutputArtifactsForComputeActionPropertyToHclTerraform(struct?: TfCodepipeline.OutputArtifactsForComputeActionProperty | cdktn.IResolvable): any;
export declare function tfCodepipelineActionPropertyToTerraform(struct?: TfCodepipeline.ActionProperty | cdktn.IResolvable): any;
export declare function tfCodepipelineActionPropertyToHclTerraform(struct?: TfCodepipeline.ActionProperty | cdktn.IResolvable): any;
export declare function tfCodepipelineStageBeforeEntryConditionRuleRuleTypeIdPropertyToTerraform(struct?: TfCodepipeline.StageBeforeEntryConditionRuleRuleTypeIdPropertyOutputReference | TfCodepipeline.StageBeforeEntryConditionRuleRuleTypeIdProperty): any;
export declare function tfCodepipelineStageBeforeEntryConditionRuleRuleTypeIdPropertyToHclTerraform(struct?: TfCodepipeline.StageBeforeEntryConditionRuleRuleTypeIdPropertyOutputReference | TfCodepipeline.StageBeforeEntryConditionRuleRuleTypeIdProperty): any;
export declare function tfCodepipelineStageBeforeEntryConditionRulePropertyToTerraform(struct?: TfCodepipeline.StageBeforeEntryConditionRuleProperty | cdktn.IResolvable): any;
export declare function tfCodepipelineStageBeforeEntryConditionRulePropertyToHclTerraform(struct?: TfCodepipeline.StageBeforeEntryConditionRuleProperty | cdktn.IResolvable): any;
export declare function tfCodepipelineStageBeforeEntryConditionPropertyToTerraform(struct?: TfCodepipeline.StageBeforeEntryConditionPropertyOutputReference | TfCodepipeline.StageBeforeEntryConditionProperty): any;
export declare function tfCodepipelineStageBeforeEntryConditionPropertyToHclTerraform(struct?: TfCodepipeline.StageBeforeEntryConditionPropertyOutputReference | TfCodepipeline.StageBeforeEntryConditionProperty): any;
export declare function tfCodepipelineBeforeEntryPropertyToTerraform(struct?: TfCodepipeline.BeforeEntryPropertyOutputReference | TfCodepipeline.BeforeEntryProperty): any;
export declare function tfCodepipelineBeforeEntryPropertyToHclTerraform(struct?: TfCodepipeline.BeforeEntryPropertyOutputReference | TfCodepipeline.BeforeEntryProperty): any;
export declare function tfCodepipelineStageOnFailureConditionRuleRuleTypeIdPropertyToTerraform(struct?: TfCodepipeline.StageOnFailureConditionRuleRuleTypeIdPropertyOutputReference | TfCodepipeline.StageOnFailureConditionRuleRuleTypeIdProperty): any;
export declare function tfCodepipelineStageOnFailureConditionRuleRuleTypeIdPropertyToHclTerraform(struct?: TfCodepipeline.StageOnFailureConditionRuleRuleTypeIdPropertyOutputReference | TfCodepipeline.StageOnFailureConditionRuleRuleTypeIdProperty): any;
export declare function tfCodepipelineStageOnFailureConditionRulePropertyToTerraform(struct?: TfCodepipeline.StageOnFailureConditionRuleProperty | cdktn.IResolvable): any;
export declare function tfCodepipelineStageOnFailureConditionRulePropertyToHclTerraform(struct?: TfCodepipeline.StageOnFailureConditionRuleProperty | cdktn.IResolvable): any;
export declare function tfCodepipelineStageOnFailureConditionPropertyToTerraform(struct?: TfCodepipeline.StageOnFailureConditionPropertyOutputReference | TfCodepipeline.StageOnFailureConditionProperty): any;
export declare function tfCodepipelineStageOnFailureConditionPropertyToHclTerraform(struct?: TfCodepipeline.StageOnFailureConditionPropertyOutputReference | TfCodepipeline.StageOnFailureConditionProperty): any;
export declare function tfCodepipelineRetryConfigurationPropertyToTerraform(struct?: TfCodepipeline.RetryConfigurationPropertyOutputReference | TfCodepipeline.RetryConfigurationProperty): any;
export declare function tfCodepipelineRetryConfigurationPropertyToHclTerraform(struct?: TfCodepipeline.RetryConfigurationPropertyOutputReference | TfCodepipeline.RetryConfigurationProperty): any;
export declare function tfCodepipelineOnFailurePropertyToTerraform(struct?: TfCodepipeline.OnFailurePropertyOutputReference | TfCodepipeline.OnFailureProperty): any;
export declare function tfCodepipelineOnFailurePropertyToHclTerraform(struct?: TfCodepipeline.OnFailurePropertyOutputReference | TfCodepipeline.OnFailureProperty): any;
export declare function tfCodepipelineStageOnSuccessConditionRuleRuleTypeIdPropertyToTerraform(struct?: TfCodepipeline.StageOnSuccessConditionRuleRuleTypeIdPropertyOutputReference | TfCodepipeline.StageOnSuccessConditionRuleRuleTypeIdProperty): any;
export declare function tfCodepipelineStageOnSuccessConditionRuleRuleTypeIdPropertyToHclTerraform(struct?: TfCodepipeline.StageOnSuccessConditionRuleRuleTypeIdPropertyOutputReference | TfCodepipeline.StageOnSuccessConditionRuleRuleTypeIdProperty): any;
export declare function tfCodepipelineStageOnSuccessConditionRulePropertyToTerraform(struct?: TfCodepipeline.StageOnSuccessConditionRuleProperty | cdktn.IResolvable): any;
export declare function tfCodepipelineStageOnSuccessConditionRulePropertyToHclTerraform(struct?: TfCodepipeline.StageOnSuccessConditionRuleProperty | cdktn.IResolvable): any;
export declare function tfCodepipelineStageOnSuccessConditionPropertyToTerraform(struct?: TfCodepipeline.StageOnSuccessConditionPropertyOutputReference | TfCodepipeline.StageOnSuccessConditionProperty): any;
export declare function tfCodepipelineStageOnSuccessConditionPropertyToHclTerraform(struct?: TfCodepipeline.StageOnSuccessConditionPropertyOutputReference | TfCodepipeline.StageOnSuccessConditionProperty): any;
export declare function tfCodepipelineOnSuccessPropertyToTerraform(struct?: TfCodepipeline.OnSuccessPropertyOutputReference | TfCodepipeline.OnSuccessProperty): any;
export declare function tfCodepipelineOnSuccessPropertyToHclTerraform(struct?: TfCodepipeline.OnSuccessPropertyOutputReference | TfCodepipeline.OnSuccessProperty): any;
export declare function tfCodepipelineStagePropertyToTerraform(struct?: TfCodepipeline.StageProperty | cdktn.IResolvable): any;
export declare function tfCodepipelineStagePropertyToHclTerraform(struct?: TfCodepipeline.StageProperty | cdktn.IResolvable): any;
export declare function tfCodepipelineTriggerGitConfigurationPullRequestBranchesPropertyToTerraform(struct?: TfCodepipeline.TriggerGitConfigurationPullRequestBranchesPropertyOutputReference | TfCodepipeline.TriggerGitConfigurationPullRequestBranchesProperty): any;
export declare function tfCodepipelineTriggerGitConfigurationPullRequestBranchesPropertyToHclTerraform(struct?: TfCodepipeline.TriggerGitConfigurationPullRequestBranchesPropertyOutputReference | TfCodepipeline.TriggerGitConfigurationPullRequestBranchesProperty): any;
export declare function tfCodepipelineTriggerGitConfigurationPullRequestFilePathsPropertyToTerraform(struct?: TfCodepipeline.TriggerGitConfigurationPullRequestFilePathsPropertyOutputReference | TfCodepipeline.TriggerGitConfigurationPullRequestFilePathsProperty): any;
export declare function tfCodepipelineTriggerGitConfigurationPullRequestFilePathsPropertyToHclTerraform(struct?: TfCodepipeline.TriggerGitConfigurationPullRequestFilePathsPropertyOutputReference | TfCodepipeline.TriggerGitConfigurationPullRequestFilePathsProperty): any;
export declare function tfCodepipelineTriggerGitConfigurationPullRequestPropertyToTerraform(struct?: TfCodepipeline.TriggerGitConfigurationPullRequestProperty | cdktn.IResolvable): any;
export declare function tfCodepipelineTriggerGitConfigurationPullRequestPropertyToHclTerraform(struct?: TfCodepipeline.TriggerGitConfigurationPullRequestProperty | cdktn.IResolvable): any;
export declare function tfCodepipelineTriggerGitConfigurationPushBranchesPropertyToTerraform(struct?: TfCodepipeline.TriggerGitConfigurationPushBranchesPropertyOutputReference | TfCodepipeline.TriggerGitConfigurationPushBranchesProperty): any;
export declare function tfCodepipelineTriggerGitConfigurationPushBranchesPropertyToHclTerraform(struct?: TfCodepipeline.TriggerGitConfigurationPushBranchesPropertyOutputReference | TfCodepipeline.TriggerGitConfigurationPushBranchesProperty): any;
export declare function tfCodepipelineTriggerGitConfigurationPushFilePathsPropertyToTerraform(struct?: TfCodepipeline.TriggerGitConfigurationPushFilePathsPropertyOutputReference | TfCodepipeline.TriggerGitConfigurationPushFilePathsProperty): any;
export declare function tfCodepipelineTriggerGitConfigurationPushFilePathsPropertyToHclTerraform(struct?: TfCodepipeline.TriggerGitConfigurationPushFilePathsPropertyOutputReference | TfCodepipeline.TriggerGitConfigurationPushFilePathsProperty): any;
export declare function tfCodepipelineTriggerGitConfigurationPushTagsPropertyToTerraform(struct?: TfCodepipeline.TriggerGitConfigurationPushTagsPropertyOutputReference | TfCodepipeline.TriggerGitConfigurationPushTagsProperty): any;
export declare function tfCodepipelineTriggerGitConfigurationPushTagsPropertyToHclTerraform(struct?: TfCodepipeline.TriggerGitConfigurationPushTagsPropertyOutputReference | TfCodepipeline.TriggerGitConfigurationPushTagsProperty): any;
export declare function tfCodepipelineTriggerGitConfigurationPushPropertyToTerraform(struct?: TfCodepipeline.TriggerGitConfigurationPushProperty | cdktn.IResolvable): any;
export declare function tfCodepipelineTriggerGitConfigurationPushPropertyToHclTerraform(struct?: TfCodepipeline.TriggerGitConfigurationPushProperty | cdktn.IResolvable): any;
export declare function tfCodepipelineTriggerGitConfigurationPropertyToTerraform(struct?: TfCodepipeline.TriggerGitConfigurationPropertyOutputReference | TfCodepipeline.TriggerGitConfigurationProperty): any;
export declare function tfCodepipelineTriggerGitConfigurationPropertyToHclTerraform(struct?: TfCodepipeline.TriggerGitConfigurationPropertyOutputReference | TfCodepipeline.TriggerGitConfigurationProperty): any;
export declare function tfCodepipelineTriggerPropertyToTerraform(struct?: TfCodepipeline.TriggerProperty | cdktn.IResolvable): any;
export declare function tfCodepipelineTriggerPropertyToHclTerraform(struct?: TfCodepipeline.TriggerProperty | cdktn.IResolvable): any;
export declare function tfCodepipelineVariablePropertyToTerraform(struct?: TfCodepipeline.VariableProperty | cdktn.IResolvable): any;
export declare function tfCodepipelineVariablePropertyToHclTerraform(struct?: TfCodepipeline.VariableProperty | cdktn.IResolvable): any;
export declare namespace TfCodepipeline {
    interface TriggerAllGitConfigurationPullRequestBranchesProperty {
    }
    class TriggerAllGitConfigurationPullRequestBranchesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TriggerAllGitConfigurationPullRequestBranchesProperty | undefined;
        set internalValue(value: TriggerAllGitConfigurationPullRequestBranchesProperty | undefined);
        get excludes(): string[];
        get includes(): string[];
    }
    class TriggerAllGitConfigurationPullRequestBranchesPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TriggerAllGitConfigurationPullRequestBranchesPropertyOutputReference;
    }
    interface TriggerAllGitConfigurationPullRequestFilePathsProperty {
    }
    class TriggerAllGitConfigurationPullRequestFilePathsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TriggerAllGitConfigurationPullRequestFilePathsProperty | undefined;
        set internalValue(value: TriggerAllGitConfigurationPullRequestFilePathsProperty | undefined);
        get excludes(): string[];
        get includes(): string[];
    }
    class TriggerAllGitConfigurationPullRequestFilePathsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TriggerAllGitConfigurationPullRequestFilePathsPropertyOutputReference;
    }
    interface TriggerAllGitConfigurationPullRequestProperty {
    }
    class TriggerAllGitConfigurationPullRequestPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TriggerAllGitConfigurationPullRequestProperty | undefined;
        set internalValue(value: TriggerAllGitConfigurationPullRequestProperty | undefined);
        private _branches;
        get branches(): TriggerAllGitConfigurationPullRequestBranchesPropertyList;
        get events(): string[];
        private _filePaths;
        get filePaths(): TriggerAllGitConfigurationPullRequestFilePathsPropertyList;
    }
    class TriggerAllGitConfigurationPullRequestPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TriggerAllGitConfigurationPullRequestPropertyOutputReference;
    }
    interface TriggerAllGitConfigurationPushBranchesProperty {
    }
    class TriggerAllGitConfigurationPushBranchesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TriggerAllGitConfigurationPushBranchesProperty | undefined;
        set internalValue(value: TriggerAllGitConfigurationPushBranchesProperty | undefined);
        get excludes(): string[];
        get includes(): string[];
    }
    class TriggerAllGitConfigurationPushBranchesPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TriggerAllGitConfigurationPushBranchesPropertyOutputReference;
    }
    interface TriggerAllGitConfigurationPushFilePathsProperty {
    }
    class TriggerAllGitConfigurationPushFilePathsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TriggerAllGitConfigurationPushFilePathsProperty | undefined;
        set internalValue(value: TriggerAllGitConfigurationPushFilePathsProperty | undefined);
        get excludes(): string[];
        get includes(): string[];
    }
    class TriggerAllGitConfigurationPushFilePathsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TriggerAllGitConfigurationPushFilePathsPropertyOutputReference;
    }
    interface TriggerAllGitConfigurationPushTagsProperty {
    }
    class TriggerAllGitConfigurationPushTagsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TriggerAllGitConfigurationPushTagsProperty | undefined;
        set internalValue(value: TriggerAllGitConfigurationPushTagsProperty | undefined);
        get excludes(): string[];
        get includes(): string[];
    }
    class TriggerAllGitConfigurationPushTagsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TriggerAllGitConfigurationPushTagsPropertyOutputReference;
    }
    interface TriggerAllGitConfigurationPushProperty {
    }
    class TriggerAllGitConfigurationPushPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TriggerAllGitConfigurationPushProperty | undefined;
        set internalValue(value: TriggerAllGitConfigurationPushProperty | undefined);
        private _branches;
        get branches(): TriggerAllGitConfigurationPushBranchesPropertyList;
        private _filePaths;
        get filePaths(): TriggerAllGitConfigurationPushFilePathsPropertyList;
        private _tags;
        get tags(): TriggerAllGitConfigurationPushTagsPropertyList;
    }
    class TriggerAllGitConfigurationPushPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TriggerAllGitConfigurationPushPropertyOutputReference;
    }
    interface TriggerAllGitConfigurationProperty {
    }
    class TriggerAllGitConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TriggerAllGitConfigurationProperty | undefined;
        set internalValue(value: TriggerAllGitConfigurationProperty | undefined);
        private _pullRequest;
        get pullRequest(): TriggerAllGitConfigurationPullRequestPropertyList;
        private _push;
        get push(): TriggerAllGitConfigurationPushPropertyList;
        get sourceActionName(): string;
    }
    class TriggerAllGitConfigurationPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TriggerAllGitConfigurationPropertyOutputReference;
    }
    interface TriggerAllProperty {
    }
    class TriggerAllPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TriggerAllProperty | undefined;
        set internalValue(value: TriggerAllProperty | undefined);
        private _gitConfiguration;
        get gitConfiguration(): TriggerAllGitConfigurationPropertyList;
        get providerType(): string;
    }
    class TriggerAllPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TriggerAllPropertyOutputReference;
    }
    interface EncryptionKeyProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#id TfCodepipeline#id}
        *
        * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
        * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
        */
        readonly id: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#type TfCodepipeline#type}
        */
        readonly type: string;
    }
    class EncryptionKeyPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): EncryptionKeyProperty | undefined;
        set internalValue(value: EncryptionKeyProperty | undefined);
        private _id?;
        get id(): string;
        set id(value: string);
        get idInput(): string | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
    }
    interface ArtifactStoreProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#location TfCodepipeline#location}
        */
        readonly location: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#region TfCodepipeline#region}
        */
        readonly region?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#type TfCodepipeline#type}
        */
        readonly type: string;
        /**
        * encryption_key block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#encryption_key TfCodepipeline#encryption_key}
        */
        readonly encryptionKey?: EncryptionKeyProperty;
    }
    class ArtifactStorePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ArtifactStoreProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ArtifactStoreProperty | cdktn.IResolvable | undefined);
        private _location?;
        get location(): string;
        set location(value: string);
        get locationInput(): string | undefined;
        private _region?;
        get region(): string;
        set region(value: string);
        resetRegion(): void;
        get regionInput(): string | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
        private _encryptionKey;
        get encryptionKey(): EncryptionKeyPropertyOutputReference;
        putEncryptionKey(value: EncryptionKeyProperty): void;
        resetEncryptionKey(): void;
        get encryptionKeyInput(): EncryptionKeyProperty | undefined;
    }
    class ArtifactStorePropertyList extends cdktn.ComplexList {
        internalValue?: ArtifactStoreProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ArtifactStorePropertyOutputReference;
    }
    interface OutputArtifactsForComputeActionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#files TfCodepipeline#files}
        */
        readonly files?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#name TfCodepipeline#name}
        */
        readonly name: string;
    }
    class OutputArtifactsForComputeActionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): OutputArtifactsForComputeActionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: OutputArtifactsForComputeActionProperty | cdktn.IResolvable | undefined);
        private _files?;
        get files(): string[];
        set files(value: string[]);
        resetFiles(): void;
        get filesInput(): string[] | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
    }
    class OutputArtifactsForComputeActionPropertyList extends cdktn.ComplexList {
        internalValue?: OutputArtifactsForComputeActionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): OutputArtifactsForComputeActionPropertyOutputReference;
    }
    interface ActionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#category TfCodepipeline#category}
        */
        readonly category: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#commands TfCodepipeline#commands}
        */
        readonly commands?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#configuration TfCodepipeline#configuration}
        */
        readonly configuration?: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#input_artifacts TfCodepipeline#input_artifacts}
        */
        readonly inputArtifacts?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#name TfCodepipeline#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#namespace TfCodepipeline#namespace}
        */
        readonly namespace?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#output_artifacts TfCodepipeline#output_artifacts}
        */
        readonly outputArtifacts?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#output_variables TfCodepipeline#output_variables}
        */
        readonly outputVariables?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#owner TfCodepipeline#owner}
        */
        readonly owner: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#provider TfCodepipeline#provider}
        */
        readonly provider: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#region TfCodepipeline#region}
        */
        readonly region?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#role_arn TfCodepipeline#role_arn}
        */
        readonly roleArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#run_order TfCodepipeline#run_order}
        */
        readonly runOrder?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#timeout_in_minutes TfCodepipeline#timeout_in_minutes}
        */
        readonly timeoutInMinutes?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#version TfCodepipeline#version}
        */
        readonly version: string;
        /**
        * output_artifacts_for_compute_action block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#output_artifacts_for_compute_action TfCodepipeline#output_artifacts_for_compute_action}
        */
        readonly outputArtifactsForComputeAction?: OutputArtifactsForComputeActionProperty[] | cdktn.IResolvable;
    }
    class ActionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ActionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ActionProperty | cdktn.IResolvable | undefined);
        private _category?;
        get category(): string;
        set category(value: string);
        get categoryInput(): string | undefined;
        private _commands?;
        get commands(): string[];
        set commands(value: string[]);
        resetCommands(): void;
        get commandsInput(): string[] | undefined;
        private _configuration?;
        get configuration(): {
            [key: string]: string;
        };
        set configuration(value: {
            [key: string]: string;
        });
        resetConfiguration(): void;
        get configurationInput(): {
            [key: string]: string;
        } | undefined;
        private _inputArtifacts?;
        get inputArtifacts(): string[];
        set inputArtifacts(value: string[]);
        resetInputArtifacts(): void;
        get inputArtifactsInput(): string[] | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _namespace?;
        get namespace(): string;
        set namespace(value: string);
        resetNamespace(): void;
        get namespaceInput(): string | undefined;
        private _outputArtifacts?;
        get outputArtifacts(): string[];
        set outputArtifacts(value: string[]);
        resetOutputArtifacts(): void;
        get outputArtifactsInput(): string[] | undefined;
        private _outputVariables?;
        get outputVariables(): string[];
        set outputVariables(value: string[]);
        resetOutputVariables(): void;
        get outputVariablesInput(): string[] | undefined;
        private _owner?;
        get owner(): string;
        set owner(value: string);
        get ownerInput(): string | undefined;
        private _provider?;
        get provider(): string;
        set provider(value: string);
        get providerInput(): string | undefined;
        private _region?;
        get region(): string;
        set region(value: string);
        resetRegion(): void;
        get regionInput(): string | undefined;
        private _roleArn?;
        get roleArn(): string;
        set roleArn(value: string);
        resetRoleArn(): void;
        get roleArnInput(): string | undefined;
        private _runOrder?;
        get runOrder(): number;
        set runOrder(value: number);
        resetRunOrder(): void;
        get runOrderInput(): number | undefined;
        private _timeoutInMinutes?;
        get timeoutInMinutes(): number;
        set timeoutInMinutes(value: number);
        resetTimeoutInMinutes(): void;
        get timeoutInMinutesInput(): number | undefined;
        private _version?;
        get version(): string;
        set version(value: string);
        get versionInput(): string | undefined;
        private _outputArtifactsForComputeAction;
        get outputArtifactsForComputeAction(): OutputArtifactsForComputeActionPropertyList;
        putOutputArtifactsForComputeAction(value: OutputArtifactsForComputeActionProperty[] | cdktn.IResolvable): void;
        resetOutputArtifactsForComputeAction(): void;
        get outputArtifactsForComputeActionInput(): cdktn.IResolvable | OutputArtifactsForComputeActionProperty[] | undefined;
    }
    class ActionPropertyList extends cdktn.ComplexList {
        internalValue?: ActionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ActionPropertyOutputReference;
    }
    interface StageBeforeEntryConditionRuleRuleTypeIdProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#category TfCodepipeline#category}
        */
        readonly category: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#owner TfCodepipeline#owner}
        */
        readonly owner?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#provider TfCodepipeline#provider}
        */
        readonly provider: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#version TfCodepipeline#version}
        */
        readonly version?: string;
    }
    class StageBeforeEntryConditionRuleRuleTypeIdPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): StageBeforeEntryConditionRuleRuleTypeIdProperty | undefined;
        set internalValue(value: StageBeforeEntryConditionRuleRuleTypeIdProperty | undefined);
        private _category?;
        get category(): string;
        set category(value: string);
        get categoryInput(): string | undefined;
        private _owner?;
        get owner(): string;
        set owner(value: string);
        resetOwner(): void;
        get ownerInput(): string | undefined;
        private _provider?;
        get provider(): string;
        set provider(value: string);
        get providerInput(): string | undefined;
        private _version?;
        get version(): string;
        set version(value: string);
        resetVersion(): void;
        get versionInput(): string | undefined;
    }
    interface StageBeforeEntryConditionRuleProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#commands TfCodepipeline#commands}
        */
        readonly commands?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#configuration TfCodepipeline#configuration}
        */
        readonly configuration?: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#input_artifacts TfCodepipeline#input_artifacts}
        */
        readonly inputArtifacts?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#name TfCodepipeline#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#region TfCodepipeline#region}
        */
        readonly region?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#role_arn TfCodepipeline#role_arn}
        */
        readonly roleArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#timeout_in_minutes TfCodepipeline#timeout_in_minutes}
        */
        readonly timeoutInMinutes?: number;
        /**
        * rule_type_id block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#rule_type_id TfCodepipeline#rule_type_id}
        */
        readonly ruleTypeId: StageBeforeEntryConditionRuleRuleTypeIdProperty;
    }
    class StageBeforeEntryConditionRulePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): StageBeforeEntryConditionRuleProperty | cdktn.IResolvable | undefined;
        set internalValue(value: StageBeforeEntryConditionRuleProperty | cdktn.IResolvable | undefined);
        private _commands?;
        get commands(): string[];
        set commands(value: string[]);
        resetCommands(): void;
        get commandsInput(): string[] | undefined;
        private _configuration?;
        get configuration(): {
            [key: string]: string;
        };
        set configuration(value: {
            [key: string]: string;
        });
        resetConfiguration(): void;
        get configurationInput(): {
            [key: string]: string;
        } | undefined;
        private _inputArtifacts?;
        get inputArtifacts(): string[];
        set inputArtifacts(value: string[]);
        resetInputArtifacts(): void;
        get inputArtifactsInput(): string[] | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _region?;
        get region(): string;
        set region(value: string);
        resetRegion(): void;
        get regionInput(): string | undefined;
        private _roleArn?;
        get roleArn(): string;
        set roleArn(value: string);
        resetRoleArn(): void;
        get roleArnInput(): string | undefined;
        private _timeoutInMinutes?;
        get timeoutInMinutes(): number;
        set timeoutInMinutes(value: number);
        resetTimeoutInMinutes(): void;
        get timeoutInMinutesInput(): number | undefined;
        private _ruleTypeId;
        get ruleTypeId(): StageBeforeEntryConditionRuleRuleTypeIdPropertyOutputReference;
        putRuleTypeId(value: StageBeforeEntryConditionRuleRuleTypeIdProperty): void;
        get ruleTypeIdInput(): StageBeforeEntryConditionRuleRuleTypeIdProperty | undefined;
    }
    class StageBeforeEntryConditionRulePropertyList extends cdktn.ComplexList {
        internalValue?: StageBeforeEntryConditionRuleProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): StageBeforeEntryConditionRulePropertyOutputReference;
    }
    interface StageBeforeEntryConditionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#result TfCodepipeline#result}
        */
        readonly result?: string;
        /**
        * rule block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#rule TfCodepipeline#rule}
        */
        readonly rule: StageBeforeEntryConditionRuleProperty[] | cdktn.IResolvable;
    }
    class StageBeforeEntryConditionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): StageBeforeEntryConditionProperty | undefined;
        set internalValue(value: StageBeforeEntryConditionProperty | undefined);
        private _result?;
        get result(): string;
        set result(value: string);
        resetResult(): void;
        get resultInput(): string | undefined;
        private _rule;
        get rule(): StageBeforeEntryConditionRulePropertyList;
        putRule(value: StageBeforeEntryConditionRuleProperty[] | cdktn.IResolvable): void;
        get ruleInput(): cdktn.IResolvable | StageBeforeEntryConditionRuleProperty[] | undefined;
    }
    interface BeforeEntryProperty {
        /**
        * condition block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#condition TfCodepipeline#condition}
        */
        readonly condition: StageBeforeEntryConditionProperty;
    }
    class BeforeEntryPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): BeforeEntryProperty | undefined;
        set internalValue(value: BeforeEntryProperty | undefined);
        private _condition;
        get condition(): StageBeforeEntryConditionPropertyOutputReference;
        putCondition(value: StageBeforeEntryConditionProperty): void;
        get conditionInput(): StageBeforeEntryConditionProperty | undefined;
    }
    interface StageOnFailureConditionRuleRuleTypeIdProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#category TfCodepipeline#category}
        */
        readonly category: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#owner TfCodepipeline#owner}
        */
        readonly owner?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#provider TfCodepipeline#provider}
        */
        readonly provider: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#version TfCodepipeline#version}
        */
        readonly version?: string;
    }
    class StageOnFailureConditionRuleRuleTypeIdPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): StageOnFailureConditionRuleRuleTypeIdProperty | undefined;
        set internalValue(value: StageOnFailureConditionRuleRuleTypeIdProperty | undefined);
        private _category?;
        get category(): string;
        set category(value: string);
        get categoryInput(): string | undefined;
        private _owner?;
        get owner(): string;
        set owner(value: string);
        resetOwner(): void;
        get ownerInput(): string | undefined;
        private _provider?;
        get provider(): string;
        set provider(value: string);
        get providerInput(): string | undefined;
        private _version?;
        get version(): string;
        set version(value: string);
        resetVersion(): void;
        get versionInput(): string | undefined;
    }
    interface StageOnFailureConditionRuleProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#commands TfCodepipeline#commands}
        */
        readonly commands?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#configuration TfCodepipeline#configuration}
        */
        readonly configuration?: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#input_artifacts TfCodepipeline#input_artifacts}
        */
        readonly inputArtifacts?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#name TfCodepipeline#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#region TfCodepipeline#region}
        */
        readonly region?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#role_arn TfCodepipeline#role_arn}
        */
        readonly roleArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#timeout_in_minutes TfCodepipeline#timeout_in_minutes}
        */
        readonly timeoutInMinutes?: number;
        /**
        * rule_type_id block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#rule_type_id TfCodepipeline#rule_type_id}
        */
        readonly ruleTypeId: StageOnFailureConditionRuleRuleTypeIdProperty;
    }
    class StageOnFailureConditionRulePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): StageOnFailureConditionRuleProperty | cdktn.IResolvable | undefined;
        set internalValue(value: StageOnFailureConditionRuleProperty | cdktn.IResolvable | undefined);
        private _commands?;
        get commands(): string[];
        set commands(value: string[]);
        resetCommands(): void;
        get commandsInput(): string[] | undefined;
        private _configuration?;
        get configuration(): {
            [key: string]: string;
        };
        set configuration(value: {
            [key: string]: string;
        });
        resetConfiguration(): void;
        get configurationInput(): {
            [key: string]: string;
        } | undefined;
        private _inputArtifacts?;
        get inputArtifacts(): string[];
        set inputArtifacts(value: string[]);
        resetInputArtifacts(): void;
        get inputArtifactsInput(): string[] | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _region?;
        get region(): string;
        set region(value: string);
        resetRegion(): void;
        get regionInput(): string | undefined;
        private _roleArn?;
        get roleArn(): string;
        set roleArn(value: string);
        resetRoleArn(): void;
        get roleArnInput(): string | undefined;
        private _timeoutInMinutes?;
        get timeoutInMinutes(): number;
        set timeoutInMinutes(value: number);
        resetTimeoutInMinutes(): void;
        get timeoutInMinutesInput(): number | undefined;
        private _ruleTypeId;
        get ruleTypeId(): StageOnFailureConditionRuleRuleTypeIdPropertyOutputReference;
        putRuleTypeId(value: StageOnFailureConditionRuleRuleTypeIdProperty): void;
        get ruleTypeIdInput(): StageOnFailureConditionRuleRuleTypeIdProperty | undefined;
    }
    class StageOnFailureConditionRulePropertyList extends cdktn.ComplexList {
        internalValue?: StageOnFailureConditionRuleProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): StageOnFailureConditionRulePropertyOutputReference;
    }
    interface StageOnFailureConditionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#result TfCodepipeline#result}
        */
        readonly result?: string;
        /**
        * rule block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#rule TfCodepipeline#rule}
        */
        readonly rule: StageOnFailureConditionRuleProperty[] | cdktn.IResolvable;
    }
    class StageOnFailureConditionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): StageOnFailureConditionProperty | undefined;
        set internalValue(value: StageOnFailureConditionProperty | undefined);
        private _result?;
        get result(): string;
        set result(value: string);
        resetResult(): void;
        get resultInput(): string | undefined;
        private _rule;
        get rule(): StageOnFailureConditionRulePropertyList;
        putRule(value: StageOnFailureConditionRuleProperty[] | cdktn.IResolvable): void;
        get ruleInput(): cdktn.IResolvable | StageOnFailureConditionRuleProperty[] | undefined;
    }
    interface RetryConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#retry_mode TfCodepipeline#retry_mode}
        */
        readonly retryMode?: string;
    }
    class RetryConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RetryConfigurationProperty | undefined;
        set internalValue(value: RetryConfigurationProperty | undefined);
        private _retryMode?;
        get retryMode(): string;
        set retryMode(value: string);
        resetRetryMode(): void;
        get retryModeInput(): string | undefined;
    }
    interface OnFailureProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#result TfCodepipeline#result}
        */
        readonly result?: string;
        /**
        * condition block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#condition TfCodepipeline#condition}
        */
        readonly condition?: StageOnFailureConditionProperty;
        /**
        * retry_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#retry_configuration TfCodepipeline#retry_configuration}
        */
        readonly retryConfiguration?: RetryConfigurationProperty;
    }
    class OnFailurePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): OnFailureProperty | undefined;
        set internalValue(value: OnFailureProperty | undefined);
        private _result?;
        get result(): string;
        set result(value: string);
        resetResult(): void;
        get resultInput(): string | undefined;
        private _condition;
        get condition(): StageOnFailureConditionPropertyOutputReference;
        putCondition(value: StageOnFailureConditionProperty): void;
        resetCondition(): void;
        get conditionInput(): StageOnFailureConditionProperty | undefined;
        private _retryConfiguration;
        get retryConfiguration(): RetryConfigurationPropertyOutputReference;
        putRetryConfiguration(value: RetryConfigurationProperty): void;
        resetRetryConfiguration(): void;
        get retryConfigurationInput(): RetryConfigurationProperty | undefined;
    }
    interface StageOnSuccessConditionRuleRuleTypeIdProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#category TfCodepipeline#category}
        */
        readonly category: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#owner TfCodepipeline#owner}
        */
        readonly owner?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#provider TfCodepipeline#provider}
        */
        readonly provider: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#version TfCodepipeline#version}
        */
        readonly version?: string;
    }
    class StageOnSuccessConditionRuleRuleTypeIdPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): StageOnSuccessConditionRuleRuleTypeIdProperty | undefined;
        set internalValue(value: StageOnSuccessConditionRuleRuleTypeIdProperty | undefined);
        private _category?;
        get category(): string;
        set category(value: string);
        get categoryInput(): string | undefined;
        private _owner?;
        get owner(): string;
        set owner(value: string);
        resetOwner(): void;
        get ownerInput(): string | undefined;
        private _provider?;
        get provider(): string;
        set provider(value: string);
        get providerInput(): string | undefined;
        private _version?;
        get version(): string;
        set version(value: string);
        resetVersion(): void;
        get versionInput(): string | undefined;
    }
    interface StageOnSuccessConditionRuleProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#commands TfCodepipeline#commands}
        */
        readonly commands?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#configuration TfCodepipeline#configuration}
        */
        readonly configuration?: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#input_artifacts TfCodepipeline#input_artifacts}
        */
        readonly inputArtifacts?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#name TfCodepipeline#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#region TfCodepipeline#region}
        */
        readonly region?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#role_arn TfCodepipeline#role_arn}
        */
        readonly roleArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#timeout_in_minutes TfCodepipeline#timeout_in_minutes}
        */
        readonly timeoutInMinutes?: number;
        /**
        * rule_type_id block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#rule_type_id TfCodepipeline#rule_type_id}
        */
        readonly ruleTypeId: StageOnSuccessConditionRuleRuleTypeIdProperty;
    }
    class StageOnSuccessConditionRulePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): StageOnSuccessConditionRuleProperty | cdktn.IResolvable | undefined;
        set internalValue(value: StageOnSuccessConditionRuleProperty | cdktn.IResolvable | undefined);
        private _commands?;
        get commands(): string[];
        set commands(value: string[]);
        resetCommands(): void;
        get commandsInput(): string[] | undefined;
        private _configuration?;
        get configuration(): {
            [key: string]: string;
        };
        set configuration(value: {
            [key: string]: string;
        });
        resetConfiguration(): void;
        get configurationInput(): {
            [key: string]: string;
        } | undefined;
        private _inputArtifacts?;
        get inputArtifacts(): string[];
        set inputArtifacts(value: string[]);
        resetInputArtifacts(): void;
        get inputArtifactsInput(): string[] | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _region?;
        get region(): string;
        set region(value: string);
        resetRegion(): void;
        get regionInput(): string | undefined;
        private _roleArn?;
        get roleArn(): string;
        set roleArn(value: string);
        resetRoleArn(): void;
        get roleArnInput(): string | undefined;
        private _timeoutInMinutes?;
        get timeoutInMinutes(): number;
        set timeoutInMinutes(value: number);
        resetTimeoutInMinutes(): void;
        get timeoutInMinutesInput(): number | undefined;
        private _ruleTypeId;
        get ruleTypeId(): StageOnSuccessConditionRuleRuleTypeIdPropertyOutputReference;
        putRuleTypeId(value: StageOnSuccessConditionRuleRuleTypeIdProperty): void;
        get ruleTypeIdInput(): StageOnSuccessConditionRuleRuleTypeIdProperty | undefined;
    }
    class StageOnSuccessConditionRulePropertyList extends cdktn.ComplexList {
        internalValue?: StageOnSuccessConditionRuleProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): StageOnSuccessConditionRulePropertyOutputReference;
    }
    interface StageOnSuccessConditionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#result TfCodepipeline#result}
        */
        readonly result?: string;
        /**
        * rule block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#rule TfCodepipeline#rule}
        */
        readonly rule: StageOnSuccessConditionRuleProperty[] | cdktn.IResolvable;
    }
    class StageOnSuccessConditionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): StageOnSuccessConditionProperty | undefined;
        set internalValue(value: StageOnSuccessConditionProperty | undefined);
        private _result?;
        get result(): string;
        set result(value: string);
        resetResult(): void;
        get resultInput(): string | undefined;
        private _rule;
        get rule(): StageOnSuccessConditionRulePropertyList;
        putRule(value: StageOnSuccessConditionRuleProperty[] | cdktn.IResolvable): void;
        get ruleInput(): cdktn.IResolvable | StageOnSuccessConditionRuleProperty[] | undefined;
    }
    interface OnSuccessProperty {
        /**
        * condition block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#condition TfCodepipeline#condition}
        */
        readonly condition: StageOnSuccessConditionProperty;
    }
    class OnSuccessPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): OnSuccessProperty | undefined;
        set internalValue(value: OnSuccessProperty | undefined);
        private _condition;
        get condition(): StageOnSuccessConditionPropertyOutputReference;
        putCondition(value: StageOnSuccessConditionProperty): void;
        get conditionInput(): StageOnSuccessConditionProperty | undefined;
    }
    interface StageProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#name TfCodepipeline#name}
        */
        readonly name: string;
        /**
        * action block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#action TfCodepipeline#action}
        */
        readonly action: ActionProperty[] | cdktn.IResolvable;
        /**
        * before_entry block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#before_entry TfCodepipeline#before_entry}
        */
        readonly beforeEntry?: BeforeEntryProperty;
        /**
        * on_failure block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#on_failure TfCodepipeline#on_failure}
        */
        readonly onFailure?: OnFailureProperty;
        /**
        * on_success block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#on_success TfCodepipeline#on_success}
        */
        readonly onSuccess?: OnSuccessProperty;
    }
    class StagePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): StageProperty | cdktn.IResolvable | undefined;
        set internalValue(value: StageProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _action;
        get action(): ActionPropertyList;
        putAction(value: ActionProperty[] | cdktn.IResolvable): void;
        get actionInput(): cdktn.IResolvable | ActionProperty[] | undefined;
        private _beforeEntry;
        get beforeEntry(): BeforeEntryPropertyOutputReference;
        putBeforeEntry(value: BeforeEntryProperty): void;
        resetBeforeEntry(): void;
        get beforeEntryInput(): BeforeEntryProperty | undefined;
        private _onFailure;
        get onFailure(): OnFailurePropertyOutputReference;
        putOnFailure(value: OnFailureProperty): void;
        resetOnFailure(): void;
        get onFailureInput(): OnFailureProperty | undefined;
        private _onSuccess;
        get onSuccess(): OnSuccessPropertyOutputReference;
        putOnSuccess(value: OnSuccessProperty): void;
        resetOnSuccess(): void;
        get onSuccessInput(): OnSuccessProperty | undefined;
    }
    class StagePropertyList extends cdktn.ComplexList {
        internalValue?: StageProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): StagePropertyOutputReference;
    }
    interface TriggerGitConfigurationPullRequestBranchesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#excludes TfCodepipeline#excludes}
        */
        readonly excludes?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#includes TfCodepipeline#includes}
        */
        readonly includes?: string[];
    }
    class TriggerGitConfigurationPullRequestBranchesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TriggerGitConfigurationPullRequestBranchesProperty | undefined;
        set internalValue(value: TriggerGitConfigurationPullRequestBranchesProperty | undefined);
        private _excludes?;
        get excludes(): string[];
        set excludes(value: string[]);
        resetExcludes(): void;
        get excludesInput(): string[] | undefined;
        private _includes?;
        get includes(): string[];
        set includes(value: string[]);
        resetIncludes(): void;
        get includesInput(): string[] | undefined;
    }
    interface TriggerGitConfigurationPullRequestFilePathsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#excludes TfCodepipeline#excludes}
        */
        readonly excludes?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#includes TfCodepipeline#includes}
        */
        readonly includes?: string[];
    }
    class TriggerGitConfigurationPullRequestFilePathsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TriggerGitConfigurationPullRequestFilePathsProperty | undefined;
        set internalValue(value: TriggerGitConfigurationPullRequestFilePathsProperty | undefined);
        private _excludes?;
        get excludes(): string[];
        set excludes(value: string[]);
        resetExcludes(): void;
        get excludesInput(): string[] | undefined;
        private _includes?;
        get includes(): string[];
        set includes(value: string[]);
        resetIncludes(): void;
        get includesInput(): string[] | undefined;
    }
    interface TriggerGitConfigurationPullRequestProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#events TfCodepipeline#events}
        */
        readonly events?: string[];
        /**
        * branches block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#branches TfCodepipeline#branches}
        */
        readonly branches?: TriggerGitConfigurationPullRequestBranchesProperty;
        /**
        * file_paths block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#file_paths TfCodepipeline#file_paths}
        */
        readonly filePaths?: TriggerGitConfigurationPullRequestFilePathsProperty;
    }
    class TriggerGitConfigurationPullRequestPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TriggerGitConfigurationPullRequestProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TriggerGitConfigurationPullRequestProperty | cdktn.IResolvable | undefined);
        private _events?;
        get events(): string[];
        set events(value: string[]);
        resetEvents(): void;
        get eventsInput(): string[] | undefined;
        private _branches;
        get branches(): TriggerGitConfigurationPullRequestBranchesPropertyOutputReference;
        putBranches(value: TriggerGitConfigurationPullRequestBranchesProperty): void;
        resetBranches(): void;
        get branchesInput(): TriggerGitConfigurationPullRequestBranchesProperty | undefined;
        private _filePaths;
        get filePaths(): TriggerGitConfigurationPullRequestFilePathsPropertyOutputReference;
        putFilePaths(value: TriggerGitConfigurationPullRequestFilePathsProperty): void;
        resetFilePaths(): void;
        get filePathsInput(): TriggerGitConfigurationPullRequestFilePathsProperty | undefined;
    }
    class TriggerGitConfigurationPullRequestPropertyList extends cdktn.ComplexList {
        internalValue?: TriggerGitConfigurationPullRequestProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TriggerGitConfigurationPullRequestPropertyOutputReference;
    }
    interface TriggerGitConfigurationPushBranchesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#excludes TfCodepipeline#excludes}
        */
        readonly excludes?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#includes TfCodepipeline#includes}
        */
        readonly includes?: string[];
    }
    class TriggerGitConfigurationPushBranchesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TriggerGitConfigurationPushBranchesProperty | undefined;
        set internalValue(value: TriggerGitConfigurationPushBranchesProperty | undefined);
        private _excludes?;
        get excludes(): string[];
        set excludes(value: string[]);
        resetExcludes(): void;
        get excludesInput(): string[] | undefined;
        private _includes?;
        get includes(): string[];
        set includes(value: string[]);
        resetIncludes(): void;
        get includesInput(): string[] | undefined;
    }
    interface TriggerGitConfigurationPushFilePathsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#excludes TfCodepipeline#excludes}
        */
        readonly excludes?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#includes TfCodepipeline#includes}
        */
        readonly includes?: string[];
    }
    class TriggerGitConfigurationPushFilePathsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TriggerGitConfigurationPushFilePathsProperty | undefined;
        set internalValue(value: TriggerGitConfigurationPushFilePathsProperty | undefined);
        private _excludes?;
        get excludes(): string[];
        set excludes(value: string[]);
        resetExcludes(): void;
        get excludesInput(): string[] | undefined;
        private _includes?;
        get includes(): string[];
        set includes(value: string[]);
        resetIncludes(): void;
        get includesInput(): string[] | undefined;
    }
    interface TriggerGitConfigurationPushTagsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#excludes TfCodepipeline#excludes}
        */
        readonly excludes?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#includes TfCodepipeline#includes}
        */
        readonly includes?: string[];
    }
    class TriggerGitConfigurationPushTagsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TriggerGitConfigurationPushTagsProperty | undefined;
        set internalValue(value: TriggerGitConfigurationPushTagsProperty | undefined);
        private _excludes?;
        get excludes(): string[];
        set excludes(value: string[]);
        resetExcludes(): void;
        get excludesInput(): string[] | undefined;
        private _includes?;
        get includes(): string[];
        set includes(value: string[]);
        resetIncludes(): void;
        get includesInput(): string[] | undefined;
    }
    interface TriggerGitConfigurationPushProperty {
        /**
        * branches block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#branches TfCodepipeline#branches}
        */
        readonly branches?: TriggerGitConfigurationPushBranchesProperty;
        /**
        * file_paths block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#file_paths TfCodepipeline#file_paths}
        */
        readonly filePaths?: TriggerGitConfigurationPushFilePathsProperty;
        /**
        * tags block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#tags TfCodepipeline#tags}
        */
        readonly tags?: TriggerGitConfigurationPushTagsProperty;
    }
    class TriggerGitConfigurationPushPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TriggerGitConfigurationPushProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TriggerGitConfigurationPushProperty | cdktn.IResolvable | undefined);
        private _branches;
        get branches(): TriggerGitConfigurationPushBranchesPropertyOutputReference;
        putBranches(value: TriggerGitConfigurationPushBranchesProperty): void;
        resetBranches(): void;
        get branchesInput(): TriggerGitConfigurationPushBranchesProperty | undefined;
        private _filePaths;
        get filePaths(): TriggerGitConfigurationPushFilePathsPropertyOutputReference;
        putFilePaths(value: TriggerGitConfigurationPushFilePathsProperty): void;
        resetFilePaths(): void;
        get filePathsInput(): TriggerGitConfigurationPushFilePathsProperty | undefined;
        private _tags;
        get tags(): TriggerGitConfigurationPushTagsPropertyOutputReference;
        putTags(value: TriggerGitConfigurationPushTagsProperty): void;
        resetTags(): void;
        get tagsInput(): TriggerGitConfigurationPushTagsProperty | undefined;
    }
    class TriggerGitConfigurationPushPropertyList extends cdktn.ComplexList {
        internalValue?: TriggerGitConfigurationPushProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TriggerGitConfigurationPushPropertyOutputReference;
    }
    interface TriggerGitConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#source_action_name TfCodepipeline#source_action_name}
        */
        readonly sourceActionName: string;
        /**
        * pull_request block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#pull_request TfCodepipeline#pull_request}
        */
        readonly pullRequest?: TriggerGitConfigurationPullRequestProperty[] | cdktn.IResolvable;
        /**
        * push block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#push TfCodepipeline#push}
        */
        readonly push?: TriggerGitConfigurationPushProperty[] | cdktn.IResolvable;
    }
    class TriggerGitConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TriggerGitConfigurationProperty | undefined;
        set internalValue(value: TriggerGitConfigurationProperty | undefined);
        private _sourceActionName?;
        get sourceActionName(): string;
        set sourceActionName(value: string);
        get sourceActionNameInput(): string | undefined;
        private _pullRequest;
        get pullRequest(): TriggerGitConfigurationPullRequestPropertyList;
        putPullRequest(value: TriggerGitConfigurationPullRequestProperty[] | cdktn.IResolvable): void;
        resetPullRequest(): void;
        get pullRequestInput(): cdktn.IResolvable | TriggerGitConfigurationPullRequestProperty[] | undefined;
        private _push;
        get push(): TriggerGitConfigurationPushPropertyList;
        putPush(value: TriggerGitConfigurationPushProperty[] | cdktn.IResolvable): void;
        resetPush(): void;
        get pushInput(): cdktn.IResolvable | TriggerGitConfigurationPushProperty[] | undefined;
    }
    interface TriggerProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#provider_type TfCodepipeline#provider_type}
        */
        readonly providerType: string;
        /**
        * git_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#git_configuration TfCodepipeline#git_configuration}
        */
        readonly gitConfiguration: TriggerGitConfigurationProperty;
    }
    class TriggerPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TriggerProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TriggerProperty | cdktn.IResolvable | undefined);
        private _providerType?;
        get providerType(): string;
        set providerType(value: string);
        get providerTypeInput(): string | undefined;
        private _gitConfiguration;
        get gitConfiguration(): TriggerGitConfigurationPropertyOutputReference;
        putGitConfiguration(value: TriggerGitConfigurationProperty): void;
        get gitConfigurationInput(): TriggerGitConfigurationProperty | undefined;
    }
    class TriggerPropertyList extends cdktn.ComplexList {
        internalValue?: TriggerProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TriggerPropertyOutputReference;
    }
    interface VariableProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#default_value TfCodepipeline#default_value}
        */
        readonly defaultValue?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#description TfCodepipeline#description}
        */
        readonly description?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#name TfCodepipeline#name}
        */
        readonly name: string;
    }
    class VariablePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): VariableProperty | cdktn.IResolvable | undefined;
        set internalValue(value: VariableProperty | cdktn.IResolvable | undefined);
        private _defaultValue?;
        get defaultValue(): string;
        set defaultValue(value: string);
        resetDefaultValue(): void;
        get defaultValueInput(): string | undefined;
        private _description?;
        get description(): string;
        set description(value: string);
        resetDescription(): void;
        get descriptionInput(): string | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
    }
    class VariablePropertyList extends cdktn.ComplexList {
        internalValue?: VariableProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): VariablePropertyOutputReference;
    }
}
