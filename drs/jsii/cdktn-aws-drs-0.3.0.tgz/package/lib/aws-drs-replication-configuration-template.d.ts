import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsReplicationConfigurationTemplateConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/drs_replication_configuration_template#associate_default_security_group AwsReplicationConfigurationTemplate#associate_default_security_group}
    */
    readonly associateDefaultSecurityGroup: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/drs_replication_configuration_template#auto_replicate_new_disks AwsReplicationConfigurationTemplate#auto_replicate_new_disks}
    */
    readonly autoReplicateNewDisks?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/drs_replication_configuration_template#bandwidth_throttling AwsReplicationConfigurationTemplate#bandwidth_throttling}
    */
    readonly bandwidthThrottling: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/drs_replication_configuration_template#create_public_ip AwsReplicationConfigurationTemplate#create_public_ip}
    */
    readonly createPublicIp: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/drs_replication_configuration_template#data_plane_routing AwsReplicationConfigurationTemplate#data_plane_routing}
    */
    readonly dataPlaneRouting: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/drs_replication_configuration_template#default_large_staging_disk_type AwsReplicationConfigurationTemplate#default_large_staging_disk_type}
    */
    readonly defaultLargeStagingDiskType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/drs_replication_configuration_template#ebs_encryption AwsReplicationConfigurationTemplate#ebs_encryption}
    */
    readonly ebsEncryption: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/drs_replication_configuration_template#ebs_encryption_key_arn AwsReplicationConfigurationTemplate#ebs_encryption_key_arn}
    */
    readonly ebsEncryptionKeyArn?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/drs_replication_configuration_template#region AwsReplicationConfigurationTemplate#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/drs_replication_configuration_template#replication_server_instance_type AwsReplicationConfigurationTemplate#replication_server_instance_type}
    */
    readonly replicationServerInstanceType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/drs_replication_configuration_template#replication_servers_security_groups_ids AwsReplicationConfigurationTemplate#replication_servers_security_groups_ids}
    */
    readonly replicationServersSecurityGroupsIds: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/drs_replication_configuration_template#staging_area_subnet_id AwsReplicationConfigurationTemplate#staging_area_subnet_id}
    */
    readonly stagingAreaSubnetId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/drs_replication_configuration_template#staging_area_tags AwsReplicationConfigurationTemplate#staging_area_tags}
    */
    readonly stagingAreaTags: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/drs_replication_configuration_template#tags AwsReplicationConfigurationTemplate#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/drs_replication_configuration_template#use_dedicated_replication_server AwsReplicationConfigurationTemplate#use_dedicated_replication_server}
    */
    readonly useDedicatedReplicationServer: boolean | cdktn.IResolvable;
    /**
    * pit_policy block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/drs_replication_configuration_template#pit_policy AwsReplicationConfigurationTemplate#pit_policy}
    */
    readonly pitPolicy?: AwsReplicationConfigurationTemplate.PitPolicyProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/drs_replication_configuration_template#timeouts AwsReplicationConfigurationTemplate#timeouts}
    */
    readonly timeouts?: AwsReplicationConfigurationTemplate.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/drs_replication_configuration_template aws_drs_replication_configuration_template}
*/
export declare class AwsReplicationConfigurationTemplate extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_drs_replication_configuration_template";
    /**
    * Generates CDKTN code for importing a AwsReplicationConfigurationTemplate resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsReplicationConfigurationTemplate to import
    * @param importFromId The id of the existing AwsReplicationConfigurationTemplate that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/drs_replication_configuration_template#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsReplicationConfigurationTemplate to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/drs_replication_configuration_template aws_drs_replication_configuration_template} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsReplicationConfigurationTemplateConfig
    */
    constructor(scope: Construct, id: string, config: AwsReplicationConfigurationTemplateConfig);
    get arn(): string;
    private _associateDefaultSecurityGroup?;
    get associateDefaultSecurityGroup(): boolean | cdktn.IResolvable;
    set associateDefaultSecurityGroup(value: boolean | cdktn.IResolvable);
    get associateDefaultSecurityGroupInput(): boolean | cdktn.IResolvable | undefined;
    private _autoReplicateNewDisks?;
    get autoReplicateNewDisks(): boolean | cdktn.IResolvable;
    set autoReplicateNewDisks(value: boolean | cdktn.IResolvable);
    resetAutoReplicateNewDisks(): void;
    get autoReplicateNewDisksInput(): boolean | cdktn.IResolvable | undefined;
    private _bandwidthThrottling?;
    get bandwidthThrottling(): number;
    set bandwidthThrottling(value: number);
    get bandwidthThrottlingInput(): number | undefined;
    private _createPublicIp?;
    get createPublicIp(): boolean | cdktn.IResolvable;
    set createPublicIp(value: boolean | cdktn.IResolvable);
    get createPublicIpInput(): boolean | cdktn.IResolvable | undefined;
    private _dataPlaneRouting?;
    get dataPlaneRouting(): string;
    set dataPlaneRouting(value: string);
    get dataPlaneRoutingInput(): string | undefined;
    private _defaultLargeStagingDiskType?;
    get defaultLargeStagingDiskType(): string;
    set defaultLargeStagingDiskType(value: string);
    get defaultLargeStagingDiskTypeInput(): string | undefined;
    private _ebsEncryption?;
    get ebsEncryption(): string;
    set ebsEncryption(value: string);
    get ebsEncryptionInput(): string | undefined;
    private _ebsEncryptionKeyArn?;
    get ebsEncryptionKeyArn(): string;
    set ebsEncryptionKeyArn(value: string);
    resetEbsEncryptionKeyArn(): void;
    get ebsEncryptionKeyArnInput(): string | undefined;
    get id(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _replicationServerInstanceType?;
    get replicationServerInstanceType(): string;
    set replicationServerInstanceType(value: string);
    get replicationServerInstanceTypeInput(): string | undefined;
    private _replicationServersSecurityGroupsIds?;
    get replicationServersSecurityGroupsIds(): string[];
    set replicationServersSecurityGroupsIds(value: string[]);
    get replicationServersSecurityGroupsIdsInput(): string[] | undefined;
    private _stagingAreaSubnetId?;
    get stagingAreaSubnetId(): string;
    set stagingAreaSubnetId(value: string);
    get stagingAreaSubnetIdInput(): string | undefined;
    private _stagingAreaTags?;
    get stagingAreaTags(): {
        [key: string]: string;
    };
    set stagingAreaTags(value: {
        [key: string]: string;
    });
    get stagingAreaTagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    private _useDedicatedReplicationServer?;
    get useDedicatedReplicationServer(): boolean | cdktn.IResolvable;
    set useDedicatedReplicationServer(value: boolean | cdktn.IResolvable);
    get useDedicatedReplicationServerInput(): boolean | cdktn.IResolvable | undefined;
    private _pitPolicy;
    get pitPolicy(): AwsReplicationConfigurationTemplate.PitPolicyPropertyList;
    putPitPolicy(value: AwsReplicationConfigurationTemplate.PitPolicyProperty[] | cdktn.IResolvable): void;
    resetPitPolicy(): void;
    get pitPolicyInput(): cdktn.IResolvable | AwsReplicationConfigurationTemplate.PitPolicyProperty[] | undefined;
    private _timeouts;
    get timeouts(): AwsReplicationConfigurationTemplate.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsReplicationConfigurationTemplate.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsReplicationConfigurationTemplate.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsReplicationConfigurationTemplatePitPolicyPropertyToTerraform(struct?: AwsReplicationConfigurationTemplate.PitPolicyProperty | cdktn.IResolvable): any;
export declare function awsReplicationConfigurationTemplatePitPolicyPropertyToHclTerraform(struct?: AwsReplicationConfigurationTemplate.PitPolicyProperty | cdktn.IResolvable): any;
export declare function awsReplicationConfigurationTemplateTimeoutsPropertyToTerraform(struct?: AwsReplicationConfigurationTemplate.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsReplicationConfigurationTemplateTimeoutsPropertyToHclTerraform(struct?: AwsReplicationConfigurationTemplate.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsReplicationConfigurationTemplate {
    interface PitPolicyProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/drs_replication_configuration_template#enabled AwsReplicationConfigurationTemplate#enabled}
        */
        readonly enabled?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/drs_replication_configuration_template#interval AwsReplicationConfigurationTemplate#interval}
        */
        readonly interval: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/drs_replication_configuration_template#retention_duration AwsReplicationConfigurationTemplate#retention_duration}
        */
        readonly retentionDuration: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/drs_replication_configuration_template#rule_id AwsReplicationConfigurationTemplate#rule_id}
        */
        readonly ruleId?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/drs_replication_configuration_template#units AwsReplicationConfigurationTemplate#units}
        */
        readonly units: string;
    }
    class PitPolicyPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): PitPolicyProperty | cdktn.IResolvable | undefined;
        set internalValue(value: PitPolicyProperty | cdktn.IResolvable | undefined);
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        resetEnabled(): void;
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
        private _interval?;
        get interval(): number;
        set interval(value: number);
        get intervalInput(): number | undefined;
        private _retentionDuration?;
        get retentionDuration(): number;
        set retentionDuration(value: number);
        get retentionDurationInput(): number | undefined;
        private _ruleId?;
        get ruleId(): number;
        set ruleId(value: number);
        resetRuleId(): void;
        get ruleIdInput(): number | undefined;
        private _units?;
        get units(): string;
        set units(value: string);
        get unitsInput(): string | undefined;
    }
    class PitPolicyPropertyList extends cdktn.ComplexList {
        internalValue?: PitPolicyProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): PitPolicyPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/drs_replication_configuration_template#create AwsReplicationConfigurationTemplate#create}
        */
        readonly create?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Setting a timeout for a Delete operation is only applicable if changes are saved into state before the destroy operation occurs.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/drs_replication_configuration_template#delete AwsReplicationConfigurationTemplate#delete}
        */
        readonly delete?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/drs_replication_configuration_template#update AwsReplicationConfigurationTemplate#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
