import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsGatewayRouteConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#id AwsGatewayRoute#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#mesh_name AwsGatewayRoute#mesh_name}
    */
    readonly meshName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#mesh_owner AwsGatewayRoute#mesh_owner}
    */
    readonly meshOwner?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#name AwsGatewayRoute#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#region AwsGatewayRoute#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#tags AwsGatewayRoute#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#tags_all AwsGatewayRoute#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#virtual_gateway_name AwsGatewayRoute#virtual_gateway_name}
    */
    readonly virtualGatewayName: string;
    /**
    * spec block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#spec AwsGatewayRoute#spec}
    */
    readonly spec: AwsGatewayRoute.SpecProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route aws_appmesh_gateway_route}
*/
export declare class AwsGatewayRoute extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_appmesh_gateway_route";
    /**
    * Generates CDKTN code for importing a AwsGatewayRoute resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsGatewayRoute to import
    * @param importFromId The id of the existing AwsGatewayRoute that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsGatewayRoute to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route aws_appmesh_gateway_route} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsGatewayRouteConfig
    */
    constructor(scope: Construct, id: string, config: AwsGatewayRouteConfig);
    get arn(): string;
    get createdDate(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get lastUpdatedDate(): string;
    private _meshName?;
    get meshName(): string;
    set meshName(value: string);
    get meshNameInput(): string | undefined;
    private _meshOwner?;
    get meshOwner(): string;
    set meshOwner(value: string);
    resetMeshOwner(): void;
    get meshOwnerInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get resourceOwner(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _virtualGatewayName?;
    get virtualGatewayName(): string;
    set virtualGatewayName(value: string);
    get virtualGatewayNameInput(): string | undefined;
    private _spec;
    get spec(): AwsGatewayRoute.SpecPropertyOutputReference;
    putSpec(value: AwsGatewayRoute.SpecProperty): void;
    get specInput(): AwsGatewayRoute.SpecProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsGatewayRouteSpecGrpcRouteActionTargetVirtualServicePropertyToTerraform(struct?: AwsGatewayRoute.SpecGrpcRouteActionTargetVirtualServicePropertyOutputReference | AwsGatewayRoute.SpecGrpcRouteActionTargetVirtualServiceProperty): any;
export declare function awsGatewayRouteSpecGrpcRouteActionTargetVirtualServicePropertyToHclTerraform(struct?: AwsGatewayRoute.SpecGrpcRouteActionTargetVirtualServicePropertyOutputReference | AwsGatewayRoute.SpecGrpcRouteActionTargetVirtualServiceProperty): any;
export declare function awsGatewayRouteSpecGrpcRouteActionTargetPropertyToTerraform(struct?: AwsGatewayRoute.SpecGrpcRouteActionTargetPropertyOutputReference | AwsGatewayRoute.SpecGrpcRouteActionTargetProperty): any;
export declare function awsGatewayRouteSpecGrpcRouteActionTargetPropertyToHclTerraform(struct?: AwsGatewayRoute.SpecGrpcRouteActionTargetPropertyOutputReference | AwsGatewayRoute.SpecGrpcRouteActionTargetProperty): any;
export declare function awsGatewayRouteSpecGrpcRouteActionPropertyToTerraform(struct?: AwsGatewayRoute.SpecGrpcRouteActionPropertyOutputReference | AwsGatewayRoute.SpecGrpcRouteActionProperty): any;
export declare function awsGatewayRouteSpecGrpcRouteActionPropertyToHclTerraform(struct?: AwsGatewayRoute.SpecGrpcRouteActionPropertyOutputReference | AwsGatewayRoute.SpecGrpcRouteActionProperty): any;
export declare function awsGatewayRouteSpecGrpcRouteMatchPropertyToTerraform(struct?: AwsGatewayRoute.SpecGrpcRouteMatchPropertyOutputReference | AwsGatewayRoute.SpecGrpcRouteMatchProperty): any;
export declare function awsGatewayRouteSpecGrpcRouteMatchPropertyToHclTerraform(struct?: AwsGatewayRoute.SpecGrpcRouteMatchPropertyOutputReference | AwsGatewayRoute.SpecGrpcRouteMatchProperty): any;
export declare function awsGatewayRouteGrpcRoutePropertyToTerraform(struct?: AwsGatewayRoute.GrpcRoutePropertyOutputReference | AwsGatewayRoute.GrpcRouteProperty): any;
export declare function awsGatewayRouteGrpcRoutePropertyToHclTerraform(struct?: AwsGatewayRoute.GrpcRoutePropertyOutputReference | AwsGatewayRoute.GrpcRouteProperty): any;
export declare function awsGatewayRouteSpecHttp2RouteActionRewriteHostnamePropertyToTerraform(struct?: AwsGatewayRoute.SpecHttp2RouteActionRewriteHostnamePropertyOutputReference | AwsGatewayRoute.SpecHttp2RouteActionRewriteHostnameProperty): any;
export declare function awsGatewayRouteSpecHttp2RouteActionRewriteHostnamePropertyToHclTerraform(struct?: AwsGatewayRoute.SpecHttp2RouteActionRewriteHostnamePropertyOutputReference | AwsGatewayRoute.SpecHttp2RouteActionRewriteHostnameProperty): any;
export declare function awsGatewayRouteSpecHttp2RouteActionRewritePathPropertyToTerraform(struct?: AwsGatewayRoute.SpecHttp2RouteActionRewritePathPropertyOutputReference | AwsGatewayRoute.SpecHttp2RouteActionRewritePathProperty): any;
export declare function awsGatewayRouteSpecHttp2RouteActionRewritePathPropertyToHclTerraform(struct?: AwsGatewayRoute.SpecHttp2RouteActionRewritePathPropertyOutputReference | AwsGatewayRoute.SpecHttp2RouteActionRewritePathProperty): any;
export declare function awsGatewayRouteSpecHttp2RouteActionRewritePrefixPropertyToTerraform(struct?: AwsGatewayRoute.SpecHttp2RouteActionRewritePrefixPropertyOutputReference | AwsGatewayRoute.SpecHttp2RouteActionRewritePrefixProperty): any;
export declare function awsGatewayRouteSpecHttp2RouteActionRewritePrefixPropertyToHclTerraform(struct?: AwsGatewayRoute.SpecHttp2RouteActionRewritePrefixPropertyOutputReference | AwsGatewayRoute.SpecHttp2RouteActionRewritePrefixProperty): any;
export declare function awsGatewayRouteSpecHttp2RouteActionRewritePropertyToTerraform(struct?: AwsGatewayRoute.SpecHttp2RouteActionRewritePropertyOutputReference | AwsGatewayRoute.SpecHttp2RouteActionRewriteProperty): any;
export declare function awsGatewayRouteSpecHttp2RouteActionRewritePropertyToHclTerraform(struct?: AwsGatewayRoute.SpecHttp2RouteActionRewritePropertyOutputReference | AwsGatewayRoute.SpecHttp2RouteActionRewriteProperty): any;
export declare function awsGatewayRouteSpecHttp2RouteActionTargetVirtualServicePropertyToTerraform(struct?: AwsGatewayRoute.SpecHttp2RouteActionTargetVirtualServicePropertyOutputReference | AwsGatewayRoute.SpecHttp2RouteActionTargetVirtualServiceProperty): any;
export declare function awsGatewayRouteSpecHttp2RouteActionTargetVirtualServicePropertyToHclTerraform(struct?: AwsGatewayRoute.SpecHttp2RouteActionTargetVirtualServicePropertyOutputReference | AwsGatewayRoute.SpecHttp2RouteActionTargetVirtualServiceProperty): any;
export declare function awsGatewayRouteSpecHttp2RouteActionTargetPropertyToTerraform(struct?: AwsGatewayRoute.SpecHttp2RouteActionTargetPropertyOutputReference | AwsGatewayRoute.SpecHttp2RouteActionTargetProperty): any;
export declare function awsGatewayRouteSpecHttp2RouteActionTargetPropertyToHclTerraform(struct?: AwsGatewayRoute.SpecHttp2RouteActionTargetPropertyOutputReference | AwsGatewayRoute.SpecHttp2RouteActionTargetProperty): any;
export declare function awsGatewayRouteSpecHttp2RouteActionPropertyToTerraform(struct?: AwsGatewayRoute.SpecHttp2RouteActionPropertyOutputReference | AwsGatewayRoute.SpecHttp2RouteActionProperty): any;
export declare function awsGatewayRouteSpecHttp2RouteActionPropertyToHclTerraform(struct?: AwsGatewayRoute.SpecHttp2RouteActionPropertyOutputReference | AwsGatewayRoute.SpecHttp2RouteActionProperty): any;
export declare function awsGatewayRouteSpecHttp2RouteMatchHeaderMatchRangePropertyToTerraform(struct?: AwsGatewayRoute.SpecHttp2RouteMatchHeaderMatchRangePropertyOutputReference | AwsGatewayRoute.SpecHttp2RouteMatchHeaderMatchRangeProperty): any;
export declare function awsGatewayRouteSpecHttp2RouteMatchHeaderMatchRangePropertyToHclTerraform(struct?: AwsGatewayRoute.SpecHttp2RouteMatchHeaderMatchRangePropertyOutputReference | AwsGatewayRoute.SpecHttp2RouteMatchHeaderMatchRangeProperty): any;
export declare function awsGatewayRouteSpecHttp2RouteMatchHeaderMatchPropertyToTerraform(struct?: AwsGatewayRoute.SpecHttp2RouteMatchHeaderMatchPropertyOutputReference | AwsGatewayRoute.SpecHttp2RouteMatchHeaderMatchProperty): any;
export declare function awsGatewayRouteSpecHttp2RouteMatchHeaderMatchPropertyToHclTerraform(struct?: AwsGatewayRoute.SpecHttp2RouteMatchHeaderMatchPropertyOutputReference | AwsGatewayRoute.SpecHttp2RouteMatchHeaderMatchProperty): any;
export declare function awsGatewayRouteSpecHttp2RouteMatchHeaderPropertyToTerraform(struct?: AwsGatewayRoute.SpecHttp2RouteMatchHeaderProperty | cdktn.IResolvable): any;
export declare function awsGatewayRouteSpecHttp2RouteMatchHeaderPropertyToHclTerraform(struct?: AwsGatewayRoute.SpecHttp2RouteMatchHeaderProperty | cdktn.IResolvable): any;
export declare function awsGatewayRouteSpecHttp2RouteMatchHostnamePropertyToTerraform(struct?: AwsGatewayRoute.SpecHttp2RouteMatchHostnamePropertyOutputReference | AwsGatewayRoute.SpecHttp2RouteMatchHostnameProperty): any;
export declare function awsGatewayRouteSpecHttp2RouteMatchHostnamePropertyToHclTerraform(struct?: AwsGatewayRoute.SpecHttp2RouteMatchHostnamePropertyOutputReference | AwsGatewayRoute.SpecHttp2RouteMatchHostnameProperty): any;
export declare function awsGatewayRouteSpecHttp2RouteMatchPathPropertyToTerraform(struct?: AwsGatewayRoute.SpecHttp2RouteMatchPathPropertyOutputReference | AwsGatewayRoute.SpecHttp2RouteMatchPathProperty): any;
export declare function awsGatewayRouteSpecHttp2RouteMatchPathPropertyToHclTerraform(struct?: AwsGatewayRoute.SpecHttp2RouteMatchPathPropertyOutputReference | AwsGatewayRoute.SpecHttp2RouteMatchPathProperty): any;
export declare function awsGatewayRouteSpecHttp2RouteMatchQueryParameterMatchPropertyToTerraform(struct?: AwsGatewayRoute.SpecHttp2RouteMatchQueryParameterMatchPropertyOutputReference | AwsGatewayRoute.SpecHttp2RouteMatchQueryParameterMatchProperty): any;
export declare function awsGatewayRouteSpecHttp2RouteMatchQueryParameterMatchPropertyToHclTerraform(struct?: AwsGatewayRoute.SpecHttp2RouteMatchQueryParameterMatchPropertyOutputReference | AwsGatewayRoute.SpecHttp2RouteMatchQueryParameterMatchProperty): any;
export declare function awsGatewayRouteSpecHttp2RouteMatchQueryParameterPropertyToTerraform(struct?: AwsGatewayRoute.SpecHttp2RouteMatchQueryParameterProperty | cdktn.IResolvable): any;
export declare function awsGatewayRouteSpecHttp2RouteMatchQueryParameterPropertyToHclTerraform(struct?: AwsGatewayRoute.SpecHttp2RouteMatchQueryParameterProperty | cdktn.IResolvable): any;
export declare function awsGatewayRouteSpecHttp2RouteMatchPropertyToTerraform(struct?: AwsGatewayRoute.SpecHttp2RouteMatchPropertyOutputReference | AwsGatewayRoute.SpecHttp2RouteMatchProperty): any;
export declare function awsGatewayRouteSpecHttp2RouteMatchPropertyToHclTerraform(struct?: AwsGatewayRoute.SpecHttp2RouteMatchPropertyOutputReference | AwsGatewayRoute.SpecHttp2RouteMatchProperty): any;
export declare function awsGatewayRouteHttp2RoutePropertyToTerraform(struct?: AwsGatewayRoute.Http2RoutePropertyOutputReference | AwsGatewayRoute.Http2RouteProperty): any;
export declare function awsGatewayRouteHttp2RoutePropertyToHclTerraform(struct?: AwsGatewayRoute.Http2RoutePropertyOutputReference | AwsGatewayRoute.Http2RouteProperty): any;
export declare function awsGatewayRouteSpecHttpRouteActionRewriteHostnamePropertyToTerraform(struct?: AwsGatewayRoute.SpecHttpRouteActionRewriteHostnamePropertyOutputReference | AwsGatewayRoute.SpecHttpRouteActionRewriteHostnameProperty): any;
export declare function awsGatewayRouteSpecHttpRouteActionRewriteHostnamePropertyToHclTerraform(struct?: AwsGatewayRoute.SpecHttpRouteActionRewriteHostnamePropertyOutputReference | AwsGatewayRoute.SpecHttpRouteActionRewriteHostnameProperty): any;
export declare function awsGatewayRouteSpecHttpRouteActionRewritePathPropertyToTerraform(struct?: AwsGatewayRoute.SpecHttpRouteActionRewritePathPropertyOutputReference | AwsGatewayRoute.SpecHttpRouteActionRewritePathProperty): any;
export declare function awsGatewayRouteSpecHttpRouteActionRewritePathPropertyToHclTerraform(struct?: AwsGatewayRoute.SpecHttpRouteActionRewritePathPropertyOutputReference | AwsGatewayRoute.SpecHttpRouteActionRewritePathProperty): any;
export declare function awsGatewayRouteSpecHttpRouteActionRewritePrefixPropertyToTerraform(struct?: AwsGatewayRoute.SpecHttpRouteActionRewritePrefixPropertyOutputReference | AwsGatewayRoute.SpecHttpRouteActionRewritePrefixProperty): any;
export declare function awsGatewayRouteSpecHttpRouteActionRewritePrefixPropertyToHclTerraform(struct?: AwsGatewayRoute.SpecHttpRouteActionRewritePrefixPropertyOutputReference | AwsGatewayRoute.SpecHttpRouteActionRewritePrefixProperty): any;
export declare function awsGatewayRouteSpecHttpRouteActionRewritePropertyToTerraform(struct?: AwsGatewayRoute.SpecHttpRouteActionRewritePropertyOutputReference | AwsGatewayRoute.SpecHttpRouteActionRewriteProperty): any;
export declare function awsGatewayRouteSpecHttpRouteActionRewritePropertyToHclTerraform(struct?: AwsGatewayRoute.SpecHttpRouteActionRewritePropertyOutputReference | AwsGatewayRoute.SpecHttpRouteActionRewriteProperty): any;
export declare function awsGatewayRouteSpecHttpRouteActionTargetVirtualServicePropertyToTerraform(struct?: AwsGatewayRoute.SpecHttpRouteActionTargetVirtualServicePropertyOutputReference | AwsGatewayRoute.SpecHttpRouteActionTargetVirtualServiceProperty): any;
export declare function awsGatewayRouteSpecHttpRouteActionTargetVirtualServicePropertyToHclTerraform(struct?: AwsGatewayRoute.SpecHttpRouteActionTargetVirtualServicePropertyOutputReference | AwsGatewayRoute.SpecHttpRouteActionTargetVirtualServiceProperty): any;
export declare function awsGatewayRouteSpecHttpRouteActionTargetPropertyToTerraform(struct?: AwsGatewayRoute.SpecHttpRouteActionTargetPropertyOutputReference | AwsGatewayRoute.SpecHttpRouteActionTargetProperty): any;
export declare function awsGatewayRouteSpecHttpRouteActionTargetPropertyToHclTerraform(struct?: AwsGatewayRoute.SpecHttpRouteActionTargetPropertyOutputReference | AwsGatewayRoute.SpecHttpRouteActionTargetProperty): any;
export declare function awsGatewayRouteSpecHttpRouteActionPropertyToTerraform(struct?: AwsGatewayRoute.SpecHttpRouteActionPropertyOutputReference | AwsGatewayRoute.SpecHttpRouteActionProperty): any;
export declare function awsGatewayRouteSpecHttpRouteActionPropertyToHclTerraform(struct?: AwsGatewayRoute.SpecHttpRouteActionPropertyOutputReference | AwsGatewayRoute.SpecHttpRouteActionProperty): any;
export declare function awsGatewayRouteSpecHttpRouteMatchHeaderMatchRangePropertyToTerraform(struct?: AwsGatewayRoute.SpecHttpRouteMatchHeaderMatchRangePropertyOutputReference | AwsGatewayRoute.SpecHttpRouteMatchHeaderMatchRangeProperty): any;
export declare function awsGatewayRouteSpecHttpRouteMatchHeaderMatchRangePropertyToHclTerraform(struct?: AwsGatewayRoute.SpecHttpRouteMatchHeaderMatchRangePropertyOutputReference | AwsGatewayRoute.SpecHttpRouteMatchHeaderMatchRangeProperty): any;
export declare function awsGatewayRouteSpecHttpRouteMatchHeaderMatchPropertyToTerraform(struct?: AwsGatewayRoute.SpecHttpRouteMatchHeaderMatchPropertyOutputReference | AwsGatewayRoute.SpecHttpRouteMatchHeaderMatchProperty): any;
export declare function awsGatewayRouteSpecHttpRouteMatchHeaderMatchPropertyToHclTerraform(struct?: AwsGatewayRoute.SpecHttpRouteMatchHeaderMatchPropertyOutputReference | AwsGatewayRoute.SpecHttpRouteMatchHeaderMatchProperty): any;
export declare function awsGatewayRouteSpecHttpRouteMatchHeaderPropertyToTerraform(struct?: AwsGatewayRoute.SpecHttpRouteMatchHeaderProperty | cdktn.IResolvable): any;
export declare function awsGatewayRouteSpecHttpRouteMatchHeaderPropertyToHclTerraform(struct?: AwsGatewayRoute.SpecHttpRouteMatchHeaderProperty | cdktn.IResolvable): any;
export declare function awsGatewayRouteSpecHttpRouteMatchHostnamePropertyToTerraform(struct?: AwsGatewayRoute.SpecHttpRouteMatchHostnamePropertyOutputReference | AwsGatewayRoute.SpecHttpRouteMatchHostnameProperty): any;
export declare function awsGatewayRouteSpecHttpRouteMatchHostnamePropertyToHclTerraform(struct?: AwsGatewayRoute.SpecHttpRouteMatchHostnamePropertyOutputReference | AwsGatewayRoute.SpecHttpRouteMatchHostnameProperty): any;
export declare function awsGatewayRouteSpecHttpRouteMatchPathPropertyToTerraform(struct?: AwsGatewayRoute.SpecHttpRouteMatchPathPropertyOutputReference | AwsGatewayRoute.SpecHttpRouteMatchPathProperty): any;
export declare function awsGatewayRouteSpecHttpRouteMatchPathPropertyToHclTerraform(struct?: AwsGatewayRoute.SpecHttpRouteMatchPathPropertyOutputReference | AwsGatewayRoute.SpecHttpRouteMatchPathProperty): any;
export declare function awsGatewayRouteSpecHttpRouteMatchQueryParameterMatchPropertyToTerraform(struct?: AwsGatewayRoute.SpecHttpRouteMatchQueryParameterMatchPropertyOutputReference | AwsGatewayRoute.SpecHttpRouteMatchQueryParameterMatchProperty): any;
export declare function awsGatewayRouteSpecHttpRouteMatchQueryParameterMatchPropertyToHclTerraform(struct?: AwsGatewayRoute.SpecHttpRouteMatchQueryParameterMatchPropertyOutputReference | AwsGatewayRoute.SpecHttpRouteMatchQueryParameterMatchProperty): any;
export declare function awsGatewayRouteSpecHttpRouteMatchQueryParameterPropertyToTerraform(struct?: AwsGatewayRoute.SpecHttpRouteMatchQueryParameterProperty | cdktn.IResolvable): any;
export declare function awsGatewayRouteSpecHttpRouteMatchQueryParameterPropertyToHclTerraform(struct?: AwsGatewayRoute.SpecHttpRouteMatchQueryParameterProperty | cdktn.IResolvable): any;
export declare function awsGatewayRouteSpecHttpRouteMatchPropertyToTerraform(struct?: AwsGatewayRoute.SpecHttpRouteMatchPropertyOutputReference | AwsGatewayRoute.SpecHttpRouteMatchProperty): any;
export declare function awsGatewayRouteSpecHttpRouteMatchPropertyToHclTerraform(struct?: AwsGatewayRoute.SpecHttpRouteMatchPropertyOutputReference | AwsGatewayRoute.SpecHttpRouteMatchProperty): any;
export declare function awsGatewayRouteHttpRoutePropertyToTerraform(struct?: AwsGatewayRoute.HttpRoutePropertyOutputReference | AwsGatewayRoute.HttpRouteProperty): any;
export declare function awsGatewayRouteHttpRoutePropertyToHclTerraform(struct?: AwsGatewayRoute.HttpRoutePropertyOutputReference | AwsGatewayRoute.HttpRouteProperty): any;
export declare function awsGatewayRouteSpecPropertyToTerraform(struct?: AwsGatewayRoute.SpecPropertyOutputReference | AwsGatewayRoute.SpecProperty): any;
export declare function awsGatewayRouteSpecPropertyToHclTerraform(struct?: AwsGatewayRoute.SpecPropertyOutputReference | AwsGatewayRoute.SpecProperty): any;
export declare namespace AwsGatewayRoute {
    interface SpecGrpcRouteActionTargetVirtualServiceProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#virtual_service_name AwsGatewayRoute#virtual_service_name}
        */
        readonly virtualServiceName: string;
    }
    class SpecGrpcRouteActionTargetVirtualServicePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecGrpcRouteActionTargetVirtualServiceProperty | undefined;
        set internalValue(value: SpecGrpcRouteActionTargetVirtualServiceProperty | undefined);
        private _virtualServiceName?;
        get virtualServiceName(): string;
        set virtualServiceName(value: string);
        get virtualServiceNameInput(): string | undefined;
    }
    interface SpecGrpcRouteActionTargetProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#port AwsGatewayRoute#port}
        */
        readonly port?: number;
        /**
        * virtual_service block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#virtual_service AwsGatewayRoute#virtual_service}
        */
        readonly virtualService: SpecGrpcRouteActionTargetVirtualServiceProperty;
    }
    class SpecGrpcRouteActionTargetPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecGrpcRouteActionTargetProperty | undefined;
        set internalValue(value: SpecGrpcRouteActionTargetProperty | undefined);
        private _port?;
        get port(): number;
        set port(value: number);
        resetPort(): void;
        get portInput(): number | undefined;
        private _virtualService;
        get virtualService(): SpecGrpcRouteActionTargetVirtualServicePropertyOutputReference;
        putVirtualService(value: SpecGrpcRouteActionTargetVirtualServiceProperty): void;
        get virtualServiceInput(): SpecGrpcRouteActionTargetVirtualServiceProperty | undefined;
    }
    interface SpecGrpcRouteActionProperty {
        /**
        * target block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#target AwsGatewayRoute#target}
        */
        readonly target: SpecGrpcRouteActionTargetProperty;
    }
    class SpecGrpcRouteActionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecGrpcRouteActionProperty | undefined;
        set internalValue(value: SpecGrpcRouteActionProperty | undefined);
        private _target;
        get target(): SpecGrpcRouteActionTargetPropertyOutputReference;
        putTarget(value: SpecGrpcRouteActionTargetProperty): void;
        get targetInput(): SpecGrpcRouteActionTargetProperty | undefined;
    }
    interface SpecGrpcRouteMatchProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#port AwsGatewayRoute#port}
        */
        readonly port?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#service_name AwsGatewayRoute#service_name}
        */
        readonly serviceName: string;
    }
    class SpecGrpcRouteMatchPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecGrpcRouteMatchProperty | undefined;
        set internalValue(value: SpecGrpcRouteMatchProperty | undefined);
        private _port?;
        get port(): number;
        set port(value: number);
        resetPort(): void;
        get portInput(): number | undefined;
        private _serviceName?;
        get serviceName(): string;
        set serviceName(value: string);
        get serviceNameInput(): string | undefined;
    }
    interface GrpcRouteProperty {
        /**
        * action block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#action AwsGatewayRoute#action}
        */
        readonly action: SpecGrpcRouteActionProperty;
        /**
        * match block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#match AwsGatewayRoute#match}
        */
        readonly match: SpecGrpcRouteMatchProperty;
    }
    class GrpcRoutePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): GrpcRouteProperty | undefined;
        set internalValue(value: GrpcRouteProperty | undefined);
        private _action;
        get action(): SpecGrpcRouteActionPropertyOutputReference;
        putAction(value: SpecGrpcRouteActionProperty): void;
        get actionInput(): SpecGrpcRouteActionProperty | undefined;
        private _match;
        get match(): SpecGrpcRouteMatchPropertyOutputReference;
        putMatch(value: SpecGrpcRouteMatchProperty): void;
        get matchInput(): SpecGrpcRouteMatchProperty | undefined;
    }
    interface SpecHttp2RouteActionRewriteHostnameProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#default_target_hostname AwsGatewayRoute#default_target_hostname}
        */
        readonly defaultTargetHostname: string;
    }
    class SpecHttp2RouteActionRewriteHostnamePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecHttp2RouteActionRewriteHostnameProperty | undefined;
        set internalValue(value: SpecHttp2RouteActionRewriteHostnameProperty | undefined);
        private _defaultTargetHostname?;
        get defaultTargetHostname(): string;
        set defaultTargetHostname(value: string);
        get defaultTargetHostnameInput(): string | undefined;
    }
    interface SpecHttp2RouteActionRewritePathProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#exact AwsGatewayRoute#exact}
        */
        readonly exact: string;
    }
    class SpecHttp2RouteActionRewritePathPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecHttp2RouteActionRewritePathProperty | undefined;
        set internalValue(value: SpecHttp2RouteActionRewritePathProperty | undefined);
        private _exact?;
        get exact(): string;
        set exact(value: string);
        get exactInput(): string | undefined;
    }
    interface SpecHttp2RouteActionRewritePrefixProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#default_prefix AwsGatewayRoute#default_prefix}
        */
        readonly defaultPrefix?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#value AwsGatewayRoute#value}
        */
        readonly value?: string;
    }
    class SpecHttp2RouteActionRewritePrefixPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecHttp2RouteActionRewritePrefixProperty | undefined;
        set internalValue(value: SpecHttp2RouteActionRewritePrefixProperty | undefined);
        private _defaultPrefix?;
        get defaultPrefix(): string;
        set defaultPrefix(value: string);
        resetDefaultPrefix(): void;
        get defaultPrefixInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        resetValue(): void;
        get valueInput(): string | undefined;
    }
    interface SpecHttp2RouteActionRewriteProperty {
        /**
        * hostname block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#hostname AwsGatewayRoute#hostname}
        */
        readonly hostname?: SpecHttp2RouteActionRewriteHostnameProperty;
        /**
        * path block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#path AwsGatewayRoute#path}
        */
        readonly path?: SpecHttp2RouteActionRewritePathProperty;
        /**
        * prefix block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#prefix AwsGatewayRoute#prefix}
        */
        readonly prefix?: SpecHttp2RouteActionRewritePrefixProperty;
    }
    class SpecHttp2RouteActionRewritePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecHttp2RouteActionRewriteProperty | undefined;
        set internalValue(value: SpecHttp2RouteActionRewriteProperty | undefined);
        private _hostname;
        get hostname(): SpecHttp2RouteActionRewriteHostnamePropertyOutputReference;
        putHostname(value: SpecHttp2RouteActionRewriteHostnameProperty): void;
        resetHostname(): void;
        get hostnameInput(): SpecHttp2RouteActionRewriteHostnameProperty | undefined;
        private _path;
        get path(): SpecHttp2RouteActionRewritePathPropertyOutputReference;
        putPath(value: SpecHttp2RouteActionRewritePathProperty): void;
        resetPath(): void;
        get pathInput(): SpecHttp2RouteActionRewritePathProperty | undefined;
        private _prefix;
        get prefix(): SpecHttp2RouteActionRewritePrefixPropertyOutputReference;
        putPrefix(value: SpecHttp2RouteActionRewritePrefixProperty): void;
        resetPrefix(): void;
        get prefixInput(): SpecHttp2RouteActionRewritePrefixProperty | undefined;
    }
    interface SpecHttp2RouteActionTargetVirtualServiceProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#virtual_service_name AwsGatewayRoute#virtual_service_name}
        */
        readonly virtualServiceName: string;
    }
    class SpecHttp2RouteActionTargetVirtualServicePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecHttp2RouteActionTargetVirtualServiceProperty | undefined;
        set internalValue(value: SpecHttp2RouteActionTargetVirtualServiceProperty | undefined);
        private _virtualServiceName?;
        get virtualServiceName(): string;
        set virtualServiceName(value: string);
        get virtualServiceNameInput(): string | undefined;
    }
    interface SpecHttp2RouteActionTargetProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#port AwsGatewayRoute#port}
        */
        readonly port?: number;
        /**
        * virtual_service block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#virtual_service AwsGatewayRoute#virtual_service}
        */
        readonly virtualService: SpecHttp2RouteActionTargetVirtualServiceProperty;
    }
    class SpecHttp2RouteActionTargetPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecHttp2RouteActionTargetProperty | undefined;
        set internalValue(value: SpecHttp2RouteActionTargetProperty | undefined);
        private _port?;
        get port(): number;
        set port(value: number);
        resetPort(): void;
        get portInput(): number | undefined;
        private _virtualService;
        get virtualService(): SpecHttp2RouteActionTargetVirtualServicePropertyOutputReference;
        putVirtualService(value: SpecHttp2RouteActionTargetVirtualServiceProperty): void;
        get virtualServiceInput(): SpecHttp2RouteActionTargetVirtualServiceProperty | undefined;
    }
    interface SpecHttp2RouteActionProperty {
        /**
        * rewrite block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#rewrite AwsGatewayRoute#rewrite}
        */
        readonly rewrite?: SpecHttp2RouteActionRewriteProperty;
        /**
        * target block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#target AwsGatewayRoute#target}
        */
        readonly target: SpecHttp2RouteActionTargetProperty;
    }
    class SpecHttp2RouteActionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecHttp2RouteActionProperty | undefined;
        set internalValue(value: SpecHttp2RouteActionProperty | undefined);
        private _rewrite;
        get rewrite(): SpecHttp2RouteActionRewritePropertyOutputReference;
        putRewrite(value: SpecHttp2RouteActionRewriteProperty): void;
        resetRewrite(): void;
        get rewriteInput(): SpecHttp2RouteActionRewriteProperty | undefined;
        private _target;
        get target(): SpecHttp2RouteActionTargetPropertyOutputReference;
        putTarget(value: SpecHttp2RouteActionTargetProperty): void;
        get targetInput(): SpecHttp2RouteActionTargetProperty | undefined;
    }
    interface SpecHttp2RouteMatchHeaderMatchRangeProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#end AwsGatewayRoute#end}
        */
        readonly end: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#start AwsGatewayRoute#start}
        */
        readonly start: number;
    }
    class SpecHttp2RouteMatchHeaderMatchRangePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecHttp2RouteMatchHeaderMatchRangeProperty | undefined;
        set internalValue(value: SpecHttp2RouteMatchHeaderMatchRangeProperty | undefined);
        private _end?;
        get end(): number;
        set end(value: number);
        get endInput(): number | undefined;
        private _start?;
        get start(): number;
        set start(value: number);
        get startInput(): number | undefined;
    }
    interface SpecHttp2RouteMatchHeaderMatchProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#exact AwsGatewayRoute#exact}
        */
        readonly exact?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#prefix AwsGatewayRoute#prefix}
        */
        readonly prefix?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#regex AwsGatewayRoute#regex}
        */
        readonly regex?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#suffix AwsGatewayRoute#suffix}
        */
        readonly suffix?: string;
        /**
        * range block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#range AwsGatewayRoute#range}
        */
        readonly range?: SpecHttp2RouteMatchHeaderMatchRangeProperty;
    }
    class SpecHttp2RouteMatchHeaderMatchPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecHttp2RouteMatchHeaderMatchProperty | undefined;
        set internalValue(value: SpecHttp2RouteMatchHeaderMatchProperty | undefined);
        private _exact?;
        get exact(): string;
        set exact(value: string);
        resetExact(): void;
        get exactInput(): string | undefined;
        private _prefix?;
        get prefix(): string;
        set prefix(value: string);
        resetPrefix(): void;
        get prefixInput(): string | undefined;
        private _regex?;
        get regex(): string;
        set regex(value: string);
        resetRegex(): void;
        get regexInput(): string | undefined;
        private _suffix?;
        get suffix(): string;
        set suffix(value: string);
        resetSuffix(): void;
        get suffixInput(): string | undefined;
        private _range;
        get range(): SpecHttp2RouteMatchHeaderMatchRangePropertyOutputReference;
        putRange(value: SpecHttp2RouteMatchHeaderMatchRangeProperty): void;
        resetRange(): void;
        get rangeInput(): SpecHttp2RouteMatchHeaderMatchRangeProperty | undefined;
    }
    interface SpecHttp2RouteMatchHeaderProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#invert AwsGatewayRoute#invert}
        */
        readonly invert?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#name AwsGatewayRoute#name}
        */
        readonly name: string;
        /**
        * match block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#match AwsGatewayRoute#match}
        */
        readonly match?: SpecHttp2RouteMatchHeaderMatchProperty;
    }
    class SpecHttp2RouteMatchHeaderPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecHttp2RouteMatchHeaderProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SpecHttp2RouteMatchHeaderProperty | cdktn.IResolvable | undefined);
        private _invert?;
        get invert(): boolean | cdktn.IResolvable;
        set invert(value: boolean | cdktn.IResolvable);
        resetInvert(): void;
        get invertInput(): boolean | cdktn.IResolvable | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _match;
        get match(): SpecHttp2RouteMatchHeaderMatchPropertyOutputReference;
        putMatch(value: SpecHttp2RouteMatchHeaderMatchProperty): void;
        resetMatch(): void;
        get matchInput(): SpecHttp2RouteMatchHeaderMatchProperty | undefined;
    }
    class SpecHttp2RouteMatchHeaderPropertyList extends cdktn.ComplexList {
        internalValue?: SpecHttp2RouteMatchHeaderProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecHttp2RouteMatchHeaderPropertyOutputReference;
    }
    interface SpecHttp2RouteMatchHostnameProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#exact AwsGatewayRoute#exact}
        */
        readonly exact?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#suffix AwsGatewayRoute#suffix}
        */
        readonly suffix?: string;
    }
    class SpecHttp2RouteMatchHostnamePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecHttp2RouteMatchHostnameProperty | undefined;
        set internalValue(value: SpecHttp2RouteMatchHostnameProperty | undefined);
        private _exact?;
        get exact(): string;
        set exact(value: string);
        resetExact(): void;
        get exactInput(): string | undefined;
        private _suffix?;
        get suffix(): string;
        set suffix(value: string);
        resetSuffix(): void;
        get suffixInput(): string | undefined;
    }
    interface SpecHttp2RouteMatchPathProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#exact AwsGatewayRoute#exact}
        */
        readonly exact?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#regex AwsGatewayRoute#regex}
        */
        readonly regex?: string;
    }
    class SpecHttp2RouteMatchPathPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecHttp2RouteMatchPathProperty | undefined;
        set internalValue(value: SpecHttp2RouteMatchPathProperty | undefined);
        private _exact?;
        get exact(): string;
        set exact(value: string);
        resetExact(): void;
        get exactInput(): string | undefined;
        private _regex?;
        get regex(): string;
        set regex(value: string);
        resetRegex(): void;
        get regexInput(): string | undefined;
    }
    interface SpecHttp2RouteMatchQueryParameterMatchProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#exact AwsGatewayRoute#exact}
        */
        readonly exact?: string;
    }
    class SpecHttp2RouteMatchQueryParameterMatchPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecHttp2RouteMatchQueryParameterMatchProperty | undefined;
        set internalValue(value: SpecHttp2RouteMatchQueryParameterMatchProperty | undefined);
        private _exact?;
        get exact(): string;
        set exact(value: string);
        resetExact(): void;
        get exactInput(): string | undefined;
    }
    interface SpecHttp2RouteMatchQueryParameterProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#name AwsGatewayRoute#name}
        */
        readonly name: string;
        /**
        * match block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#match AwsGatewayRoute#match}
        */
        readonly match?: SpecHttp2RouteMatchQueryParameterMatchProperty;
    }
    class SpecHttp2RouteMatchQueryParameterPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecHttp2RouteMatchQueryParameterProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SpecHttp2RouteMatchQueryParameterProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _match;
        get match(): SpecHttp2RouteMatchQueryParameterMatchPropertyOutputReference;
        putMatch(value: SpecHttp2RouteMatchQueryParameterMatchProperty): void;
        resetMatch(): void;
        get matchInput(): SpecHttp2RouteMatchQueryParameterMatchProperty | undefined;
    }
    class SpecHttp2RouteMatchQueryParameterPropertyList extends cdktn.ComplexList {
        internalValue?: SpecHttp2RouteMatchQueryParameterProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecHttp2RouteMatchQueryParameterPropertyOutputReference;
    }
    interface SpecHttp2RouteMatchProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#port AwsGatewayRoute#port}
        */
        readonly port?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#prefix AwsGatewayRoute#prefix}
        */
        readonly prefix?: string;
        /**
        * header block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#header AwsGatewayRoute#header}
        */
        readonly header?: SpecHttp2RouteMatchHeaderProperty[] | cdktn.IResolvable;
        /**
        * hostname block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#hostname AwsGatewayRoute#hostname}
        */
        readonly hostname?: SpecHttp2RouteMatchHostnameProperty;
        /**
        * path block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#path AwsGatewayRoute#path}
        */
        readonly path?: SpecHttp2RouteMatchPathProperty;
        /**
        * query_parameter block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#query_parameter AwsGatewayRoute#query_parameter}
        */
        readonly queryParameter?: SpecHttp2RouteMatchQueryParameterProperty[] | cdktn.IResolvable;
    }
    class SpecHttp2RouteMatchPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecHttp2RouteMatchProperty | undefined;
        set internalValue(value: SpecHttp2RouteMatchProperty | undefined);
        private _port?;
        get port(): number;
        set port(value: number);
        resetPort(): void;
        get portInput(): number | undefined;
        private _prefix?;
        get prefix(): string;
        set prefix(value: string);
        resetPrefix(): void;
        get prefixInput(): string | undefined;
        private _header;
        get header(): SpecHttp2RouteMatchHeaderPropertyList;
        putHeader(value: SpecHttp2RouteMatchHeaderProperty[] | cdktn.IResolvable): void;
        resetHeader(): void;
        get headerInput(): cdktn.IResolvable | SpecHttp2RouteMatchHeaderProperty[] | undefined;
        private _hostname;
        get hostname(): SpecHttp2RouteMatchHostnamePropertyOutputReference;
        putHostname(value: SpecHttp2RouteMatchHostnameProperty): void;
        resetHostname(): void;
        get hostnameInput(): SpecHttp2RouteMatchHostnameProperty | undefined;
        private _path;
        get path(): SpecHttp2RouteMatchPathPropertyOutputReference;
        putPath(value: SpecHttp2RouteMatchPathProperty): void;
        resetPath(): void;
        get pathInput(): SpecHttp2RouteMatchPathProperty | undefined;
        private _queryParameter;
        get queryParameter(): SpecHttp2RouteMatchQueryParameterPropertyList;
        putQueryParameter(value: SpecHttp2RouteMatchQueryParameterProperty[] | cdktn.IResolvable): void;
        resetQueryParameter(): void;
        get queryParameterInput(): cdktn.IResolvable | SpecHttp2RouteMatchQueryParameterProperty[] | undefined;
    }
    interface Http2RouteProperty {
        /**
        * action block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#action AwsGatewayRoute#action}
        */
        readonly action: SpecHttp2RouteActionProperty;
        /**
        * match block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#match AwsGatewayRoute#match}
        */
        readonly match: SpecHttp2RouteMatchProperty;
    }
    class Http2RoutePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): Http2RouteProperty | undefined;
        set internalValue(value: Http2RouteProperty | undefined);
        private _action;
        get action(): SpecHttp2RouteActionPropertyOutputReference;
        putAction(value: SpecHttp2RouteActionProperty): void;
        get actionInput(): SpecHttp2RouteActionProperty | undefined;
        private _match;
        get match(): SpecHttp2RouteMatchPropertyOutputReference;
        putMatch(value: SpecHttp2RouteMatchProperty): void;
        get matchInput(): SpecHttp2RouteMatchProperty | undefined;
    }
    interface SpecHttpRouteActionRewriteHostnameProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#default_target_hostname AwsGatewayRoute#default_target_hostname}
        */
        readonly defaultTargetHostname: string;
    }
    class SpecHttpRouteActionRewriteHostnamePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecHttpRouteActionRewriteHostnameProperty | undefined;
        set internalValue(value: SpecHttpRouteActionRewriteHostnameProperty | undefined);
        private _defaultTargetHostname?;
        get defaultTargetHostname(): string;
        set defaultTargetHostname(value: string);
        get defaultTargetHostnameInput(): string | undefined;
    }
    interface SpecHttpRouteActionRewritePathProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#exact AwsGatewayRoute#exact}
        */
        readonly exact: string;
    }
    class SpecHttpRouteActionRewritePathPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecHttpRouteActionRewritePathProperty | undefined;
        set internalValue(value: SpecHttpRouteActionRewritePathProperty | undefined);
        private _exact?;
        get exact(): string;
        set exact(value: string);
        get exactInput(): string | undefined;
    }
    interface SpecHttpRouteActionRewritePrefixProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#default_prefix AwsGatewayRoute#default_prefix}
        */
        readonly defaultPrefix?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#value AwsGatewayRoute#value}
        */
        readonly value?: string;
    }
    class SpecHttpRouteActionRewritePrefixPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecHttpRouteActionRewritePrefixProperty | undefined;
        set internalValue(value: SpecHttpRouteActionRewritePrefixProperty | undefined);
        private _defaultPrefix?;
        get defaultPrefix(): string;
        set defaultPrefix(value: string);
        resetDefaultPrefix(): void;
        get defaultPrefixInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        resetValue(): void;
        get valueInput(): string | undefined;
    }
    interface SpecHttpRouteActionRewriteProperty {
        /**
        * hostname block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#hostname AwsGatewayRoute#hostname}
        */
        readonly hostname?: SpecHttpRouteActionRewriteHostnameProperty;
        /**
        * path block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#path AwsGatewayRoute#path}
        */
        readonly path?: SpecHttpRouteActionRewritePathProperty;
        /**
        * prefix block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#prefix AwsGatewayRoute#prefix}
        */
        readonly prefix?: SpecHttpRouteActionRewritePrefixProperty;
    }
    class SpecHttpRouteActionRewritePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecHttpRouteActionRewriteProperty | undefined;
        set internalValue(value: SpecHttpRouteActionRewriteProperty | undefined);
        private _hostname;
        get hostname(): SpecHttpRouteActionRewriteHostnamePropertyOutputReference;
        putHostname(value: SpecHttpRouteActionRewriteHostnameProperty): void;
        resetHostname(): void;
        get hostnameInput(): SpecHttpRouteActionRewriteHostnameProperty | undefined;
        private _path;
        get path(): SpecHttpRouteActionRewritePathPropertyOutputReference;
        putPath(value: SpecHttpRouteActionRewritePathProperty): void;
        resetPath(): void;
        get pathInput(): SpecHttpRouteActionRewritePathProperty | undefined;
        private _prefix;
        get prefix(): SpecHttpRouteActionRewritePrefixPropertyOutputReference;
        putPrefix(value: SpecHttpRouteActionRewritePrefixProperty): void;
        resetPrefix(): void;
        get prefixInput(): SpecHttpRouteActionRewritePrefixProperty | undefined;
    }
    interface SpecHttpRouteActionTargetVirtualServiceProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#virtual_service_name AwsGatewayRoute#virtual_service_name}
        */
        readonly virtualServiceName: string;
    }
    class SpecHttpRouteActionTargetVirtualServicePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecHttpRouteActionTargetVirtualServiceProperty | undefined;
        set internalValue(value: SpecHttpRouteActionTargetVirtualServiceProperty | undefined);
        private _virtualServiceName?;
        get virtualServiceName(): string;
        set virtualServiceName(value: string);
        get virtualServiceNameInput(): string | undefined;
    }
    interface SpecHttpRouteActionTargetProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#port AwsGatewayRoute#port}
        */
        readonly port?: number;
        /**
        * virtual_service block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#virtual_service AwsGatewayRoute#virtual_service}
        */
        readonly virtualService: SpecHttpRouteActionTargetVirtualServiceProperty;
    }
    class SpecHttpRouteActionTargetPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecHttpRouteActionTargetProperty | undefined;
        set internalValue(value: SpecHttpRouteActionTargetProperty | undefined);
        private _port?;
        get port(): number;
        set port(value: number);
        resetPort(): void;
        get portInput(): number | undefined;
        private _virtualService;
        get virtualService(): SpecHttpRouteActionTargetVirtualServicePropertyOutputReference;
        putVirtualService(value: SpecHttpRouteActionTargetVirtualServiceProperty): void;
        get virtualServiceInput(): SpecHttpRouteActionTargetVirtualServiceProperty | undefined;
    }
    interface SpecHttpRouteActionProperty {
        /**
        * rewrite block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#rewrite AwsGatewayRoute#rewrite}
        */
        readonly rewrite?: SpecHttpRouteActionRewriteProperty;
        /**
        * target block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#target AwsGatewayRoute#target}
        */
        readonly target: SpecHttpRouteActionTargetProperty;
    }
    class SpecHttpRouteActionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecHttpRouteActionProperty | undefined;
        set internalValue(value: SpecHttpRouteActionProperty | undefined);
        private _rewrite;
        get rewrite(): SpecHttpRouteActionRewritePropertyOutputReference;
        putRewrite(value: SpecHttpRouteActionRewriteProperty): void;
        resetRewrite(): void;
        get rewriteInput(): SpecHttpRouteActionRewriteProperty | undefined;
        private _target;
        get target(): SpecHttpRouteActionTargetPropertyOutputReference;
        putTarget(value: SpecHttpRouteActionTargetProperty): void;
        get targetInput(): SpecHttpRouteActionTargetProperty | undefined;
    }
    interface SpecHttpRouteMatchHeaderMatchRangeProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#end AwsGatewayRoute#end}
        */
        readonly end: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#start AwsGatewayRoute#start}
        */
        readonly start: number;
    }
    class SpecHttpRouteMatchHeaderMatchRangePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecHttpRouteMatchHeaderMatchRangeProperty | undefined;
        set internalValue(value: SpecHttpRouteMatchHeaderMatchRangeProperty | undefined);
        private _end?;
        get end(): number;
        set end(value: number);
        get endInput(): number | undefined;
        private _start?;
        get start(): number;
        set start(value: number);
        get startInput(): number | undefined;
    }
    interface SpecHttpRouteMatchHeaderMatchProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#exact AwsGatewayRoute#exact}
        */
        readonly exact?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#prefix AwsGatewayRoute#prefix}
        */
        readonly prefix?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#regex AwsGatewayRoute#regex}
        */
        readonly regex?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#suffix AwsGatewayRoute#suffix}
        */
        readonly suffix?: string;
        /**
        * range block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#range AwsGatewayRoute#range}
        */
        readonly range?: SpecHttpRouteMatchHeaderMatchRangeProperty;
    }
    class SpecHttpRouteMatchHeaderMatchPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecHttpRouteMatchHeaderMatchProperty | undefined;
        set internalValue(value: SpecHttpRouteMatchHeaderMatchProperty | undefined);
        private _exact?;
        get exact(): string;
        set exact(value: string);
        resetExact(): void;
        get exactInput(): string | undefined;
        private _prefix?;
        get prefix(): string;
        set prefix(value: string);
        resetPrefix(): void;
        get prefixInput(): string | undefined;
        private _regex?;
        get regex(): string;
        set regex(value: string);
        resetRegex(): void;
        get regexInput(): string | undefined;
        private _suffix?;
        get suffix(): string;
        set suffix(value: string);
        resetSuffix(): void;
        get suffixInput(): string | undefined;
        private _range;
        get range(): SpecHttpRouteMatchHeaderMatchRangePropertyOutputReference;
        putRange(value: SpecHttpRouteMatchHeaderMatchRangeProperty): void;
        resetRange(): void;
        get rangeInput(): SpecHttpRouteMatchHeaderMatchRangeProperty | undefined;
    }
    interface SpecHttpRouteMatchHeaderProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#invert AwsGatewayRoute#invert}
        */
        readonly invert?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#name AwsGatewayRoute#name}
        */
        readonly name: string;
        /**
        * match block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#match AwsGatewayRoute#match}
        */
        readonly match?: SpecHttpRouteMatchHeaderMatchProperty;
    }
    class SpecHttpRouteMatchHeaderPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecHttpRouteMatchHeaderProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SpecHttpRouteMatchHeaderProperty | cdktn.IResolvable | undefined);
        private _invert?;
        get invert(): boolean | cdktn.IResolvable;
        set invert(value: boolean | cdktn.IResolvable);
        resetInvert(): void;
        get invertInput(): boolean | cdktn.IResolvable | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _match;
        get match(): SpecHttpRouteMatchHeaderMatchPropertyOutputReference;
        putMatch(value: SpecHttpRouteMatchHeaderMatchProperty): void;
        resetMatch(): void;
        get matchInput(): SpecHttpRouteMatchHeaderMatchProperty | undefined;
    }
    class SpecHttpRouteMatchHeaderPropertyList extends cdktn.ComplexList {
        internalValue?: SpecHttpRouteMatchHeaderProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecHttpRouteMatchHeaderPropertyOutputReference;
    }
    interface SpecHttpRouteMatchHostnameProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#exact AwsGatewayRoute#exact}
        */
        readonly exact?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#suffix AwsGatewayRoute#suffix}
        */
        readonly suffix?: string;
    }
    class SpecHttpRouteMatchHostnamePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecHttpRouteMatchHostnameProperty | undefined;
        set internalValue(value: SpecHttpRouteMatchHostnameProperty | undefined);
        private _exact?;
        get exact(): string;
        set exact(value: string);
        resetExact(): void;
        get exactInput(): string | undefined;
        private _suffix?;
        get suffix(): string;
        set suffix(value: string);
        resetSuffix(): void;
        get suffixInput(): string | undefined;
    }
    interface SpecHttpRouteMatchPathProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#exact AwsGatewayRoute#exact}
        */
        readonly exact?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#regex AwsGatewayRoute#regex}
        */
        readonly regex?: string;
    }
    class SpecHttpRouteMatchPathPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecHttpRouteMatchPathProperty | undefined;
        set internalValue(value: SpecHttpRouteMatchPathProperty | undefined);
        private _exact?;
        get exact(): string;
        set exact(value: string);
        resetExact(): void;
        get exactInput(): string | undefined;
        private _regex?;
        get regex(): string;
        set regex(value: string);
        resetRegex(): void;
        get regexInput(): string | undefined;
    }
    interface SpecHttpRouteMatchQueryParameterMatchProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#exact AwsGatewayRoute#exact}
        */
        readonly exact?: string;
    }
    class SpecHttpRouteMatchQueryParameterMatchPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecHttpRouteMatchQueryParameterMatchProperty | undefined;
        set internalValue(value: SpecHttpRouteMatchQueryParameterMatchProperty | undefined);
        private _exact?;
        get exact(): string;
        set exact(value: string);
        resetExact(): void;
        get exactInput(): string | undefined;
    }
    interface SpecHttpRouteMatchQueryParameterProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#name AwsGatewayRoute#name}
        */
        readonly name: string;
        /**
        * match block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#match AwsGatewayRoute#match}
        */
        readonly match?: SpecHttpRouteMatchQueryParameterMatchProperty;
    }
    class SpecHttpRouteMatchQueryParameterPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecHttpRouteMatchQueryParameterProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SpecHttpRouteMatchQueryParameterProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _match;
        get match(): SpecHttpRouteMatchQueryParameterMatchPropertyOutputReference;
        putMatch(value: SpecHttpRouteMatchQueryParameterMatchProperty): void;
        resetMatch(): void;
        get matchInput(): SpecHttpRouteMatchQueryParameterMatchProperty | undefined;
    }
    class SpecHttpRouteMatchQueryParameterPropertyList extends cdktn.ComplexList {
        internalValue?: SpecHttpRouteMatchQueryParameterProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecHttpRouteMatchQueryParameterPropertyOutputReference;
    }
    interface SpecHttpRouteMatchProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#port AwsGatewayRoute#port}
        */
        readonly port?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#prefix AwsGatewayRoute#prefix}
        */
        readonly prefix?: string;
        /**
        * header block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#header AwsGatewayRoute#header}
        */
        readonly header?: SpecHttpRouteMatchHeaderProperty[] | cdktn.IResolvable;
        /**
        * hostname block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#hostname AwsGatewayRoute#hostname}
        */
        readonly hostname?: SpecHttpRouteMatchHostnameProperty;
        /**
        * path block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#path AwsGatewayRoute#path}
        */
        readonly path?: SpecHttpRouteMatchPathProperty;
        /**
        * query_parameter block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#query_parameter AwsGatewayRoute#query_parameter}
        */
        readonly queryParameter?: SpecHttpRouteMatchQueryParameterProperty[] | cdktn.IResolvable;
    }
    class SpecHttpRouteMatchPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecHttpRouteMatchProperty | undefined;
        set internalValue(value: SpecHttpRouteMatchProperty | undefined);
        private _port?;
        get port(): number;
        set port(value: number);
        resetPort(): void;
        get portInput(): number | undefined;
        private _prefix?;
        get prefix(): string;
        set prefix(value: string);
        resetPrefix(): void;
        get prefixInput(): string | undefined;
        private _header;
        get header(): SpecHttpRouteMatchHeaderPropertyList;
        putHeader(value: SpecHttpRouteMatchHeaderProperty[] | cdktn.IResolvable): void;
        resetHeader(): void;
        get headerInput(): cdktn.IResolvable | SpecHttpRouteMatchHeaderProperty[] | undefined;
        private _hostname;
        get hostname(): SpecHttpRouteMatchHostnamePropertyOutputReference;
        putHostname(value: SpecHttpRouteMatchHostnameProperty): void;
        resetHostname(): void;
        get hostnameInput(): SpecHttpRouteMatchHostnameProperty | undefined;
        private _path;
        get path(): SpecHttpRouteMatchPathPropertyOutputReference;
        putPath(value: SpecHttpRouteMatchPathProperty): void;
        resetPath(): void;
        get pathInput(): SpecHttpRouteMatchPathProperty | undefined;
        private _queryParameter;
        get queryParameter(): SpecHttpRouteMatchQueryParameterPropertyList;
        putQueryParameter(value: SpecHttpRouteMatchQueryParameterProperty[] | cdktn.IResolvable): void;
        resetQueryParameter(): void;
        get queryParameterInput(): cdktn.IResolvable | SpecHttpRouteMatchQueryParameterProperty[] | undefined;
    }
    interface HttpRouteProperty {
        /**
        * action block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#action AwsGatewayRoute#action}
        */
        readonly action: SpecHttpRouteActionProperty;
        /**
        * match block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#match AwsGatewayRoute#match}
        */
        readonly match: SpecHttpRouteMatchProperty;
    }
    class HttpRoutePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): HttpRouteProperty | undefined;
        set internalValue(value: HttpRouteProperty | undefined);
        private _action;
        get action(): SpecHttpRouteActionPropertyOutputReference;
        putAction(value: SpecHttpRouteActionProperty): void;
        get actionInput(): SpecHttpRouteActionProperty | undefined;
        private _match;
        get match(): SpecHttpRouteMatchPropertyOutputReference;
        putMatch(value: SpecHttpRouteMatchProperty): void;
        get matchInput(): SpecHttpRouteMatchProperty | undefined;
    }
    interface SpecProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#priority AwsGatewayRoute#priority}
        */
        readonly priority?: number;
        /**
        * grpc_route block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#grpc_route AwsGatewayRoute#grpc_route}
        */
        readonly grpcRoute?: GrpcRouteProperty;
        /**
        * http2_route block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#http2_route AwsGatewayRoute#http2_route}
        */
        readonly http2Route?: Http2RouteProperty;
        /**
        * http_route block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#http_route AwsGatewayRoute#http_route}
        */
        readonly httpRoute?: HttpRouteProperty;
    }
    class SpecPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecProperty | undefined;
        set internalValue(value: SpecProperty | undefined);
        private _priority?;
        get priority(): number;
        set priority(value: number);
        resetPriority(): void;
        get priorityInput(): number | undefined;
        private _grpcRoute;
        get grpcRoute(): GrpcRoutePropertyOutputReference;
        putGrpcRoute(value: GrpcRouteProperty): void;
        resetGrpcRoute(): void;
        get grpcRouteInput(): GrpcRouteProperty | undefined;
        private _http2Route;
        get http2Route(): Http2RoutePropertyOutputReference;
        putHttp2Route(value: Http2RouteProperty): void;
        resetHttp2Route(): void;
        get http2RouteInput(): Http2RouteProperty | undefined;
        private _httpRoute;
        get httpRoute(): HttpRoutePropertyOutputReference;
        putHttpRoute(value: HttpRouteProperty): void;
        resetHttpRoute(): void;
        get httpRouteInput(): HttpRouteProperty | undefined;
    }
}
