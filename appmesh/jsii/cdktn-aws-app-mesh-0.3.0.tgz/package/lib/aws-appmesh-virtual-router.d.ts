import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsVirtualRouterConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_router#id AwsVirtualRouter#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_router#mesh_name AwsVirtualRouter#mesh_name}
    */
    readonly meshName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_router#mesh_owner AwsVirtualRouter#mesh_owner}
    */
    readonly meshOwner?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_router#name AwsVirtualRouter#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_router#region AwsVirtualRouter#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_router#tags AwsVirtualRouter#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_router#tags_all AwsVirtualRouter#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * spec block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_router#spec AwsVirtualRouter#spec}
    */
    readonly spec: AwsVirtualRouter.SpecProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_router aws_appmesh_virtual_router}
*/
export declare class AwsVirtualRouter extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_appmesh_virtual_router";
    /**
    * Generates CDKTN code for importing a AwsVirtualRouter resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsVirtualRouter to import
    * @param importFromId The id of the existing AwsVirtualRouter that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_router#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsVirtualRouter to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_router aws_appmesh_virtual_router} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsVirtualRouterConfig
    */
    constructor(scope: Construct, id: string, config: AwsVirtualRouterConfig);
    get arn(): string;
    get createdDate(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get lastUpdatedDate(): string;
    private _meshName?;
    get meshName(): string;
    set meshName(value: string);
    get meshNameInput(): string | undefined;
    private _meshOwner?;
    get meshOwner(): string;
    set meshOwner(value: string);
    resetMeshOwner(): void;
    get meshOwnerInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get resourceOwner(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _spec;
    get spec(): AwsVirtualRouter.SpecPropertyOutputReference;
    putSpec(value: AwsVirtualRouter.SpecProperty): void;
    get specInput(): AwsVirtualRouter.SpecProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsVirtualRouterPortMappingPropertyToTerraform(struct?: AwsVirtualRouter.PortMappingPropertyOutputReference | AwsVirtualRouter.PortMappingProperty): any;
export declare function awsVirtualRouterPortMappingPropertyToHclTerraform(struct?: AwsVirtualRouter.PortMappingPropertyOutputReference | AwsVirtualRouter.PortMappingProperty): any;
export declare function awsVirtualRouterListenerPropertyToTerraform(struct?: AwsVirtualRouter.ListenerProperty | cdktn.IResolvable): any;
export declare function awsVirtualRouterListenerPropertyToHclTerraform(struct?: AwsVirtualRouter.ListenerProperty | cdktn.IResolvable): any;
export declare function awsVirtualRouterSpecPropertyToTerraform(struct?: AwsVirtualRouter.SpecPropertyOutputReference | AwsVirtualRouter.SpecProperty): any;
export declare function awsVirtualRouterSpecPropertyToHclTerraform(struct?: AwsVirtualRouter.SpecPropertyOutputReference | AwsVirtualRouter.SpecProperty): any;
export declare namespace AwsVirtualRouter {
    interface PortMappingProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_router#port AwsVirtualRouter#port}
        */
        readonly port: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_router#protocol AwsVirtualRouter#protocol}
        */
        readonly protocol: string;
    }
    class PortMappingPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): PortMappingProperty | undefined;
        set internalValue(value: PortMappingProperty | undefined);
        private _port?;
        get port(): number;
        set port(value: number);
        get portInput(): number | undefined;
        private _protocol?;
        get protocol(): string;
        set protocol(value: string);
        get protocolInput(): string | undefined;
    }
    interface ListenerProperty {
        /**
        * port_mapping block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_router#port_mapping AwsVirtualRouter#port_mapping}
        */
        readonly portMapping: PortMappingProperty;
    }
    class ListenerPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ListenerProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ListenerProperty | cdktn.IResolvable | undefined);
        private _portMapping;
        get portMapping(): PortMappingPropertyOutputReference;
        putPortMapping(value: PortMappingProperty): void;
        get portMappingInput(): PortMappingProperty | undefined;
    }
    class ListenerPropertyList extends cdktn.ComplexList {
        internalValue?: ListenerProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ListenerPropertyOutputReference;
    }
    interface SpecProperty {
        /**
        * listener block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_router#listener AwsVirtualRouter#listener}
        */
        readonly listener?: ListenerProperty[] | cdktn.IResolvable;
    }
    class SpecPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecProperty | undefined;
        set internalValue(value: SpecProperty | undefined);
        private _listener;
        get listener(): ListenerPropertyList;
        putListener(value: ListenerProperty[] | cdktn.IResolvable): void;
        resetListener(): void;
        get listenerInput(): cdktn.IResolvable | ListenerProperty[] | undefined;
    }
}
