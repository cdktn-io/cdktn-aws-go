import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsVirtualNodeConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/appmesh_virtual_node#id DataAwsVirtualNode#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/appmesh_virtual_node#mesh_name DataAwsVirtualNode#mesh_name}
    */
    readonly meshName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/appmesh_virtual_node#mesh_owner DataAwsVirtualNode#mesh_owner}
    */
    readonly meshOwner?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/appmesh_virtual_node#name DataAwsVirtualNode#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/appmesh_virtual_node#region DataAwsVirtualNode#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/appmesh_virtual_node#tags DataAwsVirtualNode#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/appmesh_virtual_node aws_appmesh_virtual_node}
*/
export declare class DataAwsVirtualNode extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_appmesh_virtual_node";
    /**
    * Generates CDKTN code for importing a DataAwsVirtualNode resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsVirtualNode to import
    * @param importFromId The id of the existing DataAwsVirtualNode that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/appmesh_virtual_node#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsVirtualNode to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/appmesh_virtual_node aws_appmesh_virtual_node} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsVirtualNodeConfig
    */
    constructor(scope: Construct, id: string, config: DataAwsVirtualNodeConfig);
    get arn(): string;
    get createdDate(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get lastUpdatedDate(): string;
    private _meshName?;
    get meshName(): string;
    set meshName(value: string);
    get meshNameInput(): string | undefined;
    private _meshOwner?;
    get meshOwner(): string;
    set meshOwner(value: string);
    resetMeshOwner(): void;
    get meshOwnerInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get resourceOwner(): string;
    private _spec;
    get spec(): DataAwsVirtualNode.SpecPropertyList;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataAwsVirtualNodeSpecBackendVirtualServiceClientPolicyTlsCertificateFilePropertyToTerraform(struct?: DataAwsVirtualNode.SpecBackendVirtualServiceClientPolicyTlsCertificateFileProperty): any;
export declare function dataAwsVirtualNodeSpecBackendVirtualServiceClientPolicyTlsCertificateFilePropertyToHclTerraform(struct?: DataAwsVirtualNode.SpecBackendVirtualServiceClientPolicyTlsCertificateFileProperty): any;
export declare function dataAwsVirtualNodeSpecBackendVirtualServiceClientPolicyTlsCertificateSdsPropertyToTerraform(struct?: DataAwsVirtualNode.SpecBackendVirtualServiceClientPolicyTlsCertificateSdsProperty): any;
export declare function dataAwsVirtualNodeSpecBackendVirtualServiceClientPolicyTlsCertificateSdsPropertyToHclTerraform(struct?: DataAwsVirtualNode.SpecBackendVirtualServiceClientPolicyTlsCertificateSdsProperty): any;
export declare function dataAwsVirtualNodeSpecBackendVirtualServiceClientPolicyTlsCertificatePropertyToTerraform(struct?: DataAwsVirtualNode.SpecBackendVirtualServiceClientPolicyTlsCertificateProperty): any;
export declare function dataAwsVirtualNodeSpecBackendVirtualServiceClientPolicyTlsCertificatePropertyToHclTerraform(struct?: DataAwsVirtualNode.SpecBackendVirtualServiceClientPolicyTlsCertificateProperty): any;
export declare function dataAwsVirtualNodeSpecBackendVirtualServiceClientPolicyTlsValidationSubjectAlternativeNamesMatchPropertyToTerraform(struct?: DataAwsVirtualNode.SpecBackendVirtualServiceClientPolicyTlsValidationSubjectAlternativeNamesMatchProperty): any;
export declare function dataAwsVirtualNodeSpecBackendVirtualServiceClientPolicyTlsValidationSubjectAlternativeNamesMatchPropertyToHclTerraform(struct?: DataAwsVirtualNode.SpecBackendVirtualServiceClientPolicyTlsValidationSubjectAlternativeNamesMatchProperty): any;
export declare function dataAwsVirtualNodeSpecBackendVirtualServiceClientPolicyTlsValidationSubjectAlternativeNamesPropertyToTerraform(struct?: DataAwsVirtualNode.SpecBackendVirtualServiceClientPolicyTlsValidationSubjectAlternativeNamesProperty): any;
export declare function dataAwsVirtualNodeSpecBackendVirtualServiceClientPolicyTlsValidationSubjectAlternativeNamesPropertyToHclTerraform(struct?: DataAwsVirtualNode.SpecBackendVirtualServiceClientPolicyTlsValidationSubjectAlternativeNamesProperty): any;
export declare function dataAwsVirtualNodeSpecBackendVirtualServiceClientPolicyTlsValidationTrustAcmPropertyToTerraform(struct?: DataAwsVirtualNode.SpecBackendVirtualServiceClientPolicyTlsValidationTrustAcmProperty): any;
export declare function dataAwsVirtualNodeSpecBackendVirtualServiceClientPolicyTlsValidationTrustAcmPropertyToHclTerraform(struct?: DataAwsVirtualNode.SpecBackendVirtualServiceClientPolicyTlsValidationTrustAcmProperty): any;
export declare function dataAwsVirtualNodeSpecBackendVirtualServiceClientPolicyTlsValidationTrustFilePropertyToTerraform(struct?: DataAwsVirtualNode.SpecBackendVirtualServiceClientPolicyTlsValidationTrustFileProperty): any;
export declare function dataAwsVirtualNodeSpecBackendVirtualServiceClientPolicyTlsValidationTrustFilePropertyToHclTerraform(struct?: DataAwsVirtualNode.SpecBackendVirtualServiceClientPolicyTlsValidationTrustFileProperty): any;
export declare function dataAwsVirtualNodeSpecBackendVirtualServiceClientPolicyTlsValidationTrustSdsPropertyToTerraform(struct?: DataAwsVirtualNode.SpecBackendVirtualServiceClientPolicyTlsValidationTrustSdsProperty): any;
export declare function dataAwsVirtualNodeSpecBackendVirtualServiceClientPolicyTlsValidationTrustSdsPropertyToHclTerraform(struct?: DataAwsVirtualNode.SpecBackendVirtualServiceClientPolicyTlsValidationTrustSdsProperty): any;
export declare function dataAwsVirtualNodeSpecBackendVirtualServiceClientPolicyTlsValidationTrustPropertyToTerraform(struct?: DataAwsVirtualNode.SpecBackendVirtualServiceClientPolicyTlsValidationTrustProperty): any;
export declare function dataAwsVirtualNodeSpecBackendVirtualServiceClientPolicyTlsValidationTrustPropertyToHclTerraform(struct?: DataAwsVirtualNode.SpecBackendVirtualServiceClientPolicyTlsValidationTrustProperty): any;
export declare function dataAwsVirtualNodeSpecBackendVirtualServiceClientPolicyTlsValidationPropertyToTerraform(struct?: DataAwsVirtualNode.SpecBackendVirtualServiceClientPolicyTlsValidationProperty): any;
export declare function dataAwsVirtualNodeSpecBackendVirtualServiceClientPolicyTlsValidationPropertyToHclTerraform(struct?: DataAwsVirtualNode.SpecBackendVirtualServiceClientPolicyTlsValidationProperty): any;
export declare function dataAwsVirtualNodeSpecBackendVirtualServiceClientPolicyTlsPropertyToTerraform(struct?: DataAwsVirtualNode.SpecBackendVirtualServiceClientPolicyTlsProperty): any;
export declare function dataAwsVirtualNodeSpecBackendVirtualServiceClientPolicyTlsPropertyToHclTerraform(struct?: DataAwsVirtualNode.SpecBackendVirtualServiceClientPolicyTlsProperty): any;
export declare function dataAwsVirtualNodeSpecBackendVirtualServiceClientPolicyPropertyToTerraform(struct?: DataAwsVirtualNode.SpecBackendVirtualServiceClientPolicyProperty): any;
export declare function dataAwsVirtualNodeSpecBackendVirtualServiceClientPolicyPropertyToHclTerraform(struct?: DataAwsVirtualNode.SpecBackendVirtualServiceClientPolicyProperty): any;
export declare function dataAwsVirtualNodeVirtualServicePropertyToTerraform(struct?: DataAwsVirtualNode.VirtualServiceProperty): any;
export declare function dataAwsVirtualNodeVirtualServicePropertyToHclTerraform(struct?: DataAwsVirtualNode.VirtualServiceProperty): any;
export declare function dataAwsVirtualNodeBackendPropertyToTerraform(struct?: DataAwsVirtualNode.BackendProperty): any;
export declare function dataAwsVirtualNodeBackendPropertyToHclTerraform(struct?: DataAwsVirtualNode.BackendProperty): any;
export declare function dataAwsVirtualNodeSpecBackendDefaultsClientPolicyTlsCertificateFilePropertyToTerraform(struct?: DataAwsVirtualNode.SpecBackendDefaultsClientPolicyTlsCertificateFileProperty): any;
export declare function dataAwsVirtualNodeSpecBackendDefaultsClientPolicyTlsCertificateFilePropertyToHclTerraform(struct?: DataAwsVirtualNode.SpecBackendDefaultsClientPolicyTlsCertificateFileProperty): any;
export declare function dataAwsVirtualNodeSpecBackendDefaultsClientPolicyTlsCertificateSdsPropertyToTerraform(struct?: DataAwsVirtualNode.SpecBackendDefaultsClientPolicyTlsCertificateSdsProperty): any;
export declare function dataAwsVirtualNodeSpecBackendDefaultsClientPolicyTlsCertificateSdsPropertyToHclTerraform(struct?: DataAwsVirtualNode.SpecBackendDefaultsClientPolicyTlsCertificateSdsProperty): any;
export declare function dataAwsVirtualNodeSpecBackendDefaultsClientPolicyTlsCertificatePropertyToTerraform(struct?: DataAwsVirtualNode.SpecBackendDefaultsClientPolicyTlsCertificateProperty): any;
export declare function dataAwsVirtualNodeSpecBackendDefaultsClientPolicyTlsCertificatePropertyToHclTerraform(struct?: DataAwsVirtualNode.SpecBackendDefaultsClientPolicyTlsCertificateProperty): any;
export declare function dataAwsVirtualNodeSpecBackendDefaultsClientPolicyTlsValidationSubjectAlternativeNamesMatchPropertyToTerraform(struct?: DataAwsVirtualNode.SpecBackendDefaultsClientPolicyTlsValidationSubjectAlternativeNamesMatchProperty): any;
export declare function dataAwsVirtualNodeSpecBackendDefaultsClientPolicyTlsValidationSubjectAlternativeNamesMatchPropertyToHclTerraform(struct?: DataAwsVirtualNode.SpecBackendDefaultsClientPolicyTlsValidationSubjectAlternativeNamesMatchProperty): any;
export declare function dataAwsVirtualNodeSpecBackendDefaultsClientPolicyTlsValidationSubjectAlternativeNamesPropertyToTerraform(struct?: DataAwsVirtualNode.SpecBackendDefaultsClientPolicyTlsValidationSubjectAlternativeNamesProperty): any;
export declare function dataAwsVirtualNodeSpecBackendDefaultsClientPolicyTlsValidationSubjectAlternativeNamesPropertyToHclTerraform(struct?: DataAwsVirtualNode.SpecBackendDefaultsClientPolicyTlsValidationSubjectAlternativeNamesProperty): any;
export declare function dataAwsVirtualNodeSpecBackendDefaultsClientPolicyTlsValidationTrustAcmPropertyToTerraform(struct?: DataAwsVirtualNode.SpecBackendDefaultsClientPolicyTlsValidationTrustAcmProperty): any;
export declare function dataAwsVirtualNodeSpecBackendDefaultsClientPolicyTlsValidationTrustAcmPropertyToHclTerraform(struct?: DataAwsVirtualNode.SpecBackendDefaultsClientPolicyTlsValidationTrustAcmProperty): any;
export declare function dataAwsVirtualNodeSpecBackendDefaultsClientPolicyTlsValidationTrustFilePropertyToTerraform(struct?: DataAwsVirtualNode.SpecBackendDefaultsClientPolicyTlsValidationTrustFileProperty): any;
export declare function dataAwsVirtualNodeSpecBackendDefaultsClientPolicyTlsValidationTrustFilePropertyToHclTerraform(struct?: DataAwsVirtualNode.SpecBackendDefaultsClientPolicyTlsValidationTrustFileProperty): any;
export declare function dataAwsVirtualNodeSpecBackendDefaultsClientPolicyTlsValidationTrustSdsPropertyToTerraform(struct?: DataAwsVirtualNode.SpecBackendDefaultsClientPolicyTlsValidationTrustSdsProperty): any;
export declare function dataAwsVirtualNodeSpecBackendDefaultsClientPolicyTlsValidationTrustSdsPropertyToHclTerraform(struct?: DataAwsVirtualNode.SpecBackendDefaultsClientPolicyTlsValidationTrustSdsProperty): any;
export declare function dataAwsVirtualNodeSpecBackendDefaultsClientPolicyTlsValidationTrustPropertyToTerraform(struct?: DataAwsVirtualNode.SpecBackendDefaultsClientPolicyTlsValidationTrustProperty): any;
export declare function dataAwsVirtualNodeSpecBackendDefaultsClientPolicyTlsValidationTrustPropertyToHclTerraform(struct?: DataAwsVirtualNode.SpecBackendDefaultsClientPolicyTlsValidationTrustProperty): any;
export declare function dataAwsVirtualNodeSpecBackendDefaultsClientPolicyTlsValidationPropertyToTerraform(struct?: DataAwsVirtualNode.SpecBackendDefaultsClientPolicyTlsValidationProperty): any;
export declare function dataAwsVirtualNodeSpecBackendDefaultsClientPolicyTlsValidationPropertyToHclTerraform(struct?: DataAwsVirtualNode.SpecBackendDefaultsClientPolicyTlsValidationProperty): any;
export declare function dataAwsVirtualNodeSpecBackendDefaultsClientPolicyTlsPropertyToTerraform(struct?: DataAwsVirtualNode.SpecBackendDefaultsClientPolicyTlsProperty): any;
export declare function dataAwsVirtualNodeSpecBackendDefaultsClientPolicyTlsPropertyToHclTerraform(struct?: DataAwsVirtualNode.SpecBackendDefaultsClientPolicyTlsProperty): any;
export declare function dataAwsVirtualNodeSpecBackendDefaultsClientPolicyPropertyToTerraform(struct?: DataAwsVirtualNode.SpecBackendDefaultsClientPolicyProperty): any;
export declare function dataAwsVirtualNodeSpecBackendDefaultsClientPolicyPropertyToHclTerraform(struct?: DataAwsVirtualNode.SpecBackendDefaultsClientPolicyProperty): any;
export declare function dataAwsVirtualNodeBackendDefaultsPropertyToTerraform(struct?: DataAwsVirtualNode.BackendDefaultsProperty): any;
export declare function dataAwsVirtualNodeBackendDefaultsPropertyToHclTerraform(struct?: DataAwsVirtualNode.BackendDefaultsProperty): any;
export declare function dataAwsVirtualNodeSpecListenerConnectionPoolGrpcPropertyToTerraform(struct?: DataAwsVirtualNode.SpecListenerConnectionPoolGrpcProperty): any;
export declare function dataAwsVirtualNodeSpecListenerConnectionPoolGrpcPropertyToHclTerraform(struct?: DataAwsVirtualNode.SpecListenerConnectionPoolGrpcProperty): any;
export declare function dataAwsVirtualNodeSpecListenerConnectionPoolHttpPropertyToTerraform(struct?: DataAwsVirtualNode.SpecListenerConnectionPoolHttpProperty): any;
export declare function dataAwsVirtualNodeSpecListenerConnectionPoolHttpPropertyToHclTerraform(struct?: DataAwsVirtualNode.SpecListenerConnectionPoolHttpProperty): any;
export declare function dataAwsVirtualNodeSpecListenerConnectionPoolHttp2PropertyToTerraform(struct?: DataAwsVirtualNode.SpecListenerConnectionPoolHttp2Property): any;
export declare function dataAwsVirtualNodeSpecListenerConnectionPoolHttp2PropertyToHclTerraform(struct?: DataAwsVirtualNode.SpecListenerConnectionPoolHttp2Property): any;
export declare function dataAwsVirtualNodeSpecListenerConnectionPoolTcpPropertyToTerraform(struct?: DataAwsVirtualNode.SpecListenerConnectionPoolTcpProperty): any;
export declare function dataAwsVirtualNodeSpecListenerConnectionPoolTcpPropertyToHclTerraform(struct?: DataAwsVirtualNode.SpecListenerConnectionPoolTcpProperty): any;
export declare function dataAwsVirtualNodeConnectionPoolPropertyToTerraform(struct?: DataAwsVirtualNode.ConnectionPoolProperty): any;
export declare function dataAwsVirtualNodeConnectionPoolPropertyToHclTerraform(struct?: DataAwsVirtualNode.ConnectionPoolProperty): any;
export declare function dataAwsVirtualNodeHealthCheckPropertyToTerraform(struct?: DataAwsVirtualNode.HealthCheckProperty): any;
export declare function dataAwsVirtualNodeHealthCheckPropertyToHclTerraform(struct?: DataAwsVirtualNode.HealthCheckProperty): any;
export declare function dataAwsVirtualNodeBaseEjectionDurationPropertyToTerraform(struct?: DataAwsVirtualNode.BaseEjectionDurationProperty): any;
export declare function dataAwsVirtualNodeBaseEjectionDurationPropertyToHclTerraform(struct?: DataAwsVirtualNode.BaseEjectionDurationProperty): any;
export declare function dataAwsVirtualNodeIntervalPropertyToTerraform(struct?: DataAwsVirtualNode.IntervalProperty): any;
export declare function dataAwsVirtualNodeIntervalPropertyToHclTerraform(struct?: DataAwsVirtualNode.IntervalProperty): any;
export declare function dataAwsVirtualNodeOutlierDetectionPropertyToTerraform(struct?: DataAwsVirtualNode.OutlierDetectionProperty): any;
export declare function dataAwsVirtualNodeOutlierDetectionPropertyToHclTerraform(struct?: DataAwsVirtualNode.OutlierDetectionProperty): any;
export declare function dataAwsVirtualNodePortMappingPropertyToTerraform(struct?: DataAwsVirtualNode.PortMappingProperty): any;
export declare function dataAwsVirtualNodePortMappingPropertyToHclTerraform(struct?: DataAwsVirtualNode.PortMappingProperty): any;
export declare function dataAwsVirtualNodeSpecListenerTimeoutGrpcIdlePropertyToTerraform(struct?: DataAwsVirtualNode.SpecListenerTimeoutGrpcIdleProperty): any;
export declare function dataAwsVirtualNodeSpecListenerTimeoutGrpcIdlePropertyToHclTerraform(struct?: DataAwsVirtualNode.SpecListenerTimeoutGrpcIdleProperty): any;
export declare function dataAwsVirtualNodeSpecListenerTimeoutGrpcPerRequestPropertyToTerraform(struct?: DataAwsVirtualNode.SpecListenerTimeoutGrpcPerRequestProperty): any;
export declare function dataAwsVirtualNodeSpecListenerTimeoutGrpcPerRequestPropertyToHclTerraform(struct?: DataAwsVirtualNode.SpecListenerTimeoutGrpcPerRequestProperty): any;
export declare function dataAwsVirtualNodeSpecListenerTimeoutGrpcPropertyToTerraform(struct?: DataAwsVirtualNode.SpecListenerTimeoutGrpcProperty): any;
export declare function dataAwsVirtualNodeSpecListenerTimeoutGrpcPropertyToHclTerraform(struct?: DataAwsVirtualNode.SpecListenerTimeoutGrpcProperty): any;
export declare function dataAwsVirtualNodeSpecListenerTimeoutHttpIdlePropertyToTerraform(struct?: DataAwsVirtualNode.SpecListenerTimeoutHttpIdleProperty): any;
export declare function dataAwsVirtualNodeSpecListenerTimeoutHttpIdlePropertyToHclTerraform(struct?: DataAwsVirtualNode.SpecListenerTimeoutHttpIdleProperty): any;
export declare function dataAwsVirtualNodeSpecListenerTimeoutHttpPerRequestPropertyToTerraform(struct?: DataAwsVirtualNode.SpecListenerTimeoutHttpPerRequestProperty): any;
export declare function dataAwsVirtualNodeSpecListenerTimeoutHttpPerRequestPropertyToHclTerraform(struct?: DataAwsVirtualNode.SpecListenerTimeoutHttpPerRequestProperty): any;
export declare function dataAwsVirtualNodeSpecListenerTimeoutHttpPropertyToTerraform(struct?: DataAwsVirtualNode.SpecListenerTimeoutHttpProperty): any;
export declare function dataAwsVirtualNodeSpecListenerTimeoutHttpPropertyToHclTerraform(struct?: DataAwsVirtualNode.SpecListenerTimeoutHttpProperty): any;
export declare function dataAwsVirtualNodeSpecListenerTimeoutHttp2IdlePropertyToTerraform(struct?: DataAwsVirtualNode.SpecListenerTimeoutHttp2IdleProperty): any;
export declare function dataAwsVirtualNodeSpecListenerTimeoutHttp2IdlePropertyToHclTerraform(struct?: DataAwsVirtualNode.SpecListenerTimeoutHttp2IdleProperty): any;
export declare function dataAwsVirtualNodeSpecListenerTimeoutHttp2PerRequestPropertyToTerraform(struct?: DataAwsVirtualNode.SpecListenerTimeoutHttp2PerRequestProperty): any;
export declare function dataAwsVirtualNodeSpecListenerTimeoutHttp2PerRequestPropertyToHclTerraform(struct?: DataAwsVirtualNode.SpecListenerTimeoutHttp2PerRequestProperty): any;
export declare function dataAwsVirtualNodeSpecListenerTimeoutHttp2PropertyToTerraform(struct?: DataAwsVirtualNode.SpecListenerTimeoutHttp2Property): any;
export declare function dataAwsVirtualNodeSpecListenerTimeoutHttp2PropertyToHclTerraform(struct?: DataAwsVirtualNode.SpecListenerTimeoutHttp2Property): any;
export declare function dataAwsVirtualNodeSpecListenerTimeoutTcpIdlePropertyToTerraform(struct?: DataAwsVirtualNode.SpecListenerTimeoutTcpIdleProperty): any;
export declare function dataAwsVirtualNodeSpecListenerTimeoutTcpIdlePropertyToHclTerraform(struct?: DataAwsVirtualNode.SpecListenerTimeoutTcpIdleProperty): any;
export declare function dataAwsVirtualNodeSpecListenerTimeoutTcpPropertyToTerraform(struct?: DataAwsVirtualNode.SpecListenerTimeoutTcpProperty): any;
export declare function dataAwsVirtualNodeSpecListenerTimeoutTcpPropertyToHclTerraform(struct?: DataAwsVirtualNode.SpecListenerTimeoutTcpProperty): any;
export declare function dataAwsVirtualNodeTimeoutPropertyToTerraform(struct?: DataAwsVirtualNode.TimeoutProperty): any;
export declare function dataAwsVirtualNodeTimeoutPropertyToHclTerraform(struct?: DataAwsVirtualNode.TimeoutProperty): any;
export declare function dataAwsVirtualNodeSpecListenerTlsCertificateAcmPropertyToTerraform(struct?: DataAwsVirtualNode.SpecListenerTlsCertificateAcmProperty): any;
export declare function dataAwsVirtualNodeSpecListenerTlsCertificateAcmPropertyToHclTerraform(struct?: DataAwsVirtualNode.SpecListenerTlsCertificateAcmProperty): any;
export declare function dataAwsVirtualNodeSpecListenerTlsCertificateFilePropertyToTerraform(struct?: DataAwsVirtualNode.SpecListenerTlsCertificateFileProperty): any;
export declare function dataAwsVirtualNodeSpecListenerTlsCertificateFilePropertyToHclTerraform(struct?: DataAwsVirtualNode.SpecListenerTlsCertificateFileProperty): any;
export declare function dataAwsVirtualNodeSpecListenerTlsCertificateSdsPropertyToTerraform(struct?: DataAwsVirtualNode.SpecListenerTlsCertificateSdsProperty): any;
export declare function dataAwsVirtualNodeSpecListenerTlsCertificateSdsPropertyToHclTerraform(struct?: DataAwsVirtualNode.SpecListenerTlsCertificateSdsProperty): any;
export declare function dataAwsVirtualNodeSpecListenerTlsCertificatePropertyToTerraform(struct?: DataAwsVirtualNode.SpecListenerTlsCertificateProperty): any;
export declare function dataAwsVirtualNodeSpecListenerTlsCertificatePropertyToHclTerraform(struct?: DataAwsVirtualNode.SpecListenerTlsCertificateProperty): any;
export declare function dataAwsVirtualNodeSpecListenerTlsValidationSubjectAlternativeNamesMatchPropertyToTerraform(struct?: DataAwsVirtualNode.SpecListenerTlsValidationSubjectAlternativeNamesMatchProperty): any;
export declare function dataAwsVirtualNodeSpecListenerTlsValidationSubjectAlternativeNamesMatchPropertyToHclTerraform(struct?: DataAwsVirtualNode.SpecListenerTlsValidationSubjectAlternativeNamesMatchProperty): any;
export declare function dataAwsVirtualNodeSpecListenerTlsValidationSubjectAlternativeNamesPropertyToTerraform(struct?: DataAwsVirtualNode.SpecListenerTlsValidationSubjectAlternativeNamesProperty): any;
export declare function dataAwsVirtualNodeSpecListenerTlsValidationSubjectAlternativeNamesPropertyToHclTerraform(struct?: DataAwsVirtualNode.SpecListenerTlsValidationSubjectAlternativeNamesProperty): any;
export declare function dataAwsVirtualNodeSpecListenerTlsValidationTrustFilePropertyToTerraform(struct?: DataAwsVirtualNode.SpecListenerTlsValidationTrustFileProperty): any;
export declare function dataAwsVirtualNodeSpecListenerTlsValidationTrustFilePropertyToHclTerraform(struct?: DataAwsVirtualNode.SpecListenerTlsValidationTrustFileProperty): any;
export declare function dataAwsVirtualNodeSpecListenerTlsValidationTrustSdsPropertyToTerraform(struct?: DataAwsVirtualNode.SpecListenerTlsValidationTrustSdsProperty): any;
export declare function dataAwsVirtualNodeSpecListenerTlsValidationTrustSdsPropertyToHclTerraform(struct?: DataAwsVirtualNode.SpecListenerTlsValidationTrustSdsProperty): any;
export declare function dataAwsVirtualNodeSpecListenerTlsValidationTrustPropertyToTerraform(struct?: DataAwsVirtualNode.SpecListenerTlsValidationTrustProperty): any;
export declare function dataAwsVirtualNodeSpecListenerTlsValidationTrustPropertyToHclTerraform(struct?: DataAwsVirtualNode.SpecListenerTlsValidationTrustProperty): any;
export declare function dataAwsVirtualNodeSpecListenerTlsValidationPropertyToTerraform(struct?: DataAwsVirtualNode.SpecListenerTlsValidationProperty): any;
export declare function dataAwsVirtualNodeSpecListenerTlsValidationPropertyToHclTerraform(struct?: DataAwsVirtualNode.SpecListenerTlsValidationProperty): any;
export declare function dataAwsVirtualNodeSpecListenerTlsPropertyToTerraform(struct?: DataAwsVirtualNode.SpecListenerTlsProperty): any;
export declare function dataAwsVirtualNodeSpecListenerTlsPropertyToHclTerraform(struct?: DataAwsVirtualNode.SpecListenerTlsProperty): any;
export declare function dataAwsVirtualNodeListenerPropertyToTerraform(struct?: DataAwsVirtualNode.ListenerProperty): any;
export declare function dataAwsVirtualNodeListenerPropertyToHclTerraform(struct?: DataAwsVirtualNode.ListenerProperty): any;
export declare function dataAwsVirtualNodeJsonPropertyToTerraform(struct?: DataAwsVirtualNode.JsonProperty): any;
export declare function dataAwsVirtualNodeJsonPropertyToHclTerraform(struct?: DataAwsVirtualNode.JsonProperty): any;
export declare function dataAwsVirtualNodeFormatPropertyToTerraform(struct?: DataAwsVirtualNode.FormatProperty): any;
export declare function dataAwsVirtualNodeFormatPropertyToHclTerraform(struct?: DataAwsVirtualNode.FormatProperty): any;
export declare function dataAwsVirtualNodeSpecLoggingAccessLogFilePropertyToTerraform(struct?: DataAwsVirtualNode.SpecLoggingAccessLogFileProperty): any;
export declare function dataAwsVirtualNodeSpecLoggingAccessLogFilePropertyToHclTerraform(struct?: DataAwsVirtualNode.SpecLoggingAccessLogFileProperty): any;
export declare function dataAwsVirtualNodeAccessLogPropertyToTerraform(struct?: DataAwsVirtualNode.AccessLogProperty): any;
export declare function dataAwsVirtualNodeAccessLogPropertyToHclTerraform(struct?: DataAwsVirtualNode.AccessLogProperty): any;
export declare function dataAwsVirtualNodeLoggingPropertyToTerraform(struct?: DataAwsVirtualNode.LoggingProperty): any;
export declare function dataAwsVirtualNodeLoggingPropertyToHclTerraform(struct?: DataAwsVirtualNode.LoggingProperty): any;
export declare function dataAwsVirtualNodeAwsCloudMapPropertyToTerraform(struct?: DataAwsVirtualNode.AwsCloudMapProperty): any;
export declare function dataAwsVirtualNodeAwsCloudMapPropertyToHclTerraform(struct?: DataAwsVirtualNode.AwsCloudMapProperty): any;
export declare function dataAwsVirtualNodeDnsPropertyToTerraform(struct?: DataAwsVirtualNode.DnsProperty): any;
export declare function dataAwsVirtualNodeDnsPropertyToHclTerraform(struct?: DataAwsVirtualNode.DnsProperty): any;
export declare function dataAwsVirtualNodeServiceDiscoveryPropertyToTerraform(struct?: DataAwsVirtualNode.ServiceDiscoveryProperty): any;
export declare function dataAwsVirtualNodeServiceDiscoveryPropertyToHclTerraform(struct?: DataAwsVirtualNode.ServiceDiscoveryProperty): any;
export declare function dataAwsVirtualNodeSpecPropertyToTerraform(struct?: DataAwsVirtualNode.SpecProperty): any;
export declare function dataAwsVirtualNodeSpecPropertyToHclTerraform(struct?: DataAwsVirtualNode.SpecProperty): any;
export declare namespace DataAwsVirtualNode {
    interface SpecBackendVirtualServiceClientPolicyTlsCertificateFileProperty {
    }
    class SpecBackendVirtualServiceClientPolicyTlsCertificateFilePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecBackendVirtualServiceClientPolicyTlsCertificateFileProperty | undefined;
        set internalValue(value: SpecBackendVirtualServiceClientPolicyTlsCertificateFileProperty | undefined);
        get certificateChain(): string;
        get privateKey(): string;
    }
    class SpecBackendVirtualServiceClientPolicyTlsCertificateFilePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecBackendVirtualServiceClientPolicyTlsCertificateFilePropertyOutputReference;
    }
    interface SpecBackendVirtualServiceClientPolicyTlsCertificateSdsProperty {
    }
    class SpecBackendVirtualServiceClientPolicyTlsCertificateSdsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecBackendVirtualServiceClientPolicyTlsCertificateSdsProperty | undefined;
        set internalValue(value: SpecBackendVirtualServiceClientPolicyTlsCertificateSdsProperty | undefined);
        get secretName(): string;
    }
    class SpecBackendVirtualServiceClientPolicyTlsCertificateSdsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecBackendVirtualServiceClientPolicyTlsCertificateSdsPropertyOutputReference;
    }
    interface SpecBackendVirtualServiceClientPolicyTlsCertificateProperty {
    }
    class SpecBackendVirtualServiceClientPolicyTlsCertificatePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecBackendVirtualServiceClientPolicyTlsCertificateProperty | undefined;
        set internalValue(value: SpecBackendVirtualServiceClientPolicyTlsCertificateProperty | undefined);
        private _file;
        get file(): SpecBackendVirtualServiceClientPolicyTlsCertificateFilePropertyList;
        private _sds;
        get sds(): SpecBackendVirtualServiceClientPolicyTlsCertificateSdsPropertyList;
    }
    class SpecBackendVirtualServiceClientPolicyTlsCertificatePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecBackendVirtualServiceClientPolicyTlsCertificatePropertyOutputReference;
    }
    interface SpecBackendVirtualServiceClientPolicyTlsValidationSubjectAlternativeNamesMatchProperty {
    }
    class SpecBackendVirtualServiceClientPolicyTlsValidationSubjectAlternativeNamesMatchPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecBackendVirtualServiceClientPolicyTlsValidationSubjectAlternativeNamesMatchProperty | undefined;
        set internalValue(value: SpecBackendVirtualServiceClientPolicyTlsValidationSubjectAlternativeNamesMatchProperty | undefined);
        get exact(): string[];
    }
    class SpecBackendVirtualServiceClientPolicyTlsValidationSubjectAlternativeNamesMatchPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecBackendVirtualServiceClientPolicyTlsValidationSubjectAlternativeNamesMatchPropertyOutputReference;
    }
    interface SpecBackendVirtualServiceClientPolicyTlsValidationSubjectAlternativeNamesProperty {
    }
    class SpecBackendVirtualServiceClientPolicyTlsValidationSubjectAlternativeNamesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecBackendVirtualServiceClientPolicyTlsValidationSubjectAlternativeNamesProperty | undefined;
        set internalValue(value: SpecBackendVirtualServiceClientPolicyTlsValidationSubjectAlternativeNamesProperty | undefined);
        private _match;
        get match(): SpecBackendVirtualServiceClientPolicyTlsValidationSubjectAlternativeNamesMatchPropertyList;
    }
    class SpecBackendVirtualServiceClientPolicyTlsValidationSubjectAlternativeNamesPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecBackendVirtualServiceClientPolicyTlsValidationSubjectAlternativeNamesPropertyOutputReference;
    }
    interface SpecBackendVirtualServiceClientPolicyTlsValidationTrustAcmProperty {
    }
    class SpecBackendVirtualServiceClientPolicyTlsValidationTrustAcmPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecBackendVirtualServiceClientPolicyTlsValidationTrustAcmProperty | undefined;
        set internalValue(value: SpecBackendVirtualServiceClientPolicyTlsValidationTrustAcmProperty | undefined);
        get certificateAuthorityArns(): string[];
    }
    class SpecBackendVirtualServiceClientPolicyTlsValidationTrustAcmPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecBackendVirtualServiceClientPolicyTlsValidationTrustAcmPropertyOutputReference;
    }
    interface SpecBackendVirtualServiceClientPolicyTlsValidationTrustFileProperty {
    }
    class SpecBackendVirtualServiceClientPolicyTlsValidationTrustFilePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecBackendVirtualServiceClientPolicyTlsValidationTrustFileProperty | undefined;
        set internalValue(value: SpecBackendVirtualServiceClientPolicyTlsValidationTrustFileProperty | undefined);
        get certificateChain(): string;
    }
    class SpecBackendVirtualServiceClientPolicyTlsValidationTrustFilePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecBackendVirtualServiceClientPolicyTlsValidationTrustFilePropertyOutputReference;
    }
    interface SpecBackendVirtualServiceClientPolicyTlsValidationTrustSdsProperty {
    }
    class SpecBackendVirtualServiceClientPolicyTlsValidationTrustSdsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecBackendVirtualServiceClientPolicyTlsValidationTrustSdsProperty | undefined;
        set internalValue(value: SpecBackendVirtualServiceClientPolicyTlsValidationTrustSdsProperty | undefined);
        get secretName(): string;
    }
    class SpecBackendVirtualServiceClientPolicyTlsValidationTrustSdsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecBackendVirtualServiceClientPolicyTlsValidationTrustSdsPropertyOutputReference;
    }
    interface SpecBackendVirtualServiceClientPolicyTlsValidationTrustProperty {
    }
    class SpecBackendVirtualServiceClientPolicyTlsValidationTrustPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecBackendVirtualServiceClientPolicyTlsValidationTrustProperty | undefined;
        set internalValue(value: SpecBackendVirtualServiceClientPolicyTlsValidationTrustProperty | undefined);
        private _acm;
        get acm(): SpecBackendVirtualServiceClientPolicyTlsValidationTrustAcmPropertyList;
        private _file;
        get file(): SpecBackendVirtualServiceClientPolicyTlsValidationTrustFilePropertyList;
        private _sds;
        get sds(): SpecBackendVirtualServiceClientPolicyTlsValidationTrustSdsPropertyList;
    }
    class SpecBackendVirtualServiceClientPolicyTlsValidationTrustPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecBackendVirtualServiceClientPolicyTlsValidationTrustPropertyOutputReference;
    }
    interface SpecBackendVirtualServiceClientPolicyTlsValidationProperty {
    }
    class SpecBackendVirtualServiceClientPolicyTlsValidationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecBackendVirtualServiceClientPolicyTlsValidationProperty | undefined;
        set internalValue(value: SpecBackendVirtualServiceClientPolicyTlsValidationProperty | undefined);
        private _subjectAlternativeNames;
        get subjectAlternativeNames(): SpecBackendVirtualServiceClientPolicyTlsValidationSubjectAlternativeNamesPropertyList;
        private _trust;
        get trust(): SpecBackendVirtualServiceClientPolicyTlsValidationTrustPropertyList;
    }
    class SpecBackendVirtualServiceClientPolicyTlsValidationPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecBackendVirtualServiceClientPolicyTlsValidationPropertyOutputReference;
    }
    interface SpecBackendVirtualServiceClientPolicyTlsProperty {
    }
    class SpecBackendVirtualServiceClientPolicyTlsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecBackendVirtualServiceClientPolicyTlsProperty | undefined;
        set internalValue(value: SpecBackendVirtualServiceClientPolicyTlsProperty | undefined);
        private _certificate;
        get certificate(): SpecBackendVirtualServiceClientPolicyTlsCertificatePropertyList;
        get enforce(): cdktn.IResolvable;
        get ports(): number[];
        private _validation;
        get validation(): SpecBackendVirtualServiceClientPolicyTlsValidationPropertyList;
    }
    class SpecBackendVirtualServiceClientPolicyTlsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecBackendVirtualServiceClientPolicyTlsPropertyOutputReference;
    }
    interface SpecBackendVirtualServiceClientPolicyProperty {
    }
    class SpecBackendVirtualServiceClientPolicyPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecBackendVirtualServiceClientPolicyProperty | undefined;
        set internalValue(value: SpecBackendVirtualServiceClientPolicyProperty | undefined);
        private _tls;
        get tls(): SpecBackendVirtualServiceClientPolicyTlsPropertyList;
    }
    class SpecBackendVirtualServiceClientPolicyPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecBackendVirtualServiceClientPolicyPropertyOutputReference;
    }
    interface VirtualServiceProperty {
    }
    class VirtualServicePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): VirtualServiceProperty | undefined;
        set internalValue(value: VirtualServiceProperty | undefined);
        private _clientPolicy;
        get clientPolicy(): SpecBackendVirtualServiceClientPolicyPropertyList;
        get virtualServiceName(): string;
    }
    class VirtualServicePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): VirtualServicePropertyOutputReference;
    }
    interface BackendProperty {
    }
    class BackendPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): BackendProperty | undefined;
        set internalValue(value: BackendProperty | undefined);
        private _virtualService;
        get virtualService(): VirtualServicePropertyList;
    }
    class BackendPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): BackendPropertyOutputReference;
    }
    interface SpecBackendDefaultsClientPolicyTlsCertificateFileProperty {
    }
    class SpecBackendDefaultsClientPolicyTlsCertificateFilePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecBackendDefaultsClientPolicyTlsCertificateFileProperty | undefined;
        set internalValue(value: SpecBackendDefaultsClientPolicyTlsCertificateFileProperty | undefined);
        get certificateChain(): string;
        get privateKey(): string;
    }
    class SpecBackendDefaultsClientPolicyTlsCertificateFilePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecBackendDefaultsClientPolicyTlsCertificateFilePropertyOutputReference;
    }
    interface SpecBackendDefaultsClientPolicyTlsCertificateSdsProperty {
    }
    class SpecBackendDefaultsClientPolicyTlsCertificateSdsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecBackendDefaultsClientPolicyTlsCertificateSdsProperty | undefined;
        set internalValue(value: SpecBackendDefaultsClientPolicyTlsCertificateSdsProperty | undefined);
        get secretName(): string;
    }
    class SpecBackendDefaultsClientPolicyTlsCertificateSdsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecBackendDefaultsClientPolicyTlsCertificateSdsPropertyOutputReference;
    }
    interface SpecBackendDefaultsClientPolicyTlsCertificateProperty {
    }
    class SpecBackendDefaultsClientPolicyTlsCertificatePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecBackendDefaultsClientPolicyTlsCertificateProperty | undefined;
        set internalValue(value: SpecBackendDefaultsClientPolicyTlsCertificateProperty | undefined);
        private _file;
        get file(): SpecBackendDefaultsClientPolicyTlsCertificateFilePropertyList;
        private _sds;
        get sds(): SpecBackendDefaultsClientPolicyTlsCertificateSdsPropertyList;
    }
    class SpecBackendDefaultsClientPolicyTlsCertificatePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecBackendDefaultsClientPolicyTlsCertificatePropertyOutputReference;
    }
    interface SpecBackendDefaultsClientPolicyTlsValidationSubjectAlternativeNamesMatchProperty {
    }
    class SpecBackendDefaultsClientPolicyTlsValidationSubjectAlternativeNamesMatchPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecBackendDefaultsClientPolicyTlsValidationSubjectAlternativeNamesMatchProperty | undefined;
        set internalValue(value: SpecBackendDefaultsClientPolicyTlsValidationSubjectAlternativeNamesMatchProperty | undefined);
        get exact(): string[];
    }
    class SpecBackendDefaultsClientPolicyTlsValidationSubjectAlternativeNamesMatchPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecBackendDefaultsClientPolicyTlsValidationSubjectAlternativeNamesMatchPropertyOutputReference;
    }
    interface SpecBackendDefaultsClientPolicyTlsValidationSubjectAlternativeNamesProperty {
    }
    class SpecBackendDefaultsClientPolicyTlsValidationSubjectAlternativeNamesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecBackendDefaultsClientPolicyTlsValidationSubjectAlternativeNamesProperty | undefined;
        set internalValue(value: SpecBackendDefaultsClientPolicyTlsValidationSubjectAlternativeNamesProperty | undefined);
        private _match;
        get match(): SpecBackendDefaultsClientPolicyTlsValidationSubjectAlternativeNamesMatchPropertyList;
    }
    class SpecBackendDefaultsClientPolicyTlsValidationSubjectAlternativeNamesPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecBackendDefaultsClientPolicyTlsValidationSubjectAlternativeNamesPropertyOutputReference;
    }
    interface SpecBackendDefaultsClientPolicyTlsValidationTrustAcmProperty {
    }
    class SpecBackendDefaultsClientPolicyTlsValidationTrustAcmPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecBackendDefaultsClientPolicyTlsValidationTrustAcmProperty | undefined;
        set internalValue(value: SpecBackendDefaultsClientPolicyTlsValidationTrustAcmProperty | undefined);
        get certificateAuthorityArns(): string[];
    }
    class SpecBackendDefaultsClientPolicyTlsValidationTrustAcmPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecBackendDefaultsClientPolicyTlsValidationTrustAcmPropertyOutputReference;
    }
    interface SpecBackendDefaultsClientPolicyTlsValidationTrustFileProperty {
    }
    class SpecBackendDefaultsClientPolicyTlsValidationTrustFilePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecBackendDefaultsClientPolicyTlsValidationTrustFileProperty | undefined;
        set internalValue(value: SpecBackendDefaultsClientPolicyTlsValidationTrustFileProperty | undefined);
        get certificateChain(): string;
    }
    class SpecBackendDefaultsClientPolicyTlsValidationTrustFilePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecBackendDefaultsClientPolicyTlsValidationTrustFilePropertyOutputReference;
    }
    interface SpecBackendDefaultsClientPolicyTlsValidationTrustSdsProperty {
    }
    class SpecBackendDefaultsClientPolicyTlsValidationTrustSdsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecBackendDefaultsClientPolicyTlsValidationTrustSdsProperty | undefined;
        set internalValue(value: SpecBackendDefaultsClientPolicyTlsValidationTrustSdsProperty | undefined);
        get secretName(): string;
    }
    class SpecBackendDefaultsClientPolicyTlsValidationTrustSdsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecBackendDefaultsClientPolicyTlsValidationTrustSdsPropertyOutputReference;
    }
    interface SpecBackendDefaultsClientPolicyTlsValidationTrustProperty {
    }
    class SpecBackendDefaultsClientPolicyTlsValidationTrustPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecBackendDefaultsClientPolicyTlsValidationTrustProperty | undefined;
        set internalValue(value: SpecBackendDefaultsClientPolicyTlsValidationTrustProperty | undefined);
        private _acm;
        get acm(): SpecBackendDefaultsClientPolicyTlsValidationTrustAcmPropertyList;
        private _file;
        get file(): SpecBackendDefaultsClientPolicyTlsValidationTrustFilePropertyList;
        private _sds;
        get sds(): SpecBackendDefaultsClientPolicyTlsValidationTrustSdsPropertyList;
    }
    class SpecBackendDefaultsClientPolicyTlsValidationTrustPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecBackendDefaultsClientPolicyTlsValidationTrustPropertyOutputReference;
    }
    interface SpecBackendDefaultsClientPolicyTlsValidationProperty {
    }
    class SpecBackendDefaultsClientPolicyTlsValidationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecBackendDefaultsClientPolicyTlsValidationProperty | undefined;
        set internalValue(value: SpecBackendDefaultsClientPolicyTlsValidationProperty | undefined);
        private _subjectAlternativeNames;
        get subjectAlternativeNames(): SpecBackendDefaultsClientPolicyTlsValidationSubjectAlternativeNamesPropertyList;
        private _trust;
        get trust(): SpecBackendDefaultsClientPolicyTlsValidationTrustPropertyList;
    }
    class SpecBackendDefaultsClientPolicyTlsValidationPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecBackendDefaultsClientPolicyTlsValidationPropertyOutputReference;
    }
    interface SpecBackendDefaultsClientPolicyTlsProperty {
    }
    class SpecBackendDefaultsClientPolicyTlsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecBackendDefaultsClientPolicyTlsProperty | undefined;
        set internalValue(value: SpecBackendDefaultsClientPolicyTlsProperty | undefined);
        private _certificate;
        get certificate(): SpecBackendDefaultsClientPolicyTlsCertificatePropertyList;
        get enforce(): cdktn.IResolvable;
        get ports(): number[];
        private _validation;
        get validation(): SpecBackendDefaultsClientPolicyTlsValidationPropertyList;
    }
    class SpecBackendDefaultsClientPolicyTlsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecBackendDefaultsClientPolicyTlsPropertyOutputReference;
    }
    interface SpecBackendDefaultsClientPolicyProperty {
    }
    class SpecBackendDefaultsClientPolicyPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecBackendDefaultsClientPolicyProperty | undefined;
        set internalValue(value: SpecBackendDefaultsClientPolicyProperty | undefined);
        private _tls;
        get tls(): SpecBackendDefaultsClientPolicyTlsPropertyList;
    }
    class SpecBackendDefaultsClientPolicyPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecBackendDefaultsClientPolicyPropertyOutputReference;
    }
    interface BackendDefaultsProperty {
    }
    class BackendDefaultsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): BackendDefaultsProperty | undefined;
        set internalValue(value: BackendDefaultsProperty | undefined);
        private _clientPolicy;
        get clientPolicy(): SpecBackendDefaultsClientPolicyPropertyList;
    }
    class BackendDefaultsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): BackendDefaultsPropertyOutputReference;
    }
    interface SpecListenerConnectionPoolGrpcProperty {
    }
    class SpecListenerConnectionPoolGrpcPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecListenerConnectionPoolGrpcProperty | undefined;
        set internalValue(value: SpecListenerConnectionPoolGrpcProperty | undefined);
        get maxRequests(): number;
    }
    class SpecListenerConnectionPoolGrpcPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecListenerConnectionPoolGrpcPropertyOutputReference;
    }
    interface SpecListenerConnectionPoolHttpProperty {
    }
    class SpecListenerConnectionPoolHttpPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecListenerConnectionPoolHttpProperty | undefined;
        set internalValue(value: SpecListenerConnectionPoolHttpProperty | undefined);
        get maxConnections(): number;
        get maxPendingRequests(): number;
    }
    class SpecListenerConnectionPoolHttpPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecListenerConnectionPoolHttpPropertyOutputReference;
    }
    interface SpecListenerConnectionPoolHttp2Property {
    }
    class SpecListenerConnectionPoolHttp2PropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecListenerConnectionPoolHttp2Property | undefined;
        set internalValue(value: SpecListenerConnectionPoolHttp2Property | undefined);
        get maxRequests(): number;
    }
    class SpecListenerConnectionPoolHttp2PropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecListenerConnectionPoolHttp2PropertyOutputReference;
    }
    interface SpecListenerConnectionPoolTcpProperty {
    }
    class SpecListenerConnectionPoolTcpPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecListenerConnectionPoolTcpProperty | undefined;
        set internalValue(value: SpecListenerConnectionPoolTcpProperty | undefined);
        get maxConnections(): number;
    }
    class SpecListenerConnectionPoolTcpPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecListenerConnectionPoolTcpPropertyOutputReference;
    }
    interface ConnectionPoolProperty {
    }
    class ConnectionPoolPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ConnectionPoolProperty | undefined;
        set internalValue(value: ConnectionPoolProperty | undefined);
        private _grpc;
        get grpc(): SpecListenerConnectionPoolGrpcPropertyList;
        private _http;
        get http(): SpecListenerConnectionPoolHttpPropertyList;
        private _http2;
        get http2(): SpecListenerConnectionPoolHttp2PropertyList;
        private _tcp;
        get tcp(): SpecListenerConnectionPoolTcpPropertyList;
    }
    class ConnectionPoolPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ConnectionPoolPropertyOutputReference;
    }
    interface HealthCheckProperty {
    }
    class HealthCheckPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): HealthCheckProperty | undefined;
        set internalValue(value: HealthCheckProperty | undefined);
        get healthyThreshold(): number;
        get intervalMillis(): number;
        get path(): string;
        get port(): number;
        get protocol(): string;
        get timeoutMillis(): number;
        get unhealthyThreshold(): number;
    }
    class HealthCheckPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): HealthCheckPropertyOutputReference;
    }
    interface BaseEjectionDurationProperty {
    }
    class BaseEjectionDurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): BaseEjectionDurationProperty | undefined;
        set internalValue(value: BaseEjectionDurationProperty | undefined);
        get unit(): string;
        get value(): number;
    }
    class BaseEjectionDurationPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): BaseEjectionDurationPropertyOutputReference;
    }
    interface IntervalProperty {
    }
    class IntervalPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): IntervalProperty | undefined;
        set internalValue(value: IntervalProperty | undefined);
        get unit(): string;
        get value(): number;
    }
    class IntervalPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): IntervalPropertyOutputReference;
    }
    interface OutlierDetectionProperty {
    }
    class OutlierDetectionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): OutlierDetectionProperty | undefined;
        set internalValue(value: OutlierDetectionProperty | undefined);
        private _baseEjectionDuration;
        get baseEjectionDuration(): BaseEjectionDurationPropertyList;
        private _interval;
        get interval(): IntervalPropertyList;
        get maxEjectionPercent(): number;
        get maxServerErrors(): number;
    }
    class OutlierDetectionPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): OutlierDetectionPropertyOutputReference;
    }
    interface PortMappingProperty {
    }
    class PortMappingPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): PortMappingProperty | undefined;
        set internalValue(value: PortMappingProperty | undefined);
        get port(): number;
        get protocol(): string;
    }
    class PortMappingPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): PortMappingPropertyOutputReference;
    }
    interface SpecListenerTimeoutGrpcIdleProperty {
    }
    class SpecListenerTimeoutGrpcIdlePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecListenerTimeoutGrpcIdleProperty | undefined;
        set internalValue(value: SpecListenerTimeoutGrpcIdleProperty | undefined);
        get unit(): string;
        get value(): number;
    }
    class SpecListenerTimeoutGrpcIdlePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecListenerTimeoutGrpcIdlePropertyOutputReference;
    }
    interface SpecListenerTimeoutGrpcPerRequestProperty {
    }
    class SpecListenerTimeoutGrpcPerRequestPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecListenerTimeoutGrpcPerRequestProperty | undefined;
        set internalValue(value: SpecListenerTimeoutGrpcPerRequestProperty | undefined);
        get unit(): string;
        get value(): number;
    }
    class SpecListenerTimeoutGrpcPerRequestPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecListenerTimeoutGrpcPerRequestPropertyOutputReference;
    }
    interface SpecListenerTimeoutGrpcProperty {
    }
    class SpecListenerTimeoutGrpcPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecListenerTimeoutGrpcProperty | undefined;
        set internalValue(value: SpecListenerTimeoutGrpcProperty | undefined);
        private _idle;
        get idle(): SpecListenerTimeoutGrpcIdlePropertyList;
        private _perRequest;
        get perRequest(): SpecListenerTimeoutGrpcPerRequestPropertyList;
    }
    class SpecListenerTimeoutGrpcPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecListenerTimeoutGrpcPropertyOutputReference;
    }
    interface SpecListenerTimeoutHttpIdleProperty {
    }
    class SpecListenerTimeoutHttpIdlePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecListenerTimeoutHttpIdleProperty | undefined;
        set internalValue(value: SpecListenerTimeoutHttpIdleProperty | undefined);
        get unit(): string;
        get value(): number;
    }
    class SpecListenerTimeoutHttpIdlePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecListenerTimeoutHttpIdlePropertyOutputReference;
    }
    interface SpecListenerTimeoutHttpPerRequestProperty {
    }
    class SpecListenerTimeoutHttpPerRequestPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecListenerTimeoutHttpPerRequestProperty | undefined;
        set internalValue(value: SpecListenerTimeoutHttpPerRequestProperty | undefined);
        get unit(): string;
        get value(): number;
    }
    class SpecListenerTimeoutHttpPerRequestPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecListenerTimeoutHttpPerRequestPropertyOutputReference;
    }
    interface SpecListenerTimeoutHttpProperty {
    }
    class SpecListenerTimeoutHttpPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecListenerTimeoutHttpProperty | undefined;
        set internalValue(value: SpecListenerTimeoutHttpProperty | undefined);
        private _idle;
        get idle(): SpecListenerTimeoutHttpIdlePropertyList;
        private _perRequest;
        get perRequest(): SpecListenerTimeoutHttpPerRequestPropertyList;
    }
    class SpecListenerTimeoutHttpPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecListenerTimeoutHttpPropertyOutputReference;
    }
    interface SpecListenerTimeoutHttp2IdleProperty {
    }
    class SpecListenerTimeoutHttp2IdlePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecListenerTimeoutHttp2IdleProperty | undefined;
        set internalValue(value: SpecListenerTimeoutHttp2IdleProperty | undefined);
        get unit(): string;
        get value(): number;
    }
    class SpecListenerTimeoutHttp2IdlePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecListenerTimeoutHttp2IdlePropertyOutputReference;
    }
    interface SpecListenerTimeoutHttp2PerRequestProperty {
    }
    class SpecListenerTimeoutHttp2PerRequestPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecListenerTimeoutHttp2PerRequestProperty | undefined;
        set internalValue(value: SpecListenerTimeoutHttp2PerRequestProperty | undefined);
        get unit(): string;
        get value(): number;
    }
    class SpecListenerTimeoutHttp2PerRequestPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecListenerTimeoutHttp2PerRequestPropertyOutputReference;
    }
    interface SpecListenerTimeoutHttp2Property {
    }
    class SpecListenerTimeoutHttp2PropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecListenerTimeoutHttp2Property | undefined;
        set internalValue(value: SpecListenerTimeoutHttp2Property | undefined);
        private _idle;
        get idle(): SpecListenerTimeoutHttp2IdlePropertyList;
        private _perRequest;
        get perRequest(): SpecListenerTimeoutHttp2PerRequestPropertyList;
    }
    class SpecListenerTimeoutHttp2PropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecListenerTimeoutHttp2PropertyOutputReference;
    }
    interface SpecListenerTimeoutTcpIdleProperty {
    }
    class SpecListenerTimeoutTcpIdlePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecListenerTimeoutTcpIdleProperty | undefined;
        set internalValue(value: SpecListenerTimeoutTcpIdleProperty | undefined);
        get unit(): string;
        get value(): number;
    }
    class SpecListenerTimeoutTcpIdlePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecListenerTimeoutTcpIdlePropertyOutputReference;
    }
    interface SpecListenerTimeoutTcpProperty {
    }
    class SpecListenerTimeoutTcpPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecListenerTimeoutTcpProperty | undefined;
        set internalValue(value: SpecListenerTimeoutTcpProperty | undefined);
        private _idle;
        get idle(): SpecListenerTimeoutTcpIdlePropertyList;
    }
    class SpecListenerTimeoutTcpPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecListenerTimeoutTcpPropertyOutputReference;
    }
    interface TimeoutProperty {
    }
    class TimeoutPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TimeoutProperty | undefined;
        set internalValue(value: TimeoutProperty | undefined);
        private _grpc;
        get grpc(): SpecListenerTimeoutGrpcPropertyList;
        private _http;
        get http(): SpecListenerTimeoutHttpPropertyList;
        private _http2;
        get http2(): SpecListenerTimeoutHttp2PropertyList;
        private _tcp;
        get tcp(): SpecListenerTimeoutTcpPropertyList;
    }
    class TimeoutPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TimeoutPropertyOutputReference;
    }
    interface SpecListenerTlsCertificateAcmProperty {
    }
    class SpecListenerTlsCertificateAcmPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecListenerTlsCertificateAcmProperty | undefined;
        set internalValue(value: SpecListenerTlsCertificateAcmProperty | undefined);
        get certificateArn(): string;
    }
    class SpecListenerTlsCertificateAcmPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecListenerTlsCertificateAcmPropertyOutputReference;
    }
    interface SpecListenerTlsCertificateFileProperty {
    }
    class SpecListenerTlsCertificateFilePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecListenerTlsCertificateFileProperty | undefined;
        set internalValue(value: SpecListenerTlsCertificateFileProperty | undefined);
        get certificateChain(): string;
        get privateKey(): string;
    }
    class SpecListenerTlsCertificateFilePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecListenerTlsCertificateFilePropertyOutputReference;
    }
    interface SpecListenerTlsCertificateSdsProperty {
    }
    class SpecListenerTlsCertificateSdsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecListenerTlsCertificateSdsProperty | undefined;
        set internalValue(value: SpecListenerTlsCertificateSdsProperty | undefined);
        get secretName(): string;
    }
    class SpecListenerTlsCertificateSdsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecListenerTlsCertificateSdsPropertyOutputReference;
    }
    interface SpecListenerTlsCertificateProperty {
    }
    class SpecListenerTlsCertificatePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecListenerTlsCertificateProperty | undefined;
        set internalValue(value: SpecListenerTlsCertificateProperty | undefined);
        private _acm;
        get acm(): SpecListenerTlsCertificateAcmPropertyList;
        private _file;
        get file(): SpecListenerTlsCertificateFilePropertyList;
        private _sds;
        get sds(): SpecListenerTlsCertificateSdsPropertyList;
    }
    class SpecListenerTlsCertificatePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecListenerTlsCertificatePropertyOutputReference;
    }
    interface SpecListenerTlsValidationSubjectAlternativeNamesMatchProperty {
    }
    class SpecListenerTlsValidationSubjectAlternativeNamesMatchPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecListenerTlsValidationSubjectAlternativeNamesMatchProperty | undefined;
        set internalValue(value: SpecListenerTlsValidationSubjectAlternativeNamesMatchProperty | undefined);
        get exact(): string[];
    }
    class SpecListenerTlsValidationSubjectAlternativeNamesMatchPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecListenerTlsValidationSubjectAlternativeNamesMatchPropertyOutputReference;
    }
    interface SpecListenerTlsValidationSubjectAlternativeNamesProperty {
    }
    class SpecListenerTlsValidationSubjectAlternativeNamesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecListenerTlsValidationSubjectAlternativeNamesProperty | undefined;
        set internalValue(value: SpecListenerTlsValidationSubjectAlternativeNamesProperty | undefined);
        private _match;
        get match(): SpecListenerTlsValidationSubjectAlternativeNamesMatchPropertyList;
    }
    class SpecListenerTlsValidationSubjectAlternativeNamesPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecListenerTlsValidationSubjectAlternativeNamesPropertyOutputReference;
    }
    interface SpecListenerTlsValidationTrustFileProperty {
    }
    class SpecListenerTlsValidationTrustFilePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecListenerTlsValidationTrustFileProperty | undefined;
        set internalValue(value: SpecListenerTlsValidationTrustFileProperty | undefined);
        get certificateChain(): string;
    }
    class SpecListenerTlsValidationTrustFilePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecListenerTlsValidationTrustFilePropertyOutputReference;
    }
    interface SpecListenerTlsValidationTrustSdsProperty {
    }
    class SpecListenerTlsValidationTrustSdsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecListenerTlsValidationTrustSdsProperty | undefined;
        set internalValue(value: SpecListenerTlsValidationTrustSdsProperty | undefined);
        get secretName(): string;
    }
    class SpecListenerTlsValidationTrustSdsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecListenerTlsValidationTrustSdsPropertyOutputReference;
    }
    interface SpecListenerTlsValidationTrustProperty {
    }
    class SpecListenerTlsValidationTrustPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecListenerTlsValidationTrustProperty | undefined;
        set internalValue(value: SpecListenerTlsValidationTrustProperty | undefined);
        private _file;
        get file(): SpecListenerTlsValidationTrustFilePropertyList;
        private _sds;
        get sds(): SpecListenerTlsValidationTrustSdsPropertyList;
    }
    class SpecListenerTlsValidationTrustPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecListenerTlsValidationTrustPropertyOutputReference;
    }
    interface SpecListenerTlsValidationProperty {
    }
    class SpecListenerTlsValidationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecListenerTlsValidationProperty | undefined;
        set internalValue(value: SpecListenerTlsValidationProperty | undefined);
        private _subjectAlternativeNames;
        get subjectAlternativeNames(): SpecListenerTlsValidationSubjectAlternativeNamesPropertyList;
        private _trust;
        get trust(): SpecListenerTlsValidationTrustPropertyList;
    }
    class SpecListenerTlsValidationPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecListenerTlsValidationPropertyOutputReference;
    }
    interface SpecListenerTlsProperty {
    }
    class SpecListenerTlsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecListenerTlsProperty | undefined;
        set internalValue(value: SpecListenerTlsProperty | undefined);
        private _certificate;
        get certificate(): SpecListenerTlsCertificatePropertyList;
        get mode(): string;
        private _validation;
        get validation(): SpecListenerTlsValidationPropertyList;
    }
    class SpecListenerTlsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecListenerTlsPropertyOutputReference;
    }
    interface ListenerProperty {
    }
    class ListenerPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ListenerProperty | undefined;
        set internalValue(value: ListenerProperty | undefined);
        private _connectionPool;
        get connectionPool(): ConnectionPoolPropertyList;
        private _healthCheck;
        get healthCheck(): HealthCheckPropertyList;
        private _outlierDetection;
        get outlierDetection(): OutlierDetectionPropertyList;
        private _portMapping;
        get portMapping(): PortMappingPropertyList;
        private _timeout;
        get timeout(): TimeoutPropertyList;
        private _tls;
        get tls(): SpecListenerTlsPropertyList;
    }
    class ListenerPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ListenerPropertyOutputReference;
    }
    interface JsonProperty {
    }
    class JsonPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): JsonProperty | undefined;
        set internalValue(value: JsonProperty | undefined);
        get key(): string;
        get value(): string;
    }
    class JsonPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): JsonPropertyOutputReference;
    }
    interface FormatProperty {
    }
    class FormatPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): FormatProperty | undefined;
        set internalValue(value: FormatProperty | undefined);
        private _json;
        get json(): JsonPropertyList;
        get text(): string;
    }
    class FormatPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): FormatPropertyOutputReference;
    }
    interface SpecLoggingAccessLogFileProperty {
    }
    class SpecLoggingAccessLogFilePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecLoggingAccessLogFileProperty | undefined;
        set internalValue(value: SpecLoggingAccessLogFileProperty | undefined);
        private _format;
        get format(): FormatPropertyList;
        get path(): string;
    }
    class SpecLoggingAccessLogFilePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecLoggingAccessLogFilePropertyOutputReference;
    }
    interface AccessLogProperty {
    }
    class AccessLogPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AccessLogProperty | undefined;
        set internalValue(value: AccessLogProperty | undefined);
        private _file;
        get file(): SpecLoggingAccessLogFilePropertyList;
    }
    class AccessLogPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AccessLogPropertyOutputReference;
    }
    interface LoggingProperty {
    }
    class LoggingPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): LoggingProperty | undefined;
        set internalValue(value: LoggingProperty | undefined);
        private _accessLog;
        get accessLog(): AccessLogPropertyList;
    }
    class LoggingPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): LoggingPropertyOutputReference;
    }
    interface AwsCloudMapProperty {
    }
    class AwsCloudMapPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AwsCloudMapProperty | undefined;
        set internalValue(value: AwsCloudMapProperty | undefined);
        private _attributes;
        get attributes(): cdktn.StringMap;
        get namespaceName(): string;
        get serviceName(): string;
    }
    class AwsCloudMapPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AwsCloudMapPropertyOutputReference;
    }
    interface DnsProperty {
    }
    class DnsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DnsProperty | undefined;
        set internalValue(value: DnsProperty | undefined);
        get hostname(): string;
        get ipPreference(): string;
        get responseType(): string;
    }
    class DnsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DnsPropertyOutputReference;
    }
    interface ServiceDiscoveryProperty {
    }
    class ServiceDiscoveryPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ServiceDiscoveryProperty | undefined;
        set internalValue(value: ServiceDiscoveryProperty | undefined);
        private _awsCloudMap;
        get awsCloudMap(): AwsCloudMapPropertyList;
        private _dns;
        get dns(): DnsPropertyList;
    }
    class ServiceDiscoveryPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ServiceDiscoveryPropertyOutputReference;
    }
    interface SpecProperty {
    }
    class SpecPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecProperty | undefined;
        set internalValue(value: SpecProperty | undefined);
        private _backend;
        get backend(): BackendPropertyList;
        private _backendDefaults;
        get backendDefaults(): BackendDefaultsPropertyList;
        private _listener;
        get listener(): ListenerPropertyList;
        private _logging;
        get logging(): LoggingPropertyList;
        private _serviceDiscovery;
        get serviceDiscovery(): ServiceDiscoveryPropertyList;
    }
    class SpecPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecPropertyOutputReference;
    }
}
