import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsGatewayRouteConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/appmesh_gateway_route#id DataAwsGatewayRoute#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/appmesh_gateway_route#mesh_name DataAwsGatewayRoute#mesh_name}
    */
    readonly meshName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/appmesh_gateway_route#mesh_owner DataAwsGatewayRoute#mesh_owner}
    */
    readonly meshOwner?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/appmesh_gateway_route#name DataAwsGatewayRoute#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/appmesh_gateway_route#region DataAwsGatewayRoute#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/appmesh_gateway_route#tags DataAwsGatewayRoute#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/appmesh_gateway_route#virtual_gateway_name DataAwsGatewayRoute#virtual_gateway_name}
    */
    readonly virtualGatewayName: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/appmesh_gateway_route aws_appmesh_gateway_route}
*/
export declare class DataAwsGatewayRoute extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_appmesh_gateway_route";
    /**
    * Generates CDKTN code for importing a DataAwsGatewayRoute resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsGatewayRoute to import
    * @param importFromId The id of the existing DataAwsGatewayRoute that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/appmesh_gateway_route#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsGatewayRoute to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/appmesh_gateway_route aws_appmesh_gateway_route} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsGatewayRouteConfig
    */
    constructor(scope: Construct, id: string, config: DataAwsGatewayRouteConfig);
    get arn(): string;
    get createdDate(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get lastUpdatedDate(): string;
    private _meshName?;
    get meshName(): string;
    set meshName(value: string);
    get meshNameInput(): string | undefined;
    private _meshOwner?;
    get meshOwner(): string;
    set meshOwner(value: string);
    resetMeshOwner(): void;
    get meshOwnerInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get resourceOwner(): string;
    private _spec;
    get spec(): DataAwsGatewayRoute.SpecPropertyList;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _virtualGatewayName?;
    get virtualGatewayName(): string;
    set virtualGatewayName(value: string);
    get virtualGatewayNameInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataAwsGatewayRouteSpecGrpcRouteActionTargetVirtualServicePropertyToTerraform(struct?: DataAwsGatewayRoute.SpecGrpcRouteActionTargetVirtualServiceProperty): any;
export declare function dataAwsGatewayRouteSpecGrpcRouteActionTargetVirtualServicePropertyToHclTerraform(struct?: DataAwsGatewayRoute.SpecGrpcRouteActionTargetVirtualServiceProperty): any;
export declare function dataAwsGatewayRouteSpecGrpcRouteActionTargetPropertyToTerraform(struct?: DataAwsGatewayRoute.SpecGrpcRouteActionTargetProperty): any;
export declare function dataAwsGatewayRouteSpecGrpcRouteActionTargetPropertyToHclTerraform(struct?: DataAwsGatewayRoute.SpecGrpcRouteActionTargetProperty): any;
export declare function dataAwsGatewayRouteSpecGrpcRouteActionPropertyToTerraform(struct?: DataAwsGatewayRoute.SpecGrpcRouteActionProperty): any;
export declare function dataAwsGatewayRouteSpecGrpcRouteActionPropertyToHclTerraform(struct?: DataAwsGatewayRoute.SpecGrpcRouteActionProperty): any;
export declare function dataAwsGatewayRouteSpecGrpcRouteMatchPropertyToTerraform(struct?: DataAwsGatewayRoute.SpecGrpcRouteMatchProperty): any;
export declare function dataAwsGatewayRouteSpecGrpcRouteMatchPropertyToHclTerraform(struct?: DataAwsGatewayRoute.SpecGrpcRouteMatchProperty): any;
export declare function dataAwsGatewayRouteGrpcRoutePropertyToTerraform(struct?: DataAwsGatewayRoute.GrpcRouteProperty): any;
export declare function dataAwsGatewayRouteGrpcRoutePropertyToHclTerraform(struct?: DataAwsGatewayRoute.GrpcRouteProperty): any;
export declare function dataAwsGatewayRouteSpecHttp2RouteActionRewriteHostnamePropertyToTerraform(struct?: DataAwsGatewayRoute.SpecHttp2RouteActionRewriteHostnameProperty): any;
export declare function dataAwsGatewayRouteSpecHttp2RouteActionRewriteHostnamePropertyToHclTerraform(struct?: DataAwsGatewayRoute.SpecHttp2RouteActionRewriteHostnameProperty): any;
export declare function dataAwsGatewayRouteSpecHttp2RouteActionRewritePathPropertyToTerraform(struct?: DataAwsGatewayRoute.SpecHttp2RouteActionRewritePathProperty): any;
export declare function dataAwsGatewayRouteSpecHttp2RouteActionRewritePathPropertyToHclTerraform(struct?: DataAwsGatewayRoute.SpecHttp2RouteActionRewritePathProperty): any;
export declare function dataAwsGatewayRouteSpecHttp2RouteActionRewritePrefixPropertyToTerraform(struct?: DataAwsGatewayRoute.SpecHttp2RouteActionRewritePrefixProperty): any;
export declare function dataAwsGatewayRouteSpecHttp2RouteActionRewritePrefixPropertyToHclTerraform(struct?: DataAwsGatewayRoute.SpecHttp2RouteActionRewritePrefixProperty): any;
export declare function dataAwsGatewayRouteSpecHttp2RouteActionRewritePropertyToTerraform(struct?: DataAwsGatewayRoute.SpecHttp2RouteActionRewriteProperty): any;
export declare function dataAwsGatewayRouteSpecHttp2RouteActionRewritePropertyToHclTerraform(struct?: DataAwsGatewayRoute.SpecHttp2RouteActionRewriteProperty): any;
export declare function dataAwsGatewayRouteSpecHttp2RouteActionTargetVirtualServicePropertyToTerraform(struct?: DataAwsGatewayRoute.SpecHttp2RouteActionTargetVirtualServiceProperty): any;
export declare function dataAwsGatewayRouteSpecHttp2RouteActionTargetVirtualServicePropertyToHclTerraform(struct?: DataAwsGatewayRoute.SpecHttp2RouteActionTargetVirtualServiceProperty): any;
export declare function dataAwsGatewayRouteSpecHttp2RouteActionTargetPropertyToTerraform(struct?: DataAwsGatewayRoute.SpecHttp2RouteActionTargetProperty): any;
export declare function dataAwsGatewayRouteSpecHttp2RouteActionTargetPropertyToHclTerraform(struct?: DataAwsGatewayRoute.SpecHttp2RouteActionTargetProperty): any;
export declare function dataAwsGatewayRouteSpecHttp2RouteActionPropertyToTerraform(struct?: DataAwsGatewayRoute.SpecHttp2RouteActionProperty): any;
export declare function dataAwsGatewayRouteSpecHttp2RouteActionPropertyToHclTerraform(struct?: DataAwsGatewayRoute.SpecHttp2RouteActionProperty): any;
export declare function dataAwsGatewayRouteSpecHttp2RouteMatchHeaderMatchRangePropertyToTerraform(struct?: DataAwsGatewayRoute.SpecHttp2RouteMatchHeaderMatchRangeProperty): any;
export declare function dataAwsGatewayRouteSpecHttp2RouteMatchHeaderMatchRangePropertyToHclTerraform(struct?: DataAwsGatewayRoute.SpecHttp2RouteMatchHeaderMatchRangeProperty): any;
export declare function dataAwsGatewayRouteSpecHttp2RouteMatchHeaderMatchPropertyToTerraform(struct?: DataAwsGatewayRoute.SpecHttp2RouteMatchHeaderMatchProperty): any;
export declare function dataAwsGatewayRouteSpecHttp2RouteMatchHeaderMatchPropertyToHclTerraform(struct?: DataAwsGatewayRoute.SpecHttp2RouteMatchHeaderMatchProperty): any;
export declare function dataAwsGatewayRouteSpecHttp2RouteMatchHeaderPropertyToTerraform(struct?: DataAwsGatewayRoute.SpecHttp2RouteMatchHeaderProperty): any;
export declare function dataAwsGatewayRouteSpecHttp2RouteMatchHeaderPropertyToHclTerraform(struct?: DataAwsGatewayRoute.SpecHttp2RouteMatchHeaderProperty): any;
export declare function dataAwsGatewayRouteSpecHttp2RouteMatchHostnamePropertyToTerraform(struct?: DataAwsGatewayRoute.SpecHttp2RouteMatchHostnameProperty): any;
export declare function dataAwsGatewayRouteSpecHttp2RouteMatchHostnamePropertyToHclTerraform(struct?: DataAwsGatewayRoute.SpecHttp2RouteMatchHostnameProperty): any;
export declare function dataAwsGatewayRouteSpecHttp2RouteMatchPathPropertyToTerraform(struct?: DataAwsGatewayRoute.SpecHttp2RouteMatchPathProperty): any;
export declare function dataAwsGatewayRouteSpecHttp2RouteMatchPathPropertyToHclTerraform(struct?: DataAwsGatewayRoute.SpecHttp2RouteMatchPathProperty): any;
export declare function dataAwsGatewayRouteSpecHttp2RouteMatchQueryParameterMatchPropertyToTerraform(struct?: DataAwsGatewayRoute.SpecHttp2RouteMatchQueryParameterMatchProperty): any;
export declare function dataAwsGatewayRouteSpecHttp2RouteMatchQueryParameterMatchPropertyToHclTerraform(struct?: DataAwsGatewayRoute.SpecHttp2RouteMatchQueryParameterMatchProperty): any;
export declare function dataAwsGatewayRouteSpecHttp2RouteMatchQueryParameterPropertyToTerraform(struct?: DataAwsGatewayRoute.SpecHttp2RouteMatchQueryParameterProperty): any;
export declare function dataAwsGatewayRouteSpecHttp2RouteMatchQueryParameterPropertyToHclTerraform(struct?: DataAwsGatewayRoute.SpecHttp2RouteMatchQueryParameterProperty): any;
export declare function dataAwsGatewayRouteSpecHttp2RouteMatchPropertyToTerraform(struct?: DataAwsGatewayRoute.SpecHttp2RouteMatchProperty): any;
export declare function dataAwsGatewayRouteSpecHttp2RouteMatchPropertyToHclTerraform(struct?: DataAwsGatewayRoute.SpecHttp2RouteMatchProperty): any;
export declare function dataAwsGatewayRouteHttp2RoutePropertyToTerraform(struct?: DataAwsGatewayRoute.Http2RouteProperty): any;
export declare function dataAwsGatewayRouteHttp2RoutePropertyToHclTerraform(struct?: DataAwsGatewayRoute.Http2RouteProperty): any;
export declare function dataAwsGatewayRouteSpecHttpRouteActionRewriteHostnamePropertyToTerraform(struct?: DataAwsGatewayRoute.SpecHttpRouteActionRewriteHostnameProperty): any;
export declare function dataAwsGatewayRouteSpecHttpRouteActionRewriteHostnamePropertyToHclTerraform(struct?: DataAwsGatewayRoute.SpecHttpRouteActionRewriteHostnameProperty): any;
export declare function dataAwsGatewayRouteSpecHttpRouteActionRewritePathPropertyToTerraform(struct?: DataAwsGatewayRoute.SpecHttpRouteActionRewritePathProperty): any;
export declare function dataAwsGatewayRouteSpecHttpRouteActionRewritePathPropertyToHclTerraform(struct?: DataAwsGatewayRoute.SpecHttpRouteActionRewritePathProperty): any;
export declare function dataAwsGatewayRouteSpecHttpRouteActionRewritePrefixPropertyToTerraform(struct?: DataAwsGatewayRoute.SpecHttpRouteActionRewritePrefixProperty): any;
export declare function dataAwsGatewayRouteSpecHttpRouteActionRewritePrefixPropertyToHclTerraform(struct?: DataAwsGatewayRoute.SpecHttpRouteActionRewritePrefixProperty): any;
export declare function dataAwsGatewayRouteSpecHttpRouteActionRewritePropertyToTerraform(struct?: DataAwsGatewayRoute.SpecHttpRouteActionRewriteProperty): any;
export declare function dataAwsGatewayRouteSpecHttpRouteActionRewritePropertyToHclTerraform(struct?: DataAwsGatewayRoute.SpecHttpRouteActionRewriteProperty): any;
export declare function dataAwsGatewayRouteSpecHttpRouteActionTargetVirtualServicePropertyToTerraform(struct?: DataAwsGatewayRoute.SpecHttpRouteActionTargetVirtualServiceProperty): any;
export declare function dataAwsGatewayRouteSpecHttpRouteActionTargetVirtualServicePropertyToHclTerraform(struct?: DataAwsGatewayRoute.SpecHttpRouteActionTargetVirtualServiceProperty): any;
export declare function dataAwsGatewayRouteSpecHttpRouteActionTargetPropertyToTerraform(struct?: DataAwsGatewayRoute.SpecHttpRouteActionTargetProperty): any;
export declare function dataAwsGatewayRouteSpecHttpRouteActionTargetPropertyToHclTerraform(struct?: DataAwsGatewayRoute.SpecHttpRouteActionTargetProperty): any;
export declare function dataAwsGatewayRouteSpecHttpRouteActionPropertyToTerraform(struct?: DataAwsGatewayRoute.SpecHttpRouteActionProperty): any;
export declare function dataAwsGatewayRouteSpecHttpRouteActionPropertyToHclTerraform(struct?: DataAwsGatewayRoute.SpecHttpRouteActionProperty): any;
export declare function dataAwsGatewayRouteSpecHttpRouteMatchHeaderMatchRangePropertyToTerraform(struct?: DataAwsGatewayRoute.SpecHttpRouteMatchHeaderMatchRangeProperty): any;
export declare function dataAwsGatewayRouteSpecHttpRouteMatchHeaderMatchRangePropertyToHclTerraform(struct?: DataAwsGatewayRoute.SpecHttpRouteMatchHeaderMatchRangeProperty): any;
export declare function dataAwsGatewayRouteSpecHttpRouteMatchHeaderMatchPropertyToTerraform(struct?: DataAwsGatewayRoute.SpecHttpRouteMatchHeaderMatchProperty): any;
export declare function dataAwsGatewayRouteSpecHttpRouteMatchHeaderMatchPropertyToHclTerraform(struct?: DataAwsGatewayRoute.SpecHttpRouteMatchHeaderMatchProperty): any;
export declare function dataAwsGatewayRouteSpecHttpRouteMatchHeaderPropertyToTerraform(struct?: DataAwsGatewayRoute.SpecHttpRouteMatchHeaderProperty): any;
export declare function dataAwsGatewayRouteSpecHttpRouteMatchHeaderPropertyToHclTerraform(struct?: DataAwsGatewayRoute.SpecHttpRouteMatchHeaderProperty): any;
export declare function dataAwsGatewayRouteSpecHttpRouteMatchHostnamePropertyToTerraform(struct?: DataAwsGatewayRoute.SpecHttpRouteMatchHostnameProperty): any;
export declare function dataAwsGatewayRouteSpecHttpRouteMatchHostnamePropertyToHclTerraform(struct?: DataAwsGatewayRoute.SpecHttpRouteMatchHostnameProperty): any;
export declare function dataAwsGatewayRouteSpecHttpRouteMatchPathPropertyToTerraform(struct?: DataAwsGatewayRoute.SpecHttpRouteMatchPathProperty): any;
export declare function dataAwsGatewayRouteSpecHttpRouteMatchPathPropertyToHclTerraform(struct?: DataAwsGatewayRoute.SpecHttpRouteMatchPathProperty): any;
export declare function dataAwsGatewayRouteSpecHttpRouteMatchQueryParameterMatchPropertyToTerraform(struct?: DataAwsGatewayRoute.SpecHttpRouteMatchQueryParameterMatchProperty): any;
export declare function dataAwsGatewayRouteSpecHttpRouteMatchQueryParameterMatchPropertyToHclTerraform(struct?: DataAwsGatewayRoute.SpecHttpRouteMatchQueryParameterMatchProperty): any;
export declare function dataAwsGatewayRouteSpecHttpRouteMatchQueryParameterPropertyToTerraform(struct?: DataAwsGatewayRoute.SpecHttpRouteMatchQueryParameterProperty): any;
export declare function dataAwsGatewayRouteSpecHttpRouteMatchQueryParameterPropertyToHclTerraform(struct?: DataAwsGatewayRoute.SpecHttpRouteMatchQueryParameterProperty): any;
export declare function dataAwsGatewayRouteSpecHttpRouteMatchPropertyToTerraform(struct?: DataAwsGatewayRoute.SpecHttpRouteMatchProperty): any;
export declare function dataAwsGatewayRouteSpecHttpRouteMatchPropertyToHclTerraform(struct?: DataAwsGatewayRoute.SpecHttpRouteMatchProperty): any;
export declare function dataAwsGatewayRouteHttpRoutePropertyToTerraform(struct?: DataAwsGatewayRoute.HttpRouteProperty): any;
export declare function dataAwsGatewayRouteHttpRoutePropertyToHclTerraform(struct?: DataAwsGatewayRoute.HttpRouteProperty): any;
export declare function dataAwsGatewayRouteSpecPropertyToTerraform(struct?: DataAwsGatewayRoute.SpecProperty): any;
export declare function dataAwsGatewayRouteSpecPropertyToHclTerraform(struct?: DataAwsGatewayRoute.SpecProperty): any;
export declare namespace DataAwsGatewayRoute {
    interface SpecGrpcRouteActionTargetVirtualServiceProperty {
    }
    class SpecGrpcRouteActionTargetVirtualServicePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecGrpcRouteActionTargetVirtualServiceProperty | undefined;
        set internalValue(value: SpecGrpcRouteActionTargetVirtualServiceProperty | undefined);
        get virtualServiceName(): string;
    }
    class SpecGrpcRouteActionTargetVirtualServicePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecGrpcRouteActionTargetVirtualServicePropertyOutputReference;
    }
    interface SpecGrpcRouteActionTargetProperty {
    }
    class SpecGrpcRouteActionTargetPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecGrpcRouteActionTargetProperty | undefined;
        set internalValue(value: SpecGrpcRouteActionTargetProperty | undefined);
        get port(): number;
        private _virtualService;
        get virtualService(): SpecGrpcRouteActionTargetVirtualServicePropertyList;
    }
    class SpecGrpcRouteActionTargetPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecGrpcRouteActionTargetPropertyOutputReference;
    }
    interface SpecGrpcRouteActionProperty {
    }
    class SpecGrpcRouteActionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecGrpcRouteActionProperty | undefined;
        set internalValue(value: SpecGrpcRouteActionProperty | undefined);
        private _target;
        get target(): SpecGrpcRouteActionTargetPropertyList;
    }
    class SpecGrpcRouteActionPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecGrpcRouteActionPropertyOutputReference;
    }
    interface SpecGrpcRouteMatchProperty {
    }
    class SpecGrpcRouteMatchPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecGrpcRouteMatchProperty | undefined;
        set internalValue(value: SpecGrpcRouteMatchProperty | undefined);
        get port(): number;
        get serviceName(): string;
    }
    class SpecGrpcRouteMatchPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecGrpcRouteMatchPropertyOutputReference;
    }
    interface GrpcRouteProperty {
    }
    class GrpcRoutePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): GrpcRouteProperty | undefined;
        set internalValue(value: GrpcRouteProperty | undefined);
        private _action;
        get action(): SpecGrpcRouteActionPropertyList;
        private _match;
        get match(): SpecGrpcRouteMatchPropertyList;
    }
    class GrpcRoutePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): GrpcRoutePropertyOutputReference;
    }
    interface SpecHttp2RouteActionRewriteHostnameProperty {
    }
    class SpecHttp2RouteActionRewriteHostnamePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecHttp2RouteActionRewriteHostnameProperty | undefined;
        set internalValue(value: SpecHttp2RouteActionRewriteHostnameProperty | undefined);
        get defaultTargetHostname(): string;
    }
    class SpecHttp2RouteActionRewriteHostnamePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecHttp2RouteActionRewriteHostnamePropertyOutputReference;
    }
    interface SpecHttp2RouteActionRewritePathProperty {
    }
    class SpecHttp2RouteActionRewritePathPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecHttp2RouteActionRewritePathProperty | undefined;
        set internalValue(value: SpecHttp2RouteActionRewritePathProperty | undefined);
        get exact(): string;
    }
    class SpecHttp2RouteActionRewritePathPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecHttp2RouteActionRewritePathPropertyOutputReference;
    }
    interface SpecHttp2RouteActionRewritePrefixProperty {
    }
    class SpecHttp2RouteActionRewritePrefixPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecHttp2RouteActionRewritePrefixProperty | undefined;
        set internalValue(value: SpecHttp2RouteActionRewritePrefixProperty | undefined);
        get defaultPrefix(): string;
        get value(): string;
    }
    class SpecHttp2RouteActionRewritePrefixPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecHttp2RouteActionRewritePrefixPropertyOutputReference;
    }
    interface SpecHttp2RouteActionRewriteProperty {
    }
    class SpecHttp2RouteActionRewritePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecHttp2RouteActionRewriteProperty | undefined;
        set internalValue(value: SpecHttp2RouteActionRewriteProperty | undefined);
        private _hostname;
        get hostname(): SpecHttp2RouteActionRewriteHostnamePropertyList;
        private _path;
        get path(): SpecHttp2RouteActionRewritePathPropertyList;
        private _prefix;
        get prefix(): SpecHttp2RouteActionRewritePrefixPropertyList;
    }
    class SpecHttp2RouteActionRewritePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecHttp2RouteActionRewritePropertyOutputReference;
    }
    interface SpecHttp2RouteActionTargetVirtualServiceProperty {
    }
    class SpecHttp2RouteActionTargetVirtualServicePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecHttp2RouteActionTargetVirtualServiceProperty | undefined;
        set internalValue(value: SpecHttp2RouteActionTargetVirtualServiceProperty | undefined);
        get virtualServiceName(): string;
    }
    class SpecHttp2RouteActionTargetVirtualServicePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecHttp2RouteActionTargetVirtualServicePropertyOutputReference;
    }
    interface SpecHttp2RouteActionTargetProperty {
    }
    class SpecHttp2RouteActionTargetPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecHttp2RouteActionTargetProperty | undefined;
        set internalValue(value: SpecHttp2RouteActionTargetProperty | undefined);
        get port(): number;
        private _virtualService;
        get virtualService(): SpecHttp2RouteActionTargetVirtualServicePropertyList;
    }
    class SpecHttp2RouteActionTargetPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecHttp2RouteActionTargetPropertyOutputReference;
    }
    interface SpecHttp2RouteActionProperty {
    }
    class SpecHttp2RouteActionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecHttp2RouteActionProperty | undefined;
        set internalValue(value: SpecHttp2RouteActionProperty | undefined);
        private _rewrite;
        get rewrite(): SpecHttp2RouteActionRewritePropertyList;
        private _target;
        get target(): SpecHttp2RouteActionTargetPropertyList;
    }
    class SpecHttp2RouteActionPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecHttp2RouteActionPropertyOutputReference;
    }
    interface SpecHttp2RouteMatchHeaderMatchRangeProperty {
    }
    class SpecHttp2RouteMatchHeaderMatchRangePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecHttp2RouteMatchHeaderMatchRangeProperty | undefined;
        set internalValue(value: SpecHttp2RouteMatchHeaderMatchRangeProperty | undefined);
        get end(): number;
        get start(): number;
    }
    class SpecHttp2RouteMatchHeaderMatchRangePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecHttp2RouteMatchHeaderMatchRangePropertyOutputReference;
    }
    interface SpecHttp2RouteMatchHeaderMatchProperty {
    }
    class SpecHttp2RouteMatchHeaderMatchPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecHttp2RouteMatchHeaderMatchProperty | undefined;
        set internalValue(value: SpecHttp2RouteMatchHeaderMatchProperty | undefined);
        get exact(): string;
        get prefix(): string;
        private _range;
        get range(): SpecHttp2RouteMatchHeaderMatchRangePropertyList;
        get regex(): string;
        get suffix(): string;
    }
    class SpecHttp2RouteMatchHeaderMatchPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecHttp2RouteMatchHeaderMatchPropertyOutputReference;
    }
    interface SpecHttp2RouteMatchHeaderProperty {
    }
    class SpecHttp2RouteMatchHeaderPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecHttp2RouteMatchHeaderProperty | undefined;
        set internalValue(value: SpecHttp2RouteMatchHeaderProperty | undefined);
        get invert(): cdktn.IResolvable;
        private _match;
        get match(): SpecHttp2RouteMatchHeaderMatchPropertyList;
        get name(): string;
    }
    class SpecHttp2RouteMatchHeaderPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecHttp2RouteMatchHeaderPropertyOutputReference;
    }
    interface SpecHttp2RouteMatchHostnameProperty {
    }
    class SpecHttp2RouteMatchHostnamePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecHttp2RouteMatchHostnameProperty | undefined;
        set internalValue(value: SpecHttp2RouteMatchHostnameProperty | undefined);
        get exact(): string;
        get suffix(): string;
    }
    class SpecHttp2RouteMatchHostnamePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecHttp2RouteMatchHostnamePropertyOutputReference;
    }
    interface SpecHttp2RouteMatchPathProperty {
    }
    class SpecHttp2RouteMatchPathPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecHttp2RouteMatchPathProperty | undefined;
        set internalValue(value: SpecHttp2RouteMatchPathProperty | undefined);
        get exact(): string;
        get regex(): string;
    }
    class SpecHttp2RouteMatchPathPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecHttp2RouteMatchPathPropertyOutputReference;
    }
    interface SpecHttp2RouteMatchQueryParameterMatchProperty {
    }
    class SpecHttp2RouteMatchQueryParameterMatchPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecHttp2RouteMatchQueryParameterMatchProperty | undefined;
        set internalValue(value: SpecHttp2RouteMatchQueryParameterMatchProperty | undefined);
        get exact(): string;
    }
    class SpecHttp2RouteMatchQueryParameterMatchPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecHttp2RouteMatchQueryParameterMatchPropertyOutputReference;
    }
    interface SpecHttp2RouteMatchQueryParameterProperty {
    }
    class SpecHttp2RouteMatchQueryParameterPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecHttp2RouteMatchQueryParameterProperty | undefined;
        set internalValue(value: SpecHttp2RouteMatchQueryParameterProperty | undefined);
        private _match;
        get match(): SpecHttp2RouteMatchQueryParameterMatchPropertyList;
        get name(): string;
    }
    class SpecHttp2RouteMatchQueryParameterPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecHttp2RouteMatchQueryParameterPropertyOutputReference;
    }
    interface SpecHttp2RouteMatchProperty {
    }
    class SpecHttp2RouteMatchPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecHttp2RouteMatchProperty | undefined;
        set internalValue(value: SpecHttp2RouteMatchProperty | undefined);
        private _header;
        get header(): SpecHttp2RouteMatchHeaderPropertyList;
        private _hostname;
        get hostname(): SpecHttp2RouteMatchHostnamePropertyList;
        private _path;
        get path(): SpecHttp2RouteMatchPathPropertyList;
        get port(): number;
        get prefix(): string;
        private _queryParameter;
        get queryParameter(): SpecHttp2RouteMatchQueryParameterPropertyList;
    }
    class SpecHttp2RouteMatchPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecHttp2RouteMatchPropertyOutputReference;
    }
    interface Http2RouteProperty {
    }
    class Http2RoutePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): Http2RouteProperty | undefined;
        set internalValue(value: Http2RouteProperty | undefined);
        private _action;
        get action(): SpecHttp2RouteActionPropertyList;
        private _match;
        get match(): SpecHttp2RouteMatchPropertyList;
    }
    class Http2RoutePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): Http2RoutePropertyOutputReference;
    }
    interface SpecHttpRouteActionRewriteHostnameProperty {
    }
    class SpecHttpRouteActionRewriteHostnamePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecHttpRouteActionRewriteHostnameProperty | undefined;
        set internalValue(value: SpecHttpRouteActionRewriteHostnameProperty | undefined);
        get defaultTargetHostname(): string;
    }
    class SpecHttpRouteActionRewriteHostnamePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecHttpRouteActionRewriteHostnamePropertyOutputReference;
    }
    interface SpecHttpRouteActionRewritePathProperty {
    }
    class SpecHttpRouteActionRewritePathPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecHttpRouteActionRewritePathProperty | undefined;
        set internalValue(value: SpecHttpRouteActionRewritePathProperty | undefined);
        get exact(): string;
    }
    class SpecHttpRouteActionRewritePathPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecHttpRouteActionRewritePathPropertyOutputReference;
    }
    interface SpecHttpRouteActionRewritePrefixProperty {
    }
    class SpecHttpRouteActionRewritePrefixPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecHttpRouteActionRewritePrefixProperty | undefined;
        set internalValue(value: SpecHttpRouteActionRewritePrefixProperty | undefined);
        get defaultPrefix(): string;
        get value(): string;
    }
    class SpecHttpRouteActionRewritePrefixPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecHttpRouteActionRewritePrefixPropertyOutputReference;
    }
    interface SpecHttpRouteActionRewriteProperty {
    }
    class SpecHttpRouteActionRewritePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecHttpRouteActionRewriteProperty | undefined;
        set internalValue(value: SpecHttpRouteActionRewriteProperty | undefined);
        private _hostname;
        get hostname(): SpecHttpRouteActionRewriteHostnamePropertyList;
        private _path;
        get path(): SpecHttpRouteActionRewritePathPropertyList;
        private _prefix;
        get prefix(): SpecHttpRouteActionRewritePrefixPropertyList;
    }
    class SpecHttpRouteActionRewritePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecHttpRouteActionRewritePropertyOutputReference;
    }
    interface SpecHttpRouteActionTargetVirtualServiceProperty {
    }
    class SpecHttpRouteActionTargetVirtualServicePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecHttpRouteActionTargetVirtualServiceProperty | undefined;
        set internalValue(value: SpecHttpRouteActionTargetVirtualServiceProperty | undefined);
        get virtualServiceName(): string;
    }
    class SpecHttpRouteActionTargetVirtualServicePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecHttpRouteActionTargetVirtualServicePropertyOutputReference;
    }
    interface SpecHttpRouteActionTargetProperty {
    }
    class SpecHttpRouteActionTargetPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecHttpRouteActionTargetProperty | undefined;
        set internalValue(value: SpecHttpRouteActionTargetProperty | undefined);
        get port(): number;
        private _virtualService;
        get virtualService(): SpecHttpRouteActionTargetVirtualServicePropertyList;
    }
    class SpecHttpRouteActionTargetPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecHttpRouteActionTargetPropertyOutputReference;
    }
    interface SpecHttpRouteActionProperty {
    }
    class SpecHttpRouteActionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecHttpRouteActionProperty | undefined;
        set internalValue(value: SpecHttpRouteActionProperty | undefined);
        private _rewrite;
        get rewrite(): SpecHttpRouteActionRewritePropertyList;
        private _target;
        get target(): SpecHttpRouteActionTargetPropertyList;
    }
    class SpecHttpRouteActionPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecHttpRouteActionPropertyOutputReference;
    }
    interface SpecHttpRouteMatchHeaderMatchRangeProperty {
    }
    class SpecHttpRouteMatchHeaderMatchRangePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecHttpRouteMatchHeaderMatchRangeProperty | undefined;
        set internalValue(value: SpecHttpRouteMatchHeaderMatchRangeProperty | undefined);
        get end(): number;
        get start(): number;
    }
    class SpecHttpRouteMatchHeaderMatchRangePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecHttpRouteMatchHeaderMatchRangePropertyOutputReference;
    }
    interface SpecHttpRouteMatchHeaderMatchProperty {
    }
    class SpecHttpRouteMatchHeaderMatchPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecHttpRouteMatchHeaderMatchProperty | undefined;
        set internalValue(value: SpecHttpRouteMatchHeaderMatchProperty | undefined);
        get exact(): string;
        get prefix(): string;
        private _range;
        get range(): SpecHttpRouteMatchHeaderMatchRangePropertyList;
        get regex(): string;
        get suffix(): string;
    }
    class SpecHttpRouteMatchHeaderMatchPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecHttpRouteMatchHeaderMatchPropertyOutputReference;
    }
    interface SpecHttpRouteMatchHeaderProperty {
    }
    class SpecHttpRouteMatchHeaderPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecHttpRouteMatchHeaderProperty | undefined;
        set internalValue(value: SpecHttpRouteMatchHeaderProperty | undefined);
        get invert(): cdktn.IResolvable;
        private _match;
        get match(): SpecHttpRouteMatchHeaderMatchPropertyList;
        get name(): string;
    }
    class SpecHttpRouteMatchHeaderPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecHttpRouteMatchHeaderPropertyOutputReference;
    }
    interface SpecHttpRouteMatchHostnameProperty {
    }
    class SpecHttpRouteMatchHostnamePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecHttpRouteMatchHostnameProperty | undefined;
        set internalValue(value: SpecHttpRouteMatchHostnameProperty | undefined);
        get exact(): string;
        get suffix(): string;
    }
    class SpecHttpRouteMatchHostnamePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecHttpRouteMatchHostnamePropertyOutputReference;
    }
    interface SpecHttpRouteMatchPathProperty {
    }
    class SpecHttpRouteMatchPathPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecHttpRouteMatchPathProperty | undefined;
        set internalValue(value: SpecHttpRouteMatchPathProperty | undefined);
        get exact(): string;
        get regex(): string;
    }
    class SpecHttpRouteMatchPathPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecHttpRouteMatchPathPropertyOutputReference;
    }
    interface SpecHttpRouteMatchQueryParameterMatchProperty {
    }
    class SpecHttpRouteMatchQueryParameterMatchPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecHttpRouteMatchQueryParameterMatchProperty | undefined;
        set internalValue(value: SpecHttpRouteMatchQueryParameterMatchProperty | undefined);
        get exact(): string;
    }
    class SpecHttpRouteMatchQueryParameterMatchPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecHttpRouteMatchQueryParameterMatchPropertyOutputReference;
    }
    interface SpecHttpRouteMatchQueryParameterProperty {
    }
    class SpecHttpRouteMatchQueryParameterPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecHttpRouteMatchQueryParameterProperty | undefined;
        set internalValue(value: SpecHttpRouteMatchQueryParameterProperty | undefined);
        private _match;
        get match(): SpecHttpRouteMatchQueryParameterMatchPropertyList;
        get name(): string;
    }
    class SpecHttpRouteMatchQueryParameterPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecHttpRouteMatchQueryParameterPropertyOutputReference;
    }
    interface SpecHttpRouteMatchProperty {
    }
    class SpecHttpRouteMatchPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecHttpRouteMatchProperty | undefined;
        set internalValue(value: SpecHttpRouteMatchProperty | undefined);
        private _header;
        get header(): SpecHttpRouteMatchHeaderPropertyList;
        private _hostname;
        get hostname(): SpecHttpRouteMatchHostnamePropertyList;
        private _path;
        get path(): SpecHttpRouteMatchPathPropertyList;
        get port(): number;
        get prefix(): string;
        private _queryParameter;
        get queryParameter(): SpecHttpRouteMatchQueryParameterPropertyList;
    }
    class SpecHttpRouteMatchPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecHttpRouteMatchPropertyOutputReference;
    }
    interface HttpRouteProperty {
    }
    class HttpRoutePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): HttpRouteProperty | undefined;
        set internalValue(value: HttpRouteProperty | undefined);
        private _action;
        get action(): SpecHttpRouteActionPropertyList;
        private _match;
        get match(): SpecHttpRouteMatchPropertyList;
    }
    class HttpRoutePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): HttpRoutePropertyOutputReference;
    }
    interface SpecProperty {
    }
    class SpecPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecProperty | undefined;
        set internalValue(value: SpecProperty | undefined);
        private _grpcRoute;
        get grpcRoute(): GrpcRoutePropertyList;
        private _http2Route;
        get http2Route(): Http2RoutePropertyList;
        private _httpRoute;
        get httpRoute(): HttpRoutePropertyList;
        get priority(): number;
    }
    class SpecPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecPropertyOutputReference;
    }
}
