import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsVirtualNodeConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#id AwsVirtualNode#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#mesh_name AwsVirtualNode#mesh_name}
    */
    readonly meshName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#mesh_owner AwsVirtualNode#mesh_owner}
    */
    readonly meshOwner?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#name AwsVirtualNode#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#region AwsVirtualNode#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#tags AwsVirtualNode#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#tags_all AwsVirtualNode#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * spec block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#spec AwsVirtualNode#spec}
    */
    readonly spec: AwsVirtualNode.SpecProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node aws_appmesh_virtual_node}
*/
export declare class AwsVirtualNode extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_appmesh_virtual_node";
    /**
    * Generates CDKTN code for importing a AwsVirtualNode resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsVirtualNode to import
    * @param importFromId The id of the existing AwsVirtualNode that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsVirtualNode to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node aws_appmesh_virtual_node} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsVirtualNodeConfig
    */
    constructor(scope: Construct, id: string, config: AwsVirtualNodeConfig);
    get arn(): string;
    get createdDate(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get lastUpdatedDate(): string;
    private _meshName?;
    get meshName(): string;
    set meshName(value: string);
    get meshNameInput(): string | undefined;
    private _meshOwner?;
    get meshOwner(): string;
    set meshOwner(value: string);
    resetMeshOwner(): void;
    get meshOwnerInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get resourceOwner(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _spec;
    get spec(): AwsVirtualNode.SpecPropertyOutputReference;
    putSpec(value: AwsVirtualNode.SpecProperty): void;
    get specInput(): AwsVirtualNode.SpecProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsVirtualNodeSpecBackendVirtualServiceClientPolicyTlsCertificateFilePropertyToTerraform(struct?: AwsVirtualNode.SpecBackendVirtualServiceClientPolicyTlsCertificateFilePropertyOutputReference | AwsVirtualNode.SpecBackendVirtualServiceClientPolicyTlsCertificateFileProperty): any;
export declare function awsVirtualNodeSpecBackendVirtualServiceClientPolicyTlsCertificateFilePropertyToHclTerraform(struct?: AwsVirtualNode.SpecBackendVirtualServiceClientPolicyTlsCertificateFilePropertyOutputReference | AwsVirtualNode.SpecBackendVirtualServiceClientPolicyTlsCertificateFileProperty): any;
export declare function awsVirtualNodeSpecBackendVirtualServiceClientPolicyTlsCertificateSdsPropertyToTerraform(struct?: AwsVirtualNode.SpecBackendVirtualServiceClientPolicyTlsCertificateSdsPropertyOutputReference | AwsVirtualNode.SpecBackendVirtualServiceClientPolicyTlsCertificateSdsProperty): any;
export declare function awsVirtualNodeSpecBackendVirtualServiceClientPolicyTlsCertificateSdsPropertyToHclTerraform(struct?: AwsVirtualNode.SpecBackendVirtualServiceClientPolicyTlsCertificateSdsPropertyOutputReference | AwsVirtualNode.SpecBackendVirtualServiceClientPolicyTlsCertificateSdsProperty): any;
export declare function awsVirtualNodeSpecBackendVirtualServiceClientPolicyTlsCertificatePropertyToTerraform(struct?: AwsVirtualNode.SpecBackendVirtualServiceClientPolicyTlsCertificatePropertyOutputReference | AwsVirtualNode.SpecBackendVirtualServiceClientPolicyTlsCertificateProperty): any;
export declare function awsVirtualNodeSpecBackendVirtualServiceClientPolicyTlsCertificatePropertyToHclTerraform(struct?: AwsVirtualNode.SpecBackendVirtualServiceClientPolicyTlsCertificatePropertyOutputReference | AwsVirtualNode.SpecBackendVirtualServiceClientPolicyTlsCertificateProperty): any;
export declare function awsVirtualNodeSpecBackendVirtualServiceClientPolicyTlsValidationSubjectAlternativeNamesMatchPropertyToTerraform(struct?: AwsVirtualNode.SpecBackendVirtualServiceClientPolicyTlsValidationSubjectAlternativeNamesMatchPropertyOutputReference | AwsVirtualNode.SpecBackendVirtualServiceClientPolicyTlsValidationSubjectAlternativeNamesMatchProperty): any;
export declare function awsVirtualNodeSpecBackendVirtualServiceClientPolicyTlsValidationSubjectAlternativeNamesMatchPropertyToHclTerraform(struct?: AwsVirtualNode.SpecBackendVirtualServiceClientPolicyTlsValidationSubjectAlternativeNamesMatchPropertyOutputReference | AwsVirtualNode.SpecBackendVirtualServiceClientPolicyTlsValidationSubjectAlternativeNamesMatchProperty): any;
export declare function awsVirtualNodeSpecBackendVirtualServiceClientPolicyTlsValidationSubjectAlternativeNamesPropertyToTerraform(struct?: AwsVirtualNode.SpecBackendVirtualServiceClientPolicyTlsValidationSubjectAlternativeNamesPropertyOutputReference | AwsVirtualNode.SpecBackendVirtualServiceClientPolicyTlsValidationSubjectAlternativeNamesProperty): any;
export declare function awsVirtualNodeSpecBackendVirtualServiceClientPolicyTlsValidationSubjectAlternativeNamesPropertyToHclTerraform(struct?: AwsVirtualNode.SpecBackendVirtualServiceClientPolicyTlsValidationSubjectAlternativeNamesPropertyOutputReference | AwsVirtualNode.SpecBackendVirtualServiceClientPolicyTlsValidationSubjectAlternativeNamesProperty): any;
export declare function awsVirtualNodeSpecBackendVirtualServiceClientPolicyTlsValidationTrustAcmPropertyToTerraform(struct?: AwsVirtualNode.SpecBackendVirtualServiceClientPolicyTlsValidationTrustAcmPropertyOutputReference | AwsVirtualNode.SpecBackendVirtualServiceClientPolicyTlsValidationTrustAcmProperty): any;
export declare function awsVirtualNodeSpecBackendVirtualServiceClientPolicyTlsValidationTrustAcmPropertyToHclTerraform(struct?: AwsVirtualNode.SpecBackendVirtualServiceClientPolicyTlsValidationTrustAcmPropertyOutputReference | AwsVirtualNode.SpecBackendVirtualServiceClientPolicyTlsValidationTrustAcmProperty): any;
export declare function awsVirtualNodeSpecBackendVirtualServiceClientPolicyTlsValidationTrustFilePropertyToTerraform(struct?: AwsVirtualNode.SpecBackendVirtualServiceClientPolicyTlsValidationTrustFilePropertyOutputReference | AwsVirtualNode.SpecBackendVirtualServiceClientPolicyTlsValidationTrustFileProperty): any;
export declare function awsVirtualNodeSpecBackendVirtualServiceClientPolicyTlsValidationTrustFilePropertyToHclTerraform(struct?: AwsVirtualNode.SpecBackendVirtualServiceClientPolicyTlsValidationTrustFilePropertyOutputReference | AwsVirtualNode.SpecBackendVirtualServiceClientPolicyTlsValidationTrustFileProperty): any;
export declare function awsVirtualNodeSpecBackendVirtualServiceClientPolicyTlsValidationTrustSdsPropertyToTerraform(struct?: AwsVirtualNode.SpecBackendVirtualServiceClientPolicyTlsValidationTrustSdsPropertyOutputReference | AwsVirtualNode.SpecBackendVirtualServiceClientPolicyTlsValidationTrustSdsProperty): any;
export declare function awsVirtualNodeSpecBackendVirtualServiceClientPolicyTlsValidationTrustSdsPropertyToHclTerraform(struct?: AwsVirtualNode.SpecBackendVirtualServiceClientPolicyTlsValidationTrustSdsPropertyOutputReference | AwsVirtualNode.SpecBackendVirtualServiceClientPolicyTlsValidationTrustSdsProperty): any;
export declare function awsVirtualNodeSpecBackendVirtualServiceClientPolicyTlsValidationTrustPropertyToTerraform(struct?: AwsVirtualNode.SpecBackendVirtualServiceClientPolicyTlsValidationTrustPropertyOutputReference | AwsVirtualNode.SpecBackendVirtualServiceClientPolicyTlsValidationTrustProperty): any;
export declare function awsVirtualNodeSpecBackendVirtualServiceClientPolicyTlsValidationTrustPropertyToHclTerraform(struct?: AwsVirtualNode.SpecBackendVirtualServiceClientPolicyTlsValidationTrustPropertyOutputReference | AwsVirtualNode.SpecBackendVirtualServiceClientPolicyTlsValidationTrustProperty): any;
export declare function awsVirtualNodeSpecBackendVirtualServiceClientPolicyTlsValidationPropertyToTerraform(struct?: AwsVirtualNode.SpecBackendVirtualServiceClientPolicyTlsValidationPropertyOutputReference | AwsVirtualNode.SpecBackendVirtualServiceClientPolicyTlsValidationProperty): any;
export declare function awsVirtualNodeSpecBackendVirtualServiceClientPolicyTlsValidationPropertyToHclTerraform(struct?: AwsVirtualNode.SpecBackendVirtualServiceClientPolicyTlsValidationPropertyOutputReference | AwsVirtualNode.SpecBackendVirtualServiceClientPolicyTlsValidationProperty): any;
export declare function awsVirtualNodeSpecBackendVirtualServiceClientPolicyTlsPropertyToTerraform(struct?: AwsVirtualNode.SpecBackendVirtualServiceClientPolicyTlsPropertyOutputReference | AwsVirtualNode.SpecBackendVirtualServiceClientPolicyTlsProperty): any;
export declare function awsVirtualNodeSpecBackendVirtualServiceClientPolicyTlsPropertyToHclTerraform(struct?: AwsVirtualNode.SpecBackendVirtualServiceClientPolicyTlsPropertyOutputReference | AwsVirtualNode.SpecBackendVirtualServiceClientPolicyTlsProperty): any;
export declare function awsVirtualNodeSpecBackendVirtualServiceClientPolicyPropertyToTerraform(struct?: AwsVirtualNode.SpecBackendVirtualServiceClientPolicyPropertyOutputReference | AwsVirtualNode.SpecBackendVirtualServiceClientPolicyProperty): any;
export declare function awsVirtualNodeSpecBackendVirtualServiceClientPolicyPropertyToHclTerraform(struct?: AwsVirtualNode.SpecBackendVirtualServiceClientPolicyPropertyOutputReference | AwsVirtualNode.SpecBackendVirtualServiceClientPolicyProperty): any;
export declare function awsVirtualNodeVirtualServicePropertyToTerraform(struct?: AwsVirtualNode.VirtualServicePropertyOutputReference | AwsVirtualNode.VirtualServiceProperty): any;
export declare function awsVirtualNodeVirtualServicePropertyToHclTerraform(struct?: AwsVirtualNode.VirtualServicePropertyOutputReference | AwsVirtualNode.VirtualServiceProperty): any;
export declare function awsVirtualNodeBackendPropertyToTerraform(struct?: AwsVirtualNode.BackendProperty | cdktn.IResolvable): any;
export declare function awsVirtualNodeBackendPropertyToHclTerraform(struct?: AwsVirtualNode.BackendProperty | cdktn.IResolvable): any;
export declare function awsVirtualNodeSpecBackendDefaultsClientPolicyTlsCertificateFilePropertyToTerraform(struct?: AwsVirtualNode.SpecBackendDefaultsClientPolicyTlsCertificateFilePropertyOutputReference | AwsVirtualNode.SpecBackendDefaultsClientPolicyTlsCertificateFileProperty): any;
export declare function awsVirtualNodeSpecBackendDefaultsClientPolicyTlsCertificateFilePropertyToHclTerraform(struct?: AwsVirtualNode.SpecBackendDefaultsClientPolicyTlsCertificateFilePropertyOutputReference | AwsVirtualNode.SpecBackendDefaultsClientPolicyTlsCertificateFileProperty): any;
export declare function awsVirtualNodeSpecBackendDefaultsClientPolicyTlsCertificateSdsPropertyToTerraform(struct?: AwsVirtualNode.SpecBackendDefaultsClientPolicyTlsCertificateSdsPropertyOutputReference | AwsVirtualNode.SpecBackendDefaultsClientPolicyTlsCertificateSdsProperty): any;
export declare function awsVirtualNodeSpecBackendDefaultsClientPolicyTlsCertificateSdsPropertyToHclTerraform(struct?: AwsVirtualNode.SpecBackendDefaultsClientPolicyTlsCertificateSdsPropertyOutputReference | AwsVirtualNode.SpecBackendDefaultsClientPolicyTlsCertificateSdsProperty): any;
export declare function awsVirtualNodeSpecBackendDefaultsClientPolicyTlsCertificatePropertyToTerraform(struct?: AwsVirtualNode.SpecBackendDefaultsClientPolicyTlsCertificatePropertyOutputReference | AwsVirtualNode.SpecBackendDefaultsClientPolicyTlsCertificateProperty): any;
export declare function awsVirtualNodeSpecBackendDefaultsClientPolicyTlsCertificatePropertyToHclTerraform(struct?: AwsVirtualNode.SpecBackendDefaultsClientPolicyTlsCertificatePropertyOutputReference | AwsVirtualNode.SpecBackendDefaultsClientPolicyTlsCertificateProperty): any;
export declare function awsVirtualNodeSpecBackendDefaultsClientPolicyTlsValidationSubjectAlternativeNamesMatchPropertyToTerraform(struct?: AwsVirtualNode.SpecBackendDefaultsClientPolicyTlsValidationSubjectAlternativeNamesMatchPropertyOutputReference | AwsVirtualNode.SpecBackendDefaultsClientPolicyTlsValidationSubjectAlternativeNamesMatchProperty): any;
export declare function awsVirtualNodeSpecBackendDefaultsClientPolicyTlsValidationSubjectAlternativeNamesMatchPropertyToHclTerraform(struct?: AwsVirtualNode.SpecBackendDefaultsClientPolicyTlsValidationSubjectAlternativeNamesMatchPropertyOutputReference | AwsVirtualNode.SpecBackendDefaultsClientPolicyTlsValidationSubjectAlternativeNamesMatchProperty): any;
export declare function awsVirtualNodeSpecBackendDefaultsClientPolicyTlsValidationSubjectAlternativeNamesPropertyToTerraform(struct?: AwsVirtualNode.SpecBackendDefaultsClientPolicyTlsValidationSubjectAlternativeNamesPropertyOutputReference | AwsVirtualNode.SpecBackendDefaultsClientPolicyTlsValidationSubjectAlternativeNamesProperty): any;
export declare function awsVirtualNodeSpecBackendDefaultsClientPolicyTlsValidationSubjectAlternativeNamesPropertyToHclTerraform(struct?: AwsVirtualNode.SpecBackendDefaultsClientPolicyTlsValidationSubjectAlternativeNamesPropertyOutputReference | AwsVirtualNode.SpecBackendDefaultsClientPolicyTlsValidationSubjectAlternativeNamesProperty): any;
export declare function awsVirtualNodeSpecBackendDefaultsClientPolicyTlsValidationTrustAcmPropertyToTerraform(struct?: AwsVirtualNode.SpecBackendDefaultsClientPolicyTlsValidationTrustAcmPropertyOutputReference | AwsVirtualNode.SpecBackendDefaultsClientPolicyTlsValidationTrustAcmProperty): any;
export declare function awsVirtualNodeSpecBackendDefaultsClientPolicyTlsValidationTrustAcmPropertyToHclTerraform(struct?: AwsVirtualNode.SpecBackendDefaultsClientPolicyTlsValidationTrustAcmPropertyOutputReference | AwsVirtualNode.SpecBackendDefaultsClientPolicyTlsValidationTrustAcmProperty): any;
export declare function awsVirtualNodeSpecBackendDefaultsClientPolicyTlsValidationTrustFilePropertyToTerraform(struct?: AwsVirtualNode.SpecBackendDefaultsClientPolicyTlsValidationTrustFilePropertyOutputReference | AwsVirtualNode.SpecBackendDefaultsClientPolicyTlsValidationTrustFileProperty): any;
export declare function awsVirtualNodeSpecBackendDefaultsClientPolicyTlsValidationTrustFilePropertyToHclTerraform(struct?: AwsVirtualNode.SpecBackendDefaultsClientPolicyTlsValidationTrustFilePropertyOutputReference | AwsVirtualNode.SpecBackendDefaultsClientPolicyTlsValidationTrustFileProperty): any;
export declare function awsVirtualNodeSpecBackendDefaultsClientPolicyTlsValidationTrustSdsPropertyToTerraform(struct?: AwsVirtualNode.SpecBackendDefaultsClientPolicyTlsValidationTrustSdsPropertyOutputReference | AwsVirtualNode.SpecBackendDefaultsClientPolicyTlsValidationTrustSdsProperty): any;
export declare function awsVirtualNodeSpecBackendDefaultsClientPolicyTlsValidationTrustSdsPropertyToHclTerraform(struct?: AwsVirtualNode.SpecBackendDefaultsClientPolicyTlsValidationTrustSdsPropertyOutputReference | AwsVirtualNode.SpecBackendDefaultsClientPolicyTlsValidationTrustSdsProperty): any;
export declare function awsVirtualNodeSpecBackendDefaultsClientPolicyTlsValidationTrustPropertyToTerraform(struct?: AwsVirtualNode.SpecBackendDefaultsClientPolicyTlsValidationTrustPropertyOutputReference | AwsVirtualNode.SpecBackendDefaultsClientPolicyTlsValidationTrustProperty): any;
export declare function awsVirtualNodeSpecBackendDefaultsClientPolicyTlsValidationTrustPropertyToHclTerraform(struct?: AwsVirtualNode.SpecBackendDefaultsClientPolicyTlsValidationTrustPropertyOutputReference | AwsVirtualNode.SpecBackendDefaultsClientPolicyTlsValidationTrustProperty): any;
export declare function awsVirtualNodeSpecBackendDefaultsClientPolicyTlsValidationPropertyToTerraform(struct?: AwsVirtualNode.SpecBackendDefaultsClientPolicyTlsValidationPropertyOutputReference | AwsVirtualNode.SpecBackendDefaultsClientPolicyTlsValidationProperty): any;
export declare function awsVirtualNodeSpecBackendDefaultsClientPolicyTlsValidationPropertyToHclTerraform(struct?: AwsVirtualNode.SpecBackendDefaultsClientPolicyTlsValidationPropertyOutputReference | AwsVirtualNode.SpecBackendDefaultsClientPolicyTlsValidationProperty): any;
export declare function awsVirtualNodeSpecBackendDefaultsClientPolicyTlsPropertyToTerraform(struct?: AwsVirtualNode.SpecBackendDefaultsClientPolicyTlsPropertyOutputReference | AwsVirtualNode.SpecBackendDefaultsClientPolicyTlsProperty): any;
export declare function awsVirtualNodeSpecBackendDefaultsClientPolicyTlsPropertyToHclTerraform(struct?: AwsVirtualNode.SpecBackendDefaultsClientPolicyTlsPropertyOutputReference | AwsVirtualNode.SpecBackendDefaultsClientPolicyTlsProperty): any;
export declare function awsVirtualNodeSpecBackendDefaultsClientPolicyPropertyToTerraform(struct?: AwsVirtualNode.SpecBackendDefaultsClientPolicyPropertyOutputReference | AwsVirtualNode.SpecBackendDefaultsClientPolicyProperty): any;
export declare function awsVirtualNodeSpecBackendDefaultsClientPolicyPropertyToHclTerraform(struct?: AwsVirtualNode.SpecBackendDefaultsClientPolicyPropertyOutputReference | AwsVirtualNode.SpecBackendDefaultsClientPolicyProperty): any;
export declare function awsVirtualNodeBackendDefaultsPropertyToTerraform(struct?: AwsVirtualNode.BackendDefaultsPropertyOutputReference | AwsVirtualNode.BackendDefaultsProperty): any;
export declare function awsVirtualNodeBackendDefaultsPropertyToHclTerraform(struct?: AwsVirtualNode.BackendDefaultsPropertyOutputReference | AwsVirtualNode.BackendDefaultsProperty): any;
export declare function awsVirtualNodeSpecListenerConnectionPoolGrpcPropertyToTerraform(struct?: AwsVirtualNode.SpecListenerConnectionPoolGrpcPropertyOutputReference | AwsVirtualNode.SpecListenerConnectionPoolGrpcProperty): any;
export declare function awsVirtualNodeSpecListenerConnectionPoolGrpcPropertyToHclTerraform(struct?: AwsVirtualNode.SpecListenerConnectionPoolGrpcPropertyOutputReference | AwsVirtualNode.SpecListenerConnectionPoolGrpcProperty): any;
export declare function awsVirtualNodeSpecListenerConnectionPoolHttpPropertyToTerraform(struct?: AwsVirtualNode.SpecListenerConnectionPoolHttpProperty | cdktn.IResolvable): any;
export declare function awsVirtualNodeSpecListenerConnectionPoolHttpPropertyToHclTerraform(struct?: AwsVirtualNode.SpecListenerConnectionPoolHttpProperty | cdktn.IResolvable): any;
export declare function awsVirtualNodeSpecListenerConnectionPoolHttp2PropertyToTerraform(struct?: AwsVirtualNode.SpecListenerConnectionPoolHttp2Property | cdktn.IResolvable): any;
export declare function awsVirtualNodeSpecListenerConnectionPoolHttp2PropertyToHclTerraform(struct?: AwsVirtualNode.SpecListenerConnectionPoolHttp2Property | cdktn.IResolvable): any;
export declare function awsVirtualNodeSpecListenerConnectionPoolTcpPropertyToTerraform(struct?: AwsVirtualNode.SpecListenerConnectionPoolTcpProperty | cdktn.IResolvable): any;
export declare function awsVirtualNodeSpecListenerConnectionPoolTcpPropertyToHclTerraform(struct?: AwsVirtualNode.SpecListenerConnectionPoolTcpProperty | cdktn.IResolvable): any;
export declare function awsVirtualNodeConnectionPoolPropertyToTerraform(struct?: AwsVirtualNode.ConnectionPoolPropertyOutputReference | AwsVirtualNode.ConnectionPoolProperty): any;
export declare function awsVirtualNodeConnectionPoolPropertyToHclTerraform(struct?: AwsVirtualNode.ConnectionPoolPropertyOutputReference | AwsVirtualNode.ConnectionPoolProperty): any;
export declare function awsVirtualNodeHealthCheckPropertyToTerraform(struct?: AwsVirtualNode.HealthCheckPropertyOutputReference | AwsVirtualNode.HealthCheckProperty): any;
export declare function awsVirtualNodeHealthCheckPropertyToHclTerraform(struct?: AwsVirtualNode.HealthCheckPropertyOutputReference | AwsVirtualNode.HealthCheckProperty): any;
export declare function awsVirtualNodeBaseEjectionDurationPropertyToTerraform(struct?: AwsVirtualNode.BaseEjectionDurationPropertyOutputReference | AwsVirtualNode.BaseEjectionDurationProperty): any;
export declare function awsVirtualNodeBaseEjectionDurationPropertyToHclTerraform(struct?: AwsVirtualNode.BaseEjectionDurationPropertyOutputReference | AwsVirtualNode.BaseEjectionDurationProperty): any;
export declare function awsVirtualNodeIntervalPropertyToTerraform(struct?: AwsVirtualNode.IntervalPropertyOutputReference | AwsVirtualNode.IntervalProperty): any;
export declare function awsVirtualNodeIntervalPropertyToHclTerraform(struct?: AwsVirtualNode.IntervalPropertyOutputReference | AwsVirtualNode.IntervalProperty): any;
export declare function awsVirtualNodeOutlierDetectionPropertyToTerraform(struct?: AwsVirtualNode.OutlierDetectionPropertyOutputReference | AwsVirtualNode.OutlierDetectionProperty): any;
export declare function awsVirtualNodeOutlierDetectionPropertyToHclTerraform(struct?: AwsVirtualNode.OutlierDetectionPropertyOutputReference | AwsVirtualNode.OutlierDetectionProperty): any;
export declare function awsVirtualNodePortMappingPropertyToTerraform(struct?: AwsVirtualNode.PortMappingPropertyOutputReference | AwsVirtualNode.PortMappingProperty): any;
export declare function awsVirtualNodePortMappingPropertyToHclTerraform(struct?: AwsVirtualNode.PortMappingPropertyOutputReference | AwsVirtualNode.PortMappingProperty): any;
export declare function awsVirtualNodeSpecListenerTimeoutGrpcIdlePropertyToTerraform(struct?: AwsVirtualNode.SpecListenerTimeoutGrpcIdlePropertyOutputReference | AwsVirtualNode.SpecListenerTimeoutGrpcIdleProperty): any;
export declare function awsVirtualNodeSpecListenerTimeoutGrpcIdlePropertyToHclTerraform(struct?: AwsVirtualNode.SpecListenerTimeoutGrpcIdlePropertyOutputReference | AwsVirtualNode.SpecListenerTimeoutGrpcIdleProperty): any;
export declare function awsVirtualNodeSpecListenerTimeoutGrpcPerRequestPropertyToTerraform(struct?: AwsVirtualNode.SpecListenerTimeoutGrpcPerRequestPropertyOutputReference | AwsVirtualNode.SpecListenerTimeoutGrpcPerRequestProperty): any;
export declare function awsVirtualNodeSpecListenerTimeoutGrpcPerRequestPropertyToHclTerraform(struct?: AwsVirtualNode.SpecListenerTimeoutGrpcPerRequestPropertyOutputReference | AwsVirtualNode.SpecListenerTimeoutGrpcPerRequestProperty): any;
export declare function awsVirtualNodeSpecListenerTimeoutGrpcPropertyToTerraform(struct?: AwsVirtualNode.SpecListenerTimeoutGrpcPropertyOutputReference | AwsVirtualNode.SpecListenerTimeoutGrpcProperty): any;
export declare function awsVirtualNodeSpecListenerTimeoutGrpcPropertyToHclTerraform(struct?: AwsVirtualNode.SpecListenerTimeoutGrpcPropertyOutputReference | AwsVirtualNode.SpecListenerTimeoutGrpcProperty): any;
export declare function awsVirtualNodeSpecListenerTimeoutHttpIdlePropertyToTerraform(struct?: AwsVirtualNode.SpecListenerTimeoutHttpIdlePropertyOutputReference | AwsVirtualNode.SpecListenerTimeoutHttpIdleProperty): any;
export declare function awsVirtualNodeSpecListenerTimeoutHttpIdlePropertyToHclTerraform(struct?: AwsVirtualNode.SpecListenerTimeoutHttpIdlePropertyOutputReference | AwsVirtualNode.SpecListenerTimeoutHttpIdleProperty): any;
export declare function awsVirtualNodeSpecListenerTimeoutHttpPerRequestPropertyToTerraform(struct?: AwsVirtualNode.SpecListenerTimeoutHttpPerRequestPropertyOutputReference | AwsVirtualNode.SpecListenerTimeoutHttpPerRequestProperty): any;
export declare function awsVirtualNodeSpecListenerTimeoutHttpPerRequestPropertyToHclTerraform(struct?: AwsVirtualNode.SpecListenerTimeoutHttpPerRequestPropertyOutputReference | AwsVirtualNode.SpecListenerTimeoutHttpPerRequestProperty): any;
export declare function awsVirtualNodeSpecListenerTimeoutHttpPropertyToTerraform(struct?: AwsVirtualNode.SpecListenerTimeoutHttpPropertyOutputReference | AwsVirtualNode.SpecListenerTimeoutHttpProperty): any;
export declare function awsVirtualNodeSpecListenerTimeoutHttpPropertyToHclTerraform(struct?: AwsVirtualNode.SpecListenerTimeoutHttpPropertyOutputReference | AwsVirtualNode.SpecListenerTimeoutHttpProperty): any;
export declare function awsVirtualNodeSpecListenerTimeoutHttp2IdlePropertyToTerraform(struct?: AwsVirtualNode.SpecListenerTimeoutHttp2IdlePropertyOutputReference | AwsVirtualNode.SpecListenerTimeoutHttp2IdleProperty): any;
export declare function awsVirtualNodeSpecListenerTimeoutHttp2IdlePropertyToHclTerraform(struct?: AwsVirtualNode.SpecListenerTimeoutHttp2IdlePropertyOutputReference | AwsVirtualNode.SpecListenerTimeoutHttp2IdleProperty): any;
export declare function awsVirtualNodeSpecListenerTimeoutHttp2PerRequestPropertyToTerraform(struct?: AwsVirtualNode.SpecListenerTimeoutHttp2PerRequestPropertyOutputReference | AwsVirtualNode.SpecListenerTimeoutHttp2PerRequestProperty): any;
export declare function awsVirtualNodeSpecListenerTimeoutHttp2PerRequestPropertyToHclTerraform(struct?: AwsVirtualNode.SpecListenerTimeoutHttp2PerRequestPropertyOutputReference | AwsVirtualNode.SpecListenerTimeoutHttp2PerRequestProperty): any;
export declare function awsVirtualNodeSpecListenerTimeoutHttp2PropertyToTerraform(struct?: AwsVirtualNode.SpecListenerTimeoutHttp2PropertyOutputReference | AwsVirtualNode.SpecListenerTimeoutHttp2Property): any;
export declare function awsVirtualNodeSpecListenerTimeoutHttp2PropertyToHclTerraform(struct?: AwsVirtualNode.SpecListenerTimeoutHttp2PropertyOutputReference | AwsVirtualNode.SpecListenerTimeoutHttp2Property): any;
export declare function awsVirtualNodeSpecListenerTimeoutTcpIdlePropertyToTerraform(struct?: AwsVirtualNode.SpecListenerTimeoutTcpIdlePropertyOutputReference | AwsVirtualNode.SpecListenerTimeoutTcpIdleProperty): any;
export declare function awsVirtualNodeSpecListenerTimeoutTcpIdlePropertyToHclTerraform(struct?: AwsVirtualNode.SpecListenerTimeoutTcpIdlePropertyOutputReference | AwsVirtualNode.SpecListenerTimeoutTcpIdleProperty): any;
export declare function awsVirtualNodeSpecListenerTimeoutTcpPropertyToTerraform(struct?: AwsVirtualNode.SpecListenerTimeoutTcpPropertyOutputReference | AwsVirtualNode.SpecListenerTimeoutTcpProperty): any;
export declare function awsVirtualNodeSpecListenerTimeoutTcpPropertyToHclTerraform(struct?: AwsVirtualNode.SpecListenerTimeoutTcpPropertyOutputReference | AwsVirtualNode.SpecListenerTimeoutTcpProperty): any;
export declare function awsVirtualNodeTimeoutPropertyToTerraform(struct?: AwsVirtualNode.TimeoutPropertyOutputReference | AwsVirtualNode.TimeoutProperty): any;
export declare function awsVirtualNodeTimeoutPropertyToHclTerraform(struct?: AwsVirtualNode.TimeoutPropertyOutputReference | AwsVirtualNode.TimeoutProperty): any;
export declare function awsVirtualNodeSpecListenerTlsCertificateAcmPropertyToTerraform(struct?: AwsVirtualNode.SpecListenerTlsCertificateAcmPropertyOutputReference | AwsVirtualNode.SpecListenerTlsCertificateAcmProperty): any;
export declare function awsVirtualNodeSpecListenerTlsCertificateAcmPropertyToHclTerraform(struct?: AwsVirtualNode.SpecListenerTlsCertificateAcmPropertyOutputReference | AwsVirtualNode.SpecListenerTlsCertificateAcmProperty): any;
export declare function awsVirtualNodeSpecListenerTlsCertificateFilePropertyToTerraform(struct?: AwsVirtualNode.SpecListenerTlsCertificateFilePropertyOutputReference | AwsVirtualNode.SpecListenerTlsCertificateFileProperty): any;
export declare function awsVirtualNodeSpecListenerTlsCertificateFilePropertyToHclTerraform(struct?: AwsVirtualNode.SpecListenerTlsCertificateFilePropertyOutputReference | AwsVirtualNode.SpecListenerTlsCertificateFileProperty): any;
export declare function awsVirtualNodeSpecListenerTlsCertificateSdsPropertyToTerraform(struct?: AwsVirtualNode.SpecListenerTlsCertificateSdsPropertyOutputReference | AwsVirtualNode.SpecListenerTlsCertificateSdsProperty): any;
export declare function awsVirtualNodeSpecListenerTlsCertificateSdsPropertyToHclTerraform(struct?: AwsVirtualNode.SpecListenerTlsCertificateSdsPropertyOutputReference | AwsVirtualNode.SpecListenerTlsCertificateSdsProperty): any;
export declare function awsVirtualNodeSpecListenerTlsCertificatePropertyToTerraform(struct?: AwsVirtualNode.SpecListenerTlsCertificatePropertyOutputReference | AwsVirtualNode.SpecListenerTlsCertificateProperty): any;
export declare function awsVirtualNodeSpecListenerTlsCertificatePropertyToHclTerraform(struct?: AwsVirtualNode.SpecListenerTlsCertificatePropertyOutputReference | AwsVirtualNode.SpecListenerTlsCertificateProperty): any;
export declare function awsVirtualNodeSpecListenerTlsValidationSubjectAlternativeNamesMatchPropertyToTerraform(struct?: AwsVirtualNode.SpecListenerTlsValidationSubjectAlternativeNamesMatchPropertyOutputReference | AwsVirtualNode.SpecListenerTlsValidationSubjectAlternativeNamesMatchProperty): any;
export declare function awsVirtualNodeSpecListenerTlsValidationSubjectAlternativeNamesMatchPropertyToHclTerraform(struct?: AwsVirtualNode.SpecListenerTlsValidationSubjectAlternativeNamesMatchPropertyOutputReference | AwsVirtualNode.SpecListenerTlsValidationSubjectAlternativeNamesMatchProperty): any;
export declare function awsVirtualNodeSpecListenerTlsValidationSubjectAlternativeNamesPropertyToTerraform(struct?: AwsVirtualNode.SpecListenerTlsValidationSubjectAlternativeNamesPropertyOutputReference | AwsVirtualNode.SpecListenerTlsValidationSubjectAlternativeNamesProperty): any;
export declare function awsVirtualNodeSpecListenerTlsValidationSubjectAlternativeNamesPropertyToHclTerraform(struct?: AwsVirtualNode.SpecListenerTlsValidationSubjectAlternativeNamesPropertyOutputReference | AwsVirtualNode.SpecListenerTlsValidationSubjectAlternativeNamesProperty): any;
export declare function awsVirtualNodeSpecListenerTlsValidationTrustFilePropertyToTerraform(struct?: AwsVirtualNode.SpecListenerTlsValidationTrustFilePropertyOutputReference | AwsVirtualNode.SpecListenerTlsValidationTrustFileProperty): any;
export declare function awsVirtualNodeSpecListenerTlsValidationTrustFilePropertyToHclTerraform(struct?: AwsVirtualNode.SpecListenerTlsValidationTrustFilePropertyOutputReference | AwsVirtualNode.SpecListenerTlsValidationTrustFileProperty): any;
export declare function awsVirtualNodeSpecListenerTlsValidationTrustSdsPropertyToTerraform(struct?: AwsVirtualNode.SpecListenerTlsValidationTrustSdsPropertyOutputReference | AwsVirtualNode.SpecListenerTlsValidationTrustSdsProperty): any;
export declare function awsVirtualNodeSpecListenerTlsValidationTrustSdsPropertyToHclTerraform(struct?: AwsVirtualNode.SpecListenerTlsValidationTrustSdsPropertyOutputReference | AwsVirtualNode.SpecListenerTlsValidationTrustSdsProperty): any;
export declare function awsVirtualNodeSpecListenerTlsValidationTrustPropertyToTerraform(struct?: AwsVirtualNode.SpecListenerTlsValidationTrustPropertyOutputReference | AwsVirtualNode.SpecListenerTlsValidationTrustProperty): any;
export declare function awsVirtualNodeSpecListenerTlsValidationTrustPropertyToHclTerraform(struct?: AwsVirtualNode.SpecListenerTlsValidationTrustPropertyOutputReference | AwsVirtualNode.SpecListenerTlsValidationTrustProperty): any;
export declare function awsVirtualNodeSpecListenerTlsValidationPropertyToTerraform(struct?: AwsVirtualNode.SpecListenerTlsValidationPropertyOutputReference | AwsVirtualNode.SpecListenerTlsValidationProperty): any;
export declare function awsVirtualNodeSpecListenerTlsValidationPropertyToHclTerraform(struct?: AwsVirtualNode.SpecListenerTlsValidationPropertyOutputReference | AwsVirtualNode.SpecListenerTlsValidationProperty): any;
export declare function awsVirtualNodeSpecListenerTlsPropertyToTerraform(struct?: AwsVirtualNode.SpecListenerTlsPropertyOutputReference | AwsVirtualNode.SpecListenerTlsProperty): any;
export declare function awsVirtualNodeSpecListenerTlsPropertyToHclTerraform(struct?: AwsVirtualNode.SpecListenerTlsPropertyOutputReference | AwsVirtualNode.SpecListenerTlsProperty): any;
export declare function awsVirtualNodeListenerPropertyToTerraform(struct?: AwsVirtualNode.ListenerProperty | cdktn.IResolvable): any;
export declare function awsVirtualNodeListenerPropertyToHclTerraform(struct?: AwsVirtualNode.ListenerProperty | cdktn.IResolvable): any;
export declare function awsVirtualNodeJsonPropertyToTerraform(struct?: AwsVirtualNode.JsonProperty | cdktn.IResolvable): any;
export declare function awsVirtualNodeJsonPropertyToHclTerraform(struct?: AwsVirtualNode.JsonProperty | cdktn.IResolvable): any;
export declare function awsVirtualNodeFormatPropertyToTerraform(struct?: AwsVirtualNode.FormatPropertyOutputReference | AwsVirtualNode.FormatProperty): any;
export declare function awsVirtualNodeFormatPropertyToHclTerraform(struct?: AwsVirtualNode.FormatPropertyOutputReference | AwsVirtualNode.FormatProperty): any;
export declare function awsVirtualNodeSpecLoggingAccessLogFilePropertyToTerraform(struct?: AwsVirtualNode.SpecLoggingAccessLogFilePropertyOutputReference | AwsVirtualNode.SpecLoggingAccessLogFileProperty): any;
export declare function awsVirtualNodeSpecLoggingAccessLogFilePropertyToHclTerraform(struct?: AwsVirtualNode.SpecLoggingAccessLogFilePropertyOutputReference | AwsVirtualNode.SpecLoggingAccessLogFileProperty): any;
export declare function awsVirtualNodeAccessLogPropertyToTerraform(struct?: AwsVirtualNode.AccessLogPropertyOutputReference | AwsVirtualNode.AccessLogProperty): any;
export declare function awsVirtualNodeAccessLogPropertyToHclTerraform(struct?: AwsVirtualNode.AccessLogPropertyOutputReference | AwsVirtualNode.AccessLogProperty): any;
export declare function awsVirtualNodeLoggingPropertyToTerraform(struct?: AwsVirtualNode.LoggingPropertyOutputReference | AwsVirtualNode.LoggingProperty): any;
export declare function awsVirtualNodeLoggingPropertyToHclTerraform(struct?: AwsVirtualNode.LoggingPropertyOutputReference | AwsVirtualNode.LoggingProperty): any;
export declare function awsVirtualNodeAwsCloudMapPropertyToTerraform(struct?: AwsVirtualNode.AwsCloudMapPropertyOutputReference | AwsVirtualNode.AwsCloudMapProperty): any;
export declare function awsVirtualNodeAwsCloudMapPropertyToHclTerraform(struct?: AwsVirtualNode.AwsCloudMapPropertyOutputReference | AwsVirtualNode.AwsCloudMapProperty): any;
export declare function awsVirtualNodeDnsPropertyToTerraform(struct?: AwsVirtualNode.DnsPropertyOutputReference | AwsVirtualNode.DnsProperty): any;
export declare function awsVirtualNodeDnsPropertyToHclTerraform(struct?: AwsVirtualNode.DnsPropertyOutputReference | AwsVirtualNode.DnsProperty): any;
export declare function awsVirtualNodeServiceDiscoveryPropertyToTerraform(struct?: AwsVirtualNode.ServiceDiscoveryPropertyOutputReference | AwsVirtualNode.ServiceDiscoveryProperty): any;
export declare function awsVirtualNodeServiceDiscoveryPropertyToHclTerraform(struct?: AwsVirtualNode.ServiceDiscoveryPropertyOutputReference | AwsVirtualNode.ServiceDiscoveryProperty): any;
export declare function awsVirtualNodeSpecPropertyToTerraform(struct?: AwsVirtualNode.SpecPropertyOutputReference | AwsVirtualNode.SpecProperty): any;
export declare function awsVirtualNodeSpecPropertyToHclTerraform(struct?: AwsVirtualNode.SpecPropertyOutputReference | AwsVirtualNode.SpecProperty): any;
export declare namespace AwsVirtualNode {
    interface SpecBackendVirtualServiceClientPolicyTlsCertificateFileProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#certificate_chain AwsVirtualNode#certificate_chain}
        */
        readonly certificateChain: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#private_key AwsVirtualNode#private_key}
        */
        readonly privateKey: string;
    }
    class SpecBackendVirtualServiceClientPolicyTlsCertificateFilePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecBackendVirtualServiceClientPolicyTlsCertificateFileProperty | undefined;
        set internalValue(value: SpecBackendVirtualServiceClientPolicyTlsCertificateFileProperty | undefined);
        private _certificateChain?;
        get certificateChain(): string;
        set certificateChain(value: string);
        get certificateChainInput(): string | undefined;
        private _privateKey?;
        get privateKey(): string;
        set privateKey(value: string);
        get privateKeyInput(): string | undefined;
    }
    interface SpecBackendVirtualServiceClientPolicyTlsCertificateSdsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#secret_name AwsVirtualNode#secret_name}
        */
        readonly secretName: string;
    }
    class SpecBackendVirtualServiceClientPolicyTlsCertificateSdsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecBackendVirtualServiceClientPolicyTlsCertificateSdsProperty | undefined;
        set internalValue(value: SpecBackendVirtualServiceClientPolicyTlsCertificateSdsProperty | undefined);
        private _secretName?;
        get secretName(): string;
        set secretName(value: string);
        get secretNameInput(): string | undefined;
    }
    interface SpecBackendVirtualServiceClientPolicyTlsCertificateProperty {
        /**
        * file block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#file AwsVirtualNode#file}
        */
        readonly file?: SpecBackendVirtualServiceClientPolicyTlsCertificateFileProperty;
        /**
        * sds block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#sds AwsVirtualNode#sds}
        */
        readonly sds?: SpecBackendVirtualServiceClientPolicyTlsCertificateSdsProperty;
    }
    class SpecBackendVirtualServiceClientPolicyTlsCertificatePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecBackendVirtualServiceClientPolicyTlsCertificateProperty | undefined;
        set internalValue(value: SpecBackendVirtualServiceClientPolicyTlsCertificateProperty | undefined);
        private _file;
        get file(): SpecBackendVirtualServiceClientPolicyTlsCertificateFilePropertyOutputReference;
        putFile(value: SpecBackendVirtualServiceClientPolicyTlsCertificateFileProperty): void;
        resetFile(): void;
        get fileInput(): SpecBackendVirtualServiceClientPolicyTlsCertificateFileProperty | undefined;
        private _sds;
        get sds(): SpecBackendVirtualServiceClientPolicyTlsCertificateSdsPropertyOutputReference;
        putSds(value: SpecBackendVirtualServiceClientPolicyTlsCertificateSdsProperty): void;
        resetSds(): void;
        get sdsInput(): SpecBackendVirtualServiceClientPolicyTlsCertificateSdsProperty | undefined;
    }
    interface SpecBackendVirtualServiceClientPolicyTlsValidationSubjectAlternativeNamesMatchProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#exact AwsVirtualNode#exact}
        */
        readonly exact: string[];
    }
    class SpecBackendVirtualServiceClientPolicyTlsValidationSubjectAlternativeNamesMatchPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecBackendVirtualServiceClientPolicyTlsValidationSubjectAlternativeNamesMatchProperty | undefined;
        set internalValue(value: SpecBackendVirtualServiceClientPolicyTlsValidationSubjectAlternativeNamesMatchProperty | undefined);
        private _exact?;
        get exact(): string[];
        set exact(value: string[]);
        get exactInput(): string[] | undefined;
    }
    interface SpecBackendVirtualServiceClientPolicyTlsValidationSubjectAlternativeNamesProperty {
        /**
        * match block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#match AwsVirtualNode#match}
        */
        readonly match: SpecBackendVirtualServiceClientPolicyTlsValidationSubjectAlternativeNamesMatchProperty;
    }
    class SpecBackendVirtualServiceClientPolicyTlsValidationSubjectAlternativeNamesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecBackendVirtualServiceClientPolicyTlsValidationSubjectAlternativeNamesProperty | undefined;
        set internalValue(value: SpecBackendVirtualServiceClientPolicyTlsValidationSubjectAlternativeNamesProperty | undefined);
        private _match;
        get match(): SpecBackendVirtualServiceClientPolicyTlsValidationSubjectAlternativeNamesMatchPropertyOutputReference;
        putMatch(value: SpecBackendVirtualServiceClientPolicyTlsValidationSubjectAlternativeNamesMatchProperty): void;
        get matchInput(): SpecBackendVirtualServiceClientPolicyTlsValidationSubjectAlternativeNamesMatchProperty | undefined;
    }
    interface SpecBackendVirtualServiceClientPolicyTlsValidationTrustAcmProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#certificate_authority_arns AwsVirtualNode#certificate_authority_arns}
        */
        readonly certificateAuthorityArns: string[];
    }
    class SpecBackendVirtualServiceClientPolicyTlsValidationTrustAcmPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecBackendVirtualServiceClientPolicyTlsValidationTrustAcmProperty | undefined;
        set internalValue(value: SpecBackendVirtualServiceClientPolicyTlsValidationTrustAcmProperty | undefined);
        private _certificateAuthorityArns?;
        get certificateAuthorityArns(): string[];
        set certificateAuthorityArns(value: string[]);
        get certificateAuthorityArnsInput(): string[] | undefined;
    }
    interface SpecBackendVirtualServiceClientPolicyTlsValidationTrustFileProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#certificate_chain AwsVirtualNode#certificate_chain}
        */
        readonly certificateChain: string;
    }
    class SpecBackendVirtualServiceClientPolicyTlsValidationTrustFilePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecBackendVirtualServiceClientPolicyTlsValidationTrustFileProperty | undefined;
        set internalValue(value: SpecBackendVirtualServiceClientPolicyTlsValidationTrustFileProperty | undefined);
        private _certificateChain?;
        get certificateChain(): string;
        set certificateChain(value: string);
        get certificateChainInput(): string | undefined;
    }
    interface SpecBackendVirtualServiceClientPolicyTlsValidationTrustSdsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#secret_name AwsVirtualNode#secret_name}
        */
        readonly secretName: string;
    }
    class SpecBackendVirtualServiceClientPolicyTlsValidationTrustSdsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecBackendVirtualServiceClientPolicyTlsValidationTrustSdsProperty | undefined;
        set internalValue(value: SpecBackendVirtualServiceClientPolicyTlsValidationTrustSdsProperty | undefined);
        private _secretName?;
        get secretName(): string;
        set secretName(value: string);
        get secretNameInput(): string | undefined;
    }
    interface SpecBackendVirtualServiceClientPolicyTlsValidationTrustProperty {
        /**
        * acm block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#acm AwsVirtualNode#acm}
        */
        readonly acm?: SpecBackendVirtualServiceClientPolicyTlsValidationTrustAcmProperty;
        /**
        * file block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#file AwsVirtualNode#file}
        */
        readonly file?: SpecBackendVirtualServiceClientPolicyTlsValidationTrustFileProperty;
        /**
        * sds block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#sds AwsVirtualNode#sds}
        */
        readonly sds?: SpecBackendVirtualServiceClientPolicyTlsValidationTrustSdsProperty;
    }
    class SpecBackendVirtualServiceClientPolicyTlsValidationTrustPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecBackendVirtualServiceClientPolicyTlsValidationTrustProperty | undefined;
        set internalValue(value: SpecBackendVirtualServiceClientPolicyTlsValidationTrustProperty | undefined);
        private _acm;
        get acm(): SpecBackendVirtualServiceClientPolicyTlsValidationTrustAcmPropertyOutputReference;
        putAcm(value: SpecBackendVirtualServiceClientPolicyTlsValidationTrustAcmProperty): void;
        resetAcm(): void;
        get acmInput(): SpecBackendVirtualServiceClientPolicyTlsValidationTrustAcmProperty | undefined;
        private _file;
        get file(): SpecBackendVirtualServiceClientPolicyTlsValidationTrustFilePropertyOutputReference;
        putFile(value: SpecBackendVirtualServiceClientPolicyTlsValidationTrustFileProperty): void;
        resetFile(): void;
        get fileInput(): SpecBackendVirtualServiceClientPolicyTlsValidationTrustFileProperty | undefined;
        private _sds;
        get sds(): SpecBackendVirtualServiceClientPolicyTlsValidationTrustSdsPropertyOutputReference;
        putSds(value: SpecBackendVirtualServiceClientPolicyTlsValidationTrustSdsProperty): void;
        resetSds(): void;
        get sdsInput(): SpecBackendVirtualServiceClientPolicyTlsValidationTrustSdsProperty | undefined;
    }
    interface SpecBackendVirtualServiceClientPolicyTlsValidationProperty {
        /**
        * subject_alternative_names block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#subject_alternative_names AwsVirtualNode#subject_alternative_names}
        */
        readonly subjectAlternativeNames?: SpecBackendVirtualServiceClientPolicyTlsValidationSubjectAlternativeNamesProperty;
        /**
        * trust block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#trust AwsVirtualNode#trust}
        */
        readonly trust: SpecBackendVirtualServiceClientPolicyTlsValidationTrustProperty;
    }
    class SpecBackendVirtualServiceClientPolicyTlsValidationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecBackendVirtualServiceClientPolicyTlsValidationProperty | undefined;
        set internalValue(value: SpecBackendVirtualServiceClientPolicyTlsValidationProperty | undefined);
        private _subjectAlternativeNames;
        get subjectAlternativeNames(): SpecBackendVirtualServiceClientPolicyTlsValidationSubjectAlternativeNamesPropertyOutputReference;
        putSubjectAlternativeNames(value: SpecBackendVirtualServiceClientPolicyTlsValidationSubjectAlternativeNamesProperty): void;
        resetSubjectAlternativeNames(): void;
        get subjectAlternativeNamesInput(): SpecBackendVirtualServiceClientPolicyTlsValidationSubjectAlternativeNamesProperty | undefined;
        private _trust;
        get trust(): SpecBackendVirtualServiceClientPolicyTlsValidationTrustPropertyOutputReference;
        putTrust(value: SpecBackendVirtualServiceClientPolicyTlsValidationTrustProperty): void;
        get trustInput(): SpecBackendVirtualServiceClientPolicyTlsValidationTrustProperty | undefined;
    }
    interface SpecBackendVirtualServiceClientPolicyTlsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#enforce AwsVirtualNode#enforce}
        */
        readonly enforce?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#ports AwsVirtualNode#ports}
        */
        readonly ports?: number[];
        /**
        * certificate block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#certificate AwsVirtualNode#certificate}
        */
        readonly certificate?: SpecBackendVirtualServiceClientPolicyTlsCertificateProperty;
        /**
        * validation block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#validation AwsVirtualNode#validation}
        */
        readonly validation: SpecBackendVirtualServiceClientPolicyTlsValidationProperty;
    }
    class SpecBackendVirtualServiceClientPolicyTlsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecBackendVirtualServiceClientPolicyTlsProperty | undefined;
        set internalValue(value: SpecBackendVirtualServiceClientPolicyTlsProperty | undefined);
        private _enforce?;
        get enforce(): boolean | cdktn.IResolvable;
        set enforce(value: boolean | cdktn.IResolvable);
        resetEnforce(): void;
        get enforceInput(): boolean | cdktn.IResolvable | undefined;
        private _ports?;
        get ports(): number[];
        set ports(value: number[]);
        resetPorts(): void;
        get portsInput(): number[] | undefined;
        private _certificate;
        get certificate(): SpecBackendVirtualServiceClientPolicyTlsCertificatePropertyOutputReference;
        putCertificate(value: SpecBackendVirtualServiceClientPolicyTlsCertificateProperty): void;
        resetCertificate(): void;
        get certificateInput(): SpecBackendVirtualServiceClientPolicyTlsCertificateProperty | undefined;
        private _validation;
        get validation(): SpecBackendVirtualServiceClientPolicyTlsValidationPropertyOutputReference;
        putValidation(value: SpecBackendVirtualServiceClientPolicyTlsValidationProperty): void;
        get validationInput(): SpecBackendVirtualServiceClientPolicyTlsValidationProperty | undefined;
    }
    interface SpecBackendVirtualServiceClientPolicyProperty {
        /**
        * tls block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#tls AwsVirtualNode#tls}
        */
        readonly tls?: SpecBackendVirtualServiceClientPolicyTlsProperty;
    }
    class SpecBackendVirtualServiceClientPolicyPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecBackendVirtualServiceClientPolicyProperty | undefined;
        set internalValue(value: SpecBackendVirtualServiceClientPolicyProperty | undefined);
        private _tls;
        get tls(): SpecBackendVirtualServiceClientPolicyTlsPropertyOutputReference;
        putTls(value: SpecBackendVirtualServiceClientPolicyTlsProperty): void;
        resetTls(): void;
        get tlsInput(): SpecBackendVirtualServiceClientPolicyTlsProperty | undefined;
    }
    interface VirtualServiceProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#virtual_service_name AwsVirtualNode#virtual_service_name}
        */
        readonly virtualServiceName: string;
        /**
        * client_policy block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#client_policy AwsVirtualNode#client_policy}
        */
        readonly clientPolicy?: SpecBackendVirtualServiceClientPolicyProperty;
    }
    class VirtualServicePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): VirtualServiceProperty | undefined;
        set internalValue(value: VirtualServiceProperty | undefined);
        private _virtualServiceName?;
        get virtualServiceName(): string;
        set virtualServiceName(value: string);
        get virtualServiceNameInput(): string | undefined;
        private _clientPolicy;
        get clientPolicy(): SpecBackendVirtualServiceClientPolicyPropertyOutputReference;
        putClientPolicy(value: SpecBackendVirtualServiceClientPolicyProperty): void;
        resetClientPolicy(): void;
        get clientPolicyInput(): SpecBackendVirtualServiceClientPolicyProperty | undefined;
    }
    interface BackendProperty {
        /**
        * virtual_service block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#virtual_service AwsVirtualNode#virtual_service}
        */
        readonly virtualService: VirtualServiceProperty;
    }
    class BackendPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): BackendProperty | cdktn.IResolvable | undefined;
        set internalValue(value: BackendProperty | cdktn.IResolvable | undefined);
        private _virtualService;
        get virtualService(): VirtualServicePropertyOutputReference;
        putVirtualService(value: VirtualServiceProperty): void;
        get virtualServiceInput(): VirtualServiceProperty | undefined;
    }
    class BackendPropertyList extends cdktn.ComplexList {
        internalValue?: BackendProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): BackendPropertyOutputReference;
    }
    interface SpecBackendDefaultsClientPolicyTlsCertificateFileProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#certificate_chain AwsVirtualNode#certificate_chain}
        */
        readonly certificateChain: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#private_key AwsVirtualNode#private_key}
        */
        readonly privateKey: string;
    }
    class SpecBackendDefaultsClientPolicyTlsCertificateFilePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecBackendDefaultsClientPolicyTlsCertificateFileProperty | undefined;
        set internalValue(value: SpecBackendDefaultsClientPolicyTlsCertificateFileProperty | undefined);
        private _certificateChain?;
        get certificateChain(): string;
        set certificateChain(value: string);
        get certificateChainInput(): string | undefined;
        private _privateKey?;
        get privateKey(): string;
        set privateKey(value: string);
        get privateKeyInput(): string | undefined;
    }
    interface SpecBackendDefaultsClientPolicyTlsCertificateSdsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#secret_name AwsVirtualNode#secret_name}
        */
        readonly secretName: string;
    }
    class SpecBackendDefaultsClientPolicyTlsCertificateSdsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecBackendDefaultsClientPolicyTlsCertificateSdsProperty | undefined;
        set internalValue(value: SpecBackendDefaultsClientPolicyTlsCertificateSdsProperty | undefined);
        private _secretName?;
        get secretName(): string;
        set secretName(value: string);
        get secretNameInput(): string | undefined;
    }
    interface SpecBackendDefaultsClientPolicyTlsCertificateProperty {
        /**
        * file block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#file AwsVirtualNode#file}
        */
        readonly file?: SpecBackendDefaultsClientPolicyTlsCertificateFileProperty;
        /**
        * sds block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#sds AwsVirtualNode#sds}
        */
        readonly sds?: SpecBackendDefaultsClientPolicyTlsCertificateSdsProperty;
    }
    class SpecBackendDefaultsClientPolicyTlsCertificatePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecBackendDefaultsClientPolicyTlsCertificateProperty | undefined;
        set internalValue(value: SpecBackendDefaultsClientPolicyTlsCertificateProperty | undefined);
        private _file;
        get file(): SpecBackendDefaultsClientPolicyTlsCertificateFilePropertyOutputReference;
        putFile(value: SpecBackendDefaultsClientPolicyTlsCertificateFileProperty): void;
        resetFile(): void;
        get fileInput(): SpecBackendDefaultsClientPolicyTlsCertificateFileProperty | undefined;
        private _sds;
        get sds(): SpecBackendDefaultsClientPolicyTlsCertificateSdsPropertyOutputReference;
        putSds(value: SpecBackendDefaultsClientPolicyTlsCertificateSdsProperty): void;
        resetSds(): void;
        get sdsInput(): SpecBackendDefaultsClientPolicyTlsCertificateSdsProperty | undefined;
    }
    interface SpecBackendDefaultsClientPolicyTlsValidationSubjectAlternativeNamesMatchProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#exact AwsVirtualNode#exact}
        */
        readonly exact: string[];
    }
    class SpecBackendDefaultsClientPolicyTlsValidationSubjectAlternativeNamesMatchPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecBackendDefaultsClientPolicyTlsValidationSubjectAlternativeNamesMatchProperty | undefined;
        set internalValue(value: SpecBackendDefaultsClientPolicyTlsValidationSubjectAlternativeNamesMatchProperty | undefined);
        private _exact?;
        get exact(): string[];
        set exact(value: string[]);
        get exactInput(): string[] | undefined;
    }
    interface SpecBackendDefaultsClientPolicyTlsValidationSubjectAlternativeNamesProperty {
        /**
        * match block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#match AwsVirtualNode#match}
        */
        readonly match: SpecBackendDefaultsClientPolicyTlsValidationSubjectAlternativeNamesMatchProperty;
    }
    class SpecBackendDefaultsClientPolicyTlsValidationSubjectAlternativeNamesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecBackendDefaultsClientPolicyTlsValidationSubjectAlternativeNamesProperty | undefined;
        set internalValue(value: SpecBackendDefaultsClientPolicyTlsValidationSubjectAlternativeNamesProperty | undefined);
        private _match;
        get match(): SpecBackendDefaultsClientPolicyTlsValidationSubjectAlternativeNamesMatchPropertyOutputReference;
        putMatch(value: SpecBackendDefaultsClientPolicyTlsValidationSubjectAlternativeNamesMatchProperty): void;
        get matchInput(): SpecBackendDefaultsClientPolicyTlsValidationSubjectAlternativeNamesMatchProperty | undefined;
    }
    interface SpecBackendDefaultsClientPolicyTlsValidationTrustAcmProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#certificate_authority_arns AwsVirtualNode#certificate_authority_arns}
        */
        readonly certificateAuthorityArns: string[];
    }
    class SpecBackendDefaultsClientPolicyTlsValidationTrustAcmPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecBackendDefaultsClientPolicyTlsValidationTrustAcmProperty | undefined;
        set internalValue(value: SpecBackendDefaultsClientPolicyTlsValidationTrustAcmProperty | undefined);
        private _certificateAuthorityArns?;
        get certificateAuthorityArns(): string[];
        set certificateAuthorityArns(value: string[]);
        get certificateAuthorityArnsInput(): string[] | undefined;
    }
    interface SpecBackendDefaultsClientPolicyTlsValidationTrustFileProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#certificate_chain AwsVirtualNode#certificate_chain}
        */
        readonly certificateChain: string;
    }
    class SpecBackendDefaultsClientPolicyTlsValidationTrustFilePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecBackendDefaultsClientPolicyTlsValidationTrustFileProperty | undefined;
        set internalValue(value: SpecBackendDefaultsClientPolicyTlsValidationTrustFileProperty | undefined);
        private _certificateChain?;
        get certificateChain(): string;
        set certificateChain(value: string);
        get certificateChainInput(): string | undefined;
    }
    interface SpecBackendDefaultsClientPolicyTlsValidationTrustSdsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#secret_name AwsVirtualNode#secret_name}
        */
        readonly secretName: string;
    }
    class SpecBackendDefaultsClientPolicyTlsValidationTrustSdsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecBackendDefaultsClientPolicyTlsValidationTrustSdsProperty | undefined;
        set internalValue(value: SpecBackendDefaultsClientPolicyTlsValidationTrustSdsProperty | undefined);
        private _secretName?;
        get secretName(): string;
        set secretName(value: string);
        get secretNameInput(): string | undefined;
    }
    interface SpecBackendDefaultsClientPolicyTlsValidationTrustProperty {
        /**
        * acm block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#acm AwsVirtualNode#acm}
        */
        readonly acm?: SpecBackendDefaultsClientPolicyTlsValidationTrustAcmProperty;
        /**
        * file block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#file AwsVirtualNode#file}
        */
        readonly file?: SpecBackendDefaultsClientPolicyTlsValidationTrustFileProperty;
        /**
        * sds block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#sds AwsVirtualNode#sds}
        */
        readonly sds?: SpecBackendDefaultsClientPolicyTlsValidationTrustSdsProperty;
    }
    class SpecBackendDefaultsClientPolicyTlsValidationTrustPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecBackendDefaultsClientPolicyTlsValidationTrustProperty | undefined;
        set internalValue(value: SpecBackendDefaultsClientPolicyTlsValidationTrustProperty | undefined);
        private _acm;
        get acm(): SpecBackendDefaultsClientPolicyTlsValidationTrustAcmPropertyOutputReference;
        putAcm(value: SpecBackendDefaultsClientPolicyTlsValidationTrustAcmProperty): void;
        resetAcm(): void;
        get acmInput(): SpecBackendDefaultsClientPolicyTlsValidationTrustAcmProperty | undefined;
        private _file;
        get file(): SpecBackendDefaultsClientPolicyTlsValidationTrustFilePropertyOutputReference;
        putFile(value: SpecBackendDefaultsClientPolicyTlsValidationTrustFileProperty): void;
        resetFile(): void;
        get fileInput(): SpecBackendDefaultsClientPolicyTlsValidationTrustFileProperty | undefined;
        private _sds;
        get sds(): SpecBackendDefaultsClientPolicyTlsValidationTrustSdsPropertyOutputReference;
        putSds(value: SpecBackendDefaultsClientPolicyTlsValidationTrustSdsProperty): void;
        resetSds(): void;
        get sdsInput(): SpecBackendDefaultsClientPolicyTlsValidationTrustSdsProperty | undefined;
    }
    interface SpecBackendDefaultsClientPolicyTlsValidationProperty {
        /**
        * subject_alternative_names block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#subject_alternative_names AwsVirtualNode#subject_alternative_names}
        */
        readonly subjectAlternativeNames?: SpecBackendDefaultsClientPolicyTlsValidationSubjectAlternativeNamesProperty;
        /**
        * trust block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#trust AwsVirtualNode#trust}
        */
        readonly trust: SpecBackendDefaultsClientPolicyTlsValidationTrustProperty;
    }
    class SpecBackendDefaultsClientPolicyTlsValidationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecBackendDefaultsClientPolicyTlsValidationProperty | undefined;
        set internalValue(value: SpecBackendDefaultsClientPolicyTlsValidationProperty | undefined);
        private _subjectAlternativeNames;
        get subjectAlternativeNames(): SpecBackendDefaultsClientPolicyTlsValidationSubjectAlternativeNamesPropertyOutputReference;
        putSubjectAlternativeNames(value: SpecBackendDefaultsClientPolicyTlsValidationSubjectAlternativeNamesProperty): void;
        resetSubjectAlternativeNames(): void;
        get subjectAlternativeNamesInput(): SpecBackendDefaultsClientPolicyTlsValidationSubjectAlternativeNamesProperty | undefined;
        private _trust;
        get trust(): SpecBackendDefaultsClientPolicyTlsValidationTrustPropertyOutputReference;
        putTrust(value: SpecBackendDefaultsClientPolicyTlsValidationTrustProperty): void;
        get trustInput(): SpecBackendDefaultsClientPolicyTlsValidationTrustProperty | undefined;
    }
    interface SpecBackendDefaultsClientPolicyTlsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#enforce AwsVirtualNode#enforce}
        */
        readonly enforce?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#ports AwsVirtualNode#ports}
        */
        readonly ports?: number[];
        /**
        * certificate block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#certificate AwsVirtualNode#certificate}
        */
        readonly certificate?: SpecBackendDefaultsClientPolicyTlsCertificateProperty;
        /**
        * validation block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#validation AwsVirtualNode#validation}
        */
        readonly validation: SpecBackendDefaultsClientPolicyTlsValidationProperty;
    }
    class SpecBackendDefaultsClientPolicyTlsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecBackendDefaultsClientPolicyTlsProperty | undefined;
        set internalValue(value: SpecBackendDefaultsClientPolicyTlsProperty | undefined);
        private _enforce?;
        get enforce(): boolean | cdktn.IResolvable;
        set enforce(value: boolean | cdktn.IResolvable);
        resetEnforce(): void;
        get enforceInput(): boolean | cdktn.IResolvable | undefined;
        private _ports?;
        get ports(): number[];
        set ports(value: number[]);
        resetPorts(): void;
        get portsInput(): number[] | undefined;
        private _certificate;
        get certificate(): SpecBackendDefaultsClientPolicyTlsCertificatePropertyOutputReference;
        putCertificate(value: SpecBackendDefaultsClientPolicyTlsCertificateProperty): void;
        resetCertificate(): void;
        get certificateInput(): SpecBackendDefaultsClientPolicyTlsCertificateProperty | undefined;
        private _validation;
        get validation(): SpecBackendDefaultsClientPolicyTlsValidationPropertyOutputReference;
        putValidation(value: SpecBackendDefaultsClientPolicyTlsValidationProperty): void;
        get validationInput(): SpecBackendDefaultsClientPolicyTlsValidationProperty | undefined;
    }
    interface SpecBackendDefaultsClientPolicyProperty {
        /**
        * tls block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#tls AwsVirtualNode#tls}
        */
        readonly tls?: SpecBackendDefaultsClientPolicyTlsProperty;
    }
    class SpecBackendDefaultsClientPolicyPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecBackendDefaultsClientPolicyProperty | undefined;
        set internalValue(value: SpecBackendDefaultsClientPolicyProperty | undefined);
        private _tls;
        get tls(): SpecBackendDefaultsClientPolicyTlsPropertyOutputReference;
        putTls(value: SpecBackendDefaultsClientPolicyTlsProperty): void;
        resetTls(): void;
        get tlsInput(): SpecBackendDefaultsClientPolicyTlsProperty | undefined;
    }
    interface BackendDefaultsProperty {
        /**
        * client_policy block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#client_policy AwsVirtualNode#client_policy}
        */
        readonly clientPolicy?: SpecBackendDefaultsClientPolicyProperty;
    }
    class BackendDefaultsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): BackendDefaultsProperty | undefined;
        set internalValue(value: BackendDefaultsProperty | undefined);
        private _clientPolicy;
        get clientPolicy(): SpecBackendDefaultsClientPolicyPropertyOutputReference;
        putClientPolicy(value: SpecBackendDefaultsClientPolicyProperty): void;
        resetClientPolicy(): void;
        get clientPolicyInput(): SpecBackendDefaultsClientPolicyProperty | undefined;
    }
    interface SpecListenerConnectionPoolGrpcProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#max_requests AwsVirtualNode#max_requests}
        */
        readonly maxRequests: number;
    }
    class SpecListenerConnectionPoolGrpcPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecListenerConnectionPoolGrpcProperty | undefined;
        set internalValue(value: SpecListenerConnectionPoolGrpcProperty | undefined);
        private _maxRequests?;
        get maxRequests(): number;
        set maxRequests(value: number);
        get maxRequestsInput(): number | undefined;
    }
    interface SpecListenerConnectionPoolHttpProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#max_connections AwsVirtualNode#max_connections}
        */
        readonly maxConnections: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#max_pending_requests AwsVirtualNode#max_pending_requests}
        */
        readonly maxPendingRequests?: number;
    }
    class SpecListenerConnectionPoolHttpPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecListenerConnectionPoolHttpProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SpecListenerConnectionPoolHttpProperty | cdktn.IResolvable | undefined);
        private _maxConnections?;
        get maxConnections(): number;
        set maxConnections(value: number);
        get maxConnectionsInput(): number | undefined;
        private _maxPendingRequests?;
        get maxPendingRequests(): number;
        set maxPendingRequests(value: number);
        resetMaxPendingRequests(): void;
        get maxPendingRequestsInput(): number | undefined;
    }
    class SpecListenerConnectionPoolHttpPropertyList extends cdktn.ComplexList {
        internalValue?: SpecListenerConnectionPoolHttpProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecListenerConnectionPoolHttpPropertyOutputReference;
    }
    interface SpecListenerConnectionPoolHttp2Property {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#max_requests AwsVirtualNode#max_requests}
        */
        readonly maxRequests: number;
    }
    class SpecListenerConnectionPoolHttp2PropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecListenerConnectionPoolHttp2Property | cdktn.IResolvable | undefined;
        set internalValue(value: SpecListenerConnectionPoolHttp2Property | cdktn.IResolvable | undefined);
        private _maxRequests?;
        get maxRequests(): number;
        set maxRequests(value: number);
        get maxRequestsInput(): number | undefined;
    }
    class SpecListenerConnectionPoolHttp2PropertyList extends cdktn.ComplexList {
        internalValue?: SpecListenerConnectionPoolHttp2Property[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecListenerConnectionPoolHttp2PropertyOutputReference;
    }
    interface SpecListenerConnectionPoolTcpProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#max_connections AwsVirtualNode#max_connections}
        */
        readonly maxConnections: number;
    }
    class SpecListenerConnectionPoolTcpPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecListenerConnectionPoolTcpProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SpecListenerConnectionPoolTcpProperty | cdktn.IResolvable | undefined);
        private _maxConnections?;
        get maxConnections(): number;
        set maxConnections(value: number);
        get maxConnectionsInput(): number | undefined;
    }
    class SpecListenerConnectionPoolTcpPropertyList extends cdktn.ComplexList {
        internalValue?: SpecListenerConnectionPoolTcpProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecListenerConnectionPoolTcpPropertyOutputReference;
    }
    interface ConnectionPoolProperty {
        /**
        * grpc block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#grpc AwsVirtualNode#grpc}
        */
        readonly grpc?: SpecListenerConnectionPoolGrpcProperty;
        /**
        * http block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#http AwsVirtualNode#http}
        */
        readonly http?: SpecListenerConnectionPoolHttpProperty[] | cdktn.IResolvable;
        /**
        * http2 block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#http2 AwsVirtualNode#http2}
        */
        readonly http2?: SpecListenerConnectionPoolHttp2Property[] | cdktn.IResolvable;
        /**
        * tcp block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#tcp AwsVirtualNode#tcp}
        */
        readonly tcp?: SpecListenerConnectionPoolTcpProperty[] | cdktn.IResolvable;
    }
    class ConnectionPoolPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ConnectionPoolProperty | undefined;
        set internalValue(value: ConnectionPoolProperty | undefined);
        private _grpc;
        get grpc(): SpecListenerConnectionPoolGrpcPropertyOutputReference;
        putGrpc(value: SpecListenerConnectionPoolGrpcProperty): void;
        resetGrpc(): void;
        get grpcInput(): SpecListenerConnectionPoolGrpcProperty | undefined;
        private _http;
        get http(): SpecListenerConnectionPoolHttpPropertyList;
        putHttp(value: SpecListenerConnectionPoolHttpProperty[] | cdktn.IResolvable): void;
        resetHttp(): void;
        get httpInput(): cdktn.IResolvable | SpecListenerConnectionPoolHttpProperty[] | undefined;
        private _http2;
        get http2(): SpecListenerConnectionPoolHttp2PropertyList;
        putHttp2(value: SpecListenerConnectionPoolHttp2Property[] | cdktn.IResolvable): void;
        resetHttp2(): void;
        get http2Input(): cdktn.IResolvable | SpecListenerConnectionPoolHttp2Property[] | undefined;
        private _tcp;
        get tcp(): SpecListenerConnectionPoolTcpPropertyList;
        putTcp(value: SpecListenerConnectionPoolTcpProperty[] | cdktn.IResolvable): void;
        resetTcp(): void;
        get tcpInput(): cdktn.IResolvable | SpecListenerConnectionPoolTcpProperty[] | undefined;
    }
    interface HealthCheckProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#healthy_threshold AwsVirtualNode#healthy_threshold}
        */
        readonly healthyThreshold: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#interval_millis AwsVirtualNode#interval_millis}
        */
        readonly intervalMillis: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#path AwsVirtualNode#path}
        */
        readonly path?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#port AwsVirtualNode#port}
        */
        readonly port?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#protocol AwsVirtualNode#protocol}
        */
        readonly protocol: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#timeout_millis AwsVirtualNode#timeout_millis}
        */
        readonly timeoutMillis: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#unhealthy_threshold AwsVirtualNode#unhealthy_threshold}
        */
        readonly unhealthyThreshold: number;
    }
    class HealthCheckPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): HealthCheckProperty | undefined;
        set internalValue(value: HealthCheckProperty | undefined);
        private _healthyThreshold?;
        get healthyThreshold(): number;
        set healthyThreshold(value: number);
        get healthyThresholdInput(): number | undefined;
        private _intervalMillis?;
        get intervalMillis(): number;
        set intervalMillis(value: number);
        get intervalMillisInput(): number | undefined;
        private _path?;
        get path(): string;
        set path(value: string);
        resetPath(): void;
        get pathInput(): string | undefined;
        private _port?;
        get port(): number;
        set port(value: number);
        resetPort(): void;
        get portInput(): number | undefined;
        private _protocol?;
        get protocol(): string;
        set protocol(value: string);
        get protocolInput(): string | undefined;
        private _timeoutMillis?;
        get timeoutMillis(): number;
        set timeoutMillis(value: number);
        get timeoutMillisInput(): number | undefined;
        private _unhealthyThreshold?;
        get unhealthyThreshold(): number;
        set unhealthyThreshold(value: number);
        get unhealthyThresholdInput(): number | undefined;
    }
    interface BaseEjectionDurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#unit AwsVirtualNode#unit}
        */
        readonly unit: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#value AwsVirtualNode#value}
        */
        readonly value: number;
    }
    class BaseEjectionDurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): BaseEjectionDurationProperty | undefined;
        set internalValue(value: BaseEjectionDurationProperty | undefined);
        private _unit?;
        get unit(): string;
        set unit(value: string);
        get unitInput(): string | undefined;
        private _value?;
        get value(): number;
        set value(value: number);
        get valueInput(): number | undefined;
    }
    interface IntervalProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#unit AwsVirtualNode#unit}
        */
        readonly unit: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#value AwsVirtualNode#value}
        */
        readonly value: number;
    }
    class IntervalPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): IntervalProperty | undefined;
        set internalValue(value: IntervalProperty | undefined);
        private _unit?;
        get unit(): string;
        set unit(value: string);
        get unitInput(): string | undefined;
        private _value?;
        get value(): number;
        set value(value: number);
        get valueInput(): number | undefined;
    }
    interface OutlierDetectionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#max_ejection_percent AwsVirtualNode#max_ejection_percent}
        */
        readonly maxEjectionPercent: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#max_server_errors AwsVirtualNode#max_server_errors}
        */
        readonly maxServerErrors: number;
        /**
        * base_ejection_duration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#base_ejection_duration AwsVirtualNode#base_ejection_duration}
        */
        readonly baseEjectionDuration: BaseEjectionDurationProperty;
        /**
        * interval block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#interval AwsVirtualNode#interval}
        */
        readonly interval: IntervalProperty;
    }
    class OutlierDetectionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): OutlierDetectionProperty | undefined;
        set internalValue(value: OutlierDetectionProperty | undefined);
        private _maxEjectionPercent?;
        get maxEjectionPercent(): number;
        set maxEjectionPercent(value: number);
        get maxEjectionPercentInput(): number | undefined;
        private _maxServerErrors?;
        get maxServerErrors(): number;
        set maxServerErrors(value: number);
        get maxServerErrorsInput(): number | undefined;
        private _baseEjectionDuration;
        get baseEjectionDuration(): BaseEjectionDurationPropertyOutputReference;
        putBaseEjectionDuration(value: BaseEjectionDurationProperty): void;
        get baseEjectionDurationInput(): BaseEjectionDurationProperty | undefined;
        private _interval;
        get interval(): IntervalPropertyOutputReference;
        putInterval(value: IntervalProperty): void;
        get intervalInput(): IntervalProperty | undefined;
    }
    interface PortMappingProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#port AwsVirtualNode#port}
        */
        readonly port: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#protocol AwsVirtualNode#protocol}
        */
        readonly protocol: string;
    }
    class PortMappingPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): PortMappingProperty | undefined;
        set internalValue(value: PortMappingProperty | undefined);
        private _port?;
        get port(): number;
        set port(value: number);
        get portInput(): number | undefined;
        private _protocol?;
        get protocol(): string;
        set protocol(value: string);
        get protocolInput(): string | undefined;
    }
    interface SpecListenerTimeoutGrpcIdleProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#unit AwsVirtualNode#unit}
        */
        readonly unit: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#value AwsVirtualNode#value}
        */
        readonly value: number;
    }
    class SpecListenerTimeoutGrpcIdlePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecListenerTimeoutGrpcIdleProperty | undefined;
        set internalValue(value: SpecListenerTimeoutGrpcIdleProperty | undefined);
        private _unit?;
        get unit(): string;
        set unit(value: string);
        get unitInput(): string | undefined;
        private _value?;
        get value(): number;
        set value(value: number);
        get valueInput(): number | undefined;
    }
    interface SpecListenerTimeoutGrpcPerRequestProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#unit AwsVirtualNode#unit}
        */
        readonly unit: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#value AwsVirtualNode#value}
        */
        readonly value: number;
    }
    class SpecListenerTimeoutGrpcPerRequestPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecListenerTimeoutGrpcPerRequestProperty | undefined;
        set internalValue(value: SpecListenerTimeoutGrpcPerRequestProperty | undefined);
        private _unit?;
        get unit(): string;
        set unit(value: string);
        get unitInput(): string | undefined;
        private _value?;
        get value(): number;
        set value(value: number);
        get valueInput(): number | undefined;
    }
    interface SpecListenerTimeoutGrpcProperty {
        /**
        * idle block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#idle AwsVirtualNode#idle}
        */
        readonly idle?: SpecListenerTimeoutGrpcIdleProperty;
        /**
        * per_request block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#per_request AwsVirtualNode#per_request}
        */
        readonly perRequest?: SpecListenerTimeoutGrpcPerRequestProperty;
    }
    class SpecListenerTimeoutGrpcPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecListenerTimeoutGrpcProperty | undefined;
        set internalValue(value: SpecListenerTimeoutGrpcProperty | undefined);
        private _idle;
        get idle(): SpecListenerTimeoutGrpcIdlePropertyOutputReference;
        putIdle(value: SpecListenerTimeoutGrpcIdleProperty): void;
        resetIdle(): void;
        get idleInput(): SpecListenerTimeoutGrpcIdleProperty | undefined;
        private _perRequest;
        get perRequest(): SpecListenerTimeoutGrpcPerRequestPropertyOutputReference;
        putPerRequest(value: SpecListenerTimeoutGrpcPerRequestProperty): void;
        resetPerRequest(): void;
        get perRequestInput(): SpecListenerTimeoutGrpcPerRequestProperty | undefined;
    }
    interface SpecListenerTimeoutHttpIdleProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#unit AwsVirtualNode#unit}
        */
        readonly unit: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#value AwsVirtualNode#value}
        */
        readonly value: number;
    }
    class SpecListenerTimeoutHttpIdlePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecListenerTimeoutHttpIdleProperty | undefined;
        set internalValue(value: SpecListenerTimeoutHttpIdleProperty | undefined);
        private _unit?;
        get unit(): string;
        set unit(value: string);
        get unitInput(): string | undefined;
        private _value?;
        get value(): number;
        set value(value: number);
        get valueInput(): number | undefined;
    }
    interface SpecListenerTimeoutHttpPerRequestProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#unit AwsVirtualNode#unit}
        */
        readonly unit: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#value AwsVirtualNode#value}
        */
        readonly value: number;
    }
    class SpecListenerTimeoutHttpPerRequestPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecListenerTimeoutHttpPerRequestProperty | undefined;
        set internalValue(value: SpecListenerTimeoutHttpPerRequestProperty | undefined);
        private _unit?;
        get unit(): string;
        set unit(value: string);
        get unitInput(): string | undefined;
        private _value?;
        get value(): number;
        set value(value: number);
        get valueInput(): number | undefined;
    }
    interface SpecListenerTimeoutHttpProperty {
        /**
        * idle block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#idle AwsVirtualNode#idle}
        */
        readonly idle?: SpecListenerTimeoutHttpIdleProperty;
        /**
        * per_request block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#per_request AwsVirtualNode#per_request}
        */
        readonly perRequest?: SpecListenerTimeoutHttpPerRequestProperty;
    }
    class SpecListenerTimeoutHttpPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecListenerTimeoutHttpProperty | undefined;
        set internalValue(value: SpecListenerTimeoutHttpProperty | undefined);
        private _idle;
        get idle(): SpecListenerTimeoutHttpIdlePropertyOutputReference;
        putIdle(value: SpecListenerTimeoutHttpIdleProperty): void;
        resetIdle(): void;
        get idleInput(): SpecListenerTimeoutHttpIdleProperty | undefined;
        private _perRequest;
        get perRequest(): SpecListenerTimeoutHttpPerRequestPropertyOutputReference;
        putPerRequest(value: SpecListenerTimeoutHttpPerRequestProperty): void;
        resetPerRequest(): void;
        get perRequestInput(): SpecListenerTimeoutHttpPerRequestProperty | undefined;
    }
    interface SpecListenerTimeoutHttp2IdleProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#unit AwsVirtualNode#unit}
        */
        readonly unit: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#value AwsVirtualNode#value}
        */
        readonly value: number;
    }
    class SpecListenerTimeoutHttp2IdlePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecListenerTimeoutHttp2IdleProperty | undefined;
        set internalValue(value: SpecListenerTimeoutHttp2IdleProperty | undefined);
        private _unit?;
        get unit(): string;
        set unit(value: string);
        get unitInput(): string | undefined;
        private _value?;
        get value(): number;
        set value(value: number);
        get valueInput(): number | undefined;
    }
    interface SpecListenerTimeoutHttp2PerRequestProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#unit AwsVirtualNode#unit}
        */
        readonly unit: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#value AwsVirtualNode#value}
        */
        readonly value: number;
    }
    class SpecListenerTimeoutHttp2PerRequestPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecListenerTimeoutHttp2PerRequestProperty | undefined;
        set internalValue(value: SpecListenerTimeoutHttp2PerRequestProperty | undefined);
        private _unit?;
        get unit(): string;
        set unit(value: string);
        get unitInput(): string | undefined;
        private _value?;
        get value(): number;
        set value(value: number);
        get valueInput(): number | undefined;
    }
    interface SpecListenerTimeoutHttp2Property {
        /**
        * idle block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#idle AwsVirtualNode#idle}
        */
        readonly idle?: SpecListenerTimeoutHttp2IdleProperty;
        /**
        * per_request block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#per_request AwsVirtualNode#per_request}
        */
        readonly perRequest?: SpecListenerTimeoutHttp2PerRequestProperty;
    }
    class SpecListenerTimeoutHttp2PropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecListenerTimeoutHttp2Property | undefined;
        set internalValue(value: SpecListenerTimeoutHttp2Property | undefined);
        private _idle;
        get idle(): SpecListenerTimeoutHttp2IdlePropertyOutputReference;
        putIdle(value: SpecListenerTimeoutHttp2IdleProperty): void;
        resetIdle(): void;
        get idleInput(): SpecListenerTimeoutHttp2IdleProperty | undefined;
        private _perRequest;
        get perRequest(): SpecListenerTimeoutHttp2PerRequestPropertyOutputReference;
        putPerRequest(value: SpecListenerTimeoutHttp2PerRequestProperty): void;
        resetPerRequest(): void;
        get perRequestInput(): SpecListenerTimeoutHttp2PerRequestProperty | undefined;
    }
    interface SpecListenerTimeoutTcpIdleProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#unit AwsVirtualNode#unit}
        */
        readonly unit: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#value AwsVirtualNode#value}
        */
        readonly value: number;
    }
    class SpecListenerTimeoutTcpIdlePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecListenerTimeoutTcpIdleProperty | undefined;
        set internalValue(value: SpecListenerTimeoutTcpIdleProperty | undefined);
        private _unit?;
        get unit(): string;
        set unit(value: string);
        get unitInput(): string | undefined;
        private _value?;
        get value(): number;
        set value(value: number);
        get valueInput(): number | undefined;
    }
    interface SpecListenerTimeoutTcpProperty {
        /**
        * idle block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#idle AwsVirtualNode#idle}
        */
        readonly idle?: SpecListenerTimeoutTcpIdleProperty;
    }
    class SpecListenerTimeoutTcpPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecListenerTimeoutTcpProperty | undefined;
        set internalValue(value: SpecListenerTimeoutTcpProperty | undefined);
        private _idle;
        get idle(): SpecListenerTimeoutTcpIdlePropertyOutputReference;
        putIdle(value: SpecListenerTimeoutTcpIdleProperty): void;
        resetIdle(): void;
        get idleInput(): SpecListenerTimeoutTcpIdleProperty | undefined;
    }
    interface TimeoutProperty {
        /**
        * grpc block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#grpc AwsVirtualNode#grpc}
        */
        readonly grpc?: SpecListenerTimeoutGrpcProperty;
        /**
        * http block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#http AwsVirtualNode#http}
        */
        readonly http?: SpecListenerTimeoutHttpProperty;
        /**
        * http2 block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#http2 AwsVirtualNode#http2}
        */
        readonly http2?: SpecListenerTimeoutHttp2Property;
        /**
        * tcp block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#tcp AwsVirtualNode#tcp}
        */
        readonly tcp?: SpecListenerTimeoutTcpProperty;
    }
    class TimeoutPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutProperty | undefined;
        set internalValue(value: TimeoutProperty | undefined);
        private _grpc;
        get grpc(): SpecListenerTimeoutGrpcPropertyOutputReference;
        putGrpc(value: SpecListenerTimeoutGrpcProperty): void;
        resetGrpc(): void;
        get grpcInput(): SpecListenerTimeoutGrpcProperty | undefined;
        private _http;
        get http(): SpecListenerTimeoutHttpPropertyOutputReference;
        putHttp(value: SpecListenerTimeoutHttpProperty): void;
        resetHttp(): void;
        get httpInput(): SpecListenerTimeoutHttpProperty | undefined;
        private _http2;
        get http2(): SpecListenerTimeoutHttp2PropertyOutputReference;
        putHttp2(value: SpecListenerTimeoutHttp2Property): void;
        resetHttp2(): void;
        get http2Input(): SpecListenerTimeoutHttp2Property | undefined;
        private _tcp;
        get tcp(): SpecListenerTimeoutTcpPropertyOutputReference;
        putTcp(value: SpecListenerTimeoutTcpProperty): void;
        resetTcp(): void;
        get tcpInput(): SpecListenerTimeoutTcpProperty | undefined;
    }
    interface SpecListenerTlsCertificateAcmProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#certificate_arn AwsVirtualNode#certificate_arn}
        */
        readonly certificateArn: string;
    }
    class SpecListenerTlsCertificateAcmPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecListenerTlsCertificateAcmProperty | undefined;
        set internalValue(value: SpecListenerTlsCertificateAcmProperty | undefined);
        private _certificateArn?;
        get certificateArn(): string;
        set certificateArn(value: string);
        get certificateArnInput(): string | undefined;
    }
    interface SpecListenerTlsCertificateFileProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#certificate_chain AwsVirtualNode#certificate_chain}
        */
        readonly certificateChain: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#private_key AwsVirtualNode#private_key}
        */
        readonly privateKey: string;
    }
    class SpecListenerTlsCertificateFilePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecListenerTlsCertificateFileProperty | undefined;
        set internalValue(value: SpecListenerTlsCertificateFileProperty | undefined);
        private _certificateChain?;
        get certificateChain(): string;
        set certificateChain(value: string);
        get certificateChainInput(): string | undefined;
        private _privateKey?;
        get privateKey(): string;
        set privateKey(value: string);
        get privateKeyInput(): string | undefined;
    }
    interface SpecListenerTlsCertificateSdsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#secret_name AwsVirtualNode#secret_name}
        */
        readonly secretName: string;
    }
    class SpecListenerTlsCertificateSdsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecListenerTlsCertificateSdsProperty | undefined;
        set internalValue(value: SpecListenerTlsCertificateSdsProperty | undefined);
        private _secretName?;
        get secretName(): string;
        set secretName(value: string);
        get secretNameInput(): string | undefined;
    }
    interface SpecListenerTlsCertificateProperty {
        /**
        * acm block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#acm AwsVirtualNode#acm}
        */
        readonly acm?: SpecListenerTlsCertificateAcmProperty;
        /**
        * file block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#file AwsVirtualNode#file}
        */
        readonly file?: SpecListenerTlsCertificateFileProperty;
        /**
        * sds block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#sds AwsVirtualNode#sds}
        */
        readonly sds?: SpecListenerTlsCertificateSdsProperty;
    }
    class SpecListenerTlsCertificatePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecListenerTlsCertificateProperty | undefined;
        set internalValue(value: SpecListenerTlsCertificateProperty | undefined);
        private _acm;
        get acm(): SpecListenerTlsCertificateAcmPropertyOutputReference;
        putAcm(value: SpecListenerTlsCertificateAcmProperty): void;
        resetAcm(): void;
        get acmInput(): SpecListenerTlsCertificateAcmProperty | undefined;
        private _file;
        get file(): SpecListenerTlsCertificateFilePropertyOutputReference;
        putFile(value: SpecListenerTlsCertificateFileProperty): void;
        resetFile(): void;
        get fileInput(): SpecListenerTlsCertificateFileProperty | undefined;
        private _sds;
        get sds(): SpecListenerTlsCertificateSdsPropertyOutputReference;
        putSds(value: SpecListenerTlsCertificateSdsProperty): void;
        resetSds(): void;
        get sdsInput(): SpecListenerTlsCertificateSdsProperty | undefined;
    }
    interface SpecListenerTlsValidationSubjectAlternativeNamesMatchProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#exact AwsVirtualNode#exact}
        */
        readonly exact: string[];
    }
    class SpecListenerTlsValidationSubjectAlternativeNamesMatchPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecListenerTlsValidationSubjectAlternativeNamesMatchProperty | undefined;
        set internalValue(value: SpecListenerTlsValidationSubjectAlternativeNamesMatchProperty | undefined);
        private _exact?;
        get exact(): string[];
        set exact(value: string[]);
        get exactInput(): string[] | undefined;
    }
    interface SpecListenerTlsValidationSubjectAlternativeNamesProperty {
        /**
        * match block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#match AwsVirtualNode#match}
        */
        readonly match: SpecListenerTlsValidationSubjectAlternativeNamesMatchProperty;
    }
    class SpecListenerTlsValidationSubjectAlternativeNamesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecListenerTlsValidationSubjectAlternativeNamesProperty | undefined;
        set internalValue(value: SpecListenerTlsValidationSubjectAlternativeNamesProperty | undefined);
        private _match;
        get match(): SpecListenerTlsValidationSubjectAlternativeNamesMatchPropertyOutputReference;
        putMatch(value: SpecListenerTlsValidationSubjectAlternativeNamesMatchProperty): void;
        get matchInput(): SpecListenerTlsValidationSubjectAlternativeNamesMatchProperty | undefined;
    }
    interface SpecListenerTlsValidationTrustFileProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#certificate_chain AwsVirtualNode#certificate_chain}
        */
        readonly certificateChain: string;
    }
    class SpecListenerTlsValidationTrustFilePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecListenerTlsValidationTrustFileProperty | undefined;
        set internalValue(value: SpecListenerTlsValidationTrustFileProperty | undefined);
        private _certificateChain?;
        get certificateChain(): string;
        set certificateChain(value: string);
        get certificateChainInput(): string | undefined;
    }
    interface SpecListenerTlsValidationTrustSdsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#secret_name AwsVirtualNode#secret_name}
        */
        readonly secretName: string;
    }
    class SpecListenerTlsValidationTrustSdsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecListenerTlsValidationTrustSdsProperty | undefined;
        set internalValue(value: SpecListenerTlsValidationTrustSdsProperty | undefined);
        private _secretName?;
        get secretName(): string;
        set secretName(value: string);
        get secretNameInput(): string | undefined;
    }
    interface SpecListenerTlsValidationTrustProperty {
        /**
        * file block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#file AwsVirtualNode#file}
        */
        readonly file?: SpecListenerTlsValidationTrustFileProperty;
        /**
        * sds block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#sds AwsVirtualNode#sds}
        */
        readonly sds?: SpecListenerTlsValidationTrustSdsProperty;
    }
    class SpecListenerTlsValidationTrustPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecListenerTlsValidationTrustProperty | undefined;
        set internalValue(value: SpecListenerTlsValidationTrustProperty | undefined);
        private _file;
        get file(): SpecListenerTlsValidationTrustFilePropertyOutputReference;
        putFile(value: SpecListenerTlsValidationTrustFileProperty): void;
        resetFile(): void;
        get fileInput(): SpecListenerTlsValidationTrustFileProperty | undefined;
        private _sds;
        get sds(): SpecListenerTlsValidationTrustSdsPropertyOutputReference;
        putSds(value: SpecListenerTlsValidationTrustSdsProperty): void;
        resetSds(): void;
        get sdsInput(): SpecListenerTlsValidationTrustSdsProperty | undefined;
    }
    interface SpecListenerTlsValidationProperty {
        /**
        * subject_alternative_names block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#subject_alternative_names AwsVirtualNode#subject_alternative_names}
        */
        readonly subjectAlternativeNames?: SpecListenerTlsValidationSubjectAlternativeNamesProperty;
        /**
        * trust block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#trust AwsVirtualNode#trust}
        */
        readonly trust: SpecListenerTlsValidationTrustProperty;
    }
    class SpecListenerTlsValidationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecListenerTlsValidationProperty | undefined;
        set internalValue(value: SpecListenerTlsValidationProperty | undefined);
        private _subjectAlternativeNames;
        get subjectAlternativeNames(): SpecListenerTlsValidationSubjectAlternativeNamesPropertyOutputReference;
        putSubjectAlternativeNames(value: SpecListenerTlsValidationSubjectAlternativeNamesProperty): void;
        resetSubjectAlternativeNames(): void;
        get subjectAlternativeNamesInput(): SpecListenerTlsValidationSubjectAlternativeNamesProperty | undefined;
        private _trust;
        get trust(): SpecListenerTlsValidationTrustPropertyOutputReference;
        putTrust(value: SpecListenerTlsValidationTrustProperty): void;
        get trustInput(): SpecListenerTlsValidationTrustProperty | undefined;
    }
    interface SpecListenerTlsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#mode AwsVirtualNode#mode}
        */
        readonly mode: string;
        /**
        * certificate block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#certificate AwsVirtualNode#certificate}
        */
        readonly certificate: SpecListenerTlsCertificateProperty;
        /**
        * validation block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#validation AwsVirtualNode#validation}
        */
        readonly validation?: SpecListenerTlsValidationProperty;
    }
    class SpecListenerTlsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecListenerTlsProperty | undefined;
        set internalValue(value: SpecListenerTlsProperty | undefined);
        private _mode?;
        get mode(): string;
        set mode(value: string);
        get modeInput(): string | undefined;
        private _certificate;
        get certificate(): SpecListenerTlsCertificatePropertyOutputReference;
        putCertificate(value: SpecListenerTlsCertificateProperty): void;
        get certificateInput(): SpecListenerTlsCertificateProperty | undefined;
        private _validation;
        get validation(): SpecListenerTlsValidationPropertyOutputReference;
        putValidation(value: SpecListenerTlsValidationProperty): void;
        resetValidation(): void;
        get validationInput(): SpecListenerTlsValidationProperty | undefined;
    }
    interface ListenerProperty {
        /**
        * connection_pool block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#connection_pool AwsVirtualNode#connection_pool}
        */
        readonly connectionPool?: ConnectionPoolProperty;
        /**
        * health_check block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#health_check AwsVirtualNode#health_check}
        */
        readonly healthCheck?: HealthCheckProperty;
        /**
        * outlier_detection block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#outlier_detection AwsVirtualNode#outlier_detection}
        */
        readonly outlierDetection?: OutlierDetectionProperty;
        /**
        * port_mapping block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#port_mapping AwsVirtualNode#port_mapping}
        */
        readonly portMapping: PortMappingProperty;
        /**
        * timeout block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#timeout AwsVirtualNode#timeout}
        */
        readonly timeout?: TimeoutProperty;
        /**
        * tls block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#tls AwsVirtualNode#tls}
        */
        readonly tls?: SpecListenerTlsProperty;
    }
    class ListenerPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ListenerProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ListenerProperty | cdktn.IResolvable | undefined);
        private _connectionPool;
        get connectionPool(): ConnectionPoolPropertyOutputReference;
        putConnectionPool(value: ConnectionPoolProperty): void;
        resetConnectionPool(): void;
        get connectionPoolInput(): ConnectionPoolProperty | undefined;
        private _healthCheck;
        get healthCheck(): HealthCheckPropertyOutputReference;
        putHealthCheck(value: HealthCheckProperty): void;
        resetHealthCheck(): void;
        get healthCheckInput(): HealthCheckProperty | undefined;
        private _outlierDetection;
        get outlierDetection(): OutlierDetectionPropertyOutputReference;
        putOutlierDetection(value: OutlierDetectionProperty): void;
        resetOutlierDetection(): void;
        get outlierDetectionInput(): OutlierDetectionProperty | undefined;
        private _portMapping;
        get portMapping(): PortMappingPropertyOutputReference;
        putPortMapping(value: PortMappingProperty): void;
        get portMappingInput(): PortMappingProperty | undefined;
        private _timeout;
        get timeout(): TimeoutPropertyOutputReference;
        putTimeout(value: TimeoutProperty): void;
        resetTimeout(): void;
        get timeoutInput(): TimeoutProperty | undefined;
        private _tls;
        get tls(): SpecListenerTlsPropertyOutputReference;
        putTls(value: SpecListenerTlsProperty): void;
        resetTls(): void;
        get tlsInput(): SpecListenerTlsProperty | undefined;
    }
    class ListenerPropertyList extends cdktn.ComplexList {
        internalValue?: ListenerProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ListenerPropertyOutputReference;
    }
    interface JsonProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#key AwsVirtualNode#key}
        */
        readonly key: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#value AwsVirtualNode#value}
        */
        readonly value: string;
    }
    class JsonPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): JsonProperty | cdktn.IResolvable | undefined;
        set internalValue(value: JsonProperty | cdktn.IResolvable | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        get keyInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class JsonPropertyList extends cdktn.ComplexList {
        internalValue?: JsonProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): JsonPropertyOutputReference;
    }
    interface FormatProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#text AwsVirtualNode#text}
        */
        readonly text?: string;
        /**
        * json block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#json AwsVirtualNode#json}
        */
        readonly json?: JsonProperty[] | cdktn.IResolvable;
    }
    class FormatPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): FormatProperty | undefined;
        set internalValue(value: FormatProperty | undefined);
        private _text?;
        get text(): string;
        set text(value: string);
        resetText(): void;
        get textInput(): string | undefined;
        private _json;
        get json(): JsonPropertyList;
        putJson(value: JsonProperty[] | cdktn.IResolvable): void;
        resetJson(): void;
        get jsonInput(): cdktn.IResolvable | JsonProperty[] | undefined;
    }
    interface SpecLoggingAccessLogFileProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#path AwsVirtualNode#path}
        */
        readonly path: string;
        /**
        * format block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#format AwsVirtualNode#format}
        */
        readonly format?: FormatProperty;
    }
    class SpecLoggingAccessLogFilePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecLoggingAccessLogFileProperty | undefined;
        set internalValue(value: SpecLoggingAccessLogFileProperty | undefined);
        private _path?;
        get path(): string;
        set path(value: string);
        get pathInput(): string | undefined;
        private _format;
        get format(): FormatPropertyOutputReference;
        putFormat(value: FormatProperty): void;
        resetFormat(): void;
        get formatInput(): FormatProperty | undefined;
    }
    interface AccessLogProperty {
        /**
        * file block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#file AwsVirtualNode#file}
        */
        readonly file?: SpecLoggingAccessLogFileProperty;
    }
    class AccessLogPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AccessLogProperty | undefined;
        set internalValue(value: AccessLogProperty | undefined);
        private _file;
        get file(): SpecLoggingAccessLogFilePropertyOutputReference;
        putFile(value: SpecLoggingAccessLogFileProperty): void;
        resetFile(): void;
        get fileInput(): SpecLoggingAccessLogFileProperty | undefined;
    }
    interface LoggingProperty {
        /**
        * access_log block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#access_log AwsVirtualNode#access_log}
        */
        readonly accessLog?: AccessLogProperty;
    }
    class LoggingPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): LoggingProperty | undefined;
        set internalValue(value: LoggingProperty | undefined);
        private _accessLog;
        get accessLog(): AccessLogPropertyOutputReference;
        putAccessLog(value: AccessLogProperty): void;
        resetAccessLog(): void;
        get accessLogInput(): AccessLogProperty | undefined;
    }
    interface AwsCloudMapProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#attributes AwsVirtualNode#attributes}
        */
        readonly attributes?: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#namespace_name AwsVirtualNode#namespace_name}
        */
        readonly namespaceName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#service_name AwsVirtualNode#service_name}
        */
        readonly serviceName: string;
    }
    class AwsCloudMapPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AwsCloudMapProperty | undefined;
        set internalValue(value: AwsCloudMapProperty | undefined);
        private _attributes?;
        get attributes(): {
            [key: string]: string;
        };
        set attributes(value: {
            [key: string]: string;
        });
        resetAttributes(): void;
        get attributesInput(): {
            [key: string]: string;
        } | undefined;
        private _namespaceName?;
        get namespaceName(): string;
        set namespaceName(value: string);
        get namespaceNameInput(): string | undefined;
        private _serviceName?;
        get serviceName(): string;
        set serviceName(value: string);
        get serviceNameInput(): string | undefined;
    }
    interface DnsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#hostname AwsVirtualNode#hostname}
        */
        readonly hostname: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#ip_preference AwsVirtualNode#ip_preference}
        */
        readonly ipPreference?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#response_type AwsVirtualNode#response_type}
        */
        readonly responseType?: string;
    }
    class DnsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DnsProperty | undefined;
        set internalValue(value: DnsProperty | undefined);
        private _hostname?;
        get hostname(): string;
        set hostname(value: string);
        get hostnameInput(): string | undefined;
        private _ipPreference?;
        get ipPreference(): string;
        set ipPreference(value: string);
        resetIpPreference(): void;
        get ipPreferenceInput(): string | undefined;
        private _responseType?;
        get responseType(): string;
        set responseType(value: string);
        resetResponseType(): void;
        get responseTypeInput(): string | undefined;
    }
    interface ServiceDiscoveryProperty {
        /**
        * aws_cloud_map block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#aws_cloud_map AwsVirtualNode#aws_cloud_map}
        */
        readonly awsCloudMap?: AwsCloudMapProperty;
        /**
        * dns block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#dns AwsVirtualNode#dns}
        */
        readonly dns?: DnsProperty;
    }
    class ServiceDiscoveryPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ServiceDiscoveryProperty | undefined;
        set internalValue(value: ServiceDiscoveryProperty | undefined);
        private _awsCloudMap;
        get awsCloudMap(): AwsCloudMapPropertyOutputReference;
        putAwsCloudMap(value: AwsCloudMapProperty): void;
        resetAwsCloudMap(): void;
        get awsCloudMapInput(): AwsCloudMapProperty | undefined;
        private _dns;
        get dns(): DnsPropertyOutputReference;
        putDns(value: DnsProperty): void;
        resetDns(): void;
        get dnsInput(): DnsProperty | undefined;
    }
    interface SpecProperty {
        /**
        * backend block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#backend AwsVirtualNode#backend}
        */
        readonly backend?: BackendProperty[] | cdktn.IResolvable;
        /**
        * backend_defaults block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#backend_defaults AwsVirtualNode#backend_defaults}
        */
        readonly backendDefaults?: BackendDefaultsProperty;
        /**
        * listener block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#listener AwsVirtualNode#listener}
        */
        readonly listener?: ListenerProperty[] | cdktn.IResolvable;
        /**
        * logging block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#logging AwsVirtualNode#logging}
        */
        readonly logging?: LoggingProperty;
        /**
        * service_discovery block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#service_discovery AwsVirtualNode#service_discovery}
        */
        readonly serviceDiscovery?: ServiceDiscoveryProperty;
    }
    class SpecPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecProperty | undefined;
        set internalValue(value: SpecProperty | undefined);
        private _backend;
        get backend(): BackendPropertyList;
        putBackend(value: BackendProperty[] | cdktn.IResolvable): void;
        resetBackend(): void;
        get backendInput(): cdktn.IResolvable | BackendProperty[] | undefined;
        private _backendDefaults;
        get backendDefaults(): BackendDefaultsPropertyOutputReference;
        putBackendDefaults(value: BackendDefaultsProperty): void;
        resetBackendDefaults(): void;
        get backendDefaultsInput(): BackendDefaultsProperty | undefined;
        private _listener;
        get listener(): ListenerPropertyList;
        putListener(value: ListenerProperty[] | cdktn.IResolvable): void;
        resetListener(): void;
        get listenerInput(): cdktn.IResolvable | ListenerProperty[] | undefined;
        private _logging;
        get logging(): LoggingPropertyOutputReference;
        putLogging(value: LoggingProperty): void;
        resetLogging(): void;
        get loggingInput(): LoggingProperty | undefined;
        private _serviceDiscovery;
        get serviceDiscovery(): ServiceDiscoveryPropertyOutputReference;
        putServiceDiscovery(value: ServiceDiscoveryProperty): void;
        resetServiceDiscovery(): void;
        get serviceDiscoveryInput(): ServiceDiscoveryProperty | undefined;
    }
}
