import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsVirtualGatewayConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_gateway#id AwsVirtualGateway#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_gateway#mesh_name AwsVirtualGateway#mesh_name}
    */
    readonly meshName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_gateway#mesh_owner AwsVirtualGateway#mesh_owner}
    */
    readonly meshOwner?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_gateway#name AwsVirtualGateway#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_gateway#region AwsVirtualGateway#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_gateway#tags AwsVirtualGateway#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_gateway#tags_all AwsVirtualGateway#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * spec block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_gateway#spec AwsVirtualGateway#spec}
    */
    readonly spec: AwsVirtualGateway.SpecProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_gateway aws_appmesh_virtual_gateway}
*/
export declare class AwsVirtualGateway extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_appmesh_virtual_gateway";
    /**
    * Generates CDKTN code for importing a AwsVirtualGateway resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsVirtualGateway to import
    * @param importFromId The id of the existing AwsVirtualGateway that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_gateway#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsVirtualGateway to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_gateway aws_appmesh_virtual_gateway} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsVirtualGatewayConfig
    */
    constructor(scope: Construct, id: string, config: AwsVirtualGatewayConfig);
    get arn(): string;
    get createdDate(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get lastUpdatedDate(): string;
    private _meshName?;
    get meshName(): string;
    set meshName(value: string);
    get meshNameInput(): string | undefined;
    private _meshOwner?;
    get meshOwner(): string;
    set meshOwner(value: string);
    resetMeshOwner(): void;
    get meshOwnerInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get resourceOwner(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _spec;
    get spec(): AwsVirtualGateway.SpecPropertyOutputReference;
    putSpec(value: AwsVirtualGateway.SpecProperty): void;
    get specInput(): AwsVirtualGateway.SpecProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsVirtualGatewaySpecBackendDefaultsClientPolicyTlsCertificateFilePropertyToTerraform(struct?: AwsVirtualGateway.SpecBackendDefaultsClientPolicyTlsCertificateFilePropertyOutputReference | AwsVirtualGateway.SpecBackendDefaultsClientPolicyTlsCertificateFileProperty): any;
export declare function awsVirtualGatewaySpecBackendDefaultsClientPolicyTlsCertificateFilePropertyToHclTerraform(struct?: AwsVirtualGateway.SpecBackendDefaultsClientPolicyTlsCertificateFilePropertyOutputReference | AwsVirtualGateway.SpecBackendDefaultsClientPolicyTlsCertificateFileProperty): any;
export declare function awsVirtualGatewaySpecBackendDefaultsClientPolicyTlsCertificateSdsPropertyToTerraform(struct?: AwsVirtualGateway.SpecBackendDefaultsClientPolicyTlsCertificateSdsPropertyOutputReference | AwsVirtualGateway.SpecBackendDefaultsClientPolicyTlsCertificateSdsProperty): any;
export declare function awsVirtualGatewaySpecBackendDefaultsClientPolicyTlsCertificateSdsPropertyToHclTerraform(struct?: AwsVirtualGateway.SpecBackendDefaultsClientPolicyTlsCertificateSdsPropertyOutputReference | AwsVirtualGateway.SpecBackendDefaultsClientPolicyTlsCertificateSdsProperty): any;
export declare function awsVirtualGatewaySpecBackendDefaultsClientPolicyTlsCertificatePropertyToTerraform(struct?: AwsVirtualGateway.SpecBackendDefaultsClientPolicyTlsCertificatePropertyOutputReference | AwsVirtualGateway.SpecBackendDefaultsClientPolicyTlsCertificateProperty): any;
export declare function awsVirtualGatewaySpecBackendDefaultsClientPolicyTlsCertificatePropertyToHclTerraform(struct?: AwsVirtualGateway.SpecBackendDefaultsClientPolicyTlsCertificatePropertyOutputReference | AwsVirtualGateway.SpecBackendDefaultsClientPolicyTlsCertificateProperty): any;
export declare function awsVirtualGatewaySpecBackendDefaultsClientPolicyTlsValidationSubjectAlternativeNamesMatchPropertyToTerraform(struct?: AwsVirtualGateway.SpecBackendDefaultsClientPolicyTlsValidationSubjectAlternativeNamesMatchPropertyOutputReference | AwsVirtualGateway.SpecBackendDefaultsClientPolicyTlsValidationSubjectAlternativeNamesMatchProperty): any;
export declare function awsVirtualGatewaySpecBackendDefaultsClientPolicyTlsValidationSubjectAlternativeNamesMatchPropertyToHclTerraform(struct?: AwsVirtualGateway.SpecBackendDefaultsClientPolicyTlsValidationSubjectAlternativeNamesMatchPropertyOutputReference | AwsVirtualGateway.SpecBackendDefaultsClientPolicyTlsValidationSubjectAlternativeNamesMatchProperty): any;
export declare function awsVirtualGatewaySpecBackendDefaultsClientPolicyTlsValidationSubjectAlternativeNamesPropertyToTerraform(struct?: AwsVirtualGateway.SpecBackendDefaultsClientPolicyTlsValidationSubjectAlternativeNamesPropertyOutputReference | AwsVirtualGateway.SpecBackendDefaultsClientPolicyTlsValidationSubjectAlternativeNamesProperty): any;
export declare function awsVirtualGatewaySpecBackendDefaultsClientPolicyTlsValidationSubjectAlternativeNamesPropertyToHclTerraform(struct?: AwsVirtualGateway.SpecBackendDefaultsClientPolicyTlsValidationSubjectAlternativeNamesPropertyOutputReference | AwsVirtualGateway.SpecBackendDefaultsClientPolicyTlsValidationSubjectAlternativeNamesProperty): any;
export declare function awsVirtualGatewaySpecBackendDefaultsClientPolicyTlsValidationTrustAcmPropertyToTerraform(struct?: AwsVirtualGateway.SpecBackendDefaultsClientPolicyTlsValidationTrustAcmPropertyOutputReference | AwsVirtualGateway.SpecBackendDefaultsClientPolicyTlsValidationTrustAcmProperty): any;
export declare function awsVirtualGatewaySpecBackendDefaultsClientPolicyTlsValidationTrustAcmPropertyToHclTerraform(struct?: AwsVirtualGateway.SpecBackendDefaultsClientPolicyTlsValidationTrustAcmPropertyOutputReference | AwsVirtualGateway.SpecBackendDefaultsClientPolicyTlsValidationTrustAcmProperty): any;
export declare function awsVirtualGatewaySpecBackendDefaultsClientPolicyTlsValidationTrustFilePropertyToTerraform(struct?: AwsVirtualGateway.SpecBackendDefaultsClientPolicyTlsValidationTrustFilePropertyOutputReference | AwsVirtualGateway.SpecBackendDefaultsClientPolicyTlsValidationTrustFileProperty): any;
export declare function awsVirtualGatewaySpecBackendDefaultsClientPolicyTlsValidationTrustFilePropertyToHclTerraform(struct?: AwsVirtualGateway.SpecBackendDefaultsClientPolicyTlsValidationTrustFilePropertyOutputReference | AwsVirtualGateway.SpecBackendDefaultsClientPolicyTlsValidationTrustFileProperty): any;
export declare function awsVirtualGatewaySpecBackendDefaultsClientPolicyTlsValidationTrustSdsPropertyToTerraform(struct?: AwsVirtualGateway.SpecBackendDefaultsClientPolicyTlsValidationTrustSdsPropertyOutputReference | AwsVirtualGateway.SpecBackendDefaultsClientPolicyTlsValidationTrustSdsProperty): any;
export declare function awsVirtualGatewaySpecBackendDefaultsClientPolicyTlsValidationTrustSdsPropertyToHclTerraform(struct?: AwsVirtualGateway.SpecBackendDefaultsClientPolicyTlsValidationTrustSdsPropertyOutputReference | AwsVirtualGateway.SpecBackendDefaultsClientPolicyTlsValidationTrustSdsProperty): any;
export declare function awsVirtualGatewaySpecBackendDefaultsClientPolicyTlsValidationTrustPropertyToTerraform(struct?: AwsVirtualGateway.SpecBackendDefaultsClientPolicyTlsValidationTrustPropertyOutputReference | AwsVirtualGateway.SpecBackendDefaultsClientPolicyTlsValidationTrustProperty): any;
export declare function awsVirtualGatewaySpecBackendDefaultsClientPolicyTlsValidationTrustPropertyToHclTerraform(struct?: AwsVirtualGateway.SpecBackendDefaultsClientPolicyTlsValidationTrustPropertyOutputReference | AwsVirtualGateway.SpecBackendDefaultsClientPolicyTlsValidationTrustProperty): any;
export declare function awsVirtualGatewaySpecBackendDefaultsClientPolicyTlsValidationPropertyToTerraform(struct?: AwsVirtualGateway.SpecBackendDefaultsClientPolicyTlsValidationPropertyOutputReference | AwsVirtualGateway.SpecBackendDefaultsClientPolicyTlsValidationProperty): any;
export declare function awsVirtualGatewaySpecBackendDefaultsClientPolicyTlsValidationPropertyToHclTerraform(struct?: AwsVirtualGateway.SpecBackendDefaultsClientPolicyTlsValidationPropertyOutputReference | AwsVirtualGateway.SpecBackendDefaultsClientPolicyTlsValidationProperty): any;
export declare function awsVirtualGatewaySpecBackendDefaultsClientPolicyTlsPropertyToTerraform(struct?: AwsVirtualGateway.SpecBackendDefaultsClientPolicyTlsPropertyOutputReference | AwsVirtualGateway.SpecBackendDefaultsClientPolicyTlsProperty): any;
export declare function awsVirtualGatewaySpecBackendDefaultsClientPolicyTlsPropertyToHclTerraform(struct?: AwsVirtualGateway.SpecBackendDefaultsClientPolicyTlsPropertyOutputReference | AwsVirtualGateway.SpecBackendDefaultsClientPolicyTlsProperty): any;
export declare function awsVirtualGatewayClientPolicyPropertyToTerraform(struct?: AwsVirtualGateway.ClientPolicyPropertyOutputReference | AwsVirtualGateway.ClientPolicyProperty): any;
export declare function awsVirtualGatewayClientPolicyPropertyToHclTerraform(struct?: AwsVirtualGateway.ClientPolicyPropertyOutputReference | AwsVirtualGateway.ClientPolicyProperty): any;
export declare function awsVirtualGatewayBackendDefaultsPropertyToTerraform(struct?: AwsVirtualGateway.BackendDefaultsPropertyOutputReference | AwsVirtualGateway.BackendDefaultsProperty): any;
export declare function awsVirtualGatewayBackendDefaultsPropertyToHclTerraform(struct?: AwsVirtualGateway.BackendDefaultsPropertyOutputReference | AwsVirtualGateway.BackendDefaultsProperty): any;
export declare function awsVirtualGatewayGrpcPropertyToTerraform(struct?: AwsVirtualGateway.GrpcPropertyOutputReference | AwsVirtualGateway.GrpcProperty): any;
export declare function awsVirtualGatewayGrpcPropertyToHclTerraform(struct?: AwsVirtualGateway.GrpcPropertyOutputReference | AwsVirtualGateway.GrpcProperty): any;
export declare function awsVirtualGatewayHttpPropertyToTerraform(struct?: AwsVirtualGateway.HttpPropertyOutputReference | AwsVirtualGateway.HttpProperty): any;
export declare function awsVirtualGatewayHttpPropertyToHclTerraform(struct?: AwsVirtualGateway.HttpPropertyOutputReference | AwsVirtualGateway.HttpProperty): any;
export declare function awsVirtualGatewayHttp2PropertyToTerraform(struct?: AwsVirtualGateway.Http2PropertyOutputReference | AwsVirtualGateway.Http2Property): any;
export declare function awsVirtualGatewayHttp2PropertyToHclTerraform(struct?: AwsVirtualGateway.Http2PropertyOutputReference | AwsVirtualGateway.Http2Property): any;
export declare function awsVirtualGatewayConnectionPoolPropertyToTerraform(struct?: AwsVirtualGateway.ConnectionPoolPropertyOutputReference | AwsVirtualGateway.ConnectionPoolProperty): any;
export declare function awsVirtualGatewayConnectionPoolPropertyToHclTerraform(struct?: AwsVirtualGateway.ConnectionPoolPropertyOutputReference | AwsVirtualGateway.ConnectionPoolProperty): any;
export declare function awsVirtualGatewayHealthCheckPropertyToTerraform(struct?: AwsVirtualGateway.HealthCheckPropertyOutputReference | AwsVirtualGateway.HealthCheckProperty): any;
export declare function awsVirtualGatewayHealthCheckPropertyToHclTerraform(struct?: AwsVirtualGateway.HealthCheckPropertyOutputReference | AwsVirtualGateway.HealthCheckProperty): any;
export declare function awsVirtualGatewayPortMappingPropertyToTerraform(struct?: AwsVirtualGateway.PortMappingPropertyOutputReference | AwsVirtualGateway.PortMappingProperty): any;
export declare function awsVirtualGatewayPortMappingPropertyToHclTerraform(struct?: AwsVirtualGateway.PortMappingPropertyOutputReference | AwsVirtualGateway.PortMappingProperty): any;
export declare function awsVirtualGatewaySpecListenerTlsCertificateAcmPropertyToTerraform(struct?: AwsVirtualGateway.SpecListenerTlsCertificateAcmPropertyOutputReference | AwsVirtualGateway.SpecListenerTlsCertificateAcmProperty): any;
export declare function awsVirtualGatewaySpecListenerTlsCertificateAcmPropertyToHclTerraform(struct?: AwsVirtualGateway.SpecListenerTlsCertificateAcmPropertyOutputReference | AwsVirtualGateway.SpecListenerTlsCertificateAcmProperty): any;
export declare function awsVirtualGatewaySpecListenerTlsCertificateFilePropertyToTerraform(struct?: AwsVirtualGateway.SpecListenerTlsCertificateFilePropertyOutputReference | AwsVirtualGateway.SpecListenerTlsCertificateFileProperty): any;
export declare function awsVirtualGatewaySpecListenerTlsCertificateFilePropertyToHclTerraform(struct?: AwsVirtualGateway.SpecListenerTlsCertificateFilePropertyOutputReference | AwsVirtualGateway.SpecListenerTlsCertificateFileProperty): any;
export declare function awsVirtualGatewaySpecListenerTlsCertificateSdsPropertyToTerraform(struct?: AwsVirtualGateway.SpecListenerTlsCertificateSdsPropertyOutputReference | AwsVirtualGateway.SpecListenerTlsCertificateSdsProperty): any;
export declare function awsVirtualGatewaySpecListenerTlsCertificateSdsPropertyToHclTerraform(struct?: AwsVirtualGateway.SpecListenerTlsCertificateSdsPropertyOutputReference | AwsVirtualGateway.SpecListenerTlsCertificateSdsProperty): any;
export declare function awsVirtualGatewaySpecListenerTlsCertificatePropertyToTerraform(struct?: AwsVirtualGateway.SpecListenerTlsCertificatePropertyOutputReference | AwsVirtualGateway.SpecListenerTlsCertificateProperty): any;
export declare function awsVirtualGatewaySpecListenerTlsCertificatePropertyToHclTerraform(struct?: AwsVirtualGateway.SpecListenerTlsCertificatePropertyOutputReference | AwsVirtualGateway.SpecListenerTlsCertificateProperty): any;
export declare function awsVirtualGatewaySpecListenerTlsValidationSubjectAlternativeNamesMatchPropertyToTerraform(struct?: AwsVirtualGateway.SpecListenerTlsValidationSubjectAlternativeNamesMatchPropertyOutputReference | AwsVirtualGateway.SpecListenerTlsValidationSubjectAlternativeNamesMatchProperty): any;
export declare function awsVirtualGatewaySpecListenerTlsValidationSubjectAlternativeNamesMatchPropertyToHclTerraform(struct?: AwsVirtualGateway.SpecListenerTlsValidationSubjectAlternativeNamesMatchPropertyOutputReference | AwsVirtualGateway.SpecListenerTlsValidationSubjectAlternativeNamesMatchProperty): any;
export declare function awsVirtualGatewaySpecListenerTlsValidationSubjectAlternativeNamesPropertyToTerraform(struct?: AwsVirtualGateway.SpecListenerTlsValidationSubjectAlternativeNamesPropertyOutputReference | AwsVirtualGateway.SpecListenerTlsValidationSubjectAlternativeNamesProperty): any;
export declare function awsVirtualGatewaySpecListenerTlsValidationSubjectAlternativeNamesPropertyToHclTerraform(struct?: AwsVirtualGateway.SpecListenerTlsValidationSubjectAlternativeNamesPropertyOutputReference | AwsVirtualGateway.SpecListenerTlsValidationSubjectAlternativeNamesProperty): any;
export declare function awsVirtualGatewaySpecListenerTlsValidationTrustFilePropertyToTerraform(struct?: AwsVirtualGateway.SpecListenerTlsValidationTrustFilePropertyOutputReference | AwsVirtualGateway.SpecListenerTlsValidationTrustFileProperty): any;
export declare function awsVirtualGatewaySpecListenerTlsValidationTrustFilePropertyToHclTerraform(struct?: AwsVirtualGateway.SpecListenerTlsValidationTrustFilePropertyOutputReference | AwsVirtualGateway.SpecListenerTlsValidationTrustFileProperty): any;
export declare function awsVirtualGatewaySpecListenerTlsValidationTrustSdsPropertyToTerraform(struct?: AwsVirtualGateway.SpecListenerTlsValidationTrustSdsPropertyOutputReference | AwsVirtualGateway.SpecListenerTlsValidationTrustSdsProperty): any;
export declare function awsVirtualGatewaySpecListenerTlsValidationTrustSdsPropertyToHclTerraform(struct?: AwsVirtualGateway.SpecListenerTlsValidationTrustSdsPropertyOutputReference | AwsVirtualGateway.SpecListenerTlsValidationTrustSdsProperty): any;
export declare function awsVirtualGatewaySpecListenerTlsValidationTrustPropertyToTerraform(struct?: AwsVirtualGateway.SpecListenerTlsValidationTrustPropertyOutputReference | AwsVirtualGateway.SpecListenerTlsValidationTrustProperty): any;
export declare function awsVirtualGatewaySpecListenerTlsValidationTrustPropertyToHclTerraform(struct?: AwsVirtualGateway.SpecListenerTlsValidationTrustPropertyOutputReference | AwsVirtualGateway.SpecListenerTlsValidationTrustProperty): any;
export declare function awsVirtualGatewaySpecListenerTlsValidationPropertyToTerraform(struct?: AwsVirtualGateway.SpecListenerTlsValidationPropertyOutputReference | AwsVirtualGateway.SpecListenerTlsValidationProperty): any;
export declare function awsVirtualGatewaySpecListenerTlsValidationPropertyToHclTerraform(struct?: AwsVirtualGateway.SpecListenerTlsValidationPropertyOutputReference | AwsVirtualGateway.SpecListenerTlsValidationProperty): any;
export declare function awsVirtualGatewaySpecListenerTlsPropertyToTerraform(struct?: AwsVirtualGateway.SpecListenerTlsPropertyOutputReference | AwsVirtualGateway.SpecListenerTlsProperty): any;
export declare function awsVirtualGatewaySpecListenerTlsPropertyToHclTerraform(struct?: AwsVirtualGateway.SpecListenerTlsPropertyOutputReference | AwsVirtualGateway.SpecListenerTlsProperty): any;
export declare function awsVirtualGatewayListenerPropertyToTerraform(struct?: AwsVirtualGateway.ListenerProperty | cdktn.IResolvable): any;
export declare function awsVirtualGatewayListenerPropertyToHclTerraform(struct?: AwsVirtualGateway.ListenerProperty | cdktn.IResolvable): any;
export declare function awsVirtualGatewayJsonPropertyToTerraform(struct?: AwsVirtualGateway.JsonProperty | cdktn.IResolvable): any;
export declare function awsVirtualGatewayJsonPropertyToHclTerraform(struct?: AwsVirtualGateway.JsonProperty | cdktn.IResolvable): any;
export declare function awsVirtualGatewayFormatPropertyToTerraform(struct?: AwsVirtualGateway.FormatPropertyOutputReference | AwsVirtualGateway.FormatProperty): any;
export declare function awsVirtualGatewayFormatPropertyToHclTerraform(struct?: AwsVirtualGateway.FormatPropertyOutputReference | AwsVirtualGateway.FormatProperty): any;
export declare function awsVirtualGatewaySpecLoggingAccessLogFilePropertyToTerraform(struct?: AwsVirtualGateway.SpecLoggingAccessLogFilePropertyOutputReference | AwsVirtualGateway.SpecLoggingAccessLogFileProperty): any;
export declare function awsVirtualGatewaySpecLoggingAccessLogFilePropertyToHclTerraform(struct?: AwsVirtualGateway.SpecLoggingAccessLogFilePropertyOutputReference | AwsVirtualGateway.SpecLoggingAccessLogFileProperty): any;
export declare function awsVirtualGatewayAccessLogPropertyToTerraform(struct?: AwsVirtualGateway.AccessLogPropertyOutputReference | AwsVirtualGateway.AccessLogProperty): any;
export declare function awsVirtualGatewayAccessLogPropertyToHclTerraform(struct?: AwsVirtualGateway.AccessLogPropertyOutputReference | AwsVirtualGateway.AccessLogProperty): any;
export declare function awsVirtualGatewayLoggingPropertyToTerraform(struct?: AwsVirtualGateway.LoggingPropertyOutputReference | AwsVirtualGateway.LoggingProperty): any;
export declare function awsVirtualGatewayLoggingPropertyToHclTerraform(struct?: AwsVirtualGateway.LoggingPropertyOutputReference | AwsVirtualGateway.LoggingProperty): any;
export declare function awsVirtualGatewaySpecPropertyToTerraform(struct?: AwsVirtualGateway.SpecPropertyOutputReference | AwsVirtualGateway.SpecProperty): any;
export declare function awsVirtualGatewaySpecPropertyToHclTerraform(struct?: AwsVirtualGateway.SpecPropertyOutputReference | AwsVirtualGateway.SpecProperty): any;
export declare namespace AwsVirtualGateway {
    interface SpecBackendDefaultsClientPolicyTlsCertificateFileProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_gateway#certificate_chain AwsVirtualGateway#certificate_chain}
        */
        readonly certificateChain: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_gateway#private_key AwsVirtualGateway#private_key}
        */
        readonly privateKey: string;
    }
    class SpecBackendDefaultsClientPolicyTlsCertificateFilePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecBackendDefaultsClientPolicyTlsCertificateFileProperty | undefined;
        set internalValue(value: SpecBackendDefaultsClientPolicyTlsCertificateFileProperty | undefined);
        private _certificateChain?;
        get certificateChain(): string;
        set certificateChain(value: string);
        get certificateChainInput(): string | undefined;
        private _privateKey?;
        get privateKey(): string;
        set privateKey(value: string);
        get privateKeyInput(): string | undefined;
    }
    interface SpecBackendDefaultsClientPolicyTlsCertificateSdsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_gateway#secret_name AwsVirtualGateway#secret_name}
        */
        readonly secretName: string;
    }
    class SpecBackendDefaultsClientPolicyTlsCertificateSdsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecBackendDefaultsClientPolicyTlsCertificateSdsProperty | undefined;
        set internalValue(value: SpecBackendDefaultsClientPolicyTlsCertificateSdsProperty | undefined);
        private _secretName?;
        get secretName(): string;
        set secretName(value: string);
        get secretNameInput(): string | undefined;
    }
    interface SpecBackendDefaultsClientPolicyTlsCertificateProperty {
        /**
        * file block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_gateway#file AwsVirtualGateway#file}
        */
        readonly file?: SpecBackendDefaultsClientPolicyTlsCertificateFileProperty;
        /**
        * sds block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_gateway#sds AwsVirtualGateway#sds}
        */
        readonly sds?: SpecBackendDefaultsClientPolicyTlsCertificateSdsProperty;
    }
    class SpecBackendDefaultsClientPolicyTlsCertificatePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecBackendDefaultsClientPolicyTlsCertificateProperty | undefined;
        set internalValue(value: SpecBackendDefaultsClientPolicyTlsCertificateProperty | undefined);
        private _file;
        get file(): SpecBackendDefaultsClientPolicyTlsCertificateFilePropertyOutputReference;
        putFile(value: SpecBackendDefaultsClientPolicyTlsCertificateFileProperty): void;
        resetFile(): void;
        get fileInput(): SpecBackendDefaultsClientPolicyTlsCertificateFileProperty | undefined;
        private _sds;
        get sds(): SpecBackendDefaultsClientPolicyTlsCertificateSdsPropertyOutputReference;
        putSds(value: SpecBackendDefaultsClientPolicyTlsCertificateSdsProperty): void;
        resetSds(): void;
        get sdsInput(): SpecBackendDefaultsClientPolicyTlsCertificateSdsProperty | undefined;
    }
    interface SpecBackendDefaultsClientPolicyTlsValidationSubjectAlternativeNamesMatchProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_gateway#exact AwsVirtualGateway#exact}
        */
        readonly exact: string[];
    }
    class SpecBackendDefaultsClientPolicyTlsValidationSubjectAlternativeNamesMatchPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecBackendDefaultsClientPolicyTlsValidationSubjectAlternativeNamesMatchProperty | undefined;
        set internalValue(value: SpecBackendDefaultsClientPolicyTlsValidationSubjectAlternativeNamesMatchProperty | undefined);
        private _exact?;
        get exact(): string[];
        set exact(value: string[]);
        get exactInput(): string[] | undefined;
    }
    interface SpecBackendDefaultsClientPolicyTlsValidationSubjectAlternativeNamesProperty {
        /**
        * match block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_gateway#match AwsVirtualGateway#match}
        */
        readonly match: SpecBackendDefaultsClientPolicyTlsValidationSubjectAlternativeNamesMatchProperty;
    }
    class SpecBackendDefaultsClientPolicyTlsValidationSubjectAlternativeNamesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecBackendDefaultsClientPolicyTlsValidationSubjectAlternativeNamesProperty | undefined;
        set internalValue(value: SpecBackendDefaultsClientPolicyTlsValidationSubjectAlternativeNamesProperty | undefined);
        private _match;
        get match(): SpecBackendDefaultsClientPolicyTlsValidationSubjectAlternativeNamesMatchPropertyOutputReference;
        putMatch(value: SpecBackendDefaultsClientPolicyTlsValidationSubjectAlternativeNamesMatchProperty): void;
        get matchInput(): SpecBackendDefaultsClientPolicyTlsValidationSubjectAlternativeNamesMatchProperty | undefined;
    }
    interface SpecBackendDefaultsClientPolicyTlsValidationTrustAcmProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_gateway#certificate_authority_arns AwsVirtualGateway#certificate_authority_arns}
        */
        readonly certificateAuthorityArns: string[];
    }
    class SpecBackendDefaultsClientPolicyTlsValidationTrustAcmPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecBackendDefaultsClientPolicyTlsValidationTrustAcmProperty | undefined;
        set internalValue(value: SpecBackendDefaultsClientPolicyTlsValidationTrustAcmProperty | undefined);
        private _certificateAuthorityArns?;
        get certificateAuthorityArns(): string[];
        set certificateAuthorityArns(value: string[]);
        get certificateAuthorityArnsInput(): string[] | undefined;
    }
    interface SpecBackendDefaultsClientPolicyTlsValidationTrustFileProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_gateway#certificate_chain AwsVirtualGateway#certificate_chain}
        */
        readonly certificateChain: string;
    }
    class SpecBackendDefaultsClientPolicyTlsValidationTrustFilePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecBackendDefaultsClientPolicyTlsValidationTrustFileProperty | undefined;
        set internalValue(value: SpecBackendDefaultsClientPolicyTlsValidationTrustFileProperty | undefined);
        private _certificateChain?;
        get certificateChain(): string;
        set certificateChain(value: string);
        get certificateChainInput(): string | undefined;
    }
    interface SpecBackendDefaultsClientPolicyTlsValidationTrustSdsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_gateway#secret_name AwsVirtualGateway#secret_name}
        */
        readonly secretName: string;
    }
    class SpecBackendDefaultsClientPolicyTlsValidationTrustSdsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecBackendDefaultsClientPolicyTlsValidationTrustSdsProperty | undefined;
        set internalValue(value: SpecBackendDefaultsClientPolicyTlsValidationTrustSdsProperty | undefined);
        private _secretName?;
        get secretName(): string;
        set secretName(value: string);
        get secretNameInput(): string | undefined;
    }
    interface SpecBackendDefaultsClientPolicyTlsValidationTrustProperty {
        /**
        * acm block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_gateway#acm AwsVirtualGateway#acm}
        */
        readonly acm?: SpecBackendDefaultsClientPolicyTlsValidationTrustAcmProperty;
        /**
        * file block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_gateway#file AwsVirtualGateway#file}
        */
        readonly file?: SpecBackendDefaultsClientPolicyTlsValidationTrustFileProperty;
        /**
        * sds block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_gateway#sds AwsVirtualGateway#sds}
        */
        readonly sds?: SpecBackendDefaultsClientPolicyTlsValidationTrustSdsProperty;
    }
    class SpecBackendDefaultsClientPolicyTlsValidationTrustPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecBackendDefaultsClientPolicyTlsValidationTrustProperty | undefined;
        set internalValue(value: SpecBackendDefaultsClientPolicyTlsValidationTrustProperty | undefined);
        private _acm;
        get acm(): SpecBackendDefaultsClientPolicyTlsValidationTrustAcmPropertyOutputReference;
        putAcm(value: SpecBackendDefaultsClientPolicyTlsValidationTrustAcmProperty): void;
        resetAcm(): void;
        get acmInput(): SpecBackendDefaultsClientPolicyTlsValidationTrustAcmProperty | undefined;
        private _file;
        get file(): SpecBackendDefaultsClientPolicyTlsValidationTrustFilePropertyOutputReference;
        putFile(value: SpecBackendDefaultsClientPolicyTlsValidationTrustFileProperty): void;
        resetFile(): void;
        get fileInput(): SpecBackendDefaultsClientPolicyTlsValidationTrustFileProperty | undefined;
        private _sds;
        get sds(): SpecBackendDefaultsClientPolicyTlsValidationTrustSdsPropertyOutputReference;
        putSds(value: SpecBackendDefaultsClientPolicyTlsValidationTrustSdsProperty): void;
        resetSds(): void;
        get sdsInput(): SpecBackendDefaultsClientPolicyTlsValidationTrustSdsProperty | undefined;
    }
    interface SpecBackendDefaultsClientPolicyTlsValidationProperty {
        /**
        * subject_alternative_names block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_gateway#subject_alternative_names AwsVirtualGateway#subject_alternative_names}
        */
        readonly subjectAlternativeNames?: SpecBackendDefaultsClientPolicyTlsValidationSubjectAlternativeNamesProperty;
        /**
        * trust block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_gateway#trust AwsVirtualGateway#trust}
        */
        readonly trust: SpecBackendDefaultsClientPolicyTlsValidationTrustProperty;
    }
    class SpecBackendDefaultsClientPolicyTlsValidationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecBackendDefaultsClientPolicyTlsValidationProperty | undefined;
        set internalValue(value: SpecBackendDefaultsClientPolicyTlsValidationProperty | undefined);
        private _subjectAlternativeNames;
        get subjectAlternativeNames(): SpecBackendDefaultsClientPolicyTlsValidationSubjectAlternativeNamesPropertyOutputReference;
        putSubjectAlternativeNames(value: SpecBackendDefaultsClientPolicyTlsValidationSubjectAlternativeNamesProperty): void;
        resetSubjectAlternativeNames(): void;
        get subjectAlternativeNamesInput(): SpecBackendDefaultsClientPolicyTlsValidationSubjectAlternativeNamesProperty | undefined;
        private _trust;
        get trust(): SpecBackendDefaultsClientPolicyTlsValidationTrustPropertyOutputReference;
        putTrust(value: SpecBackendDefaultsClientPolicyTlsValidationTrustProperty): void;
        get trustInput(): SpecBackendDefaultsClientPolicyTlsValidationTrustProperty | undefined;
    }
    interface SpecBackendDefaultsClientPolicyTlsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_gateway#enforce AwsVirtualGateway#enforce}
        */
        readonly enforce?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_gateway#ports AwsVirtualGateway#ports}
        */
        readonly ports?: number[];
        /**
        * certificate block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_gateway#certificate AwsVirtualGateway#certificate}
        */
        readonly certificate?: SpecBackendDefaultsClientPolicyTlsCertificateProperty;
        /**
        * validation block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_gateway#validation AwsVirtualGateway#validation}
        */
        readonly validation: SpecBackendDefaultsClientPolicyTlsValidationProperty;
    }
    class SpecBackendDefaultsClientPolicyTlsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecBackendDefaultsClientPolicyTlsProperty | undefined;
        set internalValue(value: SpecBackendDefaultsClientPolicyTlsProperty | undefined);
        private _enforce?;
        get enforce(): boolean | cdktn.IResolvable;
        set enforce(value: boolean | cdktn.IResolvable);
        resetEnforce(): void;
        get enforceInput(): boolean | cdktn.IResolvable | undefined;
        private _ports?;
        get ports(): number[];
        set ports(value: number[]);
        resetPorts(): void;
        get portsInput(): number[] | undefined;
        private _certificate;
        get certificate(): SpecBackendDefaultsClientPolicyTlsCertificatePropertyOutputReference;
        putCertificate(value: SpecBackendDefaultsClientPolicyTlsCertificateProperty): void;
        resetCertificate(): void;
        get certificateInput(): SpecBackendDefaultsClientPolicyTlsCertificateProperty | undefined;
        private _validation;
        get validation(): SpecBackendDefaultsClientPolicyTlsValidationPropertyOutputReference;
        putValidation(value: SpecBackendDefaultsClientPolicyTlsValidationProperty): void;
        get validationInput(): SpecBackendDefaultsClientPolicyTlsValidationProperty | undefined;
    }
    interface ClientPolicyProperty {
        /**
        * tls block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_gateway#tls AwsVirtualGateway#tls}
        */
        readonly tls?: SpecBackendDefaultsClientPolicyTlsProperty;
    }
    class ClientPolicyPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ClientPolicyProperty | undefined;
        set internalValue(value: ClientPolicyProperty | undefined);
        private _tls;
        get tls(): SpecBackendDefaultsClientPolicyTlsPropertyOutputReference;
        putTls(value: SpecBackendDefaultsClientPolicyTlsProperty): void;
        resetTls(): void;
        get tlsInput(): SpecBackendDefaultsClientPolicyTlsProperty | undefined;
    }
    interface BackendDefaultsProperty {
        /**
        * client_policy block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_gateway#client_policy AwsVirtualGateway#client_policy}
        */
        readonly clientPolicy?: ClientPolicyProperty;
    }
    class BackendDefaultsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): BackendDefaultsProperty | undefined;
        set internalValue(value: BackendDefaultsProperty | undefined);
        private _clientPolicy;
        get clientPolicy(): ClientPolicyPropertyOutputReference;
        putClientPolicy(value: ClientPolicyProperty): void;
        resetClientPolicy(): void;
        get clientPolicyInput(): ClientPolicyProperty | undefined;
    }
    interface GrpcProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_gateway#max_requests AwsVirtualGateway#max_requests}
        */
        readonly maxRequests: number;
    }
    class GrpcPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): GrpcProperty | undefined;
        set internalValue(value: GrpcProperty | undefined);
        private _maxRequests?;
        get maxRequests(): number;
        set maxRequests(value: number);
        get maxRequestsInput(): number | undefined;
    }
    interface HttpProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_gateway#max_connections AwsVirtualGateway#max_connections}
        */
        readonly maxConnections: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_gateway#max_pending_requests AwsVirtualGateway#max_pending_requests}
        */
        readonly maxPendingRequests?: number;
    }
    class HttpPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): HttpProperty | undefined;
        set internalValue(value: HttpProperty | undefined);
        private _maxConnections?;
        get maxConnections(): number;
        set maxConnections(value: number);
        get maxConnectionsInput(): number | undefined;
        private _maxPendingRequests?;
        get maxPendingRequests(): number;
        set maxPendingRequests(value: number);
        resetMaxPendingRequests(): void;
        get maxPendingRequestsInput(): number | undefined;
    }
    interface Http2Property {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_gateway#max_requests AwsVirtualGateway#max_requests}
        */
        readonly maxRequests: number;
    }
    class Http2PropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): Http2Property | undefined;
        set internalValue(value: Http2Property | undefined);
        private _maxRequests?;
        get maxRequests(): number;
        set maxRequests(value: number);
        get maxRequestsInput(): number | undefined;
    }
    interface ConnectionPoolProperty {
        /**
        * grpc block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_gateway#grpc AwsVirtualGateway#grpc}
        */
        readonly grpc?: GrpcProperty;
        /**
        * http block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_gateway#http AwsVirtualGateway#http}
        */
        readonly http?: HttpProperty;
        /**
        * http2 block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_gateway#http2 AwsVirtualGateway#http2}
        */
        readonly http2?: Http2Property;
    }
    class ConnectionPoolPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ConnectionPoolProperty | undefined;
        set internalValue(value: ConnectionPoolProperty | undefined);
        private _grpc;
        get grpc(): GrpcPropertyOutputReference;
        putGrpc(value: GrpcProperty): void;
        resetGrpc(): void;
        get grpcInput(): GrpcProperty | undefined;
        private _http;
        get http(): HttpPropertyOutputReference;
        putHttp(value: HttpProperty): void;
        resetHttp(): void;
        get httpInput(): HttpProperty | undefined;
        private _http2;
        get http2(): Http2PropertyOutputReference;
        putHttp2(value: Http2Property): void;
        resetHttp2(): void;
        get http2Input(): Http2Property | undefined;
    }
    interface HealthCheckProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_gateway#healthy_threshold AwsVirtualGateway#healthy_threshold}
        */
        readonly healthyThreshold: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_gateway#interval_millis AwsVirtualGateway#interval_millis}
        */
        readonly intervalMillis: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_gateway#path AwsVirtualGateway#path}
        */
        readonly path?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_gateway#port AwsVirtualGateway#port}
        */
        readonly port?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_gateway#protocol AwsVirtualGateway#protocol}
        */
        readonly protocol: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_gateway#timeout_millis AwsVirtualGateway#timeout_millis}
        */
        readonly timeoutMillis: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_gateway#unhealthy_threshold AwsVirtualGateway#unhealthy_threshold}
        */
        readonly unhealthyThreshold: number;
    }
    class HealthCheckPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): HealthCheckProperty | undefined;
        set internalValue(value: HealthCheckProperty | undefined);
        private _healthyThreshold?;
        get healthyThreshold(): number;
        set healthyThreshold(value: number);
        get healthyThresholdInput(): number | undefined;
        private _intervalMillis?;
        get intervalMillis(): number;
        set intervalMillis(value: number);
        get intervalMillisInput(): number | undefined;
        private _path?;
        get path(): string;
        set path(value: string);
        resetPath(): void;
        get pathInput(): string | undefined;
        private _port?;
        get port(): number;
        set port(value: number);
        resetPort(): void;
        get portInput(): number | undefined;
        private _protocol?;
        get protocol(): string;
        set protocol(value: string);
        get protocolInput(): string | undefined;
        private _timeoutMillis?;
        get timeoutMillis(): number;
        set timeoutMillis(value: number);
        get timeoutMillisInput(): number | undefined;
        private _unhealthyThreshold?;
        get unhealthyThreshold(): number;
        set unhealthyThreshold(value: number);
        get unhealthyThresholdInput(): number | undefined;
    }
    interface PortMappingProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_gateway#port AwsVirtualGateway#port}
        */
        readonly port: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_gateway#protocol AwsVirtualGateway#protocol}
        */
        readonly protocol: string;
    }
    class PortMappingPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): PortMappingProperty | undefined;
        set internalValue(value: PortMappingProperty | undefined);
        private _port?;
        get port(): number;
        set port(value: number);
        get portInput(): number | undefined;
        private _protocol?;
        get protocol(): string;
        set protocol(value: string);
        get protocolInput(): string | undefined;
    }
    interface SpecListenerTlsCertificateAcmProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_gateway#certificate_arn AwsVirtualGateway#certificate_arn}
        */
        readonly certificateArn: string;
    }
    class SpecListenerTlsCertificateAcmPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecListenerTlsCertificateAcmProperty | undefined;
        set internalValue(value: SpecListenerTlsCertificateAcmProperty | undefined);
        private _certificateArn?;
        get certificateArn(): string;
        set certificateArn(value: string);
        get certificateArnInput(): string | undefined;
    }
    interface SpecListenerTlsCertificateFileProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_gateway#certificate_chain AwsVirtualGateway#certificate_chain}
        */
        readonly certificateChain: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_gateway#private_key AwsVirtualGateway#private_key}
        */
        readonly privateKey: string;
    }
    class SpecListenerTlsCertificateFilePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecListenerTlsCertificateFileProperty | undefined;
        set internalValue(value: SpecListenerTlsCertificateFileProperty | undefined);
        private _certificateChain?;
        get certificateChain(): string;
        set certificateChain(value: string);
        get certificateChainInput(): string | undefined;
        private _privateKey?;
        get privateKey(): string;
        set privateKey(value: string);
        get privateKeyInput(): string | undefined;
    }
    interface SpecListenerTlsCertificateSdsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_gateway#secret_name AwsVirtualGateway#secret_name}
        */
        readonly secretName: string;
    }
    class SpecListenerTlsCertificateSdsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecListenerTlsCertificateSdsProperty | undefined;
        set internalValue(value: SpecListenerTlsCertificateSdsProperty | undefined);
        private _secretName?;
        get secretName(): string;
        set secretName(value: string);
        get secretNameInput(): string | undefined;
    }
    interface SpecListenerTlsCertificateProperty {
        /**
        * acm block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_gateway#acm AwsVirtualGateway#acm}
        */
        readonly acm?: SpecListenerTlsCertificateAcmProperty;
        /**
        * file block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_gateway#file AwsVirtualGateway#file}
        */
        readonly file?: SpecListenerTlsCertificateFileProperty;
        /**
        * sds block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_gateway#sds AwsVirtualGateway#sds}
        */
        readonly sds?: SpecListenerTlsCertificateSdsProperty;
    }
    class SpecListenerTlsCertificatePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecListenerTlsCertificateProperty | undefined;
        set internalValue(value: SpecListenerTlsCertificateProperty | undefined);
        private _acm;
        get acm(): SpecListenerTlsCertificateAcmPropertyOutputReference;
        putAcm(value: SpecListenerTlsCertificateAcmProperty): void;
        resetAcm(): void;
        get acmInput(): SpecListenerTlsCertificateAcmProperty | undefined;
        private _file;
        get file(): SpecListenerTlsCertificateFilePropertyOutputReference;
        putFile(value: SpecListenerTlsCertificateFileProperty): void;
        resetFile(): void;
        get fileInput(): SpecListenerTlsCertificateFileProperty | undefined;
        private _sds;
        get sds(): SpecListenerTlsCertificateSdsPropertyOutputReference;
        putSds(value: SpecListenerTlsCertificateSdsProperty): void;
        resetSds(): void;
        get sdsInput(): SpecListenerTlsCertificateSdsProperty | undefined;
    }
    interface SpecListenerTlsValidationSubjectAlternativeNamesMatchProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_gateway#exact AwsVirtualGateway#exact}
        */
        readonly exact: string[];
    }
    class SpecListenerTlsValidationSubjectAlternativeNamesMatchPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecListenerTlsValidationSubjectAlternativeNamesMatchProperty | undefined;
        set internalValue(value: SpecListenerTlsValidationSubjectAlternativeNamesMatchProperty | undefined);
        private _exact?;
        get exact(): string[];
        set exact(value: string[]);
        get exactInput(): string[] | undefined;
    }
    interface SpecListenerTlsValidationSubjectAlternativeNamesProperty {
        /**
        * match block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_gateway#match AwsVirtualGateway#match}
        */
        readonly match: SpecListenerTlsValidationSubjectAlternativeNamesMatchProperty;
    }
    class SpecListenerTlsValidationSubjectAlternativeNamesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecListenerTlsValidationSubjectAlternativeNamesProperty | undefined;
        set internalValue(value: SpecListenerTlsValidationSubjectAlternativeNamesProperty | undefined);
        private _match;
        get match(): SpecListenerTlsValidationSubjectAlternativeNamesMatchPropertyOutputReference;
        putMatch(value: SpecListenerTlsValidationSubjectAlternativeNamesMatchProperty): void;
        get matchInput(): SpecListenerTlsValidationSubjectAlternativeNamesMatchProperty | undefined;
    }
    interface SpecListenerTlsValidationTrustFileProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_gateway#certificate_chain AwsVirtualGateway#certificate_chain}
        */
        readonly certificateChain: string;
    }
    class SpecListenerTlsValidationTrustFilePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecListenerTlsValidationTrustFileProperty | undefined;
        set internalValue(value: SpecListenerTlsValidationTrustFileProperty | undefined);
        private _certificateChain?;
        get certificateChain(): string;
        set certificateChain(value: string);
        get certificateChainInput(): string | undefined;
    }
    interface SpecListenerTlsValidationTrustSdsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_gateway#secret_name AwsVirtualGateway#secret_name}
        */
        readonly secretName: string;
    }
    class SpecListenerTlsValidationTrustSdsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecListenerTlsValidationTrustSdsProperty | undefined;
        set internalValue(value: SpecListenerTlsValidationTrustSdsProperty | undefined);
        private _secretName?;
        get secretName(): string;
        set secretName(value: string);
        get secretNameInput(): string | undefined;
    }
    interface SpecListenerTlsValidationTrustProperty {
        /**
        * file block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_gateway#file AwsVirtualGateway#file}
        */
        readonly file?: SpecListenerTlsValidationTrustFileProperty;
        /**
        * sds block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_gateway#sds AwsVirtualGateway#sds}
        */
        readonly sds?: SpecListenerTlsValidationTrustSdsProperty;
    }
    class SpecListenerTlsValidationTrustPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecListenerTlsValidationTrustProperty | undefined;
        set internalValue(value: SpecListenerTlsValidationTrustProperty | undefined);
        private _file;
        get file(): SpecListenerTlsValidationTrustFilePropertyOutputReference;
        putFile(value: SpecListenerTlsValidationTrustFileProperty): void;
        resetFile(): void;
        get fileInput(): SpecListenerTlsValidationTrustFileProperty | undefined;
        private _sds;
        get sds(): SpecListenerTlsValidationTrustSdsPropertyOutputReference;
        putSds(value: SpecListenerTlsValidationTrustSdsProperty): void;
        resetSds(): void;
        get sdsInput(): SpecListenerTlsValidationTrustSdsProperty | undefined;
    }
    interface SpecListenerTlsValidationProperty {
        /**
        * subject_alternative_names block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_gateway#subject_alternative_names AwsVirtualGateway#subject_alternative_names}
        */
        readonly subjectAlternativeNames?: SpecListenerTlsValidationSubjectAlternativeNamesProperty;
        /**
        * trust block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_gateway#trust AwsVirtualGateway#trust}
        */
        readonly trust: SpecListenerTlsValidationTrustProperty;
    }
    class SpecListenerTlsValidationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecListenerTlsValidationProperty | undefined;
        set internalValue(value: SpecListenerTlsValidationProperty | undefined);
        private _subjectAlternativeNames;
        get subjectAlternativeNames(): SpecListenerTlsValidationSubjectAlternativeNamesPropertyOutputReference;
        putSubjectAlternativeNames(value: SpecListenerTlsValidationSubjectAlternativeNamesProperty): void;
        resetSubjectAlternativeNames(): void;
        get subjectAlternativeNamesInput(): SpecListenerTlsValidationSubjectAlternativeNamesProperty | undefined;
        private _trust;
        get trust(): SpecListenerTlsValidationTrustPropertyOutputReference;
        putTrust(value: SpecListenerTlsValidationTrustProperty): void;
        get trustInput(): SpecListenerTlsValidationTrustProperty | undefined;
    }
    interface SpecListenerTlsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_gateway#mode AwsVirtualGateway#mode}
        */
        readonly mode: string;
        /**
        * certificate block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_gateway#certificate AwsVirtualGateway#certificate}
        */
        readonly certificate: SpecListenerTlsCertificateProperty;
        /**
        * validation block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_gateway#validation AwsVirtualGateway#validation}
        */
        readonly validation?: SpecListenerTlsValidationProperty;
    }
    class SpecListenerTlsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecListenerTlsProperty | undefined;
        set internalValue(value: SpecListenerTlsProperty | undefined);
        private _mode?;
        get mode(): string;
        set mode(value: string);
        get modeInput(): string | undefined;
        private _certificate;
        get certificate(): SpecListenerTlsCertificatePropertyOutputReference;
        putCertificate(value: SpecListenerTlsCertificateProperty): void;
        get certificateInput(): SpecListenerTlsCertificateProperty | undefined;
        private _validation;
        get validation(): SpecListenerTlsValidationPropertyOutputReference;
        putValidation(value: SpecListenerTlsValidationProperty): void;
        resetValidation(): void;
        get validationInput(): SpecListenerTlsValidationProperty | undefined;
    }
    interface ListenerProperty {
        /**
        * connection_pool block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_gateway#connection_pool AwsVirtualGateway#connection_pool}
        */
        readonly connectionPool?: ConnectionPoolProperty;
        /**
        * health_check block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_gateway#health_check AwsVirtualGateway#health_check}
        */
        readonly healthCheck?: HealthCheckProperty;
        /**
        * port_mapping block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_gateway#port_mapping AwsVirtualGateway#port_mapping}
        */
        readonly portMapping: PortMappingProperty;
        /**
        * tls block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_gateway#tls AwsVirtualGateway#tls}
        */
        readonly tls?: SpecListenerTlsProperty;
    }
    class ListenerPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ListenerProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ListenerProperty | cdktn.IResolvable | undefined);
        private _connectionPool;
        get connectionPool(): ConnectionPoolPropertyOutputReference;
        putConnectionPool(value: ConnectionPoolProperty): void;
        resetConnectionPool(): void;
        get connectionPoolInput(): ConnectionPoolProperty | undefined;
        private _healthCheck;
        get healthCheck(): HealthCheckPropertyOutputReference;
        putHealthCheck(value: HealthCheckProperty): void;
        resetHealthCheck(): void;
        get healthCheckInput(): HealthCheckProperty | undefined;
        private _portMapping;
        get portMapping(): PortMappingPropertyOutputReference;
        putPortMapping(value: PortMappingProperty): void;
        get portMappingInput(): PortMappingProperty | undefined;
        private _tls;
        get tls(): SpecListenerTlsPropertyOutputReference;
        putTls(value: SpecListenerTlsProperty): void;
        resetTls(): void;
        get tlsInput(): SpecListenerTlsProperty | undefined;
    }
    class ListenerPropertyList extends cdktn.ComplexList {
        internalValue?: ListenerProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ListenerPropertyOutputReference;
    }
    interface JsonProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_gateway#key AwsVirtualGateway#key}
        */
        readonly key: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_gateway#value AwsVirtualGateway#value}
        */
        readonly value: string;
    }
    class JsonPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): JsonProperty | cdktn.IResolvable | undefined;
        set internalValue(value: JsonProperty | cdktn.IResolvable | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        get keyInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class JsonPropertyList extends cdktn.ComplexList {
        internalValue?: JsonProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): JsonPropertyOutputReference;
    }
    interface FormatProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_gateway#text AwsVirtualGateway#text}
        */
        readonly text?: string;
        /**
        * json block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_gateway#json AwsVirtualGateway#json}
        */
        readonly json?: JsonProperty[] | cdktn.IResolvable;
    }
    class FormatPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): FormatProperty | undefined;
        set internalValue(value: FormatProperty | undefined);
        private _text?;
        get text(): string;
        set text(value: string);
        resetText(): void;
        get textInput(): string | undefined;
        private _json;
        get json(): JsonPropertyList;
        putJson(value: JsonProperty[] | cdktn.IResolvable): void;
        resetJson(): void;
        get jsonInput(): cdktn.IResolvable | JsonProperty[] | undefined;
    }
    interface SpecLoggingAccessLogFileProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_gateway#path AwsVirtualGateway#path}
        */
        readonly path: string;
        /**
        * format block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_gateway#format AwsVirtualGateway#format}
        */
        readonly format?: FormatProperty;
    }
    class SpecLoggingAccessLogFilePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecLoggingAccessLogFileProperty | undefined;
        set internalValue(value: SpecLoggingAccessLogFileProperty | undefined);
        private _path?;
        get path(): string;
        set path(value: string);
        get pathInput(): string | undefined;
        private _format;
        get format(): FormatPropertyOutputReference;
        putFormat(value: FormatProperty): void;
        resetFormat(): void;
        get formatInput(): FormatProperty | undefined;
    }
    interface AccessLogProperty {
        /**
        * file block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_gateway#file AwsVirtualGateway#file}
        */
        readonly file?: SpecLoggingAccessLogFileProperty;
    }
    class AccessLogPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AccessLogProperty | undefined;
        set internalValue(value: AccessLogProperty | undefined);
        private _file;
        get file(): SpecLoggingAccessLogFilePropertyOutputReference;
        putFile(value: SpecLoggingAccessLogFileProperty): void;
        resetFile(): void;
        get fileInput(): SpecLoggingAccessLogFileProperty | undefined;
    }
    interface LoggingProperty {
        /**
        * access_log block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_gateway#access_log AwsVirtualGateway#access_log}
        */
        readonly accessLog?: AccessLogProperty;
    }
    class LoggingPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): LoggingProperty | undefined;
        set internalValue(value: LoggingProperty | undefined);
        private _accessLog;
        get accessLog(): AccessLogPropertyOutputReference;
        putAccessLog(value: AccessLogProperty): void;
        resetAccessLog(): void;
        get accessLogInput(): AccessLogProperty | undefined;
    }
    interface SpecProperty {
        /**
        * backend_defaults block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_gateway#backend_defaults AwsVirtualGateway#backend_defaults}
        */
        readonly backendDefaults?: BackendDefaultsProperty;
        /**
        * listener block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_gateway#listener AwsVirtualGateway#listener}
        */
        readonly listener: ListenerProperty[] | cdktn.IResolvable;
        /**
        * logging block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_gateway#logging AwsVirtualGateway#logging}
        */
        readonly logging?: LoggingProperty;
    }
    class SpecPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecProperty | undefined;
        set internalValue(value: SpecProperty | undefined);
        private _backendDefaults;
        get backendDefaults(): BackendDefaultsPropertyOutputReference;
        putBackendDefaults(value: BackendDefaultsProperty): void;
        resetBackendDefaults(): void;
        get backendDefaultsInput(): BackendDefaultsProperty | undefined;
        private _listener;
        get listener(): ListenerPropertyList;
        putListener(value: ListenerProperty[] | cdktn.IResolvable): void;
        get listenerInput(): cdktn.IResolvable | ListenerProperty[] | undefined;
        private _logging;
        get logging(): LoggingPropertyOutputReference;
        putLogging(value: LoggingProperty): void;
        resetLogging(): void;
        get loggingInput(): LoggingProperty | undefined;
    }
}
