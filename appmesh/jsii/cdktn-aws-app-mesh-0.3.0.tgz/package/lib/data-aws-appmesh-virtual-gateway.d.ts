import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsVirtualGatewayConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/appmesh_virtual_gateway#id DataAwsVirtualGateway#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/appmesh_virtual_gateway#mesh_name DataAwsVirtualGateway#mesh_name}
    */
    readonly meshName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/appmesh_virtual_gateway#name DataAwsVirtualGateway#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/appmesh_virtual_gateway#region DataAwsVirtualGateway#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/appmesh_virtual_gateway#tags DataAwsVirtualGateway#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/appmesh_virtual_gateway aws_appmesh_virtual_gateway}
*/
export declare class DataAwsVirtualGateway extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_appmesh_virtual_gateway";
    /**
    * Generates CDKTN code for importing a DataAwsVirtualGateway resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsVirtualGateway to import
    * @param importFromId The id of the existing DataAwsVirtualGateway that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/appmesh_virtual_gateway#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsVirtualGateway to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/appmesh_virtual_gateway aws_appmesh_virtual_gateway} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsVirtualGatewayConfig
    */
    constructor(scope: Construct, id: string, config: DataAwsVirtualGatewayConfig);
    get arn(): string;
    get createdDate(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get lastUpdatedDate(): string;
    private _meshName?;
    get meshName(): string;
    set meshName(value: string);
    get meshNameInput(): string | undefined;
    get meshOwner(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get resourceOwner(): string;
    private _spec;
    get spec(): DataAwsVirtualGateway.SpecPropertyList;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataAwsVirtualGatewaySpecBackendDefaultsClientPolicyTlsCertificateFilePropertyToTerraform(struct?: DataAwsVirtualGateway.SpecBackendDefaultsClientPolicyTlsCertificateFileProperty): any;
export declare function dataAwsVirtualGatewaySpecBackendDefaultsClientPolicyTlsCertificateFilePropertyToHclTerraform(struct?: DataAwsVirtualGateway.SpecBackendDefaultsClientPolicyTlsCertificateFileProperty): any;
export declare function dataAwsVirtualGatewaySpecBackendDefaultsClientPolicyTlsCertificateSdsPropertyToTerraform(struct?: DataAwsVirtualGateway.SpecBackendDefaultsClientPolicyTlsCertificateSdsProperty): any;
export declare function dataAwsVirtualGatewaySpecBackendDefaultsClientPolicyTlsCertificateSdsPropertyToHclTerraform(struct?: DataAwsVirtualGateway.SpecBackendDefaultsClientPolicyTlsCertificateSdsProperty): any;
export declare function dataAwsVirtualGatewaySpecBackendDefaultsClientPolicyTlsCertificatePropertyToTerraform(struct?: DataAwsVirtualGateway.SpecBackendDefaultsClientPolicyTlsCertificateProperty): any;
export declare function dataAwsVirtualGatewaySpecBackendDefaultsClientPolicyTlsCertificatePropertyToHclTerraform(struct?: DataAwsVirtualGateway.SpecBackendDefaultsClientPolicyTlsCertificateProperty): any;
export declare function dataAwsVirtualGatewaySpecBackendDefaultsClientPolicyTlsValidationSubjectAlternativeNamesMatchPropertyToTerraform(struct?: DataAwsVirtualGateway.SpecBackendDefaultsClientPolicyTlsValidationSubjectAlternativeNamesMatchProperty): any;
export declare function dataAwsVirtualGatewaySpecBackendDefaultsClientPolicyTlsValidationSubjectAlternativeNamesMatchPropertyToHclTerraform(struct?: DataAwsVirtualGateway.SpecBackendDefaultsClientPolicyTlsValidationSubjectAlternativeNamesMatchProperty): any;
export declare function dataAwsVirtualGatewaySpecBackendDefaultsClientPolicyTlsValidationSubjectAlternativeNamesPropertyToTerraform(struct?: DataAwsVirtualGateway.SpecBackendDefaultsClientPolicyTlsValidationSubjectAlternativeNamesProperty): any;
export declare function dataAwsVirtualGatewaySpecBackendDefaultsClientPolicyTlsValidationSubjectAlternativeNamesPropertyToHclTerraform(struct?: DataAwsVirtualGateway.SpecBackendDefaultsClientPolicyTlsValidationSubjectAlternativeNamesProperty): any;
export declare function dataAwsVirtualGatewaySpecBackendDefaultsClientPolicyTlsValidationTrustAcmPropertyToTerraform(struct?: DataAwsVirtualGateway.SpecBackendDefaultsClientPolicyTlsValidationTrustAcmProperty): any;
export declare function dataAwsVirtualGatewaySpecBackendDefaultsClientPolicyTlsValidationTrustAcmPropertyToHclTerraform(struct?: DataAwsVirtualGateway.SpecBackendDefaultsClientPolicyTlsValidationTrustAcmProperty): any;
export declare function dataAwsVirtualGatewaySpecBackendDefaultsClientPolicyTlsValidationTrustFilePropertyToTerraform(struct?: DataAwsVirtualGateway.SpecBackendDefaultsClientPolicyTlsValidationTrustFileProperty): any;
export declare function dataAwsVirtualGatewaySpecBackendDefaultsClientPolicyTlsValidationTrustFilePropertyToHclTerraform(struct?: DataAwsVirtualGateway.SpecBackendDefaultsClientPolicyTlsValidationTrustFileProperty): any;
export declare function dataAwsVirtualGatewaySpecBackendDefaultsClientPolicyTlsValidationTrustSdsPropertyToTerraform(struct?: DataAwsVirtualGateway.SpecBackendDefaultsClientPolicyTlsValidationTrustSdsProperty): any;
export declare function dataAwsVirtualGatewaySpecBackendDefaultsClientPolicyTlsValidationTrustSdsPropertyToHclTerraform(struct?: DataAwsVirtualGateway.SpecBackendDefaultsClientPolicyTlsValidationTrustSdsProperty): any;
export declare function dataAwsVirtualGatewaySpecBackendDefaultsClientPolicyTlsValidationTrustPropertyToTerraform(struct?: DataAwsVirtualGateway.SpecBackendDefaultsClientPolicyTlsValidationTrustProperty): any;
export declare function dataAwsVirtualGatewaySpecBackendDefaultsClientPolicyTlsValidationTrustPropertyToHclTerraform(struct?: DataAwsVirtualGateway.SpecBackendDefaultsClientPolicyTlsValidationTrustProperty): any;
export declare function dataAwsVirtualGatewaySpecBackendDefaultsClientPolicyTlsValidationPropertyToTerraform(struct?: DataAwsVirtualGateway.SpecBackendDefaultsClientPolicyTlsValidationProperty): any;
export declare function dataAwsVirtualGatewaySpecBackendDefaultsClientPolicyTlsValidationPropertyToHclTerraform(struct?: DataAwsVirtualGateway.SpecBackendDefaultsClientPolicyTlsValidationProperty): any;
export declare function dataAwsVirtualGatewaySpecBackendDefaultsClientPolicyTlsPropertyToTerraform(struct?: DataAwsVirtualGateway.SpecBackendDefaultsClientPolicyTlsProperty): any;
export declare function dataAwsVirtualGatewaySpecBackendDefaultsClientPolicyTlsPropertyToHclTerraform(struct?: DataAwsVirtualGateway.SpecBackendDefaultsClientPolicyTlsProperty): any;
export declare function dataAwsVirtualGatewayClientPolicyPropertyToTerraform(struct?: DataAwsVirtualGateway.ClientPolicyProperty): any;
export declare function dataAwsVirtualGatewayClientPolicyPropertyToHclTerraform(struct?: DataAwsVirtualGateway.ClientPolicyProperty): any;
export declare function dataAwsVirtualGatewayBackendDefaultsPropertyToTerraform(struct?: DataAwsVirtualGateway.BackendDefaultsProperty): any;
export declare function dataAwsVirtualGatewayBackendDefaultsPropertyToHclTerraform(struct?: DataAwsVirtualGateway.BackendDefaultsProperty): any;
export declare function dataAwsVirtualGatewayGrpcPropertyToTerraform(struct?: DataAwsVirtualGateway.GrpcProperty): any;
export declare function dataAwsVirtualGatewayGrpcPropertyToHclTerraform(struct?: DataAwsVirtualGateway.GrpcProperty): any;
export declare function dataAwsVirtualGatewayHttpPropertyToTerraform(struct?: DataAwsVirtualGateway.HttpProperty): any;
export declare function dataAwsVirtualGatewayHttpPropertyToHclTerraform(struct?: DataAwsVirtualGateway.HttpProperty): any;
export declare function dataAwsVirtualGatewayHttp2PropertyToTerraform(struct?: DataAwsVirtualGateway.Http2Property): any;
export declare function dataAwsVirtualGatewayHttp2PropertyToHclTerraform(struct?: DataAwsVirtualGateway.Http2Property): any;
export declare function dataAwsVirtualGatewayConnectionPoolPropertyToTerraform(struct?: DataAwsVirtualGateway.ConnectionPoolProperty): any;
export declare function dataAwsVirtualGatewayConnectionPoolPropertyToHclTerraform(struct?: DataAwsVirtualGateway.ConnectionPoolProperty): any;
export declare function dataAwsVirtualGatewayHealthCheckPropertyToTerraform(struct?: DataAwsVirtualGateway.HealthCheckProperty): any;
export declare function dataAwsVirtualGatewayHealthCheckPropertyToHclTerraform(struct?: DataAwsVirtualGateway.HealthCheckProperty): any;
export declare function dataAwsVirtualGatewayPortMappingPropertyToTerraform(struct?: DataAwsVirtualGateway.PortMappingProperty): any;
export declare function dataAwsVirtualGatewayPortMappingPropertyToHclTerraform(struct?: DataAwsVirtualGateway.PortMappingProperty): any;
export declare function dataAwsVirtualGatewaySpecListenerTlsCertificateAcmPropertyToTerraform(struct?: DataAwsVirtualGateway.SpecListenerTlsCertificateAcmProperty): any;
export declare function dataAwsVirtualGatewaySpecListenerTlsCertificateAcmPropertyToHclTerraform(struct?: DataAwsVirtualGateway.SpecListenerTlsCertificateAcmProperty): any;
export declare function dataAwsVirtualGatewaySpecListenerTlsCertificateFilePropertyToTerraform(struct?: DataAwsVirtualGateway.SpecListenerTlsCertificateFileProperty): any;
export declare function dataAwsVirtualGatewaySpecListenerTlsCertificateFilePropertyToHclTerraform(struct?: DataAwsVirtualGateway.SpecListenerTlsCertificateFileProperty): any;
export declare function dataAwsVirtualGatewaySpecListenerTlsCertificateSdsPropertyToTerraform(struct?: DataAwsVirtualGateway.SpecListenerTlsCertificateSdsProperty): any;
export declare function dataAwsVirtualGatewaySpecListenerTlsCertificateSdsPropertyToHclTerraform(struct?: DataAwsVirtualGateway.SpecListenerTlsCertificateSdsProperty): any;
export declare function dataAwsVirtualGatewaySpecListenerTlsCertificatePropertyToTerraform(struct?: DataAwsVirtualGateway.SpecListenerTlsCertificateProperty): any;
export declare function dataAwsVirtualGatewaySpecListenerTlsCertificatePropertyToHclTerraform(struct?: DataAwsVirtualGateway.SpecListenerTlsCertificateProperty): any;
export declare function dataAwsVirtualGatewaySpecListenerTlsValidationSubjectAlternativeNamesMatchPropertyToTerraform(struct?: DataAwsVirtualGateway.SpecListenerTlsValidationSubjectAlternativeNamesMatchProperty): any;
export declare function dataAwsVirtualGatewaySpecListenerTlsValidationSubjectAlternativeNamesMatchPropertyToHclTerraform(struct?: DataAwsVirtualGateway.SpecListenerTlsValidationSubjectAlternativeNamesMatchProperty): any;
export declare function dataAwsVirtualGatewaySpecListenerTlsValidationSubjectAlternativeNamesPropertyToTerraform(struct?: DataAwsVirtualGateway.SpecListenerTlsValidationSubjectAlternativeNamesProperty): any;
export declare function dataAwsVirtualGatewaySpecListenerTlsValidationSubjectAlternativeNamesPropertyToHclTerraform(struct?: DataAwsVirtualGateway.SpecListenerTlsValidationSubjectAlternativeNamesProperty): any;
export declare function dataAwsVirtualGatewaySpecListenerTlsValidationTrustFilePropertyToTerraform(struct?: DataAwsVirtualGateway.SpecListenerTlsValidationTrustFileProperty): any;
export declare function dataAwsVirtualGatewaySpecListenerTlsValidationTrustFilePropertyToHclTerraform(struct?: DataAwsVirtualGateway.SpecListenerTlsValidationTrustFileProperty): any;
export declare function dataAwsVirtualGatewaySpecListenerTlsValidationTrustSdsPropertyToTerraform(struct?: DataAwsVirtualGateway.SpecListenerTlsValidationTrustSdsProperty): any;
export declare function dataAwsVirtualGatewaySpecListenerTlsValidationTrustSdsPropertyToHclTerraform(struct?: DataAwsVirtualGateway.SpecListenerTlsValidationTrustSdsProperty): any;
export declare function dataAwsVirtualGatewaySpecListenerTlsValidationTrustPropertyToTerraform(struct?: DataAwsVirtualGateway.SpecListenerTlsValidationTrustProperty): any;
export declare function dataAwsVirtualGatewaySpecListenerTlsValidationTrustPropertyToHclTerraform(struct?: DataAwsVirtualGateway.SpecListenerTlsValidationTrustProperty): any;
export declare function dataAwsVirtualGatewaySpecListenerTlsValidationPropertyToTerraform(struct?: DataAwsVirtualGateway.SpecListenerTlsValidationProperty): any;
export declare function dataAwsVirtualGatewaySpecListenerTlsValidationPropertyToHclTerraform(struct?: DataAwsVirtualGateway.SpecListenerTlsValidationProperty): any;
export declare function dataAwsVirtualGatewaySpecListenerTlsPropertyToTerraform(struct?: DataAwsVirtualGateway.SpecListenerTlsProperty): any;
export declare function dataAwsVirtualGatewaySpecListenerTlsPropertyToHclTerraform(struct?: DataAwsVirtualGateway.SpecListenerTlsProperty): any;
export declare function dataAwsVirtualGatewayListenerPropertyToTerraform(struct?: DataAwsVirtualGateway.ListenerProperty): any;
export declare function dataAwsVirtualGatewayListenerPropertyToHclTerraform(struct?: DataAwsVirtualGateway.ListenerProperty): any;
export declare function dataAwsVirtualGatewayJsonPropertyToTerraform(struct?: DataAwsVirtualGateway.JsonProperty): any;
export declare function dataAwsVirtualGatewayJsonPropertyToHclTerraform(struct?: DataAwsVirtualGateway.JsonProperty): any;
export declare function dataAwsVirtualGatewayFormatPropertyToTerraform(struct?: DataAwsVirtualGateway.FormatProperty): any;
export declare function dataAwsVirtualGatewayFormatPropertyToHclTerraform(struct?: DataAwsVirtualGateway.FormatProperty): any;
export declare function dataAwsVirtualGatewaySpecLoggingAccessLogFilePropertyToTerraform(struct?: DataAwsVirtualGateway.SpecLoggingAccessLogFileProperty): any;
export declare function dataAwsVirtualGatewaySpecLoggingAccessLogFilePropertyToHclTerraform(struct?: DataAwsVirtualGateway.SpecLoggingAccessLogFileProperty): any;
export declare function dataAwsVirtualGatewayAccessLogPropertyToTerraform(struct?: DataAwsVirtualGateway.AccessLogProperty): any;
export declare function dataAwsVirtualGatewayAccessLogPropertyToHclTerraform(struct?: DataAwsVirtualGateway.AccessLogProperty): any;
export declare function dataAwsVirtualGatewayLoggingPropertyToTerraform(struct?: DataAwsVirtualGateway.LoggingProperty): any;
export declare function dataAwsVirtualGatewayLoggingPropertyToHclTerraform(struct?: DataAwsVirtualGateway.LoggingProperty): any;
export declare function dataAwsVirtualGatewaySpecPropertyToTerraform(struct?: DataAwsVirtualGateway.SpecProperty): any;
export declare function dataAwsVirtualGatewaySpecPropertyToHclTerraform(struct?: DataAwsVirtualGateway.SpecProperty): any;
export declare namespace DataAwsVirtualGateway {
    interface SpecBackendDefaultsClientPolicyTlsCertificateFileProperty {
    }
    class SpecBackendDefaultsClientPolicyTlsCertificateFilePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecBackendDefaultsClientPolicyTlsCertificateFileProperty | undefined;
        set internalValue(value: SpecBackendDefaultsClientPolicyTlsCertificateFileProperty | undefined);
        get certificateChain(): string;
        get privateKey(): string;
    }
    class SpecBackendDefaultsClientPolicyTlsCertificateFilePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecBackendDefaultsClientPolicyTlsCertificateFilePropertyOutputReference;
    }
    interface SpecBackendDefaultsClientPolicyTlsCertificateSdsProperty {
    }
    class SpecBackendDefaultsClientPolicyTlsCertificateSdsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecBackendDefaultsClientPolicyTlsCertificateSdsProperty | undefined;
        set internalValue(value: SpecBackendDefaultsClientPolicyTlsCertificateSdsProperty | undefined);
        get secretName(): string;
    }
    class SpecBackendDefaultsClientPolicyTlsCertificateSdsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecBackendDefaultsClientPolicyTlsCertificateSdsPropertyOutputReference;
    }
    interface SpecBackendDefaultsClientPolicyTlsCertificateProperty {
    }
    class SpecBackendDefaultsClientPolicyTlsCertificatePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecBackendDefaultsClientPolicyTlsCertificateProperty | undefined;
        set internalValue(value: SpecBackendDefaultsClientPolicyTlsCertificateProperty | undefined);
        private _file;
        get file(): SpecBackendDefaultsClientPolicyTlsCertificateFilePropertyList;
        private _sds;
        get sds(): SpecBackendDefaultsClientPolicyTlsCertificateSdsPropertyList;
    }
    class SpecBackendDefaultsClientPolicyTlsCertificatePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecBackendDefaultsClientPolicyTlsCertificatePropertyOutputReference;
    }
    interface SpecBackendDefaultsClientPolicyTlsValidationSubjectAlternativeNamesMatchProperty {
    }
    class SpecBackendDefaultsClientPolicyTlsValidationSubjectAlternativeNamesMatchPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecBackendDefaultsClientPolicyTlsValidationSubjectAlternativeNamesMatchProperty | undefined;
        set internalValue(value: SpecBackendDefaultsClientPolicyTlsValidationSubjectAlternativeNamesMatchProperty | undefined);
        get exact(): string[];
    }
    class SpecBackendDefaultsClientPolicyTlsValidationSubjectAlternativeNamesMatchPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecBackendDefaultsClientPolicyTlsValidationSubjectAlternativeNamesMatchPropertyOutputReference;
    }
    interface SpecBackendDefaultsClientPolicyTlsValidationSubjectAlternativeNamesProperty {
    }
    class SpecBackendDefaultsClientPolicyTlsValidationSubjectAlternativeNamesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecBackendDefaultsClientPolicyTlsValidationSubjectAlternativeNamesProperty | undefined;
        set internalValue(value: SpecBackendDefaultsClientPolicyTlsValidationSubjectAlternativeNamesProperty | undefined);
        private _match;
        get match(): SpecBackendDefaultsClientPolicyTlsValidationSubjectAlternativeNamesMatchPropertyList;
    }
    class SpecBackendDefaultsClientPolicyTlsValidationSubjectAlternativeNamesPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecBackendDefaultsClientPolicyTlsValidationSubjectAlternativeNamesPropertyOutputReference;
    }
    interface SpecBackendDefaultsClientPolicyTlsValidationTrustAcmProperty {
    }
    class SpecBackendDefaultsClientPolicyTlsValidationTrustAcmPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecBackendDefaultsClientPolicyTlsValidationTrustAcmProperty | undefined;
        set internalValue(value: SpecBackendDefaultsClientPolicyTlsValidationTrustAcmProperty | undefined);
        get certificateAuthorityArns(): string[];
    }
    class SpecBackendDefaultsClientPolicyTlsValidationTrustAcmPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecBackendDefaultsClientPolicyTlsValidationTrustAcmPropertyOutputReference;
    }
    interface SpecBackendDefaultsClientPolicyTlsValidationTrustFileProperty {
    }
    class SpecBackendDefaultsClientPolicyTlsValidationTrustFilePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecBackendDefaultsClientPolicyTlsValidationTrustFileProperty | undefined;
        set internalValue(value: SpecBackendDefaultsClientPolicyTlsValidationTrustFileProperty | undefined);
        get certificateChain(): string;
    }
    class SpecBackendDefaultsClientPolicyTlsValidationTrustFilePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecBackendDefaultsClientPolicyTlsValidationTrustFilePropertyOutputReference;
    }
    interface SpecBackendDefaultsClientPolicyTlsValidationTrustSdsProperty {
    }
    class SpecBackendDefaultsClientPolicyTlsValidationTrustSdsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecBackendDefaultsClientPolicyTlsValidationTrustSdsProperty | undefined;
        set internalValue(value: SpecBackendDefaultsClientPolicyTlsValidationTrustSdsProperty | undefined);
        get secretName(): string;
    }
    class SpecBackendDefaultsClientPolicyTlsValidationTrustSdsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecBackendDefaultsClientPolicyTlsValidationTrustSdsPropertyOutputReference;
    }
    interface SpecBackendDefaultsClientPolicyTlsValidationTrustProperty {
    }
    class SpecBackendDefaultsClientPolicyTlsValidationTrustPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecBackendDefaultsClientPolicyTlsValidationTrustProperty | undefined;
        set internalValue(value: SpecBackendDefaultsClientPolicyTlsValidationTrustProperty | undefined);
        private _acm;
        get acm(): SpecBackendDefaultsClientPolicyTlsValidationTrustAcmPropertyList;
        private _file;
        get file(): SpecBackendDefaultsClientPolicyTlsValidationTrustFilePropertyList;
        private _sds;
        get sds(): SpecBackendDefaultsClientPolicyTlsValidationTrustSdsPropertyList;
    }
    class SpecBackendDefaultsClientPolicyTlsValidationTrustPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecBackendDefaultsClientPolicyTlsValidationTrustPropertyOutputReference;
    }
    interface SpecBackendDefaultsClientPolicyTlsValidationProperty {
    }
    class SpecBackendDefaultsClientPolicyTlsValidationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecBackendDefaultsClientPolicyTlsValidationProperty | undefined;
        set internalValue(value: SpecBackendDefaultsClientPolicyTlsValidationProperty | undefined);
        private _subjectAlternativeNames;
        get subjectAlternativeNames(): SpecBackendDefaultsClientPolicyTlsValidationSubjectAlternativeNamesPropertyList;
        private _trust;
        get trust(): SpecBackendDefaultsClientPolicyTlsValidationTrustPropertyList;
    }
    class SpecBackendDefaultsClientPolicyTlsValidationPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecBackendDefaultsClientPolicyTlsValidationPropertyOutputReference;
    }
    interface SpecBackendDefaultsClientPolicyTlsProperty {
    }
    class SpecBackendDefaultsClientPolicyTlsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecBackendDefaultsClientPolicyTlsProperty | undefined;
        set internalValue(value: SpecBackendDefaultsClientPolicyTlsProperty | undefined);
        private _certificate;
        get certificate(): SpecBackendDefaultsClientPolicyTlsCertificatePropertyList;
        get enforce(): cdktn.IResolvable;
        get ports(): number[];
        private _validation;
        get validation(): SpecBackendDefaultsClientPolicyTlsValidationPropertyList;
    }
    class SpecBackendDefaultsClientPolicyTlsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecBackendDefaultsClientPolicyTlsPropertyOutputReference;
    }
    interface ClientPolicyProperty {
    }
    class ClientPolicyPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ClientPolicyProperty | undefined;
        set internalValue(value: ClientPolicyProperty | undefined);
        private _tls;
        get tls(): SpecBackendDefaultsClientPolicyTlsPropertyList;
    }
    class ClientPolicyPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ClientPolicyPropertyOutputReference;
    }
    interface BackendDefaultsProperty {
    }
    class BackendDefaultsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): BackendDefaultsProperty | undefined;
        set internalValue(value: BackendDefaultsProperty | undefined);
        private _clientPolicy;
        get clientPolicy(): ClientPolicyPropertyList;
    }
    class BackendDefaultsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): BackendDefaultsPropertyOutputReference;
    }
    interface GrpcProperty {
    }
    class GrpcPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): GrpcProperty | undefined;
        set internalValue(value: GrpcProperty | undefined);
        get maxRequests(): number;
    }
    class GrpcPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): GrpcPropertyOutputReference;
    }
    interface HttpProperty {
    }
    class HttpPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): HttpProperty | undefined;
        set internalValue(value: HttpProperty | undefined);
        get maxConnections(): number;
        get maxPendingRequests(): number;
    }
    class HttpPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): HttpPropertyOutputReference;
    }
    interface Http2Property {
    }
    class Http2PropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): Http2Property | undefined;
        set internalValue(value: Http2Property | undefined);
        get maxRequests(): number;
    }
    class Http2PropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): Http2PropertyOutputReference;
    }
    interface ConnectionPoolProperty {
    }
    class ConnectionPoolPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ConnectionPoolProperty | undefined;
        set internalValue(value: ConnectionPoolProperty | undefined);
        private _grpc;
        get grpc(): GrpcPropertyList;
        private _http;
        get http(): HttpPropertyList;
        private _http2;
        get http2(): Http2PropertyList;
    }
    class ConnectionPoolPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ConnectionPoolPropertyOutputReference;
    }
    interface HealthCheckProperty {
    }
    class HealthCheckPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): HealthCheckProperty | undefined;
        set internalValue(value: HealthCheckProperty | undefined);
        get healthyThreshold(): number;
        get intervalMillis(): number;
        get path(): string;
        get port(): number;
        get protocol(): string;
        get timeoutMillis(): number;
        get unhealthyThreshold(): number;
    }
    class HealthCheckPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): HealthCheckPropertyOutputReference;
    }
    interface PortMappingProperty {
    }
    class PortMappingPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): PortMappingProperty | undefined;
        set internalValue(value: PortMappingProperty | undefined);
        get port(): number;
        get protocol(): string;
    }
    class PortMappingPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): PortMappingPropertyOutputReference;
    }
    interface SpecListenerTlsCertificateAcmProperty {
    }
    class SpecListenerTlsCertificateAcmPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecListenerTlsCertificateAcmProperty | undefined;
        set internalValue(value: SpecListenerTlsCertificateAcmProperty | undefined);
        get certificateArn(): string;
    }
    class SpecListenerTlsCertificateAcmPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecListenerTlsCertificateAcmPropertyOutputReference;
    }
    interface SpecListenerTlsCertificateFileProperty {
    }
    class SpecListenerTlsCertificateFilePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecListenerTlsCertificateFileProperty | undefined;
        set internalValue(value: SpecListenerTlsCertificateFileProperty | undefined);
        get certificateChain(): string;
        get privateKey(): string;
    }
    class SpecListenerTlsCertificateFilePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecListenerTlsCertificateFilePropertyOutputReference;
    }
    interface SpecListenerTlsCertificateSdsProperty {
    }
    class SpecListenerTlsCertificateSdsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecListenerTlsCertificateSdsProperty | undefined;
        set internalValue(value: SpecListenerTlsCertificateSdsProperty | undefined);
        get secretName(): string;
    }
    class SpecListenerTlsCertificateSdsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecListenerTlsCertificateSdsPropertyOutputReference;
    }
    interface SpecListenerTlsCertificateProperty {
    }
    class SpecListenerTlsCertificatePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecListenerTlsCertificateProperty | undefined;
        set internalValue(value: SpecListenerTlsCertificateProperty | undefined);
        private _acm;
        get acm(): SpecListenerTlsCertificateAcmPropertyList;
        private _file;
        get file(): SpecListenerTlsCertificateFilePropertyList;
        private _sds;
        get sds(): SpecListenerTlsCertificateSdsPropertyList;
    }
    class SpecListenerTlsCertificatePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecListenerTlsCertificatePropertyOutputReference;
    }
    interface SpecListenerTlsValidationSubjectAlternativeNamesMatchProperty {
    }
    class SpecListenerTlsValidationSubjectAlternativeNamesMatchPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecListenerTlsValidationSubjectAlternativeNamesMatchProperty | undefined;
        set internalValue(value: SpecListenerTlsValidationSubjectAlternativeNamesMatchProperty | undefined);
        get exact(): string[];
    }
    class SpecListenerTlsValidationSubjectAlternativeNamesMatchPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecListenerTlsValidationSubjectAlternativeNamesMatchPropertyOutputReference;
    }
    interface SpecListenerTlsValidationSubjectAlternativeNamesProperty {
    }
    class SpecListenerTlsValidationSubjectAlternativeNamesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecListenerTlsValidationSubjectAlternativeNamesProperty | undefined;
        set internalValue(value: SpecListenerTlsValidationSubjectAlternativeNamesProperty | undefined);
        private _match;
        get match(): SpecListenerTlsValidationSubjectAlternativeNamesMatchPropertyList;
    }
    class SpecListenerTlsValidationSubjectAlternativeNamesPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecListenerTlsValidationSubjectAlternativeNamesPropertyOutputReference;
    }
    interface SpecListenerTlsValidationTrustFileProperty {
    }
    class SpecListenerTlsValidationTrustFilePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecListenerTlsValidationTrustFileProperty | undefined;
        set internalValue(value: SpecListenerTlsValidationTrustFileProperty | undefined);
        get certificateChain(): string;
    }
    class SpecListenerTlsValidationTrustFilePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecListenerTlsValidationTrustFilePropertyOutputReference;
    }
    interface SpecListenerTlsValidationTrustSdsProperty {
    }
    class SpecListenerTlsValidationTrustSdsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecListenerTlsValidationTrustSdsProperty | undefined;
        set internalValue(value: SpecListenerTlsValidationTrustSdsProperty | undefined);
        get secretName(): string;
    }
    class SpecListenerTlsValidationTrustSdsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecListenerTlsValidationTrustSdsPropertyOutputReference;
    }
    interface SpecListenerTlsValidationTrustProperty {
    }
    class SpecListenerTlsValidationTrustPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecListenerTlsValidationTrustProperty | undefined;
        set internalValue(value: SpecListenerTlsValidationTrustProperty | undefined);
        private _file;
        get file(): SpecListenerTlsValidationTrustFilePropertyList;
        private _sds;
        get sds(): SpecListenerTlsValidationTrustSdsPropertyList;
    }
    class SpecListenerTlsValidationTrustPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecListenerTlsValidationTrustPropertyOutputReference;
    }
    interface SpecListenerTlsValidationProperty {
    }
    class SpecListenerTlsValidationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecListenerTlsValidationProperty | undefined;
        set internalValue(value: SpecListenerTlsValidationProperty | undefined);
        private _subjectAlternativeNames;
        get subjectAlternativeNames(): SpecListenerTlsValidationSubjectAlternativeNamesPropertyList;
        private _trust;
        get trust(): SpecListenerTlsValidationTrustPropertyList;
    }
    class SpecListenerTlsValidationPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecListenerTlsValidationPropertyOutputReference;
    }
    interface SpecListenerTlsProperty {
    }
    class SpecListenerTlsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecListenerTlsProperty | undefined;
        set internalValue(value: SpecListenerTlsProperty | undefined);
        private _certificate;
        get certificate(): SpecListenerTlsCertificatePropertyList;
        get mode(): string;
        private _validation;
        get validation(): SpecListenerTlsValidationPropertyList;
    }
    class SpecListenerTlsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecListenerTlsPropertyOutputReference;
    }
    interface ListenerProperty {
    }
    class ListenerPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ListenerProperty | undefined;
        set internalValue(value: ListenerProperty | undefined);
        private _connectionPool;
        get connectionPool(): ConnectionPoolPropertyList;
        private _healthCheck;
        get healthCheck(): HealthCheckPropertyList;
        private _portMapping;
        get portMapping(): PortMappingPropertyList;
        private _tls;
        get tls(): SpecListenerTlsPropertyList;
    }
    class ListenerPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ListenerPropertyOutputReference;
    }
    interface JsonProperty {
    }
    class JsonPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): JsonProperty | undefined;
        set internalValue(value: JsonProperty | undefined);
        get key(): string;
        get value(): string;
    }
    class JsonPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): JsonPropertyOutputReference;
    }
    interface FormatProperty {
    }
    class FormatPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): FormatProperty | undefined;
        set internalValue(value: FormatProperty | undefined);
        private _json;
        get json(): JsonPropertyList;
        get text(): string;
    }
    class FormatPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): FormatPropertyOutputReference;
    }
    interface SpecLoggingAccessLogFileProperty {
    }
    class SpecLoggingAccessLogFilePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecLoggingAccessLogFileProperty | undefined;
        set internalValue(value: SpecLoggingAccessLogFileProperty | undefined);
        private _format;
        get format(): FormatPropertyList;
        get path(): string;
    }
    class SpecLoggingAccessLogFilePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecLoggingAccessLogFilePropertyOutputReference;
    }
    interface AccessLogProperty {
    }
    class AccessLogPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AccessLogProperty | undefined;
        set internalValue(value: AccessLogProperty | undefined);
        private _file;
        get file(): SpecLoggingAccessLogFilePropertyList;
    }
    class AccessLogPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AccessLogPropertyOutputReference;
    }
    interface LoggingProperty {
    }
    class LoggingPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): LoggingProperty | undefined;
        set internalValue(value: LoggingProperty | undefined);
        private _accessLog;
        get accessLog(): AccessLogPropertyList;
    }
    class LoggingPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): LoggingPropertyOutputReference;
    }
    interface SpecProperty {
    }
    class SpecPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecProperty | undefined;
        set internalValue(value: SpecProperty | undefined);
        private _backendDefaults;
        get backendDefaults(): BackendDefaultsPropertyList;
        private _listener;
        get listener(): ListenerPropertyList;
        private _logging;
        get logging(): LoggingPropertyList;
    }
    class SpecPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecPropertyOutputReference;
    }
}
