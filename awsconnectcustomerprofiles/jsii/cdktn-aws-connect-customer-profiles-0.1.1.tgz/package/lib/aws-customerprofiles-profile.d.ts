import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsCustomerprofilesProfileConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/customerprofiles_profile#account_number AwsCustomerprofilesProfile#account_number}
    */
    readonly accountNumber?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/customerprofiles_profile#additional_information AwsCustomerprofilesProfile#additional_information}
    */
    readonly additionalInformation?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/customerprofiles_profile#attributes AwsCustomerprofilesProfile#attributes}
    */
    readonly attributes?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/customerprofiles_profile#birth_date AwsCustomerprofilesProfile#birth_date}
    */
    readonly birthDate?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/customerprofiles_profile#business_email_address AwsCustomerprofilesProfile#business_email_address}
    */
    readonly businessEmailAddress?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/customerprofiles_profile#business_name AwsCustomerprofilesProfile#business_name}
    */
    readonly businessName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/customerprofiles_profile#business_phone_number AwsCustomerprofilesProfile#business_phone_number}
    */
    readonly businessPhoneNumber?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/customerprofiles_profile#domain_name AwsCustomerprofilesProfile#domain_name}
    */
    readonly domainName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/customerprofiles_profile#email_address AwsCustomerprofilesProfile#email_address}
    */
    readonly emailAddress?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/customerprofiles_profile#first_name AwsCustomerprofilesProfile#first_name}
    */
    readonly firstName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/customerprofiles_profile#gender_string AwsCustomerprofilesProfile#gender_string}
    */
    readonly genderString?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/customerprofiles_profile#home_phone_number AwsCustomerprofilesProfile#home_phone_number}
    */
    readonly homePhoneNumber?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/customerprofiles_profile#id AwsCustomerprofilesProfile#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/customerprofiles_profile#last_name AwsCustomerprofilesProfile#last_name}
    */
    readonly lastName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/customerprofiles_profile#middle_name AwsCustomerprofilesProfile#middle_name}
    */
    readonly middleName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/customerprofiles_profile#mobile_phone_number AwsCustomerprofilesProfile#mobile_phone_number}
    */
    readonly mobilePhoneNumber?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/customerprofiles_profile#party_type_string AwsCustomerprofilesProfile#party_type_string}
    */
    readonly partyTypeString?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/customerprofiles_profile#personal_email_address AwsCustomerprofilesProfile#personal_email_address}
    */
    readonly personalEmailAddress?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/customerprofiles_profile#phone_number AwsCustomerprofilesProfile#phone_number}
    */
    readonly phoneNumber?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/customerprofiles_profile#region AwsCustomerprofilesProfile#region}
    */
    readonly region?: string;
    /**
    * address block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/customerprofiles_profile#address AwsCustomerprofilesProfile#address}
    */
    readonly address?: AwsCustomerprofilesProfile.AddressProperty;
    /**
    * billing_address block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/customerprofiles_profile#billing_address AwsCustomerprofilesProfile#billing_address}
    */
    readonly billingAddress?: AwsCustomerprofilesProfile.BillingAddressProperty;
    /**
    * mailing_address block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/customerprofiles_profile#mailing_address AwsCustomerprofilesProfile#mailing_address}
    */
    readonly mailingAddress?: AwsCustomerprofilesProfile.MailingAddressProperty;
    /**
    * shipping_address block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/customerprofiles_profile#shipping_address AwsCustomerprofilesProfile#shipping_address}
    */
    readonly shippingAddress?: AwsCustomerprofilesProfile.ShippingAddressProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/customerprofiles_profile aws_customerprofiles_profile}
*/
export declare class AwsCustomerprofilesProfile extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_customerprofiles_profile";
    /**
    * Generates CDKTN code for importing a AwsCustomerprofilesProfile resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsCustomerprofilesProfile to import
    * @param importFromId The id of the existing AwsCustomerprofilesProfile that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/customerprofiles_profile#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsCustomerprofilesProfile to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/customerprofiles_profile aws_customerprofiles_profile} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsCustomerprofilesProfileConfig
    */
    constructor(scope: Construct, id: string, config: AwsCustomerprofilesProfileConfig);
    private _accountNumber?;
    get accountNumber(): string;
    set accountNumber(value: string);
    resetAccountNumber(): void;
    get accountNumberInput(): string | undefined;
    private _additionalInformation?;
    get additionalInformation(): string;
    set additionalInformation(value: string);
    resetAdditionalInformation(): void;
    get additionalInformationInput(): string | undefined;
    private _attributes?;
    get attributes(): {
        [key: string]: string;
    };
    set attributes(value: {
        [key: string]: string;
    });
    resetAttributes(): void;
    get attributesInput(): {
        [key: string]: string;
    } | undefined;
    private _birthDate?;
    get birthDate(): string;
    set birthDate(value: string);
    resetBirthDate(): void;
    get birthDateInput(): string | undefined;
    private _businessEmailAddress?;
    get businessEmailAddress(): string;
    set businessEmailAddress(value: string);
    resetBusinessEmailAddress(): void;
    get businessEmailAddressInput(): string | undefined;
    private _businessName?;
    get businessName(): string;
    set businessName(value: string);
    resetBusinessName(): void;
    get businessNameInput(): string | undefined;
    private _businessPhoneNumber?;
    get businessPhoneNumber(): string;
    set businessPhoneNumber(value: string);
    resetBusinessPhoneNumber(): void;
    get businessPhoneNumberInput(): string | undefined;
    private _domainName?;
    get domainName(): string;
    set domainName(value: string);
    get domainNameInput(): string | undefined;
    private _emailAddress?;
    get emailAddress(): string;
    set emailAddress(value: string);
    resetEmailAddress(): void;
    get emailAddressInput(): string | undefined;
    private _firstName?;
    get firstName(): string;
    set firstName(value: string);
    resetFirstName(): void;
    get firstNameInput(): string | undefined;
    private _genderString?;
    get genderString(): string;
    set genderString(value: string);
    resetGenderString(): void;
    get genderStringInput(): string | undefined;
    private _homePhoneNumber?;
    get homePhoneNumber(): string;
    set homePhoneNumber(value: string);
    resetHomePhoneNumber(): void;
    get homePhoneNumberInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _lastName?;
    get lastName(): string;
    set lastName(value: string);
    resetLastName(): void;
    get lastNameInput(): string | undefined;
    private _middleName?;
    get middleName(): string;
    set middleName(value: string);
    resetMiddleName(): void;
    get middleNameInput(): string | undefined;
    private _mobilePhoneNumber?;
    get mobilePhoneNumber(): string;
    set mobilePhoneNumber(value: string);
    resetMobilePhoneNumber(): void;
    get mobilePhoneNumberInput(): string | undefined;
    private _partyTypeString?;
    get partyTypeString(): string;
    set partyTypeString(value: string);
    resetPartyTypeString(): void;
    get partyTypeStringInput(): string | undefined;
    private _personalEmailAddress?;
    get personalEmailAddress(): string;
    set personalEmailAddress(value: string);
    resetPersonalEmailAddress(): void;
    get personalEmailAddressInput(): string | undefined;
    private _phoneNumber?;
    get phoneNumber(): string;
    set phoneNumber(value: string);
    resetPhoneNumber(): void;
    get phoneNumberInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _address;
    get address(): AwsCustomerprofilesProfile.AddressPropertyOutputReference;
    putAddress(value: AwsCustomerprofilesProfile.AddressProperty): void;
    resetAddress(): void;
    get addressInput(): AwsCustomerprofilesProfile.AddressProperty | undefined;
    private _billingAddress;
    get billingAddress(): AwsCustomerprofilesProfile.BillingAddressPropertyOutputReference;
    putBillingAddress(value: AwsCustomerprofilesProfile.BillingAddressProperty): void;
    resetBillingAddress(): void;
    get billingAddressInput(): AwsCustomerprofilesProfile.BillingAddressProperty | undefined;
    private _mailingAddress;
    get mailingAddress(): AwsCustomerprofilesProfile.MailingAddressPropertyOutputReference;
    putMailingAddress(value: AwsCustomerprofilesProfile.MailingAddressProperty): void;
    resetMailingAddress(): void;
    get mailingAddressInput(): AwsCustomerprofilesProfile.MailingAddressProperty | undefined;
    private _shippingAddress;
    get shippingAddress(): AwsCustomerprofilesProfile.ShippingAddressPropertyOutputReference;
    putShippingAddress(value: AwsCustomerprofilesProfile.ShippingAddressProperty): void;
    resetShippingAddress(): void;
    get shippingAddressInput(): AwsCustomerprofilesProfile.ShippingAddressProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsCustomerprofilesProfileAddressPropertyToTerraform(struct?: AwsCustomerprofilesProfile.AddressPropertyOutputReference | AwsCustomerprofilesProfile.AddressProperty): any;
export declare function awsCustomerprofilesProfileAddressPropertyToHclTerraform(struct?: AwsCustomerprofilesProfile.AddressPropertyOutputReference | AwsCustomerprofilesProfile.AddressProperty): any;
export declare function awsCustomerprofilesProfileBillingAddressPropertyToTerraform(struct?: AwsCustomerprofilesProfile.BillingAddressPropertyOutputReference | AwsCustomerprofilesProfile.BillingAddressProperty): any;
export declare function awsCustomerprofilesProfileBillingAddressPropertyToHclTerraform(struct?: AwsCustomerprofilesProfile.BillingAddressPropertyOutputReference | AwsCustomerprofilesProfile.BillingAddressProperty): any;
export declare function awsCustomerprofilesProfileMailingAddressPropertyToTerraform(struct?: AwsCustomerprofilesProfile.MailingAddressPropertyOutputReference | AwsCustomerprofilesProfile.MailingAddressProperty): any;
export declare function awsCustomerprofilesProfileMailingAddressPropertyToHclTerraform(struct?: AwsCustomerprofilesProfile.MailingAddressPropertyOutputReference | AwsCustomerprofilesProfile.MailingAddressProperty): any;
export declare function awsCustomerprofilesProfileShippingAddressPropertyToTerraform(struct?: AwsCustomerprofilesProfile.ShippingAddressPropertyOutputReference | AwsCustomerprofilesProfile.ShippingAddressProperty): any;
export declare function awsCustomerprofilesProfileShippingAddressPropertyToHclTerraform(struct?: AwsCustomerprofilesProfile.ShippingAddressPropertyOutputReference | AwsCustomerprofilesProfile.ShippingAddressProperty): any;
export declare namespace AwsCustomerprofilesProfile {
    interface AddressProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/customerprofiles_profile#address_1 AwsCustomerprofilesProfile#address_1}
        */
        readonly address1?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/customerprofiles_profile#address_2 AwsCustomerprofilesProfile#address_2}
        */
        readonly address2?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/customerprofiles_profile#address_3 AwsCustomerprofilesProfile#address_3}
        */
        readonly address3?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/customerprofiles_profile#address_4 AwsCustomerprofilesProfile#address_4}
        */
        readonly address4?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/customerprofiles_profile#city AwsCustomerprofilesProfile#city}
        */
        readonly city?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/customerprofiles_profile#country AwsCustomerprofilesProfile#country}
        */
        readonly country?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/customerprofiles_profile#county AwsCustomerprofilesProfile#county}
        */
        readonly county?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/customerprofiles_profile#postal_code AwsCustomerprofilesProfile#postal_code}
        */
        readonly postalCode?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/customerprofiles_profile#province AwsCustomerprofilesProfile#province}
        */
        readonly province?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/customerprofiles_profile#state AwsCustomerprofilesProfile#state}
        */
        readonly state?: string;
    }
    class AddressPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AddressProperty | undefined;
        set internalValue(value: AddressProperty | undefined);
        private _address1?;
        get address1(): string;
        set address1(value: string);
        resetAddress1(): void;
        get address1Input(): string | undefined;
        private _address2?;
        get address2(): string;
        set address2(value: string);
        resetAddress2(): void;
        get address2Input(): string | undefined;
        private _address3?;
        get address3(): string;
        set address3(value: string);
        resetAddress3(): void;
        get address3Input(): string | undefined;
        private _address4?;
        get address4(): string;
        set address4(value: string);
        resetAddress4(): void;
        get address4Input(): string | undefined;
        private _city?;
        get city(): string;
        set city(value: string);
        resetCity(): void;
        get cityInput(): string | undefined;
        private _country?;
        get country(): string;
        set country(value: string);
        resetCountry(): void;
        get countryInput(): string | undefined;
        private _county?;
        get county(): string;
        set county(value: string);
        resetCounty(): void;
        get countyInput(): string | undefined;
        private _postalCode?;
        get postalCode(): string;
        set postalCode(value: string);
        resetPostalCode(): void;
        get postalCodeInput(): string | undefined;
        private _province?;
        get province(): string;
        set province(value: string);
        resetProvince(): void;
        get provinceInput(): string | undefined;
        private _state?;
        get state(): string;
        set state(value: string);
        resetState(): void;
        get stateInput(): string | undefined;
    }
    interface BillingAddressProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/customerprofiles_profile#address_1 AwsCustomerprofilesProfile#address_1}
        */
        readonly address1?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/customerprofiles_profile#address_2 AwsCustomerprofilesProfile#address_2}
        */
        readonly address2?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/customerprofiles_profile#address_3 AwsCustomerprofilesProfile#address_3}
        */
        readonly address3?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/customerprofiles_profile#address_4 AwsCustomerprofilesProfile#address_4}
        */
        readonly address4?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/customerprofiles_profile#city AwsCustomerprofilesProfile#city}
        */
        readonly city?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/customerprofiles_profile#country AwsCustomerprofilesProfile#country}
        */
        readonly country?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/customerprofiles_profile#county AwsCustomerprofilesProfile#county}
        */
        readonly county?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/customerprofiles_profile#postal_code AwsCustomerprofilesProfile#postal_code}
        */
        readonly postalCode?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/customerprofiles_profile#province AwsCustomerprofilesProfile#province}
        */
        readonly province?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/customerprofiles_profile#state AwsCustomerprofilesProfile#state}
        */
        readonly state?: string;
    }
    class BillingAddressPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): BillingAddressProperty | undefined;
        set internalValue(value: BillingAddressProperty | undefined);
        private _address1?;
        get address1(): string;
        set address1(value: string);
        resetAddress1(): void;
        get address1Input(): string | undefined;
        private _address2?;
        get address2(): string;
        set address2(value: string);
        resetAddress2(): void;
        get address2Input(): string | undefined;
        private _address3?;
        get address3(): string;
        set address3(value: string);
        resetAddress3(): void;
        get address3Input(): string | undefined;
        private _address4?;
        get address4(): string;
        set address4(value: string);
        resetAddress4(): void;
        get address4Input(): string | undefined;
        private _city?;
        get city(): string;
        set city(value: string);
        resetCity(): void;
        get cityInput(): string | undefined;
        private _country?;
        get country(): string;
        set country(value: string);
        resetCountry(): void;
        get countryInput(): string | undefined;
        private _county?;
        get county(): string;
        set county(value: string);
        resetCounty(): void;
        get countyInput(): string | undefined;
        private _postalCode?;
        get postalCode(): string;
        set postalCode(value: string);
        resetPostalCode(): void;
        get postalCodeInput(): string | undefined;
        private _province?;
        get province(): string;
        set province(value: string);
        resetProvince(): void;
        get provinceInput(): string | undefined;
        private _state?;
        get state(): string;
        set state(value: string);
        resetState(): void;
        get stateInput(): string | undefined;
    }
    interface MailingAddressProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/customerprofiles_profile#address_1 AwsCustomerprofilesProfile#address_1}
        */
        readonly address1?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/customerprofiles_profile#address_2 AwsCustomerprofilesProfile#address_2}
        */
        readonly address2?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/customerprofiles_profile#address_3 AwsCustomerprofilesProfile#address_3}
        */
        readonly address3?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/customerprofiles_profile#address_4 AwsCustomerprofilesProfile#address_4}
        */
        readonly address4?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/customerprofiles_profile#city AwsCustomerprofilesProfile#city}
        */
        readonly city?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/customerprofiles_profile#country AwsCustomerprofilesProfile#country}
        */
        readonly country?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/customerprofiles_profile#county AwsCustomerprofilesProfile#county}
        */
        readonly county?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/customerprofiles_profile#postal_code AwsCustomerprofilesProfile#postal_code}
        */
        readonly postalCode?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/customerprofiles_profile#province AwsCustomerprofilesProfile#province}
        */
        readonly province?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/customerprofiles_profile#state AwsCustomerprofilesProfile#state}
        */
        readonly state?: string;
    }
    class MailingAddressPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): MailingAddressProperty | undefined;
        set internalValue(value: MailingAddressProperty | undefined);
        private _address1?;
        get address1(): string;
        set address1(value: string);
        resetAddress1(): void;
        get address1Input(): string | undefined;
        private _address2?;
        get address2(): string;
        set address2(value: string);
        resetAddress2(): void;
        get address2Input(): string | undefined;
        private _address3?;
        get address3(): string;
        set address3(value: string);
        resetAddress3(): void;
        get address3Input(): string | undefined;
        private _address4?;
        get address4(): string;
        set address4(value: string);
        resetAddress4(): void;
        get address4Input(): string | undefined;
        private _city?;
        get city(): string;
        set city(value: string);
        resetCity(): void;
        get cityInput(): string | undefined;
        private _country?;
        get country(): string;
        set country(value: string);
        resetCountry(): void;
        get countryInput(): string | undefined;
        private _county?;
        get county(): string;
        set county(value: string);
        resetCounty(): void;
        get countyInput(): string | undefined;
        private _postalCode?;
        get postalCode(): string;
        set postalCode(value: string);
        resetPostalCode(): void;
        get postalCodeInput(): string | undefined;
        private _province?;
        get province(): string;
        set province(value: string);
        resetProvince(): void;
        get provinceInput(): string | undefined;
        private _state?;
        get state(): string;
        set state(value: string);
        resetState(): void;
        get stateInput(): string | undefined;
    }
    interface ShippingAddressProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/customerprofiles_profile#address_1 AwsCustomerprofilesProfile#address_1}
        */
        readonly address1?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/customerprofiles_profile#address_2 AwsCustomerprofilesProfile#address_2}
        */
        readonly address2?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/customerprofiles_profile#address_3 AwsCustomerprofilesProfile#address_3}
        */
        readonly address3?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/customerprofiles_profile#address_4 AwsCustomerprofilesProfile#address_4}
        */
        readonly address4?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/customerprofiles_profile#city AwsCustomerprofilesProfile#city}
        */
        readonly city?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/customerprofiles_profile#country AwsCustomerprofilesProfile#country}
        */
        readonly country?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/customerprofiles_profile#county AwsCustomerprofilesProfile#county}
        */
        readonly county?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/customerprofiles_profile#postal_code AwsCustomerprofilesProfile#postal_code}
        */
        readonly postalCode?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/customerprofiles_profile#province AwsCustomerprofilesProfile#province}
        */
        readonly province?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/customerprofiles_profile#state AwsCustomerprofilesProfile#state}
        */
        readonly state?: string;
    }
    class ShippingAddressPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ShippingAddressProperty | undefined;
        set internalValue(value: ShippingAddressProperty | undefined);
        private _address1?;
        get address1(): string;
        set address1(value: string);
        resetAddress1(): void;
        get address1Input(): string | undefined;
        private _address2?;
        get address2(): string;
        set address2(value: string);
        resetAddress2(): void;
        get address2Input(): string | undefined;
        private _address3?;
        get address3(): string;
        set address3(value: string);
        resetAddress3(): void;
        get address3Input(): string | undefined;
        private _address4?;
        get address4(): string;
        set address4(value: string);
        resetAddress4(): void;
        get address4Input(): string | undefined;
        private _city?;
        get city(): string;
        set city(value: string);
        resetCity(): void;
        get cityInput(): string | undefined;
        private _country?;
        get country(): string;
        set country(value: string);
        resetCountry(): void;
        get countryInput(): string | undefined;
        private _county?;
        get county(): string;
        set county(value: string);
        resetCounty(): void;
        get countyInput(): string | undefined;
        private _postalCode?;
        get postalCode(): string;
        set postalCode(value: string);
        resetPostalCode(): void;
        get postalCodeInput(): string | undefined;
        private _province?;
        get province(): string;
        set province(value: string);
        resetProvince(): void;
        get provinceInput(): string | undefined;
        private _state?;
        get state(): string;
        set state(value: string);
        resetState(): void;
        get stateInput(): string | undefined;
    }
}
