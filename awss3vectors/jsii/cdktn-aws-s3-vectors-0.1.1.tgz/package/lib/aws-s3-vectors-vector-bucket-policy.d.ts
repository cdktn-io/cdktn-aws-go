import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsS3VectorsVectorBucketPolicyConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3vectors_vector_bucket_policy#policy AwsS3VectorsVectorBucketPolicy#policy}
    */
    readonly policy: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3vectors_vector_bucket_policy#region AwsS3VectorsVectorBucketPolicy#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3vectors_vector_bucket_policy#vector_bucket_arn AwsS3VectorsVectorBucketPolicy#vector_bucket_arn}
    */
    readonly vectorBucketArn: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3vectors_vector_bucket_policy aws_s3vectors_vector_bucket_policy}
*/
export declare class AwsS3VectorsVectorBucketPolicy extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_s3vectors_vector_bucket_policy";
    /**
    * Generates CDKTN code for importing a AwsS3VectorsVectorBucketPolicy resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsS3VectorsVectorBucketPolicy to import
    * @param importFromId The id of the existing AwsS3VectorsVectorBucketPolicy that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3vectors_vector_bucket_policy#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsS3VectorsVectorBucketPolicy to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3vectors_vector_bucket_policy aws_s3vectors_vector_bucket_policy} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsS3VectorsVectorBucketPolicyConfig
    */
    constructor(scope: Construct, id: string, config: AwsS3VectorsVectorBucketPolicyConfig);
    private _policy?;
    get policy(): string;
    set policy(value: string);
    get policyInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _vectorBucketArn?;
    get vectorBucketArn(): string;
    set vectorBucketArn(value: string);
    get vectorBucketArnInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
