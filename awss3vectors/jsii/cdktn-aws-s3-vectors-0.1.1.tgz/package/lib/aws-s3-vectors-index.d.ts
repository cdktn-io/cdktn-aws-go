import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsS3VectorsIndexConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3vectors_index#data_type AwsS3VectorsIndex#data_type}
    */
    readonly dataType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3vectors_index#dimension AwsS3VectorsIndex#dimension}
    */
    readonly dimension: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3vectors_index#distance_metric AwsS3VectorsIndex#distance_metric}
    */
    readonly distanceMetric: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3vectors_index#encryption_configuration AwsS3VectorsIndex#encryption_configuration}
    */
    readonly encryptionConfiguration?: AwsS3VectorsIndex.EncryptionConfigurationProperty[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3vectors_index#index_name AwsS3VectorsIndex#index_name}
    */
    readonly indexName: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3vectors_index#region AwsS3VectorsIndex#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3vectors_index#tags AwsS3VectorsIndex#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3vectors_index#vector_bucket_name AwsS3VectorsIndex#vector_bucket_name}
    */
    readonly vectorBucketName: string;
    /**
    * metadata_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3vectors_index#metadata_configuration AwsS3VectorsIndex#metadata_configuration}
    */
    readonly metadataConfiguration?: AwsS3VectorsIndex.MetadataConfigurationProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3vectors_index aws_s3vectors_index}
*/
export declare class AwsS3VectorsIndex extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_s3vectors_index";
    /**
    * Generates CDKTN code for importing a AwsS3VectorsIndex resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsS3VectorsIndex to import
    * @param importFromId The id of the existing AwsS3VectorsIndex that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3vectors_index#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsS3VectorsIndex to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3vectors_index aws_s3vectors_index} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsS3VectorsIndexConfig
    */
    constructor(scope: Construct, id: string, config: AwsS3VectorsIndexConfig);
    get creationTime(): string;
    private _dataType?;
    get dataType(): string;
    set dataType(value: string);
    get dataTypeInput(): string | undefined;
    private _dimension?;
    get dimension(): number;
    set dimension(value: number);
    get dimensionInput(): number | undefined;
    private _distanceMetric?;
    get distanceMetric(): string;
    set distanceMetric(value: string);
    get distanceMetricInput(): string | undefined;
    private _encryptionConfiguration;
    get encryptionConfiguration(): AwsS3VectorsIndex.EncryptionConfigurationPropertyList;
    putEncryptionConfiguration(value: AwsS3VectorsIndex.EncryptionConfigurationProperty[] | cdktn.IResolvable): void;
    resetEncryptionConfiguration(): void;
    get encryptionConfigurationInput(): cdktn.IResolvable | AwsS3VectorsIndex.EncryptionConfigurationProperty[] | undefined;
    get indexArn(): string;
    private _indexName?;
    get indexName(): string;
    set indexName(value: string);
    get indexNameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    private _vectorBucketName?;
    get vectorBucketName(): string;
    set vectorBucketName(value: string);
    get vectorBucketNameInput(): string | undefined;
    private _metadataConfiguration;
    get metadataConfiguration(): AwsS3VectorsIndex.MetadataConfigurationPropertyList;
    putMetadataConfiguration(value: AwsS3VectorsIndex.MetadataConfigurationProperty[] | cdktn.IResolvable): void;
    resetMetadataConfiguration(): void;
    get metadataConfigurationInput(): cdktn.IResolvable | AwsS3VectorsIndex.MetadataConfigurationProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsS3VectorsIndexEncryptionConfigurationPropertyToTerraform(struct?: AwsS3VectorsIndex.EncryptionConfigurationProperty | cdktn.IResolvable): any;
export declare function awsS3VectorsIndexEncryptionConfigurationPropertyToHclTerraform(struct?: AwsS3VectorsIndex.EncryptionConfigurationProperty | cdktn.IResolvable): any;
export declare function awsS3VectorsIndexMetadataConfigurationPropertyToTerraform(struct?: AwsS3VectorsIndex.MetadataConfigurationProperty | cdktn.IResolvable): any;
export declare function awsS3VectorsIndexMetadataConfigurationPropertyToHclTerraform(struct?: AwsS3VectorsIndex.MetadataConfigurationProperty | cdktn.IResolvable): any;
export declare namespace AwsS3VectorsIndex {
    interface EncryptionConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3vectors_index#kms_key_arn AwsS3VectorsIndex#kms_key_arn}
        */
        readonly kmsKeyArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3vectors_index#sse_type AwsS3VectorsIndex#sse_type}
        */
        readonly sseType?: string;
    }
    class EncryptionConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EncryptionConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: EncryptionConfigurationProperty | cdktn.IResolvable | undefined);
        private _kmsKeyArn?;
        get kmsKeyArn(): string;
        set kmsKeyArn(value: string);
        resetKmsKeyArn(): void;
        get kmsKeyArnInput(): string | undefined;
        private _sseType?;
        get sseType(): string;
        set sseType(value: string);
        resetSseType(): void;
        get sseTypeInput(): string | undefined;
    }
    class EncryptionConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: EncryptionConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EncryptionConfigurationPropertyOutputReference;
    }
    interface MetadataConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3vectors_index#non_filterable_metadata_keys AwsS3VectorsIndex#non_filterable_metadata_keys}
        */
        readonly nonFilterableMetadataKeys: string[];
    }
    class MetadataConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): MetadataConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: MetadataConfigurationProperty | cdktn.IResolvable | undefined);
        private _nonFilterableMetadataKeys?;
        get nonFilterableMetadataKeys(): string[];
        set nonFilterableMetadataKeys(value: string[]);
        get nonFilterableMetadataKeysInput(): string[] | undefined;
    }
    class MetadataConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: MetadataConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): MetadataConfigurationPropertyOutputReference;
    }
}
