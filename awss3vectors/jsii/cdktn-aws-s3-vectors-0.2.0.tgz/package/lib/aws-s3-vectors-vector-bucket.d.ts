import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfVectorBucketConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3vectors_vector_bucket#encryption_configuration TfVectorBucket#encryption_configuration}
    */
    readonly encryptionConfiguration?: TfVectorBucket.EncryptionConfigurationProperty[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3vectors_vector_bucket#force_destroy TfVectorBucket#force_destroy}
    */
    readonly forceDestroy?: boolean | cdktn.IResolvable;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3vectors_vector_bucket#region TfVectorBucket#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3vectors_vector_bucket#tags TfVectorBucket#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3vectors_vector_bucket#vector_bucket_name TfVectorBucket#vector_bucket_name}
    */
    readonly vectorBucketName: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3vectors_vector_bucket aws_s3vectors_vector_bucket}
*/
export declare class TfVectorBucket extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_s3vectors_vector_bucket";
    /**
    * Generates CDKTN code for importing a TfVectorBucket resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfVectorBucket to import
    * @param importFromId The id of the existing TfVectorBucket that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3vectors_vector_bucket#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfVectorBucket to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3vectors_vector_bucket aws_s3vectors_vector_bucket} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfVectorBucketConfig
    */
    constructor(scope: Construct, id: string, config: TfVectorBucketConfig);
    get creationTime(): string;
    private _encryptionConfiguration;
    get encryptionConfiguration(): TfVectorBucket.EncryptionConfigurationPropertyList;
    putEncryptionConfiguration(value: TfVectorBucket.EncryptionConfigurationProperty[] | cdktn.IResolvable): void;
    resetEncryptionConfiguration(): void;
    get encryptionConfigurationInput(): cdktn.IResolvable | TfVectorBucket.EncryptionConfigurationProperty[] | undefined;
    private _forceDestroy?;
    get forceDestroy(): boolean | cdktn.IResolvable;
    set forceDestroy(value: boolean | cdktn.IResolvable);
    resetForceDestroy(): void;
    get forceDestroyInput(): boolean | cdktn.IResolvable | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    get vectorBucketArn(): string;
    private _vectorBucketName?;
    get vectorBucketName(): string;
    set vectorBucketName(value: string);
    get vectorBucketNameInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfVectorBucketEncryptionConfigurationPropertyToTerraform(struct?: TfVectorBucket.EncryptionConfigurationProperty | cdktn.IResolvable): any;
export declare function tfVectorBucketEncryptionConfigurationPropertyToHclTerraform(struct?: TfVectorBucket.EncryptionConfigurationProperty | cdktn.IResolvable): any;
export declare namespace TfVectorBucket {
    interface EncryptionConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3vectors_vector_bucket#kms_key_arn TfVectorBucket#kms_key_arn}
        */
        readonly kmsKeyArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3vectors_vector_bucket#sse_type TfVectorBucket#sse_type}
        */
        readonly sseType?: string;
    }
    class EncryptionConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EncryptionConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: EncryptionConfigurationProperty | cdktn.IResolvable | undefined);
        private _kmsKeyArn?;
        get kmsKeyArn(): string;
        set kmsKeyArn(value: string);
        resetKmsKeyArn(): void;
        get kmsKeyArnInput(): string | undefined;
        private _sseType?;
        get sseType(): string;
        set sseType(value: string);
        resetSseType(): void;
        get sseTypeInput(): string | undefined;
    }
    class EncryptionConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: EncryptionConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EncryptionConfigurationPropertyOutputReference;
    }
}
