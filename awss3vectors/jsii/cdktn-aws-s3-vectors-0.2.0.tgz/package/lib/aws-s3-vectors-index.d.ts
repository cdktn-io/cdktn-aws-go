import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfIndexConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3vectors_index#data_type TfIndex#data_type}
    */
    readonly dataType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3vectors_index#dimension TfIndex#dimension}
    */
    readonly dimension: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3vectors_index#distance_metric TfIndex#distance_metric}
    */
    readonly distanceMetric: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3vectors_index#encryption_configuration TfIndex#encryption_configuration}
    */
    readonly encryptionConfiguration?: TfIndex.EncryptionConfigurationProperty[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3vectors_index#index_name TfIndex#index_name}
    */
    readonly indexName: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3vectors_index#region TfIndex#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3vectors_index#tags TfIndex#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3vectors_index#vector_bucket_name TfIndex#vector_bucket_name}
    */
    readonly vectorBucketName: string;
    /**
    * metadata_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3vectors_index#metadata_configuration TfIndex#metadata_configuration}
    */
    readonly metadataConfiguration?: TfIndex.MetadataConfigurationProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3vectors_index aws_s3vectors_index}
*/
export declare class TfIndex extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_s3vectors_index";
    /**
    * Generates CDKTN code for importing a TfIndex resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfIndex to import
    * @param importFromId The id of the existing TfIndex that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3vectors_index#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfIndex to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3vectors_index aws_s3vectors_index} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfIndexConfig
    */
    constructor(scope: Construct, id: string, config: TfIndexConfig);
    get creationTime(): string;
    private _dataType?;
    get dataType(): string;
    set dataType(value: string);
    get dataTypeInput(): string | undefined;
    private _dimension?;
    get dimension(): number;
    set dimension(value: number);
    get dimensionInput(): number | undefined;
    private _distanceMetric?;
    get distanceMetric(): string;
    set distanceMetric(value: string);
    get distanceMetricInput(): string | undefined;
    private _encryptionConfiguration;
    get encryptionConfiguration(): TfIndex.EncryptionConfigurationPropertyList;
    putEncryptionConfiguration(value: TfIndex.EncryptionConfigurationProperty[] | cdktn.IResolvable): void;
    resetEncryptionConfiguration(): void;
    get encryptionConfigurationInput(): cdktn.IResolvable | TfIndex.EncryptionConfigurationProperty[] | undefined;
    get indexArn(): string;
    private _indexName?;
    get indexName(): string;
    set indexName(value: string);
    get indexNameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    private _vectorBucketName?;
    get vectorBucketName(): string;
    set vectorBucketName(value: string);
    get vectorBucketNameInput(): string | undefined;
    private _metadataConfiguration;
    get metadataConfiguration(): TfIndex.MetadataConfigurationPropertyList;
    putMetadataConfiguration(value: TfIndex.MetadataConfigurationProperty[] | cdktn.IResolvable): void;
    resetMetadataConfiguration(): void;
    get metadataConfigurationInput(): cdktn.IResolvable | TfIndex.MetadataConfigurationProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfIndexEncryptionConfigurationPropertyToTerraform(struct?: TfIndex.EncryptionConfigurationProperty | cdktn.IResolvable): any;
export declare function tfIndexEncryptionConfigurationPropertyToHclTerraform(struct?: TfIndex.EncryptionConfigurationProperty | cdktn.IResolvable): any;
export declare function tfIndexMetadataConfigurationPropertyToTerraform(struct?: TfIndex.MetadataConfigurationProperty | cdktn.IResolvable): any;
export declare function tfIndexMetadataConfigurationPropertyToHclTerraform(struct?: TfIndex.MetadataConfigurationProperty | cdktn.IResolvable): any;
export declare namespace TfIndex {
    interface EncryptionConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3vectors_index#kms_key_arn TfIndex#kms_key_arn}
        */
        readonly kmsKeyArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3vectors_index#sse_type TfIndex#sse_type}
        */
        readonly sseType?: string;
    }
    class EncryptionConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EncryptionConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: EncryptionConfigurationProperty | cdktn.IResolvable | undefined);
        private _kmsKeyArn?;
        get kmsKeyArn(): string;
        set kmsKeyArn(value: string);
        resetKmsKeyArn(): void;
        get kmsKeyArnInput(): string | undefined;
        private _sseType?;
        get sseType(): string;
        set sseType(value: string);
        resetSseType(): void;
        get sseTypeInput(): string | undefined;
    }
    class EncryptionConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: EncryptionConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EncryptionConfigurationPropertyOutputReference;
    }
    interface MetadataConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3vectors_index#non_filterable_metadata_keys TfIndex#non_filterable_metadata_keys}
        */
        readonly nonFilterableMetadataKeys: string[];
    }
    class MetadataConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): MetadataConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: MetadataConfigurationProperty | cdktn.IResolvable | undefined);
        private _nonFilterableMetadataKeys?;
        get nonFilterableMetadataKeys(): string[];
        set nonFilterableMetadataKeys(value: string[]);
        get nonFilterableMetadataKeysInput(): string[] | undefined;
    }
    class MetadataConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: MetadataConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): MetadataConfigurationPropertyOutputReference;
    }
}
