import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsTableExportConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_table_export#export_format AwsTableExport#export_format}
    */
    readonly exportFormat?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_table_export#export_time AwsTableExport#export_time}
    */
    readonly exportTime?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_table_export#export_type AwsTableExport#export_type}
    */
    readonly exportType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_table_export#id AwsTableExport#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_table_export#region AwsTableExport#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_table_export#s3_bucket AwsTableExport#s3_bucket}
    */
    readonly s3Bucket: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_table_export#s3_bucket_owner AwsTableExport#s3_bucket_owner}
    */
    readonly s3BucketOwner?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_table_export#s3_prefix AwsTableExport#s3_prefix}
    */
    readonly s3Prefix?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_table_export#s3_sse_algorithm AwsTableExport#s3_sse_algorithm}
    */
    readonly s3SseAlgorithm?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_table_export#s3_sse_kms_key_id AwsTableExport#s3_sse_kms_key_id}
    */
    readonly s3SseKmsKeyId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_table_export#table_arn AwsTableExport#table_arn}
    */
    readonly tableArn: string;
    /**
    * incremental_export_specification block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_table_export#incremental_export_specification AwsTableExport#incremental_export_specification}
    */
    readonly incrementalExportSpecification?: AwsTableExport.IncrementalExportSpecificationProperty;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_table_export#timeouts AwsTableExport#timeouts}
    */
    readonly timeouts?: AwsTableExport.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_table_export aws_dynamodb_table_export}
*/
export declare class AwsTableExport extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_dynamodb_table_export";
    /**
    * Generates CDKTN code for importing a AwsTableExport resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsTableExport to import
    * @param importFromId The id of the existing AwsTableExport that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_table_export#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsTableExport to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_table_export aws_dynamodb_table_export} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsTableExportConfig
    */
    constructor(scope: Construct, id: string, config: AwsTableExportConfig);
    get arn(): string;
    get billedSizeInBytes(): number;
    get endTime(): string;
    private _exportFormat?;
    get exportFormat(): string;
    set exportFormat(value: string);
    resetExportFormat(): void;
    get exportFormatInput(): string | undefined;
    get exportStatus(): string;
    private _exportTime?;
    get exportTime(): string;
    set exportTime(value: string);
    resetExportTime(): void;
    get exportTimeInput(): string | undefined;
    private _exportType?;
    get exportType(): string;
    set exportType(value: string);
    resetExportType(): void;
    get exportTypeInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get itemCount(): number;
    get manifestFilesS3Key(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _s3Bucket?;
    get s3Bucket(): string;
    set s3Bucket(value: string);
    get s3BucketInput(): string | undefined;
    private _s3BucketOwner?;
    get s3BucketOwner(): string;
    set s3BucketOwner(value: string);
    resetS3BucketOwner(): void;
    get s3BucketOwnerInput(): string | undefined;
    private _s3Prefix?;
    get s3Prefix(): string;
    set s3Prefix(value: string);
    resetS3Prefix(): void;
    get s3PrefixInput(): string | undefined;
    private _s3SseAlgorithm?;
    get s3SseAlgorithm(): string;
    set s3SseAlgorithm(value: string);
    resetS3SseAlgorithm(): void;
    get s3SseAlgorithmInput(): string | undefined;
    private _s3SseKmsKeyId?;
    get s3SseKmsKeyId(): string;
    set s3SseKmsKeyId(value: string);
    resetS3SseKmsKeyId(): void;
    get s3SseKmsKeyIdInput(): string | undefined;
    get startTime(): string;
    private _tableArn?;
    get tableArn(): string;
    set tableArn(value: string);
    get tableArnInput(): string | undefined;
    private _incrementalExportSpecification;
    get incrementalExportSpecification(): AwsTableExport.IncrementalExportSpecificationPropertyOutputReference;
    putIncrementalExportSpecification(value: AwsTableExport.IncrementalExportSpecificationProperty): void;
    resetIncrementalExportSpecification(): void;
    get incrementalExportSpecificationInput(): AwsTableExport.IncrementalExportSpecificationProperty | undefined;
    private _timeouts;
    get timeouts(): AwsTableExport.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsTableExport.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsTableExport.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsTableExportIncrementalExportSpecificationPropertyToTerraform(struct?: AwsTableExport.IncrementalExportSpecificationPropertyOutputReference | AwsTableExport.IncrementalExportSpecificationProperty): any;
export declare function awsTableExportIncrementalExportSpecificationPropertyToHclTerraform(struct?: AwsTableExport.IncrementalExportSpecificationPropertyOutputReference | AwsTableExport.IncrementalExportSpecificationProperty): any;
export declare function awsTableExportTimeoutsPropertyToTerraform(struct?: AwsTableExport.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsTableExportTimeoutsPropertyToHclTerraform(struct?: AwsTableExport.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsTableExport {
    interface IncrementalExportSpecificationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_table_export#export_from_time AwsTableExport#export_from_time}
        */
        readonly exportFromTime?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_table_export#export_to_time AwsTableExport#export_to_time}
        */
        readonly exportToTime?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_table_export#export_view_type AwsTableExport#export_view_type}
        */
        readonly exportViewType?: string;
    }
    class IncrementalExportSpecificationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): IncrementalExportSpecificationProperty | undefined;
        set internalValue(value: IncrementalExportSpecificationProperty | undefined);
        private _exportFromTime?;
        get exportFromTime(): string;
        set exportFromTime(value: string);
        resetExportFromTime(): void;
        get exportFromTimeInput(): string | undefined;
        private _exportToTime?;
        get exportToTime(): string;
        set exportToTime(value: string);
        resetExportToTime(): void;
        get exportToTimeInput(): string | undefined;
        private _exportViewType?;
        get exportViewType(): string;
        set exportViewType(value: string);
        resetExportViewType(): void;
        get exportViewTypeInput(): string | undefined;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_table_export#create AwsTableExport#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dynamodb_table_export#delete AwsTableExport#delete}
        */
        readonly delete?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
    }
}
