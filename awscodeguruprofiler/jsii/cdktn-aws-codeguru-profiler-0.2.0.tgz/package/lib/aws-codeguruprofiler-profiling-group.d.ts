import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfProfilingGroupConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codeguruprofiler_profiling_group#compute_platform TfProfilingGroup#compute_platform}
    */
    readonly computePlatform?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codeguruprofiler_profiling_group#name TfProfilingGroup#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codeguruprofiler_profiling_group#region TfProfilingGroup#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codeguruprofiler_profiling_group#tags TfProfilingGroup#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * agent_orchestration_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codeguruprofiler_profiling_group#agent_orchestration_config TfProfilingGroup#agent_orchestration_config}
    */
    readonly agentOrchestrationConfig?: TfProfilingGroup.AgentOrchestrationConfigProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codeguruprofiler_profiling_group aws_codeguruprofiler_profiling_group}
*/
export declare class TfProfilingGroup extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_codeguruprofiler_profiling_group";
    /**
    * Generates CDKTN code for importing a TfProfilingGroup resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfProfilingGroup to import
    * @param importFromId The id of the existing TfProfilingGroup that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codeguruprofiler_profiling_group#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfProfilingGroup to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codeguruprofiler_profiling_group aws_codeguruprofiler_profiling_group} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfProfilingGroupConfig
    */
    constructor(scope: Construct, id: string, config: TfProfilingGroupConfig);
    get arn(): string;
    private _computePlatform?;
    get computePlatform(): string;
    set computePlatform(value: string);
    resetComputePlatform(): void;
    get computePlatformInput(): string | undefined;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    private _agentOrchestrationConfig;
    get agentOrchestrationConfig(): TfProfilingGroup.AgentOrchestrationConfigPropertyList;
    putAgentOrchestrationConfig(value: TfProfilingGroup.AgentOrchestrationConfigProperty[] | cdktn.IResolvable): void;
    resetAgentOrchestrationConfig(): void;
    get agentOrchestrationConfigInput(): cdktn.IResolvable | TfProfilingGroup.AgentOrchestrationConfigProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfProfilingGroupAgentOrchestrationConfigPropertyToTerraform(struct?: TfProfilingGroup.AgentOrchestrationConfigProperty | cdktn.IResolvable): any;
export declare function tfProfilingGroupAgentOrchestrationConfigPropertyToHclTerraform(struct?: TfProfilingGroup.AgentOrchestrationConfigProperty | cdktn.IResolvable): any;
export declare namespace TfProfilingGroup {
    interface AgentOrchestrationConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codeguruprofiler_profiling_group#profiling_enabled TfProfilingGroup#profiling_enabled}
        */
        readonly profilingEnabled: boolean | cdktn.IResolvable;
    }
    class AgentOrchestrationConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AgentOrchestrationConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: AgentOrchestrationConfigProperty | cdktn.IResolvable | undefined);
        private _profilingEnabled?;
        get profilingEnabled(): boolean | cdktn.IResolvable;
        set profilingEnabled(value: boolean | cdktn.IResolvable);
        get profilingEnabledInput(): boolean | cdktn.IResolvable | undefined;
    }
    class AgentOrchestrationConfigPropertyList extends cdktn.ComplexList {
        internalValue?: AgentOrchestrationConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AgentOrchestrationConfigPropertyOutputReference;
    }
}
