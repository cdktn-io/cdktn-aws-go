import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsCodeguruprofilerProfilingGroupConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codeguruprofiler_profiling_group#compute_platform AwsCodeguruprofilerProfilingGroup#compute_platform}
    */
    readonly computePlatform?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codeguruprofiler_profiling_group#name AwsCodeguruprofilerProfilingGroup#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codeguruprofiler_profiling_group#region AwsCodeguruprofilerProfilingGroup#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codeguruprofiler_profiling_group#tags AwsCodeguruprofilerProfilingGroup#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * agent_orchestration_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codeguruprofiler_profiling_group#agent_orchestration_config AwsCodeguruprofilerProfilingGroup#agent_orchestration_config}
    */
    readonly agentOrchestrationConfig?: AwsCodeguruprofilerProfilingGroup.AgentOrchestrationConfigProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codeguruprofiler_profiling_group aws_codeguruprofiler_profiling_group}
*/
export declare class AwsCodeguruprofilerProfilingGroup extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_codeguruprofiler_profiling_group";
    /**
    * Generates CDKTN code for importing a AwsCodeguruprofilerProfilingGroup resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsCodeguruprofilerProfilingGroup to import
    * @param importFromId The id of the existing AwsCodeguruprofilerProfilingGroup that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codeguruprofiler_profiling_group#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsCodeguruprofilerProfilingGroup to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codeguruprofiler_profiling_group aws_codeguruprofiler_profiling_group} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsCodeguruprofilerProfilingGroupConfig
    */
    constructor(scope: Construct, id: string, config: AwsCodeguruprofilerProfilingGroupConfig);
    get arn(): string;
    private _computePlatform?;
    get computePlatform(): string;
    set computePlatform(value: string);
    resetComputePlatform(): void;
    get computePlatformInput(): string | undefined;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    private _agentOrchestrationConfig;
    get agentOrchestrationConfig(): AwsCodeguruprofilerProfilingGroup.AgentOrchestrationConfigPropertyList;
    putAgentOrchestrationConfig(value: AwsCodeguruprofilerProfilingGroup.AgentOrchestrationConfigProperty[] | cdktn.IResolvable): void;
    resetAgentOrchestrationConfig(): void;
    get agentOrchestrationConfigInput(): cdktn.IResolvable | AwsCodeguruprofilerProfilingGroup.AgentOrchestrationConfigProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsCodeguruprofilerProfilingGroupAgentOrchestrationConfigPropertyToTerraform(struct?: AwsCodeguruprofilerProfilingGroup.AgentOrchestrationConfigProperty | cdktn.IResolvable): any;
export declare function awsCodeguruprofilerProfilingGroupAgentOrchestrationConfigPropertyToHclTerraform(struct?: AwsCodeguruprofilerProfilingGroup.AgentOrchestrationConfigProperty | cdktn.IResolvable): any;
export declare namespace AwsCodeguruprofilerProfilingGroup {
    interface AgentOrchestrationConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codeguruprofiler_profiling_group#profiling_enabled AwsCodeguruprofilerProfilingGroup#profiling_enabled}
        */
        readonly profilingEnabled: boolean | cdktn.IResolvable;
    }
    class AgentOrchestrationConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AgentOrchestrationConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: AgentOrchestrationConfigProperty | cdktn.IResolvable | undefined);
        private _profilingEnabled?;
        get profilingEnabled(): boolean | cdktn.IResolvable;
        set profilingEnabled(value: boolean | cdktn.IResolvable);
        get profilingEnabledInput(): boolean | cdktn.IResolvable | undefined;
    }
    class AgentOrchestrationConfigPropertyList extends cdktn.ComplexList {
        internalValue?: AgentOrchestrationConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AgentOrchestrationConfigPropertyOutputReference;
    }
}
