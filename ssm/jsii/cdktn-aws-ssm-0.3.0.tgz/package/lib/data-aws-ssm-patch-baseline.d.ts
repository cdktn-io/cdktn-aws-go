import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsPatchBaselineConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ssm_patch_baseline#default_baseline DataAwsPatchBaseline#default_baseline}
    */
    readonly defaultBaseline?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ssm_patch_baseline#id DataAwsPatchBaseline#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ssm_patch_baseline#name_prefix DataAwsPatchBaseline#name_prefix}
    */
    readonly namePrefix?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ssm_patch_baseline#operating_system DataAwsPatchBaseline#operating_system}
    */
    readonly operatingSystem?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ssm_patch_baseline#owner DataAwsPatchBaseline#owner}
    */
    readonly owner: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ssm_patch_baseline#region DataAwsPatchBaseline#region}
    */
    readonly region?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ssm_patch_baseline aws_ssm_patch_baseline}
*/
export declare class DataAwsPatchBaseline extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_ssm_patch_baseline";
    /**
    * Generates CDKTN code for importing a DataAwsPatchBaseline resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsPatchBaseline to import
    * @param importFromId The id of the existing DataAwsPatchBaseline that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ssm_patch_baseline#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsPatchBaseline to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ssm_patch_baseline aws_ssm_patch_baseline} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsPatchBaselineConfig
    */
    constructor(scope: Construct, id: string, config: DataAwsPatchBaselineConfig);
    private _approvalRule;
    get approvalRule(): DataAwsPatchBaseline.ApprovalRulePropertyList;
    get approvedPatches(): string[];
    get approvedPatchesComplianceLevel(): string;
    get approvedPatchesEnableNonSecurity(): cdktn.IResolvable;
    get availableSecurityUpdatesComplianceStatus(): string;
    private _defaultBaseline?;
    get defaultBaseline(): boolean | cdktn.IResolvable;
    set defaultBaseline(value: boolean | cdktn.IResolvable);
    resetDefaultBaseline(): void;
    get defaultBaselineInput(): boolean | cdktn.IResolvable | undefined;
    get description(): string;
    private _globalFilter;
    get globalFilter(): DataAwsPatchBaseline.GlobalFilterPropertyList;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get json(): string;
    get name(): string;
    private _namePrefix?;
    get namePrefix(): string;
    set namePrefix(value: string);
    resetNamePrefix(): void;
    get namePrefixInput(): string | undefined;
    private _operatingSystem?;
    get operatingSystem(): string;
    set operatingSystem(value: string);
    resetOperatingSystem(): void;
    get operatingSystemInput(): string | undefined;
    private _owner?;
    get owner(): string;
    set owner(value: string);
    get ownerInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get rejectedPatches(): string[];
    get rejectedPatchesAction(): string;
    private _source;
    get source(): DataAwsPatchBaseline.SourcePropertyList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataAwsPatchBaselinePatchFilterPropertyToTerraform(struct?: DataAwsPatchBaseline.PatchFilterProperty): any;
export declare function dataAwsPatchBaselinePatchFilterPropertyToHclTerraform(struct?: DataAwsPatchBaseline.PatchFilterProperty): any;
export declare function dataAwsPatchBaselineApprovalRulePropertyToTerraform(struct?: DataAwsPatchBaseline.ApprovalRuleProperty): any;
export declare function dataAwsPatchBaselineApprovalRulePropertyToHclTerraform(struct?: DataAwsPatchBaseline.ApprovalRuleProperty): any;
export declare function dataAwsPatchBaselineGlobalFilterPropertyToTerraform(struct?: DataAwsPatchBaseline.GlobalFilterProperty): any;
export declare function dataAwsPatchBaselineGlobalFilterPropertyToHclTerraform(struct?: DataAwsPatchBaseline.GlobalFilterProperty): any;
export declare function dataAwsPatchBaselineSourcePropertyToTerraform(struct?: DataAwsPatchBaseline.SourceProperty): any;
export declare function dataAwsPatchBaselineSourcePropertyToHclTerraform(struct?: DataAwsPatchBaseline.SourceProperty): any;
export declare namespace DataAwsPatchBaseline {
    interface PatchFilterProperty {
    }
    class PatchFilterPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): PatchFilterProperty | undefined;
        set internalValue(value: PatchFilterProperty | undefined);
        get key(): string;
        get values(): string[];
    }
    class PatchFilterPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): PatchFilterPropertyOutputReference;
    }
    interface ApprovalRuleProperty {
    }
    class ApprovalRulePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ApprovalRuleProperty | undefined;
        set internalValue(value: ApprovalRuleProperty | undefined);
        get approveAfterDays(): number;
        get approveUntilDate(): string;
        get complianceLevel(): string;
        get enableNonSecurity(): cdktn.IResolvable;
        private _patchFilter;
        get patchFilter(): PatchFilterPropertyList;
    }
    class ApprovalRulePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ApprovalRulePropertyOutputReference;
    }
    interface GlobalFilterProperty {
    }
    class GlobalFilterPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): GlobalFilterProperty | undefined;
        set internalValue(value: GlobalFilterProperty | undefined);
        get key(): string;
        get values(): string[];
    }
    class GlobalFilterPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): GlobalFilterPropertyOutputReference;
    }
    interface SourceProperty {
    }
    class SourcePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SourceProperty | undefined;
        set internalValue(value: SourceProperty | undefined);
        get configuration(): string;
        get name(): string;
        get products(): string[];
    }
    class SourcePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SourcePropertyOutputReference;
    }
}
