import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsPatchBaselineConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssm_patch_baseline#approved_patches AwsPatchBaseline#approved_patches}
    */
    readonly approvedPatches?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssm_patch_baseline#approved_patches_compliance_level AwsPatchBaseline#approved_patches_compliance_level}
    */
    readonly approvedPatchesComplianceLevel?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssm_patch_baseline#approved_patches_enable_non_security AwsPatchBaseline#approved_patches_enable_non_security}
    */
    readonly approvedPatchesEnableNonSecurity?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssm_patch_baseline#available_security_updates_compliance_status AwsPatchBaseline#available_security_updates_compliance_status}
    */
    readonly availableSecurityUpdatesComplianceStatus?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssm_patch_baseline#description AwsPatchBaseline#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssm_patch_baseline#id AwsPatchBaseline#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssm_patch_baseline#name AwsPatchBaseline#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssm_patch_baseline#operating_system AwsPatchBaseline#operating_system}
    */
    readonly operatingSystem?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssm_patch_baseline#region AwsPatchBaseline#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssm_patch_baseline#rejected_patches AwsPatchBaseline#rejected_patches}
    */
    readonly rejectedPatches?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssm_patch_baseline#rejected_patches_action AwsPatchBaseline#rejected_patches_action}
    */
    readonly rejectedPatchesAction?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssm_patch_baseline#tags AwsPatchBaseline#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssm_patch_baseline#tags_all AwsPatchBaseline#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * approval_rule block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssm_patch_baseline#approval_rule AwsPatchBaseline#approval_rule}
    */
    readonly approvalRule?: AwsPatchBaseline.ApprovalRuleProperty[] | cdktn.IResolvable;
    /**
    * global_filter block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssm_patch_baseline#global_filter AwsPatchBaseline#global_filter}
    */
    readonly globalFilter?: AwsPatchBaseline.GlobalFilterProperty[] | cdktn.IResolvable;
    /**
    * source block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssm_patch_baseline#source AwsPatchBaseline#source}
    */
    readonly source?: AwsPatchBaseline.SourceProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssm_patch_baseline aws_ssm_patch_baseline}
*/
export declare class AwsPatchBaseline extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_ssm_patch_baseline";
    /**
    * Generates CDKTN code for importing a AwsPatchBaseline resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsPatchBaseline to import
    * @param importFromId The id of the existing AwsPatchBaseline that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssm_patch_baseline#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsPatchBaseline to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssm_patch_baseline aws_ssm_patch_baseline} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsPatchBaselineConfig
    */
    constructor(scope: Construct, id: string, config: AwsPatchBaselineConfig);
    private _approvedPatches?;
    get approvedPatches(): string[];
    set approvedPatches(value: string[]);
    resetApprovedPatches(): void;
    get approvedPatchesInput(): string[] | undefined;
    private _approvedPatchesComplianceLevel?;
    get approvedPatchesComplianceLevel(): string;
    set approvedPatchesComplianceLevel(value: string);
    resetApprovedPatchesComplianceLevel(): void;
    get approvedPatchesComplianceLevelInput(): string | undefined;
    private _approvedPatchesEnableNonSecurity?;
    get approvedPatchesEnableNonSecurity(): boolean | cdktn.IResolvable;
    set approvedPatchesEnableNonSecurity(value: boolean | cdktn.IResolvable);
    resetApprovedPatchesEnableNonSecurity(): void;
    get approvedPatchesEnableNonSecurityInput(): boolean | cdktn.IResolvable | undefined;
    get arn(): string;
    private _availableSecurityUpdatesComplianceStatus?;
    get availableSecurityUpdatesComplianceStatus(): string;
    set availableSecurityUpdatesComplianceStatus(value: string);
    resetAvailableSecurityUpdatesComplianceStatus(): void;
    get availableSecurityUpdatesComplianceStatusInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get json(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _operatingSystem?;
    get operatingSystem(): string;
    set operatingSystem(value: string);
    resetOperatingSystem(): void;
    get operatingSystemInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _rejectedPatches?;
    get rejectedPatches(): string[];
    set rejectedPatches(value: string[]);
    resetRejectedPatches(): void;
    get rejectedPatchesInput(): string[] | undefined;
    private _rejectedPatchesAction?;
    get rejectedPatchesAction(): string;
    set rejectedPatchesAction(value: string);
    resetRejectedPatchesAction(): void;
    get rejectedPatchesActionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _approvalRule;
    get approvalRule(): AwsPatchBaseline.ApprovalRulePropertyList;
    putApprovalRule(value: AwsPatchBaseline.ApprovalRuleProperty[] | cdktn.IResolvable): void;
    resetApprovalRule(): void;
    get approvalRuleInput(): cdktn.IResolvable | AwsPatchBaseline.ApprovalRuleProperty[] | undefined;
    private _globalFilter;
    get globalFilter(): AwsPatchBaseline.GlobalFilterPropertyList;
    putGlobalFilter(value: AwsPatchBaseline.GlobalFilterProperty[] | cdktn.IResolvable): void;
    resetGlobalFilter(): void;
    get globalFilterInput(): cdktn.IResolvable | AwsPatchBaseline.GlobalFilterProperty[] | undefined;
    private _source;
    get source(): AwsPatchBaseline.SourcePropertyList;
    putSource(value: AwsPatchBaseline.SourceProperty[] | cdktn.IResolvable): void;
    resetSource(): void;
    get sourceInput(): cdktn.IResolvable | AwsPatchBaseline.SourceProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsPatchBaselinePatchFilterPropertyToTerraform(struct?: AwsPatchBaseline.PatchFilterProperty | cdktn.IResolvable): any;
export declare function awsPatchBaselinePatchFilterPropertyToHclTerraform(struct?: AwsPatchBaseline.PatchFilterProperty | cdktn.IResolvable): any;
export declare function awsPatchBaselineApprovalRulePropertyToTerraform(struct?: AwsPatchBaseline.ApprovalRuleProperty | cdktn.IResolvable): any;
export declare function awsPatchBaselineApprovalRulePropertyToHclTerraform(struct?: AwsPatchBaseline.ApprovalRuleProperty | cdktn.IResolvable): any;
export declare function awsPatchBaselineGlobalFilterPropertyToTerraform(struct?: AwsPatchBaseline.GlobalFilterProperty | cdktn.IResolvable): any;
export declare function awsPatchBaselineGlobalFilterPropertyToHclTerraform(struct?: AwsPatchBaseline.GlobalFilterProperty | cdktn.IResolvable): any;
export declare function awsPatchBaselineSourcePropertyToTerraform(struct?: AwsPatchBaseline.SourceProperty | cdktn.IResolvable): any;
export declare function awsPatchBaselineSourcePropertyToHclTerraform(struct?: AwsPatchBaseline.SourceProperty | cdktn.IResolvable): any;
export declare namespace AwsPatchBaseline {
    interface PatchFilterProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssm_patch_baseline#key AwsPatchBaseline#key}
        */
        readonly key: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssm_patch_baseline#values AwsPatchBaseline#values}
        */
        readonly values: string[];
    }
    class PatchFilterPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): PatchFilterProperty | cdktn.IResolvable | undefined;
        set internalValue(value: PatchFilterProperty | cdktn.IResolvable | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        get keyInput(): string | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        get valuesInput(): string[] | undefined;
    }
    class PatchFilterPropertyList extends cdktn.ComplexList {
        internalValue?: PatchFilterProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): PatchFilterPropertyOutputReference;
    }
    interface ApprovalRuleProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssm_patch_baseline#approve_after_days AwsPatchBaseline#approve_after_days}
        */
        readonly approveAfterDays?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssm_patch_baseline#approve_until_date AwsPatchBaseline#approve_until_date}
        */
        readonly approveUntilDate?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssm_patch_baseline#compliance_level AwsPatchBaseline#compliance_level}
        */
        readonly complianceLevel?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssm_patch_baseline#enable_non_security AwsPatchBaseline#enable_non_security}
        */
        readonly enableNonSecurity?: boolean | cdktn.IResolvable;
        /**
        * patch_filter block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssm_patch_baseline#patch_filter AwsPatchBaseline#patch_filter}
        */
        readonly patchFilter: PatchFilterProperty[] | cdktn.IResolvable;
    }
    class ApprovalRulePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ApprovalRuleProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ApprovalRuleProperty | cdktn.IResolvable | undefined);
        private _approveAfterDays?;
        get approveAfterDays(): number;
        set approveAfterDays(value: number);
        resetApproveAfterDays(): void;
        get approveAfterDaysInput(): number | undefined;
        private _approveUntilDate?;
        get approveUntilDate(): string;
        set approveUntilDate(value: string);
        resetApproveUntilDate(): void;
        get approveUntilDateInput(): string | undefined;
        private _complianceLevel?;
        get complianceLevel(): string;
        set complianceLevel(value: string);
        resetComplianceLevel(): void;
        get complianceLevelInput(): string | undefined;
        private _enableNonSecurity?;
        get enableNonSecurity(): boolean | cdktn.IResolvable;
        set enableNonSecurity(value: boolean | cdktn.IResolvable);
        resetEnableNonSecurity(): void;
        get enableNonSecurityInput(): boolean | cdktn.IResolvable | undefined;
        private _patchFilter;
        get patchFilter(): PatchFilterPropertyList;
        putPatchFilter(value: PatchFilterProperty[] | cdktn.IResolvable): void;
        get patchFilterInput(): cdktn.IResolvable | PatchFilterProperty[] | undefined;
    }
    class ApprovalRulePropertyList extends cdktn.ComplexList {
        internalValue?: ApprovalRuleProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ApprovalRulePropertyOutputReference;
    }
    interface GlobalFilterProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssm_patch_baseline#key AwsPatchBaseline#key}
        */
        readonly key: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssm_patch_baseline#values AwsPatchBaseline#values}
        */
        readonly values: string[];
    }
    class GlobalFilterPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): GlobalFilterProperty | cdktn.IResolvable | undefined;
        set internalValue(value: GlobalFilterProperty | cdktn.IResolvable | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        get keyInput(): string | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        get valuesInput(): string[] | undefined;
    }
    class GlobalFilterPropertyList extends cdktn.ComplexList {
        internalValue?: GlobalFilterProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): GlobalFilterPropertyOutputReference;
    }
    interface SourceProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssm_patch_baseline#configuration AwsPatchBaseline#configuration}
        */
        readonly configuration: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssm_patch_baseline#name AwsPatchBaseline#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssm_patch_baseline#products AwsPatchBaseline#products}
        */
        readonly products: string[];
    }
    class SourcePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SourceProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SourceProperty | cdktn.IResolvable | undefined);
        private _configuration?;
        get configuration(): string;
        set configuration(value: string);
        get configurationInput(): string | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _products?;
        get products(): string[];
        set products(value: string[]);
        get productsInput(): string[] | undefined;
    }
    class SourcePropertyList extends cdktn.ComplexList {
        internalValue?: SourceProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SourcePropertyOutputReference;
    }
}
