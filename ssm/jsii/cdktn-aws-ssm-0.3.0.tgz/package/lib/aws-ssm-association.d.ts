import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsAssociationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssm_association#apply_only_at_cron_interval AwsAssociation#apply_only_at_cron_interval}
    */
    readonly applyOnlyAtCronInterval?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssm_association#association_name AwsAssociation#association_name}
    */
    readonly associationName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssm_association#automation_target_parameter_name AwsAssociation#automation_target_parameter_name}
    */
    readonly automationTargetParameterName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssm_association#calendar_names AwsAssociation#calendar_names}
    */
    readonly calendarNames?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssm_association#compliance_severity AwsAssociation#compliance_severity}
    */
    readonly complianceSeverity?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssm_association#document_version AwsAssociation#document_version}
    */
    readonly documentVersion?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssm_association#id AwsAssociation#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssm_association#max_concurrency AwsAssociation#max_concurrency}
    */
    readonly maxConcurrency?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssm_association#max_errors AwsAssociation#max_errors}
    */
    readonly maxErrors?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssm_association#name AwsAssociation#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssm_association#parameters AwsAssociation#parameters}
    */
    readonly parameters?: {
        [key: string]: string;
    };
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssm_association#region AwsAssociation#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssm_association#schedule_expression AwsAssociation#schedule_expression}
    */
    readonly scheduleExpression?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssm_association#sync_compliance AwsAssociation#sync_compliance}
    */
    readonly syncCompliance?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssm_association#tags AwsAssociation#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssm_association#tags_all AwsAssociation#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssm_association#wait_for_success_timeout_seconds AwsAssociation#wait_for_success_timeout_seconds}
    */
    readonly waitForSuccessTimeoutSeconds?: number;
    /**
    * output_location block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssm_association#output_location AwsAssociation#output_location}
    */
    readonly outputLocation?: AwsAssociation.OutputLocationProperty;
    /**
    * targets block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssm_association#targets AwsAssociation#targets}
    */
    readonly targets?: AwsAssociation.TargetsProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssm_association aws_ssm_association}
*/
export declare class AwsAssociation extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_ssm_association";
    /**
    * Generates CDKTN code for importing a AwsAssociation resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsAssociation to import
    * @param importFromId The id of the existing AwsAssociation that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssm_association#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsAssociation to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssm_association aws_ssm_association} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsAssociationConfig
    */
    constructor(scope: Construct, id: string, config: AwsAssociationConfig);
    private _applyOnlyAtCronInterval?;
    get applyOnlyAtCronInterval(): boolean | cdktn.IResolvable;
    set applyOnlyAtCronInterval(value: boolean | cdktn.IResolvable);
    resetApplyOnlyAtCronInterval(): void;
    get applyOnlyAtCronIntervalInput(): boolean | cdktn.IResolvable | undefined;
    get arn(): string;
    get associationId(): string;
    private _associationName?;
    get associationName(): string;
    set associationName(value: string);
    resetAssociationName(): void;
    get associationNameInput(): string | undefined;
    private _automationTargetParameterName?;
    get automationTargetParameterName(): string;
    set automationTargetParameterName(value: string);
    resetAutomationTargetParameterName(): void;
    get automationTargetParameterNameInput(): string | undefined;
    private _calendarNames?;
    get calendarNames(): string[];
    set calendarNames(value: string[]);
    resetCalendarNames(): void;
    get calendarNamesInput(): string[] | undefined;
    private _complianceSeverity?;
    get complianceSeverity(): string;
    set complianceSeverity(value: string);
    resetComplianceSeverity(): void;
    get complianceSeverityInput(): string | undefined;
    private _documentVersion?;
    get documentVersion(): string;
    set documentVersion(value: string);
    resetDocumentVersion(): void;
    get documentVersionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _maxConcurrency?;
    get maxConcurrency(): string;
    set maxConcurrency(value: string);
    resetMaxConcurrency(): void;
    get maxConcurrencyInput(): string | undefined;
    private _maxErrors?;
    get maxErrors(): string;
    set maxErrors(value: string);
    resetMaxErrors(): void;
    get maxErrorsInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _parameters?;
    get parameters(): {
        [key: string]: string;
    };
    set parameters(value: {
        [key: string]: string;
    });
    resetParameters(): void;
    get parametersInput(): {
        [key: string]: string;
    } | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _scheduleExpression?;
    get scheduleExpression(): string;
    set scheduleExpression(value: string);
    resetScheduleExpression(): void;
    get scheduleExpressionInput(): string | undefined;
    private _syncCompliance?;
    get syncCompliance(): string;
    set syncCompliance(value: string);
    resetSyncCompliance(): void;
    get syncComplianceInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _waitForSuccessTimeoutSeconds?;
    get waitForSuccessTimeoutSeconds(): number;
    set waitForSuccessTimeoutSeconds(value: number);
    resetWaitForSuccessTimeoutSeconds(): void;
    get waitForSuccessTimeoutSecondsInput(): number | undefined;
    private _outputLocation;
    get outputLocation(): AwsAssociation.OutputLocationPropertyOutputReference;
    putOutputLocation(value: AwsAssociation.OutputLocationProperty): void;
    resetOutputLocation(): void;
    get outputLocationInput(): AwsAssociation.OutputLocationProperty | undefined;
    private _targets;
    get targets(): AwsAssociation.TargetsPropertyList;
    putTargets(value: AwsAssociation.TargetsProperty[] | cdktn.IResolvable): void;
    resetTargets(): void;
    get targetsInput(): cdktn.IResolvable | AwsAssociation.TargetsProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsAssociationOutputLocationPropertyToTerraform(struct?: AwsAssociation.OutputLocationPropertyOutputReference | AwsAssociation.OutputLocationProperty): any;
export declare function awsAssociationOutputLocationPropertyToHclTerraform(struct?: AwsAssociation.OutputLocationPropertyOutputReference | AwsAssociation.OutputLocationProperty): any;
export declare function awsAssociationTargetsPropertyToTerraform(struct?: AwsAssociation.TargetsProperty | cdktn.IResolvable): any;
export declare function awsAssociationTargetsPropertyToHclTerraform(struct?: AwsAssociation.TargetsProperty | cdktn.IResolvable): any;
export declare namespace AwsAssociation {
    interface OutputLocationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssm_association#s3_bucket_name AwsAssociation#s3_bucket_name}
        */
        readonly s3BucketName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssm_association#s3_key_prefix AwsAssociation#s3_key_prefix}
        */
        readonly s3KeyPrefix?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssm_association#s3_region AwsAssociation#s3_region}
        */
        readonly s3Region?: string;
    }
    class OutputLocationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): OutputLocationProperty | undefined;
        set internalValue(value: OutputLocationProperty | undefined);
        private _s3BucketName?;
        get s3BucketName(): string;
        set s3BucketName(value: string);
        get s3BucketNameInput(): string | undefined;
        private _s3KeyPrefix?;
        get s3KeyPrefix(): string;
        set s3KeyPrefix(value: string);
        resetS3KeyPrefix(): void;
        get s3KeyPrefixInput(): string | undefined;
        private _s3Region?;
        get s3Region(): string;
        set s3Region(value: string);
        resetS3Region(): void;
        get s3RegionInput(): string | undefined;
    }
    interface TargetsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssm_association#key AwsAssociation#key}
        */
        readonly key: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssm_association#values AwsAssociation#values}
        */
        readonly values: string[];
    }
    class TargetsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TargetsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TargetsProperty | cdktn.IResolvable | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        get keyInput(): string | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        get valuesInput(): string[] | undefined;
    }
    class TargetsPropertyList extends cdktn.ComplexList {
        internalValue?: TargetsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TargetsPropertyOutputReference;
    }
}
