import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsResourceDataSyncConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssm_resource_data_sync#id AwsResourceDataSync#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssm_resource_data_sync#name AwsResourceDataSync#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssm_resource_data_sync#region AwsResourceDataSync#region}
    */
    readonly region?: string;
    /**
    * s3_destination block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssm_resource_data_sync#s3_destination AwsResourceDataSync#s3_destination}
    */
    readonly s3Destination: AwsResourceDataSync.S3DestinationProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssm_resource_data_sync aws_ssm_resource_data_sync}
*/
export declare class AwsResourceDataSync extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_ssm_resource_data_sync";
    /**
    * Generates CDKTN code for importing a AwsResourceDataSync resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsResourceDataSync to import
    * @param importFromId The id of the existing AwsResourceDataSync that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssm_resource_data_sync#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsResourceDataSync to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssm_resource_data_sync aws_ssm_resource_data_sync} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsResourceDataSyncConfig
    */
    constructor(scope: Construct, id: string, config: AwsResourceDataSyncConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _s3Destination;
    get s3Destination(): AwsResourceDataSync.S3DestinationPropertyOutputReference;
    putS3Destination(value: AwsResourceDataSync.S3DestinationProperty): void;
    get s3DestinationInput(): AwsResourceDataSync.S3DestinationProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsResourceDataSyncDestinationDataSharingPropertyToTerraform(struct?: AwsResourceDataSync.DestinationDataSharingPropertyOutputReference | AwsResourceDataSync.DestinationDataSharingProperty): any;
export declare function awsResourceDataSyncDestinationDataSharingPropertyToHclTerraform(struct?: AwsResourceDataSync.DestinationDataSharingPropertyOutputReference | AwsResourceDataSync.DestinationDataSharingProperty): any;
export declare function awsResourceDataSyncS3DestinationPropertyToTerraform(struct?: AwsResourceDataSync.S3DestinationPropertyOutputReference | AwsResourceDataSync.S3DestinationProperty): any;
export declare function awsResourceDataSyncS3DestinationPropertyToHclTerraform(struct?: AwsResourceDataSync.S3DestinationPropertyOutputReference | AwsResourceDataSync.S3DestinationProperty): any;
export declare namespace AwsResourceDataSync {
    interface DestinationDataSharingProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssm_resource_data_sync#destination_data_sharing_type AwsResourceDataSync#destination_data_sharing_type}
        */
        readonly destinationDataSharingType?: string;
    }
    class DestinationDataSharingPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DestinationDataSharingProperty | undefined;
        set internalValue(value: DestinationDataSharingProperty | undefined);
        private _destinationDataSharingType?;
        get destinationDataSharingType(): string;
        set destinationDataSharingType(value: string);
        resetDestinationDataSharingType(): void;
        get destinationDataSharingTypeInput(): string | undefined;
    }
    interface S3DestinationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssm_resource_data_sync#bucket_name AwsResourceDataSync#bucket_name}
        */
        readonly bucketName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssm_resource_data_sync#kms_key_arn AwsResourceDataSync#kms_key_arn}
        */
        readonly kmsKeyArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssm_resource_data_sync#prefix AwsResourceDataSync#prefix}
        */
        readonly prefix?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssm_resource_data_sync#region AwsResourceDataSync#region}
        */
        readonly region: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssm_resource_data_sync#sync_format AwsResourceDataSync#sync_format}
        */
        readonly syncFormat?: string;
        /**
        * destination_data_sharing block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssm_resource_data_sync#destination_data_sharing AwsResourceDataSync#destination_data_sharing}
        */
        readonly destinationDataSharing?: DestinationDataSharingProperty;
    }
    class S3DestinationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): S3DestinationProperty | undefined;
        set internalValue(value: S3DestinationProperty | undefined);
        private _bucketName?;
        get bucketName(): string;
        set bucketName(value: string);
        get bucketNameInput(): string | undefined;
        private _kmsKeyArn?;
        get kmsKeyArn(): string;
        set kmsKeyArn(value: string);
        resetKmsKeyArn(): void;
        get kmsKeyArnInput(): string | undefined;
        private _prefix?;
        get prefix(): string;
        set prefix(value: string);
        resetPrefix(): void;
        get prefixInput(): string | undefined;
        private _region?;
        get region(): string;
        set region(value: string);
        get regionInput(): string | undefined;
        private _syncFormat?;
        get syncFormat(): string;
        set syncFormat(value: string);
        resetSyncFormat(): void;
        get syncFormatInput(): string | undefined;
        private _destinationDataSharing;
        get destinationDataSharing(): DestinationDataSharingPropertyOutputReference;
        putDestinationDataSharing(value: DestinationDataSharingProperty): void;
        resetDestinationDataSharing(): void;
        get destinationDataSharingInput(): DestinationDataSharingProperty | undefined;
    }
}
