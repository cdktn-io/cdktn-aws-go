import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsMaintenanceWindowTaskConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssm_maintenance_window_task#cutoff_behavior AwsMaintenanceWindowTask#cutoff_behavior}
    */
    readonly cutoffBehavior?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssm_maintenance_window_task#description AwsMaintenanceWindowTask#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssm_maintenance_window_task#id AwsMaintenanceWindowTask#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssm_maintenance_window_task#max_concurrency AwsMaintenanceWindowTask#max_concurrency}
    */
    readonly maxConcurrency?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssm_maintenance_window_task#max_errors AwsMaintenanceWindowTask#max_errors}
    */
    readonly maxErrors?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssm_maintenance_window_task#name AwsMaintenanceWindowTask#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssm_maintenance_window_task#priority AwsMaintenanceWindowTask#priority}
    */
    readonly priority?: number;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssm_maintenance_window_task#region AwsMaintenanceWindowTask#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssm_maintenance_window_task#service_role_arn AwsMaintenanceWindowTask#service_role_arn}
    */
    readonly serviceRoleArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssm_maintenance_window_task#task_arn AwsMaintenanceWindowTask#task_arn}
    */
    readonly taskArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssm_maintenance_window_task#task_type AwsMaintenanceWindowTask#task_type}
    */
    readonly taskType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssm_maintenance_window_task#window_id AwsMaintenanceWindowTask#window_id}
    */
    readonly windowId: string;
    /**
    * targets block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssm_maintenance_window_task#targets AwsMaintenanceWindowTask#targets}
    */
    readonly targets?: AwsMaintenanceWindowTask.TargetsProperty[] | cdktn.IResolvable;
    /**
    * task_invocation_parameters block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssm_maintenance_window_task#task_invocation_parameters AwsMaintenanceWindowTask#task_invocation_parameters}
    */
    readonly taskInvocationParameters?: AwsMaintenanceWindowTask.TaskInvocationParametersProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssm_maintenance_window_task aws_ssm_maintenance_window_task}
*/
export declare class AwsMaintenanceWindowTask extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_ssm_maintenance_window_task";
    /**
    * Generates CDKTN code for importing a AwsMaintenanceWindowTask resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsMaintenanceWindowTask to import
    * @param importFromId The id of the existing AwsMaintenanceWindowTask that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssm_maintenance_window_task#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsMaintenanceWindowTask to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssm_maintenance_window_task aws_ssm_maintenance_window_task} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsMaintenanceWindowTaskConfig
    */
    constructor(scope: Construct, id: string, config: AwsMaintenanceWindowTaskConfig);
    get arn(): string;
    private _cutoffBehavior?;
    get cutoffBehavior(): string;
    set cutoffBehavior(value: string);
    resetCutoffBehavior(): void;
    get cutoffBehaviorInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _maxConcurrency?;
    get maxConcurrency(): string;
    set maxConcurrency(value: string);
    resetMaxConcurrency(): void;
    get maxConcurrencyInput(): string | undefined;
    private _maxErrors?;
    get maxErrors(): string;
    set maxErrors(value: string);
    resetMaxErrors(): void;
    get maxErrorsInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _priority?;
    get priority(): number;
    set priority(value: number);
    resetPriority(): void;
    get priorityInput(): number | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _serviceRoleArn?;
    get serviceRoleArn(): string;
    set serviceRoleArn(value: string);
    resetServiceRoleArn(): void;
    get serviceRoleArnInput(): string | undefined;
    private _taskArn?;
    get taskArn(): string;
    set taskArn(value: string);
    get taskArnInput(): string | undefined;
    private _taskType?;
    get taskType(): string;
    set taskType(value: string);
    get taskTypeInput(): string | undefined;
    private _windowId?;
    get windowId(): string;
    set windowId(value: string);
    get windowIdInput(): string | undefined;
    get windowTaskId(): string;
    private _targets;
    get targets(): AwsMaintenanceWindowTask.TargetsPropertyList;
    putTargets(value: AwsMaintenanceWindowTask.TargetsProperty[] | cdktn.IResolvable): void;
    resetTargets(): void;
    get targetsInput(): cdktn.IResolvable | AwsMaintenanceWindowTask.TargetsProperty[] | undefined;
    private _taskInvocationParameters;
    get taskInvocationParameters(): AwsMaintenanceWindowTask.TaskInvocationParametersPropertyOutputReference;
    putTaskInvocationParameters(value: AwsMaintenanceWindowTask.TaskInvocationParametersProperty): void;
    resetTaskInvocationParameters(): void;
    get taskInvocationParametersInput(): AwsMaintenanceWindowTask.TaskInvocationParametersProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsMaintenanceWindowTaskTargetsPropertyToTerraform(struct?: AwsMaintenanceWindowTask.TargetsProperty | cdktn.IResolvable): any;
export declare function awsMaintenanceWindowTaskTargetsPropertyToHclTerraform(struct?: AwsMaintenanceWindowTask.TargetsProperty | cdktn.IResolvable): any;
export declare function awsMaintenanceWindowTaskTaskInvocationParametersAutomationParametersParameterPropertyToTerraform(struct?: AwsMaintenanceWindowTask.TaskInvocationParametersAutomationParametersParameterProperty | cdktn.IResolvable): any;
export declare function awsMaintenanceWindowTaskTaskInvocationParametersAutomationParametersParameterPropertyToHclTerraform(struct?: AwsMaintenanceWindowTask.TaskInvocationParametersAutomationParametersParameterProperty | cdktn.IResolvable): any;
export declare function awsMaintenanceWindowTaskAutomationParametersPropertyToTerraform(struct?: AwsMaintenanceWindowTask.AutomationParametersPropertyOutputReference | AwsMaintenanceWindowTask.AutomationParametersProperty): any;
export declare function awsMaintenanceWindowTaskAutomationParametersPropertyToHclTerraform(struct?: AwsMaintenanceWindowTask.AutomationParametersPropertyOutputReference | AwsMaintenanceWindowTask.AutomationParametersProperty): any;
export declare function awsMaintenanceWindowTaskLambdaParametersPropertyToTerraform(struct?: AwsMaintenanceWindowTask.LambdaParametersPropertyOutputReference | AwsMaintenanceWindowTask.LambdaParametersProperty): any;
export declare function awsMaintenanceWindowTaskLambdaParametersPropertyToHclTerraform(struct?: AwsMaintenanceWindowTask.LambdaParametersPropertyOutputReference | AwsMaintenanceWindowTask.LambdaParametersProperty): any;
export declare function awsMaintenanceWindowTaskCloudwatchConfigPropertyToTerraform(struct?: AwsMaintenanceWindowTask.CloudwatchConfigPropertyOutputReference | AwsMaintenanceWindowTask.CloudwatchConfigProperty): any;
export declare function awsMaintenanceWindowTaskCloudwatchConfigPropertyToHclTerraform(struct?: AwsMaintenanceWindowTask.CloudwatchConfigPropertyOutputReference | AwsMaintenanceWindowTask.CloudwatchConfigProperty): any;
export declare function awsMaintenanceWindowTaskNotificationConfigPropertyToTerraform(struct?: AwsMaintenanceWindowTask.NotificationConfigPropertyOutputReference | AwsMaintenanceWindowTask.NotificationConfigProperty): any;
export declare function awsMaintenanceWindowTaskNotificationConfigPropertyToHclTerraform(struct?: AwsMaintenanceWindowTask.NotificationConfigPropertyOutputReference | AwsMaintenanceWindowTask.NotificationConfigProperty): any;
export declare function awsMaintenanceWindowTaskTaskInvocationParametersRunCommandParametersParameterPropertyToTerraform(struct?: AwsMaintenanceWindowTask.TaskInvocationParametersRunCommandParametersParameterProperty | cdktn.IResolvable): any;
export declare function awsMaintenanceWindowTaskTaskInvocationParametersRunCommandParametersParameterPropertyToHclTerraform(struct?: AwsMaintenanceWindowTask.TaskInvocationParametersRunCommandParametersParameterProperty | cdktn.IResolvable): any;
export declare function awsMaintenanceWindowTaskRunCommandParametersPropertyToTerraform(struct?: AwsMaintenanceWindowTask.RunCommandParametersPropertyOutputReference | AwsMaintenanceWindowTask.RunCommandParametersProperty): any;
export declare function awsMaintenanceWindowTaskRunCommandParametersPropertyToHclTerraform(struct?: AwsMaintenanceWindowTask.RunCommandParametersPropertyOutputReference | AwsMaintenanceWindowTask.RunCommandParametersProperty): any;
export declare function awsMaintenanceWindowTaskStepFunctionsParametersPropertyToTerraform(struct?: AwsMaintenanceWindowTask.StepFunctionsParametersPropertyOutputReference | AwsMaintenanceWindowTask.StepFunctionsParametersProperty): any;
export declare function awsMaintenanceWindowTaskStepFunctionsParametersPropertyToHclTerraform(struct?: AwsMaintenanceWindowTask.StepFunctionsParametersPropertyOutputReference | AwsMaintenanceWindowTask.StepFunctionsParametersProperty): any;
export declare function awsMaintenanceWindowTaskTaskInvocationParametersPropertyToTerraform(struct?: AwsMaintenanceWindowTask.TaskInvocationParametersPropertyOutputReference | AwsMaintenanceWindowTask.TaskInvocationParametersProperty): any;
export declare function awsMaintenanceWindowTaskTaskInvocationParametersPropertyToHclTerraform(struct?: AwsMaintenanceWindowTask.TaskInvocationParametersPropertyOutputReference | AwsMaintenanceWindowTask.TaskInvocationParametersProperty): any;
export declare namespace AwsMaintenanceWindowTask {
    interface TargetsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssm_maintenance_window_task#key AwsMaintenanceWindowTask#key}
        */
        readonly key: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssm_maintenance_window_task#values AwsMaintenanceWindowTask#values}
        */
        readonly values: string[];
    }
    class TargetsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TargetsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TargetsProperty | cdktn.IResolvable | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        get keyInput(): string | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        get valuesInput(): string[] | undefined;
    }
    class TargetsPropertyList extends cdktn.ComplexList {
        internalValue?: TargetsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TargetsPropertyOutputReference;
    }
    interface TaskInvocationParametersAutomationParametersParameterProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssm_maintenance_window_task#name AwsMaintenanceWindowTask#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssm_maintenance_window_task#values AwsMaintenanceWindowTask#values}
        */
        readonly values: string[];
    }
    class TaskInvocationParametersAutomationParametersParameterPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TaskInvocationParametersAutomationParametersParameterProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TaskInvocationParametersAutomationParametersParameterProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        get valuesInput(): string[] | undefined;
    }
    class TaskInvocationParametersAutomationParametersParameterPropertyList extends cdktn.ComplexList {
        internalValue?: TaskInvocationParametersAutomationParametersParameterProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TaskInvocationParametersAutomationParametersParameterPropertyOutputReference;
    }
    interface AutomationParametersProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssm_maintenance_window_task#document_version AwsMaintenanceWindowTask#document_version}
        */
        readonly documentVersion?: string;
        /**
        * parameter block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssm_maintenance_window_task#parameter AwsMaintenanceWindowTask#parameter}
        */
        readonly parameter?: TaskInvocationParametersAutomationParametersParameterProperty[] | cdktn.IResolvable;
    }
    class AutomationParametersPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AutomationParametersProperty | undefined;
        set internalValue(value: AutomationParametersProperty | undefined);
        private _documentVersion?;
        get documentVersion(): string;
        set documentVersion(value: string);
        resetDocumentVersion(): void;
        get documentVersionInput(): string | undefined;
        private _parameter;
        get parameter(): TaskInvocationParametersAutomationParametersParameterPropertyList;
        putParameter(value: TaskInvocationParametersAutomationParametersParameterProperty[] | cdktn.IResolvable): void;
        resetParameter(): void;
        get parameterInput(): cdktn.IResolvable | TaskInvocationParametersAutomationParametersParameterProperty[] | undefined;
    }
    interface LambdaParametersProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssm_maintenance_window_task#client_context AwsMaintenanceWindowTask#client_context}
        */
        readonly clientContext?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssm_maintenance_window_task#payload AwsMaintenanceWindowTask#payload}
        */
        readonly payload?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssm_maintenance_window_task#qualifier AwsMaintenanceWindowTask#qualifier}
        */
        readonly qualifier?: string;
    }
    class LambdaParametersPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): LambdaParametersProperty | undefined;
        set internalValue(value: LambdaParametersProperty | undefined);
        private _clientContext?;
        get clientContext(): string;
        set clientContext(value: string);
        resetClientContext(): void;
        get clientContextInput(): string | undefined;
        private _payload?;
        get payload(): string;
        set payload(value: string);
        resetPayload(): void;
        get payloadInput(): string | undefined;
        private _qualifier?;
        get qualifier(): string;
        set qualifier(value: string);
        resetQualifier(): void;
        get qualifierInput(): string | undefined;
    }
    interface CloudwatchConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssm_maintenance_window_task#cloudwatch_log_group_name AwsMaintenanceWindowTask#cloudwatch_log_group_name}
        */
        readonly cloudwatchLogGroupName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssm_maintenance_window_task#cloudwatch_output_enabled AwsMaintenanceWindowTask#cloudwatch_output_enabled}
        */
        readonly cloudwatchOutputEnabled?: boolean | cdktn.IResolvable;
    }
    class CloudwatchConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CloudwatchConfigProperty | undefined;
        set internalValue(value: CloudwatchConfigProperty | undefined);
        private _cloudwatchLogGroupName?;
        get cloudwatchLogGroupName(): string;
        set cloudwatchLogGroupName(value: string);
        resetCloudwatchLogGroupName(): void;
        get cloudwatchLogGroupNameInput(): string | undefined;
        private _cloudwatchOutputEnabled?;
        get cloudwatchOutputEnabled(): boolean | cdktn.IResolvable;
        set cloudwatchOutputEnabled(value: boolean | cdktn.IResolvable);
        resetCloudwatchOutputEnabled(): void;
        get cloudwatchOutputEnabledInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface NotificationConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssm_maintenance_window_task#notification_arn AwsMaintenanceWindowTask#notification_arn}
        */
        readonly notificationArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssm_maintenance_window_task#notification_events AwsMaintenanceWindowTask#notification_events}
        */
        readonly notificationEvents?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssm_maintenance_window_task#notification_type AwsMaintenanceWindowTask#notification_type}
        */
        readonly notificationType?: string;
    }
    class NotificationConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): NotificationConfigProperty | undefined;
        set internalValue(value: NotificationConfigProperty | undefined);
        private _notificationArn?;
        get notificationArn(): string;
        set notificationArn(value: string);
        resetNotificationArn(): void;
        get notificationArnInput(): string | undefined;
        private _notificationEvents?;
        get notificationEvents(): string[];
        set notificationEvents(value: string[]);
        resetNotificationEvents(): void;
        get notificationEventsInput(): string[] | undefined;
        private _notificationType?;
        get notificationType(): string;
        set notificationType(value: string);
        resetNotificationType(): void;
        get notificationTypeInput(): string | undefined;
    }
    interface TaskInvocationParametersRunCommandParametersParameterProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssm_maintenance_window_task#name AwsMaintenanceWindowTask#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssm_maintenance_window_task#values AwsMaintenanceWindowTask#values}
        */
        readonly values: string[];
    }
    class TaskInvocationParametersRunCommandParametersParameterPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TaskInvocationParametersRunCommandParametersParameterProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TaskInvocationParametersRunCommandParametersParameterProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        get valuesInput(): string[] | undefined;
    }
    class TaskInvocationParametersRunCommandParametersParameterPropertyList extends cdktn.ComplexList {
        internalValue?: TaskInvocationParametersRunCommandParametersParameterProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TaskInvocationParametersRunCommandParametersParameterPropertyOutputReference;
    }
    interface RunCommandParametersProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssm_maintenance_window_task#comment AwsMaintenanceWindowTask#comment}
        */
        readonly comment?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssm_maintenance_window_task#document_hash AwsMaintenanceWindowTask#document_hash}
        */
        readonly documentHash?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssm_maintenance_window_task#document_hash_type AwsMaintenanceWindowTask#document_hash_type}
        */
        readonly documentHashType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssm_maintenance_window_task#document_version AwsMaintenanceWindowTask#document_version}
        */
        readonly documentVersion?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssm_maintenance_window_task#output_s3_bucket AwsMaintenanceWindowTask#output_s3_bucket}
        */
        readonly outputS3Bucket?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssm_maintenance_window_task#output_s3_key_prefix AwsMaintenanceWindowTask#output_s3_key_prefix}
        */
        readonly outputS3KeyPrefix?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssm_maintenance_window_task#service_role_arn AwsMaintenanceWindowTask#service_role_arn}
        */
        readonly serviceRoleArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssm_maintenance_window_task#timeout_seconds AwsMaintenanceWindowTask#timeout_seconds}
        */
        readonly timeoutSeconds?: number;
        /**
        * cloudwatch_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssm_maintenance_window_task#cloudwatch_config AwsMaintenanceWindowTask#cloudwatch_config}
        */
        readonly cloudwatchConfig?: CloudwatchConfigProperty;
        /**
        * notification_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssm_maintenance_window_task#notification_config AwsMaintenanceWindowTask#notification_config}
        */
        readonly notificationConfig?: NotificationConfigProperty;
        /**
        * parameter block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssm_maintenance_window_task#parameter AwsMaintenanceWindowTask#parameter}
        */
        readonly parameter?: TaskInvocationParametersRunCommandParametersParameterProperty[] | cdktn.IResolvable;
    }
    class RunCommandParametersPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RunCommandParametersProperty | undefined;
        set internalValue(value: RunCommandParametersProperty | undefined);
        private _comment?;
        get comment(): string;
        set comment(value: string);
        resetComment(): void;
        get commentInput(): string | undefined;
        private _documentHash?;
        get documentHash(): string;
        set documentHash(value: string);
        resetDocumentHash(): void;
        get documentHashInput(): string | undefined;
        private _documentHashType?;
        get documentHashType(): string;
        set documentHashType(value: string);
        resetDocumentHashType(): void;
        get documentHashTypeInput(): string | undefined;
        private _documentVersion?;
        get documentVersion(): string;
        set documentVersion(value: string);
        resetDocumentVersion(): void;
        get documentVersionInput(): string | undefined;
        private _outputS3Bucket?;
        get outputS3Bucket(): string;
        set outputS3Bucket(value: string);
        resetOutputS3Bucket(): void;
        get outputS3BucketInput(): string | undefined;
        private _outputS3KeyPrefix?;
        get outputS3KeyPrefix(): string;
        set outputS3KeyPrefix(value: string);
        resetOutputS3KeyPrefix(): void;
        get outputS3KeyPrefixInput(): string | undefined;
        private _serviceRoleArn?;
        get serviceRoleArn(): string;
        set serviceRoleArn(value: string);
        resetServiceRoleArn(): void;
        get serviceRoleArnInput(): string | undefined;
        private _timeoutSeconds?;
        get timeoutSeconds(): number;
        set timeoutSeconds(value: number);
        resetTimeoutSeconds(): void;
        get timeoutSecondsInput(): number | undefined;
        private _cloudwatchConfig;
        get cloudwatchConfig(): CloudwatchConfigPropertyOutputReference;
        putCloudwatchConfig(value: CloudwatchConfigProperty): void;
        resetCloudwatchConfig(): void;
        get cloudwatchConfigInput(): CloudwatchConfigProperty | undefined;
        private _notificationConfig;
        get notificationConfig(): NotificationConfigPropertyOutputReference;
        putNotificationConfig(value: NotificationConfigProperty): void;
        resetNotificationConfig(): void;
        get notificationConfigInput(): NotificationConfigProperty | undefined;
        private _parameter;
        get parameter(): TaskInvocationParametersRunCommandParametersParameterPropertyList;
        putParameter(value: TaskInvocationParametersRunCommandParametersParameterProperty[] | cdktn.IResolvable): void;
        resetParameter(): void;
        get parameterInput(): cdktn.IResolvable | TaskInvocationParametersRunCommandParametersParameterProperty[] | undefined;
    }
    interface StepFunctionsParametersProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssm_maintenance_window_task#input AwsMaintenanceWindowTask#input}
        */
        readonly input?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssm_maintenance_window_task#name AwsMaintenanceWindowTask#name}
        */
        readonly name?: string;
    }
    class StepFunctionsParametersPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): StepFunctionsParametersProperty | undefined;
        set internalValue(value: StepFunctionsParametersProperty | undefined);
        private _input?;
        get input(): string;
        set input(value: string);
        resetInput(): void;
        get inputInput(): string | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        resetName(): void;
        get nameInput(): string | undefined;
    }
    interface TaskInvocationParametersProperty {
        /**
        * automation_parameters block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssm_maintenance_window_task#automation_parameters AwsMaintenanceWindowTask#automation_parameters}
        */
        readonly automationParameters?: AutomationParametersProperty;
        /**
        * lambda_parameters block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssm_maintenance_window_task#lambda_parameters AwsMaintenanceWindowTask#lambda_parameters}
        */
        readonly lambdaParameters?: LambdaParametersProperty;
        /**
        * run_command_parameters block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssm_maintenance_window_task#run_command_parameters AwsMaintenanceWindowTask#run_command_parameters}
        */
        readonly runCommandParameters?: RunCommandParametersProperty;
        /**
        * step_functions_parameters block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssm_maintenance_window_task#step_functions_parameters AwsMaintenanceWindowTask#step_functions_parameters}
        */
        readonly stepFunctionsParameters?: StepFunctionsParametersProperty;
    }
    class TaskInvocationParametersPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TaskInvocationParametersProperty | undefined;
        set internalValue(value: TaskInvocationParametersProperty | undefined);
        private _automationParameters;
        get automationParameters(): AutomationParametersPropertyOutputReference;
        putAutomationParameters(value: AutomationParametersProperty): void;
        resetAutomationParameters(): void;
        get automationParametersInput(): AutomationParametersProperty | undefined;
        private _lambdaParameters;
        get lambdaParameters(): LambdaParametersPropertyOutputReference;
        putLambdaParameters(value: LambdaParametersProperty): void;
        resetLambdaParameters(): void;
        get lambdaParametersInput(): LambdaParametersProperty | undefined;
        private _runCommandParameters;
        get runCommandParameters(): RunCommandParametersPropertyOutputReference;
        putRunCommandParameters(value: RunCommandParametersProperty): void;
        resetRunCommandParameters(): void;
        get runCommandParametersInput(): RunCommandParametersProperty | undefined;
        private _stepFunctionsParameters;
        get stepFunctionsParameters(): StepFunctionsParametersPropertyOutputReference;
        putStepFunctionsParameters(value: StepFunctionsParametersProperty): void;
        resetStepFunctionsParameters(): void;
        get stepFunctionsParametersInput(): StepFunctionsParametersProperty | undefined;
    }
}
