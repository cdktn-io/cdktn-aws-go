import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsConnectHoursOfOperationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/connect_hours_of_operation#description AwsConnectHoursOfOperation#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/connect_hours_of_operation#id AwsConnectHoursOfOperation#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/connect_hours_of_operation#instance_id AwsConnectHoursOfOperation#instance_id}
    */
    readonly instanceId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/connect_hours_of_operation#name AwsConnectHoursOfOperation#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/connect_hours_of_operation#region AwsConnectHoursOfOperation#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/connect_hours_of_operation#tags AwsConnectHoursOfOperation#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/connect_hours_of_operation#tags_all AwsConnectHoursOfOperation#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/connect_hours_of_operation#time_zone AwsConnectHoursOfOperation#time_zone}
    */
    readonly timeZone: string;
    /**
    * config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/connect_hours_of_operation#config AwsConnectHoursOfOperation#config}
    */
    readonly config: AwsConnectHoursOfOperation.ConfigProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/connect_hours_of_operation aws_connect_hours_of_operation}
*/
export declare class AwsConnectHoursOfOperation extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_connect_hours_of_operation";
    /**
    * Generates CDKTN code for importing a AwsConnectHoursOfOperation resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsConnectHoursOfOperation to import
    * @param importFromId The id of the existing AwsConnectHoursOfOperation that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/connect_hours_of_operation#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsConnectHoursOfOperation to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/connect_hours_of_operation aws_connect_hours_of_operation} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsConnectHoursOfOperationConfig
    */
    constructor(scope: Construct, id: string, config: AwsConnectHoursOfOperationConfig);
    get arn(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get hoursOfOperationId(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _instanceId?;
    get instanceId(): string;
    set instanceId(value: string);
    get instanceIdInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _timeZone?;
    get timeZone(): string;
    set timeZone(value: string);
    get timeZoneInput(): string | undefined;
    private _config;
    get config(): AwsConnectHoursOfOperation.ConfigPropertyList;
    putConfig(value: AwsConnectHoursOfOperation.ConfigProperty[] | cdktn.IResolvable): void;
    get configInput(): cdktn.IResolvable | AwsConnectHoursOfOperation.ConfigProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsConnectHoursOfOperationEndTimePropertyToTerraform(struct?: AwsConnectHoursOfOperation.EndTimePropertyOutputReference | AwsConnectHoursOfOperation.EndTimeProperty): any;
export declare function awsConnectHoursOfOperationEndTimePropertyToHclTerraform(struct?: AwsConnectHoursOfOperation.EndTimePropertyOutputReference | AwsConnectHoursOfOperation.EndTimeProperty): any;
export declare function awsConnectHoursOfOperationStartTimePropertyToTerraform(struct?: AwsConnectHoursOfOperation.StartTimePropertyOutputReference | AwsConnectHoursOfOperation.StartTimeProperty): any;
export declare function awsConnectHoursOfOperationStartTimePropertyToHclTerraform(struct?: AwsConnectHoursOfOperation.StartTimePropertyOutputReference | AwsConnectHoursOfOperation.StartTimeProperty): any;
export declare function awsConnectHoursOfOperationConfigPropertyToTerraform(struct?: AwsConnectHoursOfOperation.ConfigProperty | cdktn.IResolvable): any;
export declare function awsConnectHoursOfOperationConfigPropertyToHclTerraform(struct?: AwsConnectHoursOfOperation.ConfigProperty | cdktn.IResolvable): any;
export declare namespace AwsConnectHoursOfOperation {
    interface EndTimeProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/connect_hours_of_operation#hours AwsConnectHoursOfOperation#hours}
        */
        readonly hours: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/connect_hours_of_operation#minutes AwsConnectHoursOfOperation#minutes}
        */
        readonly minutes: number;
    }
    class EndTimePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): EndTimeProperty | undefined;
        set internalValue(value: EndTimeProperty | undefined);
        private _hours?;
        get hours(): number;
        set hours(value: number);
        get hoursInput(): number | undefined;
        private _minutes?;
        get minutes(): number;
        set minutes(value: number);
        get minutesInput(): number | undefined;
    }
    interface StartTimeProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/connect_hours_of_operation#hours AwsConnectHoursOfOperation#hours}
        */
        readonly hours: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/connect_hours_of_operation#minutes AwsConnectHoursOfOperation#minutes}
        */
        readonly minutes: number;
    }
    class StartTimePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): StartTimeProperty | undefined;
        set internalValue(value: StartTimeProperty | undefined);
        private _hours?;
        get hours(): number;
        set hours(value: number);
        get hoursInput(): number | undefined;
        private _minutes?;
        get minutes(): number;
        set minutes(value: number);
        get minutesInput(): number | undefined;
    }
    interface ConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/connect_hours_of_operation#day AwsConnectHoursOfOperation#day}
        */
        readonly day: string;
        /**
        * end_time block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/connect_hours_of_operation#end_time AwsConnectHoursOfOperation#end_time}
        */
        readonly endTime: EndTimeProperty;
        /**
        * start_time block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/connect_hours_of_operation#start_time AwsConnectHoursOfOperation#start_time}
        */
        readonly startTime: StartTimeProperty;
    }
    class ConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ConfigProperty | cdktn.IResolvable | undefined);
        private _day?;
        get day(): string;
        set day(value: string);
        get dayInput(): string | undefined;
        private _endTime;
        get endTime(): EndTimePropertyOutputReference;
        putEndTime(value: EndTimeProperty): void;
        get endTimeInput(): EndTimeProperty | undefined;
        private _startTime;
        get startTime(): StartTimePropertyOutputReference;
        putStartTime(value: StartTimeProperty): void;
        get startTimeInput(): StartTimeProperty | undefined;
    }
    class ConfigPropertyList extends cdktn.ComplexList {
        internalValue?: ConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ConfigPropertyOutputReference;
    }
}
