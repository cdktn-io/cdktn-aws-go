import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsConnectInstanceStorageConfigConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/connect_instance_storage_config#id AwsConnectInstanceStorageConfig#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/connect_instance_storage_config#instance_id AwsConnectInstanceStorageConfig#instance_id}
    */
    readonly instanceId: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/connect_instance_storage_config#region AwsConnectInstanceStorageConfig#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/connect_instance_storage_config#resource_type AwsConnectInstanceStorageConfig#resource_type}
    */
    readonly resourceType: string;
    /**
    * storage_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/connect_instance_storage_config#storage_config AwsConnectInstanceStorageConfig#storage_config}
    */
    readonly storageConfig: AwsConnectInstanceStorageConfig.StorageConfigProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/connect_instance_storage_config aws_connect_instance_storage_config}
*/
export declare class AwsConnectInstanceStorageConfig extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_connect_instance_storage_config";
    /**
    * Generates CDKTN code for importing a AwsConnectInstanceStorageConfig resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsConnectInstanceStorageConfig to import
    * @param importFromId The id of the existing AwsConnectInstanceStorageConfig that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/connect_instance_storage_config#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsConnectInstanceStorageConfig to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/connect_instance_storage_config aws_connect_instance_storage_config} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsConnectInstanceStorageConfigConfig
    */
    constructor(scope: Construct, id: string, config: AwsConnectInstanceStorageConfigConfig);
    get associationId(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _instanceId?;
    get instanceId(): string;
    set instanceId(value: string);
    get instanceIdInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _resourceType?;
    get resourceType(): string;
    set resourceType(value: string);
    get resourceTypeInput(): string | undefined;
    private _storageConfig;
    get storageConfig(): AwsConnectInstanceStorageConfig.StorageConfigPropertyOutputReference;
    putStorageConfig(value: AwsConnectInstanceStorageConfig.StorageConfigProperty): void;
    get storageConfigInput(): AwsConnectInstanceStorageConfig.StorageConfigProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsConnectInstanceStorageConfigKinesisFirehoseConfigPropertyToTerraform(struct?: AwsConnectInstanceStorageConfig.KinesisFirehoseConfigPropertyOutputReference | AwsConnectInstanceStorageConfig.KinesisFirehoseConfigProperty): any;
export declare function awsConnectInstanceStorageConfigKinesisFirehoseConfigPropertyToHclTerraform(struct?: AwsConnectInstanceStorageConfig.KinesisFirehoseConfigPropertyOutputReference | AwsConnectInstanceStorageConfig.KinesisFirehoseConfigProperty): any;
export declare function awsConnectInstanceStorageConfigKinesisStreamConfigPropertyToTerraform(struct?: AwsConnectInstanceStorageConfig.KinesisStreamConfigPropertyOutputReference | AwsConnectInstanceStorageConfig.KinesisStreamConfigProperty): any;
export declare function awsConnectInstanceStorageConfigKinesisStreamConfigPropertyToHclTerraform(struct?: AwsConnectInstanceStorageConfig.KinesisStreamConfigPropertyOutputReference | AwsConnectInstanceStorageConfig.KinesisStreamConfigProperty): any;
export declare function awsConnectInstanceStorageConfigStorageConfigKinesisVideoStreamConfigEncryptionConfigPropertyToTerraform(struct?: AwsConnectInstanceStorageConfig.StorageConfigKinesisVideoStreamConfigEncryptionConfigPropertyOutputReference | AwsConnectInstanceStorageConfig.StorageConfigKinesisVideoStreamConfigEncryptionConfigProperty): any;
export declare function awsConnectInstanceStorageConfigStorageConfigKinesisVideoStreamConfigEncryptionConfigPropertyToHclTerraform(struct?: AwsConnectInstanceStorageConfig.StorageConfigKinesisVideoStreamConfigEncryptionConfigPropertyOutputReference | AwsConnectInstanceStorageConfig.StorageConfigKinesisVideoStreamConfigEncryptionConfigProperty): any;
export declare function awsConnectInstanceStorageConfigKinesisVideoStreamConfigPropertyToTerraform(struct?: AwsConnectInstanceStorageConfig.KinesisVideoStreamConfigPropertyOutputReference | AwsConnectInstanceStorageConfig.KinesisVideoStreamConfigProperty): any;
export declare function awsConnectInstanceStorageConfigKinesisVideoStreamConfigPropertyToHclTerraform(struct?: AwsConnectInstanceStorageConfig.KinesisVideoStreamConfigPropertyOutputReference | AwsConnectInstanceStorageConfig.KinesisVideoStreamConfigProperty): any;
export declare function awsConnectInstanceStorageConfigStorageConfigS3ConfigEncryptionConfigPropertyToTerraform(struct?: AwsConnectInstanceStorageConfig.StorageConfigS3ConfigEncryptionConfigPropertyOutputReference | AwsConnectInstanceStorageConfig.StorageConfigS3ConfigEncryptionConfigProperty): any;
export declare function awsConnectInstanceStorageConfigStorageConfigS3ConfigEncryptionConfigPropertyToHclTerraform(struct?: AwsConnectInstanceStorageConfig.StorageConfigS3ConfigEncryptionConfigPropertyOutputReference | AwsConnectInstanceStorageConfig.StorageConfigS3ConfigEncryptionConfigProperty): any;
export declare function awsConnectInstanceStorageConfigS3ConfigPropertyToTerraform(struct?: AwsConnectInstanceStorageConfig.S3ConfigPropertyOutputReference | AwsConnectInstanceStorageConfig.S3ConfigProperty): any;
export declare function awsConnectInstanceStorageConfigS3ConfigPropertyToHclTerraform(struct?: AwsConnectInstanceStorageConfig.S3ConfigPropertyOutputReference | AwsConnectInstanceStorageConfig.S3ConfigProperty): any;
export declare function awsConnectInstanceStorageConfigStorageConfigPropertyToTerraform(struct?: AwsConnectInstanceStorageConfig.StorageConfigPropertyOutputReference | AwsConnectInstanceStorageConfig.StorageConfigProperty): any;
export declare function awsConnectInstanceStorageConfigStorageConfigPropertyToHclTerraform(struct?: AwsConnectInstanceStorageConfig.StorageConfigPropertyOutputReference | AwsConnectInstanceStorageConfig.StorageConfigProperty): any;
export declare namespace AwsConnectInstanceStorageConfig {
    interface KinesisFirehoseConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/connect_instance_storage_config#firehose_arn AwsConnectInstanceStorageConfig#firehose_arn}
        */
        readonly firehoseArn: string;
    }
    class KinesisFirehoseConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): KinesisFirehoseConfigProperty | undefined;
        set internalValue(value: KinesisFirehoseConfigProperty | undefined);
        private _firehoseArn?;
        get firehoseArn(): string;
        set firehoseArn(value: string);
        get firehoseArnInput(): string | undefined;
    }
    interface KinesisStreamConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/connect_instance_storage_config#stream_arn AwsConnectInstanceStorageConfig#stream_arn}
        */
        readonly streamArn: string;
    }
    class KinesisStreamConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): KinesisStreamConfigProperty | undefined;
        set internalValue(value: KinesisStreamConfigProperty | undefined);
        private _streamArn?;
        get streamArn(): string;
        set streamArn(value: string);
        get streamArnInput(): string | undefined;
    }
    interface StorageConfigKinesisVideoStreamConfigEncryptionConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/connect_instance_storage_config#encryption_type AwsConnectInstanceStorageConfig#encryption_type}
        */
        readonly encryptionType: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/connect_instance_storage_config#key_id AwsConnectInstanceStorageConfig#key_id}
        */
        readonly keyId: string;
    }
    class StorageConfigKinesisVideoStreamConfigEncryptionConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): StorageConfigKinesisVideoStreamConfigEncryptionConfigProperty | undefined;
        set internalValue(value: StorageConfigKinesisVideoStreamConfigEncryptionConfigProperty | undefined);
        private _encryptionType?;
        get encryptionType(): string;
        set encryptionType(value: string);
        get encryptionTypeInput(): string | undefined;
        private _keyId?;
        get keyId(): string;
        set keyId(value: string);
        get keyIdInput(): string | undefined;
    }
    interface KinesisVideoStreamConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/connect_instance_storage_config#prefix AwsConnectInstanceStorageConfig#prefix}
        */
        readonly prefix: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/connect_instance_storage_config#retention_period_hours AwsConnectInstanceStorageConfig#retention_period_hours}
        */
        readonly retentionPeriodHours: number;
        /**
        * encryption_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/connect_instance_storage_config#encryption_config AwsConnectInstanceStorageConfig#encryption_config}
        */
        readonly encryptionConfig: StorageConfigKinesisVideoStreamConfigEncryptionConfigProperty;
    }
    class KinesisVideoStreamConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): KinesisVideoStreamConfigProperty | undefined;
        set internalValue(value: KinesisVideoStreamConfigProperty | undefined);
        private _prefix?;
        get prefix(): string;
        set prefix(value: string);
        get prefixInput(): string | undefined;
        private _retentionPeriodHours?;
        get retentionPeriodHours(): number;
        set retentionPeriodHours(value: number);
        get retentionPeriodHoursInput(): number | undefined;
        private _encryptionConfig;
        get encryptionConfig(): StorageConfigKinesisVideoStreamConfigEncryptionConfigPropertyOutputReference;
        putEncryptionConfig(value: StorageConfigKinesisVideoStreamConfigEncryptionConfigProperty): void;
        get encryptionConfigInput(): StorageConfigKinesisVideoStreamConfigEncryptionConfigProperty | undefined;
    }
    interface StorageConfigS3ConfigEncryptionConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/connect_instance_storage_config#encryption_type AwsConnectInstanceStorageConfig#encryption_type}
        */
        readonly encryptionType: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/connect_instance_storage_config#key_id AwsConnectInstanceStorageConfig#key_id}
        */
        readonly keyId: string;
    }
    class StorageConfigS3ConfigEncryptionConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): StorageConfigS3ConfigEncryptionConfigProperty | undefined;
        set internalValue(value: StorageConfigS3ConfigEncryptionConfigProperty | undefined);
        private _encryptionType?;
        get encryptionType(): string;
        set encryptionType(value: string);
        get encryptionTypeInput(): string | undefined;
        private _keyId?;
        get keyId(): string;
        set keyId(value: string);
        get keyIdInput(): string | undefined;
    }
    interface S3ConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/connect_instance_storage_config#bucket_name AwsConnectInstanceStorageConfig#bucket_name}
        */
        readonly bucketName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/connect_instance_storage_config#bucket_prefix AwsConnectInstanceStorageConfig#bucket_prefix}
        */
        readonly bucketPrefix: string;
        /**
        * encryption_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/connect_instance_storage_config#encryption_config AwsConnectInstanceStorageConfig#encryption_config}
        */
        readonly encryptionConfig?: StorageConfigS3ConfigEncryptionConfigProperty;
    }
    class S3ConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): S3ConfigProperty | undefined;
        set internalValue(value: S3ConfigProperty | undefined);
        private _bucketName?;
        get bucketName(): string;
        set bucketName(value: string);
        get bucketNameInput(): string | undefined;
        private _bucketPrefix?;
        get bucketPrefix(): string;
        set bucketPrefix(value: string);
        get bucketPrefixInput(): string | undefined;
        private _encryptionConfig;
        get encryptionConfig(): StorageConfigS3ConfigEncryptionConfigPropertyOutputReference;
        putEncryptionConfig(value: StorageConfigS3ConfigEncryptionConfigProperty): void;
        resetEncryptionConfig(): void;
        get encryptionConfigInput(): StorageConfigS3ConfigEncryptionConfigProperty | undefined;
    }
    interface StorageConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/connect_instance_storage_config#storage_type AwsConnectInstanceStorageConfig#storage_type}
        */
        readonly storageType: string;
        /**
        * kinesis_firehose_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/connect_instance_storage_config#kinesis_firehose_config AwsConnectInstanceStorageConfig#kinesis_firehose_config}
        */
        readonly kinesisFirehoseConfig?: KinesisFirehoseConfigProperty;
        /**
        * kinesis_stream_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/connect_instance_storage_config#kinesis_stream_config AwsConnectInstanceStorageConfig#kinesis_stream_config}
        */
        readonly kinesisStreamConfig?: KinesisStreamConfigProperty;
        /**
        * kinesis_video_stream_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/connect_instance_storage_config#kinesis_video_stream_config AwsConnectInstanceStorageConfig#kinesis_video_stream_config}
        */
        readonly kinesisVideoStreamConfig?: KinesisVideoStreamConfigProperty;
        /**
        * s3_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/connect_instance_storage_config#s3_config AwsConnectInstanceStorageConfig#s3_config}
        */
        readonly s3Config?: S3ConfigProperty;
    }
    class StorageConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): StorageConfigProperty | undefined;
        set internalValue(value: StorageConfigProperty | undefined);
        private _storageType?;
        get storageType(): string;
        set storageType(value: string);
        get storageTypeInput(): string | undefined;
        private _kinesisFirehoseConfig;
        get kinesisFirehoseConfig(): KinesisFirehoseConfigPropertyOutputReference;
        putKinesisFirehoseConfig(value: KinesisFirehoseConfigProperty): void;
        resetKinesisFirehoseConfig(): void;
        get kinesisFirehoseConfigInput(): KinesisFirehoseConfigProperty | undefined;
        private _kinesisStreamConfig;
        get kinesisStreamConfig(): KinesisStreamConfigPropertyOutputReference;
        putKinesisStreamConfig(value: KinesisStreamConfigProperty): void;
        resetKinesisStreamConfig(): void;
        get kinesisStreamConfigInput(): KinesisStreamConfigProperty | undefined;
        private _kinesisVideoStreamConfig;
        get kinesisVideoStreamConfig(): KinesisVideoStreamConfigPropertyOutputReference;
        putKinesisVideoStreamConfig(value: KinesisVideoStreamConfigProperty): void;
        resetKinesisVideoStreamConfig(): void;
        get kinesisVideoStreamConfigInput(): KinesisVideoStreamConfigProperty | undefined;
        private _s3Config;
        get s3Config(): S3ConfigPropertyOutputReference;
        putS3Config(value: S3ConfigProperty): void;
        resetS3Config(): void;
        get s3ConfigInput(): S3ConfigProperty | undefined;
    }
}
