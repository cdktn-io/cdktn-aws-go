import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsConnectQuickConnectConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/connect_quick_connect#description AwsConnectQuickConnect#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/connect_quick_connect#id AwsConnectQuickConnect#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/connect_quick_connect#instance_id AwsConnectQuickConnect#instance_id}
    */
    readonly instanceId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/connect_quick_connect#name AwsConnectQuickConnect#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/connect_quick_connect#region AwsConnectQuickConnect#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/connect_quick_connect#tags AwsConnectQuickConnect#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/connect_quick_connect#tags_all AwsConnectQuickConnect#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * quick_connect_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/connect_quick_connect#quick_connect_config AwsConnectQuickConnect#quick_connect_config}
    */
    readonly quickConnectConfig: AwsConnectQuickConnect.QuickConnectConfigProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/connect_quick_connect aws_connect_quick_connect}
*/
export declare class AwsConnectQuickConnect extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_connect_quick_connect";
    /**
    * Generates CDKTN code for importing a AwsConnectQuickConnect resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsConnectQuickConnect to import
    * @param importFromId The id of the existing AwsConnectQuickConnect that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/connect_quick_connect#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsConnectQuickConnect to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/connect_quick_connect aws_connect_quick_connect} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsConnectQuickConnectConfig
    */
    constructor(scope: Construct, id: string, config: AwsConnectQuickConnectConfig);
    get arn(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _instanceId?;
    get instanceId(): string;
    set instanceId(value: string);
    get instanceIdInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get quickConnectId(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _quickConnectConfig;
    get quickConnectConfig(): AwsConnectQuickConnect.QuickConnectConfigPropertyOutputReference;
    putQuickConnectConfig(value: AwsConnectQuickConnect.QuickConnectConfigProperty): void;
    get quickConnectConfigInput(): AwsConnectQuickConnect.QuickConnectConfigProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsConnectQuickConnectPhoneConfigPropertyToTerraform(struct?: AwsConnectQuickConnect.PhoneConfigProperty | cdktn.IResolvable): any;
export declare function awsConnectQuickConnectPhoneConfigPropertyToHclTerraform(struct?: AwsConnectQuickConnect.PhoneConfigProperty | cdktn.IResolvable): any;
export declare function awsConnectQuickConnectQueueConfigPropertyToTerraform(struct?: AwsConnectQuickConnect.QueueConfigProperty | cdktn.IResolvable): any;
export declare function awsConnectQuickConnectQueueConfigPropertyToHclTerraform(struct?: AwsConnectQuickConnect.QueueConfigProperty | cdktn.IResolvable): any;
export declare function awsConnectQuickConnectUserConfigPropertyToTerraform(struct?: AwsConnectQuickConnect.UserConfigProperty | cdktn.IResolvable): any;
export declare function awsConnectQuickConnectUserConfigPropertyToHclTerraform(struct?: AwsConnectQuickConnect.UserConfigProperty | cdktn.IResolvable): any;
export declare function awsConnectQuickConnectQuickConnectConfigPropertyToTerraform(struct?: AwsConnectQuickConnect.QuickConnectConfigPropertyOutputReference | AwsConnectQuickConnect.QuickConnectConfigProperty): any;
export declare function awsConnectQuickConnectQuickConnectConfigPropertyToHclTerraform(struct?: AwsConnectQuickConnect.QuickConnectConfigPropertyOutputReference | AwsConnectQuickConnect.QuickConnectConfigProperty): any;
export declare namespace AwsConnectQuickConnect {
    interface PhoneConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/connect_quick_connect#phone_number AwsConnectQuickConnect#phone_number}
        */
        readonly phoneNumber: string;
    }
    class PhoneConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): PhoneConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: PhoneConfigProperty | cdktn.IResolvable | undefined);
        private _phoneNumber?;
        get phoneNumber(): string;
        set phoneNumber(value: string);
        get phoneNumberInput(): string | undefined;
    }
    class PhoneConfigPropertyList extends cdktn.ComplexList {
        internalValue?: PhoneConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): PhoneConfigPropertyOutputReference;
    }
    interface QueueConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/connect_quick_connect#contact_flow_id AwsConnectQuickConnect#contact_flow_id}
        */
        readonly contactFlowId: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/connect_quick_connect#queue_id AwsConnectQuickConnect#queue_id}
        */
        readonly queueId: string;
    }
    class QueueConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): QueueConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: QueueConfigProperty | cdktn.IResolvable | undefined);
        private _contactFlowId?;
        get contactFlowId(): string;
        set contactFlowId(value: string);
        get contactFlowIdInput(): string | undefined;
        private _queueId?;
        get queueId(): string;
        set queueId(value: string);
        get queueIdInput(): string | undefined;
    }
    class QueueConfigPropertyList extends cdktn.ComplexList {
        internalValue?: QueueConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): QueueConfigPropertyOutputReference;
    }
    interface UserConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/connect_quick_connect#contact_flow_id AwsConnectQuickConnect#contact_flow_id}
        */
        readonly contactFlowId: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/connect_quick_connect#user_id AwsConnectQuickConnect#user_id}
        */
        readonly userId: string;
    }
    class UserConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): UserConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: UserConfigProperty | cdktn.IResolvable | undefined);
        private _contactFlowId?;
        get contactFlowId(): string;
        set contactFlowId(value: string);
        get contactFlowIdInput(): string | undefined;
        private _userId?;
        get userId(): string;
        set userId(value: string);
        get userIdInput(): string | undefined;
    }
    class UserConfigPropertyList extends cdktn.ComplexList {
        internalValue?: UserConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): UserConfigPropertyOutputReference;
    }
    interface QuickConnectConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/connect_quick_connect#quick_connect_type AwsConnectQuickConnect#quick_connect_type}
        */
        readonly quickConnectType: string;
        /**
        * phone_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/connect_quick_connect#phone_config AwsConnectQuickConnect#phone_config}
        */
        readonly phoneConfig?: PhoneConfigProperty[] | cdktn.IResolvable;
        /**
        * queue_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/connect_quick_connect#queue_config AwsConnectQuickConnect#queue_config}
        */
        readonly queueConfig?: QueueConfigProperty[] | cdktn.IResolvable;
        /**
        * user_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/connect_quick_connect#user_config AwsConnectQuickConnect#user_config}
        */
        readonly userConfig?: UserConfigProperty[] | cdktn.IResolvable;
    }
    class QuickConnectConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): QuickConnectConfigProperty | undefined;
        set internalValue(value: QuickConnectConfigProperty | undefined);
        private _quickConnectType?;
        get quickConnectType(): string;
        set quickConnectType(value: string);
        get quickConnectTypeInput(): string | undefined;
        private _phoneConfig;
        get phoneConfig(): PhoneConfigPropertyList;
        putPhoneConfig(value: PhoneConfigProperty[] | cdktn.IResolvable): void;
        resetPhoneConfig(): void;
        get phoneConfigInput(): cdktn.IResolvable | PhoneConfigProperty[] | undefined;
        private _queueConfig;
        get queueConfig(): QueueConfigPropertyList;
        putQueueConfig(value: QueueConfigProperty[] | cdktn.IResolvable): void;
        resetQueueConfig(): void;
        get queueConfigInput(): cdktn.IResolvable | QueueConfigProperty[] | undefined;
        private _userConfig;
        get userConfig(): UserConfigPropertyList;
        putUserConfig(value: UserConfigProperty[] | cdktn.IResolvable): void;
        resetUserConfig(): void;
        get userConfigInput(): cdktn.IResolvable | UserConfigProperty[] | undefined;
    }
}
