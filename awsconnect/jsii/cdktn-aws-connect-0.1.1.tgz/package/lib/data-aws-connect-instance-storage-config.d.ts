import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsConnectInstanceStorageConfigConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/connect_instance_storage_config#association_id DataAwsConnectInstanceStorageConfig#association_id}
    */
    readonly associationId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/connect_instance_storage_config#id DataAwsConnectInstanceStorageConfig#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/connect_instance_storage_config#instance_id DataAwsConnectInstanceStorageConfig#instance_id}
    */
    readonly instanceId: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/connect_instance_storage_config#region DataAwsConnectInstanceStorageConfig#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/connect_instance_storage_config#resource_type DataAwsConnectInstanceStorageConfig#resource_type}
    */
    readonly resourceType: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/connect_instance_storage_config aws_connect_instance_storage_config}
*/
export declare class DataAwsConnectInstanceStorageConfig extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_connect_instance_storage_config";
    /**
    * Generates CDKTN code for importing a DataAwsConnectInstanceStorageConfig resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsConnectInstanceStorageConfig to import
    * @param importFromId The id of the existing DataAwsConnectInstanceStorageConfig that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/connect_instance_storage_config#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsConnectInstanceStorageConfig to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/connect_instance_storage_config aws_connect_instance_storage_config} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsConnectInstanceStorageConfigConfig
    */
    constructor(scope: Construct, id: string, config: DataAwsConnectInstanceStorageConfigConfig);
    private _associationId?;
    get associationId(): string;
    set associationId(value: string);
    get associationIdInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _instanceId?;
    get instanceId(): string;
    set instanceId(value: string);
    get instanceIdInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _resourceType?;
    get resourceType(): string;
    set resourceType(value: string);
    get resourceTypeInput(): string | undefined;
    private _storageConfig;
    get storageConfig(): DataAwsConnectInstanceStorageConfig.StorageConfigPropertyList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataAwsConnectInstanceStorageConfigKinesisFirehoseConfigPropertyToTerraform(struct?: DataAwsConnectInstanceStorageConfig.KinesisFirehoseConfigProperty): any;
export declare function dataAwsConnectInstanceStorageConfigKinesisFirehoseConfigPropertyToHclTerraform(struct?: DataAwsConnectInstanceStorageConfig.KinesisFirehoseConfigProperty): any;
export declare function dataAwsConnectInstanceStorageConfigKinesisStreamConfigPropertyToTerraform(struct?: DataAwsConnectInstanceStorageConfig.KinesisStreamConfigProperty): any;
export declare function dataAwsConnectInstanceStorageConfigKinesisStreamConfigPropertyToHclTerraform(struct?: DataAwsConnectInstanceStorageConfig.KinesisStreamConfigProperty): any;
export declare function dataAwsConnectInstanceStorageConfigStorageConfigKinesisVideoStreamConfigEncryptionConfigPropertyToTerraform(struct?: DataAwsConnectInstanceStorageConfig.StorageConfigKinesisVideoStreamConfigEncryptionConfigProperty): any;
export declare function dataAwsConnectInstanceStorageConfigStorageConfigKinesisVideoStreamConfigEncryptionConfigPropertyToHclTerraform(struct?: DataAwsConnectInstanceStorageConfig.StorageConfigKinesisVideoStreamConfigEncryptionConfigProperty): any;
export declare function dataAwsConnectInstanceStorageConfigKinesisVideoStreamConfigPropertyToTerraform(struct?: DataAwsConnectInstanceStorageConfig.KinesisVideoStreamConfigProperty): any;
export declare function dataAwsConnectInstanceStorageConfigKinesisVideoStreamConfigPropertyToHclTerraform(struct?: DataAwsConnectInstanceStorageConfig.KinesisVideoStreamConfigProperty): any;
export declare function dataAwsConnectInstanceStorageConfigStorageConfigS3ConfigEncryptionConfigPropertyToTerraform(struct?: DataAwsConnectInstanceStorageConfig.StorageConfigS3ConfigEncryptionConfigProperty): any;
export declare function dataAwsConnectInstanceStorageConfigStorageConfigS3ConfigEncryptionConfigPropertyToHclTerraform(struct?: DataAwsConnectInstanceStorageConfig.StorageConfigS3ConfigEncryptionConfigProperty): any;
export declare function dataAwsConnectInstanceStorageConfigS3ConfigPropertyToTerraform(struct?: DataAwsConnectInstanceStorageConfig.S3ConfigProperty): any;
export declare function dataAwsConnectInstanceStorageConfigS3ConfigPropertyToHclTerraform(struct?: DataAwsConnectInstanceStorageConfig.S3ConfigProperty): any;
export declare function dataAwsConnectInstanceStorageConfigStorageConfigPropertyToTerraform(struct?: DataAwsConnectInstanceStorageConfig.StorageConfigProperty): any;
export declare function dataAwsConnectInstanceStorageConfigStorageConfigPropertyToHclTerraform(struct?: DataAwsConnectInstanceStorageConfig.StorageConfigProperty): any;
export declare namespace DataAwsConnectInstanceStorageConfig {
    interface KinesisFirehoseConfigProperty {
    }
    class KinesisFirehoseConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): KinesisFirehoseConfigProperty | undefined;
        set internalValue(value: KinesisFirehoseConfigProperty | undefined);
        get firehoseArn(): string;
    }
    class KinesisFirehoseConfigPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): KinesisFirehoseConfigPropertyOutputReference;
    }
    interface KinesisStreamConfigProperty {
    }
    class KinesisStreamConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): KinesisStreamConfigProperty | undefined;
        set internalValue(value: KinesisStreamConfigProperty | undefined);
        get streamArn(): string;
    }
    class KinesisStreamConfigPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): KinesisStreamConfigPropertyOutputReference;
    }
    interface StorageConfigKinesisVideoStreamConfigEncryptionConfigProperty {
    }
    class StorageConfigKinesisVideoStreamConfigEncryptionConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): StorageConfigKinesisVideoStreamConfigEncryptionConfigProperty | undefined;
        set internalValue(value: StorageConfigKinesisVideoStreamConfigEncryptionConfigProperty | undefined);
        get encryptionType(): string;
        get keyId(): string;
    }
    class StorageConfigKinesisVideoStreamConfigEncryptionConfigPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): StorageConfigKinesisVideoStreamConfigEncryptionConfigPropertyOutputReference;
    }
    interface KinesisVideoStreamConfigProperty {
    }
    class KinesisVideoStreamConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): KinesisVideoStreamConfigProperty | undefined;
        set internalValue(value: KinesisVideoStreamConfigProperty | undefined);
        private _encryptionConfig;
        get encryptionConfig(): StorageConfigKinesisVideoStreamConfigEncryptionConfigPropertyList;
        get prefix(): string;
        get retentionPeriodHours(): number;
    }
    class KinesisVideoStreamConfigPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): KinesisVideoStreamConfigPropertyOutputReference;
    }
    interface StorageConfigS3ConfigEncryptionConfigProperty {
    }
    class StorageConfigS3ConfigEncryptionConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): StorageConfigS3ConfigEncryptionConfigProperty | undefined;
        set internalValue(value: StorageConfigS3ConfigEncryptionConfigProperty | undefined);
        get encryptionType(): string;
        get keyId(): string;
    }
    class StorageConfigS3ConfigEncryptionConfigPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): StorageConfigS3ConfigEncryptionConfigPropertyOutputReference;
    }
    interface S3ConfigProperty {
    }
    class S3ConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): S3ConfigProperty | undefined;
        set internalValue(value: S3ConfigProperty | undefined);
        get bucketName(): string;
        get bucketPrefix(): string;
        private _encryptionConfig;
        get encryptionConfig(): StorageConfigS3ConfigEncryptionConfigPropertyList;
    }
    class S3ConfigPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): S3ConfigPropertyOutputReference;
    }
    interface StorageConfigProperty {
    }
    class StorageConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): StorageConfigProperty | undefined;
        set internalValue(value: StorageConfigProperty | undefined);
        private _kinesisFirehoseConfig;
        get kinesisFirehoseConfig(): KinesisFirehoseConfigPropertyList;
        private _kinesisStreamConfig;
        get kinesisStreamConfig(): KinesisStreamConfigPropertyList;
        private _kinesisVideoStreamConfig;
        get kinesisVideoStreamConfig(): KinesisVideoStreamConfigPropertyList;
        private _s3Config;
        get s3Config(): S3ConfigPropertyList;
        get storageType(): string;
    }
    class StorageConfigPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): StorageConfigPropertyOutputReference;
    }
}
