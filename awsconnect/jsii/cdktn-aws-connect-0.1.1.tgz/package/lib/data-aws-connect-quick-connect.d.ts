import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsConnectQuickConnectConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/connect_quick_connect#id DataAwsConnectQuickConnect#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/connect_quick_connect#instance_id DataAwsConnectQuickConnect#instance_id}
    */
    readonly instanceId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/connect_quick_connect#name DataAwsConnectQuickConnect#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/connect_quick_connect#quick_connect_id DataAwsConnectQuickConnect#quick_connect_id}
    */
    readonly quickConnectId?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/connect_quick_connect#region DataAwsConnectQuickConnect#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/connect_quick_connect#tags DataAwsConnectQuickConnect#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/connect_quick_connect aws_connect_quick_connect}
*/
export declare class DataAwsConnectQuickConnect extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_connect_quick_connect";
    /**
    * Generates CDKTN code for importing a DataAwsConnectQuickConnect resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsConnectQuickConnect to import
    * @param importFromId The id of the existing DataAwsConnectQuickConnect that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/connect_quick_connect#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsConnectQuickConnect to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/connect_quick_connect aws_connect_quick_connect} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsConnectQuickConnectConfig
    */
    constructor(scope: Construct, id: string, config: DataAwsConnectQuickConnectConfig);
    get arn(): string;
    get description(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _instanceId?;
    get instanceId(): string;
    set instanceId(value: string);
    get instanceIdInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _quickConnectConfig;
    get quickConnectConfig(): DataAwsConnectQuickConnect.QuickConnectConfigPropertyList;
    private _quickConnectId?;
    get quickConnectId(): string;
    set quickConnectId(value: string);
    resetQuickConnectId(): void;
    get quickConnectIdInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataAwsConnectQuickConnectPhoneConfigPropertyToTerraform(struct?: DataAwsConnectQuickConnect.PhoneConfigProperty): any;
export declare function dataAwsConnectQuickConnectPhoneConfigPropertyToHclTerraform(struct?: DataAwsConnectQuickConnect.PhoneConfigProperty): any;
export declare function dataAwsConnectQuickConnectQueueConfigPropertyToTerraform(struct?: DataAwsConnectQuickConnect.QueueConfigProperty): any;
export declare function dataAwsConnectQuickConnectQueueConfigPropertyToHclTerraform(struct?: DataAwsConnectQuickConnect.QueueConfigProperty): any;
export declare function dataAwsConnectQuickConnectUserConfigPropertyToTerraform(struct?: DataAwsConnectQuickConnect.UserConfigProperty): any;
export declare function dataAwsConnectQuickConnectUserConfigPropertyToHclTerraform(struct?: DataAwsConnectQuickConnect.UserConfigProperty): any;
export declare function dataAwsConnectQuickConnectQuickConnectConfigPropertyToTerraform(struct?: DataAwsConnectQuickConnect.QuickConnectConfigProperty): any;
export declare function dataAwsConnectQuickConnectQuickConnectConfigPropertyToHclTerraform(struct?: DataAwsConnectQuickConnect.QuickConnectConfigProperty): any;
export declare namespace DataAwsConnectQuickConnect {
    interface PhoneConfigProperty {
    }
    class PhoneConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): PhoneConfigProperty | undefined;
        set internalValue(value: PhoneConfigProperty | undefined);
        get phoneNumber(): string;
    }
    class PhoneConfigPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): PhoneConfigPropertyOutputReference;
    }
    interface QueueConfigProperty {
    }
    class QueueConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): QueueConfigProperty | undefined;
        set internalValue(value: QueueConfigProperty | undefined);
        get contactFlowId(): string;
        get queueId(): string;
    }
    class QueueConfigPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): QueueConfigPropertyOutputReference;
    }
    interface UserConfigProperty {
    }
    class UserConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): UserConfigProperty | undefined;
        set internalValue(value: UserConfigProperty | undefined);
        get contactFlowId(): string;
        get userId(): string;
    }
    class UserConfigPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): UserConfigPropertyOutputReference;
    }
    interface QuickConnectConfigProperty {
    }
    class QuickConnectConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): QuickConnectConfigProperty | undefined;
        set internalValue(value: QuickConnectConfigProperty | undefined);
        private _phoneConfig;
        get phoneConfig(): PhoneConfigPropertyList;
        private _queueConfig;
        get queueConfig(): QueueConfigPropertyList;
        get quickConnectType(): string;
        private _userConfig;
        get userConfig(): UserConfigPropertyList;
    }
    class QuickConnectConfigPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): QuickConnectConfigPropertyOutputReference;
    }
}
