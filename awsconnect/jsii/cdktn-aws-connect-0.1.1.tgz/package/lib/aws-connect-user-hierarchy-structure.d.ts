import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsConnectUserHierarchyStructureConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/connect_user_hierarchy_structure#id AwsConnectUserHierarchyStructure#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/connect_user_hierarchy_structure#instance_id AwsConnectUserHierarchyStructure#instance_id}
    */
    readonly instanceId: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/connect_user_hierarchy_structure#region AwsConnectUserHierarchyStructure#region}
    */
    readonly region?: string;
    /**
    * hierarchy_structure block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/connect_user_hierarchy_structure#hierarchy_structure AwsConnectUserHierarchyStructure#hierarchy_structure}
    */
    readonly hierarchyStructure: AwsConnectUserHierarchyStructure.HierarchyStructureProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/connect_user_hierarchy_structure aws_connect_user_hierarchy_structure}
*/
export declare class AwsConnectUserHierarchyStructure extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_connect_user_hierarchy_structure";
    /**
    * Generates CDKTN code for importing a AwsConnectUserHierarchyStructure resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsConnectUserHierarchyStructure to import
    * @param importFromId The id of the existing AwsConnectUserHierarchyStructure that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/connect_user_hierarchy_structure#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsConnectUserHierarchyStructure to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/connect_user_hierarchy_structure aws_connect_user_hierarchy_structure} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsConnectUserHierarchyStructureConfig
    */
    constructor(scope: Construct, id: string, config: AwsConnectUserHierarchyStructureConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _instanceId?;
    get instanceId(): string;
    set instanceId(value: string);
    get instanceIdInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _hierarchyStructure;
    get hierarchyStructure(): AwsConnectUserHierarchyStructure.HierarchyStructurePropertyOutputReference;
    putHierarchyStructure(value: AwsConnectUserHierarchyStructure.HierarchyStructureProperty): void;
    get hierarchyStructureInput(): AwsConnectUserHierarchyStructure.HierarchyStructureProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsConnectUserHierarchyStructureLevelFivePropertyToTerraform(struct?: AwsConnectUserHierarchyStructure.LevelFivePropertyOutputReference | AwsConnectUserHierarchyStructure.LevelFiveProperty): any;
export declare function awsConnectUserHierarchyStructureLevelFivePropertyToHclTerraform(struct?: AwsConnectUserHierarchyStructure.LevelFivePropertyOutputReference | AwsConnectUserHierarchyStructure.LevelFiveProperty): any;
export declare function awsConnectUserHierarchyStructureLevelFourPropertyToTerraform(struct?: AwsConnectUserHierarchyStructure.LevelFourPropertyOutputReference | AwsConnectUserHierarchyStructure.LevelFourProperty): any;
export declare function awsConnectUserHierarchyStructureLevelFourPropertyToHclTerraform(struct?: AwsConnectUserHierarchyStructure.LevelFourPropertyOutputReference | AwsConnectUserHierarchyStructure.LevelFourProperty): any;
export declare function awsConnectUserHierarchyStructureLevelOnePropertyToTerraform(struct?: AwsConnectUserHierarchyStructure.LevelOnePropertyOutputReference | AwsConnectUserHierarchyStructure.LevelOneProperty): any;
export declare function awsConnectUserHierarchyStructureLevelOnePropertyToHclTerraform(struct?: AwsConnectUserHierarchyStructure.LevelOnePropertyOutputReference | AwsConnectUserHierarchyStructure.LevelOneProperty): any;
export declare function awsConnectUserHierarchyStructureLevelThreePropertyToTerraform(struct?: AwsConnectUserHierarchyStructure.LevelThreePropertyOutputReference | AwsConnectUserHierarchyStructure.LevelThreeProperty): any;
export declare function awsConnectUserHierarchyStructureLevelThreePropertyToHclTerraform(struct?: AwsConnectUserHierarchyStructure.LevelThreePropertyOutputReference | AwsConnectUserHierarchyStructure.LevelThreeProperty): any;
export declare function awsConnectUserHierarchyStructureLevelTwoPropertyToTerraform(struct?: AwsConnectUserHierarchyStructure.LevelTwoPropertyOutputReference | AwsConnectUserHierarchyStructure.LevelTwoProperty): any;
export declare function awsConnectUserHierarchyStructureLevelTwoPropertyToHclTerraform(struct?: AwsConnectUserHierarchyStructure.LevelTwoPropertyOutputReference | AwsConnectUserHierarchyStructure.LevelTwoProperty): any;
export declare function awsConnectUserHierarchyStructureHierarchyStructurePropertyToTerraform(struct?: AwsConnectUserHierarchyStructure.HierarchyStructurePropertyOutputReference | AwsConnectUserHierarchyStructure.HierarchyStructureProperty): any;
export declare function awsConnectUserHierarchyStructureHierarchyStructurePropertyToHclTerraform(struct?: AwsConnectUserHierarchyStructure.HierarchyStructurePropertyOutputReference | AwsConnectUserHierarchyStructure.HierarchyStructureProperty): any;
export declare namespace AwsConnectUserHierarchyStructure {
    interface LevelFiveProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/connect_user_hierarchy_structure#name AwsConnectUserHierarchyStructure#name}
        */
        readonly name: string;
    }
    class LevelFivePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): LevelFiveProperty | undefined;
        set internalValue(value: LevelFiveProperty | undefined);
        get arn(): string;
        get id(): string;
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
    }
    interface LevelFourProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/connect_user_hierarchy_structure#name AwsConnectUserHierarchyStructure#name}
        */
        readonly name: string;
    }
    class LevelFourPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): LevelFourProperty | undefined;
        set internalValue(value: LevelFourProperty | undefined);
        get arn(): string;
        get id(): string;
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
    }
    interface LevelOneProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/connect_user_hierarchy_structure#name AwsConnectUserHierarchyStructure#name}
        */
        readonly name: string;
    }
    class LevelOnePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): LevelOneProperty | undefined;
        set internalValue(value: LevelOneProperty | undefined);
        get arn(): string;
        get id(): string;
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
    }
    interface LevelThreeProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/connect_user_hierarchy_structure#name AwsConnectUserHierarchyStructure#name}
        */
        readonly name: string;
    }
    class LevelThreePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): LevelThreeProperty | undefined;
        set internalValue(value: LevelThreeProperty | undefined);
        get arn(): string;
        get id(): string;
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
    }
    interface LevelTwoProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/connect_user_hierarchy_structure#name AwsConnectUserHierarchyStructure#name}
        */
        readonly name: string;
    }
    class LevelTwoPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): LevelTwoProperty | undefined;
        set internalValue(value: LevelTwoProperty | undefined);
        get arn(): string;
        get id(): string;
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
    }
    interface HierarchyStructureProperty {
        /**
        * level_five block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/connect_user_hierarchy_structure#level_five AwsConnectUserHierarchyStructure#level_five}
        */
        readonly levelFive?: LevelFiveProperty;
        /**
        * level_four block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/connect_user_hierarchy_structure#level_four AwsConnectUserHierarchyStructure#level_four}
        */
        readonly levelFour?: LevelFourProperty;
        /**
        * level_one block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/connect_user_hierarchy_structure#level_one AwsConnectUserHierarchyStructure#level_one}
        */
        readonly levelOne?: LevelOneProperty;
        /**
        * level_three block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/connect_user_hierarchy_structure#level_three AwsConnectUserHierarchyStructure#level_three}
        */
        readonly levelThree?: LevelThreeProperty;
        /**
        * level_two block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/connect_user_hierarchy_structure#level_two AwsConnectUserHierarchyStructure#level_two}
        */
        readonly levelTwo?: LevelTwoProperty;
    }
    class HierarchyStructurePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): HierarchyStructureProperty | undefined;
        set internalValue(value: HierarchyStructureProperty | undefined);
        private _levelFive;
        get levelFive(): LevelFivePropertyOutputReference;
        putLevelFive(value: LevelFiveProperty): void;
        resetLevelFive(): void;
        get levelFiveInput(): LevelFiveProperty | undefined;
        private _levelFour;
        get levelFour(): LevelFourPropertyOutputReference;
        putLevelFour(value: LevelFourProperty): void;
        resetLevelFour(): void;
        get levelFourInput(): LevelFourProperty | undefined;
        private _levelOne;
        get levelOne(): LevelOnePropertyOutputReference;
        putLevelOne(value: LevelOneProperty): void;
        resetLevelOne(): void;
        get levelOneInput(): LevelOneProperty | undefined;
        private _levelThree;
        get levelThree(): LevelThreePropertyOutputReference;
        putLevelThree(value: LevelThreeProperty): void;
        resetLevelThree(): void;
        get levelThreeInput(): LevelThreeProperty | undefined;
        private _levelTwo;
        get levelTwo(): LevelTwoPropertyOutputReference;
        putLevelTwo(value: LevelTwoProperty): void;
        resetLevelTwo(): void;
        get levelTwoInput(): LevelTwoProperty | undefined;
    }
}
