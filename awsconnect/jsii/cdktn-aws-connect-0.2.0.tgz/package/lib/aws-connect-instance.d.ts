import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfInstanceConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/connect_instance#auto_resolve_best_voices_enabled TfInstance#auto_resolve_best_voices_enabled}
    */
    readonly autoResolveBestVoicesEnabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/connect_instance#contact_flow_logs_enabled TfInstance#contact_flow_logs_enabled}
    */
    readonly contactFlowLogsEnabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/connect_instance#contact_lens_enabled TfInstance#contact_lens_enabled}
    */
    readonly contactLensEnabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/connect_instance#directory_id TfInstance#directory_id}
    */
    readonly directoryId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/connect_instance#early_media_enabled TfInstance#early_media_enabled}
    */
    readonly earlyMediaEnabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/connect_instance#id TfInstance#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/connect_instance#identity_management_type TfInstance#identity_management_type}
    */
    readonly identityManagementType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/connect_instance#inbound_calls_enabled TfInstance#inbound_calls_enabled}
    */
    readonly inboundCallsEnabled: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/connect_instance#instance_alias TfInstance#instance_alias}
    */
    readonly instanceAlias?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/connect_instance#multi_party_conference_enabled TfInstance#multi_party_conference_enabled}
    */
    readonly multiPartyConferenceEnabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/connect_instance#outbound_calls_enabled TfInstance#outbound_calls_enabled}
    */
    readonly outboundCallsEnabled: boolean | cdktn.IResolvable;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/connect_instance#region TfInstance#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/connect_instance#tags TfInstance#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/connect_instance#tags_all TfInstance#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/connect_instance#timeouts TfInstance#timeouts}
    */
    readonly timeouts?: TfInstance.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/connect_instance aws_connect_instance}
*/
export declare class TfInstance extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_connect_instance";
    /**
    * Generates CDKTN code for importing a TfInstance resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfInstance to import
    * @param importFromId The id of the existing TfInstance that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/connect_instance#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfInstance to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/connect_instance aws_connect_instance} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfInstanceConfig
    */
    constructor(scope: Construct, id: string, config: TfInstanceConfig);
    get arn(): string;
    private _autoResolveBestVoicesEnabled?;
    get autoResolveBestVoicesEnabled(): boolean | cdktn.IResolvable;
    set autoResolveBestVoicesEnabled(value: boolean | cdktn.IResolvable);
    resetAutoResolveBestVoicesEnabled(): void;
    get autoResolveBestVoicesEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _contactFlowLogsEnabled?;
    get contactFlowLogsEnabled(): boolean | cdktn.IResolvable;
    set contactFlowLogsEnabled(value: boolean | cdktn.IResolvable);
    resetContactFlowLogsEnabled(): void;
    get contactFlowLogsEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _contactLensEnabled?;
    get contactLensEnabled(): boolean | cdktn.IResolvable;
    set contactLensEnabled(value: boolean | cdktn.IResolvable);
    resetContactLensEnabled(): void;
    get contactLensEnabledInput(): boolean | cdktn.IResolvable | undefined;
    get createdTime(): string;
    private _directoryId?;
    get directoryId(): string;
    set directoryId(value: string);
    resetDirectoryId(): void;
    get directoryIdInput(): string | undefined;
    private _earlyMediaEnabled?;
    get earlyMediaEnabled(): boolean | cdktn.IResolvable;
    set earlyMediaEnabled(value: boolean | cdktn.IResolvable);
    resetEarlyMediaEnabled(): void;
    get earlyMediaEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _identityManagementType?;
    get identityManagementType(): string;
    set identityManagementType(value: string);
    get identityManagementTypeInput(): string | undefined;
    private _inboundCallsEnabled?;
    get inboundCallsEnabled(): boolean | cdktn.IResolvable;
    set inboundCallsEnabled(value: boolean | cdktn.IResolvable);
    get inboundCallsEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _instanceAlias?;
    get instanceAlias(): string;
    set instanceAlias(value: string);
    resetInstanceAlias(): void;
    get instanceAliasInput(): string | undefined;
    private _multiPartyConferenceEnabled?;
    get multiPartyConferenceEnabled(): boolean | cdktn.IResolvable;
    set multiPartyConferenceEnabled(value: boolean | cdktn.IResolvable);
    resetMultiPartyConferenceEnabled(): void;
    get multiPartyConferenceEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _outboundCallsEnabled?;
    get outboundCallsEnabled(): boolean | cdktn.IResolvable;
    set outboundCallsEnabled(value: boolean | cdktn.IResolvable);
    get outboundCallsEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get serviceRole(): string;
    get status(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _timeouts;
    get timeouts(): TfInstance.TimeoutsPropertyOutputReference;
    putTimeouts(value: TfInstance.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | TfInstance.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfInstanceTimeoutsPropertyToTerraform(struct?: TfInstance.TimeoutsProperty | cdktn.IResolvable): any;
export declare function tfInstanceTimeoutsPropertyToHclTerraform(struct?: TfInstance.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace TfInstance {
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/connect_instance#create TfInstance#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/connect_instance#delete TfInstance#delete}
        */
        readonly delete?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
    }
}
