import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfUserConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/connect_user#directory_user_id TfUser#directory_user_id}
    */
    readonly directoryUserId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/connect_user#hierarchy_group_id TfUser#hierarchy_group_id}
    */
    readonly hierarchyGroupId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/connect_user#id TfUser#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/connect_user#instance_id TfUser#instance_id}
    */
    readonly instanceId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/connect_user#name TfUser#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/connect_user#password TfUser#password}
    */
    readonly password?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/connect_user#region TfUser#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/connect_user#routing_profile_id TfUser#routing_profile_id}
    */
    readonly routingProfileId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/connect_user#security_profile_ids TfUser#security_profile_ids}
    */
    readonly securityProfileIds: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/connect_user#tags TfUser#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/connect_user#tags_all TfUser#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * identity_info block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/connect_user#identity_info TfUser#identity_info}
    */
    readonly identityInfo?: TfUser.IdentityInfoProperty;
    /**
    * phone_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/connect_user#phone_config TfUser#phone_config}
    */
    readonly phoneConfig: TfUser.PhoneConfigProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/connect_user aws_connect_user}
*/
export declare class TfUser extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_connect_user";
    /**
    * Generates CDKTN code for importing a TfUser resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfUser to import
    * @param importFromId The id of the existing TfUser that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/connect_user#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfUser to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/connect_user aws_connect_user} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfUserConfig
    */
    constructor(scope: Construct, id: string, config: TfUserConfig);
    get arn(): string;
    private _directoryUserId?;
    get directoryUserId(): string;
    set directoryUserId(value: string);
    resetDirectoryUserId(): void;
    get directoryUserIdInput(): string | undefined;
    private _hierarchyGroupId?;
    get hierarchyGroupId(): string;
    set hierarchyGroupId(value: string);
    resetHierarchyGroupId(): void;
    get hierarchyGroupIdInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _instanceId?;
    get instanceId(): string;
    set instanceId(value: string);
    get instanceIdInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _password?;
    get password(): string;
    set password(value: string);
    resetPassword(): void;
    get passwordInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _routingProfileId?;
    get routingProfileId(): string;
    set routingProfileId(value: string);
    get routingProfileIdInput(): string | undefined;
    private _securityProfileIds?;
    get securityProfileIds(): string[];
    set securityProfileIds(value: string[]);
    get securityProfileIdsInput(): string[] | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    get userId(): string;
    private _identityInfo;
    get identityInfo(): TfUser.IdentityInfoPropertyOutputReference;
    putIdentityInfo(value: TfUser.IdentityInfoProperty): void;
    resetIdentityInfo(): void;
    get identityInfoInput(): TfUser.IdentityInfoProperty | undefined;
    private _phoneConfig;
    get phoneConfig(): TfUser.PhoneConfigPropertyOutputReference;
    putPhoneConfig(value: TfUser.PhoneConfigProperty): void;
    get phoneConfigInput(): TfUser.PhoneConfigProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfUserIdentityInfoPropertyToTerraform(struct?: TfUser.IdentityInfoPropertyOutputReference | TfUser.IdentityInfoProperty): any;
export declare function tfUserIdentityInfoPropertyToHclTerraform(struct?: TfUser.IdentityInfoPropertyOutputReference | TfUser.IdentityInfoProperty): any;
export declare function tfUserPhoneConfigPropertyToTerraform(struct?: TfUser.PhoneConfigPropertyOutputReference | TfUser.PhoneConfigProperty): any;
export declare function tfUserPhoneConfigPropertyToHclTerraform(struct?: TfUser.PhoneConfigPropertyOutputReference | TfUser.PhoneConfigProperty): any;
export declare namespace TfUser {
    interface IdentityInfoProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/connect_user#email TfUser#email}
        */
        readonly email?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/connect_user#first_name TfUser#first_name}
        */
        readonly firstName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/connect_user#last_name TfUser#last_name}
        */
        readonly lastName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/connect_user#secondary_email TfUser#secondary_email}
        */
        readonly secondaryEmail?: string;
    }
    class IdentityInfoPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): IdentityInfoProperty | undefined;
        set internalValue(value: IdentityInfoProperty | undefined);
        private _email?;
        get email(): string;
        set email(value: string);
        resetEmail(): void;
        get emailInput(): string | undefined;
        private _firstName?;
        get firstName(): string;
        set firstName(value: string);
        resetFirstName(): void;
        get firstNameInput(): string | undefined;
        private _lastName?;
        get lastName(): string;
        set lastName(value: string);
        resetLastName(): void;
        get lastNameInput(): string | undefined;
        private _secondaryEmail?;
        get secondaryEmail(): string;
        set secondaryEmail(value: string);
        resetSecondaryEmail(): void;
        get secondaryEmailInput(): string | undefined;
    }
    interface PhoneConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/connect_user#after_contact_work_time_limit TfUser#after_contact_work_time_limit}
        */
        readonly afterContactWorkTimeLimit?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/connect_user#auto_accept TfUser#auto_accept}
        */
        readonly autoAccept?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/connect_user#desk_phone_number TfUser#desk_phone_number}
        */
        readonly deskPhoneNumber?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/connect_user#phone_type TfUser#phone_type}
        */
        readonly phoneType: string;
    }
    class PhoneConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): PhoneConfigProperty | undefined;
        set internalValue(value: PhoneConfigProperty | undefined);
        private _afterContactWorkTimeLimit?;
        get afterContactWorkTimeLimit(): number;
        set afterContactWorkTimeLimit(value: number);
        resetAfterContactWorkTimeLimit(): void;
        get afterContactWorkTimeLimitInput(): number | undefined;
        private _autoAccept?;
        get autoAccept(): boolean | cdktn.IResolvable;
        set autoAccept(value: boolean | cdktn.IResolvable);
        resetAutoAccept(): void;
        get autoAcceptInput(): boolean | cdktn.IResolvable | undefined;
        private _deskPhoneNumber?;
        get deskPhoneNumber(): string;
        set deskPhoneNumber(value: string);
        resetDeskPhoneNumber(): void;
        get deskPhoneNumberInput(): string | undefined;
        private _phoneType?;
        get phoneType(): string;
        set phoneType(value: string);
        get phoneTypeInput(): string | undefined;
    }
}
