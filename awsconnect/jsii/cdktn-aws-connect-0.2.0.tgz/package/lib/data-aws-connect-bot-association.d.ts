import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataTfBotAssociationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/connect_bot_association#id DataTfBotAssociation#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/connect_bot_association#instance_id DataTfBotAssociation#instance_id}
    */
    readonly instanceId: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/connect_bot_association#region DataTfBotAssociation#region}
    */
    readonly region?: string;
    /**
    * lex_bot block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/connect_bot_association#lex_bot DataTfBotAssociation#lex_bot}
    */
    readonly lexBot: DataTfBotAssociation.LexBotProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/connect_bot_association aws_connect_bot_association}
*/
export declare class DataTfBotAssociation extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_connect_bot_association";
    /**
    * Generates CDKTN code for importing a DataTfBotAssociation resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataTfBotAssociation to import
    * @param importFromId The id of the existing DataTfBotAssociation that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/connect_bot_association#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataTfBotAssociation to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/connect_bot_association aws_connect_bot_association} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataTfBotAssociationConfig
    */
    constructor(scope: Construct, id: string, config: DataTfBotAssociationConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _instanceId?;
    get instanceId(): string;
    set instanceId(value: string);
    get instanceIdInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _lexBot;
    get lexBot(): DataTfBotAssociation.LexBotPropertyOutputReference;
    putLexBot(value: DataTfBotAssociation.LexBotProperty): void;
    get lexBotInput(): DataTfBotAssociation.LexBotProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataTfBotAssociationLexBotPropertyToTerraform(struct?: DataTfBotAssociation.LexBotPropertyOutputReference | DataTfBotAssociation.LexBotProperty): any;
export declare function dataTfBotAssociationLexBotPropertyToHclTerraform(struct?: DataTfBotAssociation.LexBotPropertyOutputReference | DataTfBotAssociation.LexBotProperty): any;
export declare namespace DataTfBotAssociation {
    interface LexBotProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/connect_bot_association#lex_region DataTfBotAssociation#lex_region}
        */
        readonly lexRegion?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/connect_bot_association#name DataTfBotAssociation#name}
        */
        readonly name: string;
    }
    class LexBotPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): LexBotProperty | undefined;
        set internalValue(value: LexBotProperty | undefined);
        private _lexRegion?;
        get lexRegion(): string;
        set lexRegion(value: string);
        resetLexRegion(): void;
        get lexRegionInput(): string | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
    }
}
