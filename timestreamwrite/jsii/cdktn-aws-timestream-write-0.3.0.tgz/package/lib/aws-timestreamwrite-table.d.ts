import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsTableConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreamwrite_table#database_name AwsTable#database_name}
    */
    readonly databaseName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreamwrite_table#id AwsTable#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreamwrite_table#region AwsTable#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreamwrite_table#table_name AwsTable#table_name}
    */
    readonly tableName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreamwrite_table#tags AwsTable#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreamwrite_table#tags_all AwsTable#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * magnetic_store_write_properties block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreamwrite_table#magnetic_store_write_properties AwsTable#magnetic_store_write_properties}
    */
    readonly magneticStoreWriteProperties?: AwsTable.MagneticStoreWritePropertiesProperty;
    /**
    * retention_properties block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreamwrite_table#retention_properties AwsTable#retention_properties}
    */
    readonly retentionProperties?: AwsTable.RetentionPropertiesProperty;
    /**
    * schema block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreamwrite_table#schema AwsTable#schema}
    */
    readonly schema?: AwsTable.SchemaProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreamwrite_table aws_timestreamwrite_table}
*/
export declare class AwsTable extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_timestreamwrite_table";
    /**
    * Generates CDKTN code for importing a AwsTable resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsTable to import
    * @param importFromId The id of the existing AwsTable that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreamwrite_table#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsTable to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreamwrite_table aws_timestreamwrite_table} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsTableConfig
    */
    constructor(scope: Construct, id: string, config: AwsTableConfig);
    get arn(): string;
    private _databaseName?;
    get databaseName(): string;
    set databaseName(value: string);
    get databaseNameInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tableName?;
    get tableName(): string;
    set tableName(value: string);
    get tableNameInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _magneticStoreWriteProperties;
    get magneticStoreWriteProperties(): AwsTable.MagneticStoreWritePropertiesPropertyOutputReference;
    putMagneticStoreWriteProperties(value: AwsTable.MagneticStoreWritePropertiesProperty): void;
    resetMagneticStoreWriteProperties(): void;
    get magneticStoreWritePropertiesInput(): AwsTable.MagneticStoreWritePropertiesProperty | undefined;
    private _retentionProperties;
    get retentionProperties(): AwsTable.RetentionPropertiesPropertyOutputReference;
    putRetentionProperties(value: AwsTable.RetentionPropertiesProperty): void;
    resetRetentionProperties(): void;
    get retentionPropertiesInput(): AwsTable.RetentionPropertiesProperty | undefined;
    private _schema;
    get schema(): AwsTable.SchemaPropertyOutputReference;
    putSchema(value: AwsTable.SchemaProperty): void;
    resetSchema(): void;
    get schemaInput(): AwsTable.SchemaProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsTableS3ConfigurationPropertyToTerraform(struct?: AwsTable.S3ConfigurationPropertyOutputReference | AwsTable.S3ConfigurationProperty): any;
export declare function awsTableS3ConfigurationPropertyToHclTerraform(struct?: AwsTable.S3ConfigurationPropertyOutputReference | AwsTable.S3ConfigurationProperty): any;
export declare function awsTableMagneticStoreRejectedDataLocationPropertyToTerraform(struct?: AwsTable.MagneticStoreRejectedDataLocationPropertyOutputReference | AwsTable.MagneticStoreRejectedDataLocationProperty): any;
export declare function awsTableMagneticStoreRejectedDataLocationPropertyToHclTerraform(struct?: AwsTable.MagneticStoreRejectedDataLocationPropertyOutputReference | AwsTable.MagneticStoreRejectedDataLocationProperty): any;
export declare function awsTableMagneticStoreWritePropertiesPropertyToTerraform(struct?: AwsTable.MagneticStoreWritePropertiesPropertyOutputReference | AwsTable.MagneticStoreWritePropertiesProperty): any;
export declare function awsTableMagneticStoreWritePropertiesPropertyToHclTerraform(struct?: AwsTable.MagneticStoreWritePropertiesPropertyOutputReference | AwsTable.MagneticStoreWritePropertiesProperty): any;
export declare function awsTableRetentionPropertiesPropertyToTerraform(struct?: AwsTable.RetentionPropertiesPropertyOutputReference | AwsTable.RetentionPropertiesProperty): any;
export declare function awsTableRetentionPropertiesPropertyToHclTerraform(struct?: AwsTable.RetentionPropertiesPropertyOutputReference | AwsTable.RetentionPropertiesProperty): any;
export declare function awsTableCompositePartitionKeyPropertyToTerraform(struct?: AwsTable.CompositePartitionKeyPropertyOutputReference | AwsTable.CompositePartitionKeyProperty): any;
export declare function awsTableCompositePartitionKeyPropertyToHclTerraform(struct?: AwsTable.CompositePartitionKeyPropertyOutputReference | AwsTable.CompositePartitionKeyProperty): any;
export declare function awsTableSchemaPropertyToTerraform(struct?: AwsTable.SchemaPropertyOutputReference | AwsTable.SchemaProperty): any;
export declare function awsTableSchemaPropertyToHclTerraform(struct?: AwsTable.SchemaPropertyOutputReference | AwsTable.SchemaProperty): any;
export declare namespace AwsTable {
    interface S3ConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreamwrite_table#bucket_name AwsTable#bucket_name}
        */
        readonly bucketName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreamwrite_table#encryption_option AwsTable#encryption_option}
        */
        readonly encryptionOption?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreamwrite_table#kms_key_id AwsTable#kms_key_id}
        */
        readonly kmsKeyId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreamwrite_table#object_key_prefix AwsTable#object_key_prefix}
        */
        readonly objectKeyPrefix?: string;
    }
    class S3ConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): S3ConfigurationProperty | undefined;
        set internalValue(value: S3ConfigurationProperty | undefined);
        private _bucketName?;
        get bucketName(): string;
        set bucketName(value: string);
        resetBucketName(): void;
        get bucketNameInput(): string | undefined;
        private _encryptionOption?;
        get encryptionOption(): string;
        set encryptionOption(value: string);
        resetEncryptionOption(): void;
        get encryptionOptionInput(): string | undefined;
        private _kmsKeyId?;
        get kmsKeyId(): string;
        set kmsKeyId(value: string);
        resetKmsKeyId(): void;
        get kmsKeyIdInput(): string | undefined;
        private _objectKeyPrefix?;
        get objectKeyPrefix(): string;
        set objectKeyPrefix(value: string);
        resetObjectKeyPrefix(): void;
        get objectKeyPrefixInput(): string | undefined;
    }
    interface MagneticStoreRejectedDataLocationProperty {
        /**
        * s3_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreamwrite_table#s3_configuration AwsTable#s3_configuration}
        */
        readonly s3Configuration?: S3ConfigurationProperty;
    }
    class MagneticStoreRejectedDataLocationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): MagneticStoreRejectedDataLocationProperty | undefined;
        set internalValue(value: MagneticStoreRejectedDataLocationProperty | undefined);
        private _s3Configuration;
        get s3Configuration(): S3ConfigurationPropertyOutputReference;
        putS3Configuration(value: S3ConfigurationProperty): void;
        resetS3Configuration(): void;
        get s3ConfigurationInput(): S3ConfigurationProperty | undefined;
    }
    interface MagneticStoreWritePropertiesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreamwrite_table#enable_magnetic_store_writes AwsTable#enable_magnetic_store_writes}
        */
        readonly enableMagneticStoreWrites?: boolean | cdktn.IResolvable;
        /**
        * magnetic_store_rejected_data_location block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreamwrite_table#magnetic_store_rejected_data_location AwsTable#magnetic_store_rejected_data_location}
        */
        readonly magneticStoreRejectedDataLocation?: MagneticStoreRejectedDataLocationProperty;
    }
    class MagneticStoreWritePropertiesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): MagneticStoreWritePropertiesProperty | undefined;
        set internalValue(value: MagneticStoreWritePropertiesProperty | undefined);
        private _enableMagneticStoreWrites?;
        get enableMagneticStoreWrites(): boolean | cdktn.IResolvable;
        set enableMagneticStoreWrites(value: boolean | cdktn.IResolvable);
        resetEnableMagneticStoreWrites(): void;
        get enableMagneticStoreWritesInput(): boolean | cdktn.IResolvable | undefined;
        private _magneticStoreRejectedDataLocation;
        get magneticStoreRejectedDataLocation(): MagneticStoreRejectedDataLocationPropertyOutputReference;
        putMagneticStoreRejectedDataLocation(value: MagneticStoreRejectedDataLocationProperty): void;
        resetMagneticStoreRejectedDataLocation(): void;
        get magneticStoreRejectedDataLocationInput(): MagneticStoreRejectedDataLocationProperty | undefined;
    }
    interface RetentionPropertiesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreamwrite_table#magnetic_store_retention_period_in_days AwsTable#magnetic_store_retention_period_in_days}
        */
        readonly magneticStoreRetentionPeriodInDays: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreamwrite_table#memory_store_retention_period_in_hours AwsTable#memory_store_retention_period_in_hours}
        */
        readonly memoryStoreRetentionPeriodInHours: number;
    }
    class RetentionPropertiesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RetentionPropertiesProperty | undefined;
        set internalValue(value: RetentionPropertiesProperty | undefined);
        private _magneticStoreRetentionPeriodInDays?;
        get magneticStoreRetentionPeriodInDays(): number;
        set magneticStoreRetentionPeriodInDays(value: number);
        get magneticStoreRetentionPeriodInDaysInput(): number | undefined;
        private _memoryStoreRetentionPeriodInHours?;
        get memoryStoreRetentionPeriodInHours(): number;
        set memoryStoreRetentionPeriodInHours(value: number);
        get memoryStoreRetentionPeriodInHoursInput(): number | undefined;
    }
    interface CompositePartitionKeyProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreamwrite_table#enforcement_in_record AwsTable#enforcement_in_record}
        */
        readonly enforcementInRecord?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreamwrite_table#name AwsTable#name}
        */
        readonly name?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreamwrite_table#type AwsTable#type}
        */
        readonly type: string;
    }
    class CompositePartitionKeyPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CompositePartitionKeyProperty | undefined;
        set internalValue(value: CompositePartitionKeyProperty | undefined);
        private _enforcementInRecord?;
        get enforcementInRecord(): string;
        set enforcementInRecord(value: string);
        resetEnforcementInRecord(): void;
        get enforcementInRecordInput(): string | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        resetName(): void;
        get nameInput(): string | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
    }
    interface SchemaProperty {
        /**
        * composite_partition_key block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreamwrite_table#composite_partition_key AwsTable#composite_partition_key}
        */
        readonly compositePartitionKey?: CompositePartitionKeyProperty;
    }
    class SchemaPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SchemaProperty | undefined;
        set internalValue(value: SchemaProperty | undefined);
        private _compositePartitionKey;
        get compositePartitionKey(): CompositePartitionKeyPropertyOutputReference;
        putCompositePartitionKey(value: CompositePartitionKeyProperty): void;
        resetCompositePartitionKey(): void;
        get compositePartitionKeyInput(): CompositePartitionKeyProperty | undefined;
    }
}
