import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsDatabaseConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/timestreamwrite_database#name DataAwsDatabase#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/timestreamwrite_database#region DataAwsDatabase#region}
    */
    readonly region?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/timestreamwrite_database aws_timestreamwrite_database}
*/
export declare class DataAwsDatabase extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_timestreamwrite_database";
    /**
    * Generates CDKTN code for importing a DataAwsDatabase resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsDatabase to import
    * @param importFromId The id of the existing DataAwsDatabase that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/timestreamwrite_database#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsDatabase to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/timestreamwrite_database aws_timestreamwrite_database} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsDatabaseConfig
    */
    constructor(scope: Construct, id: string, config: DataAwsDatabaseConfig);
    get arn(): string;
    get createdTime(): string;
    get kmsKeyId(): string;
    get lastUpdatedTime(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get tableCount(): number;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
