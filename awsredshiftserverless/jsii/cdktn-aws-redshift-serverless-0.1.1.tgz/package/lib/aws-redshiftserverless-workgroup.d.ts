import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsRedshiftserverlessWorkgroupConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/redshiftserverless_workgroup#base_capacity AwsRedshiftserverlessWorkgroup#base_capacity}
    */
    readonly baseCapacity?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/redshiftserverless_workgroup#enhanced_vpc_routing AwsRedshiftserverlessWorkgroup#enhanced_vpc_routing}
    */
    readonly enhancedVpcRouting?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/redshiftserverless_workgroup#id AwsRedshiftserverlessWorkgroup#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/redshiftserverless_workgroup#max_capacity AwsRedshiftserverlessWorkgroup#max_capacity}
    */
    readonly maxCapacity?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/redshiftserverless_workgroup#namespace_name AwsRedshiftserverlessWorkgroup#namespace_name}
    */
    readonly namespaceName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/redshiftserverless_workgroup#port AwsRedshiftserverlessWorkgroup#port}
    */
    readonly port?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/redshiftserverless_workgroup#publicly_accessible AwsRedshiftserverlessWorkgroup#publicly_accessible}
    */
    readonly publiclyAccessible?: boolean | cdktn.IResolvable;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/redshiftserverless_workgroup#region AwsRedshiftserverlessWorkgroup#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/redshiftserverless_workgroup#security_group_ids AwsRedshiftserverlessWorkgroup#security_group_ids}
    */
    readonly securityGroupIds?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/redshiftserverless_workgroup#subnet_ids AwsRedshiftserverlessWorkgroup#subnet_ids}
    */
    readonly subnetIds?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/redshiftserverless_workgroup#tags AwsRedshiftserverlessWorkgroup#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/redshiftserverless_workgroup#tags_all AwsRedshiftserverlessWorkgroup#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/redshiftserverless_workgroup#track_name AwsRedshiftserverlessWorkgroup#track_name}
    */
    readonly trackName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/redshiftserverless_workgroup#workgroup_name AwsRedshiftserverlessWorkgroup#workgroup_name}
    */
    readonly workgroupName: string;
    /**
    * config_parameter block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/redshiftserverless_workgroup#config_parameter AwsRedshiftserverlessWorkgroup#config_parameter}
    */
    readonly configParameter?: AwsRedshiftserverlessWorkgroup.ConfigParameterProperty[] | cdktn.IResolvable;
    /**
    * price_performance_target block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/redshiftserverless_workgroup#price_performance_target AwsRedshiftserverlessWorkgroup#price_performance_target}
    */
    readonly pricePerformanceTarget?: AwsRedshiftserverlessWorkgroup.PricePerformanceTargetProperty;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/redshiftserverless_workgroup#timeouts AwsRedshiftserverlessWorkgroup#timeouts}
    */
    readonly timeouts?: AwsRedshiftserverlessWorkgroup.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/redshiftserverless_workgroup aws_redshiftserverless_workgroup}
*/
export declare class AwsRedshiftserverlessWorkgroup extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_redshiftserverless_workgroup";
    /**
    * Generates CDKTN code for importing a AwsRedshiftserverlessWorkgroup resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsRedshiftserverlessWorkgroup to import
    * @param importFromId The id of the existing AwsRedshiftserverlessWorkgroup that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/redshiftserverless_workgroup#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsRedshiftserverlessWorkgroup to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/redshiftserverless_workgroup aws_redshiftserverless_workgroup} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsRedshiftserverlessWorkgroupConfig
    */
    constructor(scope: Construct, id: string, config: AwsRedshiftserverlessWorkgroupConfig);
    get arn(): string;
    private _baseCapacity?;
    get baseCapacity(): number;
    set baseCapacity(value: number);
    resetBaseCapacity(): void;
    get baseCapacityInput(): number | undefined;
    private _endpoint;
    get endpoint(): AwsRedshiftserverlessWorkgroup.EndpointPropertyList;
    private _enhancedVpcRouting?;
    get enhancedVpcRouting(): boolean | cdktn.IResolvable;
    set enhancedVpcRouting(value: boolean | cdktn.IResolvable);
    resetEnhancedVpcRouting(): void;
    get enhancedVpcRoutingInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _maxCapacity?;
    get maxCapacity(): number;
    set maxCapacity(value: number);
    resetMaxCapacity(): void;
    get maxCapacityInput(): number | undefined;
    private _namespaceName?;
    get namespaceName(): string;
    set namespaceName(value: string);
    get namespaceNameInput(): string | undefined;
    private _port?;
    get port(): number;
    set port(value: number);
    resetPort(): void;
    get portInput(): number | undefined;
    private _publiclyAccessible?;
    get publiclyAccessible(): boolean | cdktn.IResolvable;
    set publiclyAccessible(value: boolean | cdktn.IResolvable);
    resetPubliclyAccessible(): void;
    get publiclyAccessibleInput(): boolean | cdktn.IResolvable | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _securityGroupIds?;
    get securityGroupIds(): string[];
    set securityGroupIds(value: string[]);
    resetSecurityGroupIds(): void;
    get securityGroupIdsInput(): string[] | undefined;
    private _subnetIds?;
    get subnetIds(): string[];
    set subnetIds(value: string[]);
    resetSubnetIds(): void;
    get subnetIdsInput(): string[] | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _trackName?;
    get trackName(): string;
    set trackName(value: string);
    resetTrackName(): void;
    get trackNameInput(): string | undefined;
    get workgroupId(): string;
    private _workgroupName?;
    get workgroupName(): string;
    set workgroupName(value: string);
    get workgroupNameInput(): string | undefined;
    private _configParameter;
    get configParameter(): AwsRedshiftserverlessWorkgroup.ConfigParameterPropertyList;
    putConfigParameter(value: AwsRedshiftserverlessWorkgroup.ConfigParameterProperty[] | cdktn.IResolvable): void;
    resetConfigParameter(): void;
    get configParameterInput(): cdktn.IResolvable | AwsRedshiftserverlessWorkgroup.ConfigParameterProperty[] | undefined;
    private _pricePerformanceTarget;
    get pricePerformanceTarget(): AwsRedshiftserverlessWorkgroup.PricePerformanceTargetPropertyOutputReference;
    putPricePerformanceTarget(value: AwsRedshiftserverlessWorkgroup.PricePerformanceTargetProperty): void;
    resetPricePerformanceTarget(): void;
    get pricePerformanceTargetInput(): AwsRedshiftserverlessWorkgroup.PricePerformanceTargetProperty | undefined;
    private _timeouts;
    get timeouts(): AwsRedshiftserverlessWorkgroup.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsRedshiftserverlessWorkgroup.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsRedshiftserverlessWorkgroup.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsRedshiftserverlessWorkgroupNetworkInterfacePropertyToTerraform(struct?: AwsRedshiftserverlessWorkgroup.NetworkInterfaceProperty): any;
export declare function awsRedshiftserverlessWorkgroupNetworkInterfacePropertyToHclTerraform(struct?: AwsRedshiftserverlessWorkgroup.NetworkInterfaceProperty): any;
export declare function awsRedshiftserverlessWorkgroupVpcEndpointPropertyToTerraform(struct?: AwsRedshiftserverlessWorkgroup.VpcEndpointProperty): any;
export declare function awsRedshiftserverlessWorkgroupVpcEndpointPropertyToHclTerraform(struct?: AwsRedshiftserverlessWorkgroup.VpcEndpointProperty): any;
export declare function awsRedshiftserverlessWorkgroupEndpointPropertyToTerraform(struct?: AwsRedshiftserverlessWorkgroup.EndpointProperty): any;
export declare function awsRedshiftserverlessWorkgroupEndpointPropertyToHclTerraform(struct?: AwsRedshiftserverlessWorkgroup.EndpointProperty): any;
export declare function awsRedshiftserverlessWorkgroupConfigParameterPropertyToTerraform(struct?: AwsRedshiftserverlessWorkgroup.ConfigParameterProperty | cdktn.IResolvable): any;
export declare function awsRedshiftserverlessWorkgroupConfigParameterPropertyToHclTerraform(struct?: AwsRedshiftserverlessWorkgroup.ConfigParameterProperty | cdktn.IResolvable): any;
export declare function awsRedshiftserverlessWorkgroupPricePerformanceTargetPropertyToTerraform(struct?: AwsRedshiftserverlessWorkgroup.PricePerformanceTargetPropertyOutputReference | AwsRedshiftserverlessWorkgroup.PricePerformanceTargetProperty): any;
export declare function awsRedshiftserverlessWorkgroupPricePerformanceTargetPropertyToHclTerraform(struct?: AwsRedshiftserverlessWorkgroup.PricePerformanceTargetPropertyOutputReference | AwsRedshiftserverlessWorkgroup.PricePerformanceTargetProperty): any;
export declare function awsRedshiftserverlessWorkgroupTimeoutsPropertyToTerraform(struct?: AwsRedshiftserverlessWorkgroup.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsRedshiftserverlessWorkgroupTimeoutsPropertyToHclTerraform(struct?: AwsRedshiftserverlessWorkgroup.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsRedshiftserverlessWorkgroup {
    interface NetworkInterfaceProperty {
    }
    class NetworkInterfacePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): NetworkInterfaceProperty | undefined;
        set internalValue(value: NetworkInterfaceProperty | undefined);
        get availabilityZone(): string;
        get networkInterfaceId(): string;
        get privateIpAddress(): string;
        get subnetId(): string;
    }
    class NetworkInterfacePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): NetworkInterfacePropertyOutputReference;
    }
    interface VpcEndpointProperty {
    }
    class VpcEndpointPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): VpcEndpointProperty | undefined;
        set internalValue(value: VpcEndpointProperty | undefined);
        private _networkInterface;
        get networkInterface(): NetworkInterfacePropertyList;
        get vpcEndpointId(): string;
        get vpcId(): string;
    }
    class VpcEndpointPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): VpcEndpointPropertyOutputReference;
    }
    interface EndpointProperty {
    }
    class EndpointPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EndpointProperty | undefined;
        set internalValue(value: EndpointProperty | undefined);
        get address(): string;
        get port(): number;
        private _vpcEndpoint;
        get vpcEndpoint(): VpcEndpointPropertyList;
    }
    class EndpointPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EndpointPropertyOutputReference;
    }
    interface ConfigParameterProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/redshiftserverless_workgroup#parameter_key AwsRedshiftserverlessWorkgroup#parameter_key}
        */
        readonly parameterKey: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/redshiftserverless_workgroup#parameter_value AwsRedshiftserverlessWorkgroup#parameter_value}
        */
        readonly parameterValue: string;
    }
    class ConfigParameterPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ConfigParameterProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ConfigParameterProperty | cdktn.IResolvable | undefined);
        private _parameterKey?;
        get parameterKey(): string;
        set parameterKey(value: string);
        get parameterKeyInput(): string | undefined;
        private _parameterValue?;
        get parameterValue(): string;
        set parameterValue(value: string);
        get parameterValueInput(): string | undefined;
    }
    class ConfigParameterPropertyList extends cdktn.ComplexList {
        internalValue?: ConfigParameterProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ConfigParameterPropertyOutputReference;
    }
    interface PricePerformanceTargetProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/redshiftserverless_workgroup#enabled AwsRedshiftserverlessWorkgroup#enabled}
        */
        readonly enabled: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/redshiftserverless_workgroup#level AwsRedshiftserverlessWorkgroup#level}
        */
        readonly level?: number;
    }
    class PricePerformanceTargetPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): PricePerformanceTargetProperty | undefined;
        set internalValue(value: PricePerformanceTargetProperty | undefined);
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
        private _level?;
        get level(): number;
        set level(value: number);
        resetLevel(): void;
        get levelInput(): number | undefined;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/redshiftserverless_workgroup#create AwsRedshiftserverlessWorkgroup#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/redshiftserverless_workgroup#delete AwsRedshiftserverlessWorkgroup#delete}
        */
        readonly delete?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/redshiftserverless_workgroup#update AwsRedshiftserverlessWorkgroup#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
