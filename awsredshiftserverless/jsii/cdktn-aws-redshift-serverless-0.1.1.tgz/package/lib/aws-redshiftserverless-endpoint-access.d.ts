import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsRedshiftserverlessEndpointAccessConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/redshiftserverless_endpoint_access#endpoint_name AwsRedshiftserverlessEndpointAccess#endpoint_name}
    */
    readonly endpointName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/redshiftserverless_endpoint_access#id AwsRedshiftserverlessEndpointAccess#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/redshiftserverless_endpoint_access#owner_account AwsRedshiftserverlessEndpointAccess#owner_account}
    */
    readonly ownerAccount?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/redshiftserverless_endpoint_access#region AwsRedshiftserverlessEndpointAccess#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/redshiftserverless_endpoint_access#subnet_ids AwsRedshiftserverlessEndpointAccess#subnet_ids}
    */
    readonly subnetIds: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/redshiftserverless_endpoint_access#vpc_security_group_ids AwsRedshiftserverlessEndpointAccess#vpc_security_group_ids}
    */
    readonly vpcSecurityGroupIds?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/redshiftserverless_endpoint_access#workgroup_name AwsRedshiftserverlessEndpointAccess#workgroup_name}
    */
    readonly workgroupName: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/redshiftserverless_endpoint_access aws_redshiftserverless_endpoint_access}
*/
export declare class AwsRedshiftserverlessEndpointAccess extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_redshiftserverless_endpoint_access";
    /**
    * Generates CDKTN code for importing a AwsRedshiftserverlessEndpointAccess resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsRedshiftserverlessEndpointAccess to import
    * @param importFromId The id of the existing AwsRedshiftserverlessEndpointAccess that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/redshiftserverless_endpoint_access#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsRedshiftserverlessEndpointAccess to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/redshiftserverless_endpoint_access aws_redshiftserverless_endpoint_access} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsRedshiftserverlessEndpointAccessConfig
    */
    constructor(scope: Construct, id: string, config: AwsRedshiftserverlessEndpointAccessConfig);
    get address(): string;
    get arn(): string;
    private _endpointName?;
    get endpointName(): string;
    set endpointName(value: string);
    get endpointNameInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _ownerAccount?;
    get ownerAccount(): string;
    set ownerAccount(value: string);
    resetOwnerAccount(): void;
    get ownerAccountInput(): string | undefined;
    get port(): number;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _subnetIds?;
    get subnetIds(): string[];
    set subnetIds(value: string[]);
    get subnetIdsInput(): string[] | undefined;
    private _vpcEndpoint;
    get vpcEndpoint(): AwsRedshiftserverlessEndpointAccess.VpcEndpointPropertyList;
    private _vpcSecurityGroupIds?;
    get vpcSecurityGroupIds(): string[];
    set vpcSecurityGroupIds(value: string[]);
    resetVpcSecurityGroupIds(): void;
    get vpcSecurityGroupIdsInput(): string[] | undefined;
    private _workgroupName?;
    get workgroupName(): string;
    set workgroupName(value: string);
    get workgroupNameInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsRedshiftserverlessEndpointAccessNetworkInterfacePropertyToTerraform(struct?: AwsRedshiftserverlessEndpointAccess.NetworkInterfaceProperty): any;
export declare function awsRedshiftserverlessEndpointAccessNetworkInterfacePropertyToHclTerraform(struct?: AwsRedshiftserverlessEndpointAccess.NetworkInterfaceProperty): any;
export declare function awsRedshiftserverlessEndpointAccessVpcEndpointPropertyToTerraform(struct?: AwsRedshiftserverlessEndpointAccess.VpcEndpointProperty): any;
export declare function awsRedshiftserverlessEndpointAccessVpcEndpointPropertyToHclTerraform(struct?: AwsRedshiftserverlessEndpointAccess.VpcEndpointProperty): any;
export declare namespace AwsRedshiftserverlessEndpointAccess {
    interface NetworkInterfaceProperty {
    }
    class NetworkInterfacePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): NetworkInterfaceProperty | undefined;
        set internalValue(value: NetworkInterfaceProperty | undefined);
        get availabilityZone(): string;
        get networkInterfaceId(): string;
        get privateIpAddress(): string;
        get subnetId(): string;
    }
    class NetworkInterfacePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): NetworkInterfacePropertyOutputReference;
    }
    interface VpcEndpointProperty {
    }
    class VpcEndpointPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): VpcEndpointProperty | undefined;
        set internalValue(value: VpcEndpointProperty | undefined);
        private _networkInterface;
        get networkInterface(): NetworkInterfacePropertyList;
        get vpcEndpointId(): string;
        get vpcId(): string;
    }
    class VpcEndpointPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): VpcEndpointPropertyOutputReference;
    }
}
