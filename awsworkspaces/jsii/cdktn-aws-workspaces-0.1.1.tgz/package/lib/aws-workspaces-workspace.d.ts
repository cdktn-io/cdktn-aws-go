import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsWorkspacesWorkspaceConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspaces_workspace#bundle_id AwsWorkspacesWorkspace#bundle_id}
    */
    readonly bundleId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspaces_workspace#directory_id AwsWorkspacesWorkspace#directory_id}
    */
    readonly directoryId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspaces_workspace#id AwsWorkspacesWorkspace#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspaces_workspace#region AwsWorkspacesWorkspace#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspaces_workspace#root_volume_encryption_enabled AwsWorkspacesWorkspace#root_volume_encryption_enabled}
    */
    readonly rootVolumeEncryptionEnabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspaces_workspace#tags AwsWorkspacesWorkspace#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspaces_workspace#tags_all AwsWorkspacesWorkspace#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspaces_workspace#user_name AwsWorkspacesWorkspace#user_name}
    */
    readonly userName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspaces_workspace#user_volume_encryption_enabled AwsWorkspacesWorkspace#user_volume_encryption_enabled}
    */
    readonly userVolumeEncryptionEnabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspaces_workspace#volume_encryption_key AwsWorkspacesWorkspace#volume_encryption_key}
    */
    readonly volumeEncryptionKey?: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspaces_workspace#timeouts AwsWorkspacesWorkspace#timeouts}
    */
    readonly timeouts?: AwsWorkspacesWorkspace.TimeoutsProperty;
    /**
    * workspace_properties block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspaces_workspace#workspace_properties AwsWorkspacesWorkspace#workspace_properties}
    */
    readonly workspaceProperties?: AwsWorkspacesWorkspace.WorkspacePropertiesProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspaces_workspace aws_workspaces_workspace}
*/
export declare class AwsWorkspacesWorkspace extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_workspaces_workspace";
    /**
    * Generates CDKTN code for importing a AwsWorkspacesWorkspace resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsWorkspacesWorkspace to import
    * @param importFromId The id of the existing AwsWorkspacesWorkspace that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspaces_workspace#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsWorkspacesWorkspace to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspaces_workspace aws_workspaces_workspace} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsWorkspacesWorkspaceConfig
    */
    constructor(scope: Construct, id: string, config: AwsWorkspacesWorkspaceConfig);
    private _bundleId?;
    get bundleId(): string;
    set bundleId(value: string);
    get bundleIdInput(): string | undefined;
    get computerName(): string;
    private _directoryId?;
    get directoryId(): string;
    set directoryId(value: string);
    get directoryIdInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get ipAddress(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _rootVolumeEncryptionEnabled?;
    get rootVolumeEncryptionEnabled(): boolean | cdktn.IResolvable;
    set rootVolumeEncryptionEnabled(value: boolean | cdktn.IResolvable);
    resetRootVolumeEncryptionEnabled(): void;
    get rootVolumeEncryptionEnabledInput(): boolean | cdktn.IResolvable | undefined;
    get state(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _userName?;
    get userName(): string;
    set userName(value: string);
    get userNameInput(): string | undefined;
    private _userVolumeEncryptionEnabled?;
    get userVolumeEncryptionEnabled(): boolean | cdktn.IResolvable;
    set userVolumeEncryptionEnabled(value: boolean | cdktn.IResolvable);
    resetUserVolumeEncryptionEnabled(): void;
    get userVolumeEncryptionEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _volumeEncryptionKey?;
    get volumeEncryptionKey(): string;
    set volumeEncryptionKey(value: string);
    resetVolumeEncryptionKey(): void;
    get volumeEncryptionKeyInput(): string | undefined;
    private _timeouts;
    get timeouts(): AwsWorkspacesWorkspace.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsWorkspacesWorkspace.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsWorkspacesWorkspace.TimeoutsProperty | undefined;
    private _workspaceProperties;
    get workspaceProperties(): AwsWorkspacesWorkspace.WorkspacePropertiesPropertyOutputReference;
    putWorkspaceProperties(value: AwsWorkspacesWorkspace.WorkspacePropertiesProperty): void;
    resetWorkspaceProperties(): void;
    get workspacePropertiesInput(): AwsWorkspacesWorkspace.WorkspacePropertiesProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsWorkspacesWorkspaceTimeoutsPropertyToTerraform(struct?: AwsWorkspacesWorkspace.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsWorkspacesWorkspaceTimeoutsPropertyToHclTerraform(struct?: AwsWorkspacesWorkspace.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsWorkspacesWorkspaceWorkspacePropertiesPropertyToTerraform(struct?: AwsWorkspacesWorkspace.WorkspacePropertiesPropertyOutputReference | AwsWorkspacesWorkspace.WorkspacePropertiesProperty): any;
export declare function awsWorkspacesWorkspaceWorkspacePropertiesPropertyToHclTerraform(struct?: AwsWorkspacesWorkspace.WorkspacePropertiesPropertyOutputReference | AwsWorkspacesWorkspace.WorkspacePropertiesProperty): any;
export declare namespace AwsWorkspacesWorkspace {
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspaces_workspace#create AwsWorkspacesWorkspace#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspaces_workspace#delete AwsWorkspacesWorkspace#delete}
        */
        readonly delete?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspaces_workspace#update AwsWorkspacesWorkspace#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
    interface WorkspacePropertiesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspaces_workspace#compute_type_name AwsWorkspacesWorkspace#compute_type_name}
        */
        readonly computeTypeName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspaces_workspace#root_volume_size_gib AwsWorkspacesWorkspace#root_volume_size_gib}
        */
        readonly rootVolumeSizeGib?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspaces_workspace#running_mode AwsWorkspacesWorkspace#running_mode}
        */
        readonly runningMode?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspaces_workspace#running_mode_auto_stop_timeout_in_minutes AwsWorkspacesWorkspace#running_mode_auto_stop_timeout_in_minutes}
        */
        readonly runningModeAutoStopTimeoutInMinutes?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workspaces_workspace#user_volume_size_gib AwsWorkspacesWorkspace#user_volume_size_gib}
        */
        readonly userVolumeSizeGib?: number;
    }
    class WorkspacePropertiesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): WorkspacePropertiesProperty | undefined;
        set internalValue(value: WorkspacePropertiesProperty | undefined);
        private _computeTypeName?;
        get computeTypeName(): string;
        set computeTypeName(value: string);
        resetComputeTypeName(): void;
        get computeTypeNameInput(): string | undefined;
        private _rootVolumeSizeGib?;
        get rootVolumeSizeGib(): number;
        set rootVolumeSizeGib(value: number);
        resetRootVolumeSizeGib(): void;
        get rootVolumeSizeGibInput(): number | undefined;
        private _runningMode?;
        get runningMode(): string;
        set runningMode(value: string);
        resetRunningMode(): void;
        get runningModeInput(): string | undefined;
        private _runningModeAutoStopTimeoutInMinutes?;
        get runningModeAutoStopTimeoutInMinutes(): number;
        set runningModeAutoStopTimeoutInMinutes(value: number);
        resetRunningModeAutoStopTimeoutInMinutes(): void;
        get runningModeAutoStopTimeoutInMinutesInput(): number | undefined;
        private _userVolumeSizeGib?;
        get userVolumeSizeGib(): number;
        set userVolumeSizeGib(value: number);
        resetUserVolumeSizeGib(): void;
        get userVolumeSizeGibInput(): number | undefined;
    }
}
