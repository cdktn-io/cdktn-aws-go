import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsInspectorAssessmentTemplateConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector_assessment_template#duration AwsInspectorAssessmentTemplate#duration}
    */
    readonly duration: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector_assessment_template#id AwsInspectorAssessmentTemplate#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector_assessment_template#name AwsInspectorAssessmentTemplate#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector_assessment_template#region AwsInspectorAssessmentTemplate#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector_assessment_template#rules_package_arns AwsInspectorAssessmentTemplate#rules_package_arns}
    */
    readonly rulesPackageArns: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector_assessment_template#tags AwsInspectorAssessmentTemplate#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector_assessment_template#tags_all AwsInspectorAssessmentTemplate#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector_assessment_template#target_arn AwsInspectorAssessmentTemplate#target_arn}
    */
    readonly targetArn: string;
    /**
    * event_subscription block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector_assessment_template#event_subscription AwsInspectorAssessmentTemplate#event_subscription}
    */
    readonly eventSubscription?: AwsInspectorAssessmentTemplate.EventSubscriptionProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector_assessment_template aws_inspector_assessment_template}
*/
export declare class AwsInspectorAssessmentTemplate extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_inspector_assessment_template";
    /**
    * Generates CDKTN code for importing a AwsInspectorAssessmentTemplate resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsInspectorAssessmentTemplate to import
    * @param importFromId The id of the existing AwsInspectorAssessmentTemplate that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector_assessment_template#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsInspectorAssessmentTemplate to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector_assessment_template aws_inspector_assessment_template} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsInspectorAssessmentTemplateConfig
    */
    constructor(scope: Construct, id: string, config: AwsInspectorAssessmentTemplateConfig);
    get arn(): string;
    private _duration?;
    get duration(): number;
    set duration(value: number);
    get durationInput(): number | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _rulesPackageArns?;
    get rulesPackageArns(): string[];
    set rulesPackageArns(value: string[]);
    get rulesPackageArnsInput(): string[] | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _targetArn?;
    get targetArn(): string;
    set targetArn(value: string);
    get targetArnInput(): string | undefined;
    private _eventSubscription;
    get eventSubscription(): AwsInspectorAssessmentTemplate.EventSubscriptionPropertyList;
    putEventSubscription(value: AwsInspectorAssessmentTemplate.EventSubscriptionProperty[] | cdktn.IResolvable): void;
    resetEventSubscription(): void;
    get eventSubscriptionInput(): cdktn.IResolvable | AwsInspectorAssessmentTemplate.EventSubscriptionProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsInspectorAssessmentTemplateEventSubscriptionPropertyToTerraform(struct?: AwsInspectorAssessmentTemplate.EventSubscriptionProperty | cdktn.IResolvable): any;
export declare function awsInspectorAssessmentTemplateEventSubscriptionPropertyToHclTerraform(struct?: AwsInspectorAssessmentTemplate.EventSubscriptionProperty | cdktn.IResolvable): any;
export declare namespace AwsInspectorAssessmentTemplate {
    interface EventSubscriptionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector_assessment_template#event AwsInspectorAssessmentTemplate#event}
        */
        readonly event: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector_assessment_template#topic_arn AwsInspectorAssessmentTemplate#topic_arn}
        */
        readonly topicArn: string;
    }
    class EventSubscriptionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EventSubscriptionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: EventSubscriptionProperty | cdktn.IResolvable | undefined);
        private _event?;
        get event(): string;
        set event(value: string);
        get eventInput(): string | undefined;
        private _topicArn?;
        get topicArn(): string;
        set topicArn(value: string);
        get topicArnInput(): string | undefined;
    }
    class EventSubscriptionPropertyList extends cdktn.ComplexList {
        internalValue?: EventSubscriptionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EventSubscriptionPropertyOutputReference;
    }
}
