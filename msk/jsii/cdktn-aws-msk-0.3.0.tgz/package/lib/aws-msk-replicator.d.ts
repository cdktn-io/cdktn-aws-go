import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsReplicatorConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_replicator#description AwsReplicator#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_replicator#id AwsReplicator#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_replicator#region AwsReplicator#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_replicator#replicator_name AwsReplicator#replicator_name}
    */
    readonly replicatorName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_replicator#service_execution_role_arn AwsReplicator#service_execution_role_arn}
    */
    readonly serviceExecutionRoleArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_replicator#tags AwsReplicator#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_replicator#tags_all AwsReplicator#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * kafka_cluster block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_replicator#kafka_cluster AwsReplicator#kafka_cluster}
    */
    readonly kafkaCluster: AwsReplicator.KafkaClusterProperty[] | cdktn.IResolvable;
    /**
    * log_delivery block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_replicator#log_delivery AwsReplicator#log_delivery}
    */
    readonly logDelivery?: AwsReplicator.LogDeliveryProperty;
    /**
    * replication_info_list block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_replicator#replication_info_list AwsReplicator#replication_info_list}
    */
    readonly replicationInfoList: AwsReplicator.ReplicationInfoListProperty;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_replicator#timeouts AwsReplicator#timeouts}
    */
    readonly timeouts?: AwsReplicator.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_replicator aws_msk_replicator}
*/
export declare class AwsReplicator extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_msk_replicator";
    /**
    * Generates CDKTN code for importing a AwsReplicator resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsReplicator to import
    * @param importFromId The id of the existing AwsReplicator that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_replicator#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsReplicator to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_replicator aws_msk_replicator} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsReplicatorConfig
    */
    constructor(scope: Construct, id: string, config: AwsReplicatorConfig);
    get arn(): string;
    get currentVersion(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _replicatorName?;
    get replicatorName(): string;
    set replicatorName(value: string);
    get replicatorNameInput(): string | undefined;
    private _serviceExecutionRoleArn?;
    get serviceExecutionRoleArn(): string;
    set serviceExecutionRoleArn(value: string);
    get serviceExecutionRoleArnInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _kafkaCluster;
    get kafkaCluster(): AwsReplicator.KafkaClusterPropertyList;
    putKafkaCluster(value: AwsReplicator.KafkaClusterProperty[] | cdktn.IResolvable): void;
    get kafkaClusterInput(): cdktn.IResolvable | AwsReplicator.KafkaClusterProperty[] | undefined;
    private _logDelivery;
    get logDelivery(): AwsReplicator.LogDeliveryPropertyOutputReference;
    putLogDelivery(value: AwsReplicator.LogDeliveryProperty): void;
    resetLogDelivery(): void;
    get logDeliveryInput(): AwsReplicator.LogDeliveryProperty | undefined;
    private _replicationInfoList;
    get replicationInfoList(): AwsReplicator.ReplicationInfoListPropertyOutputReference;
    putReplicationInfoList(value: AwsReplicator.ReplicationInfoListProperty): void;
    get replicationInfoListInput(): AwsReplicator.ReplicationInfoListProperty | undefined;
    private _timeouts;
    get timeouts(): AwsReplicator.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsReplicator.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsReplicator.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsReplicatorAmazonMskClusterPropertyToTerraform(struct?: AwsReplicator.AmazonMskClusterPropertyOutputReference | AwsReplicator.AmazonMskClusterProperty): any;
export declare function awsReplicatorAmazonMskClusterPropertyToHclTerraform(struct?: AwsReplicator.AmazonMskClusterPropertyOutputReference | AwsReplicator.AmazonMskClusterProperty): any;
export declare function awsReplicatorVpcConfigPropertyToTerraform(struct?: AwsReplicator.VpcConfigPropertyOutputReference | AwsReplicator.VpcConfigProperty): any;
export declare function awsReplicatorVpcConfigPropertyToHclTerraform(struct?: AwsReplicator.VpcConfigPropertyOutputReference | AwsReplicator.VpcConfigProperty): any;
export declare function awsReplicatorKafkaClusterPropertyToTerraform(struct?: AwsReplicator.KafkaClusterProperty | cdktn.IResolvable): any;
export declare function awsReplicatorKafkaClusterPropertyToHclTerraform(struct?: AwsReplicator.KafkaClusterProperty | cdktn.IResolvable): any;
export declare function awsReplicatorCloudwatchLogsPropertyToTerraform(struct?: AwsReplicator.CloudwatchLogsPropertyOutputReference | AwsReplicator.CloudwatchLogsProperty): any;
export declare function awsReplicatorCloudwatchLogsPropertyToHclTerraform(struct?: AwsReplicator.CloudwatchLogsPropertyOutputReference | AwsReplicator.CloudwatchLogsProperty): any;
export declare function awsReplicatorFirehosePropertyToTerraform(struct?: AwsReplicator.FirehosePropertyOutputReference | AwsReplicator.FirehoseProperty): any;
export declare function awsReplicatorFirehosePropertyToHclTerraform(struct?: AwsReplicator.FirehosePropertyOutputReference | AwsReplicator.FirehoseProperty): any;
export declare function awsReplicatorS3PropertyToTerraform(struct?: AwsReplicator.S3PropertyOutputReference | AwsReplicator.S3Property): any;
export declare function awsReplicatorS3PropertyToHclTerraform(struct?: AwsReplicator.S3PropertyOutputReference | AwsReplicator.S3Property): any;
export declare function awsReplicatorReplicatorLogDeliveryPropertyToTerraform(struct?: AwsReplicator.ReplicatorLogDeliveryPropertyOutputReference | AwsReplicator.ReplicatorLogDeliveryProperty): any;
export declare function awsReplicatorReplicatorLogDeliveryPropertyToHclTerraform(struct?: AwsReplicator.ReplicatorLogDeliveryPropertyOutputReference | AwsReplicator.ReplicatorLogDeliveryProperty): any;
export declare function awsReplicatorLogDeliveryPropertyToTerraform(struct?: AwsReplicator.LogDeliveryPropertyOutputReference | AwsReplicator.LogDeliveryProperty): any;
export declare function awsReplicatorLogDeliveryPropertyToHclTerraform(struct?: AwsReplicator.LogDeliveryPropertyOutputReference | AwsReplicator.LogDeliveryProperty): any;
export declare function awsReplicatorConsumerGroupReplicationPropertyToTerraform(struct?: AwsReplicator.ConsumerGroupReplicationProperty | cdktn.IResolvable): any;
export declare function awsReplicatorConsumerGroupReplicationPropertyToHclTerraform(struct?: AwsReplicator.ConsumerGroupReplicationProperty | cdktn.IResolvable): any;
export declare function awsReplicatorStartingPositionPropertyToTerraform(struct?: AwsReplicator.StartingPositionPropertyOutputReference | AwsReplicator.StartingPositionProperty): any;
export declare function awsReplicatorStartingPositionPropertyToHclTerraform(struct?: AwsReplicator.StartingPositionPropertyOutputReference | AwsReplicator.StartingPositionProperty): any;
export declare function awsReplicatorTopicNameConfigurationPropertyToTerraform(struct?: AwsReplicator.TopicNameConfigurationPropertyOutputReference | AwsReplicator.TopicNameConfigurationProperty): any;
export declare function awsReplicatorTopicNameConfigurationPropertyToHclTerraform(struct?: AwsReplicator.TopicNameConfigurationPropertyOutputReference | AwsReplicator.TopicNameConfigurationProperty): any;
export declare function awsReplicatorTopicReplicationPropertyToTerraform(struct?: AwsReplicator.TopicReplicationProperty | cdktn.IResolvable): any;
export declare function awsReplicatorTopicReplicationPropertyToHclTerraform(struct?: AwsReplicator.TopicReplicationProperty | cdktn.IResolvable): any;
export declare function awsReplicatorReplicationInfoListPropertyToTerraform(struct?: AwsReplicator.ReplicationInfoListPropertyOutputReference | AwsReplicator.ReplicationInfoListProperty): any;
export declare function awsReplicatorReplicationInfoListPropertyToHclTerraform(struct?: AwsReplicator.ReplicationInfoListPropertyOutputReference | AwsReplicator.ReplicationInfoListProperty): any;
export declare function awsReplicatorTimeoutsPropertyToTerraform(struct?: AwsReplicator.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsReplicatorTimeoutsPropertyToHclTerraform(struct?: AwsReplicator.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsReplicator {
    interface AmazonMskClusterProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_replicator#msk_cluster_arn AwsReplicator#msk_cluster_arn}
        */
        readonly mskClusterArn: string;
    }
    class AmazonMskClusterPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AmazonMskClusterProperty | undefined;
        set internalValue(value: AmazonMskClusterProperty | undefined);
        private _mskClusterArn?;
        get mskClusterArn(): string;
        set mskClusterArn(value: string);
        get mskClusterArnInput(): string | undefined;
    }
    interface VpcConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_replicator#security_groups_ids AwsReplicator#security_groups_ids}
        */
        readonly securityGroupsIds?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_replicator#subnet_ids AwsReplicator#subnet_ids}
        */
        readonly subnetIds: string[];
    }
    class VpcConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): VpcConfigProperty | undefined;
        set internalValue(value: VpcConfigProperty | undefined);
        private _securityGroupsIds?;
        get securityGroupsIds(): string[];
        set securityGroupsIds(value: string[]);
        resetSecurityGroupsIds(): void;
        get securityGroupsIdsInput(): string[] | undefined;
        private _subnetIds?;
        get subnetIds(): string[];
        set subnetIds(value: string[]);
        get subnetIdsInput(): string[] | undefined;
    }
    interface KafkaClusterProperty {
        /**
        * amazon_msk_cluster block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_replicator#amazon_msk_cluster AwsReplicator#amazon_msk_cluster}
        */
        readonly amazonMskCluster: AmazonMskClusterProperty;
        /**
        * vpc_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_replicator#vpc_config AwsReplicator#vpc_config}
        */
        readonly vpcConfig: VpcConfigProperty;
    }
    class KafkaClusterPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): KafkaClusterProperty | cdktn.IResolvable | undefined;
        set internalValue(value: KafkaClusterProperty | cdktn.IResolvable | undefined);
        private _amazonMskCluster;
        get amazonMskCluster(): AmazonMskClusterPropertyOutputReference;
        putAmazonMskCluster(value: AmazonMskClusterProperty): void;
        get amazonMskClusterInput(): AmazonMskClusterProperty | undefined;
        private _vpcConfig;
        get vpcConfig(): VpcConfigPropertyOutputReference;
        putVpcConfig(value: VpcConfigProperty): void;
        get vpcConfigInput(): VpcConfigProperty | undefined;
    }
    class KafkaClusterPropertyList extends cdktn.ComplexList {
        internalValue?: KafkaClusterProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): KafkaClusterPropertyOutputReference;
    }
    interface CloudwatchLogsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_replicator#enabled AwsReplicator#enabled}
        */
        readonly enabled: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_replicator#log_group AwsReplicator#log_group}
        */
        readonly logGroup?: string;
    }
    class CloudwatchLogsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CloudwatchLogsProperty | undefined;
        set internalValue(value: CloudwatchLogsProperty | undefined);
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
        private _logGroup?;
        get logGroup(): string;
        set logGroup(value: string);
        resetLogGroup(): void;
        get logGroupInput(): string | undefined;
    }
    interface FirehoseProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_replicator#delivery_stream AwsReplicator#delivery_stream}
        */
        readonly deliveryStream?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_replicator#enabled AwsReplicator#enabled}
        */
        readonly enabled: boolean | cdktn.IResolvable;
    }
    class FirehosePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): FirehoseProperty | undefined;
        set internalValue(value: FirehoseProperty | undefined);
        private _deliveryStream?;
        get deliveryStream(): string;
        set deliveryStream(value: string);
        resetDeliveryStream(): void;
        get deliveryStreamInput(): string | undefined;
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface S3Property {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_replicator#bucket AwsReplicator#bucket}
        */
        readonly bucket?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_replicator#enabled AwsReplicator#enabled}
        */
        readonly enabled: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_replicator#prefix AwsReplicator#prefix}
        */
        readonly prefix?: string;
    }
    class S3PropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): S3Property | undefined;
        set internalValue(value: S3Property | undefined);
        private _bucket?;
        get bucket(): string;
        set bucket(value: string);
        resetBucket(): void;
        get bucketInput(): string | undefined;
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
        private _prefix?;
        get prefix(): string;
        set prefix(value: string);
        resetPrefix(): void;
        get prefixInput(): string | undefined;
    }
    interface ReplicatorLogDeliveryProperty {
        /**
        * cloudwatch_logs block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_replicator#cloudwatch_logs AwsReplicator#cloudwatch_logs}
        */
        readonly cloudwatchLogs?: CloudwatchLogsProperty;
        /**
        * firehose block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_replicator#firehose AwsReplicator#firehose}
        */
        readonly firehose?: FirehoseProperty;
        /**
        * s3 block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_replicator#s3 AwsReplicator#s3}
        */
        readonly s3?: S3Property;
    }
    class ReplicatorLogDeliveryPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ReplicatorLogDeliveryProperty | undefined;
        set internalValue(value: ReplicatorLogDeliveryProperty | undefined);
        private _cloudwatchLogs;
        get cloudwatchLogs(): CloudwatchLogsPropertyOutputReference;
        putCloudwatchLogs(value: CloudwatchLogsProperty): void;
        resetCloudwatchLogs(): void;
        get cloudwatchLogsInput(): CloudwatchLogsProperty | undefined;
        private _firehose;
        get firehose(): FirehosePropertyOutputReference;
        putFirehose(value: FirehoseProperty): void;
        resetFirehose(): void;
        get firehoseInput(): FirehoseProperty | undefined;
        private _s3;
        get s3(): S3PropertyOutputReference;
        putS3(value: S3Property): void;
        resetS3(): void;
        get s3Input(): S3Property | undefined;
    }
    interface LogDeliveryProperty {
        /**
        * replicator_log_delivery block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_replicator#replicator_log_delivery AwsReplicator#replicator_log_delivery}
        */
        readonly replicatorLogDelivery?: ReplicatorLogDeliveryProperty;
    }
    class LogDeliveryPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): LogDeliveryProperty | undefined;
        set internalValue(value: LogDeliveryProperty | undefined);
        private _replicatorLogDelivery;
        get replicatorLogDelivery(): ReplicatorLogDeliveryPropertyOutputReference;
        putReplicatorLogDelivery(value: ReplicatorLogDeliveryProperty): void;
        resetReplicatorLogDelivery(): void;
        get replicatorLogDeliveryInput(): ReplicatorLogDeliveryProperty | undefined;
    }
    interface ConsumerGroupReplicationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_replicator#consumer_group_offset_sync_mode AwsReplicator#consumer_group_offset_sync_mode}
        */
        readonly consumerGroupOffsetSyncMode?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_replicator#consumer_groups_to_exclude AwsReplicator#consumer_groups_to_exclude}
        */
        readonly consumerGroupsToExclude?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_replicator#consumer_groups_to_replicate AwsReplicator#consumer_groups_to_replicate}
        */
        readonly consumerGroupsToReplicate: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_replicator#detect_and_copy_new_consumer_groups AwsReplicator#detect_and_copy_new_consumer_groups}
        */
        readonly detectAndCopyNewConsumerGroups?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_replicator#synchronise_consumer_group_offsets AwsReplicator#synchronise_consumer_group_offsets}
        */
        readonly synchroniseConsumerGroupOffsets?: boolean | cdktn.IResolvable;
    }
    class ConsumerGroupReplicationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ConsumerGroupReplicationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ConsumerGroupReplicationProperty | cdktn.IResolvable | undefined);
        private _consumerGroupOffsetSyncMode?;
        get consumerGroupOffsetSyncMode(): string;
        set consumerGroupOffsetSyncMode(value: string);
        resetConsumerGroupOffsetSyncMode(): void;
        get consumerGroupOffsetSyncModeInput(): string | undefined;
        private _consumerGroupsToExclude?;
        get consumerGroupsToExclude(): string[];
        set consumerGroupsToExclude(value: string[]);
        resetConsumerGroupsToExclude(): void;
        get consumerGroupsToExcludeInput(): string[] | undefined;
        private _consumerGroupsToReplicate?;
        get consumerGroupsToReplicate(): string[];
        set consumerGroupsToReplicate(value: string[]);
        get consumerGroupsToReplicateInput(): string[] | undefined;
        private _detectAndCopyNewConsumerGroups?;
        get detectAndCopyNewConsumerGroups(): boolean | cdktn.IResolvable;
        set detectAndCopyNewConsumerGroups(value: boolean | cdktn.IResolvable);
        resetDetectAndCopyNewConsumerGroups(): void;
        get detectAndCopyNewConsumerGroupsInput(): boolean | cdktn.IResolvable | undefined;
        private _synchroniseConsumerGroupOffsets?;
        get synchroniseConsumerGroupOffsets(): boolean | cdktn.IResolvable;
        set synchroniseConsumerGroupOffsets(value: boolean | cdktn.IResolvable);
        resetSynchroniseConsumerGroupOffsets(): void;
        get synchroniseConsumerGroupOffsetsInput(): boolean | cdktn.IResolvable | undefined;
    }
    class ConsumerGroupReplicationPropertyList extends cdktn.ComplexList {
        internalValue?: ConsumerGroupReplicationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ConsumerGroupReplicationPropertyOutputReference;
    }
    interface StartingPositionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_replicator#type AwsReplicator#type}
        */
        readonly type?: string;
    }
    class StartingPositionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): StartingPositionProperty | undefined;
        set internalValue(value: StartingPositionProperty | undefined);
        private _type?;
        get type(): string;
        set type(value: string);
        resetType(): void;
        get typeInput(): string | undefined;
    }
    interface TopicNameConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_replicator#type AwsReplicator#type}
        */
        readonly type?: string;
    }
    class TopicNameConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TopicNameConfigurationProperty | undefined;
        set internalValue(value: TopicNameConfigurationProperty | undefined);
        private _type?;
        get type(): string;
        set type(value: string);
        resetType(): void;
        get typeInput(): string | undefined;
    }
    interface TopicReplicationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_replicator#copy_access_control_lists_for_topics AwsReplicator#copy_access_control_lists_for_topics}
        */
        readonly copyAccessControlListsForTopics?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_replicator#copy_topic_configurations AwsReplicator#copy_topic_configurations}
        */
        readonly copyTopicConfigurations?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_replicator#detect_and_copy_new_topics AwsReplicator#detect_and_copy_new_topics}
        */
        readonly detectAndCopyNewTopics?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_replicator#topics_to_exclude AwsReplicator#topics_to_exclude}
        */
        readonly topicsToExclude?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_replicator#topics_to_replicate AwsReplicator#topics_to_replicate}
        */
        readonly topicsToReplicate: string[];
        /**
        * starting_position block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_replicator#starting_position AwsReplicator#starting_position}
        */
        readonly startingPosition?: StartingPositionProperty;
        /**
        * topic_name_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_replicator#topic_name_configuration AwsReplicator#topic_name_configuration}
        */
        readonly topicNameConfiguration?: TopicNameConfigurationProperty;
    }
    class TopicReplicationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TopicReplicationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TopicReplicationProperty | cdktn.IResolvable | undefined);
        private _copyAccessControlListsForTopics?;
        get copyAccessControlListsForTopics(): boolean | cdktn.IResolvable;
        set copyAccessControlListsForTopics(value: boolean | cdktn.IResolvable);
        resetCopyAccessControlListsForTopics(): void;
        get copyAccessControlListsForTopicsInput(): boolean | cdktn.IResolvable | undefined;
        private _copyTopicConfigurations?;
        get copyTopicConfigurations(): boolean | cdktn.IResolvable;
        set copyTopicConfigurations(value: boolean | cdktn.IResolvable);
        resetCopyTopicConfigurations(): void;
        get copyTopicConfigurationsInput(): boolean | cdktn.IResolvable | undefined;
        private _detectAndCopyNewTopics?;
        get detectAndCopyNewTopics(): boolean | cdktn.IResolvable;
        set detectAndCopyNewTopics(value: boolean | cdktn.IResolvable);
        resetDetectAndCopyNewTopics(): void;
        get detectAndCopyNewTopicsInput(): boolean | cdktn.IResolvable | undefined;
        private _topicsToExclude?;
        get topicsToExclude(): string[];
        set topicsToExclude(value: string[]);
        resetTopicsToExclude(): void;
        get topicsToExcludeInput(): string[] | undefined;
        private _topicsToReplicate?;
        get topicsToReplicate(): string[];
        set topicsToReplicate(value: string[]);
        get topicsToReplicateInput(): string[] | undefined;
        private _startingPosition;
        get startingPosition(): StartingPositionPropertyOutputReference;
        putStartingPosition(value: StartingPositionProperty): void;
        resetStartingPosition(): void;
        get startingPositionInput(): StartingPositionProperty | undefined;
        private _topicNameConfiguration;
        get topicNameConfiguration(): TopicNameConfigurationPropertyOutputReference;
        putTopicNameConfiguration(value: TopicNameConfigurationProperty): void;
        resetTopicNameConfiguration(): void;
        get topicNameConfigurationInput(): TopicNameConfigurationProperty | undefined;
    }
    class TopicReplicationPropertyList extends cdktn.ComplexList {
        internalValue?: TopicReplicationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TopicReplicationPropertyOutputReference;
    }
    interface ReplicationInfoListProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_replicator#source_kafka_cluster_arn AwsReplicator#source_kafka_cluster_arn}
        */
        readonly sourceKafkaClusterArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_replicator#target_compression_type AwsReplicator#target_compression_type}
        */
        readonly targetCompressionType: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_replicator#target_kafka_cluster_arn AwsReplicator#target_kafka_cluster_arn}
        */
        readonly targetKafkaClusterArn: string;
        /**
        * consumer_group_replication block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_replicator#consumer_group_replication AwsReplicator#consumer_group_replication}
        */
        readonly consumerGroupReplication: ConsumerGroupReplicationProperty[] | cdktn.IResolvable;
        /**
        * topic_replication block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_replicator#topic_replication AwsReplicator#topic_replication}
        */
        readonly topicReplication: TopicReplicationProperty[] | cdktn.IResolvable;
    }
    class ReplicationInfoListPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ReplicationInfoListProperty | undefined;
        set internalValue(value: ReplicationInfoListProperty | undefined);
        get sourceKafkaClusterAlias(): string;
        private _sourceKafkaClusterArn?;
        get sourceKafkaClusterArn(): string;
        set sourceKafkaClusterArn(value: string);
        get sourceKafkaClusterArnInput(): string | undefined;
        private _targetCompressionType?;
        get targetCompressionType(): string;
        set targetCompressionType(value: string);
        get targetCompressionTypeInput(): string | undefined;
        get targetKafkaClusterAlias(): string;
        private _targetKafkaClusterArn?;
        get targetKafkaClusterArn(): string;
        set targetKafkaClusterArn(value: string);
        get targetKafkaClusterArnInput(): string | undefined;
        private _consumerGroupReplication;
        get consumerGroupReplication(): ConsumerGroupReplicationPropertyList;
        putConsumerGroupReplication(value: ConsumerGroupReplicationProperty[] | cdktn.IResolvable): void;
        get consumerGroupReplicationInput(): cdktn.IResolvable | ConsumerGroupReplicationProperty[] | undefined;
        private _topicReplication;
        get topicReplication(): TopicReplicationPropertyList;
        putTopicReplication(value: TopicReplicationProperty[] | cdktn.IResolvable): void;
        get topicReplicationInput(): cdktn.IResolvable | TopicReplicationProperty[] | undefined;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_replicator#create AwsReplicator#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_replicator#delete AwsReplicator#delete}
        */
        readonly delete?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_replicator#update AwsReplicator#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
