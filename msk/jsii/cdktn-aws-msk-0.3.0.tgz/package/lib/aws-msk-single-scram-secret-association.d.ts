import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsSingleScramSecretAssociationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_single_scram_secret_association#cluster_arn AwsSingleScramSecretAssociation#cluster_arn}
    */
    readonly clusterArn: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_single_scram_secret_association#region AwsSingleScramSecretAssociation#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_single_scram_secret_association#secret_arn AwsSingleScramSecretAssociation#secret_arn}
    */
    readonly secretArn: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_single_scram_secret_association aws_msk_single_scram_secret_association}
*/
export declare class AwsSingleScramSecretAssociation extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_msk_single_scram_secret_association";
    /**
    * Generates CDKTN code for importing a AwsSingleScramSecretAssociation resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsSingleScramSecretAssociation to import
    * @param importFromId The id of the existing AwsSingleScramSecretAssociation that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_single_scram_secret_association#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsSingleScramSecretAssociation to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_single_scram_secret_association aws_msk_single_scram_secret_association} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsSingleScramSecretAssociationConfig
    */
    constructor(scope: Construct, id: string, config: AwsSingleScramSecretAssociationConfig);
    private _clusterArn?;
    get clusterArn(): string;
    set clusterArn(value: string);
    get clusterArnInput(): string | undefined;
    get id(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _secretArn?;
    get secretArn(): string;
    set secretArn(value: string);
    get secretArnInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
