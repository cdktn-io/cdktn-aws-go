import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsClusterConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/msk_cluster#cluster_name DataAwsCluster#cluster_name}
    */
    readonly clusterName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/msk_cluster#id DataAwsCluster#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/msk_cluster#region DataAwsCluster#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/msk_cluster#tags DataAwsCluster#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/msk_cluster aws_msk_cluster}
*/
export declare class DataAwsCluster extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_msk_cluster";
    /**
    * Generates CDKTN code for importing a DataAwsCluster resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsCluster to import
    * @param importFromId The id of the existing DataAwsCluster that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/msk_cluster#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsCluster to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/msk_cluster aws_msk_cluster} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsClusterConfig
    */
    constructor(scope: Construct, id: string, config: DataAwsClusterConfig);
    get arn(): string;
    get bootstrapBrokers(): string;
    get bootstrapBrokersPublicSaslIam(): string;
    get bootstrapBrokersPublicSaslScram(): string;
    get bootstrapBrokersPublicTls(): string;
    get bootstrapBrokersSaslIam(): string;
    get bootstrapBrokersSaslScram(): string;
    get bootstrapBrokersTls(): string;
    private _brokerNodeGroupInfo;
    get brokerNodeGroupInfo(): DataAwsCluster.BrokerNodeGroupInfoPropertyList;
    private _clusterName?;
    get clusterName(): string;
    set clusterName(value: string);
    get clusterNameInput(): string | undefined;
    get clusterUuid(): string;
    get customerActionStatus(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get kafkaVersion(): string;
    get numberOfBrokerNodes(): number;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    get zookeeperConnectString(): string;
    get zookeeperConnectStringTls(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataAwsClusterPublicAccessPropertyToTerraform(struct?: DataAwsCluster.PublicAccessProperty): any;
export declare function dataAwsClusterPublicAccessPropertyToHclTerraform(struct?: DataAwsCluster.PublicAccessProperty): any;
export declare function dataAwsClusterSaslPropertyToTerraform(struct?: DataAwsCluster.SaslProperty): any;
export declare function dataAwsClusterSaslPropertyToHclTerraform(struct?: DataAwsCluster.SaslProperty): any;
export declare function dataAwsClusterClientAuthenticationPropertyToTerraform(struct?: DataAwsCluster.ClientAuthenticationProperty): any;
export declare function dataAwsClusterClientAuthenticationPropertyToHclTerraform(struct?: DataAwsCluster.ClientAuthenticationProperty): any;
export declare function dataAwsClusterVpcConnectivityPropertyToTerraform(struct?: DataAwsCluster.VpcConnectivityProperty): any;
export declare function dataAwsClusterVpcConnectivityPropertyToHclTerraform(struct?: DataAwsCluster.VpcConnectivityProperty): any;
export declare function dataAwsClusterConnectivityInfoPropertyToTerraform(struct?: DataAwsCluster.ConnectivityInfoProperty): any;
export declare function dataAwsClusterConnectivityInfoPropertyToHclTerraform(struct?: DataAwsCluster.ConnectivityInfoProperty): any;
export declare function dataAwsClusterProvisionedThroughputPropertyToTerraform(struct?: DataAwsCluster.ProvisionedThroughputProperty): any;
export declare function dataAwsClusterProvisionedThroughputPropertyToHclTerraform(struct?: DataAwsCluster.ProvisionedThroughputProperty): any;
export declare function dataAwsClusterEbsStorageInfoPropertyToTerraform(struct?: DataAwsCluster.EbsStorageInfoProperty): any;
export declare function dataAwsClusterEbsStorageInfoPropertyToHclTerraform(struct?: DataAwsCluster.EbsStorageInfoProperty): any;
export declare function dataAwsClusterStorageInfoPropertyToTerraform(struct?: DataAwsCluster.StorageInfoProperty): any;
export declare function dataAwsClusterStorageInfoPropertyToHclTerraform(struct?: DataAwsCluster.StorageInfoProperty): any;
export declare function dataAwsClusterBrokerNodeGroupInfoPropertyToTerraform(struct?: DataAwsCluster.BrokerNodeGroupInfoProperty): any;
export declare function dataAwsClusterBrokerNodeGroupInfoPropertyToHclTerraform(struct?: DataAwsCluster.BrokerNodeGroupInfoProperty): any;
export declare namespace DataAwsCluster {
    interface PublicAccessProperty {
    }
    class PublicAccessPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): PublicAccessProperty | undefined;
        set internalValue(value: PublicAccessProperty | undefined);
        get type(): string;
    }
    class PublicAccessPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): PublicAccessPropertyOutputReference;
    }
    interface SaslProperty {
    }
    class SaslPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SaslProperty | undefined;
        set internalValue(value: SaslProperty | undefined);
        get iam(): cdktn.IResolvable;
        get scram(): cdktn.IResolvable;
    }
    class SaslPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SaslPropertyOutputReference;
    }
    interface ClientAuthenticationProperty {
    }
    class ClientAuthenticationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ClientAuthenticationProperty | undefined;
        set internalValue(value: ClientAuthenticationProperty | undefined);
        private _sasl;
        get sasl(): SaslPropertyList;
        get tls(): cdktn.IResolvable;
    }
    class ClientAuthenticationPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ClientAuthenticationPropertyOutputReference;
    }
    interface VpcConnectivityProperty {
    }
    class VpcConnectivityPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): VpcConnectivityProperty | undefined;
        set internalValue(value: VpcConnectivityProperty | undefined);
        private _clientAuthentication;
        get clientAuthentication(): ClientAuthenticationPropertyList;
    }
    class VpcConnectivityPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): VpcConnectivityPropertyOutputReference;
    }
    interface ConnectivityInfoProperty {
    }
    class ConnectivityInfoPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ConnectivityInfoProperty | undefined;
        set internalValue(value: ConnectivityInfoProperty | undefined);
        get networkType(): string;
        private _publicAccess;
        get publicAccess(): PublicAccessPropertyList;
        private _vpcConnectivity;
        get vpcConnectivity(): VpcConnectivityPropertyList;
    }
    class ConnectivityInfoPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ConnectivityInfoPropertyOutputReference;
    }
    interface ProvisionedThroughputProperty {
    }
    class ProvisionedThroughputPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ProvisionedThroughputProperty | undefined;
        set internalValue(value: ProvisionedThroughputProperty | undefined);
        get enabled(): cdktn.IResolvable;
        get volumeThroughput(): number;
    }
    class ProvisionedThroughputPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ProvisionedThroughputPropertyOutputReference;
    }
    interface EbsStorageInfoProperty {
    }
    class EbsStorageInfoPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EbsStorageInfoProperty | undefined;
        set internalValue(value: EbsStorageInfoProperty | undefined);
        private _provisionedThroughput;
        get provisionedThroughput(): ProvisionedThroughputPropertyList;
        get volumeSize(): number;
    }
    class EbsStorageInfoPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EbsStorageInfoPropertyOutputReference;
    }
    interface StorageInfoProperty {
    }
    class StorageInfoPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): StorageInfoProperty | undefined;
        set internalValue(value: StorageInfoProperty | undefined);
        private _ebsStorageInfo;
        get ebsStorageInfo(): EbsStorageInfoPropertyList;
    }
    class StorageInfoPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): StorageInfoPropertyOutputReference;
    }
    interface BrokerNodeGroupInfoProperty {
    }
    class BrokerNodeGroupInfoPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): BrokerNodeGroupInfoProperty | undefined;
        set internalValue(value: BrokerNodeGroupInfoProperty | undefined);
        get azDistribution(): string;
        get clientSubnets(): string[];
        private _connectivityInfo;
        get connectivityInfo(): ConnectivityInfoPropertyList;
        get instanceType(): string;
        get securityGroups(): string[];
        private _storageInfo;
        get storageInfo(): StorageInfoPropertyList;
    }
    class BrokerNodeGroupInfoPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): BrokerNodeGroupInfoPropertyOutputReference;
    }
}
