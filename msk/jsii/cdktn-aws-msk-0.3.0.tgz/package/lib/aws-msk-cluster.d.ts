import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsClusterConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_cluster#cluster_name AwsCluster#cluster_name}
    */
    readonly clusterName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_cluster#enhanced_monitoring AwsCluster#enhanced_monitoring}
    */
    readonly enhancedMonitoring?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_cluster#id AwsCluster#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_cluster#kafka_version AwsCluster#kafka_version}
    */
    readonly kafkaVersion: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_cluster#number_of_broker_nodes AwsCluster#number_of_broker_nodes}
    */
    readonly numberOfBrokerNodes: number;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_cluster#region AwsCluster#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_cluster#storage_mode AwsCluster#storage_mode}
    */
    readonly storageMode?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_cluster#tags AwsCluster#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_cluster#tags_all AwsCluster#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * broker_node_group_info block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_cluster#broker_node_group_info AwsCluster#broker_node_group_info}
    */
    readonly brokerNodeGroupInfo: AwsCluster.BrokerNodeGroupInfoProperty;
    /**
    * client_authentication block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_cluster#client_authentication AwsCluster#client_authentication}
    */
    readonly clientAuthentication?: AwsCluster.ClientAuthenticationProperty;
    /**
    * configuration_info block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_cluster#configuration_info AwsCluster#configuration_info}
    */
    readonly configurationInfo?: AwsCluster.ConfigurationInfoProperty;
    /**
    * encryption_info block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_cluster#encryption_info AwsCluster#encryption_info}
    */
    readonly encryptionInfo?: AwsCluster.EncryptionInfoProperty;
    /**
    * logging_info block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_cluster#logging_info AwsCluster#logging_info}
    */
    readonly loggingInfo?: AwsCluster.LoggingInfoProperty;
    /**
    * open_monitoring block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_cluster#open_monitoring AwsCluster#open_monitoring}
    */
    readonly openMonitoring?: AwsCluster.OpenMonitoringProperty;
    /**
    * rebalancing block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_cluster#rebalancing AwsCluster#rebalancing}
    */
    readonly rebalancing?: AwsCluster.RebalancingProperty;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_cluster#timeouts AwsCluster#timeouts}
    */
    readonly timeouts?: AwsCluster.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_cluster aws_msk_cluster}
*/
export declare class AwsCluster extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_msk_cluster";
    /**
    * Generates CDKTN code for importing a AwsCluster resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsCluster to import
    * @param importFromId The id of the existing AwsCluster that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_cluster#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsCluster to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_cluster aws_msk_cluster} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsClusterConfig
    */
    constructor(scope: Construct, id: string, config: AwsClusterConfig);
    get arn(): string;
    get bootstrapBrokers(): string;
    get bootstrapBrokersIpv6(): string;
    get bootstrapBrokersPublicSaslIam(): string;
    get bootstrapBrokersPublicSaslScram(): string;
    get bootstrapBrokersPublicTls(): string;
    get bootstrapBrokersSaslIam(): string;
    get bootstrapBrokersSaslIamIpv6(): string;
    get bootstrapBrokersSaslScram(): string;
    get bootstrapBrokersSaslScramIpv6(): string;
    get bootstrapBrokersTls(): string;
    get bootstrapBrokersTlsIpv6(): string;
    get bootstrapBrokersVpcConnectivitySaslIam(): string;
    get bootstrapBrokersVpcConnectivitySaslScram(): string;
    get bootstrapBrokersVpcConnectivityTls(): string;
    private _clusterName?;
    get clusterName(): string;
    set clusterName(value: string);
    get clusterNameInput(): string | undefined;
    get clusterUuid(): string;
    get currentVersion(): string;
    get customerActionStatus(): string;
    private _enhancedMonitoring?;
    get enhancedMonitoring(): string;
    set enhancedMonitoring(value: string);
    resetEnhancedMonitoring(): void;
    get enhancedMonitoringInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _kafkaVersion?;
    get kafkaVersion(): string;
    set kafkaVersion(value: string);
    get kafkaVersionInput(): string | undefined;
    private _numberOfBrokerNodes?;
    get numberOfBrokerNodes(): number;
    set numberOfBrokerNodes(value: number);
    get numberOfBrokerNodesInput(): number | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _storageMode?;
    get storageMode(): string;
    set storageMode(value: string);
    resetStorageMode(): void;
    get storageModeInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    get zookeeperConnectString(): string;
    get zookeeperConnectStringTls(): string;
    private _brokerNodeGroupInfo;
    get brokerNodeGroupInfo(): AwsCluster.BrokerNodeGroupInfoPropertyOutputReference;
    putBrokerNodeGroupInfo(value: AwsCluster.BrokerNodeGroupInfoProperty): void;
    get brokerNodeGroupInfoInput(): AwsCluster.BrokerNodeGroupInfoProperty | undefined;
    private _clientAuthentication;
    get clientAuthentication(): AwsCluster.ClientAuthenticationPropertyOutputReference;
    putClientAuthentication(value: AwsCluster.ClientAuthenticationProperty): void;
    resetClientAuthentication(): void;
    get clientAuthenticationInput(): AwsCluster.ClientAuthenticationProperty | undefined;
    private _configurationInfo;
    get configurationInfo(): AwsCluster.ConfigurationInfoPropertyOutputReference;
    putConfigurationInfo(value: AwsCluster.ConfigurationInfoProperty): void;
    resetConfigurationInfo(): void;
    get configurationInfoInput(): AwsCluster.ConfigurationInfoProperty | undefined;
    private _encryptionInfo;
    get encryptionInfo(): AwsCluster.EncryptionInfoPropertyOutputReference;
    putEncryptionInfo(value: AwsCluster.EncryptionInfoProperty): void;
    resetEncryptionInfo(): void;
    get encryptionInfoInput(): AwsCluster.EncryptionInfoProperty | undefined;
    private _loggingInfo;
    get loggingInfo(): AwsCluster.LoggingInfoPropertyOutputReference;
    putLoggingInfo(value: AwsCluster.LoggingInfoProperty): void;
    resetLoggingInfo(): void;
    get loggingInfoInput(): AwsCluster.LoggingInfoProperty | undefined;
    private _openMonitoring;
    get openMonitoring(): AwsCluster.OpenMonitoringPropertyOutputReference;
    putOpenMonitoring(value: AwsCluster.OpenMonitoringProperty): void;
    resetOpenMonitoring(): void;
    get openMonitoringInput(): AwsCluster.OpenMonitoringProperty | undefined;
    private _rebalancing;
    get rebalancing(): AwsCluster.RebalancingPropertyOutputReference;
    putRebalancing(value: AwsCluster.RebalancingProperty): void;
    resetRebalancing(): void;
    get rebalancingInput(): AwsCluster.RebalancingProperty | undefined;
    private _timeouts;
    get timeouts(): AwsCluster.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsCluster.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): AwsCluster.TimeoutsProperty | cdktn.IResolvable | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsClusterPublicAccessPropertyToTerraform(struct?: AwsCluster.PublicAccessPropertyOutputReference | AwsCluster.PublicAccessProperty): any;
export declare function awsClusterPublicAccessPropertyToHclTerraform(struct?: AwsCluster.PublicAccessPropertyOutputReference | AwsCluster.PublicAccessProperty): any;
export declare function awsClusterBrokerNodeGroupInfoConnectivityInfoVpcConnectivityClientAuthenticationSaslPropertyToTerraform(struct?: AwsCluster.BrokerNodeGroupInfoConnectivityInfoVpcConnectivityClientAuthenticationSaslPropertyOutputReference | AwsCluster.BrokerNodeGroupInfoConnectivityInfoVpcConnectivityClientAuthenticationSaslProperty): any;
export declare function awsClusterBrokerNodeGroupInfoConnectivityInfoVpcConnectivityClientAuthenticationSaslPropertyToHclTerraform(struct?: AwsCluster.BrokerNodeGroupInfoConnectivityInfoVpcConnectivityClientAuthenticationSaslPropertyOutputReference | AwsCluster.BrokerNodeGroupInfoConnectivityInfoVpcConnectivityClientAuthenticationSaslProperty): any;
export declare function awsClusterBrokerNodeGroupInfoConnectivityInfoVpcConnectivityClientAuthenticationPropertyToTerraform(struct?: AwsCluster.BrokerNodeGroupInfoConnectivityInfoVpcConnectivityClientAuthenticationPropertyOutputReference | AwsCluster.BrokerNodeGroupInfoConnectivityInfoVpcConnectivityClientAuthenticationProperty): any;
export declare function awsClusterBrokerNodeGroupInfoConnectivityInfoVpcConnectivityClientAuthenticationPropertyToHclTerraform(struct?: AwsCluster.BrokerNodeGroupInfoConnectivityInfoVpcConnectivityClientAuthenticationPropertyOutputReference | AwsCluster.BrokerNodeGroupInfoConnectivityInfoVpcConnectivityClientAuthenticationProperty): any;
export declare function awsClusterVpcConnectivityPropertyToTerraform(struct?: AwsCluster.VpcConnectivityPropertyOutputReference | AwsCluster.VpcConnectivityProperty): any;
export declare function awsClusterVpcConnectivityPropertyToHclTerraform(struct?: AwsCluster.VpcConnectivityPropertyOutputReference | AwsCluster.VpcConnectivityProperty): any;
export declare function awsClusterConnectivityInfoPropertyToTerraform(struct?: AwsCluster.ConnectivityInfoPropertyOutputReference | AwsCluster.ConnectivityInfoProperty): any;
export declare function awsClusterConnectivityInfoPropertyToHclTerraform(struct?: AwsCluster.ConnectivityInfoPropertyOutputReference | AwsCluster.ConnectivityInfoProperty): any;
export declare function awsClusterProvisionedThroughputPropertyToTerraform(struct?: AwsCluster.ProvisionedThroughputPropertyOutputReference | AwsCluster.ProvisionedThroughputProperty): any;
export declare function awsClusterProvisionedThroughputPropertyToHclTerraform(struct?: AwsCluster.ProvisionedThroughputPropertyOutputReference | AwsCluster.ProvisionedThroughputProperty): any;
export declare function awsClusterEbsStorageInfoPropertyToTerraform(struct?: AwsCluster.EbsStorageInfoPropertyOutputReference | AwsCluster.EbsStorageInfoProperty): any;
export declare function awsClusterEbsStorageInfoPropertyToHclTerraform(struct?: AwsCluster.EbsStorageInfoPropertyOutputReference | AwsCluster.EbsStorageInfoProperty): any;
export declare function awsClusterStorageInfoPropertyToTerraform(struct?: AwsCluster.StorageInfoPropertyOutputReference | AwsCluster.StorageInfoProperty): any;
export declare function awsClusterStorageInfoPropertyToHclTerraform(struct?: AwsCluster.StorageInfoPropertyOutputReference | AwsCluster.StorageInfoProperty): any;
export declare function awsClusterBrokerNodeGroupInfoPropertyToTerraform(struct?: AwsCluster.BrokerNodeGroupInfoPropertyOutputReference | AwsCluster.BrokerNodeGroupInfoProperty): any;
export declare function awsClusterBrokerNodeGroupInfoPropertyToHclTerraform(struct?: AwsCluster.BrokerNodeGroupInfoPropertyOutputReference | AwsCluster.BrokerNodeGroupInfoProperty): any;
export declare function awsClusterClientAuthenticationSaslPropertyToTerraform(struct?: AwsCluster.ClientAuthenticationSaslPropertyOutputReference | AwsCluster.ClientAuthenticationSaslProperty): any;
export declare function awsClusterClientAuthenticationSaslPropertyToHclTerraform(struct?: AwsCluster.ClientAuthenticationSaslPropertyOutputReference | AwsCluster.ClientAuthenticationSaslProperty): any;
export declare function awsClusterTlsPropertyToTerraform(struct?: AwsCluster.TlsPropertyOutputReference | AwsCluster.TlsProperty): any;
export declare function awsClusterTlsPropertyToHclTerraform(struct?: AwsCluster.TlsPropertyOutputReference | AwsCluster.TlsProperty): any;
export declare function awsClusterClientAuthenticationPropertyToTerraform(struct?: AwsCluster.ClientAuthenticationPropertyOutputReference | AwsCluster.ClientAuthenticationProperty): any;
export declare function awsClusterClientAuthenticationPropertyToHclTerraform(struct?: AwsCluster.ClientAuthenticationPropertyOutputReference | AwsCluster.ClientAuthenticationProperty): any;
export declare function awsClusterConfigurationInfoPropertyToTerraform(struct?: AwsCluster.ConfigurationInfoPropertyOutputReference | AwsCluster.ConfigurationInfoProperty): any;
export declare function awsClusterConfigurationInfoPropertyToHclTerraform(struct?: AwsCluster.ConfigurationInfoPropertyOutputReference | AwsCluster.ConfigurationInfoProperty): any;
export declare function awsClusterEncryptionInTransitPropertyToTerraform(struct?: AwsCluster.EncryptionInTransitPropertyOutputReference | AwsCluster.EncryptionInTransitProperty): any;
export declare function awsClusterEncryptionInTransitPropertyToHclTerraform(struct?: AwsCluster.EncryptionInTransitPropertyOutputReference | AwsCluster.EncryptionInTransitProperty): any;
export declare function awsClusterEncryptionInfoPropertyToTerraform(struct?: AwsCluster.EncryptionInfoPropertyOutputReference | AwsCluster.EncryptionInfoProperty): any;
export declare function awsClusterEncryptionInfoPropertyToHclTerraform(struct?: AwsCluster.EncryptionInfoPropertyOutputReference | AwsCluster.EncryptionInfoProperty): any;
export declare function awsClusterCloudwatchLogsPropertyToTerraform(struct?: AwsCluster.CloudwatchLogsPropertyOutputReference | AwsCluster.CloudwatchLogsProperty): any;
export declare function awsClusterCloudwatchLogsPropertyToHclTerraform(struct?: AwsCluster.CloudwatchLogsPropertyOutputReference | AwsCluster.CloudwatchLogsProperty): any;
export declare function awsClusterFirehosePropertyToTerraform(struct?: AwsCluster.FirehosePropertyOutputReference | AwsCluster.FirehoseProperty): any;
export declare function awsClusterFirehosePropertyToHclTerraform(struct?: AwsCluster.FirehosePropertyOutputReference | AwsCluster.FirehoseProperty): any;
export declare function awsClusterS3PropertyToTerraform(struct?: AwsCluster.S3PropertyOutputReference | AwsCluster.S3Property): any;
export declare function awsClusterS3PropertyToHclTerraform(struct?: AwsCluster.S3PropertyOutputReference | AwsCluster.S3Property): any;
export declare function awsClusterBrokerLogsPropertyToTerraform(struct?: AwsCluster.BrokerLogsPropertyOutputReference | AwsCluster.BrokerLogsProperty): any;
export declare function awsClusterBrokerLogsPropertyToHclTerraform(struct?: AwsCluster.BrokerLogsPropertyOutputReference | AwsCluster.BrokerLogsProperty): any;
export declare function awsClusterLoggingInfoPropertyToTerraform(struct?: AwsCluster.LoggingInfoPropertyOutputReference | AwsCluster.LoggingInfoProperty): any;
export declare function awsClusterLoggingInfoPropertyToHclTerraform(struct?: AwsCluster.LoggingInfoPropertyOutputReference | AwsCluster.LoggingInfoProperty): any;
export declare function awsClusterJmxExporterPropertyToTerraform(struct?: AwsCluster.JmxExporterPropertyOutputReference | AwsCluster.JmxExporterProperty): any;
export declare function awsClusterJmxExporterPropertyToHclTerraform(struct?: AwsCluster.JmxExporterPropertyOutputReference | AwsCluster.JmxExporterProperty): any;
export declare function awsClusterNodeExporterPropertyToTerraform(struct?: AwsCluster.NodeExporterPropertyOutputReference | AwsCluster.NodeExporterProperty): any;
export declare function awsClusterNodeExporterPropertyToHclTerraform(struct?: AwsCluster.NodeExporterPropertyOutputReference | AwsCluster.NodeExporterProperty): any;
export declare function awsClusterPrometheusPropertyToTerraform(struct?: AwsCluster.PrometheusPropertyOutputReference | AwsCluster.PrometheusProperty): any;
export declare function awsClusterPrometheusPropertyToHclTerraform(struct?: AwsCluster.PrometheusPropertyOutputReference | AwsCluster.PrometheusProperty): any;
export declare function awsClusterOpenMonitoringPropertyToTerraform(struct?: AwsCluster.OpenMonitoringPropertyOutputReference | AwsCluster.OpenMonitoringProperty): any;
export declare function awsClusterOpenMonitoringPropertyToHclTerraform(struct?: AwsCluster.OpenMonitoringPropertyOutputReference | AwsCluster.OpenMonitoringProperty): any;
export declare function awsClusterRebalancingPropertyToTerraform(struct?: AwsCluster.RebalancingPropertyOutputReference | AwsCluster.RebalancingProperty): any;
export declare function awsClusterRebalancingPropertyToHclTerraform(struct?: AwsCluster.RebalancingPropertyOutputReference | AwsCluster.RebalancingProperty): any;
export declare function awsClusterTimeoutsPropertyToTerraform(struct?: AwsCluster.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsClusterTimeoutsPropertyToHclTerraform(struct?: AwsCluster.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsCluster {
    interface PublicAccessProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_cluster#type AwsCluster#type}
        */
        readonly type?: string;
    }
    class PublicAccessPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): PublicAccessProperty | undefined;
        set internalValue(value: PublicAccessProperty | undefined);
        private _type?;
        get type(): string;
        set type(value: string);
        resetType(): void;
        get typeInput(): string | undefined;
    }
    interface BrokerNodeGroupInfoConnectivityInfoVpcConnectivityClientAuthenticationSaslProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_cluster#iam AwsCluster#iam}
        */
        readonly iam?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_cluster#scram AwsCluster#scram}
        */
        readonly scram?: boolean | cdktn.IResolvable;
    }
    class BrokerNodeGroupInfoConnectivityInfoVpcConnectivityClientAuthenticationSaslPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): BrokerNodeGroupInfoConnectivityInfoVpcConnectivityClientAuthenticationSaslProperty | undefined;
        set internalValue(value: BrokerNodeGroupInfoConnectivityInfoVpcConnectivityClientAuthenticationSaslProperty | undefined);
        private _iam?;
        get iam(): boolean | cdktn.IResolvable;
        set iam(value: boolean | cdktn.IResolvable);
        resetIam(): void;
        get iamInput(): boolean | cdktn.IResolvable | undefined;
        private _scram?;
        get scram(): boolean | cdktn.IResolvable;
        set scram(value: boolean | cdktn.IResolvable);
        resetScram(): void;
        get scramInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface BrokerNodeGroupInfoConnectivityInfoVpcConnectivityClientAuthenticationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_cluster#tls AwsCluster#tls}
        */
        readonly tls?: boolean | cdktn.IResolvable;
        /**
        * sasl block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_cluster#sasl AwsCluster#sasl}
        */
        readonly sasl?: BrokerNodeGroupInfoConnectivityInfoVpcConnectivityClientAuthenticationSaslProperty;
    }
    class BrokerNodeGroupInfoConnectivityInfoVpcConnectivityClientAuthenticationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): BrokerNodeGroupInfoConnectivityInfoVpcConnectivityClientAuthenticationProperty | undefined;
        set internalValue(value: BrokerNodeGroupInfoConnectivityInfoVpcConnectivityClientAuthenticationProperty | undefined);
        private _tls?;
        get tls(): boolean | cdktn.IResolvable;
        set tls(value: boolean | cdktn.IResolvable);
        resetTls(): void;
        get tlsInput(): boolean | cdktn.IResolvable | undefined;
        private _sasl;
        get sasl(): BrokerNodeGroupInfoConnectivityInfoVpcConnectivityClientAuthenticationSaslPropertyOutputReference;
        putSasl(value: BrokerNodeGroupInfoConnectivityInfoVpcConnectivityClientAuthenticationSaslProperty): void;
        resetSasl(): void;
        get saslInput(): BrokerNodeGroupInfoConnectivityInfoVpcConnectivityClientAuthenticationSaslProperty | undefined;
    }
    interface VpcConnectivityProperty {
        /**
        * client_authentication block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_cluster#client_authentication AwsCluster#client_authentication}
        */
        readonly clientAuthentication?: BrokerNodeGroupInfoConnectivityInfoVpcConnectivityClientAuthenticationProperty;
    }
    class VpcConnectivityPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): VpcConnectivityProperty | undefined;
        set internalValue(value: VpcConnectivityProperty | undefined);
        private _clientAuthentication;
        get clientAuthentication(): BrokerNodeGroupInfoConnectivityInfoVpcConnectivityClientAuthenticationPropertyOutputReference;
        putClientAuthentication(value: BrokerNodeGroupInfoConnectivityInfoVpcConnectivityClientAuthenticationProperty): void;
        resetClientAuthentication(): void;
        get clientAuthenticationInput(): BrokerNodeGroupInfoConnectivityInfoVpcConnectivityClientAuthenticationProperty | undefined;
    }
    interface ConnectivityInfoProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_cluster#network_type AwsCluster#network_type}
        */
        readonly networkType?: string;
        /**
        * public_access block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_cluster#public_access AwsCluster#public_access}
        */
        readonly publicAccess?: PublicAccessProperty;
        /**
        * vpc_connectivity block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_cluster#vpc_connectivity AwsCluster#vpc_connectivity}
        */
        readonly vpcConnectivity?: VpcConnectivityProperty;
    }
    class ConnectivityInfoPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ConnectivityInfoProperty | undefined;
        set internalValue(value: ConnectivityInfoProperty | undefined);
        private _networkType?;
        get networkType(): string;
        set networkType(value: string);
        resetNetworkType(): void;
        get networkTypeInput(): string | undefined;
        private _publicAccess;
        get publicAccess(): PublicAccessPropertyOutputReference;
        putPublicAccess(value: PublicAccessProperty): void;
        resetPublicAccess(): void;
        get publicAccessInput(): PublicAccessProperty | undefined;
        private _vpcConnectivity;
        get vpcConnectivity(): VpcConnectivityPropertyOutputReference;
        putVpcConnectivity(value: VpcConnectivityProperty): void;
        resetVpcConnectivity(): void;
        get vpcConnectivityInput(): VpcConnectivityProperty | undefined;
    }
    interface ProvisionedThroughputProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_cluster#enabled AwsCluster#enabled}
        */
        readonly enabled?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_cluster#volume_throughput AwsCluster#volume_throughput}
        */
        readonly volumeThroughput?: number;
    }
    class ProvisionedThroughputPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ProvisionedThroughputProperty | undefined;
        set internalValue(value: ProvisionedThroughputProperty | undefined);
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        resetEnabled(): void;
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
        private _volumeThroughput?;
        get volumeThroughput(): number;
        set volumeThroughput(value: number);
        resetVolumeThroughput(): void;
        get volumeThroughputInput(): number | undefined;
    }
    interface EbsStorageInfoProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_cluster#volume_size AwsCluster#volume_size}
        */
        readonly volumeSize?: number;
        /**
        * provisioned_throughput block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_cluster#provisioned_throughput AwsCluster#provisioned_throughput}
        */
        readonly provisionedThroughput?: ProvisionedThroughputProperty;
    }
    class EbsStorageInfoPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): EbsStorageInfoProperty | undefined;
        set internalValue(value: EbsStorageInfoProperty | undefined);
        private _volumeSize?;
        get volumeSize(): number;
        set volumeSize(value: number);
        resetVolumeSize(): void;
        get volumeSizeInput(): number | undefined;
        private _provisionedThroughput;
        get provisionedThroughput(): ProvisionedThroughputPropertyOutputReference;
        putProvisionedThroughput(value: ProvisionedThroughputProperty): void;
        resetProvisionedThroughput(): void;
        get provisionedThroughputInput(): ProvisionedThroughputProperty | undefined;
    }
    interface StorageInfoProperty {
        /**
        * ebs_storage_info block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_cluster#ebs_storage_info AwsCluster#ebs_storage_info}
        */
        readonly ebsStorageInfo?: EbsStorageInfoProperty;
    }
    class StorageInfoPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): StorageInfoProperty | undefined;
        set internalValue(value: StorageInfoProperty | undefined);
        private _ebsStorageInfo;
        get ebsStorageInfo(): EbsStorageInfoPropertyOutputReference;
        putEbsStorageInfo(value: EbsStorageInfoProperty): void;
        resetEbsStorageInfo(): void;
        get ebsStorageInfoInput(): EbsStorageInfoProperty | undefined;
    }
    interface BrokerNodeGroupInfoProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_cluster#az_distribution AwsCluster#az_distribution}
        */
        readonly azDistribution?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_cluster#client_subnets AwsCluster#client_subnets}
        */
        readonly clientSubnets: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_cluster#instance_type AwsCluster#instance_type}
        */
        readonly instanceType: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_cluster#security_groups AwsCluster#security_groups}
        */
        readonly securityGroups: string[];
        /**
        * connectivity_info block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_cluster#connectivity_info AwsCluster#connectivity_info}
        */
        readonly connectivityInfo?: ConnectivityInfoProperty;
        /**
        * storage_info block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_cluster#storage_info AwsCluster#storage_info}
        */
        readonly storageInfo?: StorageInfoProperty;
    }
    class BrokerNodeGroupInfoPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): BrokerNodeGroupInfoProperty | undefined;
        set internalValue(value: BrokerNodeGroupInfoProperty | undefined);
        private _azDistribution?;
        get azDistribution(): string;
        set azDistribution(value: string);
        resetAzDistribution(): void;
        get azDistributionInput(): string | undefined;
        private _clientSubnets?;
        get clientSubnets(): string[];
        set clientSubnets(value: string[]);
        get clientSubnetsInput(): string[] | undefined;
        private _instanceType?;
        get instanceType(): string;
        set instanceType(value: string);
        get instanceTypeInput(): string | undefined;
        private _securityGroups?;
        get securityGroups(): string[];
        set securityGroups(value: string[]);
        get securityGroupsInput(): string[] | undefined;
        private _connectivityInfo;
        get connectivityInfo(): ConnectivityInfoPropertyOutputReference;
        putConnectivityInfo(value: ConnectivityInfoProperty): void;
        resetConnectivityInfo(): void;
        get connectivityInfoInput(): ConnectivityInfoProperty | undefined;
        private _storageInfo;
        get storageInfo(): StorageInfoPropertyOutputReference;
        putStorageInfo(value: StorageInfoProperty): void;
        resetStorageInfo(): void;
        get storageInfoInput(): StorageInfoProperty | undefined;
    }
    interface ClientAuthenticationSaslProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_cluster#iam AwsCluster#iam}
        */
        readonly iam?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_cluster#scram AwsCluster#scram}
        */
        readonly scram?: boolean | cdktn.IResolvable;
    }
    class ClientAuthenticationSaslPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ClientAuthenticationSaslProperty | undefined;
        set internalValue(value: ClientAuthenticationSaslProperty | undefined);
        private _iam?;
        get iam(): boolean | cdktn.IResolvable;
        set iam(value: boolean | cdktn.IResolvable);
        resetIam(): void;
        get iamInput(): boolean | cdktn.IResolvable | undefined;
        private _scram?;
        get scram(): boolean | cdktn.IResolvable;
        set scram(value: boolean | cdktn.IResolvable);
        resetScram(): void;
        get scramInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface TlsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_cluster#certificate_authority_arns AwsCluster#certificate_authority_arns}
        */
        readonly certificateAuthorityArns?: string[];
    }
    class TlsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TlsProperty | undefined;
        set internalValue(value: TlsProperty | undefined);
        private _certificateAuthorityArns?;
        get certificateAuthorityArns(): string[];
        set certificateAuthorityArns(value: string[]);
        resetCertificateAuthorityArns(): void;
        get certificateAuthorityArnsInput(): string[] | undefined;
    }
    interface ClientAuthenticationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_cluster#unauthenticated AwsCluster#unauthenticated}
        */
        readonly unauthenticated?: boolean | cdktn.IResolvable;
        /**
        * sasl block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_cluster#sasl AwsCluster#sasl}
        */
        readonly sasl?: ClientAuthenticationSaslProperty;
        /**
        * tls block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_cluster#tls AwsCluster#tls}
        */
        readonly tls?: TlsProperty;
    }
    class ClientAuthenticationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ClientAuthenticationProperty | undefined;
        set internalValue(value: ClientAuthenticationProperty | undefined);
        private _unauthenticated?;
        get unauthenticated(): boolean | cdktn.IResolvable;
        set unauthenticated(value: boolean | cdktn.IResolvable);
        resetUnauthenticated(): void;
        get unauthenticatedInput(): boolean | cdktn.IResolvable | undefined;
        private _sasl;
        get sasl(): ClientAuthenticationSaslPropertyOutputReference;
        putSasl(value: ClientAuthenticationSaslProperty): void;
        resetSasl(): void;
        get saslInput(): ClientAuthenticationSaslProperty | undefined;
        private _tls;
        get tls(): TlsPropertyOutputReference;
        putTls(value: TlsProperty): void;
        resetTls(): void;
        get tlsInput(): TlsProperty | undefined;
    }
    interface ConfigurationInfoProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_cluster#arn AwsCluster#arn}
        */
        readonly arn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_cluster#revision AwsCluster#revision}
        */
        readonly revision: number;
    }
    class ConfigurationInfoPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ConfigurationInfoProperty | undefined;
        set internalValue(value: ConfigurationInfoProperty | undefined);
        private _arn?;
        get arn(): string;
        set arn(value: string);
        get arnInput(): string | undefined;
        private _revision?;
        get revision(): number;
        set revision(value: number);
        get revisionInput(): number | undefined;
    }
    interface EncryptionInTransitProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_cluster#client_broker AwsCluster#client_broker}
        */
        readonly clientBroker?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_cluster#in_cluster AwsCluster#in_cluster}
        */
        readonly inCluster?: boolean | cdktn.IResolvable;
    }
    class EncryptionInTransitPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): EncryptionInTransitProperty | undefined;
        set internalValue(value: EncryptionInTransitProperty | undefined);
        private _clientBroker?;
        get clientBroker(): string;
        set clientBroker(value: string);
        resetClientBroker(): void;
        get clientBrokerInput(): string | undefined;
        private _inCluster?;
        get inCluster(): boolean | cdktn.IResolvable;
        set inCluster(value: boolean | cdktn.IResolvable);
        resetInCluster(): void;
        get inClusterInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface EncryptionInfoProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_cluster#encryption_at_rest_kms_key_arn AwsCluster#encryption_at_rest_kms_key_arn}
        */
        readonly encryptionAtRestKmsKeyArn?: string;
        /**
        * encryption_in_transit block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_cluster#encryption_in_transit AwsCluster#encryption_in_transit}
        */
        readonly encryptionInTransit?: EncryptionInTransitProperty;
    }
    class EncryptionInfoPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): EncryptionInfoProperty | undefined;
        set internalValue(value: EncryptionInfoProperty | undefined);
        private _encryptionAtRestKmsKeyArn?;
        get encryptionAtRestKmsKeyArn(): string;
        set encryptionAtRestKmsKeyArn(value: string);
        resetEncryptionAtRestKmsKeyArn(): void;
        get encryptionAtRestKmsKeyArnInput(): string | undefined;
        private _encryptionInTransit;
        get encryptionInTransit(): EncryptionInTransitPropertyOutputReference;
        putEncryptionInTransit(value: EncryptionInTransitProperty): void;
        resetEncryptionInTransit(): void;
        get encryptionInTransitInput(): EncryptionInTransitProperty | undefined;
    }
    interface CloudwatchLogsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_cluster#enabled AwsCluster#enabled}
        */
        readonly enabled: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_cluster#log_group AwsCluster#log_group}
        */
        readonly logGroup?: string;
    }
    class CloudwatchLogsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CloudwatchLogsProperty | undefined;
        set internalValue(value: CloudwatchLogsProperty | undefined);
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
        private _logGroup?;
        get logGroup(): string;
        set logGroup(value: string);
        resetLogGroup(): void;
        get logGroupInput(): string | undefined;
    }
    interface FirehoseProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_cluster#delivery_stream AwsCluster#delivery_stream}
        */
        readonly deliveryStream?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_cluster#enabled AwsCluster#enabled}
        */
        readonly enabled: boolean | cdktn.IResolvable;
    }
    class FirehosePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): FirehoseProperty | undefined;
        set internalValue(value: FirehoseProperty | undefined);
        private _deliveryStream?;
        get deliveryStream(): string;
        set deliveryStream(value: string);
        resetDeliveryStream(): void;
        get deliveryStreamInput(): string | undefined;
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface S3Property {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_cluster#bucket AwsCluster#bucket}
        */
        readonly bucket?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_cluster#enabled AwsCluster#enabled}
        */
        readonly enabled: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_cluster#prefix AwsCluster#prefix}
        */
        readonly prefix?: string;
    }
    class S3PropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): S3Property | undefined;
        set internalValue(value: S3Property | undefined);
        private _bucket?;
        get bucket(): string;
        set bucket(value: string);
        resetBucket(): void;
        get bucketInput(): string | undefined;
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
        private _prefix?;
        get prefix(): string;
        set prefix(value: string);
        resetPrefix(): void;
        get prefixInput(): string | undefined;
    }
    interface BrokerLogsProperty {
        /**
        * cloudwatch_logs block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_cluster#cloudwatch_logs AwsCluster#cloudwatch_logs}
        */
        readonly cloudwatchLogs?: CloudwatchLogsProperty;
        /**
        * firehose block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_cluster#firehose AwsCluster#firehose}
        */
        readonly firehose?: FirehoseProperty;
        /**
        * s3 block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_cluster#s3 AwsCluster#s3}
        */
        readonly s3?: S3Property;
    }
    class BrokerLogsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): BrokerLogsProperty | undefined;
        set internalValue(value: BrokerLogsProperty | undefined);
        private _cloudwatchLogs;
        get cloudwatchLogs(): CloudwatchLogsPropertyOutputReference;
        putCloudwatchLogs(value: CloudwatchLogsProperty): void;
        resetCloudwatchLogs(): void;
        get cloudwatchLogsInput(): CloudwatchLogsProperty | undefined;
        private _firehose;
        get firehose(): FirehosePropertyOutputReference;
        putFirehose(value: FirehoseProperty): void;
        resetFirehose(): void;
        get firehoseInput(): FirehoseProperty | undefined;
        private _s3;
        get s3(): S3PropertyOutputReference;
        putS3(value: S3Property): void;
        resetS3(): void;
        get s3Input(): S3Property | undefined;
    }
    interface LoggingInfoProperty {
        /**
        * broker_logs block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_cluster#broker_logs AwsCluster#broker_logs}
        */
        readonly brokerLogs: BrokerLogsProperty;
    }
    class LoggingInfoPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): LoggingInfoProperty | undefined;
        set internalValue(value: LoggingInfoProperty | undefined);
        private _brokerLogs;
        get brokerLogs(): BrokerLogsPropertyOutputReference;
        putBrokerLogs(value: BrokerLogsProperty): void;
        get brokerLogsInput(): BrokerLogsProperty | undefined;
    }
    interface JmxExporterProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_cluster#enabled_in_broker AwsCluster#enabled_in_broker}
        */
        readonly enabledInBroker: boolean | cdktn.IResolvable;
    }
    class JmxExporterPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): JmxExporterProperty | undefined;
        set internalValue(value: JmxExporterProperty | undefined);
        private _enabledInBroker?;
        get enabledInBroker(): boolean | cdktn.IResolvable;
        set enabledInBroker(value: boolean | cdktn.IResolvable);
        get enabledInBrokerInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface NodeExporterProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_cluster#enabled_in_broker AwsCluster#enabled_in_broker}
        */
        readonly enabledInBroker: boolean | cdktn.IResolvable;
    }
    class NodeExporterPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): NodeExporterProperty | undefined;
        set internalValue(value: NodeExporterProperty | undefined);
        private _enabledInBroker?;
        get enabledInBroker(): boolean | cdktn.IResolvable;
        set enabledInBroker(value: boolean | cdktn.IResolvable);
        get enabledInBrokerInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface PrometheusProperty {
        /**
        * jmx_exporter block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_cluster#jmx_exporter AwsCluster#jmx_exporter}
        */
        readonly jmxExporter?: JmxExporterProperty;
        /**
        * node_exporter block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_cluster#node_exporter AwsCluster#node_exporter}
        */
        readonly nodeExporter?: NodeExporterProperty;
    }
    class PrometheusPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): PrometheusProperty | undefined;
        set internalValue(value: PrometheusProperty | undefined);
        private _jmxExporter;
        get jmxExporter(): JmxExporterPropertyOutputReference;
        putJmxExporter(value: JmxExporterProperty): void;
        resetJmxExporter(): void;
        get jmxExporterInput(): JmxExporterProperty | undefined;
        private _nodeExporter;
        get nodeExporter(): NodeExporterPropertyOutputReference;
        putNodeExporter(value: NodeExporterProperty): void;
        resetNodeExporter(): void;
        get nodeExporterInput(): NodeExporterProperty | undefined;
    }
    interface OpenMonitoringProperty {
        /**
        * prometheus block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_cluster#prometheus AwsCluster#prometheus}
        */
        readonly prometheus: PrometheusProperty;
    }
    class OpenMonitoringPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): OpenMonitoringProperty | undefined;
        set internalValue(value: OpenMonitoringProperty | undefined);
        private _prometheus;
        get prometheus(): PrometheusPropertyOutputReference;
        putPrometheus(value: PrometheusProperty): void;
        get prometheusInput(): PrometheusProperty | undefined;
    }
    interface RebalancingProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_cluster#status AwsCluster#status}
        */
        readonly status: string;
    }
    class RebalancingPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RebalancingProperty | undefined;
        set internalValue(value: RebalancingProperty | undefined);
        private _status?;
        get status(): string;
        set status(value: string);
        get statusInput(): string | undefined;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_cluster#create AwsCluster#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_cluster#delete AwsCluster#delete}
        */
        readonly delete?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/msk_cluster#update AwsCluster#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
