import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsBillingViewsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/billing_views#billing_view_types DataAwsBillingViews#billing_view_types}
    */
    readonly billingViewTypes?: string[];
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/billing_views aws_billing_views}
*/
export declare class DataAwsBillingViews extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_billing_views";
    /**
    * Generates CDKTN code for importing a DataAwsBillingViews resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsBillingViews to import
    * @param importFromId The id of the existing DataAwsBillingViews that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/billing_views#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsBillingViews to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/billing_views aws_billing_views} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsBillingViewsConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataAwsBillingViewsConfig);
    private _billingView;
    get billingView(): DataAwsBillingViews.BillingViewPropertyList;
    private _billingViewTypes?;
    get billingViewTypes(): string[];
    set billingViewTypes(value: string[]);
    resetBillingViewTypes(): void;
    get billingViewTypesInput(): string[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataAwsBillingViewsBillingViewPropertyToTerraform(struct?: DataAwsBillingViews.BillingViewProperty): any;
export declare function dataAwsBillingViewsBillingViewPropertyToHclTerraform(struct?: DataAwsBillingViews.BillingViewProperty): any;
export declare namespace DataAwsBillingViews {
    interface BillingViewProperty {
    }
    class BillingViewPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): BillingViewProperty | undefined;
        set internalValue(value: BillingViewProperty | undefined);
        get arn(): string;
        get billingViewType(): string;
        get description(): string;
        get name(): string;
        get ownerAccountId(): string;
    }
    class BillingViewPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): BillingViewPropertyOutputReference;
    }
}
