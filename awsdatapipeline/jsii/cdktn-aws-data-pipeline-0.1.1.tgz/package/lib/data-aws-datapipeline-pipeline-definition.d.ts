import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsDatapipelinePipelineDefinitionConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/datapipeline_pipeline_definition#id DataAwsDatapipelinePipelineDefinition#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/datapipeline_pipeline_definition#pipeline_id DataAwsDatapipelinePipelineDefinition#pipeline_id}
    */
    readonly pipelineId: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/datapipeline_pipeline_definition#region DataAwsDatapipelinePipelineDefinition#region}
    */
    readonly region?: string;
    /**
    * parameter_value block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/datapipeline_pipeline_definition#parameter_value DataAwsDatapipelinePipelineDefinition#parameter_value}
    */
    readonly parameterValue?: DataAwsDatapipelinePipelineDefinition.ParameterValueProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/datapipeline_pipeline_definition aws_datapipeline_pipeline_definition}
*/
export declare class DataAwsDatapipelinePipelineDefinition extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_datapipeline_pipeline_definition";
    /**
    * Generates CDKTN code for importing a DataAwsDatapipelinePipelineDefinition resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsDatapipelinePipelineDefinition to import
    * @param importFromId The id of the existing DataAwsDatapipelinePipelineDefinition that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/datapipeline_pipeline_definition#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsDatapipelinePipelineDefinition to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/datapipeline_pipeline_definition aws_datapipeline_pipeline_definition} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsDatapipelinePipelineDefinitionConfig
    */
    constructor(scope: Construct, id: string, config: DataAwsDatapipelinePipelineDefinitionConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _parameterObject;
    get parameterObject(): DataAwsDatapipelinePipelineDefinition.ParameterObjectPropertyList;
    private _pipelineId?;
    get pipelineId(): string;
    set pipelineId(value: string);
    get pipelineIdInput(): string | undefined;
    private _pipelineObject;
    get pipelineObject(): DataAwsDatapipelinePipelineDefinition.PipelineObjectPropertyList;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _parameterValue;
    get parameterValue(): DataAwsDatapipelinePipelineDefinition.ParameterValuePropertyList;
    putParameterValue(value: DataAwsDatapipelinePipelineDefinition.ParameterValueProperty[] | cdktn.IResolvable): void;
    resetParameterValue(): void;
    get parameterValueInput(): cdktn.IResolvable | DataAwsDatapipelinePipelineDefinition.ParameterValueProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataAwsDatapipelinePipelineDefinitionAttributePropertyToTerraform(struct?: DataAwsDatapipelinePipelineDefinition.AttributeProperty): any;
export declare function dataAwsDatapipelinePipelineDefinitionAttributePropertyToHclTerraform(struct?: DataAwsDatapipelinePipelineDefinition.AttributeProperty): any;
export declare function dataAwsDatapipelinePipelineDefinitionParameterObjectPropertyToTerraform(struct?: DataAwsDatapipelinePipelineDefinition.ParameterObjectProperty): any;
export declare function dataAwsDatapipelinePipelineDefinitionParameterObjectPropertyToHclTerraform(struct?: DataAwsDatapipelinePipelineDefinition.ParameterObjectProperty): any;
export declare function dataAwsDatapipelinePipelineDefinitionFieldPropertyToTerraform(struct?: DataAwsDatapipelinePipelineDefinition.FieldProperty): any;
export declare function dataAwsDatapipelinePipelineDefinitionFieldPropertyToHclTerraform(struct?: DataAwsDatapipelinePipelineDefinition.FieldProperty): any;
export declare function dataAwsDatapipelinePipelineDefinitionPipelineObjectPropertyToTerraform(struct?: DataAwsDatapipelinePipelineDefinition.PipelineObjectProperty): any;
export declare function dataAwsDatapipelinePipelineDefinitionPipelineObjectPropertyToHclTerraform(struct?: DataAwsDatapipelinePipelineDefinition.PipelineObjectProperty): any;
export declare function dataAwsDatapipelinePipelineDefinitionParameterValuePropertyToTerraform(struct?: DataAwsDatapipelinePipelineDefinition.ParameterValueProperty | cdktn.IResolvable): any;
export declare function dataAwsDatapipelinePipelineDefinitionParameterValuePropertyToHclTerraform(struct?: DataAwsDatapipelinePipelineDefinition.ParameterValueProperty | cdktn.IResolvable): any;
export declare namespace DataAwsDatapipelinePipelineDefinition {
    interface AttributeProperty {
    }
    class AttributePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AttributeProperty | undefined;
        set internalValue(value: AttributeProperty | undefined);
        get key(): string;
        get stringValue(): string;
    }
    class AttributePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AttributePropertyOutputReference;
    }
    interface ParameterObjectProperty {
    }
    class ParameterObjectPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ParameterObjectProperty | undefined;
        set internalValue(value: ParameterObjectProperty | undefined);
        private _attribute;
        get attribute(): AttributePropertyList;
        get id(): string;
    }
    class ParameterObjectPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ParameterObjectPropertyOutputReference;
    }
    interface FieldProperty {
    }
    class FieldPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): FieldProperty | undefined;
        set internalValue(value: FieldProperty | undefined);
        get key(): string;
        get refValue(): string;
        get stringValue(): string;
    }
    class FieldPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): FieldPropertyOutputReference;
    }
    interface PipelineObjectProperty {
    }
    class PipelineObjectPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): PipelineObjectProperty | undefined;
        set internalValue(value: PipelineObjectProperty | undefined);
        private _field;
        get field(): FieldPropertyList;
        get id(): string;
        get name(): string;
    }
    class PipelineObjectPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): PipelineObjectPropertyOutputReference;
    }
    interface ParameterValueProperty {
    }
    class ParameterValuePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ParameterValueProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ParameterValueProperty | cdktn.IResolvable | undefined);
        get id(): string;
        get stringValue(): string;
    }
    class ParameterValuePropertyList extends cdktn.ComplexList {
        internalValue?: ParameterValueProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ParameterValuePropertyOutputReference;
    }
}
