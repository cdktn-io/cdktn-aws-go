import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsCustomKeyStoreConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kms_custom_key_store#cloud_hsm_cluster_id AwsCustomKeyStore#cloud_hsm_cluster_id}
    */
    readonly cloudHsmClusterId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kms_custom_key_store#custom_key_store_name AwsCustomKeyStore#custom_key_store_name}
    */
    readonly customKeyStoreName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kms_custom_key_store#custom_key_store_type AwsCustomKeyStore#custom_key_store_type}
    */
    readonly customKeyStoreType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kms_custom_key_store#id AwsCustomKeyStore#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kms_custom_key_store#key_store_password AwsCustomKeyStore#key_store_password}
    */
    readonly keyStorePassword?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kms_custom_key_store#region AwsCustomKeyStore#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kms_custom_key_store#trust_anchor_certificate AwsCustomKeyStore#trust_anchor_certificate}
    */
    readonly trustAnchorCertificate?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kms_custom_key_store#xks_proxy_connectivity AwsCustomKeyStore#xks_proxy_connectivity}
    */
    readonly xksProxyConnectivity?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kms_custom_key_store#xks_proxy_uri_endpoint AwsCustomKeyStore#xks_proxy_uri_endpoint}
    */
    readonly xksProxyUriEndpoint?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kms_custom_key_store#xks_proxy_uri_path AwsCustomKeyStore#xks_proxy_uri_path}
    */
    readonly xksProxyUriPath?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kms_custom_key_store#xks_proxy_vpc_endpoint_service_name AwsCustomKeyStore#xks_proxy_vpc_endpoint_service_name}
    */
    readonly xksProxyVpcEndpointServiceName?: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kms_custom_key_store#timeouts AwsCustomKeyStore#timeouts}
    */
    readonly timeouts?: AwsCustomKeyStore.TimeoutsProperty;
    /**
    * xks_proxy_authentication_credential block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kms_custom_key_store#xks_proxy_authentication_credential AwsCustomKeyStore#xks_proxy_authentication_credential}
    */
    readonly xksProxyAuthenticationCredential?: AwsCustomKeyStore.XksProxyAuthenticationCredentialProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kms_custom_key_store aws_kms_custom_key_store}
*/
export declare class AwsCustomKeyStore extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_kms_custom_key_store";
    /**
    * Generates CDKTN code for importing a AwsCustomKeyStore resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsCustomKeyStore to import
    * @param importFromId The id of the existing AwsCustomKeyStore that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kms_custom_key_store#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsCustomKeyStore to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kms_custom_key_store aws_kms_custom_key_store} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsCustomKeyStoreConfig
    */
    constructor(scope: Construct, id: string, config: AwsCustomKeyStoreConfig);
    private _cloudHsmClusterId?;
    get cloudHsmClusterId(): string;
    set cloudHsmClusterId(value: string);
    resetCloudHsmClusterId(): void;
    get cloudHsmClusterIdInput(): string | undefined;
    private _customKeyStoreName?;
    get customKeyStoreName(): string;
    set customKeyStoreName(value: string);
    get customKeyStoreNameInput(): string | undefined;
    private _customKeyStoreType?;
    get customKeyStoreType(): string;
    set customKeyStoreType(value: string);
    resetCustomKeyStoreType(): void;
    get customKeyStoreTypeInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _keyStorePassword?;
    get keyStorePassword(): string;
    set keyStorePassword(value: string);
    resetKeyStorePassword(): void;
    get keyStorePasswordInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _trustAnchorCertificate?;
    get trustAnchorCertificate(): string;
    set trustAnchorCertificate(value: string);
    resetTrustAnchorCertificate(): void;
    get trustAnchorCertificateInput(): string | undefined;
    private _xksProxyConnectivity?;
    get xksProxyConnectivity(): string;
    set xksProxyConnectivity(value: string);
    resetXksProxyConnectivity(): void;
    get xksProxyConnectivityInput(): string | undefined;
    private _xksProxyUriEndpoint?;
    get xksProxyUriEndpoint(): string;
    set xksProxyUriEndpoint(value: string);
    resetXksProxyUriEndpoint(): void;
    get xksProxyUriEndpointInput(): string | undefined;
    private _xksProxyUriPath?;
    get xksProxyUriPath(): string;
    set xksProxyUriPath(value: string);
    resetXksProxyUriPath(): void;
    get xksProxyUriPathInput(): string | undefined;
    private _xksProxyVpcEndpointServiceName?;
    get xksProxyVpcEndpointServiceName(): string;
    set xksProxyVpcEndpointServiceName(value: string);
    resetXksProxyVpcEndpointServiceName(): void;
    get xksProxyVpcEndpointServiceNameInput(): string | undefined;
    private _timeouts;
    get timeouts(): AwsCustomKeyStore.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsCustomKeyStore.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): AwsCustomKeyStore.TimeoutsProperty | cdktn.IResolvable | undefined;
    private _xksProxyAuthenticationCredential;
    get xksProxyAuthenticationCredential(): AwsCustomKeyStore.XksProxyAuthenticationCredentialPropertyOutputReference;
    putXksProxyAuthenticationCredential(value: AwsCustomKeyStore.XksProxyAuthenticationCredentialProperty): void;
    resetXksProxyAuthenticationCredential(): void;
    get xksProxyAuthenticationCredentialInput(): AwsCustomKeyStore.XksProxyAuthenticationCredentialProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsCustomKeyStoreTimeoutsPropertyToTerraform(struct?: AwsCustomKeyStore.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsCustomKeyStoreTimeoutsPropertyToHclTerraform(struct?: AwsCustomKeyStore.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsCustomKeyStoreXksProxyAuthenticationCredentialPropertyToTerraform(struct?: AwsCustomKeyStore.XksProxyAuthenticationCredentialPropertyOutputReference | AwsCustomKeyStore.XksProxyAuthenticationCredentialProperty): any;
export declare function awsCustomKeyStoreXksProxyAuthenticationCredentialPropertyToHclTerraform(struct?: AwsCustomKeyStore.XksProxyAuthenticationCredentialPropertyOutputReference | AwsCustomKeyStore.XksProxyAuthenticationCredentialProperty): any;
export declare namespace AwsCustomKeyStore {
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kms_custom_key_store#create AwsCustomKeyStore#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kms_custom_key_store#delete AwsCustomKeyStore#delete}
        */
        readonly delete?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kms_custom_key_store#update AwsCustomKeyStore#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
    interface XksProxyAuthenticationCredentialProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kms_custom_key_store#access_key_id AwsCustomKeyStore#access_key_id}
        */
        readonly accessKeyId: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kms_custom_key_store#raw_secret_access_key AwsCustomKeyStore#raw_secret_access_key}
        */
        readonly rawSecretAccessKey: string;
    }
    class XksProxyAuthenticationCredentialPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): XksProxyAuthenticationCredentialProperty | undefined;
        set internalValue(value: XksProxyAuthenticationCredentialProperty | undefined);
        private _accessKeyId?;
        get accessKeyId(): string;
        set accessKeyId(value: string);
        get accessKeyIdInput(): string | undefined;
        private _rawSecretAccessKey?;
        get rawSecretAccessKey(): string;
        set rawSecretAccessKey(value: string);
        get rawSecretAccessKeyInput(): string | undefined;
    }
}
