import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsKeyConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/kms_key#grant_tokens DataAwsKey#grant_tokens}
    */
    readonly grantTokens?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/kms_key#id DataAwsKey#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/kms_key#key_id DataAwsKey#key_id}
    */
    readonly keyId: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/kms_key#region DataAwsKey#region}
    */
    readonly region?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/kms_key aws_kms_key}
*/
export declare class DataAwsKey extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_kms_key";
    /**
    * Generates CDKTN code for importing a DataAwsKey resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsKey to import
    * @param importFromId The id of the existing DataAwsKey that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/kms_key#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsKey to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/kms_key aws_kms_key} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsKeyConfig
    */
    constructor(scope: Construct, id: string, config: DataAwsKeyConfig);
    get arn(): string;
    get awsAccountId(): string;
    get cloudHsmClusterId(): string;
    get creationDate(): string;
    get customKeyStoreId(): string;
    get customerMasterKeySpec(): string;
    get deletionDate(): string;
    get description(): string;
    get enabled(): cdktn.IResolvable;
    get expirationModel(): string;
    private _grantTokens?;
    get grantTokens(): string[];
    set grantTokens(value: string[]);
    resetGrantTokens(): void;
    get grantTokensInput(): string[] | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _keyId?;
    get keyId(): string;
    set keyId(value: string);
    get keyIdInput(): string | undefined;
    get keyManager(): string;
    get keySpec(): string;
    get keyState(): string;
    get keyUsage(): string;
    get multiRegion(): cdktn.IResolvable;
    private _multiRegionConfiguration;
    get multiRegionConfiguration(): DataAwsKey.MultiRegionConfigurationPropertyList;
    get origin(): string;
    get pendingDeletionWindowInDays(): number;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get validTo(): string;
    private _xksKeyConfiguration;
    get xksKeyConfiguration(): DataAwsKey.XksKeyConfigurationPropertyList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataAwsKeyPrimaryKeyPropertyToTerraform(struct?: DataAwsKey.PrimaryKeyProperty): any;
export declare function dataAwsKeyPrimaryKeyPropertyToHclTerraform(struct?: DataAwsKey.PrimaryKeyProperty): any;
export declare function dataAwsKeyReplicaKeysPropertyToTerraform(struct?: DataAwsKey.ReplicaKeysProperty): any;
export declare function dataAwsKeyReplicaKeysPropertyToHclTerraform(struct?: DataAwsKey.ReplicaKeysProperty): any;
export declare function dataAwsKeyMultiRegionConfigurationPropertyToTerraform(struct?: DataAwsKey.MultiRegionConfigurationProperty): any;
export declare function dataAwsKeyMultiRegionConfigurationPropertyToHclTerraform(struct?: DataAwsKey.MultiRegionConfigurationProperty): any;
export declare function dataAwsKeyXksKeyConfigurationPropertyToTerraform(struct?: DataAwsKey.XksKeyConfigurationProperty): any;
export declare function dataAwsKeyXksKeyConfigurationPropertyToHclTerraform(struct?: DataAwsKey.XksKeyConfigurationProperty): any;
export declare namespace DataAwsKey {
    interface PrimaryKeyProperty {
    }
    class PrimaryKeyPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): PrimaryKeyProperty | undefined;
        set internalValue(value: PrimaryKeyProperty | undefined);
        get arn(): string;
        get region(): string;
    }
    class PrimaryKeyPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): PrimaryKeyPropertyOutputReference;
    }
    interface ReplicaKeysProperty {
    }
    class ReplicaKeysPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ReplicaKeysProperty | undefined;
        set internalValue(value: ReplicaKeysProperty | undefined);
        get arn(): string;
        get region(): string;
    }
    class ReplicaKeysPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ReplicaKeysPropertyOutputReference;
    }
    interface MultiRegionConfigurationProperty {
    }
    class MultiRegionConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): MultiRegionConfigurationProperty | undefined;
        set internalValue(value: MultiRegionConfigurationProperty | undefined);
        get multiRegionKeyType(): string;
        private _primaryKey;
        get primaryKey(): PrimaryKeyPropertyList;
        private _replicaKeys;
        get replicaKeys(): ReplicaKeysPropertyList;
    }
    class MultiRegionConfigurationPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): MultiRegionConfigurationPropertyOutputReference;
    }
    interface XksKeyConfigurationProperty {
    }
    class XksKeyConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): XksKeyConfigurationProperty | undefined;
        set internalValue(value: XksKeyConfigurationProperty | undefined);
        get id(): string;
    }
    class XksKeyConfigurationPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): XksKeyConfigurationPropertyOutputReference;
    }
}
