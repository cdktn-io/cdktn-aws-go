import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsKeyspacesKeyspaceConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/keyspaces_keyspace#id AwsKeyspacesKeyspace#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/keyspaces_keyspace#name AwsKeyspacesKeyspace#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/keyspaces_keyspace#region AwsKeyspacesKeyspace#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/keyspaces_keyspace#tags AwsKeyspacesKeyspace#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/keyspaces_keyspace#tags_all AwsKeyspacesKeyspace#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * replication_specification block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/keyspaces_keyspace#replication_specification AwsKeyspacesKeyspace#replication_specification}
    */
    readonly replicationSpecification?: AwsKeyspacesKeyspace.ReplicationSpecificationProperty;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/keyspaces_keyspace#timeouts AwsKeyspacesKeyspace#timeouts}
    */
    readonly timeouts?: AwsKeyspacesKeyspace.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/keyspaces_keyspace aws_keyspaces_keyspace}
*/
export declare class AwsKeyspacesKeyspace extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_keyspaces_keyspace";
    /**
    * Generates CDKTN code for importing a AwsKeyspacesKeyspace resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsKeyspacesKeyspace to import
    * @param importFromId The id of the existing AwsKeyspacesKeyspace that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/keyspaces_keyspace#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsKeyspacesKeyspace to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/keyspaces_keyspace aws_keyspaces_keyspace} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsKeyspacesKeyspaceConfig
    */
    constructor(scope: Construct, id: string, config: AwsKeyspacesKeyspaceConfig);
    get arn(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _replicationSpecification;
    get replicationSpecification(): AwsKeyspacesKeyspace.ReplicationSpecificationPropertyOutputReference;
    putReplicationSpecification(value: AwsKeyspacesKeyspace.ReplicationSpecificationProperty): void;
    resetReplicationSpecification(): void;
    get replicationSpecificationInput(): AwsKeyspacesKeyspace.ReplicationSpecificationProperty | undefined;
    private _timeouts;
    get timeouts(): AwsKeyspacesKeyspace.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsKeyspacesKeyspace.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): AwsKeyspacesKeyspace.TimeoutsProperty | cdktn.IResolvable | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsKeyspacesKeyspaceReplicationSpecificationPropertyToTerraform(struct?: AwsKeyspacesKeyspace.ReplicationSpecificationPropertyOutputReference | AwsKeyspacesKeyspace.ReplicationSpecificationProperty): any;
export declare function awsKeyspacesKeyspaceReplicationSpecificationPropertyToHclTerraform(struct?: AwsKeyspacesKeyspace.ReplicationSpecificationPropertyOutputReference | AwsKeyspacesKeyspace.ReplicationSpecificationProperty): any;
export declare function awsKeyspacesKeyspaceTimeoutsPropertyToTerraform(struct?: AwsKeyspacesKeyspace.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsKeyspacesKeyspaceTimeoutsPropertyToHclTerraform(struct?: AwsKeyspacesKeyspace.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsKeyspacesKeyspace {
    interface ReplicationSpecificationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/keyspaces_keyspace#region_list AwsKeyspacesKeyspace#region_list}
        */
        readonly regionList?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/keyspaces_keyspace#replication_strategy AwsKeyspacesKeyspace#replication_strategy}
        */
        readonly replicationStrategy?: string;
    }
    class ReplicationSpecificationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ReplicationSpecificationProperty | undefined;
        set internalValue(value: ReplicationSpecificationProperty | undefined);
        private _regionList?;
        get regionList(): string[];
        set regionList(value: string[]);
        resetRegionList(): void;
        get regionListInput(): string[] | undefined;
        private _replicationStrategy?;
        get replicationStrategy(): string;
        set replicationStrategy(value: string);
        resetReplicationStrategy(): void;
        get replicationStrategyInput(): string | undefined;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/keyspaces_keyspace#create AwsKeyspacesKeyspace#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/keyspaces_keyspace#delete AwsKeyspacesKeyspace#delete}
        */
        readonly delete?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
    }
}
