import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfTableConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/keyspaces_table#default_time_to_live TfTable#default_time_to_live}
    */
    readonly defaultTimeToLive?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/keyspaces_table#id TfTable#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/keyspaces_table#keyspace_name TfTable#keyspace_name}
    */
    readonly keyspaceName: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/keyspaces_table#region TfTable#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/keyspaces_table#table_name TfTable#table_name}
    */
    readonly tableName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/keyspaces_table#tags TfTable#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/keyspaces_table#tags_all TfTable#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * capacity_specification block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/keyspaces_table#capacity_specification TfTable#capacity_specification}
    */
    readonly capacitySpecification?: TfTable.CapacitySpecificationProperty;
    /**
    * client_side_timestamps block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/keyspaces_table#client_side_timestamps TfTable#client_side_timestamps}
    */
    readonly clientSideTimestamps?: TfTable.ClientSideTimestampsProperty;
    /**
    * comment block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/keyspaces_table#comment TfTable#comment}
    */
    readonly comment?: TfTable.CommentProperty;
    /**
    * encryption_specification block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/keyspaces_table#encryption_specification TfTable#encryption_specification}
    */
    readonly encryptionSpecification?: TfTable.EncryptionSpecificationProperty;
    /**
    * point_in_time_recovery block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/keyspaces_table#point_in_time_recovery TfTable#point_in_time_recovery}
    */
    readonly pointInTimeRecovery?: TfTable.PointInTimeRecoveryProperty;
    /**
    * schema_definition block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/keyspaces_table#schema_definition TfTable#schema_definition}
    */
    readonly schemaDefinition: TfTable.SchemaDefinitionProperty;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/keyspaces_table#timeouts TfTable#timeouts}
    */
    readonly timeouts?: TfTable.TimeoutsProperty;
    /**
    * ttl block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/keyspaces_table#ttl TfTable#ttl}
    */
    readonly ttl?: TfTable.TtlProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/keyspaces_table aws_keyspaces_table}
*/
export declare class TfTable extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_keyspaces_table";
    /**
    * Generates CDKTN code for importing a TfTable resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfTable to import
    * @param importFromId The id of the existing TfTable that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/keyspaces_table#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfTable to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/keyspaces_table aws_keyspaces_table} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfTableConfig
    */
    constructor(scope: Construct, id: string, config: TfTableConfig);
    get arn(): string;
    private _defaultTimeToLive?;
    get defaultTimeToLive(): number;
    set defaultTimeToLive(value: number);
    resetDefaultTimeToLive(): void;
    get defaultTimeToLiveInput(): number | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _keyspaceName?;
    get keyspaceName(): string;
    set keyspaceName(value: string);
    get keyspaceNameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tableName?;
    get tableName(): string;
    set tableName(value: string);
    get tableNameInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _capacitySpecification;
    get capacitySpecification(): TfTable.CapacitySpecificationPropertyOutputReference;
    putCapacitySpecification(value: TfTable.CapacitySpecificationProperty): void;
    resetCapacitySpecification(): void;
    get capacitySpecificationInput(): TfTable.CapacitySpecificationProperty | undefined;
    private _clientSideTimestamps;
    get clientSideTimestamps(): TfTable.ClientSideTimestampsPropertyOutputReference;
    putClientSideTimestamps(value: TfTable.ClientSideTimestampsProperty): void;
    resetClientSideTimestamps(): void;
    get clientSideTimestampsInput(): TfTable.ClientSideTimestampsProperty | undefined;
    private _comment;
    get comment(): TfTable.CommentPropertyOutputReference;
    putComment(value: TfTable.CommentProperty): void;
    resetComment(): void;
    get commentInput(): TfTable.CommentProperty | undefined;
    private _encryptionSpecification;
    get encryptionSpecification(): TfTable.EncryptionSpecificationPropertyOutputReference;
    putEncryptionSpecification(value: TfTable.EncryptionSpecificationProperty): void;
    resetEncryptionSpecification(): void;
    get encryptionSpecificationInput(): TfTable.EncryptionSpecificationProperty | undefined;
    private _pointInTimeRecovery;
    get pointInTimeRecovery(): TfTable.PointInTimeRecoveryPropertyOutputReference;
    putPointInTimeRecovery(value: TfTable.PointInTimeRecoveryProperty): void;
    resetPointInTimeRecovery(): void;
    get pointInTimeRecoveryInput(): TfTable.PointInTimeRecoveryProperty | undefined;
    private _schemaDefinition;
    get schemaDefinition(): TfTable.SchemaDefinitionPropertyOutputReference;
    putSchemaDefinition(value: TfTable.SchemaDefinitionProperty): void;
    get schemaDefinitionInput(): TfTable.SchemaDefinitionProperty | undefined;
    private _timeouts;
    get timeouts(): TfTable.TimeoutsPropertyOutputReference;
    putTimeouts(value: TfTable.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | TfTable.TimeoutsProperty | undefined;
    private _ttl;
    get ttl(): TfTable.TtlPropertyOutputReference;
    putTtl(value: TfTable.TtlProperty): void;
    resetTtl(): void;
    get ttlInput(): TfTable.TtlProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfTableCapacitySpecificationPropertyToTerraform(struct?: TfTable.CapacitySpecificationPropertyOutputReference | TfTable.CapacitySpecificationProperty): any;
export declare function tfTableCapacitySpecificationPropertyToHclTerraform(struct?: TfTable.CapacitySpecificationPropertyOutputReference | TfTable.CapacitySpecificationProperty): any;
export declare function tfTableClientSideTimestampsPropertyToTerraform(struct?: TfTable.ClientSideTimestampsPropertyOutputReference | TfTable.ClientSideTimestampsProperty): any;
export declare function tfTableClientSideTimestampsPropertyToHclTerraform(struct?: TfTable.ClientSideTimestampsPropertyOutputReference | TfTable.ClientSideTimestampsProperty): any;
export declare function tfTableCommentPropertyToTerraform(struct?: TfTable.CommentPropertyOutputReference | TfTable.CommentProperty): any;
export declare function tfTableCommentPropertyToHclTerraform(struct?: TfTable.CommentPropertyOutputReference | TfTable.CommentProperty): any;
export declare function tfTableEncryptionSpecificationPropertyToTerraform(struct?: TfTable.EncryptionSpecificationPropertyOutputReference | TfTable.EncryptionSpecificationProperty): any;
export declare function tfTableEncryptionSpecificationPropertyToHclTerraform(struct?: TfTable.EncryptionSpecificationPropertyOutputReference | TfTable.EncryptionSpecificationProperty): any;
export declare function tfTablePointInTimeRecoveryPropertyToTerraform(struct?: TfTable.PointInTimeRecoveryPropertyOutputReference | TfTable.PointInTimeRecoveryProperty): any;
export declare function tfTablePointInTimeRecoveryPropertyToHclTerraform(struct?: TfTable.PointInTimeRecoveryPropertyOutputReference | TfTable.PointInTimeRecoveryProperty): any;
export declare function tfTableClusteringKeyPropertyToTerraform(struct?: TfTable.ClusteringKeyProperty | cdktn.IResolvable): any;
export declare function tfTableClusteringKeyPropertyToHclTerraform(struct?: TfTable.ClusteringKeyProperty | cdktn.IResolvable): any;
export declare function tfTableColumnPropertyToTerraform(struct?: TfTable.ColumnProperty | cdktn.IResolvable): any;
export declare function tfTableColumnPropertyToHclTerraform(struct?: TfTable.ColumnProperty | cdktn.IResolvable): any;
export declare function tfTablePartitionKeyPropertyToTerraform(struct?: TfTable.PartitionKeyProperty | cdktn.IResolvable): any;
export declare function tfTablePartitionKeyPropertyToHclTerraform(struct?: TfTable.PartitionKeyProperty | cdktn.IResolvable): any;
export declare function tfTableStaticColumnPropertyToTerraform(struct?: TfTable.StaticColumnProperty | cdktn.IResolvable): any;
export declare function tfTableStaticColumnPropertyToHclTerraform(struct?: TfTable.StaticColumnProperty | cdktn.IResolvable): any;
export declare function tfTableSchemaDefinitionPropertyToTerraform(struct?: TfTable.SchemaDefinitionPropertyOutputReference | TfTable.SchemaDefinitionProperty): any;
export declare function tfTableSchemaDefinitionPropertyToHclTerraform(struct?: TfTable.SchemaDefinitionPropertyOutputReference | TfTable.SchemaDefinitionProperty): any;
export declare function tfTableTimeoutsPropertyToTerraform(struct?: TfTable.TimeoutsProperty | cdktn.IResolvable): any;
export declare function tfTableTimeoutsPropertyToHclTerraform(struct?: TfTable.TimeoutsProperty | cdktn.IResolvable): any;
export declare function tfTableTtlPropertyToTerraform(struct?: TfTable.TtlPropertyOutputReference | TfTable.TtlProperty): any;
export declare function tfTableTtlPropertyToHclTerraform(struct?: TfTable.TtlPropertyOutputReference | TfTable.TtlProperty): any;
export declare namespace TfTable {
    interface CapacitySpecificationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/keyspaces_table#read_capacity_units TfTable#read_capacity_units}
        */
        readonly readCapacityUnits?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/keyspaces_table#throughput_mode TfTable#throughput_mode}
        */
        readonly throughputMode?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/keyspaces_table#write_capacity_units TfTable#write_capacity_units}
        */
        readonly writeCapacityUnits?: number;
    }
    class CapacitySpecificationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CapacitySpecificationProperty | undefined;
        set internalValue(value: CapacitySpecificationProperty | undefined);
        private _readCapacityUnits?;
        get readCapacityUnits(): number;
        set readCapacityUnits(value: number);
        resetReadCapacityUnits(): void;
        get readCapacityUnitsInput(): number | undefined;
        private _throughputMode?;
        get throughputMode(): string;
        set throughputMode(value: string);
        resetThroughputMode(): void;
        get throughputModeInput(): string | undefined;
        private _writeCapacityUnits?;
        get writeCapacityUnits(): number;
        set writeCapacityUnits(value: number);
        resetWriteCapacityUnits(): void;
        get writeCapacityUnitsInput(): number | undefined;
    }
    interface ClientSideTimestampsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/keyspaces_table#status TfTable#status}
        */
        readonly status: string;
    }
    class ClientSideTimestampsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ClientSideTimestampsProperty | undefined;
        set internalValue(value: ClientSideTimestampsProperty | undefined);
        private _status?;
        get status(): string;
        set status(value: string);
        get statusInput(): string | undefined;
    }
    interface CommentProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/keyspaces_table#message TfTable#message}
        */
        readonly message?: string;
    }
    class CommentPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CommentProperty | undefined;
        set internalValue(value: CommentProperty | undefined);
        private _message?;
        get message(): string;
        set message(value: string);
        resetMessage(): void;
        get messageInput(): string | undefined;
    }
    interface EncryptionSpecificationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/keyspaces_table#kms_key_identifier TfTable#kms_key_identifier}
        */
        readonly kmsKeyIdentifier?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/keyspaces_table#type TfTable#type}
        */
        readonly type?: string;
    }
    class EncryptionSpecificationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): EncryptionSpecificationProperty | undefined;
        set internalValue(value: EncryptionSpecificationProperty | undefined);
        private _kmsKeyIdentifier?;
        get kmsKeyIdentifier(): string;
        set kmsKeyIdentifier(value: string);
        resetKmsKeyIdentifier(): void;
        get kmsKeyIdentifierInput(): string | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        resetType(): void;
        get typeInput(): string | undefined;
    }
    interface PointInTimeRecoveryProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/keyspaces_table#status TfTable#status}
        */
        readonly status?: string;
    }
    class PointInTimeRecoveryPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): PointInTimeRecoveryProperty | undefined;
        set internalValue(value: PointInTimeRecoveryProperty | undefined);
        private _status?;
        get status(): string;
        set status(value: string);
        resetStatus(): void;
        get statusInput(): string | undefined;
    }
    interface ClusteringKeyProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/keyspaces_table#name TfTable#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/keyspaces_table#order_by TfTable#order_by}
        */
        readonly orderBy: string;
    }
    class ClusteringKeyPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ClusteringKeyProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ClusteringKeyProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _orderBy?;
        get orderBy(): string;
        set orderBy(value: string);
        get orderByInput(): string | undefined;
    }
    class ClusteringKeyPropertyList extends cdktn.ComplexList {
        internalValue?: ClusteringKeyProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ClusteringKeyPropertyOutputReference;
    }
    interface ColumnProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/keyspaces_table#name TfTable#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/keyspaces_table#type TfTable#type}
        */
        readonly type: string;
    }
    class ColumnPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ColumnProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ColumnProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
    }
    class ColumnPropertyList extends cdktn.ComplexList {
        internalValue?: ColumnProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ColumnPropertyOutputReference;
    }
    interface PartitionKeyProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/keyspaces_table#name TfTable#name}
        */
        readonly name: string;
    }
    class PartitionKeyPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): PartitionKeyProperty | cdktn.IResolvable | undefined;
        set internalValue(value: PartitionKeyProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
    }
    class PartitionKeyPropertyList extends cdktn.ComplexList {
        internalValue?: PartitionKeyProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): PartitionKeyPropertyOutputReference;
    }
    interface StaticColumnProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/keyspaces_table#name TfTable#name}
        */
        readonly name: string;
    }
    class StaticColumnPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): StaticColumnProperty | cdktn.IResolvable | undefined;
        set internalValue(value: StaticColumnProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
    }
    class StaticColumnPropertyList extends cdktn.ComplexList {
        internalValue?: StaticColumnProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): StaticColumnPropertyOutputReference;
    }
    interface SchemaDefinitionProperty {
        /**
        * clustering_key block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/keyspaces_table#clustering_key TfTable#clustering_key}
        */
        readonly clusteringKey?: ClusteringKeyProperty[] | cdktn.IResolvable;
        /**
        * column block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/keyspaces_table#column TfTable#column}
        */
        readonly column: ColumnProperty[] | cdktn.IResolvable;
        /**
        * partition_key block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/keyspaces_table#partition_key TfTable#partition_key}
        */
        readonly partitionKey: PartitionKeyProperty[] | cdktn.IResolvable;
        /**
        * static_column block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/keyspaces_table#static_column TfTable#static_column}
        */
        readonly staticColumn?: StaticColumnProperty[] | cdktn.IResolvable;
    }
    class SchemaDefinitionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SchemaDefinitionProperty | undefined;
        set internalValue(value: SchemaDefinitionProperty | undefined);
        private _clusteringKey;
        get clusteringKey(): ClusteringKeyPropertyList;
        putClusteringKey(value: ClusteringKeyProperty[] | cdktn.IResolvable): void;
        resetClusteringKey(): void;
        get clusteringKeyInput(): cdktn.IResolvable | ClusteringKeyProperty[] | undefined;
        private _column;
        get column(): ColumnPropertyList;
        putColumn(value: ColumnProperty[] | cdktn.IResolvable): void;
        get columnInput(): cdktn.IResolvable | ColumnProperty[] | undefined;
        private _partitionKey;
        get partitionKey(): PartitionKeyPropertyList;
        putPartitionKey(value: PartitionKeyProperty[] | cdktn.IResolvable): void;
        get partitionKeyInput(): cdktn.IResolvable | PartitionKeyProperty[] | undefined;
        private _staticColumn;
        get staticColumn(): StaticColumnPropertyList;
        putStaticColumn(value: StaticColumnProperty[] | cdktn.IResolvable): void;
        resetStaticColumn(): void;
        get staticColumnInput(): cdktn.IResolvable | StaticColumnProperty[] | undefined;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/keyspaces_table#create TfTable#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/keyspaces_table#delete TfTable#delete}
        */
        readonly delete?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/keyspaces_table#update TfTable#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
    interface TtlProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/keyspaces_table#status TfTable#status}
        */
        readonly status: string;
    }
    class TtlPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TtlProperty | undefined;
        set internalValue(value: TtlProperty | undefined);
        private _status?;
        get status(): string;
        set status(value: string);
        get statusInput(): string | undefined;
    }
}
