import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsFsxWindowsFileSystemConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_windows_file_system#active_directory_id AwsFsxWindowsFileSystem#active_directory_id}
    */
    readonly activeDirectoryId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_windows_file_system#aliases AwsFsxWindowsFileSystem#aliases}
    */
    readonly aliases?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_windows_file_system#automatic_backup_retention_days AwsFsxWindowsFileSystem#automatic_backup_retention_days}
    */
    readonly automaticBackupRetentionDays?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_windows_file_system#backup_id AwsFsxWindowsFileSystem#backup_id}
    */
    readonly backupId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_windows_file_system#copy_tags_to_backups AwsFsxWindowsFileSystem#copy_tags_to_backups}
    */
    readonly copyTagsToBackups?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_windows_file_system#daily_automatic_backup_start_time AwsFsxWindowsFileSystem#daily_automatic_backup_start_time}
    */
    readonly dailyAutomaticBackupStartTime?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_windows_file_system#deployment_type AwsFsxWindowsFileSystem#deployment_type}
    */
    readonly deploymentType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_windows_file_system#final_backup_tags AwsFsxWindowsFileSystem#final_backup_tags}
    */
    readonly finalBackupTags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_windows_file_system#id AwsFsxWindowsFileSystem#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_windows_file_system#kms_key_id AwsFsxWindowsFileSystem#kms_key_id}
    */
    readonly kmsKeyId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_windows_file_system#network_type AwsFsxWindowsFileSystem#network_type}
    */
    readonly networkType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_windows_file_system#preferred_subnet_id AwsFsxWindowsFileSystem#preferred_subnet_id}
    */
    readonly preferredSubnetId?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_windows_file_system#region AwsFsxWindowsFileSystem#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_windows_file_system#security_group_ids AwsFsxWindowsFileSystem#security_group_ids}
    */
    readonly securityGroupIds?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_windows_file_system#skip_final_backup AwsFsxWindowsFileSystem#skip_final_backup}
    */
    readonly skipFinalBackup?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_windows_file_system#storage_capacity AwsFsxWindowsFileSystem#storage_capacity}
    */
    readonly storageCapacity?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_windows_file_system#storage_type AwsFsxWindowsFileSystem#storage_type}
    */
    readonly storageType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_windows_file_system#subnet_ids AwsFsxWindowsFileSystem#subnet_ids}
    */
    readonly subnetIds: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_windows_file_system#tags AwsFsxWindowsFileSystem#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_windows_file_system#tags_all AwsFsxWindowsFileSystem#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_windows_file_system#throughput_capacity AwsFsxWindowsFileSystem#throughput_capacity}
    */
    readonly throughputCapacity: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_windows_file_system#weekly_maintenance_start_time AwsFsxWindowsFileSystem#weekly_maintenance_start_time}
    */
    readonly weeklyMaintenanceStartTime?: string;
    /**
    * audit_log_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_windows_file_system#audit_log_configuration AwsFsxWindowsFileSystem#audit_log_configuration}
    */
    readonly auditLogConfiguration?: AwsFsxWindowsFileSystem.AuditLogConfigurationProperty;
    /**
    * disk_iops_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_windows_file_system#disk_iops_configuration AwsFsxWindowsFileSystem#disk_iops_configuration}
    */
    readonly diskIopsConfiguration?: AwsFsxWindowsFileSystem.DiskIopsConfigurationProperty;
    /**
    * self_managed_active_directory block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_windows_file_system#self_managed_active_directory AwsFsxWindowsFileSystem#self_managed_active_directory}
    */
    readonly selfManagedActiveDirectory?: AwsFsxWindowsFileSystem.SelfManagedActiveDirectoryProperty;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_windows_file_system#timeouts AwsFsxWindowsFileSystem#timeouts}
    */
    readonly timeouts?: AwsFsxWindowsFileSystem.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_windows_file_system aws_fsx_windows_file_system}
*/
export declare class AwsFsxWindowsFileSystem extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_fsx_windows_file_system";
    /**
    * Generates CDKTN code for importing a AwsFsxWindowsFileSystem resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsFsxWindowsFileSystem to import
    * @param importFromId The id of the existing AwsFsxWindowsFileSystem that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_windows_file_system#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsFsxWindowsFileSystem to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_windows_file_system aws_fsx_windows_file_system} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsFsxWindowsFileSystemConfig
    */
    constructor(scope: Construct, id: string, config: AwsFsxWindowsFileSystemConfig);
    private _activeDirectoryId?;
    get activeDirectoryId(): string;
    set activeDirectoryId(value: string);
    resetActiveDirectoryId(): void;
    get activeDirectoryIdInput(): string | undefined;
    private _aliases?;
    get aliases(): string[];
    set aliases(value: string[]);
    resetAliases(): void;
    get aliasesInput(): string[] | undefined;
    get arn(): string;
    private _automaticBackupRetentionDays?;
    get automaticBackupRetentionDays(): number;
    set automaticBackupRetentionDays(value: number);
    resetAutomaticBackupRetentionDays(): void;
    get automaticBackupRetentionDaysInput(): number | undefined;
    private _backupId?;
    get backupId(): string;
    set backupId(value: string);
    resetBackupId(): void;
    get backupIdInput(): string | undefined;
    private _copyTagsToBackups?;
    get copyTagsToBackups(): boolean | cdktn.IResolvable;
    set copyTagsToBackups(value: boolean | cdktn.IResolvable);
    resetCopyTagsToBackups(): void;
    get copyTagsToBackupsInput(): boolean | cdktn.IResolvable | undefined;
    private _dailyAutomaticBackupStartTime?;
    get dailyAutomaticBackupStartTime(): string;
    set dailyAutomaticBackupStartTime(value: string);
    resetDailyAutomaticBackupStartTime(): void;
    get dailyAutomaticBackupStartTimeInput(): string | undefined;
    private _deploymentType?;
    get deploymentType(): string;
    set deploymentType(value: string);
    resetDeploymentType(): void;
    get deploymentTypeInput(): string | undefined;
    get dnsName(): string;
    private _finalBackupTags?;
    get finalBackupTags(): {
        [key: string]: string;
    };
    set finalBackupTags(value: {
        [key: string]: string;
    });
    resetFinalBackupTags(): void;
    get finalBackupTagsInput(): {
        [key: string]: string;
    } | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _kmsKeyId?;
    get kmsKeyId(): string;
    set kmsKeyId(value: string);
    resetKmsKeyId(): void;
    get kmsKeyIdInput(): string | undefined;
    get networkInterfaceIds(): string[];
    private _networkType?;
    get networkType(): string;
    set networkType(value: string);
    resetNetworkType(): void;
    get networkTypeInput(): string | undefined;
    get ownerId(): string;
    get preferredFileServerIp(): string;
    private _preferredSubnetId?;
    get preferredSubnetId(): string;
    set preferredSubnetId(value: string);
    resetPreferredSubnetId(): void;
    get preferredSubnetIdInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get remoteAdministrationEndpoint(): string;
    private _securityGroupIds?;
    get securityGroupIds(): string[];
    set securityGroupIds(value: string[]);
    resetSecurityGroupIds(): void;
    get securityGroupIdsInput(): string[] | undefined;
    private _skipFinalBackup?;
    get skipFinalBackup(): boolean | cdktn.IResolvable;
    set skipFinalBackup(value: boolean | cdktn.IResolvable);
    resetSkipFinalBackup(): void;
    get skipFinalBackupInput(): boolean | cdktn.IResolvable | undefined;
    private _storageCapacity?;
    get storageCapacity(): number;
    set storageCapacity(value: number);
    resetStorageCapacity(): void;
    get storageCapacityInput(): number | undefined;
    private _storageType?;
    get storageType(): string;
    set storageType(value: string);
    resetStorageType(): void;
    get storageTypeInput(): string | undefined;
    private _subnetIds?;
    get subnetIds(): string[];
    set subnetIds(value: string[]);
    get subnetIdsInput(): string[] | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _throughputCapacity?;
    get throughputCapacity(): number;
    set throughputCapacity(value: number);
    get throughputCapacityInput(): number | undefined;
    get vpcId(): string;
    private _weeklyMaintenanceStartTime?;
    get weeklyMaintenanceStartTime(): string;
    set weeklyMaintenanceStartTime(value: string);
    resetWeeklyMaintenanceStartTime(): void;
    get weeklyMaintenanceStartTimeInput(): string | undefined;
    private _auditLogConfiguration;
    get auditLogConfiguration(): AwsFsxWindowsFileSystem.AuditLogConfigurationPropertyOutputReference;
    putAuditLogConfiguration(value: AwsFsxWindowsFileSystem.AuditLogConfigurationProperty): void;
    resetAuditLogConfiguration(): void;
    get auditLogConfigurationInput(): AwsFsxWindowsFileSystem.AuditLogConfigurationProperty | undefined;
    private _diskIopsConfiguration;
    get diskIopsConfiguration(): AwsFsxWindowsFileSystem.DiskIopsConfigurationPropertyOutputReference;
    putDiskIopsConfiguration(value: AwsFsxWindowsFileSystem.DiskIopsConfigurationProperty): void;
    resetDiskIopsConfiguration(): void;
    get diskIopsConfigurationInput(): AwsFsxWindowsFileSystem.DiskIopsConfigurationProperty | undefined;
    private _selfManagedActiveDirectory;
    get selfManagedActiveDirectory(): AwsFsxWindowsFileSystem.SelfManagedActiveDirectoryPropertyOutputReference;
    putSelfManagedActiveDirectory(value: AwsFsxWindowsFileSystem.SelfManagedActiveDirectoryProperty): void;
    resetSelfManagedActiveDirectory(): void;
    get selfManagedActiveDirectoryInput(): AwsFsxWindowsFileSystem.SelfManagedActiveDirectoryProperty | undefined;
    private _timeouts;
    get timeouts(): AwsFsxWindowsFileSystem.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsFsxWindowsFileSystem.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsFsxWindowsFileSystem.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsFsxWindowsFileSystemAuditLogConfigurationPropertyToTerraform(struct?: AwsFsxWindowsFileSystem.AuditLogConfigurationPropertyOutputReference | AwsFsxWindowsFileSystem.AuditLogConfigurationProperty): any;
export declare function awsFsxWindowsFileSystemAuditLogConfigurationPropertyToHclTerraform(struct?: AwsFsxWindowsFileSystem.AuditLogConfigurationPropertyOutputReference | AwsFsxWindowsFileSystem.AuditLogConfigurationProperty): any;
export declare function awsFsxWindowsFileSystemDiskIopsConfigurationPropertyToTerraform(struct?: AwsFsxWindowsFileSystem.DiskIopsConfigurationPropertyOutputReference | AwsFsxWindowsFileSystem.DiskIopsConfigurationProperty): any;
export declare function awsFsxWindowsFileSystemDiskIopsConfigurationPropertyToHclTerraform(struct?: AwsFsxWindowsFileSystem.DiskIopsConfigurationPropertyOutputReference | AwsFsxWindowsFileSystem.DiskIopsConfigurationProperty): any;
export declare function awsFsxWindowsFileSystemSelfManagedActiveDirectoryPropertyToTerraform(struct?: AwsFsxWindowsFileSystem.SelfManagedActiveDirectoryPropertyOutputReference | AwsFsxWindowsFileSystem.SelfManagedActiveDirectoryProperty): any;
export declare function awsFsxWindowsFileSystemSelfManagedActiveDirectoryPropertyToHclTerraform(struct?: AwsFsxWindowsFileSystem.SelfManagedActiveDirectoryPropertyOutputReference | AwsFsxWindowsFileSystem.SelfManagedActiveDirectoryProperty): any;
export declare function awsFsxWindowsFileSystemTimeoutsPropertyToTerraform(struct?: AwsFsxWindowsFileSystem.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsFsxWindowsFileSystemTimeoutsPropertyToHclTerraform(struct?: AwsFsxWindowsFileSystem.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsFsxWindowsFileSystem {
    interface AuditLogConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_windows_file_system#audit_log_destination AwsFsxWindowsFileSystem#audit_log_destination}
        */
        readonly auditLogDestination?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_windows_file_system#file_access_audit_log_level AwsFsxWindowsFileSystem#file_access_audit_log_level}
        */
        readonly fileAccessAuditLogLevel?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_windows_file_system#file_share_access_audit_log_level AwsFsxWindowsFileSystem#file_share_access_audit_log_level}
        */
        readonly fileShareAccessAuditLogLevel?: string;
    }
    class AuditLogConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AuditLogConfigurationProperty | undefined;
        set internalValue(value: AuditLogConfigurationProperty | undefined);
        private _auditLogDestination?;
        get auditLogDestination(): string;
        set auditLogDestination(value: string);
        resetAuditLogDestination(): void;
        get auditLogDestinationInput(): string | undefined;
        private _fileAccessAuditLogLevel?;
        get fileAccessAuditLogLevel(): string;
        set fileAccessAuditLogLevel(value: string);
        resetFileAccessAuditLogLevel(): void;
        get fileAccessAuditLogLevelInput(): string | undefined;
        private _fileShareAccessAuditLogLevel?;
        get fileShareAccessAuditLogLevel(): string;
        set fileShareAccessAuditLogLevel(value: string);
        resetFileShareAccessAuditLogLevel(): void;
        get fileShareAccessAuditLogLevelInput(): string | undefined;
    }
    interface DiskIopsConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_windows_file_system#iops AwsFsxWindowsFileSystem#iops}
        */
        readonly iops?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_windows_file_system#mode AwsFsxWindowsFileSystem#mode}
        */
        readonly mode?: string;
    }
    class DiskIopsConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DiskIopsConfigurationProperty | undefined;
        set internalValue(value: DiskIopsConfigurationProperty | undefined);
        private _iops?;
        get iops(): number;
        set iops(value: number);
        resetIops(): void;
        get iopsInput(): number | undefined;
        private _mode?;
        get mode(): string;
        set mode(value: string);
        resetMode(): void;
        get modeInput(): string | undefined;
    }
    interface SelfManagedActiveDirectoryProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_windows_file_system#dns_ips AwsFsxWindowsFileSystem#dns_ips}
        */
        readonly dnsIps: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_windows_file_system#domain_join_service_account_secret AwsFsxWindowsFileSystem#domain_join_service_account_secret}
        */
        readonly domainJoinServiceAccountSecret?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_windows_file_system#domain_name AwsFsxWindowsFileSystem#domain_name}
        */
        readonly domainName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_windows_file_system#file_system_administrators_group AwsFsxWindowsFileSystem#file_system_administrators_group}
        */
        readonly fileSystemAdministratorsGroup?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_windows_file_system#organizational_unit_distinguished_name AwsFsxWindowsFileSystem#organizational_unit_distinguished_name}
        */
        readonly organizationalUnitDistinguishedName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_windows_file_system#password AwsFsxWindowsFileSystem#password}
        */
        readonly password?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_windows_file_system#password_wo AwsFsxWindowsFileSystem#password_wo}
        */
        readonly passwordWo?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_windows_file_system#password_wo_version AwsFsxWindowsFileSystem#password_wo_version}
        */
        readonly passwordWoVersion?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_windows_file_system#username AwsFsxWindowsFileSystem#username}
        */
        readonly username?: string;
    }
    class SelfManagedActiveDirectoryPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SelfManagedActiveDirectoryProperty | undefined;
        set internalValue(value: SelfManagedActiveDirectoryProperty | undefined);
        private _dnsIps?;
        get dnsIps(): string[];
        set dnsIps(value: string[]);
        get dnsIpsInput(): string[] | undefined;
        private _domainJoinServiceAccountSecret?;
        get domainJoinServiceAccountSecret(): string;
        set domainJoinServiceAccountSecret(value: string);
        resetDomainJoinServiceAccountSecret(): void;
        get domainJoinServiceAccountSecretInput(): string | undefined;
        private _domainName?;
        get domainName(): string;
        set domainName(value: string);
        get domainNameInput(): string | undefined;
        private _fileSystemAdministratorsGroup?;
        get fileSystemAdministratorsGroup(): string;
        set fileSystemAdministratorsGroup(value: string);
        resetFileSystemAdministratorsGroup(): void;
        get fileSystemAdministratorsGroupInput(): string | undefined;
        private _organizationalUnitDistinguishedName?;
        get organizationalUnitDistinguishedName(): string;
        set organizationalUnitDistinguishedName(value: string);
        resetOrganizationalUnitDistinguishedName(): void;
        get organizationalUnitDistinguishedNameInput(): string | undefined;
        private _password?;
        get password(): string;
        set password(value: string);
        resetPassword(): void;
        get passwordInput(): string | undefined;
        private _passwordWo?;
        /**
        * @deprecated Write-only: the provider never returns this value; reading it always yields null by protocol contract. The getter remains for compatibility and will be removed in a future prebuilt-provider major.
        */
        get passwordWo(): string;
        set passwordWo(value: string);
        resetPasswordWo(): void;
        get passwordWoInput(): string | undefined;
        private _passwordWoVersion?;
        get passwordWoVersion(): number;
        set passwordWoVersion(value: number);
        resetPasswordWoVersion(): void;
        get passwordWoVersionInput(): number | undefined;
        private _username?;
        get username(): string;
        set username(value: string);
        resetUsername(): void;
        get usernameInput(): string | undefined;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_windows_file_system#create AwsFsxWindowsFileSystem#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_windows_file_system#delete AwsFsxWindowsFileSystem#delete}
        */
        readonly delete?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_windows_file_system#update AwsFsxWindowsFileSystem#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
