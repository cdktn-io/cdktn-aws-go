import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsFsxOntapStorageVirtualMachineConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/fsx_ontap_storage_virtual_machine#id DataAwsFsxOntapStorageVirtualMachine#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/fsx_ontap_storage_virtual_machine#region DataAwsFsxOntapStorageVirtualMachine#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/fsx_ontap_storage_virtual_machine#tags DataAwsFsxOntapStorageVirtualMachine#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * filter block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/fsx_ontap_storage_virtual_machine#filter DataAwsFsxOntapStorageVirtualMachine#filter}
    */
    readonly filter?: DataAwsFsxOntapStorageVirtualMachine.FilterProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/fsx_ontap_storage_virtual_machine aws_fsx_ontap_storage_virtual_machine}
*/
export declare class DataAwsFsxOntapStorageVirtualMachine extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_fsx_ontap_storage_virtual_machine";
    /**
    * Generates CDKTN code for importing a DataAwsFsxOntapStorageVirtualMachine resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsFsxOntapStorageVirtualMachine to import
    * @param importFromId The id of the existing DataAwsFsxOntapStorageVirtualMachine that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/fsx_ontap_storage_virtual_machine#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsFsxOntapStorageVirtualMachine to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/fsx_ontap_storage_virtual_machine aws_fsx_ontap_storage_virtual_machine} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsFsxOntapStorageVirtualMachineConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataAwsFsxOntapStorageVirtualMachineConfig);
    private _activeDirectoryConfiguration;
    get activeDirectoryConfiguration(): DataAwsFsxOntapStorageVirtualMachine.ActiveDirectoryConfigurationPropertyList;
    get arn(): string;
    get creationTime(): string;
    private _endpoints;
    get endpoints(): DataAwsFsxOntapStorageVirtualMachine.EndpointsPropertyList;
    get fileSystemId(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get lifecycleStatus(): string;
    private _lifecycleTransitionReason;
    get lifecycleTransitionReason(): DataAwsFsxOntapStorageVirtualMachine.LifecycleTransitionReasonPropertyList;
    get name(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get subtype(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    get uuid(): string;
    private _filter;
    get filter(): DataAwsFsxOntapStorageVirtualMachine.FilterPropertyList;
    putFilter(value: DataAwsFsxOntapStorageVirtualMachine.FilterProperty[] | cdktn.IResolvable): void;
    resetFilter(): void;
    get filterInput(): cdktn.IResolvable | DataAwsFsxOntapStorageVirtualMachine.FilterProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataAwsFsxOntapStorageVirtualMachineSelfManagedActiveDirectoryConfigurationPropertyToTerraform(struct?: DataAwsFsxOntapStorageVirtualMachine.SelfManagedActiveDirectoryConfigurationProperty): any;
export declare function dataAwsFsxOntapStorageVirtualMachineSelfManagedActiveDirectoryConfigurationPropertyToHclTerraform(struct?: DataAwsFsxOntapStorageVirtualMachine.SelfManagedActiveDirectoryConfigurationProperty): any;
export declare function dataAwsFsxOntapStorageVirtualMachineActiveDirectoryConfigurationPropertyToTerraform(struct?: DataAwsFsxOntapStorageVirtualMachine.ActiveDirectoryConfigurationProperty): any;
export declare function dataAwsFsxOntapStorageVirtualMachineActiveDirectoryConfigurationPropertyToHclTerraform(struct?: DataAwsFsxOntapStorageVirtualMachine.ActiveDirectoryConfigurationProperty): any;
export declare function dataAwsFsxOntapStorageVirtualMachineIscsiPropertyToTerraform(struct?: DataAwsFsxOntapStorageVirtualMachine.IscsiProperty): any;
export declare function dataAwsFsxOntapStorageVirtualMachineIscsiPropertyToHclTerraform(struct?: DataAwsFsxOntapStorageVirtualMachine.IscsiProperty): any;
export declare function dataAwsFsxOntapStorageVirtualMachineManagementPropertyToTerraform(struct?: DataAwsFsxOntapStorageVirtualMachine.ManagementProperty): any;
export declare function dataAwsFsxOntapStorageVirtualMachineManagementPropertyToHclTerraform(struct?: DataAwsFsxOntapStorageVirtualMachine.ManagementProperty): any;
export declare function dataAwsFsxOntapStorageVirtualMachineNfsPropertyToTerraform(struct?: DataAwsFsxOntapStorageVirtualMachine.NfsProperty): any;
export declare function dataAwsFsxOntapStorageVirtualMachineNfsPropertyToHclTerraform(struct?: DataAwsFsxOntapStorageVirtualMachine.NfsProperty): any;
export declare function dataAwsFsxOntapStorageVirtualMachineSmbPropertyToTerraform(struct?: DataAwsFsxOntapStorageVirtualMachine.SmbProperty): any;
export declare function dataAwsFsxOntapStorageVirtualMachineSmbPropertyToHclTerraform(struct?: DataAwsFsxOntapStorageVirtualMachine.SmbProperty): any;
export declare function dataAwsFsxOntapStorageVirtualMachineEndpointsPropertyToTerraform(struct?: DataAwsFsxOntapStorageVirtualMachine.EndpointsProperty): any;
export declare function dataAwsFsxOntapStorageVirtualMachineEndpointsPropertyToHclTerraform(struct?: DataAwsFsxOntapStorageVirtualMachine.EndpointsProperty): any;
export declare function dataAwsFsxOntapStorageVirtualMachineLifecycleTransitionReasonPropertyToTerraform(struct?: DataAwsFsxOntapStorageVirtualMachine.LifecycleTransitionReasonProperty): any;
export declare function dataAwsFsxOntapStorageVirtualMachineLifecycleTransitionReasonPropertyToHclTerraform(struct?: DataAwsFsxOntapStorageVirtualMachine.LifecycleTransitionReasonProperty): any;
export declare function dataAwsFsxOntapStorageVirtualMachineFilterPropertyToTerraform(struct?: DataAwsFsxOntapStorageVirtualMachine.FilterProperty | cdktn.IResolvable): any;
export declare function dataAwsFsxOntapStorageVirtualMachineFilterPropertyToHclTerraform(struct?: DataAwsFsxOntapStorageVirtualMachine.FilterProperty | cdktn.IResolvable): any;
export declare namespace DataAwsFsxOntapStorageVirtualMachine {
    interface SelfManagedActiveDirectoryConfigurationProperty {
    }
    class SelfManagedActiveDirectoryConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SelfManagedActiveDirectoryConfigurationProperty | undefined;
        set internalValue(value: SelfManagedActiveDirectoryConfigurationProperty | undefined);
        get dnsIps(): string[];
        get domainName(): string;
        get fileSystemAdministratorsGroup(): string;
        get organizationalUnitDistinguishedName(): string;
        get username(): string;
    }
    class SelfManagedActiveDirectoryConfigurationPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SelfManagedActiveDirectoryConfigurationPropertyOutputReference;
    }
    interface ActiveDirectoryConfigurationProperty {
    }
    class ActiveDirectoryConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ActiveDirectoryConfigurationProperty | undefined;
        set internalValue(value: ActiveDirectoryConfigurationProperty | undefined);
        get netbiosName(): string;
        private _selfManagedActiveDirectoryConfiguration;
        get selfManagedActiveDirectoryConfiguration(): SelfManagedActiveDirectoryConfigurationPropertyList;
    }
    class ActiveDirectoryConfigurationPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ActiveDirectoryConfigurationPropertyOutputReference;
    }
    interface IscsiProperty {
    }
    class IscsiPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): IscsiProperty | undefined;
        set internalValue(value: IscsiProperty | undefined);
        get dnsName(): string;
        get ipAddresses(): string[];
    }
    class IscsiPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): IscsiPropertyOutputReference;
    }
    interface ManagementProperty {
    }
    class ManagementPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ManagementProperty | undefined;
        set internalValue(value: ManagementProperty | undefined);
        get dnsName(): string;
        get ipAddresses(): string[];
    }
    class ManagementPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ManagementPropertyOutputReference;
    }
    interface NfsProperty {
    }
    class NfsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): NfsProperty | undefined;
        set internalValue(value: NfsProperty | undefined);
        get dnsName(): string;
        get ipAddresses(): string[];
    }
    class NfsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): NfsPropertyOutputReference;
    }
    interface SmbProperty {
    }
    class SmbPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SmbProperty | undefined;
        set internalValue(value: SmbProperty | undefined);
        get dnsName(): string;
        get ipAddresses(): string[];
    }
    class SmbPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SmbPropertyOutputReference;
    }
    interface EndpointsProperty {
    }
    class EndpointsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EndpointsProperty | undefined;
        set internalValue(value: EndpointsProperty | undefined);
        private _iscsi;
        get iscsi(): IscsiPropertyList;
        private _management;
        get management(): ManagementPropertyList;
        private _nfs;
        get nfs(): NfsPropertyList;
        private _smb;
        get smb(): SmbPropertyList;
    }
    class EndpointsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EndpointsPropertyOutputReference;
    }
    interface LifecycleTransitionReasonProperty {
    }
    class LifecycleTransitionReasonPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): LifecycleTransitionReasonProperty | undefined;
        set internalValue(value: LifecycleTransitionReasonProperty | undefined);
        get message(): string;
    }
    class LifecycleTransitionReasonPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): LifecycleTransitionReasonPropertyOutputReference;
    }
    interface FilterProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/fsx_ontap_storage_virtual_machine#name DataAwsFsxOntapStorageVirtualMachine#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/fsx_ontap_storage_virtual_machine#values DataAwsFsxOntapStorageVirtualMachine#values}
        */
        readonly values: string[];
    }
    class FilterPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): FilterProperty | cdktn.IResolvable | undefined;
        set internalValue(value: FilterProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        get valuesInput(): string[] | undefined;
    }
    class FilterPropertyList extends cdktn.ComplexList {
        internalValue?: FilterProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): FilterPropertyOutputReference;
    }
}
