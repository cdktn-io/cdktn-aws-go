import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsFsxOntapVolumeConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_ontap_volume#bypass_snaplock_enterprise_retention AwsFsxOntapVolume#bypass_snaplock_enterprise_retention}
    */
    readonly bypassSnaplockEnterpriseRetention?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_ontap_volume#copy_tags_to_backups AwsFsxOntapVolume#copy_tags_to_backups}
    */
    readonly copyTagsToBackups?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_ontap_volume#final_backup_tags AwsFsxOntapVolume#final_backup_tags}
    */
    readonly finalBackupTags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_ontap_volume#id AwsFsxOntapVolume#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_ontap_volume#junction_path AwsFsxOntapVolume#junction_path}
    */
    readonly junctionPath?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_ontap_volume#name AwsFsxOntapVolume#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_ontap_volume#ontap_volume_type AwsFsxOntapVolume#ontap_volume_type}
    */
    readonly ontapVolumeType?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_ontap_volume#region AwsFsxOntapVolume#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_ontap_volume#security_style AwsFsxOntapVolume#security_style}
    */
    readonly securityStyle?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_ontap_volume#size_in_bytes AwsFsxOntapVolume#size_in_bytes}
    */
    readonly sizeInBytes?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_ontap_volume#size_in_megabytes AwsFsxOntapVolume#size_in_megabytes}
    */
    readonly sizeInMegabytes?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_ontap_volume#skip_final_backup AwsFsxOntapVolume#skip_final_backup}
    */
    readonly skipFinalBackup?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_ontap_volume#snapshot_policy AwsFsxOntapVolume#snapshot_policy}
    */
    readonly snapshotPolicy?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_ontap_volume#storage_efficiency_enabled AwsFsxOntapVolume#storage_efficiency_enabled}
    */
    readonly storageEfficiencyEnabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_ontap_volume#storage_virtual_machine_id AwsFsxOntapVolume#storage_virtual_machine_id}
    */
    readonly storageVirtualMachineId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_ontap_volume#tags AwsFsxOntapVolume#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_ontap_volume#tags_all AwsFsxOntapVolume#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_ontap_volume#volume_style AwsFsxOntapVolume#volume_style}
    */
    readonly volumeStyle?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_ontap_volume#volume_type AwsFsxOntapVolume#volume_type}
    */
    readonly volumeType?: string;
    /**
    * aggregate_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_ontap_volume#aggregate_configuration AwsFsxOntapVolume#aggregate_configuration}
    */
    readonly aggregateConfiguration?: AwsFsxOntapVolume.AggregateConfigurationProperty;
    /**
    * snaplock_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_ontap_volume#snaplock_configuration AwsFsxOntapVolume#snaplock_configuration}
    */
    readonly snaplockConfiguration?: AwsFsxOntapVolume.SnaplockConfigurationProperty;
    /**
    * tiering_policy block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_ontap_volume#tiering_policy AwsFsxOntapVolume#tiering_policy}
    */
    readonly tieringPolicy?: AwsFsxOntapVolume.TieringPolicyProperty;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_ontap_volume#timeouts AwsFsxOntapVolume#timeouts}
    */
    readonly timeouts?: AwsFsxOntapVolume.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_ontap_volume aws_fsx_ontap_volume}
*/
export declare class AwsFsxOntapVolume extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_fsx_ontap_volume";
    /**
    * Generates CDKTN code for importing a AwsFsxOntapVolume resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsFsxOntapVolume to import
    * @param importFromId The id of the existing AwsFsxOntapVolume that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_ontap_volume#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsFsxOntapVolume to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_ontap_volume aws_fsx_ontap_volume} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsFsxOntapVolumeConfig
    */
    constructor(scope: Construct, id: string, config: AwsFsxOntapVolumeConfig);
    get arn(): string;
    private _bypassSnaplockEnterpriseRetention?;
    get bypassSnaplockEnterpriseRetention(): boolean | cdktn.IResolvable;
    set bypassSnaplockEnterpriseRetention(value: boolean | cdktn.IResolvable);
    resetBypassSnaplockEnterpriseRetention(): void;
    get bypassSnaplockEnterpriseRetentionInput(): boolean | cdktn.IResolvable | undefined;
    private _copyTagsToBackups?;
    get copyTagsToBackups(): boolean | cdktn.IResolvable;
    set copyTagsToBackups(value: boolean | cdktn.IResolvable);
    resetCopyTagsToBackups(): void;
    get copyTagsToBackupsInput(): boolean | cdktn.IResolvable | undefined;
    get fileSystemId(): string;
    private _finalBackupTags?;
    get finalBackupTags(): {
        [key: string]: string;
    };
    set finalBackupTags(value: {
        [key: string]: string;
    });
    resetFinalBackupTags(): void;
    get finalBackupTagsInput(): {
        [key: string]: string;
    } | undefined;
    get flexcacheEndpointType(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _junctionPath?;
    get junctionPath(): string;
    set junctionPath(value: string);
    resetJunctionPath(): void;
    get junctionPathInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _ontapVolumeType?;
    get ontapVolumeType(): string;
    set ontapVolumeType(value: string);
    resetOntapVolumeType(): void;
    get ontapVolumeTypeInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _securityStyle?;
    get securityStyle(): string;
    set securityStyle(value: string);
    resetSecurityStyle(): void;
    get securityStyleInput(): string | undefined;
    private _sizeInBytes?;
    get sizeInBytes(): string;
    set sizeInBytes(value: string);
    resetSizeInBytes(): void;
    get sizeInBytesInput(): string | undefined;
    private _sizeInMegabytes?;
    get sizeInMegabytes(): number;
    set sizeInMegabytes(value: number);
    resetSizeInMegabytes(): void;
    get sizeInMegabytesInput(): number | undefined;
    private _skipFinalBackup?;
    get skipFinalBackup(): boolean | cdktn.IResolvable;
    set skipFinalBackup(value: boolean | cdktn.IResolvable);
    resetSkipFinalBackup(): void;
    get skipFinalBackupInput(): boolean | cdktn.IResolvable | undefined;
    private _snapshotPolicy?;
    get snapshotPolicy(): string;
    set snapshotPolicy(value: string);
    resetSnapshotPolicy(): void;
    get snapshotPolicyInput(): string | undefined;
    private _storageEfficiencyEnabled?;
    get storageEfficiencyEnabled(): boolean | cdktn.IResolvable;
    set storageEfficiencyEnabled(value: boolean | cdktn.IResolvable);
    resetStorageEfficiencyEnabled(): void;
    get storageEfficiencyEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _storageVirtualMachineId?;
    get storageVirtualMachineId(): string;
    set storageVirtualMachineId(value: string);
    get storageVirtualMachineIdInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    get uuid(): string;
    private _volumeStyle?;
    get volumeStyle(): string;
    set volumeStyle(value: string);
    resetVolumeStyle(): void;
    get volumeStyleInput(): string | undefined;
    private _volumeType?;
    get volumeType(): string;
    set volumeType(value: string);
    resetVolumeType(): void;
    get volumeTypeInput(): string | undefined;
    private _aggregateConfiguration;
    get aggregateConfiguration(): AwsFsxOntapVolume.AggregateConfigurationPropertyOutputReference;
    putAggregateConfiguration(value: AwsFsxOntapVolume.AggregateConfigurationProperty): void;
    resetAggregateConfiguration(): void;
    get aggregateConfigurationInput(): AwsFsxOntapVolume.AggregateConfigurationProperty | undefined;
    private _snaplockConfiguration;
    get snaplockConfiguration(): AwsFsxOntapVolume.SnaplockConfigurationPropertyOutputReference;
    putSnaplockConfiguration(value: AwsFsxOntapVolume.SnaplockConfigurationProperty): void;
    resetSnaplockConfiguration(): void;
    get snaplockConfigurationInput(): AwsFsxOntapVolume.SnaplockConfigurationProperty | undefined;
    private _tieringPolicy;
    get tieringPolicy(): AwsFsxOntapVolume.TieringPolicyPropertyOutputReference;
    putTieringPolicy(value: AwsFsxOntapVolume.TieringPolicyProperty): void;
    resetTieringPolicy(): void;
    get tieringPolicyInput(): AwsFsxOntapVolume.TieringPolicyProperty | undefined;
    private _timeouts;
    get timeouts(): AwsFsxOntapVolume.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsFsxOntapVolume.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsFsxOntapVolume.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsFsxOntapVolumeAggregateConfigurationPropertyToTerraform(struct?: AwsFsxOntapVolume.AggregateConfigurationPropertyOutputReference | AwsFsxOntapVolume.AggregateConfigurationProperty): any;
export declare function awsFsxOntapVolumeAggregateConfigurationPropertyToHclTerraform(struct?: AwsFsxOntapVolume.AggregateConfigurationPropertyOutputReference | AwsFsxOntapVolume.AggregateConfigurationProperty): any;
export declare function awsFsxOntapVolumeAutocommitPeriodPropertyToTerraform(struct?: AwsFsxOntapVolume.AutocommitPeriodPropertyOutputReference | AwsFsxOntapVolume.AutocommitPeriodProperty): any;
export declare function awsFsxOntapVolumeAutocommitPeriodPropertyToHclTerraform(struct?: AwsFsxOntapVolume.AutocommitPeriodPropertyOutputReference | AwsFsxOntapVolume.AutocommitPeriodProperty): any;
export declare function awsFsxOntapVolumeDefaultRetentionPropertyToTerraform(struct?: AwsFsxOntapVolume.DefaultRetentionPropertyOutputReference | AwsFsxOntapVolume.DefaultRetentionProperty): any;
export declare function awsFsxOntapVolumeDefaultRetentionPropertyToHclTerraform(struct?: AwsFsxOntapVolume.DefaultRetentionPropertyOutputReference | AwsFsxOntapVolume.DefaultRetentionProperty): any;
export declare function awsFsxOntapVolumeMaximumRetentionPropertyToTerraform(struct?: AwsFsxOntapVolume.MaximumRetentionPropertyOutputReference | AwsFsxOntapVolume.MaximumRetentionProperty): any;
export declare function awsFsxOntapVolumeMaximumRetentionPropertyToHclTerraform(struct?: AwsFsxOntapVolume.MaximumRetentionPropertyOutputReference | AwsFsxOntapVolume.MaximumRetentionProperty): any;
export declare function awsFsxOntapVolumeMinimumRetentionPropertyToTerraform(struct?: AwsFsxOntapVolume.MinimumRetentionPropertyOutputReference | AwsFsxOntapVolume.MinimumRetentionProperty): any;
export declare function awsFsxOntapVolumeMinimumRetentionPropertyToHclTerraform(struct?: AwsFsxOntapVolume.MinimumRetentionPropertyOutputReference | AwsFsxOntapVolume.MinimumRetentionProperty): any;
export declare function awsFsxOntapVolumeRetentionPeriodPropertyToTerraform(struct?: AwsFsxOntapVolume.RetentionPeriodPropertyOutputReference | AwsFsxOntapVolume.RetentionPeriodProperty): any;
export declare function awsFsxOntapVolumeRetentionPeriodPropertyToHclTerraform(struct?: AwsFsxOntapVolume.RetentionPeriodPropertyOutputReference | AwsFsxOntapVolume.RetentionPeriodProperty): any;
export declare function awsFsxOntapVolumeSnaplockConfigurationPropertyToTerraform(struct?: AwsFsxOntapVolume.SnaplockConfigurationPropertyOutputReference | AwsFsxOntapVolume.SnaplockConfigurationProperty): any;
export declare function awsFsxOntapVolumeSnaplockConfigurationPropertyToHclTerraform(struct?: AwsFsxOntapVolume.SnaplockConfigurationPropertyOutputReference | AwsFsxOntapVolume.SnaplockConfigurationProperty): any;
export declare function awsFsxOntapVolumeTieringPolicyPropertyToTerraform(struct?: AwsFsxOntapVolume.TieringPolicyPropertyOutputReference | AwsFsxOntapVolume.TieringPolicyProperty): any;
export declare function awsFsxOntapVolumeTieringPolicyPropertyToHclTerraform(struct?: AwsFsxOntapVolume.TieringPolicyPropertyOutputReference | AwsFsxOntapVolume.TieringPolicyProperty): any;
export declare function awsFsxOntapVolumeTimeoutsPropertyToTerraform(struct?: AwsFsxOntapVolume.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsFsxOntapVolumeTimeoutsPropertyToHclTerraform(struct?: AwsFsxOntapVolume.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsFsxOntapVolume {
    interface AggregateConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_ontap_volume#aggregates AwsFsxOntapVolume#aggregates}
        */
        readonly aggregates?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_ontap_volume#constituents_per_aggregate AwsFsxOntapVolume#constituents_per_aggregate}
        */
        readonly constituentsPerAggregate?: number;
    }
    class AggregateConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AggregateConfigurationProperty | undefined;
        set internalValue(value: AggregateConfigurationProperty | undefined);
        private _aggregates?;
        get aggregates(): string[];
        set aggregates(value: string[]);
        resetAggregates(): void;
        get aggregatesInput(): string[] | undefined;
        private _constituentsPerAggregate?;
        get constituentsPerAggregate(): number;
        set constituentsPerAggregate(value: number);
        resetConstituentsPerAggregate(): void;
        get constituentsPerAggregateInput(): number | undefined;
        get totalConstituents(): number;
    }
    interface AutocommitPeriodProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_ontap_volume#type AwsFsxOntapVolume#type}
        */
        readonly type?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_ontap_volume#value AwsFsxOntapVolume#value}
        */
        readonly value?: number;
    }
    class AutocommitPeriodPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AutocommitPeriodProperty | undefined;
        set internalValue(value: AutocommitPeriodProperty | undefined);
        private _type?;
        get type(): string;
        set type(value: string);
        resetType(): void;
        get typeInput(): string | undefined;
        private _value?;
        get value(): number;
        set value(value: number);
        resetValue(): void;
        get valueInput(): number | undefined;
    }
    interface DefaultRetentionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_ontap_volume#type AwsFsxOntapVolume#type}
        */
        readonly type?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_ontap_volume#value AwsFsxOntapVolume#value}
        */
        readonly value?: number;
    }
    class DefaultRetentionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DefaultRetentionProperty | undefined;
        set internalValue(value: DefaultRetentionProperty | undefined);
        private _type?;
        get type(): string;
        set type(value: string);
        resetType(): void;
        get typeInput(): string | undefined;
        private _value?;
        get value(): number;
        set value(value: number);
        resetValue(): void;
        get valueInput(): number | undefined;
    }
    interface MaximumRetentionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_ontap_volume#type AwsFsxOntapVolume#type}
        */
        readonly type?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_ontap_volume#value AwsFsxOntapVolume#value}
        */
        readonly value?: number;
    }
    class MaximumRetentionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): MaximumRetentionProperty | undefined;
        set internalValue(value: MaximumRetentionProperty | undefined);
        private _type?;
        get type(): string;
        set type(value: string);
        resetType(): void;
        get typeInput(): string | undefined;
        private _value?;
        get value(): number;
        set value(value: number);
        resetValue(): void;
        get valueInput(): number | undefined;
    }
    interface MinimumRetentionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_ontap_volume#type AwsFsxOntapVolume#type}
        */
        readonly type?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_ontap_volume#value AwsFsxOntapVolume#value}
        */
        readonly value?: number;
    }
    class MinimumRetentionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): MinimumRetentionProperty | undefined;
        set internalValue(value: MinimumRetentionProperty | undefined);
        private _type?;
        get type(): string;
        set type(value: string);
        resetType(): void;
        get typeInput(): string | undefined;
        private _value?;
        get value(): number;
        set value(value: number);
        resetValue(): void;
        get valueInput(): number | undefined;
    }
    interface RetentionPeriodProperty {
        /**
        * default_retention block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_ontap_volume#default_retention AwsFsxOntapVolume#default_retention}
        */
        readonly defaultRetention?: DefaultRetentionProperty;
        /**
        * maximum_retention block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_ontap_volume#maximum_retention AwsFsxOntapVolume#maximum_retention}
        */
        readonly maximumRetention?: MaximumRetentionProperty;
        /**
        * minimum_retention block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_ontap_volume#minimum_retention AwsFsxOntapVolume#minimum_retention}
        */
        readonly minimumRetention?: MinimumRetentionProperty;
    }
    class RetentionPeriodPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RetentionPeriodProperty | undefined;
        set internalValue(value: RetentionPeriodProperty | undefined);
        private _defaultRetention;
        get defaultRetention(): DefaultRetentionPropertyOutputReference;
        putDefaultRetention(value: DefaultRetentionProperty): void;
        resetDefaultRetention(): void;
        get defaultRetentionInput(): DefaultRetentionProperty | undefined;
        private _maximumRetention;
        get maximumRetention(): MaximumRetentionPropertyOutputReference;
        putMaximumRetention(value: MaximumRetentionProperty): void;
        resetMaximumRetention(): void;
        get maximumRetentionInput(): MaximumRetentionProperty | undefined;
        private _minimumRetention;
        get minimumRetention(): MinimumRetentionPropertyOutputReference;
        putMinimumRetention(value: MinimumRetentionProperty): void;
        resetMinimumRetention(): void;
        get minimumRetentionInput(): MinimumRetentionProperty | undefined;
    }
    interface SnaplockConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_ontap_volume#audit_log_volume AwsFsxOntapVolume#audit_log_volume}
        */
        readonly auditLogVolume?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_ontap_volume#privileged_delete AwsFsxOntapVolume#privileged_delete}
        */
        readonly privilegedDelete?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_ontap_volume#snaplock_type AwsFsxOntapVolume#snaplock_type}
        */
        readonly snaplockType: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_ontap_volume#volume_append_mode_enabled AwsFsxOntapVolume#volume_append_mode_enabled}
        */
        readonly volumeAppendModeEnabled?: boolean | cdktn.IResolvable;
        /**
        * autocommit_period block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_ontap_volume#autocommit_period AwsFsxOntapVolume#autocommit_period}
        */
        readonly autocommitPeriod?: AutocommitPeriodProperty;
        /**
        * retention_period block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_ontap_volume#retention_period AwsFsxOntapVolume#retention_period}
        */
        readonly retentionPeriod?: RetentionPeriodProperty;
    }
    class SnaplockConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SnaplockConfigurationProperty | undefined;
        set internalValue(value: SnaplockConfigurationProperty | undefined);
        private _auditLogVolume?;
        get auditLogVolume(): boolean | cdktn.IResolvable;
        set auditLogVolume(value: boolean | cdktn.IResolvable);
        resetAuditLogVolume(): void;
        get auditLogVolumeInput(): boolean | cdktn.IResolvable | undefined;
        private _privilegedDelete?;
        get privilegedDelete(): string;
        set privilegedDelete(value: string);
        resetPrivilegedDelete(): void;
        get privilegedDeleteInput(): string | undefined;
        private _snaplockType?;
        get snaplockType(): string;
        set snaplockType(value: string);
        get snaplockTypeInput(): string | undefined;
        private _volumeAppendModeEnabled?;
        get volumeAppendModeEnabled(): boolean | cdktn.IResolvable;
        set volumeAppendModeEnabled(value: boolean | cdktn.IResolvable);
        resetVolumeAppendModeEnabled(): void;
        get volumeAppendModeEnabledInput(): boolean | cdktn.IResolvable | undefined;
        private _autocommitPeriod;
        get autocommitPeriod(): AutocommitPeriodPropertyOutputReference;
        putAutocommitPeriod(value: AutocommitPeriodProperty): void;
        resetAutocommitPeriod(): void;
        get autocommitPeriodInput(): AutocommitPeriodProperty | undefined;
        private _retentionPeriod;
        get retentionPeriod(): RetentionPeriodPropertyOutputReference;
        putRetentionPeriod(value: RetentionPeriodProperty): void;
        resetRetentionPeriod(): void;
        get retentionPeriodInput(): RetentionPeriodProperty | undefined;
    }
    interface TieringPolicyProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_ontap_volume#cooling_period AwsFsxOntapVolume#cooling_period}
        */
        readonly coolingPeriod?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_ontap_volume#name AwsFsxOntapVolume#name}
        */
        readonly name?: string;
    }
    class TieringPolicyPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TieringPolicyProperty | undefined;
        set internalValue(value: TieringPolicyProperty | undefined);
        private _coolingPeriod?;
        get coolingPeriod(): number;
        set coolingPeriod(value: number);
        resetCoolingPeriod(): void;
        get coolingPeriodInput(): number | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        resetName(): void;
        get nameInput(): string | undefined;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_ontap_volume#create AwsFsxOntapVolume#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_ontap_volume#delete AwsFsxOntapVolume#delete}
        */
        readonly delete?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_ontap_volume#update AwsFsxOntapVolume#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
