import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsFsxS3AccessPointAttachmentConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_s3_access_point_attachment#name AwsFsxS3AccessPointAttachment#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_s3_access_point_attachment#region AwsFsxS3AccessPointAttachment#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_s3_access_point_attachment#type AwsFsxS3AccessPointAttachment#type}
    */
    readonly type: string;
    /**
    * openzfs_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_s3_access_point_attachment#openzfs_configuration AwsFsxS3AccessPointAttachment#openzfs_configuration}
    */
    readonly openzfsConfiguration?: AwsFsxS3AccessPointAttachment.OpenzfsConfigurationProperty[] | cdktn.IResolvable;
    /**
    * s3_access_point block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_s3_access_point_attachment#s3_access_point AwsFsxS3AccessPointAttachment#s3_access_point}
    */
    readonly s3AccessPoint?: AwsFsxS3AccessPointAttachment.S3AccessPointProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_s3_access_point_attachment#timeouts AwsFsxS3AccessPointAttachment#timeouts}
    */
    readonly timeouts?: AwsFsxS3AccessPointAttachment.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_s3_access_point_attachment aws_fsx_s3_access_point_attachment}
*/
export declare class AwsFsxS3AccessPointAttachment extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_fsx_s3_access_point_attachment";
    /**
    * Generates CDKTN code for importing a AwsFsxS3AccessPointAttachment resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsFsxS3AccessPointAttachment to import
    * @param importFromId The id of the existing AwsFsxS3AccessPointAttachment that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_s3_access_point_attachment#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsFsxS3AccessPointAttachment to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_s3_access_point_attachment aws_fsx_s3_access_point_attachment} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsFsxS3AccessPointAttachmentConfig
    */
    constructor(scope: Construct, id: string, config: AwsFsxS3AccessPointAttachmentConfig);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get s3AccessPointAlias(): string;
    get s3AccessPointArn(): string;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _openzfsConfiguration;
    get openzfsConfiguration(): AwsFsxS3AccessPointAttachment.OpenzfsConfigurationPropertyList;
    putOpenzfsConfiguration(value: AwsFsxS3AccessPointAttachment.OpenzfsConfigurationProperty[] | cdktn.IResolvable): void;
    resetOpenzfsConfiguration(): void;
    get openzfsConfigurationInput(): cdktn.IResolvable | AwsFsxS3AccessPointAttachment.OpenzfsConfigurationProperty[] | undefined;
    private _s3AccessPoint;
    get s3AccessPoint(): AwsFsxS3AccessPointAttachment.S3AccessPointPropertyList;
    putS3AccessPoint(value: AwsFsxS3AccessPointAttachment.S3AccessPointProperty[] | cdktn.IResolvable): void;
    resetS3AccessPoint(): void;
    get s3AccessPointInput(): cdktn.IResolvable | AwsFsxS3AccessPointAttachment.S3AccessPointProperty[] | undefined;
    private _timeouts;
    get timeouts(): AwsFsxS3AccessPointAttachment.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsFsxS3AccessPointAttachment.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsFsxS3AccessPointAttachment.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsFsxS3AccessPointAttachmentPosixUserPropertyToTerraform(struct?: AwsFsxS3AccessPointAttachment.PosixUserProperty | cdktn.IResolvable): any;
export declare function awsFsxS3AccessPointAttachmentPosixUserPropertyToHclTerraform(struct?: AwsFsxS3AccessPointAttachment.PosixUserProperty | cdktn.IResolvable): any;
export declare function awsFsxS3AccessPointAttachmentFileSystemIdentityPropertyToTerraform(struct?: AwsFsxS3AccessPointAttachment.FileSystemIdentityProperty | cdktn.IResolvable): any;
export declare function awsFsxS3AccessPointAttachmentFileSystemIdentityPropertyToHclTerraform(struct?: AwsFsxS3AccessPointAttachment.FileSystemIdentityProperty | cdktn.IResolvable): any;
export declare function awsFsxS3AccessPointAttachmentOpenzfsConfigurationPropertyToTerraform(struct?: AwsFsxS3AccessPointAttachment.OpenzfsConfigurationProperty | cdktn.IResolvable): any;
export declare function awsFsxS3AccessPointAttachmentOpenzfsConfigurationPropertyToHclTerraform(struct?: AwsFsxS3AccessPointAttachment.OpenzfsConfigurationProperty | cdktn.IResolvable): any;
export declare function awsFsxS3AccessPointAttachmentVpcConfigurationPropertyToTerraform(struct?: AwsFsxS3AccessPointAttachment.VpcConfigurationProperty | cdktn.IResolvable): any;
export declare function awsFsxS3AccessPointAttachmentVpcConfigurationPropertyToHclTerraform(struct?: AwsFsxS3AccessPointAttachment.VpcConfigurationProperty | cdktn.IResolvable): any;
export declare function awsFsxS3AccessPointAttachmentS3AccessPointPropertyToTerraform(struct?: AwsFsxS3AccessPointAttachment.S3AccessPointProperty | cdktn.IResolvable): any;
export declare function awsFsxS3AccessPointAttachmentS3AccessPointPropertyToHclTerraform(struct?: AwsFsxS3AccessPointAttachment.S3AccessPointProperty | cdktn.IResolvable): any;
export declare function awsFsxS3AccessPointAttachmentTimeoutsPropertyToTerraform(struct?: AwsFsxS3AccessPointAttachment.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsFsxS3AccessPointAttachmentTimeoutsPropertyToHclTerraform(struct?: AwsFsxS3AccessPointAttachment.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsFsxS3AccessPointAttachment {
    interface PosixUserProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_s3_access_point_attachment#gid AwsFsxS3AccessPointAttachment#gid}
        */
        readonly gid: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_s3_access_point_attachment#secondary_gids AwsFsxS3AccessPointAttachment#secondary_gids}
        */
        readonly secondaryGids?: number[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_s3_access_point_attachment#uid AwsFsxS3AccessPointAttachment#uid}
        */
        readonly uid: number;
    }
    class PosixUserPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): PosixUserProperty | cdktn.IResolvable | undefined;
        set internalValue(value: PosixUserProperty | cdktn.IResolvable | undefined);
        private _gid?;
        get gid(): number;
        set gid(value: number);
        get gidInput(): number | undefined;
        private _secondaryGids?;
        get secondaryGids(): number[];
        set secondaryGids(value: number[]);
        resetSecondaryGids(): void;
        get secondaryGidsInput(): number[] | undefined;
        private _uid?;
        get uid(): number;
        set uid(value: number);
        get uidInput(): number | undefined;
    }
    class PosixUserPropertyList extends cdktn.ComplexList {
        internalValue?: PosixUserProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): PosixUserPropertyOutputReference;
    }
    interface FileSystemIdentityProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_s3_access_point_attachment#type AwsFsxS3AccessPointAttachment#type}
        */
        readonly type: string;
        /**
        * posix_user block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_s3_access_point_attachment#posix_user AwsFsxS3AccessPointAttachment#posix_user}
        */
        readonly posixUser?: PosixUserProperty[] | cdktn.IResolvable;
    }
    class FileSystemIdentityPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): FileSystemIdentityProperty | cdktn.IResolvable | undefined;
        set internalValue(value: FileSystemIdentityProperty | cdktn.IResolvable | undefined);
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
        private _posixUser;
        get posixUser(): PosixUserPropertyList;
        putPosixUser(value: PosixUserProperty[] | cdktn.IResolvable): void;
        resetPosixUser(): void;
        get posixUserInput(): cdktn.IResolvable | PosixUserProperty[] | undefined;
    }
    class FileSystemIdentityPropertyList extends cdktn.ComplexList {
        internalValue?: FileSystemIdentityProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): FileSystemIdentityPropertyOutputReference;
    }
    interface OpenzfsConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_s3_access_point_attachment#volume_id AwsFsxS3AccessPointAttachment#volume_id}
        */
        readonly volumeId: string;
        /**
        * file_system_identity block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_s3_access_point_attachment#file_system_identity AwsFsxS3AccessPointAttachment#file_system_identity}
        */
        readonly fileSystemIdentity?: FileSystemIdentityProperty[] | cdktn.IResolvable;
    }
    class OpenzfsConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): OpenzfsConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: OpenzfsConfigurationProperty | cdktn.IResolvable | undefined);
        private _volumeId?;
        get volumeId(): string;
        set volumeId(value: string);
        get volumeIdInput(): string | undefined;
        private _fileSystemIdentity;
        get fileSystemIdentity(): FileSystemIdentityPropertyList;
        putFileSystemIdentity(value: FileSystemIdentityProperty[] | cdktn.IResolvable): void;
        resetFileSystemIdentity(): void;
        get fileSystemIdentityInput(): cdktn.IResolvable | FileSystemIdentityProperty[] | undefined;
    }
    class OpenzfsConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: OpenzfsConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): OpenzfsConfigurationPropertyOutputReference;
    }
    interface VpcConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_s3_access_point_attachment#vpc_id AwsFsxS3AccessPointAttachment#vpc_id}
        */
        readonly vpcId?: string;
    }
    class VpcConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): VpcConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: VpcConfigurationProperty | cdktn.IResolvable | undefined);
        private _vpcId?;
        get vpcId(): string;
        set vpcId(value: string);
        resetVpcId(): void;
        get vpcIdInput(): string | undefined;
    }
    class VpcConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: VpcConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): VpcConfigurationPropertyOutputReference;
    }
    interface S3AccessPointProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_s3_access_point_attachment#policy AwsFsxS3AccessPointAttachment#policy}
        */
        readonly policy?: string;
        /**
        * vpc_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_s3_access_point_attachment#vpc_configuration AwsFsxS3AccessPointAttachment#vpc_configuration}
        */
        readonly vpcConfiguration?: VpcConfigurationProperty[] | cdktn.IResolvable;
    }
    class S3AccessPointPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): S3AccessPointProperty | cdktn.IResolvable | undefined;
        set internalValue(value: S3AccessPointProperty | cdktn.IResolvable | undefined);
        private _policy?;
        get policy(): string;
        set policy(value: string);
        resetPolicy(): void;
        get policyInput(): string | undefined;
        private _vpcConfiguration;
        get vpcConfiguration(): VpcConfigurationPropertyList;
        putVpcConfiguration(value: VpcConfigurationProperty[] | cdktn.IResolvable): void;
        resetVpcConfiguration(): void;
        get vpcConfigurationInput(): cdktn.IResolvable | VpcConfigurationProperty[] | undefined;
    }
    class S3AccessPointPropertyList extends cdktn.ComplexList {
        internalValue?: S3AccessPointProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): S3AccessPointPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_s3_access_point_attachment#create AwsFsxS3AccessPointAttachment#create}
        */
        readonly create?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Setting a timeout for a Delete operation is only applicable if changes are saved into state before the destroy operation occurs.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_s3_access_point_attachment#delete AwsFsxS3AccessPointAttachment#delete}
        */
        readonly delete?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
    }
}
