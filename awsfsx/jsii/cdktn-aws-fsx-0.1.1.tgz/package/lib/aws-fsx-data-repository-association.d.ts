import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsFsxDataRepositoryAssociationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_data_repository_association#batch_import_meta_data_on_create AwsFsxDataRepositoryAssociation#batch_import_meta_data_on_create}
    */
    readonly batchImportMetaDataOnCreate?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_data_repository_association#data_repository_path AwsFsxDataRepositoryAssociation#data_repository_path}
    */
    readonly dataRepositoryPath: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_data_repository_association#delete_data_in_filesystem AwsFsxDataRepositoryAssociation#delete_data_in_filesystem}
    */
    readonly deleteDataInFilesystem?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_data_repository_association#file_system_id AwsFsxDataRepositoryAssociation#file_system_id}
    */
    readonly fileSystemId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_data_repository_association#file_system_path AwsFsxDataRepositoryAssociation#file_system_path}
    */
    readonly fileSystemPath: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_data_repository_association#id AwsFsxDataRepositoryAssociation#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_data_repository_association#imported_file_chunk_size AwsFsxDataRepositoryAssociation#imported_file_chunk_size}
    */
    readonly importedFileChunkSize?: number;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_data_repository_association#region AwsFsxDataRepositoryAssociation#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_data_repository_association#tags AwsFsxDataRepositoryAssociation#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_data_repository_association#tags_all AwsFsxDataRepositoryAssociation#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * s3 block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_data_repository_association#s3 AwsFsxDataRepositoryAssociation#s3}
    */
    readonly s3?: AwsFsxDataRepositoryAssociation.S3Property;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_data_repository_association#timeouts AwsFsxDataRepositoryAssociation#timeouts}
    */
    readonly timeouts?: AwsFsxDataRepositoryAssociation.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_data_repository_association aws_fsx_data_repository_association}
*/
export declare class AwsFsxDataRepositoryAssociation extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_fsx_data_repository_association";
    /**
    * Generates CDKTN code for importing a AwsFsxDataRepositoryAssociation resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsFsxDataRepositoryAssociation to import
    * @param importFromId The id of the existing AwsFsxDataRepositoryAssociation that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_data_repository_association#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsFsxDataRepositoryAssociation to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_data_repository_association aws_fsx_data_repository_association} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsFsxDataRepositoryAssociationConfig
    */
    constructor(scope: Construct, id: string, config: AwsFsxDataRepositoryAssociationConfig);
    get arn(): string;
    get associationId(): string;
    private _batchImportMetaDataOnCreate?;
    get batchImportMetaDataOnCreate(): boolean | cdktn.IResolvable;
    set batchImportMetaDataOnCreate(value: boolean | cdktn.IResolvable);
    resetBatchImportMetaDataOnCreate(): void;
    get batchImportMetaDataOnCreateInput(): boolean | cdktn.IResolvable | undefined;
    private _dataRepositoryPath?;
    get dataRepositoryPath(): string;
    set dataRepositoryPath(value: string);
    get dataRepositoryPathInput(): string | undefined;
    private _deleteDataInFilesystem?;
    get deleteDataInFilesystem(): boolean | cdktn.IResolvable;
    set deleteDataInFilesystem(value: boolean | cdktn.IResolvable);
    resetDeleteDataInFilesystem(): void;
    get deleteDataInFilesystemInput(): boolean | cdktn.IResolvable | undefined;
    private _fileSystemId?;
    get fileSystemId(): string;
    set fileSystemId(value: string);
    get fileSystemIdInput(): string | undefined;
    private _fileSystemPath?;
    get fileSystemPath(): string;
    set fileSystemPath(value: string);
    get fileSystemPathInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _importedFileChunkSize?;
    get importedFileChunkSize(): number;
    set importedFileChunkSize(value: number);
    resetImportedFileChunkSize(): void;
    get importedFileChunkSizeInput(): number | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _s3;
    get s3(): AwsFsxDataRepositoryAssociation.S3PropertyOutputReference;
    putS3(value: AwsFsxDataRepositoryAssociation.S3Property): void;
    resetS3(): void;
    get s3Input(): AwsFsxDataRepositoryAssociation.S3Property | undefined;
    private _timeouts;
    get timeouts(): AwsFsxDataRepositoryAssociation.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsFsxDataRepositoryAssociation.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsFsxDataRepositoryAssociation.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsFsxDataRepositoryAssociationAutoExportPolicyPropertyToTerraform(struct?: AwsFsxDataRepositoryAssociation.AutoExportPolicyPropertyOutputReference | AwsFsxDataRepositoryAssociation.AutoExportPolicyProperty): any;
export declare function awsFsxDataRepositoryAssociationAutoExportPolicyPropertyToHclTerraform(struct?: AwsFsxDataRepositoryAssociation.AutoExportPolicyPropertyOutputReference | AwsFsxDataRepositoryAssociation.AutoExportPolicyProperty): any;
export declare function awsFsxDataRepositoryAssociationAutoImportPolicyPropertyToTerraform(struct?: AwsFsxDataRepositoryAssociation.AutoImportPolicyPropertyOutputReference | AwsFsxDataRepositoryAssociation.AutoImportPolicyProperty): any;
export declare function awsFsxDataRepositoryAssociationAutoImportPolicyPropertyToHclTerraform(struct?: AwsFsxDataRepositoryAssociation.AutoImportPolicyPropertyOutputReference | AwsFsxDataRepositoryAssociation.AutoImportPolicyProperty): any;
export declare function awsFsxDataRepositoryAssociationS3PropertyToTerraform(struct?: AwsFsxDataRepositoryAssociation.S3PropertyOutputReference | AwsFsxDataRepositoryAssociation.S3Property): any;
export declare function awsFsxDataRepositoryAssociationS3PropertyToHclTerraform(struct?: AwsFsxDataRepositoryAssociation.S3PropertyOutputReference | AwsFsxDataRepositoryAssociation.S3Property): any;
export declare function awsFsxDataRepositoryAssociationTimeoutsPropertyToTerraform(struct?: AwsFsxDataRepositoryAssociation.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsFsxDataRepositoryAssociationTimeoutsPropertyToHclTerraform(struct?: AwsFsxDataRepositoryAssociation.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsFsxDataRepositoryAssociation {
    interface AutoExportPolicyProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_data_repository_association#events AwsFsxDataRepositoryAssociation#events}
        */
        readonly events?: string[];
    }
    class AutoExportPolicyPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AutoExportPolicyProperty | undefined;
        set internalValue(value: AutoExportPolicyProperty | undefined);
        private _events?;
        get events(): string[];
        set events(value: string[]);
        resetEvents(): void;
        get eventsInput(): string[] | undefined;
    }
    interface AutoImportPolicyProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_data_repository_association#events AwsFsxDataRepositoryAssociation#events}
        */
        readonly events?: string[];
    }
    class AutoImportPolicyPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AutoImportPolicyProperty | undefined;
        set internalValue(value: AutoImportPolicyProperty | undefined);
        private _events?;
        get events(): string[];
        set events(value: string[]);
        resetEvents(): void;
        get eventsInput(): string[] | undefined;
    }
    interface S3Property {
        /**
        * auto_export_policy block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_data_repository_association#auto_export_policy AwsFsxDataRepositoryAssociation#auto_export_policy}
        */
        readonly autoExportPolicy?: AutoExportPolicyProperty;
        /**
        * auto_import_policy block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_data_repository_association#auto_import_policy AwsFsxDataRepositoryAssociation#auto_import_policy}
        */
        readonly autoImportPolicy?: AutoImportPolicyProperty;
    }
    class S3PropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): S3Property | undefined;
        set internalValue(value: S3Property | undefined);
        private _autoExportPolicy;
        get autoExportPolicy(): AutoExportPolicyPropertyOutputReference;
        putAutoExportPolicy(value: AutoExportPolicyProperty): void;
        resetAutoExportPolicy(): void;
        get autoExportPolicyInput(): AutoExportPolicyProperty | undefined;
        private _autoImportPolicy;
        get autoImportPolicy(): AutoImportPolicyPropertyOutputReference;
        putAutoImportPolicy(value: AutoImportPolicyProperty): void;
        resetAutoImportPolicy(): void;
        get autoImportPolicyInput(): AutoImportPolicyProperty | undefined;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_data_repository_association#create AwsFsxDataRepositoryAssociation#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_data_repository_association#delete AwsFsxDataRepositoryAssociation#delete}
        */
        readonly delete?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_data_repository_association#update AwsFsxDataRepositoryAssociation#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
