import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfLustreFileSystemConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_lustre_file_system#auto_import_policy TfLustreFileSystem#auto_import_policy}
    */
    readonly autoImportPolicy?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_lustre_file_system#automatic_backup_retention_days TfLustreFileSystem#automatic_backup_retention_days}
    */
    readonly automaticBackupRetentionDays?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_lustre_file_system#backup_id TfLustreFileSystem#backup_id}
    */
    readonly backupId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_lustre_file_system#copy_tags_to_backups TfLustreFileSystem#copy_tags_to_backups}
    */
    readonly copyTagsToBackups?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_lustre_file_system#daily_automatic_backup_start_time TfLustreFileSystem#daily_automatic_backup_start_time}
    */
    readonly dailyAutomaticBackupStartTime?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_lustre_file_system#data_compression_type TfLustreFileSystem#data_compression_type}
    */
    readonly dataCompressionType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_lustre_file_system#deployment_type TfLustreFileSystem#deployment_type}
    */
    readonly deploymentType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_lustre_file_system#drive_cache_type TfLustreFileSystem#drive_cache_type}
    */
    readonly driveCacheType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_lustre_file_system#efa_enabled TfLustreFileSystem#efa_enabled}
    */
    readonly efaEnabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_lustre_file_system#export_path TfLustreFileSystem#export_path}
    */
    readonly exportPath?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_lustre_file_system#file_system_type_version TfLustreFileSystem#file_system_type_version}
    */
    readonly fileSystemTypeVersion?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_lustre_file_system#final_backup_tags TfLustreFileSystem#final_backup_tags}
    */
    readonly finalBackupTags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_lustre_file_system#id TfLustreFileSystem#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_lustre_file_system#import_path TfLustreFileSystem#import_path}
    */
    readonly importPath?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_lustre_file_system#imported_file_chunk_size TfLustreFileSystem#imported_file_chunk_size}
    */
    readonly importedFileChunkSize?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_lustre_file_system#kms_key_id TfLustreFileSystem#kms_key_id}
    */
    readonly kmsKeyId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_lustre_file_system#per_unit_storage_throughput TfLustreFileSystem#per_unit_storage_throughput}
    */
    readonly perUnitStorageThroughput?: number;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_lustre_file_system#region TfLustreFileSystem#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_lustre_file_system#security_group_ids TfLustreFileSystem#security_group_ids}
    */
    readonly securityGroupIds?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_lustre_file_system#skip_final_backup TfLustreFileSystem#skip_final_backup}
    */
    readonly skipFinalBackup?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_lustre_file_system#storage_capacity TfLustreFileSystem#storage_capacity}
    */
    readonly storageCapacity?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_lustre_file_system#storage_type TfLustreFileSystem#storage_type}
    */
    readonly storageType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_lustre_file_system#subnet_ids TfLustreFileSystem#subnet_ids}
    */
    readonly subnetIds: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_lustre_file_system#tags TfLustreFileSystem#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_lustre_file_system#tags_all TfLustreFileSystem#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_lustre_file_system#throughput_capacity TfLustreFileSystem#throughput_capacity}
    */
    readonly throughputCapacity?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_lustre_file_system#weekly_maintenance_start_time TfLustreFileSystem#weekly_maintenance_start_time}
    */
    readonly weeklyMaintenanceStartTime?: string;
    /**
    * data_read_cache_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_lustre_file_system#data_read_cache_configuration TfLustreFileSystem#data_read_cache_configuration}
    */
    readonly dataReadCacheConfiguration?: TfLustreFileSystem.DataReadCacheConfigurationProperty;
    /**
    * log_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_lustre_file_system#log_configuration TfLustreFileSystem#log_configuration}
    */
    readonly logConfiguration?: TfLustreFileSystem.LogConfigurationProperty;
    /**
    * metadata_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_lustre_file_system#metadata_configuration TfLustreFileSystem#metadata_configuration}
    */
    readonly metadataConfiguration?: TfLustreFileSystem.MetadataConfigurationProperty;
    /**
    * root_squash_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_lustre_file_system#root_squash_configuration TfLustreFileSystem#root_squash_configuration}
    */
    readonly rootSquashConfiguration?: TfLustreFileSystem.RootSquashConfigurationProperty;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_lustre_file_system#timeouts TfLustreFileSystem#timeouts}
    */
    readonly timeouts?: TfLustreFileSystem.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_lustre_file_system aws_fsx_lustre_file_system}
*/
export declare class TfLustreFileSystem extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_fsx_lustre_file_system";
    /**
    * Generates CDKTN code for importing a TfLustreFileSystem resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfLustreFileSystem to import
    * @param importFromId The id of the existing TfLustreFileSystem that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_lustre_file_system#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfLustreFileSystem to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_lustre_file_system aws_fsx_lustre_file_system} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfLustreFileSystemConfig
    */
    constructor(scope: Construct, id: string, config: TfLustreFileSystemConfig);
    get arn(): string;
    private _autoImportPolicy?;
    get autoImportPolicy(): string;
    set autoImportPolicy(value: string);
    resetAutoImportPolicy(): void;
    get autoImportPolicyInput(): string | undefined;
    private _automaticBackupRetentionDays?;
    get automaticBackupRetentionDays(): number;
    set automaticBackupRetentionDays(value: number);
    resetAutomaticBackupRetentionDays(): void;
    get automaticBackupRetentionDaysInput(): number | undefined;
    private _backupId?;
    get backupId(): string;
    set backupId(value: string);
    resetBackupId(): void;
    get backupIdInput(): string | undefined;
    private _copyTagsToBackups?;
    get copyTagsToBackups(): boolean | cdktn.IResolvable;
    set copyTagsToBackups(value: boolean | cdktn.IResolvable);
    resetCopyTagsToBackups(): void;
    get copyTagsToBackupsInput(): boolean | cdktn.IResolvable | undefined;
    private _dailyAutomaticBackupStartTime?;
    get dailyAutomaticBackupStartTime(): string;
    set dailyAutomaticBackupStartTime(value: string);
    resetDailyAutomaticBackupStartTime(): void;
    get dailyAutomaticBackupStartTimeInput(): string | undefined;
    private _dataCompressionType?;
    get dataCompressionType(): string;
    set dataCompressionType(value: string);
    resetDataCompressionType(): void;
    get dataCompressionTypeInput(): string | undefined;
    private _deploymentType?;
    get deploymentType(): string;
    set deploymentType(value: string);
    resetDeploymentType(): void;
    get deploymentTypeInput(): string | undefined;
    get dnsName(): string;
    private _driveCacheType?;
    get driveCacheType(): string;
    set driveCacheType(value: string);
    resetDriveCacheType(): void;
    get driveCacheTypeInput(): string | undefined;
    private _efaEnabled?;
    get efaEnabled(): boolean | cdktn.IResolvable;
    set efaEnabled(value: boolean | cdktn.IResolvable);
    resetEfaEnabled(): void;
    get efaEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _exportPath?;
    get exportPath(): string;
    set exportPath(value: string);
    resetExportPath(): void;
    get exportPathInput(): string | undefined;
    private _fileSystemTypeVersion?;
    get fileSystemTypeVersion(): string;
    set fileSystemTypeVersion(value: string);
    resetFileSystemTypeVersion(): void;
    get fileSystemTypeVersionInput(): string | undefined;
    private _finalBackupTags?;
    get finalBackupTags(): {
        [key: string]: string;
    };
    set finalBackupTags(value: {
        [key: string]: string;
    });
    resetFinalBackupTags(): void;
    get finalBackupTagsInput(): {
        [key: string]: string;
    } | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _importPath?;
    get importPath(): string;
    set importPath(value: string);
    resetImportPath(): void;
    get importPathInput(): string | undefined;
    private _importedFileChunkSize?;
    get importedFileChunkSize(): number;
    set importedFileChunkSize(value: number);
    resetImportedFileChunkSize(): void;
    get importedFileChunkSizeInput(): number | undefined;
    private _kmsKeyId?;
    get kmsKeyId(): string;
    set kmsKeyId(value: string);
    resetKmsKeyId(): void;
    get kmsKeyIdInput(): string | undefined;
    get mountName(): string;
    get networkInterfaceIds(): string[];
    get ownerId(): string;
    private _perUnitStorageThroughput?;
    get perUnitStorageThroughput(): number;
    set perUnitStorageThroughput(value: number);
    resetPerUnitStorageThroughput(): void;
    get perUnitStorageThroughputInput(): number | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _securityGroupIds?;
    get securityGroupIds(): string[];
    set securityGroupIds(value: string[]);
    resetSecurityGroupIds(): void;
    get securityGroupIdsInput(): string[] | undefined;
    private _skipFinalBackup?;
    get skipFinalBackup(): boolean | cdktn.IResolvable;
    set skipFinalBackup(value: boolean | cdktn.IResolvable);
    resetSkipFinalBackup(): void;
    get skipFinalBackupInput(): boolean | cdktn.IResolvable | undefined;
    private _storageCapacity?;
    get storageCapacity(): number;
    set storageCapacity(value: number);
    resetStorageCapacity(): void;
    get storageCapacityInput(): number | undefined;
    private _storageType?;
    get storageType(): string;
    set storageType(value: string);
    resetStorageType(): void;
    get storageTypeInput(): string | undefined;
    private _subnetIds?;
    get subnetIds(): string[];
    set subnetIds(value: string[]);
    get subnetIdsInput(): string[] | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _throughputCapacity?;
    get throughputCapacity(): number;
    set throughputCapacity(value: number);
    resetThroughputCapacity(): void;
    get throughputCapacityInput(): number | undefined;
    get vpcId(): string;
    private _weeklyMaintenanceStartTime?;
    get weeklyMaintenanceStartTime(): string;
    set weeklyMaintenanceStartTime(value: string);
    resetWeeklyMaintenanceStartTime(): void;
    get weeklyMaintenanceStartTimeInput(): string | undefined;
    private _dataReadCacheConfiguration;
    get dataReadCacheConfiguration(): TfLustreFileSystem.DataReadCacheConfigurationPropertyOutputReference;
    putDataReadCacheConfiguration(value: TfLustreFileSystem.DataReadCacheConfigurationProperty): void;
    resetDataReadCacheConfiguration(): void;
    get dataReadCacheConfigurationInput(): TfLustreFileSystem.DataReadCacheConfigurationProperty | undefined;
    private _logConfiguration;
    get logConfiguration(): TfLustreFileSystem.LogConfigurationPropertyOutputReference;
    putLogConfiguration(value: TfLustreFileSystem.LogConfigurationProperty): void;
    resetLogConfiguration(): void;
    get logConfigurationInput(): TfLustreFileSystem.LogConfigurationProperty | undefined;
    private _metadataConfiguration;
    get metadataConfiguration(): TfLustreFileSystem.MetadataConfigurationPropertyOutputReference;
    putMetadataConfiguration(value: TfLustreFileSystem.MetadataConfigurationProperty): void;
    resetMetadataConfiguration(): void;
    get metadataConfigurationInput(): TfLustreFileSystem.MetadataConfigurationProperty | undefined;
    private _rootSquashConfiguration;
    get rootSquashConfiguration(): TfLustreFileSystem.RootSquashConfigurationPropertyOutputReference;
    putRootSquashConfiguration(value: TfLustreFileSystem.RootSquashConfigurationProperty): void;
    resetRootSquashConfiguration(): void;
    get rootSquashConfigurationInput(): TfLustreFileSystem.RootSquashConfigurationProperty | undefined;
    private _timeouts;
    get timeouts(): TfLustreFileSystem.TimeoutsPropertyOutputReference;
    putTimeouts(value: TfLustreFileSystem.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | TfLustreFileSystem.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfLustreFileSystemDataReadCacheConfigurationPropertyToTerraform(struct?: TfLustreFileSystem.DataReadCacheConfigurationPropertyOutputReference | TfLustreFileSystem.DataReadCacheConfigurationProperty): any;
export declare function tfLustreFileSystemDataReadCacheConfigurationPropertyToHclTerraform(struct?: TfLustreFileSystem.DataReadCacheConfigurationPropertyOutputReference | TfLustreFileSystem.DataReadCacheConfigurationProperty): any;
export declare function tfLustreFileSystemLogConfigurationPropertyToTerraform(struct?: TfLustreFileSystem.LogConfigurationPropertyOutputReference | TfLustreFileSystem.LogConfigurationProperty): any;
export declare function tfLustreFileSystemLogConfigurationPropertyToHclTerraform(struct?: TfLustreFileSystem.LogConfigurationPropertyOutputReference | TfLustreFileSystem.LogConfigurationProperty): any;
export declare function tfLustreFileSystemMetadataConfigurationPropertyToTerraform(struct?: TfLustreFileSystem.MetadataConfigurationPropertyOutputReference | TfLustreFileSystem.MetadataConfigurationProperty): any;
export declare function tfLustreFileSystemMetadataConfigurationPropertyToHclTerraform(struct?: TfLustreFileSystem.MetadataConfigurationPropertyOutputReference | TfLustreFileSystem.MetadataConfigurationProperty): any;
export declare function tfLustreFileSystemRootSquashConfigurationPropertyToTerraform(struct?: TfLustreFileSystem.RootSquashConfigurationPropertyOutputReference | TfLustreFileSystem.RootSquashConfigurationProperty): any;
export declare function tfLustreFileSystemRootSquashConfigurationPropertyToHclTerraform(struct?: TfLustreFileSystem.RootSquashConfigurationPropertyOutputReference | TfLustreFileSystem.RootSquashConfigurationProperty): any;
export declare function tfLustreFileSystemTimeoutsPropertyToTerraform(struct?: TfLustreFileSystem.TimeoutsProperty | cdktn.IResolvable): any;
export declare function tfLustreFileSystemTimeoutsPropertyToHclTerraform(struct?: TfLustreFileSystem.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace TfLustreFileSystem {
    interface DataReadCacheConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_lustre_file_system#size TfLustreFileSystem#size}
        */
        readonly size?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_lustre_file_system#sizing_mode TfLustreFileSystem#sizing_mode}
        */
        readonly sizingMode: string;
    }
    class DataReadCacheConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DataReadCacheConfigurationProperty | undefined;
        set internalValue(value: DataReadCacheConfigurationProperty | undefined);
        private _size?;
        get size(): number;
        set size(value: number);
        resetSize(): void;
        get sizeInput(): number | undefined;
        private _sizingMode?;
        get sizingMode(): string;
        set sizingMode(value: string);
        get sizingModeInput(): string | undefined;
    }
    interface LogConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_lustre_file_system#destination TfLustreFileSystem#destination}
        */
        readonly destination?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_lustre_file_system#level TfLustreFileSystem#level}
        */
        readonly level?: string;
    }
    class LogConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): LogConfigurationProperty | undefined;
        set internalValue(value: LogConfigurationProperty | undefined);
        private _destination?;
        get destination(): string;
        set destination(value: string);
        resetDestination(): void;
        get destinationInput(): string | undefined;
        private _level?;
        get level(): string;
        set level(value: string);
        resetLevel(): void;
        get levelInput(): string | undefined;
    }
    interface MetadataConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_lustre_file_system#iops TfLustreFileSystem#iops}
        */
        readonly iops?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_lustre_file_system#mode TfLustreFileSystem#mode}
        */
        readonly mode?: string;
    }
    class MetadataConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): MetadataConfigurationProperty | undefined;
        set internalValue(value: MetadataConfigurationProperty | undefined);
        private _iops?;
        get iops(): number;
        set iops(value: number);
        resetIops(): void;
        get iopsInput(): number | undefined;
        private _mode?;
        get mode(): string;
        set mode(value: string);
        resetMode(): void;
        get modeInput(): string | undefined;
    }
    interface RootSquashConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_lustre_file_system#no_squash_nids TfLustreFileSystem#no_squash_nids}
        */
        readonly noSquashNids?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_lustre_file_system#root_squash TfLustreFileSystem#root_squash}
        */
        readonly rootSquash?: string;
    }
    class RootSquashConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RootSquashConfigurationProperty | undefined;
        set internalValue(value: RootSquashConfigurationProperty | undefined);
        private _noSquashNids?;
        get noSquashNids(): string[];
        set noSquashNids(value: string[]);
        resetNoSquashNids(): void;
        get noSquashNidsInput(): string[] | undefined;
        private _rootSquash?;
        get rootSquash(): string;
        set rootSquash(value: string);
        resetRootSquash(): void;
        get rootSquashInput(): string | undefined;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_lustre_file_system#create TfLustreFileSystem#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_lustre_file_system#delete TfLustreFileSystem#delete}
        */
        readonly delete?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_lustre_file_system#update TfLustreFileSystem#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
