import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfOntapStorageVirtualMachineConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_ontap_storage_virtual_machine#file_system_id TfOntapStorageVirtualMachine#file_system_id}
    */
    readonly fileSystemId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_ontap_storage_virtual_machine#id TfOntapStorageVirtualMachine#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_ontap_storage_virtual_machine#name TfOntapStorageVirtualMachine#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_ontap_storage_virtual_machine#region TfOntapStorageVirtualMachine#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_ontap_storage_virtual_machine#root_volume_security_style TfOntapStorageVirtualMachine#root_volume_security_style}
    */
    readonly rootVolumeSecurityStyle?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_ontap_storage_virtual_machine#svm_admin_password TfOntapStorageVirtualMachine#svm_admin_password}
    */
    readonly svmAdminPassword?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_ontap_storage_virtual_machine#tags TfOntapStorageVirtualMachine#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_ontap_storage_virtual_machine#tags_all TfOntapStorageVirtualMachine#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * active_directory_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_ontap_storage_virtual_machine#active_directory_configuration TfOntapStorageVirtualMachine#active_directory_configuration}
    */
    readonly activeDirectoryConfiguration?: TfOntapStorageVirtualMachine.ActiveDirectoryConfigurationProperty;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_ontap_storage_virtual_machine#timeouts TfOntapStorageVirtualMachine#timeouts}
    */
    readonly timeouts?: TfOntapStorageVirtualMachine.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_ontap_storage_virtual_machine aws_fsx_ontap_storage_virtual_machine}
*/
export declare class TfOntapStorageVirtualMachine extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_fsx_ontap_storage_virtual_machine";
    /**
    * Generates CDKTN code for importing a TfOntapStorageVirtualMachine resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfOntapStorageVirtualMachine to import
    * @param importFromId The id of the existing TfOntapStorageVirtualMachine that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_ontap_storage_virtual_machine#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfOntapStorageVirtualMachine to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_ontap_storage_virtual_machine aws_fsx_ontap_storage_virtual_machine} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfOntapStorageVirtualMachineConfig
    */
    constructor(scope: Construct, id: string, config: TfOntapStorageVirtualMachineConfig);
    get arn(): string;
    private _endpoints;
    get endpoints(): TfOntapStorageVirtualMachine.EndpointsPropertyList;
    private _fileSystemId?;
    get fileSystemId(): string;
    set fileSystemId(value: string);
    get fileSystemIdInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _rootVolumeSecurityStyle?;
    get rootVolumeSecurityStyle(): string;
    set rootVolumeSecurityStyle(value: string);
    resetRootVolumeSecurityStyle(): void;
    get rootVolumeSecurityStyleInput(): string | undefined;
    get subtype(): string;
    private _svmAdminPassword?;
    get svmAdminPassword(): string;
    set svmAdminPassword(value: string);
    resetSvmAdminPassword(): void;
    get svmAdminPasswordInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    get uuid(): string;
    private _activeDirectoryConfiguration;
    get activeDirectoryConfiguration(): TfOntapStorageVirtualMachine.ActiveDirectoryConfigurationPropertyOutputReference;
    putActiveDirectoryConfiguration(value: TfOntapStorageVirtualMachine.ActiveDirectoryConfigurationProperty): void;
    resetActiveDirectoryConfiguration(): void;
    get activeDirectoryConfigurationInput(): TfOntapStorageVirtualMachine.ActiveDirectoryConfigurationProperty | undefined;
    private _timeouts;
    get timeouts(): TfOntapStorageVirtualMachine.TimeoutsPropertyOutputReference;
    putTimeouts(value: TfOntapStorageVirtualMachine.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | TfOntapStorageVirtualMachine.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfOntapStorageVirtualMachineIscsiPropertyToTerraform(struct?: TfOntapStorageVirtualMachine.IscsiProperty): any;
export declare function tfOntapStorageVirtualMachineIscsiPropertyToHclTerraform(struct?: TfOntapStorageVirtualMachine.IscsiProperty): any;
export declare function tfOntapStorageVirtualMachineManagementPropertyToTerraform(struct?: TfOntapStorageVirtualMachine.ManagementProperty): any;
export declare function tfOntapStorageVirtualMachineManagementPropertyToHclTerraform(struct?: TfOntapStorageVirtualMachine.ManagementProperty): any;
export declare function tfOntapStorageVirtualMachineNfsPropertyToTerraform(struct?: TfOntapStorageVirtualMachine.NfsProperty): any;
export declare function tfOntapStorageVirtualMachineNfsPropertyToHclTerraform(struct?: TfOntapStorageVirtualMachine.NfsProperty): any;
export declare function tfOntapStorageVirtualMachineSmbPropertyToTerraform(struct?: TfOntapStorageVirtualMachine.SmbProperty): any;
export declare function tfOntapStorageVirtualMachineSmbPropertyToHclTerraform(struct?: TfOntapStorageVirtualMachine.SmbProperty): any;
export declare function tfOntapStorageVirtualMachineEndpointsPropertyToTerraform(struct?: TfOntapStorageVirtualMachine.EndpointsProperty): any;
export declare function tfOntapStorageVirtualMachineEndpointsPropertyToHclTerraform(struct?: TfOntapStorageVirtualMachine.EndpointsProperty): any;
export declare function tfOntapStorageVirtualMachineSelfManagedActiveDirectoryConfigurationPropertyToTerraform(struct?: TfOntapStorageVirtualMachine.SelfManagedActiveDirectoryConfigurationPropertyOutputReference | TfOntapStorageVirtualMachine.SelfManagedActiveDirectoryConfigurationProperty): any;
export declare function tfOntapStorageVirtualMachineSelfManagedActiveDirectoryConfigurationPropertyToHclTerraform(struct?: TfOntapStorageVirtualMachine.SelfManagedActiveDirectoryConfigurationPropertyOutputReference | TfOntapStorageVirtualMachine.SelfManagedActiveDirectoryConfigurationProperty): any;
export declare function tfOntapStorageVirtualMachineActiveDirectoryConfigurationPropertyToTerraform(struct?: TfOntapStorageVirtualMachine.ActiveDirectoryConfigurationPropertyOutputReference | TfOntapStorageVirtualMachine.ActiveDirectoryConfigurationProperty): any;
export declare function tfOntapStorageVirtualMachineActiveDirectoryConfigurationPropertyToHclTerraform(struct?: TfOntapStorageVirtualMachine.ActiveDirectoryConfigurationPropertyOutputReference | TfOntapStorageVirtualMachine.ActiveDirectoryConfigurationProperty): any;
export declare function tfOntapStorageVirtualMachineTimeoutsPropertyToTerraform(struct?: TfOntapStorageVirtualMachine.TimeoutsProperty | cdktn.IResolvable): any;
export declare function tfOntapStorageVirtualMachineTimeoutsPropertyToHclTerraform(struct?: TfOntapStorageVirtualMachine.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace TfOntapStorageVirtualMachine {
    interface IscsiProperty {
    }
    class IscsiPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): IscsiProperty | undefined;
        set internalValue(value: IscsiProperty | undefined);
        get dnsName(): string;
        get ipAddresses(): string[];
    }
    class IscsiPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): IscsiPropertyOutputReference;
    }
    interface ManagementProperty {
    }
    class ManagementPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ManagementProperty | undefined;
        set internalValue(value: ManagementProperty | undefined);
        get dnsName(): string;
        get ipAddresses(): string[];
    }
    class ManagementPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ManagementPropertyOutputReference;
    }
    interface NfsProperty {
    }
    class NfsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): NfsProperty | undefined;
        set internalValue(value: NfsProperty | undefined);
        get dnsName(): string;
        get ipAddresses(): string[];
    }
    class NfsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): NfsPropertyOutputReference;
    }
    interface SmbProperty {
    }
    class SmbPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SmbProperty | undefined;
        set internalValue(value: SmbProperty | undefined);
        get dnsName(): string;
        get ipAddresses(): string[];
    }
    class SmbPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SmbPropertyOutputReference;
    }
    interface EndpointsProperty {
    }
    class EndpointsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EndpointsProperty | undefined;
        set internalValue(value: EndpointsProperty | undefined);
        private _iscsi;
        get iscsi(): IscsiPropertyList;
        private _management;
        get management(): ManagementPropertyList;
        private _nfs;
        get nfs(): NfsPropertyList;
        private _smb;
        get smb(): SmbPropertyList;
    }
    class EndpointsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EndpointsPropertyOutputReference;
    }
    interface SelfManagedActiveDirectoryConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_ontap_storage_virtual_machine#dns_ips TfOntapStorageVirtualMachine#dns_ips}
        */
        readonly dnsIps: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_ontap_storage_virtual_machine#domain_name TfOntapStorageVirtualMachine#domain_name}
        */
        readonly domainName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_ontap_storage_virtual_machine#file_system_administrators_group TfOntapStorageVirtualMachine#file_system_administrators_group}
        */
        readonly fileSystemAdministratorsGroup?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_ontap_storage_virtual_machine#organizational_unit_distinguished_name TfOntapStorageVirtualMachine#organizational_unit_distinguished_name}
        */
        readonly organizationalUnitDistinguishedName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_ontap_storage_virtual_machine#password TfOntapStorageVirtualMachine#password}
        */
        readonly password: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_ontap_storage_virtual_machine#username TfOntapStorageVirtualMachine#username}
        */
        readonly username: string;
    }
    class SelfManagedActiveDirectoryConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SelfManagedActiveDirectoryConfigurationProperty | undefined;
        set internalValue(value: SelfManagedActiveDirectoryConfigurationProperty | undefined);
        private _dnsIps?;
        get dnsIps(): string[];
        set dnsIps(value: string[]);
        get dnsIpsInput(): string[] | undefined;
        private _domainName?;
        get domainName(): string;
        set domainName(value: string);
        get domainNameInput(): string | undefined;
        private _fileSystemAdministratorsGroup?;
        get fileSystemAdministratorsGroup(): string;
        set fileSystemAdministratorsGroup(value: string);
        resetFileSystemAdministratorsGroup(): void;
        get fileSystemAdministratorsGroupInput(): string | undefined;
        private _organizationalUnitDistinguishedName?;
        get organizationalUnitDistinguishedName(): string;
        set organizationalUnitDistinguishedName(value: string);
        resetOrganizationalUnitDistinguishedName(): void;
        get organizationalUnitDistinguishedNameInput(): string | undefined;
        private _password?;
        get password(): string;
        set password(value: string);
        get passwordInput(): string | undefined;
        private _username?;
        get username(): string;
        set username(value: string);
        get usernameInput(): string | undefined;
    }
    interface ActiveDirectoryConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_ontap_storage_virtual_machine#netbios_name TfOntapStorageVirtualMachine#netbios_name}
        */
        readonly netbiosName?: string;
        /**
        * self_managed_active_directory_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_ontap_storage_virtual_machine#self_managed_active_directory_configuration TfOntapStorageVirtualMachine#self_managed_active_directory_configuration}
        */
        readonly selfManagedActiveDirectoryConfiguration?: SelfManagedActiveDirectoryConfigurationProperty;
    }
    class ActiveDirectoryConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ActiveDirectoryConfigurationProperty | undefined;
        set internalValue(value: ActiveDirectoryConfigurationProperty | undefined);
        private _netbiosName?;
        get netbiosName(): string;
        set netbiosName(value: string);
        resetNetbiosName(): void;
        get netbiosNameInput(): string | undefined;
        private _selfManagedActiveDirectoryConfiguration;
        get selfManagedActiveDirectoryConfiguration(): SelfManagedActiveDirectoryConfigurationPropertyOutputReference;
        putSelfManagedActiveDirectoryConfiguration(value: SelfManagedActiveDirectoryConfigurationProperty): void;
        resetSelfManagedActiveDirectoryConfiguration(): void;
        get selfManagedActiveDirectoryConfigurationInput(): SelfManagedActiveDirectoryConfigurationProperty | undefined;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_ontap_storage_virtual_machine#create TfOntapStorageVirtualMachine#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_ontap_storage_virtual_machine#delete TfOntapStorageVirtualMachine#delete}
        */
        readonly delete?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_ontap_storage_virtual_machine#update TfOntapStorageVirtualMachine#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
