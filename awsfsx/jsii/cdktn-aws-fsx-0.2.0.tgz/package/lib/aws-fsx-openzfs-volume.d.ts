import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfOpenzfsVolumeConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_openzfs_volume#copy_tags_to_snapshots TfOpenzfsVolume#copy_tags_to_snapshots}
    */
    readonly copyTagsToSnapshots?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_openzfs_volume#data_compression_type TfOpenzfsVolume#data_compression_type}
    */
    readonly dataCompressionType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_openzfs_volume#delete_volume_options TfOpenzfsVolume#delete_volume_options}
    */
    readonly deleteVolumeOptions?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_openzfs_volume#id TfOpenzfsVolume#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_openzfs_volume#name TfOpenzfsVolume#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_openzfs_volume#parent_volume_id TfOpenzfsVolume#parent_volume_id}
    */
    readonly parentVolumeId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_openzfs_volume#read_only TfOpenzfsVolume#read_only}
    */
    readonly readOnly?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_openzfs_volume#record_size_kib TfOpenzfsVolume#record_size_kib}
    */
    readonly recordSizeKib?: number;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_openzfs_volume#region TfOpenzfsVolume#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_openzfs_volume#storage_capacity_quota_gib TfOpenzfsVolume#storage_capacity_quota_gib}
    */
    readonly storageCapacityQuotaGib?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_openzfs_volume#storage_capacity_reservation_gib TfOpenzfsVolume#storage_capacity_reservation_gib}
    */
    readonly storageCapacityReservationGib?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_openzfs_volume#tags TfOpenzfsVolume#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_openzfs_volume#tags_all TfOpenzfsVolume#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_openzfs_volume#volume_type TfOpenzfsVolume#volume_type}
    */
    readonly volumeType?: string;
    /**
    * nfs_exports block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_openzfs_volume#nfs_exports TfOpenzfsVolume#nfs_exports}
    */
    readonly nfsExports?: TfOpenzfsVolume.NfsExportsProperty;
    /**
    * origin_snapshot block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_openzfs_volume#origin_snapshot TfOpenzfsVolume#origin_snapshot}
    */
    readonly originSnapshot?: TfOpenzfsVolume.OriginSnapshotProperty;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_openzfs_volume#timeouts TfOpenzfsVolume#timeouts}
    */
    readonly timeouts?: TfOpenzfsVolume.TimeoutsProperty;
    /**
    * user_and_group_quotas block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_openzfs_volume#user_and_group_quotas TfOpenzfsVolume#user_and_group_quotas}
    */
    readonly userAndGroupQuotas?: TfOpenzfsVolume.UserAndGroupQuotasProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_openzfs_volume aws_fsx_openzfs_volume}
*/
export declare class TfOpenzfsVolume extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_fsx_openzfs_volume";
    /**
    * Generates CDKTN code for importing a TfOpenzfsVolume resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfOpenzfsVolume to import
    * @param importFromId The id of the existing TfOpenzfsVolume that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_openzfs_volume#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfOpenzfsVolume to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_openzfs_volume aws_fsx_openzfs_volume} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfOpenzfsVolumeConfig
    */
    constructor(scope: Construct, id: string, config: TfOpenzfsVolumeConfig);
    get arn(): string;
    private _copyTagsToSnapshots?;
    get copyTagsToSnapshots(): boolean | cdktn.IResolvable;
    set copyTagsToSnapshots(value: boolean | cdktn.IResolvable);
    resetCopyTagsToSnapshots(): void;
    get copyTagsToSnapshotsInput(): boolean | cdktn.IResolvable | undefined;
    private _dataCompressionType?;
    get dataCompressionType(): string;
    set dataCompressionType(value: string);
    resetDataCompressionType(): void;
    get dataCompressionTypeInput(): string | undefined;
    private _deleteVolumeOptions?;
    get deleteVolumeOptions(): string[];
    set deleteVolumeOptions(value: string[]);
    resetDeleteVolumeOptions(): void;
    get deleteVolumeOptionsInput(): string[] | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _parentVolumeId?;
    get parentVolumeId(): string;
    set parentVolumeId(value: string);
    get parentVolumeIdInput(): string | undefined;
    private _readOnly?;
    get readOnly(): boolean | cdktn.IResolvable;
    set readOnly(value: boolean | cdktn.IResolvable);
    resetReadOnly(): void;
    get readOnlyInput(): boolean | cdktn.IResolvable | undefined;
    private _recordSizeKib?;
    get recordSizeKib(): number;
    set recordSizeKib(value: number);
    resetRecordSizeKib(): void;
    get recordSizeKibInput(): number | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _storageCapacityQuotaGib?;
    get storageCapacityQuotaGib(): number;
    set storageCapacityQuotaGib(value: number);
    resetStorageCapacityQuotaGib(): void;
    get storageCapacityQuotaGibInput(): number | undefined;
    private _storageCapacityReservationGib?;
    get storageCapacityReservationGib(): number;
    set storageCapacityReservationGib(value: number);
    resetStorageCapacityReservationGib(): void;
    get storageCapacityReservationGibInput(): number | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _volumeType?;
    get volumeType(): string;
    set volumeType(value: string);
    resetVolumeType(): void;
    get volumeTypeInput(): string | undefined;
    private _nfsExports;
    get nfsExports(): TfOpenzfsVolume.NfsExportsPropertyOutputReference;
    putNfsExports(value: TfOpenzfsVolume.NfsExportsProperty): void;
    resetNfsExports(): void;
    get nfsExportsInput(): TfOpenzfsVolume.NfsExportsProperty | undefined;
    private _originSnapshot;
    get originSnapshot(): TfOpenzfsVolume.OriginSnapshotPropertyOutputReference;
    putOriginSnapshot(value: TfOpenzfsVolume.OriginSnapshotProperty): void;
    resetOriginSnapshot(): void;
    get originSnapshotInput(): TfOpenzfsVolume.OriginSnapshotProperty | undefined;
    private _timeouts;
    get timeouts(): TfOpenzfsVolume.TimeoutsPropertyOutputReference;
    putTimeouts(value: TfOpenzfsVolume.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | TfOpenzfsVolume.TimeoutsProperty | undefined;
    private _userAndGroupQuotas;
    get userAndGroupQuotas(): TfOpenzfsVolume.UserAndGroupQuotasPropertyList;
    putUserAndGroupQuotas(value: TfOpenzfsVolume.UserAndGroupQuotasProperty[] | cdktn.IResolvable): void;
    resetUserAndGroupQuotas(): void;
    get userAndGroupQuotasInput(): cdktn.IResolvable | TfOpenzfsVolume.UserAndGroupQuotasProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfOpenzfsVolumeClientConfigurationsPropertyToTerraform(struct?: TfOpenzfsVolume.ClientConfigurationsProperty | cdktn.IResolvable): any;
export declare function tfOpenzfsVolumeClientConfigurationsPropertyToHclTerraform(struct?: TfOpenzfsVolume.ClientConfigurationsProperty | cdktn.IResolvable): any;
export declare function tfOpenzfsVolumeNfsExportsPropertyToTerraform(struct?: TfOpenzfsVolume.NfsExportsPropertyOutputReference | TfOpenzfsVolume.NfsExportsProperty): any;
export declare function tfOpenzfsVolumeNfsExportsPropertyToHclTerraform(struct?: TfOpenzfsVolume.NfsExportsPropertyOutputReference | TfOpenzfsVolume.NfsExportsProperty): any;
export declare function tfOpenzfsVolumeOriginSnapshotPropertyToTerraform(struct?: TfOpenzfsVolume.OriginSnapshotPropertyOutputReference | TfOpenzfsVolume.OriginSnapshotProperty): any;
export declare function tfOpenzfsVolumeOriginSnapshotPropertyToHclTerraform(struct?: TfOpenzfsVolume.OriginSnapshotPropertyOutputReference | TfOpenzfsVolume.OriginSnapshotProperty): any;
export declare function tfOpenzfsVolumeTimeoutsPropertyToTerraform(struct?: TfOpenzfsVolume.TimeoutsProperty | cdktn.IResolvable): any;
export declare function tfOpenzfsVolumeTimeoutsPropertyToHclTerraform(struct?: TfOpenzfsVolume.TimeoutsProperty | cdktn.IResolvable): any;
export declare function tfOpenzfsVolumeUserAndGroupQuotasPropertyToTerraform(struct?: TfOpenzfsVolume.UserAndGroupQuotasProperty | cdktn.IResolvable): any;
export declare function tfOpenzfsVolumeUserAndGroupQuotasPropertyToHclTerraform(struct?: TfOpenzfsVolume.UserAndGroupQuotasProperty | cdktn.IResolvable): any;
export declare namespace TfOpenzfsVolume {
    interface ClientConfigurationsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_openzfs_volume#clients TfOpenzfsVolume#clients}
        */
        readonly clients: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_openzfs_volume#options TfOpenzfsVolume#options}
        */
        readonly options: string[];
    }
    class ClientConfigurationsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ClientConfigurationsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ClientConfigurationsProperty | cdktn.IResolvable | undefined);
        private _clients?;
        get clients(): string;
        set clients(value: string);
        get clientsInput(): string | undefined;
        private _options?;
        get options(): string[];
        set options(value: string[]);
        get optionsInput(): string[] | undefined;
    }
    class ClientConfigurationsPropertyList extends cdktn.ComplexList {
        internalValue?: ClientConfigurationsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ClientConfigurationsPropertyOutputReference;
    }
    interface NfsExportsProperty {
        /**
        * client_configurations block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_openzfs_volume#client_configurations TfOpenzfsVolume#client_configurations}
        */
        readonly clientConfigurations: ClientConfigurationsProperty[] | cdktn.IResolvable;
    }
    class NfsExportsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): NfsExportsProperty | undefined;
        set internalValue(value: NfsExportsProperty | undefined);
        private _clientConfigurations;
        get clientConfigurations(): ClientConfigurationsPropertyList;
        putClientConfigurations(value: ClientConfigurationsProperty[] | cdktn.IResolvable): void;
        get clientConfigurationsInput(): cdktn.IResolvable | ClientConfigurationsProperty[] | undefined;
    }
    interface OriginSnapshotProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_openzfs_volume#copy_strategy TfOpenzfsVolume#copy_strategy}
        */
        readonly copyStrategy: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_openzfs_volume#snapshot_arn TfOpenzfsVolume#snapshot_arn}
        */
        readonly snapshotArn: string;
    }
    class OriginSnapshotPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): OriginSnapshotProperty | undefined;
        set internalValue(value: OriginSnapshotProperty | undefined);
        private _copyStrategy?;
        get copyStrategy(): string;
        set copyStrategy(value: string);
        get copyStrategyInput(): string | undefined;
        private _snapshotArn?;
        get snapshotArn(): string;
        set snapshotArn(value: string);
        get snapshotArnInput(): string | undefined;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_openzfs_volume#create TfOpenzfsVolume#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_openzfs_volume#delete TfOpenzfsVolume#delete}
        */
        readonly delete?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_openzfs_volume#update TfOpenzfsVolume#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
    interface UserAndGroupQuotasProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_openzfs_volume#id TfOpenzfsVolume#id}
        *
        * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
        * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
        */
        readonly id: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_openzfs_volume#storage_capacity_quota_gib TfOpenzfsVolume#storage_capacity_quota_gib}
        */
        readonly storageCapacityQuotaGib: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_openzfs_volume#type TfOpenzfsVolume#type}
        */
        readonly type: string;
    }
    class UserAndGroupQuotasPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): UserAndGroupQuotasProperty | cdktn.IResolvable | undefined;
        set internalValue(value: UserAndGroupQuotasProperty | cdktn.IResolvable | undefined);
        private _id?;
        get id(): number;
        set id(value: number);
        get idInput(): number | undefined;
        private _storageCapacityQuotaGib?;
        get storageCapacityQuotaGib(): number;
        set storageCapacityQuotaGib(value: number);
        get storageCapacityQuotaGibInput(): number | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
    }
    class UserAndGroupQuotasPropertyList extends cdktn.ComplexList {
        internalValue?: UserAndGroupQuotasProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): UserAndGroupQuotasPropertyOutputReference;
    }
}
