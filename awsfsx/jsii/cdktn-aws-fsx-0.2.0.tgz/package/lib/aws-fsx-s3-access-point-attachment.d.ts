import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfS3AccessPointAttachmentConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_s3_access_point_attachment#name TfS3AccessPointAttachment#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_s3_access_point_attachment#region TfS3AccessPointAttachment#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_s3_access_point_attachment#type TfS3AccessPointAttachment#type}
    */
    readonly type: string;
    /**
    * openzfs_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_s3_access_point_attachment#openzfs_configuration TfS3AccessPointAttachment#openzfs_configuration}
    */
    readonly openzfsConfiguration?: TfS3AccessPointAttachment.OpenzfsConfigurationProperty[] | cdktn.IResolvable;
    /**
    * s3_access_point block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_s3_access_point_attachment#s3_access_point TfS3AccessPointAttachment#s3_access_point}
    */
    readonly s3AccessPoint?: TfS3AccessPointAttachment.S3AccessPointProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_s3_access_point_attachment#timeouts TfS3AccessPointAttachment#timeouts}
    */
    readonly timeouts?: TfS3AccessPointAttachment.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_s3_access_point_attachment aws_fsx_s3_access_point_attachment}
*/
export declare class TfS3AccessPointAttachment extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_fsx_s3_access_point_attachment";
    /**
    * Generates CDKTN code for importing a TfS3AccessPointAttachment resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfS3AccessPointAttachment to import
    * @param importFromId The id of the existing TfS3AccessPointAttachment that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_s3_access_point_attachment#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfS3AccessPointAttachment to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_s3_access_point_attachment aws_fsx_s3_access_point_attachment} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfS3AccessPointAttachmentConfig
    */
    constructor(scope: Construct, id: string, config: TfS3AccessPointAttachmentConfig);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get s3AccessPointAlias(): string;
    get s3AccessPointArn(): string;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _openzfsConfiguration;
    get openzfsConfiguration(): TfS3AccessPointAttachment.OpenzfsConfigurationPropertyList;
    putOpenzfsConfiguration(value: TfS3AccessPointAttachment.OpenzfsConfigurationProperty[] | cdktn.IResolvable): void;
    resetOpenzfsConfiguration(): void;
    get openzfsConfigurationInput(): cdktn.IResolvable | TfS3AccessPointAttachment.OpenzfsConfigurationProperty[] | undefined;
    private _s3AccessPoint;
    get s3AccessPoint(): TfS3AccessPointAttachment.S3AccessPointPropertyList;
    putS3AccessPoint(value: TfS3AccessPointAttachment.S3AccessPointProperty[] | cdktn.IResolvable): void;
    resetS3AccessPoint(): void;
    get s3AccessPointInput(): cdktn.IResolvable | TfS3AccessPointAttachment.S3AccessPointProperty[] | undefined;
    private _timeouts;
    get timeouts(): TfS3AccessPointAttachment.TimeoutsPropertyOutputReference;
    putTimeouts(value: TfS3AccessPointAttachment.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | TfS3AccessPointAttachment.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfS3AccessPointAttachmentPosixUserPropertyToTerraform(struct?: TfS3AccessPointAttachment.PosixUserProperty | cdktn.IResolvable): any;
export declare function tfS3AccessPointAttachmentPosixUserPropertyToHclTerraform(struct?: TfS3AccessPointAttachment.PosixUserProperty | cdktn.IResolvable): any;
export declare function tfS3AccessPointAttachmentFileSystemIdentityPropertyToTerraform(struct?: TfS3AccessPointAttachment.FileSystemIdentityProperty | cdktn.IResolvable): any;
export declare function tfS3AccessPointAttachmentFileSystemIdentityPropertyToHclTerraform(struct?: TfS3AccessPointAttachment.FileSystemIdentityProperty | cdktn.IResolvable): any;
export declare function tfS3AccessPointAttachmentOpenzfsConfigurationPropertyToTerraform(struct?: TfS3AccessPointAttachment.OpenzfsConfigurationProperty | cdktn.IResolvable): any;
export declare function tfS3AccessPointAttachmentOpenzfsConfigurationPropertyToHclTerraform(struct?: TfS3AccessPointAttachment.OpenzfsConfigurationProperty | cdktn.IResolvable): any;
export declare function tfS3AccessPointAttachmentVpcConfigurationPropertyToTerraform(struct?: TfS3AccessPointAttachment.VpcConfigurationProperty | cdktn.IResolvable): any;
export declare function tfS3AccessPointAttachmentVpcConfigurationPropertyToHclTerraform(struct?: TfS3AccessPointAttachment.VpcConfigurationProperty | cdktn.IResolvable): any;
export declare function tfS3AccessPointAttachmentS3AccessPointPropertyToTerraform(struct?: TfS3AccessPointAttachment.S3AccessPointProperty | cdktn.IResolvable): any;
export declare function tfS3AccessPointAttachmentS3AccessPointPropertyToHclTerraform(struct?: TfS3AccessPointAttachment.S3AccessPointProperty | cdktn.IResolvable): any;
export declare function tfS3AccessPointAttachmentTimeoutsPropertyToTerraform(struct?: TfS3AccessPointAttachment.TimeoutsProperty | cdktn.IResolvable): any;
export declare function tfS3AccessPointAttachmentTimeoutsPropertyToHclTerraform(struct?: TfS3AccessPointAttachment.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace TfS3AccessPointAttachment {
    interface PosixUserProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_s3_access_point_attachment#gid TfS3AccessPointAttachment#gid}
        */
        readonly gid: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_s3_access_point_attachment#secondary_gids TfS3AccessPointAttachment#secondary_gids}
        */
        readonly secondaryGids?: number[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_s3_access_point_attachment#uid TfS3AccessPointAttachment#uid}
        */
        readonly uid: number;
    }
    class PosixUserPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): PosixUserProperty | cdktn.IResolvable | undefined;
        set internalValue(value: PosixUserProperty | cdktn.IResolvable | undefined);
        private _gid?;
        get gid(): number;
        set gid(value: number);
        get gidInput(): number | undefined;
        private _secondaryGids?;
        get secondaryGids(): number[];
        set secondaryGids(value: number[]);
        resetSecondaryGids(): void;
        get secondaryGidsInput(): number[] | undefined;
        private _uid?;
        get uid(): number;
        set uid(value: number);
        get uidInput(): number | undefined;
    }
    class PosixUserPropertyList extends cdktn.ComplexList {
        internalValue?: PosixUserProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): PosixUserPropertyOutputReference;
    }
    interface FileSystemIdentityProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_s3_access_point_attachment#type TfS3AccessPointAttachment#type}
        */
        readonly type: string;
        /**
        * posix_user block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_s3_access_point_attachment#posix_user TfS3AccessPointAttachment#posix_user}
        */
        readonly posixUser?: PosixUserProperty[] | cdktn.IResolvable;
    }
    class FileSystemIdentityPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): FileSystemIdentityProperty | cdktn.IResolvable | undefined;
        set internalValue(value: FileSystemIdentityProperty | cdktn.IResolvable | undefined);
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
        private _posixUser;
        get posixUser(): PosixUserPropertyList;
        putPosixUser(value: PosixUserProperty[] | cdktn.IResolvable): void;
        resetPosixUser(): void;
        get posixUserInput(): cdktn.IResolvable | PosixUserProperty[] | undefined;
    }
    class FileSystemIdentityPropertyList extends cdktn.ComplexList {
        internalValue?: FileSystemIdentityProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): FileSystemIdentityPropertyOutputReference;
    }
    interface OpenzfsConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_s3_access_point_attachment#volume_id TfS3AccessPointAttachment#volume_id}
        */
        readonly volumeId: string;
        /**
        * file_system_identity block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_s3_access_point_attachment#file_system_identity TfS3AccessPointAttachment#file_system_identity}
        */
        readonly fileSystemIdentity?: FileSystemIdentityProperty[] | cdktn.IResolvable;
    }
    class OpenzfsConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): OpenzfsConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: OpenzfsConfigurationProperty | cdktn.IResolvable | undefined);
        private _volumeId?;
        get volumeId(): string;
        set volumeId(value: string);
        get volumeIdInput(): string | undefined;
        private _fileSystemIdentity;
        get fileSystemIdentity(): FileSystemIdentityPropertyList;
        putFileSystemIdentity(value: FileSystemIdentityProperty[] | cdktn.IResolvable): void;
        resetFileSystemIdentity(): void;
        get fileSystemIdentityInput(): cdktn.IResolvable | FileSystemIdentityProperty[] | undefined;
    }
    class OpenzfsConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: OpenzfsConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): OpenzfsConfigurationPropertyOutputReference;
    }
    interface VpcConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_s3_access_point_attachment#vpc_id TfS3AccessPointAttachment#vpc_id}
        */
        readonly vpcId?: string;
    }
    class VpcConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): VpcConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: VpcConfigurationProperty | cdktn.IResolvable | undefined);
        private _vpcId?;
        get vpcId(): string;
        set vpcId(value: string);
        resetVpcId(): void;
        get vpcIdInput(): string | undefined;
    }
    class VpcConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: VpcConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): VpcConfigurationPropertyOutputReference;
    }
    interface S3AccessPointProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_s3_access_point_attachment#policy TfS3AccessPointAttachment#policy}
        */
        readonly policy?: string;
        /**
        * vpc_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_s3_access_point_attachment#vpc_configuration TfS3AccessPointAttachment#vpc_configuration}
        */
        readonly vpcConfiguration?: VpcConfigurationProperty[] | cdktn.IResolvable;
    }
    class S3AccessPointPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): S3AccessPointProperty | cdktn.IResolvable | undefined;
        set internalValue(value: S3AccessPointProperty | cdktn.IResolvable | undefined);
        private _policy?;
        get policy(): string;
        set policy(value: string);
        resetPolicy(): void;
        get policyInput(): string | undefined;
        private _vpcConfiguration;
        get vpcConfiguration(): VpcConfigurationPropertyList;
        putVpcConfiguration(value: VpcConfigurationProperty[] | cdktn.IResolvable): void;
        resetVpcConfiguration(): void;
        get vpcConfigurationInput(): cdktn.IResolvable | VpcConfigurationProperty[] | undefined;
    }
    class S3AccessPointPropertyList extends cdktn.ComplexList {
        internalValue?: S3AccessPointProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): S3AccessPointPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_s3_access_point_attachment#create TfS3AccessPointAttachment#create}
        */
        readonly create?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Setting a timeout for a Delete operation is only applicable if changes are saved into state before the destroy operation occurs.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fsx_s3_access_point_attachment#delete TfS3AccessPointAttachment#delete}
        */
        readonly delete?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
    }
}
