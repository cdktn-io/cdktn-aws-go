import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfClusterCapacityProvidersConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_cluster_capacity_providers#capacity_providers TfClusterCapacityProviders#capacity_providers}
    */
    readonly capacityProviders?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_cluster_capacity_providers#cluster_name TfClusterCapacityProviders#cluster_name}
    */
    readonly clusterName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_cluster_capacity_providers#id TfClusterCapacityProviders#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_cluster_capacity_providers#region TfClusterCapacityProviders#region}
    */
    readonly region?: string;
    /**
    * default_capacity_provider_strategy block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_cluster_capacity_providers#default_capacity_provider_strategy TfClusterCapacityProviders#default_capacity_provider_strategy}
    */
    readonly defaultCapacityProviderStrategy?: TfClusterCapacityProviders.DefaultCapacityProviderStrategyProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_cluster_capacity_providers aws_ecs_cluster_capacity_providers}
*/
export declare class TfClusterCapacityProviders extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_ecs_cluster_capacity_providers";
    /**
    * Generates CDKTN code for importing a TfClusterCapacityProviders resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfClusterCapacityProviders to import
    * @param importFromId The id of the existing TfClusterCapacityProviders that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_cluster_capacity_providers#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfClusterCapacityProviders to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_cluster_capacity_providers aws_ecs_cluster_capacity_providers} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfClusterCapacityProvidersConfig
    */
    constructor(scope: Construct, id: string, config: TfClusterCapacityProvidersConfig);
    private _capacityProviders?;
    get capacityProviders(): string[];
    set capacityProviders(value: string[]);
    resetCapacityProviders(): void;
    get capacityProvidersInput(): string[] | undefined;
    private _clusterName?;
    get clusterName(): string;
    set clusterName(value: string);
    get clusterNameInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _defaultCapacityProviderStrategy;
    get defaultCapacityProviderStrategy(): TfClusterCapacityProviders.DefaultCapacityProviderStrategyPropertyList;
    putDefaultCapacityProviderStrategy(value: TfClusterCapacityProviders.DefaultCapacityProviderStrategyProperty[] | cdktn.IResolvable): void;
    resetDefaultCapacityProviderStrategy(): void;
    get defaultCapacityProviderStrategyInput(): cdktn.IResolvable | TfClusterCapacityProviders.DefaultCapacityProviderStrategyProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfClusterCapacityProvidersDefaultCapacityProviderStrategyPropertyToTerraform(struct?: TfClusterCapacityProviders.DefaultCapacityProviderStrategyProperty | cdktn.IResolvable): any;
export declare function tfClusterCapacityProvidersDefaultCapacityProviderStrategyPropertyToHclTerraform(struct?: TfClusterCapacityProviders.DefaultCapacityProviderStrategyProperty | cdktn.IResolvable): any;
export declare namespace TfClusterCapacityProviders {
    interface DefaultCapacityProviderStrategyProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_cluster_capacity_providers#base TfClusterCapacityProviders#base}
        */
        readonly base?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_cluster_capacity_providers#capacity_provider TfClusterCapacityProviders#capacity_provider}
        */
        readonly capacityProvider: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_cluster_capacity_providers#weight TfClusterCapacityProviders#weight}
        */
        readonly weight?: number;
    }
    class DefaultCapacityProviderStrategyPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DefaultCapacityProviderStrategyProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DefaultCapacityProviderStrategyProperty | cdktn.IResolvable | undefined);
        private _base?;
        get base(): number;
        set base(value: number);
        resetBase(): void;
        get baseInput(): number | undefined;
        private _capacityProvider?;
        get capacityProvider(): string;
        set capacityProvider(value: string);
        get capacityProviderInput(): string | undefined;
        private _weight?;
        get weight(): number;
        set weight(value: number);
        resetWeight(): void;
        get weightInput(): number | undefined;
    }
    class DefaultCapacityProviderStrategyPropertyList extends cdktn.ComplexList {
        internalValue?: DefaultCapacityProviderStrategyProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DefaultCapacityProviderStrategyPropertyOutputReference;
    }
}
