import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfTaskSetConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_task_set#cluster TfTaskSet#cluster}
    */
    readonly cluster: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_task_set#external_id TfTaskSet#external_id}
    */
    readonly externalId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_task_set#force_delete TfTaskSet#force_delete}
    */
    readonly forceDelete?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_task_set#id TfTaskSet#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_task_set#launch_type TfTaskSet#launch_type}
    */
    readonly launchType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_task_set#platform_version TfTaskSet#platform_version}
    */
    readonly platformVersion?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_task_set#region TfTaskSet#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_task_set#service TfTaskSet#service}
    */
    readonly service: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_task_set#tags TfTaskSet#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_task_set#tags_all TfTaskSet#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_task_set#task_definition TfTaskSet#task_definition}
    */
    readonly taskDefinition: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_task_set#wait_until_stable TfTaskSet#wait_until_stable}
    */
    readonly waitUntilStable?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_task_set#wait_until_stable_timeout TfTaskSet#wait_until_stable_timeout}
    */
    readonly waitUntilStableTimeout?: string;
    /**
    * capacity_provider_strategy block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_task_set#capacity_provider_strategy TfTaskSet#capacity_provider_strategy}
    */
    readonly capacityProviderStrategy?: TfTaskSet.CapacityProviderStrategyProperty[] | cdktn.IResolvable;
    /**
    * load_balancer block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_task_set#load_balancer TfTaskSet#load_balancer}
    */
    readonly loadBalancer?: TfTaskSet.LoadBalancerProperty[] | cdktn.IResolvable;
    /**
    * network_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_task_set#network_configuration TfTaskSet#network_configuration}
    */
    readonly networkConfiguration?: TfTaskSet.NetworkConfigurationProperty;
    /**
    * scale block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_task_set#scale TfTaskSet#scale}
    */
    readonly scale?: TfTaskSet.ScaleProperty;
    /**
    * service_registries block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_task_set#service_registries TfTaskSet#service_registries}
    */
    readonly serviceRegistries?: TfTaskSet.ServiceRegistriesProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_task_set aws_ecs_task_set}
*/
export declare class TfTaskSet extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_ecs_task_set";
    /**
    * Generates CDKTN code for importing a TfTaskSet resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfTaskSet to import
    * @param importFromId The id of the existing TfTaskSet that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_task_set#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfTaskSet to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_task_set aws_ecs_task_set} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfTaskSetConfig
    */
    constructor(scope: Construct, id: string, config: TfTaskSetConfig);
    get arn(): string;
    private _cluster?;
    get cluster(): string;
    set cluster(value: string);
    get clusterInput(): string | undefined;
    private _externalId?;
    get externalId(): string;
    set externalId(value: string);
    resetExternalId(): void;
    get externalIdInput(): string | undefined;
    private _forceDelete?;
    get forceDelete(): boolean | cdktn.IResolvable;
    set forceDelete(value: boolean | cdktn.IResolvable);
    resetForceDelete(): void;
    get forceDeleteInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _launchType?;
    get launchType(): string;
    set launchType(value: string);
    resetLaunchType(): void;
    get launchTypeInput(): string | undefined;
    private _platformVersion?;
    get platformVersion(): string;
    set platformVersion(value: string);
    resetPlatformVersion(): void;
    get platformVersionInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _service?;
    get service(): string;
    set service(value: string);
    get serviceInput(): string | undefined;
    get stabilityStatus(): string;
    get status(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _taskDefinition?;
    get taskDefinition(): string;
    set taskDefinition(value: string);
    get taskDefinitionInput(): string | undefined;
    get taskSetId(): string;
    private _waitUntilStable?;
    get waitUntilStable(): boolean | cdktn.IResolvable;
    set waitUntilStable(value: boolean | cdktn.IResolvable);
    resetWaitUntilStable(): void;
    get waitUntilStableInput(): boolean | cdktn.IResolvable | undefined;
    private _waitUntilStableTimeout?;
    get waitUntilStableTimeout(): string;
    set waitUntilStableTimeout(value: string);
    resetWaitUntilStableTimeout(): void;
    get waitUntilStableTimeoutInput(): string | undefined;
    private _capacityProviderStrategy;
    get capacityProviderStrategy(): TfTaskSet.CapacityProviderStrategyPropertyList;
    putCapacityProviderStrategy(value: TfTaskSet.CapacityProviderStrategyProperty[] | cdktn.IResolvable): void;
    resetCapacityProviderStrategy(): void;
    get capacityProviderStrategyInput(): cdktn.IResolvable | TfTaskSet.CapacityProviderStrategyProperty[] | undefined;
    private _loadBalancer;
    get loadBalancer(): TfTaskSet.LoadBalancerPropertyList;
    putLoadBalancer(value: TfTaskSet.LoadBalancerProperty[] | cdktn.IResolvable): void;
    resetLoadBalancer(): void;
    get loadBalancerInput(): cdktn.IResolvable | TfTaskSet.LoadBalancerProperty[] | undefined;
    private _networkConfiguration;
    get networkConfiguration(): TfTaskSet.NetworkConfigurationPropertyOutputReference;
    putNetworkConfiguration(value: TfTaskSet.NetworkConfigurationProperty): void;
    resetNetworkConfiguration(): void;
    get networkConfigurationInput(): TfTaskSet.NetworkConfigurationProperty | undefined;
    private _scale;
    get scale(): TfTaskSet.ScalePropertyOutputReference;
    putScale(value: TfTaskSet.ScaleProperty): void;
    resetScale(): void;
    get scaleInput(): TfTaskSet.ScaleProperty | undefined;
    private _serviceRegistries;
    get serviceRegistries(): TfTaskSet.ServiceRegistriesPropertyOutputReference;
    putServiceRegistries(value: TfTaskSet.ServiceRegistriesProperty): void;
    resetServiceRegistries(): void;
    get serviceRegistriesInput(): TfTaskSet.ServiceRegistriesProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfTaskSetCapacityProviderStrategyPropertyToTerraform(struct?: TfTaskSet.CapacityProviderStrategyProperty | cdktn.IResolvable): any;
export declare function tfTaskSetCapacityProviderStrategyPropertyToHclTerraform(struct?: TfTaskSet.CapacityProviderStrategyProperty | cdktn.IResolvable): any;
export declare function tfTaskSetLoadBalancerPropertyToTerraform(struct?: TfTaskSet.LoadBalancerProperty | cdktn.IResolvable): any;
export declare function tfTaskSetLoadBalancerPropertyToHclTerraform(struct?: TfTaskSet.LoadBalancerProperty | cdktn.IResolvable): any;
export declare function tfTaskSetNetworkConfigurationPropertyToTerraform(struct?: TfTaskSet.NetworkConfigurationPropertyOutputReference | TfTaskSet.NetworkConfigurationProperty): any;
export declare function tfTaskSetNetworkConfigurationPropertyToHclTerraform(struct?: TfTaskSet.NetworkConfigurationPropertyOutputReference | TfTaskSet.NetworkConfigurationProperty): any;
export declare function tfTaskSetScalePropertyToTerraform(struct?: TfTaskSet.ScalePropertyOutputReference | TfTaskSet.ScaleProperty): any;
export declare function tfTaskSetScalePropertyToHclTerraform(struct?: TfTaskSet.ScalePropertyOutputReference | TfTaskSet.ScaleProperty): any;
export declare function tfTaskSetServiceRegistriesPropertyToTerraform(struct?: TfTaskSet.ServiceRegistriesPropertyOutputReference | TfTaskSet.ServiceRegistriesProperty): any;
export declare function tfTaskSetServiceRegistriesPropertyToHclTerraform(struct?: TfTaskSet.ServiceRegistriesPropertyOutputReference | TfTaskSet.ServiceRegistriesProperty): any;
export declare namespace TfTaskSet {
    interface CapacityProviderStrategyProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_task_set#base TfTaskSet#base}
        */
        readonly base?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_task_set#capacity_provider TfTaskSet#capacity_provider}
        */
        readonly capacityProvider: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_task_set#weight TfTaskSet#weight}
        */
        readonly weight: number;
    }
    class CapacityProviderStrategyPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CapacityProviderStrategyProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CapacityProviderStrategyProperty | cdktn.IResolvable | undefined);
        private _base?;
        get base(): number;
        set base(value: number);
        resetBase(): void;
        get baseInput(): number | undefined;
        private _capacityProvider?;
        get capacityProvider(): string;
        set capacityProvider(value: string);
        get capacityProviderInput(): string | undefined;
        private _weight?;
        get weight(): number;
        set weight(value: number);
        get weightInput(): number | undefined;
    }
    class CapacityProviderStrategyPropertyList extends cdktn.ComplexList {
        internalValue?: CapacityProviderStrategyProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CapacityProviderStrategyPropertyOutputReference;
    }
    interface LoadBalancerProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_task_set#container_name TfTaskSet#container_name}
        */
        readonly containerName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_task_set#container_port TfTaskSet#container_port}
        */
        readonly containerPort?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_task_set#load_balancer_name TfTaskSet#load_balancer_name}
        */
        readonly loadBalancerName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_task_set#target_group_arn TfTaskSet#target_group_arn}
        */
        readonly targetGroupArn?: string;
    }
    class LoadBalancerPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): LoadBalancerProperty | cdktn.IResolvable | undefined;
        set internalValue(value: LoadBalancerProperty | cdktn.IResolvable | undefined);
        private _containerName?;
        get containerName(): string;
        set containerName(value: string);
        get containerNameInput(): string | undefined;
        private _containerPort?;
        get containerPort(): number;
        set containerPort(value: number);
        resetContainerPort(): void;
        get containerPortInput(): number | undefined;
        private _loadBalancerName?;
        get loadBalancerName(): string;
        set loadBalancerName(value: string);
        resetLoadBalancerName(): void;
        get loadBalancerNameInput(): string | undefined;
        private _targetGroupArn?;
        get targetGroupArn(): string;
        set targetGroupArn(value: string);
        resetTargetGroupArn(): void;
        get targetGroupArnInput(): string | undefined;
    }
    class LoadBalancerPropertyList extends cdktn.ComplexList {
        internalValue?: LoadBalancerProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): LoadBalancerPropertyOutputReference;
    }
    interface NetworkConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_task_set#assign_public_ip TfTaskSet#assign_public_ip}
        */
        readonly assignPublicIp?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_task_set#security_groups TfTaskSet#security_groups}
        */
        readonly securityGroups?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_task_set#subnets TfTaskSet#subnets}
        */
        readonly subnets: string[];
    }
    class NetworkConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): NetworkConfigurationProperty | undefined;
        set internalValue(value: NetworkConfigurationProperty | undefined);
        private _assignPublicIp?;
        get assignPublicIp(): boolean | cdktn.IResolvable;
        set assignPublicIp(value: boolean | cdktn.IResolvable);
        resetAssignPublicIp(): void;
        get assignPublicIpInput(): boolean | cdktn.IResolvable | undefined;
        private _securityGroups?;
        get securityGroups(): string[];
        set securityGroups(value: string[]);
        resetSecurityGroups(): void;
        get securityGroupsInput(): string[] | undefined;
        private _subnets?;
        get subnets(): string[];
        set subnets(value: string[]);
        get subnetsInput(): string[] | undefined;
    }
    interface ScaleProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_task_set#unit TfTaskSet#unit}
        */
        readonly unit?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_task_set#value TfTaskSet#value}
        */
        readonly value?: number;
    }
    class ScalePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ScaleProperty | undefined;
        set internalValue(value: ScaleProperty | undefined);
        private _unit?;
        get unit(): string;
        set unit(value: string);
        resetUnit(): void;
        get unitInput(): string | undefined;
        private _value?;
        get value(): number;
        set value(value: number);
        resetValue(): void;
        get valueInput(): number | undefined;
    }
    interface ServiceRegistriesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_task_set#container_name TfTaskSet#container_name}
        */
        readonly containerName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_task_set#container_port TfTaskSet#container_port}
        */
        readonly containerPort?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_task_set#port TfTaskSet#port}
        */
        readonly port?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_task_set#registry_arn TfTaskSet#registry_arn}
        */
        readonly registryArn: string;
    }
    class ServiceRegistriesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ServiceRegistriesProperty | undefined;
        set internalValue(value: ServiceRegistriesProperty | undefined);
        private _containerName?;
        get containerName(): string;
        set containerName(value: string);
        resetContainerName(): void;
        get containerNameInput(): string | undefined;
        private _containerPort?;
        get containerPort(): number;
        set containerPort(value: number);
        resetContainerPort(): void;
        get containerPortInput(): number | undefined;
        private _port?;
        get port(): number;
        set port(value: number);
        resetPort(): void;
        get portInput(): number | undefined;
        private _registryArn?;
        get registryArn(): string;
        set registryArn(value: string);
        get registryArnInput(): string | undefined;
    }
}
