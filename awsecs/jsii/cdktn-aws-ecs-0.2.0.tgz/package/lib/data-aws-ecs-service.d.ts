import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataTfServiceConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ecs_service#cluster_arn DataTfService#cluster_arn}
    */
    readonly clusterArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ecs_service#id DataTfService#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ecs_service#region DataTfService#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ecs_service#service_name DataTfService#service_name}
    */
    readonly serviceName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ecs_service#tags DataTfService#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ecs_service aws_ecs_service}
*/
export declare class DataTfService extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_ecs_service";
    /**
    * Generates CDKTN code for importing a DataTfService resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataTfService to import
    * @param importFromId The id of the existing DataTfService that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ecs_service#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataTfService to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ecs_service aws_ecs_service} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataTfServiceConfig
    */
    constructor(scope: Construct, id: string, config: DataTfServiceConfig);
    get arn(): string;
    get availabilityZoneRebalancing(): string;
    private _capacityProviderStrategy;
    get capacityProviderStrategy(): DataTfService.CapacityProviderStrategyPropertyList;
    private _clusterArn?;
    get clusterArn(): string;
    set clusterArn(value: string);
    get clusterArnInput(): string | undefined;
    get createdAt(): string;
    get createdBy(): string;
    private _deploymentConfiguration;
    get deploymentConfiguration(): DataTfService.DeploymentConfigurationPropertyList;
    private _deploymentController;
    get deploymentController(): DataTfService.DeploymentControllerPropertyList;
    private _deployments;
    get deployments(): DataTfService.DeploymentsPropertyList;
    get desiredCount(): number;
    get enableEcsManagedTags(): cdktn.IResolvable;
    get enableExecuteCommand(): cdktn.IResolvable;
    private _events;
    get events(): DataTfService.EventsPropertyList;
    get healthCheckGracePeriodSeconds(): number;
    get iamRole(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get launchType(): string;
    private _loadBalancer;
    get loadBalancer(): DataTfService.LoadBalancerPropertyList;
    private _networkConfiguration;
    get networkConfiguration(): DataTfService.NetworkConfigurationPropertyList;
    private _orderedPlacementStrategy;
    get orderedPlacementStrategy(): DataTfService.OrderedPlacementStrategyPropertyList;
    get pendingCount(): number;
    private _placementConstraints;
    get placementConstraints(): DataTfService.PlacementConstraintsPropertyList;
    get platformFamily(): string;
    get platformVersion(): string;
    get propagateTags(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get runningCount(): number;
    get schedulingStrategy(): string;
    private _serviceName?;
    get serviceName(): string;
    set serviceName(value: string);
    get serviceNameInput(): string | undefined;
    private _serviceRegistries;
    get serviceRegistries(): DataTfService.ServiceRegistriesPropertyList;
    get status(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    get taskDefinition(): string;
    private _taskSets;
    get taskSets(): DataTfService.TaskSetsPropertyList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataTfServiceCapacityProviderStrategyPropertyToTerraform(struct?: DataTfService.CapacityProviderStrategyProperty): any;
export declare function dataTfServiceCapacityProviderStrategyPropertyToHclTerraform(struct?: DataTfService.CapacityProviderStrategyProperty): any;
export declare function dataTfServiceAlarmsPropertyToTerraform(struct?: DataTfService.AlarmsProperty): any;
export declare function dataTfServiceAlarmsPropertyToHclTerraform(struct?: DataTfService.AlarmsProperty): any;
export declare function dataTfServiceCanaryConfigurationPropertyToTerraform(struct?: DataTfService.CanaryConfigurationProperty): any;
export declare function dataTfServiceCanaryConfigurationPropertyToHclTerraform(struct?: DataTfService.CanaryConfigurationProperty): any;
export declare function dataTfServiceDeploymentCircuitBreakerPropertyToTerraform(struct?: DataTfService.DeploymentCircuitBreakerProperty): any;
export declare function dataTfServiceDeploymentCircuitBreakerPropertyToHclTerraform(struct?: DataTfService.DeploymentCircuitBreakerProperty): any;
export declare function dataTfServiceLifecycleHookPropertyToTerraform(struct?: DataTfService.LifecycleHookProperty): any;
export declare function dataTfServiceLifecycleHookPropertyToHclTerraform(struct?: DataTfService.LifecycleHookProperty): any;
export declare function dataTfServiceLinearConfigurationPropertyToTerraform(struct?: DataTfService.LinearConfigurationProperty): any;
export declare function dataTfServiceLinearConfigurationPropertyToHclTerraform(struct?: DataTfService.LinearConfigurationProperty): any;
export declare function dataTfServiceDeploymentConfigurationPropertyToTerraform(struct?: DataTfService.DeploymentConfigurationProperty): any;
export declare function dataTfServiceDeploymentConfigurationPropertyToHclTerraform(struct?: DataTfService.DeploymentConfigurationProperty): any;
export declare function dataTfServiceDeploymentControllerPropertyToTerraform(struct?: DataTfService.DeploymentControllerProperty): any;
export declare function dataTfServiceDeploymentControllerPropertyToHclTerraform(struct?: DataTfService.DeploymentControllerProperty): any;
export declare function dataTfServiceDeploymentsPropertyToTerraform(struct?: DataTfService.DeploymentsProperty): any;
export declare function dataTfServiceDeploymentsPropertyToHclTerraform(struct?: DataTfService.DeploymentsProperty): any;
export declare function dataTfServiceEventsPropertyToTerraform(struct?: DataTfService.EventsProperty): any;
export declare function dataTfServiceEventsPropertyToHclTerraform(struct?: DataTfService.EventsProperty): any;
export declare function dataTfServiceAdvancedConfigurationPropertyToTerraform(struct?: DataTfService.AdvancedConfigurationProperty): any;
export declare function dataTfServiceAdvancedConfigurationPropertyToHclTerraform(struct?: DataTfService.AdvancedConfigurationProperty): any;
export declare function dataTfServiceLoadBalancerPropertyToTerraform(struct?: DataTfService.LoadBalancerProperty): any;
export declare function dataTfServiceLoadBalancerPropertyToHclTerraform(struct?: DataTfService.LoadBalancerProperty): any;
export declare function dataTfServiceNetworkConfigurationPropertyToTerraform(struct?: DataTfService.NetworkConfigurationProperty): any;
export declare function dataTfServiceNetworkConfigurationPropertyToHclTerraform(struct?: DataTfService.NetworkConfigurationProperty): any;
export declare function dataTfServiceOrderedPlacementStrategyPropertyToTerraform(struct?: DataTfService.OrderedPlacementStrategyProperty): any;
export declare function dataTfServiceOrderedPlacementStrategyPropertyToHclTerraform(struct?: DataTfService.OrderedPlacementStrategyProperty): any;
export declare function dataTfServicePlacementConstraintsPropertyToTerraform(struct?: DataTfService.PlacementConstraintsProperty): any;
export declare function dataTfServicePlacementConstraintsPropertyToHclTerraform(struct?: DataTfService.PlacementConstraintsProperty): any;
export declare function dataTfServiceServiceRegistriesPropertyToTerraform(struct?: DataTfService.ServiceRegistriesProperty): any;
export declare function dataTfServiceServiceRegistriesPropertyToHclTerraform(struct?: DataTfService.ServiceRegistriesProperty): any;
export declare function dataTfServiceTaskSetsPropertyToTerraform(struct?: DataTfService.TaskSetsProperty): any;
export declare function dataTfServiceTaskSetsPropertyToHclTerraform(struct?: DataTfService.TaskSetsProperty): any;
export declare namespace DataTfService {
    interface CapacityProviderStrategyProperty {
    }
    class CapacityProviderStrategyPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CapacityProviderStrategyProperty | undefined;
        set internalValue(value: CapacityProviderStrategyProperty | undefined);
        get base(): number;
        get capacityProvider(): string;
        get weight(): number;
    }
    class CapacityProviderStrategyPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CapacityProviderStrategyPropertyOutputReference;
    }
    interface AlarmsProperty {
    }
    class AlarmsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AlarmsProperty | undefined;
        set internalValue(value: AlarmsProperty | undefined);
        get alarmNames(): string[];
        get enable(): cdktn.IResolvable;
        get rollback(): cdktn.IResolvable;
    }
    class AlarmsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AlarmsPropertyOutputReference;
    }
    interface CanaryConfigurationProperty {
    }
    class CanaryConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CanaryConfigurationProperty | undefined;
        set internalValue(value: CanaryConfigurationProperty | undefined);
        get canaryBakeTimeInMinutes(): string;
        get canaryPercent(): number;
    }
    class CanaryConfigurationPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CanaryConfigurationPropertyOutputReference;
    }
    interface DeploymentCircuitBreakerProperty {
    }
    class DeploymentCircuitBreakerPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DeploymentCircuitBreakerProperty | undefined;
        set internalValue(value: DeploymentCircuitBreakerProperty | undefined);
        get enable(): cdktn.IResolvable;
        get rollback(): cdktn.IResolvable;
    }
    class DeploymentCircuitBreakerPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DeploymentCircuitBreakerPropertyOutputReference;
    }
    interface LifecycleHookProperty {
    }
    class LifecycleHookPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): LifecycleHookProperty | undefined;
        set internalValue(value: LifecycleHookProperty | undefined);
        get hookDetails(): string;
        get hookTargetArn(): string;
        get lifecycleStages(): string[];
        get roleArn(): string;
    }
    class LifecycleHookPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): LifecycleHookPropertyOutputReference;
    }
    interface LinearConfigurationProperty {
    }
    class LinearConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): LinearConfigurationProperty | undefined;
        set internalValue(value: LinearConfigurationProperty | undefined);
        get stepBakeTimeInMinutes(): string;
        get stepPercent(): number;
    }
    class LinearConfigurationPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): LinearConfigurationPropertyOutputReference;
    }
    interface DeploymentConfigurationProperty {
    }
    class DeploymentConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DeploymentConfigurationProperty | undefined;
        set internalValue(value: DeploymentConfigurationProperty | undefined);
        private _alarms;
        get alarms(): AlarmsPropertyList;
        get bakeTimeInMinutes(): string;
        private _canaryConfiguration;
        get canaryConfiguration(): CanaryConfigurationPropertyList;
        private _deploymentCircuitBreaker;
        get deploymentCircuitBreaker(): DeploymentCircuitBreakerPropertyList;
        private _lifecycleHook;
        get lifecycleHook(): LifecycleHookPropertyList;
        private _linearConfiguration;
        get linearConfiguration(): LinearConfigurationPropertyList;
        get maximumPercent(): number;
        get minimumHealthyPercent(): number;
        get strategy(): string;
    }
    class DeploymentConfigurationPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DeploymentConfigurationPropertyOutputReference;
    }
    interface DeploymentControllerProperty {
    }
    class DeploymentControllerPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DeploymentControllerProperty | undefined;
        set internalValue(value: DeploymentControllerProperty | undefined);
        get type(): string;
    }
    class DeploymentControllerPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DeploymentControllerPropertyOutputReference;
    }
    interface DeploymentsProperty {
    }
    class DeploymentsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DeploymentsProperty | undefined;
        set internalValue(value: DeploymentsProperty | undefined);
        get createdAt(): string;
        get desiredCount(): number;
        get id(): string;
        get pendingCount(): number;
        get runningCount(): number;
        get status(): string;
        get taskDefinition(): string;
        get updatedAt(): string;
    }
    class DeploymentsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DeploymentsPropertyOutputReference;
    }
    interface EventsProperty {
    }
    class EventsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EventsProperty | undefined;
        set internalValue(value: EventsProperty | undefined);
        get createdAt(): string;
        get id(): string;
        get message(): string;
    }
    class EventsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EventsPropertyOutputReference;
    }
    interface AdvancedConfigurationProperty {
    }
    class AdvancedConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AdvancedConfigurationProperty | undefined;
        set internalValue(value: AdvancedConfigurationProperty | undefined);
        get alternateTargetGroupArn(): string;
        get productionListenerRule(): string;
        get roleArn(): string;
        get testListenerRule(): string;
    }
    class AdvancedConfigurationPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AdvancedConfigurationPropertyOutputReference;
    }
    interface LoadBalancerProperty {
    }
    class LoadBalancerPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): LoadBalancerProperty | undefined;
        set internalValue(value: LoadBalancerProperty | undefined);
        private _advancedConfiguration;
        get advancedConfiguration(): AdvancedConfigurationPropertyList;
        get containerName(): string;
        get containerPort(): number;
        get elbName(): string;
        get targetGroupArn(): string;
    }
    class LoadBalancerPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): LoadBalancerPropertyOutputReference;
    }
    interface NetworkConfigurationProperty {
    }
    class NetworkConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): NetworkConfigurationProperty | undefined;
        set internalValue(value: NetworkConfigurationProperty | undefined);
        get assignPublicIp(): cdktn.IResolvable;
        get securityGroups(): string[];
        get subnets(): string[];
    }
    class NetworkConfigurationPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): NetworkConfigurationPropertyOutputReference;
    }
    interface OrderedPlacementStrategyProperty {
    }
    class OrderedPlacementStrategyPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): OrderedPlacementStrategyProperty | undefined;
        set internalValue(value: OrderedPlacementStrategyProperty | undefined);
        get field(): string;
        get type(): string;
    }
    class OrderedPlacementStrategyPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): OrderedPlacementStrategyPropertyOutputReference;
    }
    interface PlacementConstraintsProperty {
    }
    class PlacementConstraintsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): PlacementConstraintsProperty | undefined;
        set internalValue(value: PlacementConstraintsProperty | undefined);
        get expression(): string;
        get type(): string;
    }
    class PlacementConstraintsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): PlacementConstraintsPropertyOutputReference;
    }
    interface ServiceRegistriesProperty {
    }
    class ServiceRegistriesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ServiceRegistriesProperty | undefined;
        set internalValue(value: ServiceRegistriesProperty | undefined);
        get containerName(): string;
        get containerPort(): number;
        get port(): number;
        get registryArn(): string;
    }
    class ServiceRegistriesPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ServiceRegistriesPropertyOutputReference;
    }
    interface TaskSetsProperty {
    }
    class TaskSetsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TaskSetsProperty | undefined;
        set internalValue(value: TaskSetsProperty | undefined);
        get arn(): string;
        get createdAt(): string;
        get id(): string;
        get pendingCount(): number;
        get runningCount(): number;
        get stabilityStatus(): string;
        get status(): string;
        get taskDefinition(): string;
        get updatedAt(): string;
    }
    class TaskSetsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TaskSetsPropertyOutputReference;
    }
}
