import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsEcsServiceConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#availability_zone_rebalancing AwsEcsService#availability_zone_rebalancing}
    */
    readonly availabilityZoneRebalancing?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#cluster AwsEcsService#cluster}
    */
    readonly cluster?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#deployment_maximum_percent AwsEcsService#deployment_maximum_percent}
    */
    readonly deploymentMaximumPercent?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#deployment_minimum_healthy_percent AwsEcsService#deployment_minimum_healthy_percent}
    */
    readonly deploymentMinimumHealthyPercent?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#desired_count AwsEcsService#desired_count}
    */
    readonly desiredCount?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#enable_ecs_managed_tags AwsEcsService#enable_ecs_managed_tags}
    */
    readonly enableEcsManagedTags?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#enable_execute_command AwsEcsService#enable_execute_command}
    */
    readonly enableExecuteCommand?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#force_delete AwsEcsService#force_delete}
    */
    readonly forceDelete?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#force_new_deployment AwsEcsService#force_new_deployment}
    */
    readonly forceNewDeployment?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#health_check_grace_period_seconds AwsEcsService#health_check_grace_period_seconds}
    */
    readonly healthCheckGracePeriodSeconds?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#iam_role AwsEcsService#iam_role}
    */
    readonly iamRole?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#id AwsEcsService#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#launch_type AwsEcsService#launch_type}
    */
    readonly launchType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#name AwsEcsService#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#platform_version AwsEcsService#platform_version}
    */
    readonly platformVersion?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#propagate_tags AwsEcsService#propagate_tags}
    */
    readonly propagateTags?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#region AwsEcsService#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#scheduling_strategy AwsEcsService#scheduling_strategy}
    */
    readonly schedulingStrategy?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#sigint_rollback AwsEcsService#sigint_rollback}
    */
    readonly sigintRollback?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#tags AwsEcsService#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#tags_all AwsEcsService#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#task_definition AwsEcsService#task_definition}
    */
    readonly taskDefinition?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#triggers AwsEcsService#triggers}
    */
    readonly triggers?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#wait_for_steady_state AwsEcsService#wait_for_steady_state}
    */
    readonly waitForSteadyState?: boolean | cdktn.IResolvable;
    /**
    * alarms block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#alarms AwsEcsService#alarms}
    */
    readonly alarms?: AwsEcsService.AlarmsProperty;
    /**
    * capacity_provider_strategy block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#capacity_provider_strategy AwsEcsService#capacity_provider_strategy}
    */
    readonly capacityProviderStrategy?: AwsEcsService.CapacityProviderStrategyProperty[] | cdktn.IResolvable;
    /**
    * deployment_circuit_breaker block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#deployment_circuit_breaker AwsEcsService#deployment_circuit_breaker}
    */
    readonly deploymentCircuitBreaker?: AwsEcsService.DeploymentCircuitBreakerProperty;
    /**
    * deployment_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#deployment_configuration AwsEcsService#deployment_configuration}
    */
    readonly deploymentConfiguration?: AwsEcsService.DeploymentConfigurationProperty;
    /**
    * deployment_controller block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#deployment_controller AwsEcsService#deployment_controller}
    */
    readonly deploymentController?: AwsEcsService.DeploymentControllerProperty;
    /**
    * load_balancer block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#load_balancer AwsEcsService#load_balancer}
    */
    readonly loadBalancer?: AwsEcsService.LoadBalancerProperty[] | cdktn.IResolvable;
    /**
    * network_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#network_configuration AwsEcsService#network_configuration}
    */
    readonly networkConfiguration?: AwsEcsService.NetworkConfigurationProperty;
    /**
    * ordered_placement_strategy block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#ordered_placement_strategy AwsEcsService#ordered_placement_strategy}
    */
    readonly orderedPlacementStrategy?: AwsEcsService.OrderedPlacementStrategyProperty[] | cdktn.IResolvable;
    /**
    * placement_constraints block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#placement_constraints AwsEcsService#placement_constraints}
    */
    readonly placementConstraints?: AwsEcsService.PlacementConstraintsProperty[] | cdktn.IResolvable;
    /**
    * service_connect_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#service_connect_configuration AwsEcsService#service_connect_configuration}
    */
    readonly serviceConnectConfiguration?: AwsEcsService.ServiceConnectConfigurationProperty;
    /**
    * service_registries block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#service_registries AwsEcsService#service_registries}
    */
    readonly serviceRegistries?: AwsEcsService.ServiceRegistriesProperty;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#timeouts AwsEcsService#timeouts}
    */
    readonly timeouts?: AwsEcsService.TimeoutsProperty;
    /**
    * volume_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#volume_configuration AwsEcsService#volume_configuration}
    */
    readonly volumeConfiguration?: AwsEcsService.VolumeConfigurationProperty;
    /**
    * vpc_lattice_configurations block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#vpc_lattice_configurations AwsEcsService#vpc_lattice_configurations}
    */
    readonly vpcLatticeConfigurations?: AwsEcsService.VpcLatticeConfigurationsProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service aws_ecs_service}
*/
export declare class AwsEcsService extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_ecs_service";
    /**
    * Generates CDKTN code for importing a AwsEcsService resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsEcsService to import
    * @param importFromId The id of the existing AwsEcsService that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsEcsService to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service aws_ecs_service} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsEcsServiceConfig
    */
    constructor(scope: Construct, id: string, config: AwsEcsServiceConfig);
    get arn(): string;
    private _availabilityZoneRebalancing?;
    get availabilityZoneRebalancing(): string;
    set availabilityZoneRebalancing(value: string);
    resetAvailabilityZoneRebalancing(): void;
    get availabilityZoneRebalancingInput(): string | undefined;
    private _cluster?;
    get cluster(): string;
    set cluster(value: string);
    resetCluster(): void;
    get clusterInput(): string | undefined;
    private _deploymentMaximumPercent?;
    get deploymentMaximumPercent(): number;
    set deploymentMaximumPercent(value: number);
    resetDeploymentMaximumPercent(): void;
    get deploymentMaximumPercentInput(): number | undefined;
    private _deploymentMinimumHealthyPercent?;
    get deploymentMinimumHealthyPercent(): number;
    set deploymentMinimumHealthyPercent(value: number);
    resetDeploymentMinimumHealthyPercent(): void;
    get deploymentMinimumHealthyPercentInput(): number | undefined;
    private _desiredCount?;
    get desiredCount(): number;
    set desiredCount(value: number);
    resetDesiredCount(): void;
    get desiredCountInput(): number | undefined;
    private _enableEcsManagedTags?;
    get enableEcsManagedTags(): boolean | cdktn.IResolvable;
    set enableEcsManagedTags(value: boolean | cdktn.IResolvable);
    resetEnableEcsManagedTags(): void;
    get enableEcsManagedTagsInput(): boolean | cdktn.IResolvable | undefined;
    private _enableExecuteCommand?;
    get enableExecuteCommand(): boolean | cdktn.IResolvable;
    set enableExecuteCommand(value: boolean | cdktn.IResolvable);
    resetEnableExecuteCommand(): void;
    get enableExecuteCommandInput(): boolean | cdktn.IResolvable | undefined;
    private _forceDelete?;
    get forceDelete(): boolean | cdktn.IResolvable;
    set forceDelete(value: boolean | cdktn.IResolvable);
    resetForceDelete(): void;
    get forceDeleteInput(): boolean | cdktn.IResolvable | undefined;
    private _forceNewDeployment?;
    get forceNewDeployment(): boolean | cdktn.IResolvable;
    set forceNewDeployment(value: boolean | cdktn.IResolvable);
    resetForceNewDeployment(): void;
    get forceNewDeploymentInput(): boolean | cdktn.IResolvable | undefined;
    private _healthCheckGracePeriodSeconds?;
    get healthCheckGracePeriodSeconds(): number;
    set healthCheckGracePeriodSeconds(value: number);
    resetHealthCheckGracePeriodSeconds(): void;
    get healthCheckGracePeriodSecondsInput(): number | undefined;
    private _iamRole?;
    get iamRole(): string;
    set iamRole(value: string);
    resetIamRole(): void;
    get iamRoleInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _launchType?;
    get launchType(): string;
    set launchType(value: string);
    resetLaunchType(): void;
    get launchTypeInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _platformVersion?;
    get platformVersion(): string;
    set platformVersion(value: string);
    resetPlatformVersion(): void;
    get platformVersionInput(): string | undefined;
    private _propagateTags?;
    get propagateTags(): string;
    set propagateTags(value: string);
    resetPropagateTags(): void;
    get propagateTagsInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _schedulingStrategy?;
    get schedulingStrategy(): string;
    set schedulingStrategy(value: string);
    resetSchedulingStrategy(): void;
    get schedulingStrategyInput(): string | undefined;
    private _sigintRollback?;
    get sigintRollback(): boolean | cdktn.IResolvable;
    set sigintRollback(value: boolean | cdktn.IResolvable);
    resetSigintRollback(): void;
    get sigintRollbackInput(): boolean | cdktn.IResolvable | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _taskDefinition?;
    get taskDefinition(): string;
    set taskDefinition(value: string);
    resetTaskDefinition(): void;
    get taskDefinitionInput(): string | undefined;
    private _triggers?;
    get triggers(): {
        [key: string]: string;
    };
    set triggers(value: {
        [key: string]: string;
    });
    resetTriggers(): void;
    get triggersInput(): {
        [key: string]: string;
    } | undefined;
    private _waitForSteadyState?;
    get waitForSteadyState(): boolean | cdktn.IResolvable;
    set waitForSteadyState(value: boolean | cdktn.IResolvable);
    resetWaitForSteadyState(): void;
    get waitForSteadyStateInput(): boolean | cdktn.IResolvable | undefined;
    private _alarms;
    get alarms(): AwsEcsService.AlarmsPropertyOutputReference;
    putAlarms(value: AwsEcsService.AlarmsProperty): void;
    resetAlarms(): void;
    get alarmsInput(): AwsEcsService.AlarmsProperty | undefined;
    private _capacityProviderStrategy;
    get capacityProviderStrategy(): AwsEcsService.CapacityProviderStrategyPropertyList;
    putCapacityProviderStrategy(value: AwsEcsService.CapacityProviderStrategyProperty[] | cdktn.IResolvable): void;
    resetCapacityProviderStrategy(): void;
    get capacityProviderStrategyInput(): cdktn.IResolvable | AwsEcsService.CapacityProviderStrategyProperty[] | undefined;
    private _deploymentCircuitBreaker;
    get deploymentCircuitBreaker(): AwsEcsService.DeploymentCircuitBreakerPropertyOutputReference;
    putDeploymentCircuitBreaker(value: AwsEcsService.DeploymentCircuitBreakerProperty): void;
    resetDeploymentCircuitBreaker(): void;
    get deploymentCircuitBreakerInput(): AwsEcsService.DeploymentCircuitBreakerProperty | undefined;
    private _deploymentConfiguration;
    get deploymentConfiguration(): AwsEcsService.DeploymentConfigurationPropertyOutputReference;
    putDeploymentConfiguration(value: AwsEcsService.DeploymentConfigurationProperty): void;
    resetDeploymentConfiguration(): void;
    get deploymentConfigurationInput(): AwsEcsService.DeploymentConfigurationProperty | undefined;
    private _deploymentController;
    get deploymentController(): AwsEcsService.DeploymentControllerPropertyOutputReference;
    putDeploymentController(value: AwsEcsService.DeploymentControllerProperty): void;
    resetDeploymentController(): void;
    get deploymentControllerInput(): AwsEcsService.DeploymentControllerProperty | undefined;
    private _loadBalancer;
    get loadBalancer(): AwsEcsService.LoadBalancerPropertyList;
    putLoadBalancer(value: AwsEcsService.LoadBalancerProperty[] | cdktn.IResolvable): void;
    resetLoadBalancer(): void;
    get loadBalancerInput(): cdktn.IResolvable | AwsEcsService.LoadBalancerProperty[] | undefined;
    private _networkConfiguration;
    get networkConfiguration(): AwsEcsService.NetworkConfigurationPropertyOutputReference;
    putNetworkConfiguration(value: AwsEcsService.NetworkConfigurationProperty): void;
    resetNetworkConfiguration(): void;
    get networkConfigurationInput(): AwsEcsService.NetworkConfigurationProperty | undefined;
    private _orderedPlacementStrategy;
    get orderedPlacementStrategy(): AwsEcsService.OrderedPlacementStrategyPropertyList;
    putOrderedPlacementStrategy(value: AwsEcsService.OrderedPlacementStrategyProperty[] | cdktn.IResolvable): void;
    resetOrderedPlacementStrategy(): void;
    get orderedPlacementStrategyInput(): cdktn.IResolvable | AwsEcsService.OrderedPlacementStrategyProperty[] | undefined;
    private _placementConstraints;
    get placementConstraints(): AwsEcsService.PlacementConstraintsPropertyList;
    putPlacementConstraints(value: AwsEcsService.PlacementConstraintsProperty[] | cdktn.IResolvable): void;
    resetPlacementConstraints(): void;
    get placementConstraintsInput(): cdktn.IResolvable | AwsEcsService.PlacementConstraintsProperty[] | undefined;
    private _serviceConnectConfiguration;
    get serviceConnectConfiguration(): AwsEcsService.ServiceConnectConfigurationPropertyOutputReference;
    putServiceConnectConfiguration(value: AwsEcsService.ServiceConnectConfigurationProperty): void;
    resetServiceConnectConfiguration(): void;
    get serviceConnectConfigurationInput(): AwsEcsService.ServiceConnectConfigurationProperty | undefined;
    private _serviceRegistries;
    get serviceRegistries(): AwsEcsService.ServiceRegistriesPropertyOutputReference;
    putServiceRegistries(value: AwsEcsService.ServiceRegistriesProperty): void;
    resetServiceRegistries(): void;
    get serviceRegistriesInput(): AwsEcsService.ServiceRegistriesProperty | undefined;
    private _timeouts;
    get timeouts(): AwsEcsService.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsEcsService.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsEcsService.TimeoutsProperty | undefined;
    private _volumeConfiguration;
    get volumeConfiguration(): AwsEcsService.VolumeConfigurationPropertyOutputReference;
    putVolumeConfiguration(value: AwsEcsService.VolumeConfigurationProperty): void;
    resetVolumeConfiguration(): void;
    get volumeConfigurationInput(): AwsEcsService.VolumeConfigurationProperty | undefined;
    private _vpcLatticeConfigurations;
    get vpcLatticeConfigurations(): AwsEcsService.VpcLatticeConfigurationsPropertyList;
    putVpcLatticeConfigurations(value: AwsEcsService.VpcLatticeConfigurationsProperty[] | cdktn.IResolvable): void;
    resetVpcLatticeConfigurations(): void;
    get vpcLatticeConfigurationsInput(): cdktn.IResolvable | AwsEcsService.VpcLatticeConfigurationsProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsEcsServiceAlarmsPropertyToTerraform(struct?: AwsEcsService.AlarmsPropertyOutputReference | AwsEcsService.AlarmsProperty): any;
export declare function awsEcsServiceAlarmsPropertyToHclTerraform(struct?: AwsEcsService.AlarmsPropertyOutputReference | AwsEcsService.AlarmsProperty): any;
export declare function awsEcsServiceCapacityProviderStrategyPropertyToTerraform(struct?: AwsEcsService.CapacityProviderStrategyProperty | cdktn.IResolvable): any;
export declare function awsEcsServiceCapacityProviderStrategyPropertyToHclTerraform(struct?: AwsEcsService.CapacityProviderStrategyProperty | cdktn.IResolvable): any;
export declare function awsEcsServiceDeploymentCircuitBreakerPropertyToTerraform(struct?: AwsEcsService.DeploymentCircuitBreakerPropertyOutputReference | AwsEcsService.DeploymentCircuitBreakerProperty): any;
export declare function awsEcsServiceDeploymentCircuitBreakerPropertyToHclTerraform(struct?: AwsEcsService.DeploymentCircuitBreakerPropertyOutputReference | AwsEcsService.DeploymentCircuitBreakerProperty): any;
export declare function awsEcsServiceCanaryConfigurationPropertyToTerraform(struct?: AwsEcsService.CanaryConfigurationPropertyOutputReference | AwsEcsService.CanaryConfigurationProperty): any;
export declare function awsEcsServiceCanaryConfigurationPropertyToHclTerraform(struct?: AwsEcsService.CanaryConfigurationPropertyOutputReference | AwsEcsService.CanaryConfigurationProperty): any;
export declare function awsEcsServiceLifecycleHookPropertyToTerraform(struct?: AwsEcsService.LifecycleHookProperty | cdktn.IResolvable): any;
export declare function awsEcsServiceLifecycleHookPropertyToHclTerraform(struct?: AwsEcsService.LifecycleHookProperty | cdktn.IResolvable): any;
export declare function awsEcsServiceLinearConfigurationPropertyToTerraform(struct?: AwsEcsService.LinearConfigurationPropertyOutputReference | AwsEcsService.LinearConfigurationProperty): any;
export declare function awsEcsServiceLinearConfigurationPropertyToHclTerraform(struct?: AwsEcsService.LinearConfigurationPropertyOutputReference | AwsEcsService.LinearConfigurationProperty): any;
export declare function awsEcsServiceDeploymentConfigurationPropertyToTerraform(struct?: AwsEcsService.DeploymentConfigurationPropertyOutputReference | AwsEcsService.DeploymentConfigurationProperty): any;
export declare function awsEcsServiceDeploymentConfigurationPropertyToHclTerraform(struct?: AwsEcsService.DeploymentConfigurationPropertyOutputReference | AwsEcsService.DeploymentConfigurationProperty): any;
export declare function awsEcsServiceDeploymentControllerPropertyToTerraform(struct?: AwsEcsService.DeploymentControllerPropertyOutputReference | AwsEcsService.DeploymentControllerProperty): any;
export declare function awsEcsServiceDeploymentControllerPropertyToHclTerraform(struct?: AwsEcsService.DeploymentControllerPropertyOutputReference | AwsEcsService.DeploymentControllerProperty): any;
export declare function awsEcsServiceAdvancedConfigurationPropertyToTerraform(struct?: AwsEcsService.AdvancedConfigurationPropertyOutputReference | AwsEcsService.AdvancedConfigurationProperty): any;
export declare function awsEcsServiceAdvancedConfigurationPropertyToHclTerraform(struct?: AwsEcsService.AdvancedConfigurationPropertyOutputReference | AwsEcsService.AdvancedConfigurationProperty): any;
export declare function awsEcsServiceLoadBalancerPropertyToTerraform(struct?: AwsEcsService.LoadBalancerProperty | cdktn.IResolvable): any;
export declare function awsEcsServiceLoadBalancerPropertyToHclTerraform(struct?: AwsEcsService.LoadBalancerProperty | cdktn.IResolvable): any;
export declare function awsEcsServiceNetworkConfigurationPropertyToTerraform(struct?: AwsEcsService.NetworkConfigurationPropertyOutputReference | AwsEcsService.NetworkConfigurationProperty): any;
export declare function awsEcsServiceNetworkConfigurationPropertyToHclTerraform(struct?: AwsEcsService.NetworkConfigurationPropertyOutputReference | AwsEcsService.NetworkConfigurationProperty): any;
export declare function awsEcsServiceOrderedPlacementStrategyPropertyToTerraform(struct?: AwsEcsService.OrderedPlacementStrategyProperty | cdktn.IResolvable): any;
export declare function awsEcsServiceOrderedPlacementStrategyPropertyToHclTerraform(struct?: AwsEcsService.OrderedPlacementStrategyProperty | cdktn.IResolvable): any;
export declare function awsEcsServicePlacementConstraintsPropertyToTerraform(struct?: AwsEcsService.PlacementConstraintsProperty | cdktn.IResolvable): any;
export declare function awsEcsServicePlacementConstraintsPropertyToHclTerraform(struct?: AwsEcsService.PlacementConstraintsProperty | cdktn.IResolvable): any;
export declare function awsEcsServiceAccessLogConfigurationPropertyToTerraform(struct?: AwsEcsService.AccessLogConfigurationPropertyOutputReference | AwsEcsService.AccessLogConfigurationProperty): any;
export declare function awsEcsServiceAccessLogConfigurationPropertyToHclTerraform(struct?: AwsEcsService.AccessLogConfigurationPropertyOutputReference | AwsEcsService.AccessLogConfigurationProperty): any;
export declare function awsEcsServiceSecretOptionPropertyToTerraform(struct?: AwsEcsService.SecretOptionProperty | cdktn.IResolvable): any;
export declare function awsEcsServiceSecretOptionPropertyToHclTerraform(struct?: AwsEcsService.SecretOptionProperty | cdktn.IResolvable): any;
export declare function awsEcsServiceLogConfigurationPropertyToTerraform(struct?: AwsEcsService.LogConfigurationPropertyOutputReference | AwsEcsService.LogConfigurationProperty): any;
export declare function awsEcsServiceLogConfigurationPropertyToHclTerraform(struct?: AwsEcsService.LogConfigurationPropertyOutputReference | AwsEcsService.LogConfigurationProperty): any;
export declare function awsEcsServiceValuePropertyToTerraform(struct?: AwsEcsService.ValuePropertyOutputReference | AwsEcsService.ValueProperty): any;
export declare function awsEcsServiceValuePropertyToHclTerraform(struct?: AwsEcsService.ValuePropertyOutputReference | AwsEcsService.ValueProperty): any;
export declare function awsEcsServiceHeaderPropertyToTerraform(struct?: AwsEcsService.HeaderPropertyOutputReference | AwsEcsService.HeaderProperty): any;
export declare function awsEcsServiceHeaderPropertyToHclTerraform(struct?: AwsEcsService.HeaderPropertyOutputReference | AwsEcsService.HeaderProperty): any;
export declare function awsEcsServiceTestTrafficRulesPropertyToTerraform(struct?: AwsEcsService.TestTrafficRulesProperty | cdktn.IResolvable): any;
export declare function awsEcsServiceTestTrafficRulesPropertyToHclTerraform(struct?: AwsEcsService.TestTrafficRulesProperty | cdktn.IResolvable): any;
export declare function awsEcsServiceClientAliasPropertyToTerraform(struct?: AwsEcsService.ClientAliasPropertyOutputReference | AwsEcsService.ClientAliasProperty): any;
export declare function awsEcsServiceClientAliasPropertyToHclTerraform(struct?: AwsEcsService.ClientAliasPropertyOutputReference | AwsEcsService.ClientAliasProperty): any;
export declare function awsEcsServiceTimeoutPropertyToTerraform(struct?: AwsEcsService.TimeoutPropertyOutputReference | AwsEcsService.TimeoutProperty): any;
export declare function awsEcsServiceTimeoutPropertyToHclTerraform(struct?: AwsEcsService.TimeoutPropertyOutputReference | AwsEcsService.TimeoutProperty): any;
export declare function awsEcsServiceIssuerCertAuthorityPropertyToTerraform(struct?: AwsEcsService.IssuerCertAuthorityPropertyOutputReference | AwsEcsService.IssuerCertAuthorityProperty): any;
export declare function awsEcsServiceIssuerCertAuthorityPropertyToHclTerraform(struct?: AwsEcsService.IssuerCertAuthorityPropertyOutputReference | AwsEcsService.IssuerCertAuthorityProperty): any;
export declare function awsEcsServiceTlsPropertyToTerraform(struct?: AwsEcsService.TlsPropertyOutputReference | AwsEcsService.TlsProperty): any;
export declare function awsEcsServiceTlsPropertyToHclTerraform(struct?: AwsEcsService.TlsPropertyOutputReference | AwsEcsService.TlsProperty): any;
export declare function awsEcsServiceServicePropertyToTerraform(struct?: AwsEcsService.ServiceProperty | cdktn.IResolvable): any;
export declare function awsEcsServiceServicePropertyToHclTerraform(struct?: AwsEcsService.ServiceProperty | cdktn.IResolvable): any;
export declare function awsEcsServiceServiceConnectConfigurationPropertyToTerraform(struct?: AwsEcsService.ServiceConnectConfigurationPropertyOutputReference | AwsEcsService.ServiceConnectConfigurationProperty): any;
export declare function awsEcsServiceServiceConnectConfigurationPropertyToHclTerraform(struct?: AwsEcsService.ServiceConnectConfigurationPropertyOutputReference | AwsEcsService.ServiceConnectConfigurationProperty): any;
export declare function awsEcsServiceServiceRegistriesPropertyToTerraform(struct?: AwsEcsService.ServiceRegistriesPropertyOutputReference | AwsEcsService.ServiceRegistriesProperty): any;
export declare function awsEcsServiceServiceRegistriesPropertyToHclTerraform(struct?: AwsEcsService.ServiceRegistriesPropertyOutputReference | AwsEcsService.ServiceRegistriesProperty): any;
export declare function awsEcsServiceTimeoutsPropertyToTerraform(struct?: AwsEcsService.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsEcsServiceTimeoutsPropertyToHclTerraform(struct?: AwsEcsService.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsEcsServiceTagSpecificationsPropertyToTerraform(struct?: AwsEcsService.TagSpecificationsProperty | cdktn.IResolvable): any;
export declare function awsEcsServiceTagSpecificationsPropertyToHclTerraform(struct?: AwsEcsService.TagSpecificationsProperty | cdktn.IResolvable): any;
export declare function awsEcsServiceManagedEbsVolumePropertyToTerraform(struct?: AwsEcsService.ManagedEbsVolumePropertyOutputReference | AwsEcsService.ManagedEbsVolumeProperty): any;
export declare function awsEcsServiceManagedEbsVolumePropertyToHclTerraform(struct?: AwsEcsService.ManagedEbsVolumePropertyOutputReference | AwsEcsService.ManagedEbsVolumeProperty): any;
export declare function awsEcsServiceVolumeConfigurationPropertyToTerraform(struct?: AwsEcsService.VolumeConfigurationPropertyOutputReference | AwsEcsService.VolumeConfigurationProperty): any;
export declare function awsEcsServiceVolumeConfigurationPropertyToHclTerraform(struct?: AwsEcsService.VolumeConfigurationPropertyOutputReference | AwsEcsService.VolumeConfigurationProperty): any;
export declare function awsEcsServiceVpcLatticeConfigurationsPropertyToTerraform(struct?: AwsEcsService.VpcLatticeConfigurationsProperty | cdktn.IResolvable): any;
export declare function awsEcsServiceVpcLatticeConfigurationsPropertyToHclTerraform(struct?: AwsEcsService.VpcLatticeConfigurationsProperty | cdktn.IResolvable): any;
export declare namespace AwsEcsService {
    interface AlarmsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#alarm_names AwsEcsService#alarm_names}
        */
        readonly alarmNames: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#enable AwsEcsService#enable}
        */
        readonly enable: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#rollback AwsEcsService#rollback}
        */
        readonly rollback: boolean | cdktn.IResolvable;
    }
    class AlarmsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AlarmsProperty | undefined;
        set internalValue(value: AlarmsProperty | undefined);
        private _alarmNames?;
        get alarmNames(): string[];
        set alarmNames(value: string[]);
        get alarmNamesInput(): string[] | undefined;
        private _enable?;
        get enable(): boolean | cdktn.IResolvable;
        set enable(value: boolean | cdktn.IResolvable);
        get enableInput(): boolean | cdktn.IResolvable | undefined;
        private _rollback?;
        get rollback(): boolean | cdktn.IResolvable;
        set rollback(value: boolean | cdktn.IResolvable);
        get rollbackInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface CapacityProviderStrategyProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#base AwsEcsService#base}
        */
        readonly base?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#capacity_provider AwsEcsService#capacity_provider}
        */
        readonly capacityProvider: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#weight AwsEcsService#weight}
        */
        readonly weight?: number;
    }
    class CapacityProviderStrategyPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CapacityProviderStrategyProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CapacityProviderStrategyProperty | cdktn.IResolvable | undefined);
        private _base?;
        get base(): number;
        set base(value: number);
        resetBase(): void;
        get baseInput(): number | undefined;
        private _capacityProvider?;
        get capacityProvider(): string;
        set capacityProvider(value: string);
        get capacityProviderInput(): string | undefined;
        private _weight?;
        get weight(): number;
        set weight(value: number);
        resetWeight(): void;
        get weightInput(): number | undefined;
    }
    class CapacityProviderStrategyPropertyList extends cdktn.ComplexList {
        internalValue?: CapacityProviderStrategyProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CapacityProviderStrategyPropertyOutputReference;
    }
    interface DeploymentCircuitBreakerProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#enable AwsEcsService#enable}
        */
        readonly enable: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#rollback AwsEcsService#rollback}
        */
        readonly rollback: boolean | cdktn.IResolvable;
    }
    class DeploymentCircuitBreakerPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DeploymentCircuitBreakerProperty | undefined;
        set internalValue(value: DeploymentCircuitBreakerProperty | undefined);
        private _enable?;
        get enable(): boolean | cdktn.IResolvable;
        set enable(value: boolean | cdktn.IResolvable);
        get enableInput(): boolean | cdktn.IResolvable | undefined;
        private _rollback?;
        get rollback(): boolean | cdktn.IResolvable;
        set rollback(value: boolean | cdktn.IResolvable);
        get rollbackInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface CanaryConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#canary_bake_time_in_minutes AwsEcsService#canary_bake_time_in_minutes}
        */
        readonly canaryBakeTimeInMinutes?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#canary_percent AwsEcsService#canary_percent}
        */
        readonly canaryPercent?: number;
    }
    class CanaryConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CanaryConfigurationProperty | undefined;
        set internalValue(value: CanaryConfigurationProperty | undefined);
        private _canaryBakeTimeInMinutes?;
        get canaryBakeTimeInMinutes(): string;
        set canaryBakeTimeInMinutes(value: string);
        resetCanaryBakeTimeInMinutes(): void;
        get canaryBakeTimeInMinutesInput(): string | undefined;
        private _canaryPercent?;
        get canaryPercent(): number;
        set canaryPercent(value: number);
        resetCanaryPercent(): void;
        get canaryPercentInput(): number | undefined;
    }
    interface LifecycleHookProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#hook_details AwsEcsService#hook_details}
        */
        readonly hookDetails?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#hook_target_arn AwsEcsService#hook_target_arn}
        */
        readonly hookTargetArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#lifecycle_stages AwsEcsService#lifecycle_stages}
        */
        readonly lifecycleStages: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#role_arn AwsEcsService#role_arn}
        */
        readonly roleArn: string;
    }
    class LifecycleHookPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): LifecycleHookProperty | cdktn.IResolvable | undefined;
        set internalValue(value: LifecycleHookProperty | cdktn.IResolvable | undefined);
        private _hookDetails?;
        get hookDetails(): string;
        set hookDetails(value: string);
        resetHookDetails(): void;
        get hookDetailsInput(): string | undefined;
        private _hookTargetArn?;
        get hookTargetArn(): string;
        set hookTargetArn(value: string);
        get hookTargetArnInput(): string | undefined;
        private _lifecycleStages?;
        get lifecycleStages(): string[];
        set lifecycleStages(value: string[]);
        get lifecycleStagesInput(): string[] | undefined;
        private _roleArn?;
        get roleArn(): string;
        set roleArn(value: string);
        get roleArnInput(): string | undefined;
    }
    class LifecycleHookPropertyList extends cdktn.ComplexList {
        internalValue?: LifecycleHookProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): LifecycleHookPropertyOutputReference;
    }
    interface LinearConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#step_bake_time_in_minutes AwsEcsService#step_bake_time_in_minutes}
        */
        readonly stepBakeTimeInMinutes?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#step_percent AwsEcsService#step_percent}
        */
        readonly stepPercent?: number;
    }
    class LinearConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): LinearConfigurationProperty | undefined;
        set internalValue(value: LinearConfigurationProperty | undefined);
        private _stepBakeTimeInMinutes?;
        get stepBakeTimeInMinutes(): string;
        set stepBakeTimeInMinutes(value: string);
        resetStepBakeTimeInMinutes(): void;
        get stepBakeTimeInMinutesInput(): string | undefined;
        private _stepPercent?;
        get stepPercent(): number;
        set stepPercent(value: number);
        resetStepPercent(): void;
        get stepPercentInput(): number | undefined;
    }
    interface DeploymentConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#bake_time_in_minutes AwsEcsService#bake_time_in_minutes}
        */
        readonly bakeTimeInMinutes?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#strategy AwsEcsService#strategy}
        */
        readonly strategy?: string;
        /**
        * canary_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#canary_configuration AwsEcsService#canary_configuration}
        */
        readonly canaryConfiguration?: CanaryConfigurationProperty;
        /**
        * lifecycle_hook block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#lifecycle_hook AwsEcsService#lifecycle_hook}
        */
        readonly lifecycleHook?: LifecycleHookProperty[] | cdktn.IResolvable;
        /**
        * linear_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#linear_configuration AwsEcsService#linear_configuration}
        */
        readonly linearConfiguration?: LinearConfigurationProperty;
    }
    class DeploymentConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DeploymentConfigurationProperty | undefined;
        set internalValue(value: DeploymentConfigurationProperty | undefined);
        private _bakeTimeInMinutes?;
        get bakeTimeInMinutes(): string;
        set bakeTimeInMinutes(value: string);
        resetBakeTimeInMinutes(): void;
        get bakeTimeInMinutesInput(): string | undefined;
        private _strategy?;
        get strategy(): string;
        set strategy(value: string);
        resetStrategy(): void;
        get strategyInput(): string | undefined;
        private _canaryConfiguration;
        get canaryConfiguration(): CanaryConfigurationPropertyOutputReference;
        putCanaryConfiguration(value: CanaryConfigurationProperty): void;
        resetCanaryConfiguration(): void;
        get canaryConfigurationInput(): CanaryConfigurationProperty | undefined;
        private _lifecycleHook;
        get lifecycleHook(): LifecycleHookPropertyList;
        putLifecycleHook(value: LifecycleHookProperty[] | cdktn.IResolvable): void;
        resetLifecycleHook(): void;
        get lifecycleHookInput(): cdktn.IResolvable | LifecycleHookProperty[] | undefined;
        private _linearConfiguration;
        get linearConfiguration(): LinearConfigurationPropertyOutputReference;
        putLinearConfiguration(value: LinearConfigurationProperty): void;
        resetLinearConfiguration(): void;
        get linearConfigurationInput(): LinearConfigurationProperty | undefined;
    }
    interface DeploymentControllerProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#type AwsEcsService#type}
        */
        readonly type?: string;
    }
    class DeploymentControllerPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DeploymentControllerProperty | undefined;
        set internalValue(value: DeploymentControllerProperty | undefined);
        private _type?;
        get type(): string;
        set type(value: string);
        resetType(): void;
        get typeInput(): string | undefined;
    }
    interface AdvancedConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#alternate_target_group_arn AwsEcsService#alternate_target_group_arn}
        */
        readonly alternateTargetGroupArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#production_listener_rule AwsEcsService#production_listener_rule}
        */
        readonly productionListenerRule: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#role_arn AwsEcsService#role_arn}
        */
        readonly roleArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#test_listener_rule AwsEcsService#test_listener_rule}
        */
        readonly testListenerRule?: string;
    }
    class AdvancedConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AdvancedConfigurationProperty | undefined;
        set internalValue(value: AdvancedConfigurationProperty | undefined);
        private _alternateTargetGroupArn?;
        get alternateTargetGroupArn(): string;
        set alternateTargetGroupArn(value: string);
        get alternateTargetGroupArnInput(): string | undefined;
        private _productionListenerRule?;
        get productionListenerRule(): string;
        set productionListenerRule(value: string);
        get productionListenerRuleInput(): string | undefined;
        private _roleArn?;
        get roleArn(): string;
        set roleArn(value: string);
        get roleArnInput(): string | undefined;
        private _testListenerRule?;
        get testListenerRule(): string;
        set testListenerRule(value: string);
        resetTestListenerRule(): void;
        get testListenerRuleInput(): string | undefined;
    }
    interface LoadBalancerProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#container_name AwsEcsService#container_name}
        */
        readonly containerName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#container_port AwsEcsService#container_port}
        */
        readonly containerPort: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#elb_name AwsEcsService#elb_name}
        */
        readonly elbName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#target_group_arn AwsEcsService#target_group_arn}
        */
        readonly targetGroupArn?: string;
        /**
        * advanced_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#advanced_configuration AwsEcsService#advanced_configuration}
        */
        readonly advancedConfiguration?: AdvancedConfigurationProperty;
    }
    class LoadBalancerPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): LoadBalancerProperty | cdktn.IResolvable | undefined;
        set internalValue(value: LoadBalancerProperty | cdktn.IResolvable | undefined);
        private _containerName?;
        get containerName(): string;
        set containerName(value: string);
        get containerNameInput(): string | undefined;
        private _containerPort?;
        get containerPort(): number;
        set containerPort(value: number);
        get containerPortInput(): number | undefined;
        private _elbName?;
        get elbName(): string;
        set elbName(value: string);
        resetElbName(): void;
        get elbNameInput(): string | undefined;
        private _targetGroupArn?;
        get targetGroupArn(): string;
        set targetGroupArn(value: string);
        resetTargetGroupArn(): void;
        get targetGroupArnInput(): string | undefined;
        private _advancedConfiguration;
        get advancedConfiguration(): AdvancedConfigurationPropertyOutputReference;
        putAdvancedConfiguration(value: AdvancedConfigurationProperty): void;
        resetAdvancedConfiguration(): void;
        get advancedConfigurationInput(): AdvancedConfigurationProperty | undefined;
    }
    class LoadBalancerPropertyList extends cdktn.ComplexList {
        internalValue?: LoadBalancerProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): LoadBalancerPropertyOutputReference;
    }
    interface NetworkConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#assign_public_ip AwsEcsService#assign_public_ip}
        */
        readonly assignPublicIp?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#security_groups AwsEcsService#security_groups}
        */
        readonly securityGroups?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#subnets AwsEcsService#subnets}
        */
        readonly subnets: string[];
    }
    class NetworkConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): NetworkConfigurationProperty | undefined;
        set internalValue(value: NetworkConfigurationProperty | undefined);
        private _assignPublicIp?;
        get assignPublicIp(): boolean | cdktn.IResolvable;
        set assignPublicIp(value: boolean | cdktn.IResolvable);
        resetAssignPublicIp(): void;
        get assignPublicIpInput(): boolean | cdktn.IResolvable | undefined;
        private _securityGroups?;
        get securityGroups(): string[];
        set securityGroups(value: string[]);
        resetSecurityGroups(): void;
        get securityGroupsInput(): string[] | undefined;
        private _subnets?;
        get subnets(): string[];
        set subnets(value: string[]);
        get subnetsInput(): string[] | undefined;
    }
    interface OrderedPlacementStrategyProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#field AwsEcsService#field}
        */
        readonly field?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#type AwsEcsService#type}
        */
        readonly type: string;
    }
    class OrderedPlacementStrategyPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): OrderedPlacementStrategyProperty | cdktn.IResolvable | undefined;
        set internalValue(value: OrderedPlacementStrategyProperty | cdktn.IResolvable | undefined);
        private _field?;
        get field(): string;
        set field(value: string);
        resetField(): void;
        get fieldInput(): string | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
    }
    class OrderedPlacementStrategyPropertyList extends cdktn.ComplexList {
        internalValue?: OrderedPlacementStrategyProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): OrderedPlacementStrategyPropertyOutputReference;
    }
    interface PlacementConstraintsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#expression AwsEcsService#expression}
        */
        readonly expression?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#type AwsEcsService#type}
        */
        readonly type: string;
    }
    class PlacementConstraintsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): PlacementConstraintsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: PlacementConstraintsProperty | cdktn.IResolvable | undefined);
        private _expression?;
        get expression(): string;
        set expression(value: string);
        resetExpression(): void;
        get expressionInput(): string | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
    }
    class PlacementConstraintsPropertyList extends cdktn.ComplexList {
        internalValue?: PlacementConstraintsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): PlacementConstraintsPropertyOutputReference;
    }
    interface AccessLogConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#format AwsEcsService#format}
        */
        readonly format: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#include_query_parameters AwsEcsService#include_query_parameters}
        */
        readonly includeQueryParameters?: string;
    }
    class AccessLogConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AccessLogConfigurationProperty | undefined;
        set internalValue(value: AccessLogConfigurationProperty | undefined);
        private _format?;
        get format(): string;
        set format(value: string);
        get formatInput(): string | undefined;
        private _includeQueryParameters?;
        get includeQueryParameters(): string;
        set includeQueryParameters(value: string);
        resetIncludeQueryParameters(): void;
        get includeQueryParametersInput(): string | undefined;
    }
    interface SecretOptionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#name AwsEcsService#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#value_from AwsEcsService#value_from}
        */
        readonly valueFrom: string;
    }
    class SecretOptionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SecretOptionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SecretOptionProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _valueFrom?;
        get valueFrom(): string;
        set valueFrom(value: string);
        get valueFromInput(): string | undefined;
    }
    class SecretOptionPropertyList extends cdktn.ComplexList {
        internalValue?: SecretOptionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SecretOptionPropertyOutputReference;
    }
    interface LogConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#log_driver AwsEcsService#log_driver}
        */
        readonly logDriver: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#options AwsEcsService#options}
        */
        readonly options?: {
            [key: string]: string;
        };
        /**
        * secret_option block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#secret_option AwsEcsService#secret_option}
        */
        readonly secretOption?: SecretOptionProperty[] | cdktn.IResolvable;
    }
    class LogConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): LogConfigurationProperty | undefined;
        set internalValue(value: LogConfigurationProperty | undefined);
        private _logDriver?;
        get logDriver(): string;
        set logDriver(value: string);
        get logDriverInput(): string | undefined;
        private _options?;
        get options(): {
            [key: string]: string;
        };
        set options(value: {
            [key: string]: string;
        });
        resetOptions(): void;
        get optionsInput(): {
            [key: string]: string;
        } | undefined;
        private _secretOption;
        get secretOption(): SecretOptionPropertyList;
        putSecretOption(value: SecretOptionProperty[] | cdktn.IResolvable): void;
        resetSecretOption(): void;
        get secretOptionInput(): cdktn.IResolvable | SecretOptionProperty[] | undefined;
    }
    interface ValueProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#exact AwsEcsService#exact}
        */
        readonly exact: string;
    }
    class ValuePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ValueProperty | undefined;
        set internalValue(value: ValueProperty | undefined);
        private _exact?;
        get exact(): string;
        set exact(value: string);
        get exactInput(): string | undefined;
    }
    interface HeaderProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#name AwsEcsService#name}
        */
        readonly name: string;
        /**
        * value block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#value AwsEcsService#value}
        */
        readonly value: ValueProperty;
    }
    class HeaderPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): HeaderProperty | undefined;
        set internalValue(value: HeaderProperty | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _value;
        get value(): ValuePropertyOutputReference;
        putValue(value: ValueProperty): void;
        get valueInput(): ValueProperty | undefined;
    }
    interface TestTrafficRulesProperty {
        /**
        * header block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#header AwsEcsService#header}
        */
        readonly header?: HeaderProperty;
    }
    class TestTrafficRulesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TestTrafficRulesProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TestTrafficRulesProperty | cdktn.IResolvable | undefined);
        private _header;
        get header(): HeaderPropertyOutputReference;
        putHeader(value: HeaderProperty): void;
        resetHeader(): void;
        get headerInput(): HeaderProperty | undefined;
    }
    class TestTrafficRulesPropertyList extends cdktn.ComplexList {
        internalValue?: TestTrafficRulesProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TestTrafficRulesPropertyOutputReference;
    }
    interface ClientAliasProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#dns_name AwsEcsService#dns_name}
        */
        readonly dnsName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#port AwsEcsService#port}
        */
        readonly port: number;
        /**
        * test_traffic_rules block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#test_traffic_rules AwsEcsService#test_traffic_rules}
        */
        readonly testTrafficRules?: TestTrafficRulesProperty[] | cdktn.IResolvable;
    }
    class ClientAliasPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ClientAliasProperty | undefined;
        set internalValue(value: ClientAliasProperty | undefined);
        private _dnsName?;
        get dnsName(): string;
        set dnsName(value: string);
        resetDnsName(): void;
        get dnsNameInput(): string | undefined;
        private _port?;
        get port(): number;
        set port(value: number);
        get portInput(): number | undefined;
        private _testTrafficRules;
        get testTrafficRules(): TestTrafficRulesPropertyList;
        putTestTrafficRules(value: TestTrafficRulesProperty[] | cdktn.IResolvable): void;
        resetTestTrafficRules(): void;
        get testTrafficRulesInput(): cdktn.IResolvable | TestTrafficRulesProperty[] | undefined;
    }
    interface TimeoutProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#idle_timeout_seconds AwsEcsService#idle_timeout_seconds}
        */
        readonly idleTimeoutSeconds?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#per_request_timeout_seconds AwsEcsService#per_request_timeout_seconds}
        */
        readonly perRequestTimeoutSeconds?: number;
    }
    class TimeoutPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutProperty | undefined;
        set internalValue(value: TimeoutProperty | undefined);
        private _idleTimeoutSeconds?;
        get idleTimeoutSeconds(): number;
        set idleTimeoutSeconds(value: number);
        resetIdleTimeoutSeconds(): void;
        get idleTimeoutSecondsInput(): number | undefined;
        private _perRequestTimeoutSeconds?;
        get perRequestTimeoutSeconds(): number;
        set perRequestTimeoutSeconds(value: number);
        resetPerRequestTimeoutSeconds(): void;
        get perRequestTimeoutSecondsInput(): number | undefined;
    }
    interface IssuerCertAuthorityProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#aws_pca_authority_arn AwsEcsService#aws_pca_authority_arn}
        */
        readonly awsPcaAuthorityArn: string;
    }
    class IssuerCertAuthorityPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): IssuerCertAuthorityProperty | undefined;
        set internalValue(value: IssuerCertAuthorityProperty | undefined);
        private _awsPcaAuthorityArn?;
        get awsPcaAuthorityArn(): string;
        set awsPcaAuthorityArn(value: string);
        get awsPcaAuthorityArnInput(): string | undefined;
    }
    interface TlsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#kms_key AwsEcsService#kms_key}
        */
        readonly kmsKey?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#role_arn AwsEcsService#role_arn}
        */
        readonly roleArn?: string;
        /**
        * issuer_cert_authority block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#issuer_cert_authority AwsEcsService#issuer_cert_authority}
        */
        readonly issuerCertAuthority: IssuerCertAuthorityProperty;
    }
    class TlsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TlsProperty | undefined;
        set internalValue(value: TlsProperty | undefined);
        private _kmsKey?;
        get kmsKey(): string;
        set kmsKey(value: string);
        resetKmsKey(): void;
        get kmsKeyInput(): string | undefined;
        private _roleArn?;
        get roleArn(): string;
        set roleArn(value: string);
        resetRoleArn(): void;
        get roleArnInput(): string | undefined;
        private _issuerCertAuthority;
        get issuerCertAuthority(): IssuerCertAuthorityPropertyOutputReference;
        putIssuerCertAuthority(value: IssuerCertAuthorityProperty): void;
        get issuerCertAuthorityInput(): IssuerCertAuthorityProperty | undefined;
    }
    interface ServiceProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#discovery_name AwsEcsService#discovery_name}
        */
        readonly discoveryName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#ingress_port_override AwsEcsService#ingress_port_override}
        */
        readonly ingressPortOverride?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#port_name AwsEcsService#port_name}
        */
        readonly portName: string;
        /**
        * client_alias block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#client_alias AwsEcsService#client_alias}
        */
        readonly clientAlias?: ClientAliasProperty;
        /**
        * timeout block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#timeout AwsEcsService#timeout}
        */
        readonly timeout?: TimeoutProperty;
        /**
        * tls block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#tls AwsEcsService#tls}
        */
        readonly tls?: TlsProperty;
    }
    class ServicePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ServiceProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ServiceProperty | cdktn.IResolvable | undefined);
        private _discoveryName?;
        get discoveryName(): string;
        set discoveryName(value: string);
        resetDiscoveryName(): void;
        get discoveryNameInput(): string | undefined;
        private _ingressPortOverride?;
        get ingressPortOverride(): number;
        set ingressPortOverride(value: number);
        resetIngressPortOverride(): void;
        get ingressPortOverrideInput(): number | undefined;
        private _portName?;
        get portName(): string;
        set portName(value: string);
        get portNameInput(): string | undefined;
        private _clientAlias;
        get clientAlias(): ClientAliasPropertyOutputReference;
        putClientAlias(value: ClientAliasProperty): void;
        resetClientAlias(): void;
        get clientAliasInput(): ClientAliasProperty | undefined;
        private _timeout;
        get timeout(): TimeoutPropertyOutputReference;
        putTimeout(value: TimeoutProperty): void;
        resetTimeout(): void;
        get timeoutInput(): TimeoutProperty | undefined;
        private _tls;
        get tls(): TlsPropertyOutputReference;
        putTls(value: TlsProperty): void;
        resetTls(): void;
        get tlsInput(): TlsProperty | undefined;
    }
    class ServicePropertyList extends cdktn.ComplexList {
        internalValue?: ServiceProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ServicePropertyOutputReference;
    }
    interface ServiceConnectConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#enabled AwsEcsService#enabled}
        */
        readonly enabled: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#namespace AwsEcsService#namespace}
        */
        readonly namespace?: string;
        /**
        * access_log_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#access_log_configuration AwsEcsService#access_log_configuration}
        */
        readonly accessLogConfiguration?: AccessLogConfigurationProperty;
        /**
        * log_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#log_configuration AwsEcsService#log_configuration}
        */
        readonly logConfiguration?: LogConfigurationProperty;
        /**
        * service block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#service AwsEcsService#service}
        */
        readonly service?: ServiceProperty[] | cdktn.IResolvable;
    }
    class ServiceConnectConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ServiceConnectConfigurationProperty | undefined;
        set internalValue(value: ServiceConnectConfigurationProperty | undefined);
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
        private _namespace?;
        get namespace(): string;
        set namespace(value: string);
        resetNamespace(): void;
        get namespaceInput(): string | undefined;
        private _accessLogConfiguration;
        get accessLogConfiguration(): AccessLogConfigurationPropertyOutputReference;
        putAccessLogConfiguration(value: AccessLogConfigurationProperty): void;
        resetAccessLogConfiguration(): void;
        get accessLogConfigurationInput(): AccessLogConfigurationProperty | undefined;
        private _logConfiguration;
        get logConfiguration(): LogConfigurationPropertyOutputReference;
        putLogConfiguration(value: LogConfigurationProperty): void;
        resetLogConfiguration(): void;
        get logConfigurationInput(): LogConfigurationProperty | undefined;
        private _service;
        get service(): ServicePropertyList;
        putService(value: ServiceProperty[] | cdktn.IResolvable): void;
        resetService(): void;
        get serviceInput(): cdktn.IResolvable | ServiceProperty[] | undefined;
    }
    interface ServiceRegistriesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#container_name AwsEcsService#container_name}
        */
        readonly containerName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#container_port AwsEcsService#container_port}
        */
        readonly containerPort?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#port AwsEcsService#port}
        */
        readonly port?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#registry_arn AwsEcsService#registry_arn}
        */
        readonly registryArn: string;
    }
    class ServiceRegistriesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ServiceRegistriesProperty | undefined;
        set internalValue(value: ServiceRegistriesProperty | undefined);
        private _containerName?;
        get containerName(): string;
        set containerName(value: string);
        resetContainerName(): void;
        get containerNameInput(): string | undefined;
        private _containerPort?;
        get containerPort(): number;
        set containerPort(value: number);
        resetContainerPort(): void;
        get containerPortInput(): number | undefined;
        private _port?;
        get port(): number;
        set port(value: number);
        resetPort(): void;
        get portInput(): number | undefined;
        private _registryArn?;
        get registryArn(): string;
        set registryArn(value: string);
        get registryArnInput(): string | undefined;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#create AwsEcsService#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#delete AwsEcsService#delete}
        */
        readonly delete?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#update AwsEcsService#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
    interface TagSpecificationsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#propagate_tags AwsEcsService#propagate_tags}
        */
        readonly propagateTags?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#resource_type AwsEcsService#resource_type}
        */
        readonly resourceType: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#tags AwsEcsService#tags}
        */
        readonly tags?: {
            [key: string]: string;
        };
    }
    class TagSpecificationsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TagSpecificationsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TagSpecificationsProperty | cdktn.IResolvable | undefined);
        private _propagateTags?;
        get propagateTags(): string;
        set propagateTags(value: string);
        resetPropagateTags(): void;
        get propagateTagsInput(): string | undefined;
        private _resourceType?;
        get resourceType(): string;
        set resourceType(value: string);
        get resourceTypeInput(): string | undefined;
        private _tags?;
        get tags(): {
            [key: string]: string;
        };
        set tags(value: {
            [key: string]: string;
        });
        resetTags(): void;
        get tagsInput(): {
            [key: string]: string;
        } | undefined;
    }
    class TagSpecificationsPropertyList extends cdktn.ComplexList {
        internalValue?: TagSpecificationsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TagSpecificationsPropertyOutputReference;
    }
    interface ManagedEbsVolumeProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#encrypted AwsEcsService#encrypted}
        */
        readonly encrypted?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#file_system_type AwsEcsService#file_system_type}
        */
        readonly fileSystemType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#iops AwsEcsService#iops}
        */
        readonly iops?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#kms_key_id AwsEcsService#kms_key_id}
        */
        readonly kmsKeyId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#role_arn AwsEcsService#role_arn}
        */
        readonly roleArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#size_in_gb AwsEcsService#size_in_gb}
        */
        readonly sizeInGb?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#snapshot_id AwsEcsService#snapshot_id}
        */
        readonly snapshotId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#throughput AwsEcsService#throughput}
        */
        readonly throughput?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#volume_initialization_rate AwsEcsService#volume_initialization_rate}
        */
        readonly volumeInitializationRate?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#volume_type AwsEcsService#volume_type}
        */
        readonly volumeType?: string;
        /**
        * tag_specifications block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#tag_specifications AwsEcsService#tag_specifications}
        */
        readonly tagSpecifications?: TagSpecificationsProperty[] | cdktn.IResolvable;
    }
    class ManagedEbsVolumePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ManagedEbsVolumeProperty | undefined;
        set internalValue(value: ManagedEbsVolumeProperty | undefined);
        private _encrypted?;
        get encrypted(): boolean | cdktn.IResolvable;
        set encrypted(value: boolean | cdktn.IResolvable);
        resetEncrypted(): void;
        get encryptedInput(): boolean | cdktn.IResolvable | undefined;
        private _fileSystemType?;
        get fileSystemType(): string;
        set fileSystemType(value: string);
        resetFileSystemType(): void;
        get fileSystemTypeInput(): string | undefined;
        private _iops?;
        get iops(): number;
        set iops(value: number);
        resetIops(): void;
        get iopsInput(): number | undefined;
        private _kmsKeyId?;
        get kmsKeyId(): string;
        set kmsKeyId(value: string);
        resetKmsKeyId(): void;
        get kmsKeyIdInput(): string | undefined;
        private _roleArn?;
        get roleArn(): string;
        set roleArn(value: string);
        get roleArnInput(): string | undefined;
        private _sizeInGb?;
        get sizeInGb(): number;
        set sizeInGb(value: number);
        resetSizeInGb(): void;
        get sizeInGbInput(): number | undefined;
        private _snapshotId?;
        get snapshotId(): string;
        set snapshotId(value: string);
        resetSnapshotId(): void;
        get snapshotIdInput(): string | undefined;
        private _throughput?;
        get throughput(): number;
        set throughput(value: number);
        resetThroughput(): void;
        get throughputInput(): number | undefined;
        private _volumeInitializationRate?;
        get volumeInitializationRate(): number;
        set volumeInitializationRate(value: number);
        resetVolumeInitializationRate(): void;
        get volumeInitializationRateInput(): number | undefined;
        private _volumeType?;
        get volumeType(): string;
        set volumeType(value: string);
        resetVolumeType(): void;
        get volumeTypeInput(): string | undefined;
        private _tagSpecifications;
        get tagSpecifications(): TagSpecificationsPropertyList;
        putTagSpecifications(value: TagSpecificationsProperty[] | cdktn.IResolvable): void;
        resetTagSpecifications(): void;
        get tagSpecificationsInput(): cdktn.IResolvable | TagSpecificationsProperty[] | undefined;
    }
    interface VolumeConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#name AwsEcsService#name}
        */
        readonly name: string;
        /**
        * managed_ebs_volume block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#managed_ebs_volume AwsEcsService#managed_ebs_volume}
        */
        readonly managedEbsVolume: ManagedEbsVolumeProperty;
    }
    class VolumeConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): VolumeConfigurationProperty | undefined;
        set internalValue(value: VolumeConfigurationProperty | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _managedEbsVolume;
        get managedEbsVolume(): ManagedEbsVolumePropertyOutputReference;
        putManagedEbsVolume(value: ManagedEbsVolumeProperty): void;
        get managedEbsVolumeInput(): ManagedEbsVolumeProperty | undefined;
    }
    interface VpcLatticeConfigurationsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#port_name AwsEcsService#port_name}
        */
        readonly portName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#role_arn AwsEcsService#role_arn}
        */
        readonly roleArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#target_group_arn AwsEcsService#target_group_arn}
        */
        readonly targetGroupArn: string;
    }
    class VpcLatticeConfigurationsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): VpcLatticeConfigurationsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: VpcLatticeConfigurationsProperty | cdktn.IResolvable | undefined);
        private _portName?;
        get portName(): string;
        set portName(value: string);
        get portNameInput(): string | undefined;
        private _roleArn?;
        get roleArn(): string;
        set roleArn(value: string);
        get roleArnInput(): string | undefined;
        private _targetGroupArn?;
        get targetGroupArn(): string;
        set targetGroupArn(value: string);
        get targetGroupArnInput(): string | undefined;
    }
    class VpcLatticeConfigurationsPropertyList extends cdktn.ComplexList {
        internalValue?: VpcLatticeConfigurationsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): VpcLatticeConfigurationsPropertyOutputReference;
    }
}
