import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsEcsCapacityProviderConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_capacity_provider#cluster AwsEcsCapacityProvider#cluster}
    */
    readonly cluster?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_capacity_provider#id AwsEcsCapacityProvider#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_capacity_provider#name AwsEcsCapacityProvider#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_capacity_provider#region AwsEcsCapacityProvider#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_capacity_provider#tags AwsEcsCapacityProvider#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_capacity_provider#tags_all AwsEcsCapacityProvider#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * auto_scaling_group_provider block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_capacity_provider#auto_scaling_group_provider AwsEcsCapacityProvider#auto_scaling_group_provider}
    */
    readonly autoScalingGroupProvider?: AwsEcsCapacityProvider.AutoScalingGroupProviderProperty;
    /**
    * managed_instances_provider block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_capacity_provider#managed_instances_provider AwsEcsCapacityProvider#managed_instances_provider}
    */
    readonly managedInstancesProvider?: AwsEcsCapacityProvider.ManagedInstancesProviderProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_capacity_provider aws_ecs_capacity_provider}
*/
export declare class AwsEcsCapacityProvider extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_ecs_capacity_provider";
    /**
    * Generates CDKTN code for importing a AwsEcsCapacityProvider resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsEcsCapacityProvider to import
    * @param importFromId The id of the existing AwsEcsCapacityProvider that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_capacity_provider#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsEcsCapacityProvider to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_capacity_provider aws_ecs_capacity_provider} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsEcsCapacityProviderConfig
    */
    constructor(scope: Construct, id: string, config: AwsEcsCapacityProviderConfig);
    get arn(): string;
    private _cluster?;
    get cluster(): string;
    set cluster(value: string);
    resetCluster(): void;
    get clusterInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _autoScalingGroupProvider;
    get autoScalingGroupProvider(): AwsEcsCapacityProvider.AutoScalingGroupProviderPropertyOutputReference;
    putAutoScalingGroupProvider(value: AwsEcsCapacityProvider.AutoScalingGroupProviderProperty): void;
    resetAutoScalingGroupProvider(): void;
    get autoScalingGroupProviderInput(): AwsEcsCapacityProvider.AutoScalingGroupProviderProperty | undefined;
    private _managedInstancesProvider;
    get managedInstancesProvider(): AwsEcsCapacityProvider.ManagedInstancesProviderPropertyOutputReference;
    putManagedInstancesProvider(value: AwsEcsCapacityProvider.ManagedInstancesProviderProperty): void;
    resetManagedInstancesProvider(): void;
    get managedInstancesProviderInput(): AwsEcsCapacityProvider.ManagedInstancesProviderProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsEcsCapacityProviderManagedScalingPropertyToTerraform(struct?: AwsEcsCapacityProvider.ManagedScalingPropertyOutputReference | AwsEcsCapacityProvider.ManagedScalingProperty): any;
export declare function awsEcsCapacityProviderManagedScalingPropertyToHclTerraform(struct?: AwsEcsCapacityProvider.ManagedScalingPropertyOutputReference | AwsEcsCapacityProvider.ManagedScalingProperty): any;
export declare function awsEcsCapacityProviderAutoScalingGroupProviderPropertyToTerraform(struct?: AwsEcsCapacityProvider.AutoScalingGroupProviderPropertyOutputReference | AwsEcsCapacityProvider.AutoScalingGroupProviderProperty): any;
export declare function awsEcsCapacityProviderAutoScalingGroupProviderPropertyToHclTerraform(struct?: AwsEcsCapacityProvider.AutoScalingGroupProviderPropertyOutputReference | AwsEcsCapacityProvider.AutoScalingGroupProviderProperty): any;
export declare function awsEcsCapacityProviderInfrastructureOptimizationPropertyToTerraform(struct?: AwsEcsCapacityProvider.InfrastructureOptimizationPropertyOutputReference | AwsEcsCapacityProvider.InfrastructureOptimizationProperty): any;
export declare function awsEcsCapacityProviderInfrastructureOptimizationPropertyToHclTerraform(struct?: AwsEcsCapacityProvider.InfrastructureOptimizationPropertyOutputReference | AwsEcsCapacityProvider.InfrastructureOptimizationProperty): any;
export declare function awsEcsCapacityProviderCapacityReservationsPropertyToTerraform(struct?: AwsEcsCapacityProvider.CapacityReservationsPropertyOutputReference | AwsEcsCapacityProvider.CapacityReservationsProperty): any;
export declare function awsEcsCapacityProviderCapacityReservationsPropertyToHclTerraform(struct?: AwsEcsCapacityProvider.CapacityReservationsPropertyOutputReference | AwsEcsCapacityProvider.CapacityReservationsProperty): any;
export declare function awsEcsCapacityProviderAcceleratorCountPropertyToTerraform(struct?: AwsEcsCapacityProvider.AcceleratorCountPropertyOutputReference | AwsEcsCapacityProvider.AcceleratorCountProperty): any;
export declare function awsEcsCapacityProviderAcceleratorCountPropertyToHclTerraform(struct?: AwsEcsCapacityProvider.AcceleratorCountPropertyOutputReference | AwsEcsCapacityProvider.AcceleratorCountProperty): any;
export declare function awsEcsCapacityProviderAcceleratorTotalMemoryMibPropertyToTerraform(struct?: AwsEcsCapacityProvider.AcceleratorTotalMemoryMibPropertyOutputReference | AwsEcsCapacityProvider.AcceleratorTotalMemoryMibProperty): any;
export declare function awsEcsCapacityProviderAcceleratorTotalMemoryMibPropertyToHclTerraform(struct?: AwsEcsCapacityProvider.AcceleratorTotalMemoryMibPropertyOutputReference | AwsEcsCapacityProvider.AcceleratorTotalMemoryMibProperty): any;
export declare function awsEcsCapacityProviderBaselineEbsBandwidthMbpsPropertyToTerraform(struct?: AwsEcsCapacityProvider.BaselineEbsBandwidthMbpsPropertyOutputReference | AwsEcsCapacityProvider.BaselineEbsBandwidthMbpsProperty): any;
export declare function awsEcsCapacityProviderBaselineEbsBandwidthMbpsPropertyToHclTerraform(struct?: AwsEcsCapacityProvider.BaselineEbsBandwidthMbpsPropertyOutputReference | AwsEcsCapacityProvider.BaselineEbsBandwidthMbpsProperty): any;
export declare function awsEcsCapacityProviderMemoryGibPerVcpuPropertyToTerraform(struct?: AwsEcsCapacityProvider.MemoryGibPerVcpuPropertyOutputReference | AwsEcsCapacityProvider.MemoryGibPerVcpuProperty): any;
export declare function awsEcsCapacityProviderMemoryGibPerVcpuPropertyToHclTerraform(struct?: AwsEcsCapacityProvider.MemoryGibPerVcpuPropertyOutputReference | AwsEcsCapacityProvider.MemoryGibPerVcpuProperty): any;
export declare function awsEcsCapacityProviderMemoryMibPropertyToTerraform(struct?: AwsEcsCapacityProvider.MemoryMibPropertyOutputReference | AwsEcsCapacityProvider.MemoryMibProperty): any;
export declare function awsEcsCapacityProviderMemoryMibPropertyToHclTerraform(struct?: AwsEcsCapacityProvider.MemoryMibPropertyOutputReference | AwsEcsCapacityProvider.MemoryMibProperty): any;
export declare function awsEcsCapacityProviderNetworkBandwidthGbpsPropertyToTerraform(struct?: AwsEcsCapacityProvider.NetworkBandwidthGbpsPropertyOutputReference | AwsEcsCapacityProvider.NetworkBandwidthGbpsProperty): any;
export declare function awsEcsCapacityProviderNetworkBandwidthGbpsPropertyToHclTerraform(struct?: AwsEcsCapacityProvider.NetworkBandwidthGbpsPropertyOutputReference | AwsEcsCapacityProvider.NetworkBandwidthGbpsProperty): any;
export declare function awsEcsCapacityProviderNetworkInterfaceCountPropertyToTerraform(struct?: AwsEcsCapacityProvider.NetworkInterfaceCountPropertyOutputReference | AwsEcsCapacityProvider.NetworkInterfaceCountProperty): any;
export declare function awsEcsCapacityProviderNetworkInterfaceCountPropertyToHclTerraform(struct?: AwsEcsCapacityProvider.NetworkInterfaceCountPropertyOutputReference | AwsEcsCapacityProvider.NetworkInterfaceCountProperty): any;
export declare function awsEcsCapacityProviderTotalLocalStorageGbPropertyToTerraform(struct?: AwsEcsCapacityProvider.TotalLocalStorageGbPropertyOutputReference | AwsEcsCapacityProvider.TotalLocalStorageGbProperty): any;
export declare function awsEcsCapacityProviderTotalLocalStorageGbPropertyToHclTerraform(struct?: AwsEcsCapacityProvider.TotalLocalStorageGbPropertyOutputReference | AwsEcsCapacityProvider.TotalLocalStorageGbProperty): any;
export declare function awsEcsCapacityProviderVcpuCountPropertyToTerraform(struct?: AwsEcsCapacityProvider.VcpuCountPropertyOutputReference | AwsEcsCapacityProvider.VcpuCountProperty): any;
export declare function awsEcsCapacityProviderVcpuCountPropertyToHclTerraform(struct?: AwsEcsCapacityProvider.VcpuCountPropertyOutputReference | AwsEcsCapacityProvider.VcpuCountProperty): any;
export declare function awsEcsCapacityProviderInstanceRequirementsPropertyToTerraform(struct?: AwsEcsCapacityProvider.InstanceRequirementsPropertyOutputReference | AwsEcsCapacityProvider.InstanceRequirementsProperty): any;
export declare function awsEcsCapacityProviderInstanceRequirementsPropertyToHclTerraform(struct?: AwsEcsCapacityProvider.InstanceRequirementsPropertyOutputReference | AwsEcsCapacityProvider.InstanceRequirementsProperty): any;
export declare function awsEcsCapacityProviderLocalStorageConfigurationPropertyToTerraform(struct?: AwsEcsCapacityProvider.LocalStorageConfigurationPropertyOutputReference | AwsEcsCapacityProvider.LocalStorageConfigurationProperty): any;
export declare function awsEcsCapacityProviderLocalStorageConfigurationPropertyToHclTerraform(struct?: AwsEcsCapacityProvider.LocalStorageConfigurationPropertyOutputReference | AwsEcsCapacityProvider.LocalStorageConfigurationProperty): any;
export declare function awsEcsCapacityProviderNetworkConfigurationPropertyToTerraform(struct?: AwsEcsCapacityProvider.NetworkConfigurationPropertyOutputReference | AwsEcsCapacityProvider.NetworkConfigurationProperty): any;
export declare function awsEcsCapacityProviderNetworkConfigurationPropertyToHclTerraform(struct?: AwsEcsCapacityProvider.NetworkConfigurationPropertyOutputReference | AwsEcsCapacityProvider.NetworkConfigurationProperty): any;
export declare function awsEcsCapacityProviderStorageConfigurationPropertyToTerraform(struct?: AwsEcsCapacityProvider.StorageConfigurationPropertyOutputReference | AwsEcsCapacityProvider.StorageConfigurationProperty): any;
export declare function awsEcsCapacityProviderStorageConfigurationPropertyToHclTerraform(struct?: AwsEcsCapacityProvider.StorageConfigurationPropertyOutputReference | AwsEcsCapacityProvider.StorageConfigurationProperty): any;
export declare function awsEcsCapacityProviderInstanceLaunchTemplatePropertyToTerraform(struct?: AwsEcsCapacityProvider.InstanceLaunchTemplatePropertyOutputReference | AwsEcsCapacityProvider.InstanceLaunchTemplateProperty): any;
export declare function awsEcsCapacityProviderInstanceLaunchTemplatePropertyToHclTerraform(struct?: AwsEcsCapacityProvider.InstanceLaunchTemplatePropertyOutputReference | AwsEcsCapacityProvider.InstanceLaunchTemplateProperty): any;
export declare function awsEcsCapacityProviderManagedInstancesProviderPropertyToTerraform(struct?: AwsEcsCapacityProvider.ManagedInstancesProviderPropertyOutputReference | AwsEcsCapacityProvider.ManagedInstancesProviderProperty): any;
export declare function awsEcsCapacityProviderManagedInstancesProviderPropertyToHclTerraform(struct?: AwsEcsCapacityProvider.ManagedInstancesProviderPropertyOutputReference | AwsEcsCapacityProvider.ManagedInstancesProviderProperty): any;
export declare namespace AwsEcsCapacityProvider {
    interface ManagedScalingProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_capacity_provider#instance_warmup_period AwsEcsCapacityProvider#instance_warmup_period}
        */
        readonly instanceWarmupPeriod?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_capacity_provider#maximum_scaling_step_size AwsEcsCapacityProvider#maximum_scaling_step_size}
        */
        readonly maximumScalingStepSize?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_capacity_provider#minimum_scaling_step_size AwsEcsCapacityProvider#minimum_scaling_step_size}
        */
        readonly minimumScalingStepSize?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_capacity_provider#status AwsEcsCapacityProvider#status}
        */
        readonly status?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_capacity_provider#target_capacity AwsEcsCapacityProvider#target_capacity}
        */
        readonly targetCapacity?: number;
    }
    class ManagedScalingPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ManagedScalingProperty | undefined;
        set internalValue(value: ManagedScalingProperty | undefined);
        private _instanceWarmupPeriod?;
        get instanceWarmupPeriod(): number;
        set instanceWarmupPeriod(value: number);
        resetInstanceWarmupPeriod(): void;
        get instanceWarmupPeriodInput(): number | undefined;
        private _maximumScalingStepSize?;
        get maximumScalingStepSize(): number;
        set maximumScalingStepSize(value: number);
        resetMaximumScalingStepSize(): void;
        get maximumScalingStepSizeInput(): number | undefined;
        private _minimumScalingStepSize?;
        get minimumScalingStepSize(): number;
        set minimumScalingStepSize(value: number);
        resetMinimumScalingStepSize(): void;
        get minimumScalingStepSizeInput(): number | undefined;
        private _status?;
        get status(): string;
        set status(value: string);
        resetStatus(): void;
        get statusInput(): string | undefined;
        private _targetCapacity?;
        get targetCapacity(): number;
        set targetCapacity(value: number);
        resetTargetCapacity(): void;
        get targetCapacityInput(): number | undefined;
    }
    interface AutoScalingGroupProviderProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_capacity_provider#auto_scaling_group_arn AwsEcsCapacityProvider#auto_scaling_group_arn}
        */
        readonly autoScalingGroupArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_capacity_provider#managed_draining AwsEcsCapacityProvider#managed_draining}
        */
        readonly managedDraining?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_capacity_provider#managed_termination_protection AwsEcsCapacityProvider#managed_termination_protection}
        */
        readonly managedTerminationProtection?: string;
        /**
        * managed_scaling block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_capacity_provider#managed_scaling AwsEcsCapacityProvider#managed_scaling}
        */
        readonly managedScaling?: ManagedScalingProperty;
    }
    class AutoScalingGroupProviderPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AutoScalingGroupProviderProperty | undefined;
        set internalValue(value: AutoScalingGroupProviderProperty | undefined);
        private _autoScalingGroupArn?;
        get autoScalingGroupArn(): string;
        set autoScalingGroupArn(value: string);
        get autoScalingGroupArnInput(): string | undefined;
        private _managedDraining?;
        get managedDraining(): string;
        set managedDraining(value: string);
        resetManagedDraining(): void;
        get managedDrainingInput(): string | undefined;
        private _managedTerminationProtection?;
        get managedTerminationProtection(): string;
        set managedTerminationProtection(value: string);
        resetManagedTerminationProtection(): void;
        get managedTerminationProtectionInput(): string | undefined;
        private _managedScaling;
        get managedScaling(): ManagedScalingPropertyOutputReference;
        putManagedScaling(value: ManagedScalingProperty): void;
        resetManagedScaling(): void;
        get managedScalingInput(): ManagedScalingProperty | undefined;
    }
    interface InfrastructureOptimizationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_capacity_provider#scale_in_after AwsEcsCapacityProvider#scale_in_after}
        */
        readonly scaleInAfter?: number;
    }
    class InfrastructureOptimizationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): InfrastructureOptimizationProperty | undefined;
        set internalValue(value: InfrastructureOptimizationProperty | undefined);
        private _scaleInAfter?;
        get scaleInAfter(): number;
        set scaleInAfter(value: number);
        resetScaleInAfter(): void;
        get scaleInAfterInput(): number | undefined;
    }
    interface CapacityReservationsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_capacity_provider#reservation_group_arn AwsEcsCapacityProvider#reservation_group_arn}
        */
        readonly reservationGroupArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_capacity_provider#reservation_preference AwsEcsCapacityProvider#reservation_preference}
        */
        readonly reservationPreference?: string;
    }
    class CapacityReservationsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CapacityReservationsProperty | undefined;
        set internalValue(value: CapacityReservationsProperty | undefined);
        private _reservationGroupArn?;
        get reservationGroupArn(): string;
        set reservationGroupArn(value: string);
        resetReservationGroupArn(): void;
        get reservationGroupArnInput(): string | undefined;
        private _reservationPreference?;
        get reservationPreference(): string;
        set reservationPreference(value: string);
        resetReservationPreference(): void;
        get reservationPreferenceInput(): string | undefined;
    }
    interface AcceleratorCountProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_capacity_provider#max AwsEcsCapacityProvider#max}
        */
        readonly max?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_capacity_provider#min AwsEcsCapacityProvider#min}
        */
        readonly min?: number;
    }
    class AcceleratorCountPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AcceleratorCountProperty | undefined;
        set internalValue(value: AcceleratorCountProperty | undefined);
        private _max?;
        get max(): number;
        set max(value: number);
        resetMax(): void;
        get maxInput(): number | undefined;
        private _min?;
        get min(): number;
        set min(value: number);
        resetMin(): void;
        get minInput(): number | undefined;
    }
    interface AcceleratorTotalMemoryMibProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_capacity_provider#max AwsEcsCapacityProvider#max}
        */
        readonly max?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_capacity_provider#min AwsEcsCapacityProvider#min}
        */
        readonly min?: number;
    }
    class AcceleratorTotalMemoryMibPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AcceleratorTotalMemoryMibProperty | undefined;
        set internalValue(value: AcceleratorTotalMemoryMibProperty | undefined);
        private _max?;
        get max(): number;
        set max(value: number);
        resetMax(): void;
        get maxInput(): number | undefined;
        private _min?;
        get min(): number;
        set min(value: number);
        resetMin(): void;
        get minInput(): number | undefined;
    }
    interface BaselineEbsBandwidthMbpsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_capacity_provider#max AwsEcsCapacityProvider#max}
        */
        readonly max?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_capacity_provider#min AwsEcsCapacityProvider#min}
        */
        readonly min?: number;
    }
    class BaselineEbsBandwidthMbpsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): BaselineEbsBandwidthMbpsProperty | undefined;
        set internalValue(value: BaselineEbsBandwidthMbpsProperty | undefined);
        private _max?;
        get max(): number;
        set max(value: number);
        resetMax(): void;
        get maxInput(): number | undefined;
        private _min?;
        get min(): number;
        set min(value: number);
        resetMin(): void;
        get minInput(): number | undefined;
    }
    interface MemoryGibPerVcpuProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_capacity_provider#max AwsEcsCapacityProvider#max}
        */
        readonly max?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_capacity_provider#min AwsEcsCapacityProvider#min}
        */
        readonly min?: number;
    }
    class MemoryGibPerVcpuPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): MemoryGibPerVcpuProperty | undefined;
        set internalValue(value: MemoryGibPerVcpuProperty | undefined);
        private _max?;
        get max(): number;
        set max(value: number);
        resetMax(): void;
        get maxInput(): number | undefined;
        private _min?;
        get min(): number;
        set min(value: number);
        resetMin(): void;
        get minInput(): number | undefined;
    }
    interface MemoryMibProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_capacity_provider#max AwsEcsCapacityProvider#max}
        */
        readonly max?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_capacity_provider#min AwsEcsCapacityProvider#min}
        */
        readonly min: number;
    }
    class MemoryMibPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): MemoryMibProperty | undefined;
        set internalValue(value: MemoryMibProperty | undefined);
        private _max?;
        get max(): number;
        set max(value: number);
        resetMax(): void;
        get maxInput(): number | undefined;
        private _min?;
        get min(): number;
        set min(value: number);
        get minInput(): number | undefined;
    }
    interface NetworkBandwidthGbpsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_capacity_provider#max AwsEcsCapacityProvider#max}
        */
        readonly max?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_capacity_provider#min AwsEcsCapacityProvider#min}
        */
        readonly min?: number;
    }
    class NetworkBandwidthGbpsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): NetworkBandwidthGbpsProperty | undefined;
        set internalValue(value: NetworkBandwidthGbpsProperty | undefined);
        private _max?;
        get max(): number;
        set max(value: number);
        resetMax(): void;
        get maxInput(): number | undefined;
        private _min?;
        get min(): number;
        set min(value: number);
        resetMin(): void;
        get minInput(): number | undefined;
    }
    interface NetworkInterfaceCountProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_capacity_provider#max AwsEcsCapacityProvider#max}
        */
        readonly max?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_capacity_provider#min AwsEcsCapacityProvider#min}
        */
        readonly min?: number;
    }
    class NetworkInterfaceCountPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): NetworkInterfaceCountProperty | undefined;
        set internalValue(value: NetworkInterfaceCountProperty | undefined);
        private _max?;
        get max(): number;
        set max(value: number);
        resetMax(): void;
        get maxInput(): number | undefined;
        private _min?;
        get min(): number;
        set min(value: number);
        resetMin(): void;
        get minInput(): number | undefined;
    }
    interface TotalLocalStorageGbProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_capacity_provider#max AwsEcsCapacityProvider#max}
        */
        readonly max?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_capacity_provider#min AwsEcsCapacityProvider#min}
        */
        readonly min?: number;
    }
    class TotalLocalStorageGbPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TotalLocalStorageGbProperty | undefined;
        set internalValue(value: TotalLocalStorageGbProperty | undefined);
        private _max?;
        get max(): number;
        set max(value: number);
        resetMax(): void;
        get maxInput(): number | undefined;
        private _min?;
        get min(): number;
        set min(value: number);
        resetMin(): void;
        get minInput(): number | undefined;
    }
    interface VcpuCountProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_capacity_provider#max AwsEcsCapacityProvider#max}
        */
        readonly max?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_capacity_provider#min AwsEcsCapacityProvider#min}
        */
        readonly min: number;
    }
    class VcpuCountPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): VcpuCountProperty | undefined;
        set internalValue(value: VcpuCountProperty | undefined);
        private _max?;
        get max(): number;
        set max(value: number);
        resetMax(): void;
        get maxInput(): number | undefined;
        private _min?;
        get min(): number;
        set min(value: number);
        get minInput(): number | undefined;
    }
    interface InstanceRequirementsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_capacity_provider#accelerator_manufacturers AwsEcsCapacityProvider#accelerator_manufacturers}
        */
        readonly acceleratorManufacturers?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_capacity_provider#accelerator_names AwsEcsCapacityProvider#accelerator_names}
        */
        readonly acceleratorNames?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_capacity_provider#accelerator_types AwsEcsCapacityProvider#accelerator_types}
        */
        readonly acceleratorTypes?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_capacity_provider#allowed_instance_types AwsEcsCapacityProvider#allowed_instance_types}
        */
        readonly allowedInstanceTypes?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_capacity_provider#bare_metal AwsEcsCapacityProvider#bare_metal}
        */
        readonly bareMetal?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_capacity_provider#burstable_performance AwsEcsCapacityProvider#burstable_performance}
        */
        readonly burstablePerformance?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_capacity_provider#cpu_manufacturers AwsEcsCapacityProvider#cpu_manufacturers}
        */
        readonly cpuManufacturers?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_capacity_provider#excluded_instance_types AwsEcsCapacityProvider#excluded_instance_types}
        */
        readonly excludedInstanceTypes?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_capacity_provider#instance_generations AwsEcsCapacityProvider#instance_generations}
        */
        readonly instanceGenerations?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_capacity_provider#local_storage AwsEcsCapacityProvider#local_storage}
        */
        readonly localStorage?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_capacity_provider#local_storage_types AwsEcsCapacityProvider#local_storage_types}
        */
        readonly localStorageTypes?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_capacity_provider#max_spot_price_as_percentage_of_optimal_on_demand_price AwsEcsCapacityProvider#max_spot_price_as_percentage_of_optimal_on_demand_price}
        */
        readonly maxSpotPriceAsPercentageOfOptimalOnDemandPrice?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_capacity_provider#on_demand_max_price_percentage_over_lowest_price AwsEcsCapacityProvider#on_demand_max_price_percentage_over_lowest_price}
        */
        readonly onDemandMaxPricePercentageOverLowestPrice?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_capacity_provider#require_hibernate_support AwsEcsCapacityProvider#require_hibernate_support}
        */
        readonly requireHibernateSupport?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_capacity_provider#spot_max_price_percentage_over_lowest_price AwsEcsCapacityProvider#spot_max_price_percentage_over_lowest_price}
        */
        readonly spotMaxPricePercentageOverLowestPrice?: number;
        /**
        * accelerator_count block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_capacity_provider#accelerator_count AwsEcsCapacityProvider#accelerator_count}
        */
        readonly acceleratorCount?: AcceleratorCountProperty;
        /**
        * accelerator_total_memory_mib block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_capacity_provider#accelerator_total_memory_mib AwsEcsCapacityProvider#accelerator_total_memory_mib}
        */
        readonly acceleratorTotalMemoryMib?: AcceleratorTotalMemoryMibProperty;
        /**
        * baseline_ebs_bandwidth_mbps block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_capacity_provider#baseline_ebs_bandwidth_mbps AwsEcsCapacityProvider#baseline_ebs_bandwidth_mbps}
        */
        readonly baselineEbsBandwidthMbps?: BaselineEbsBandwidthMbpsProperty;
        /**
        * memory_gib_per_vcpu block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_capacity_provider#memory_gib_per_vcpu AwsEcsCapacityProvider#memory_gib_per_vcpu}
        */
        readonly memoryGibPerVcpu?: MemoryGibPerVcpuProperty;
        /**
        * memory_mib block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_capacity_provider#memory_mib AwsEcsCapacityProvider#memory_mib}
        */
        readonly memoryMib: MemoryMibProperty;
        /**
        * network_bandwidth_gbps block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_capacity_provider#network_bandwidth_gbps AwsEcsCapacityProvider#network_bandwidth_gbps}
        */
        readonly networkBandwidthGbps?: NetworkBandwidthGbpsProperty;
        /**
        * network_interface_count block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_capacity_provider#network_interface_count AwsEcsCapacityProvider#network_interface_count}
        */
        readonly networkInterfaceCount?: NetworkInterfaceCountProperty;
        /**
        * total_local_storage_gb block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_capacity_provider#total_local_storage_gb AwsEcsCapacityProvider#total_local_storage_gb}
        */
        readonly totalLocalStorageGb?: TotalLocalStorageGbProperty;
        /**
        * vcpu_count block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_capacity_provider#vcpu_count AwsEcsCapacityProvider#vcpu_count}
        */
        readonly vcpuCount: VcpuCountProperty;
    }
    class InstanceRequirementsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): InstanceRequirementsProperty | undefined;
        set internalValue(value: InstanceRequirementsProperty | undefined);
        private _acceleratorManufacturers?;
        get acceleratorManufacturers(): string[];
        set acceleratorManufacturers(value: string[]);
        resetAcceleratorManufacturers(): void;
        get acceleratorManufacturersInput(): string[] | undefined;
        private _acceleratorNames?;
        get acceleratorNames(): string[];
        set acceleratorNames(value: string[]);
        resetAcceleratorNames(): void;
        get acceleratorNamesInput(): string[] | undefined;
        private _acceleratorTypes?;
        get acceleratorTypes(): string[];
        set acceleratorTypes(value: string[]);
        resetAcceleratorTypes(): void;
        get acceleratorTypesInput(): string[] | undefined;
        private _allowedInstanceTypes?;
        get allowedInstanceTypes(): string[];
        set allowedInstanceTypes(value: string[]);
        resetAllowedInstanceTypes(): void;
        get allowedInstanceTypesInput(): string[] | undefined;
        private _bareMetal?;
        get bareMetal(): string;
        set bareMetal(value: string);
        resetBareMetal(): void;
        get bareMetalInput(): string | undefined;
        private _burstablePerformance?;
        get burstablePerformance(): string;
        set burstablePerformance(value: string);
        resetBurstablePerformance(): void;
        get burstablePerformanceInput(): string | undefined;
        private _cpuManufacturers?;
        get cpuManufacturers(): string[];
        set cpuManufacturers(value: string[]);
        resetCpuManufacturers(): void;
        get cpuManufacturersInput(): string[] | undefined;
        private _excludedInstanceTypes?;
        get excludedInstanceTypes(): string[];
        set excludedInstanceTypes(value: string[]);
        resetExcludedInstanceTypes(): void;
        get excludedInstanceTypesInput(): string[] | undefined;
        private _instanceGenerations?;
        get instanceGenerations(): string[];
        set instanceGenerations(value: string[]);
        resetInstanceGenerations(): void;
        get instanceGenerationsInput(): string[] | undefined;
        private _localStorage?;
        get localStorage(): string;
        set localStorage(value: string);
        resetLocalStorage(): void;
        get localStorageInput(): string | undefined;
        private _localStorageTypes?;
        get localStorageTypes(): string[];
        set localStorageTypes(value: string[]);
        resetLocalStorageTypes(): void;
        get localStorageTypesInput(): string[] | undefined;
        private _maxSpotPriceAsPercentageOfOptimalOnDemandPrice?;
        get maxSpotPriceAsPercentageOfOptimalOnDemandPrice(): number;
        set maxSpotPriceAsPercentageOfOptimalOnDemandPrice(value: number);
        resetMaxSpotPriceAsPercentageOfOptimalOnDemandPrice(): void;
        get maxSpotPriceAsPercentageOfOptimalOnDemandPriceInput(): number | undefined;
        private _onDemandMaxPricePercentageOverLowestPrice?;
        get onDemandMaxPricePercentageOverLowestPrice(): number;
        set onDemandMaxPricePercentageOverLowestPrice(value: number);
        resetOnDemandMaxPricePercentageOverLowestPrice(): void;
        get onDemandMaxPricePercentageOverLowestPriceInput(): number | undefined;
        private _requireHibernateSupport?;
        get requireHibernateSupport(): boolean | cdktn.IResolvable;
        set requireHibernateSupport(value: boolean | cdktn.IResolvable);
        resetRequireHibernateSupport(): void;
        get requireHibernateSupportInput(): boolean | cdktn.IResolvable | undefined;
        private _spotMaxPricePercentageOverLowestPrice?;
        get spotMaxPricePercentageOverLowestPrice(): number;
        set spotMaxPricePercentageOverLowestPrice(value: number);
        resetSpotMaxPricePercentageOverLowestPrice(): void;
        get spotMaxPricePercentageOverLowestPriceInput(): number | undefined;
        private _acceleratorCount;
        get acceleratorCount(): AcceleratorCountPropertyOutputReference;
        putAcceleratorCount(value: AcceleratorCountProperty): void;
        resetAcceleratorCount(): void;
        get acceleratorCountInput(): AcceleratorCountProperty | undefined;
        private _acceleratorTotalMemoryMib;
        get acceleratorTotalMemoryMib(): AcceleratorTotalMemoryMibPropertyOutputReference;
        putAcceleratorTotalMemoryMib(value: AcceleratorTotalMemoryMibProperty): void;
        resetAcceleratorTotalMemoryMib(): void;
        get acceleratorTotalMemoryMibInput(): AcceleratorTotalMemoryMibProperty | undefined;
        private _baselineEbsBandwidthMbps;
        get baselineEbsBandwidthMbps(): BaselineEbsBandwidthMbpsPropertyOutputReference;
        putBaselineEbsBandwidthMbps(value: BaselineEbsBandwidthMbpsProperty): void;
        resetBaselineEbsBandwidthMbps(): void;
        get baselineEbsBandwidthMbpsInput(): BaselineEbsBandwidthMbpsProperty | undefined;
        private _memoryGibPerVcpu;
        get memoryGibPerVcpu(): MemoryGibPerVcpuPropertyOutputReference;
        putMemoryGibPerVcpu(value: MemoryGibPerVcpuProperty): void;
        resetMemoryGibPerVcpu(): void;
        get memoryGibPerVcpuInput(): MemoryGibPerVcpuProperty | undefined;
        private _memoryMib;
        get memoryMib(): MemoryMibPropertyOutputReference;
        putMemoryMib(value: MemoryMibProperty): void;
        get memoryMibInput(): MemoryMibProperty | undefined;
        private _networkBandwidthGbps;
        get networkBandwidthGbps(): NetworkBandwidthGbpsPropertyOutputReference;
        putNetworkBandwidthGbps(value: NetworkBandwidthGbpsProperty): void;
        resetNetworkBandwidthGbps(): void;
        get networkBandwidthGbpsInput(): NetworkBandwidthGbpsProperty | undefined;
        private _networkInterfaceCount;
        get networkInterfaceCount(): NetworkInterfaceCountPropertyOutputReference;
        putNetworkInterfaceCount(value: NetworkInterfaceCountProperty): void;
        resetNetworkInterfaceCount(): void;
        get networkInterfaceCountInput(): NetworkInterfaceCountProperty | undefined;
        private _totalLocalStorageGb;
        get totalLocalStorageGb(): TotalLocalStorageGbPropertyOutputReference;
        putTotalLocalStorageGb(value: TotalLocalStorageGbProperty): void;
        resetTotalLocalStorageGb(): void;
        get totalLocalStorageGbInput(): TotalLocalStorageGbProperty | undefined;
        private _vcpuCount;
        get vcpuCount(): VcpuCountPropertyOutputReference;
        putVcpuCount(value: VcpuCountProperty): void;
        get vcpuCountInput(): VcpuCountProperty | undefined;
    }
    interface LocalStorageConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_capacity_provider#use_local_storage AwsEcsCapacityProvider#use_local_storage}
        */
        readonly useLocalStorage?: boolean | cdktn.IResolvable;
    }
    class LocalStorageConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): LocalStorageConfigurationProperty | undefined;
        set internalValue(value: LocalStorageConfigurationProperty | undefined);
        private _useLocalStorage?;
        get useLocalStorage(): boolean | cdktn.IResolvable;
        set useLocalStorage(value: boolean | cdktn.IResolvable);
        resetUseLocalStorage(): void;
        get useLocalStorageInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface NetworkConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_capacity_provider#security_groups AwsEcsCapacityProvider#security_groups}
        */
        readonly securityGroups?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_capacity_provider#subnets AwsEcsCapacityProvider#subnets}
        */
        readonly subnets: string[];
    }
    class NetworkConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): NetworkConfigurationProperty | undefined;
        set internalValue(value: NetworkConfigurationProperty | undefined);
        private _securityGroups?;
        get securityGroups(): string[];
        set securityGroups(value: string[]);
        resetSecurityGroups(): void;
        get securityGroupsInput(): string[] | undefined;
        private _subnets?;
        get subnets(): string[];
        set subnets(value: string[]);
        get subnetsInput(): string[] | undefined;
    }
    interface StorageConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_capacity_provider#storage_size_gib AwsEcsCapacityProvider#storage_size_gib}
        */
        readonly storageSizeGib: number;
    }
    class StorageConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): StorageConfigurationProperty | undefined;
        set internalValue(value: StorageConfigurationProperty | undefined);
        private _storageSizeGib?;
        get storageSizeGib(): number;
        set storageSizeGib(value: number);
        get storageSizeGibInput(): number | undefined;
    }
    interface InstanceLaunchTemplateProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_capacity_provider#capacity_option_type AwsEcsCapacityProvider#capacity_option_type}
        */
        readonly capacityOptionType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_capacity_provider#ec2_instance_profile_arn AwsEcsCapacityProvider#ec2_instance_profile_arn}
        */
        readonly ec2InstanceProfileArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_capacity_provider#monitoring AwsEcsCapacityProvider#monitoring}
        */
        readonly monitoring?: string;
        /**
        * capacity_reservations block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_capacity_provider#capacity_reservations AwsEcsCapacityProvider#capacity_reservations}
        */
        readonly capacityReservations?: CapacityReservationsProperty;
        /**
        * instance_requirements block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_capacity_provider#instance_requirements AwsEcsCapacityProvider#instance_requirements}
        */
        readonly instanceRequirements?: InstanceRequirementsProperty;
        /**
        * local_storage_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_capacity_provider#local_storage_configuration AwsEcsCapacityProvider#local_storage_configuration}
        */
        readonly localStorageConfiguration?: LocalStorageConfigurationProperty;
        /**
        * network_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_capacity_provider#network_configuration AwsEcsCapacityProvider#network_configuration}
        */
        readonly networkConfiguration: NetworkConfigurationProperty;
        /**
        * storage_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_capacity_provider#storage_configuration AwsEcsCapacityProvider#storage_configuration}
        */
        readonly storageConfiguration?: StorageConfigurationProperty;
    }
    class InstanceLaunchTemplatePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): InstanceLaunchTemplateProperty | undefined;
        set internalValue(value: InstanceLaunchTemplateProperty | undefined);
        private _capacityOptionType?;
        get capacityOptionType(): string;
        set capacityOptionType(value: string);
        resetCapacityOptionType(): void;
        get capacityOptionTypeInput(): string | undefined;
        private _ec2InstanceProfileArn?;
        get ec2InstanceProfileArn(): string;
        set ec2InstanceProfileArn(value: string);
        get ec2InstanceProfileArnInput(): string | undefined;
        private _monitoring?;
        get monitoring(): string;
        set monitoring(value: string);
        resetMonitoring(): void;
        get monitoringInput(): string | undefined;
        private _capacityReservations;
        get capacityReservations(): CapacityReservationsPropertyOutputReference;
        putCapacityReservations(value: CapacityReservationsProperty): void;
        resetCapacityReservations(): void;
        get capacityReservationsInput(): CapacityReservationsProperty | undefined;
        private _instanceRequirements;
        get instanceRequirements(): InstanceRequirementsPropertyOutputReference;
        putInstanceRequirements(value: InstanceRequirementsProperty): void;
        resetInstanceRequirements(): void;
        get instanceRequirementsInput(): InstanceRequirementsProperty | undefined;
        private _localStorageConfiguration;
        get localStorageConfiguration(): LocalStorageConfigurationPropertyOutputReference;
        putLocalStorageConfiguration(value: LocalStorageConfigurationProperty): void;
        resetLocalStorageConfiguration(): void;
        get localStorageConfigurationInput(): LocalStorageConfigurationProperty | undefined;
        private _networkConfiguration;
        get networkConfiguration(): NetworkConfigurationPropertyOutputReference;
        putNetworkConfiguration(value: NetworkConfigurationProperty): void;
        get networkConfigurationInput(): NetworkConfigurationProperty | undefined;
        private _storageConfiguration;
        get storageConfiguration(): StorageConfigurationPropertyOutputReference;
        putStorageConfiguration(value: StorageConfigurationProperty): void;
        resetStorageConfiguration(): void;
        get storageConfigurationInput(): StorageConfigurationProperty | undefined;
    }
    interface ManagedInstancesProviderProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_capacity_provider#infrastructure_role_arn AwsEcsCapacityProvider#infrastructure_role_arn}
        */
        readonly infrastructureRoleArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_capacity_provider#propagate_tags AwsEcsCapacityProvider#propagate_tags}
        */
        readonly propagateTags?: string;
        /**
        * infrastructure_optimization block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_capacity_provider#infrastructure_optimization AwsEcsCapacityProvider#infrastructure_optimization}
        */
        readonly infrastructureOptimization?: InfrastructureOptimizationProperty;
        /**
        * instance_launch_template block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_capacity_provider#instance_launch_template AwsEcsCapacityProvider#instance_launch_template}
        */
        readonly instanceLaunchTemplate: InstanceLaunchTemplateProperty;
    }
    class ManagedInstancesProviderPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ManagedInstancesProviderProperty | undefined;
        set internalValue(value: ManagedInstancesProviderProperty | undefined);
        private _infrastructureRoleArn?;
        get infrastructureRoleArn(): string;
        set infrastructureRoleArn(value: string);
        get infrastructureRoleArnInput(): string | undefined;
        private _propagateTags?;
        get propagateTags(): string;
        set propagateTags(value: string);
        resetPropagateTags(): void;
        get propagateTagsInput(): string | undefined;
        private _infrastructureOptimization;
        get infrastructureOptimization(): InfrastructureOptimizationPropertyOutputReference;
        putInfrastructureOptimization(value: InfrastructureOptimizationProperty): void;
        resetInfrastructureOptimization(): void;
        get infrastructureOptimizationInput(): InfrastructureOptimizationProperty | undefined;
        private _instanceLaunchTemplate;
        get instanceLaunchTemplate(): InstanceLaunchTemplatePropertyOutputReference;
        putInstanceLaunchTemplate(value: InstanceLaunchTemplateProperty): void;
        get instanceLaunchTemplateInput(): InstanceLaunchTemplateProperty | undefined;
    }
}
