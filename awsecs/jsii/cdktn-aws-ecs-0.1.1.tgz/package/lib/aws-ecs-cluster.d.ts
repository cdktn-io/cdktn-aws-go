import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsEcsClusterConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_cluster#id AwsEcsCluster#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_cluster#name AwsEcsCluster#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_cluster#region AwsEcsCluster#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_cluster#tags AwsEcsCluster#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_cluster#tags_all AwsEcsCluster#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_cluster#configuration AwsEcsCluster#configuration}
    */
    readonly configuration?: AwsEcsCluster.ConfigurationProperty;
    /**
    * service_connect_defaults block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_cluster#service_connect_defaults AwsEcsCluster#service_connect_defaults}
    */
    readonly serviceConnectDefaults?: AwsEcsCluster.ServiceConnectDefaultsProperty;
    /**
    * setting block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_cluster#setting AwsEcsCluster#setting}
    */
    readonly setting?: AwsEcsCluster.SettingProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_cluster aws_ecs_cluster}
*/
export declare class AwsEcsCluster extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_ecs_cluster";
    /**
    * Generates CDKTN code for importing a AwsEcsCluster resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsEcsCluster to import
    * @param importFromId The id of the existing AwsEcsCluster that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_cluster#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsEcsCluster to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_cluster aws_ecs_cluster} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsEcsClusterConfig
    */
    constructor(scope: Construct, id: string, config: AwsEcsClusterConfig);
    get arn(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _configuration;
    get configuration(): AwsEcsCluster.ConfigurationPropertyOutputReference;
    putConfiguration(value: AwsEcsCluster.ConfigurationProperty): void;
    resetConfiguration(): void;
    get configurationInput(): AwsEcsCluster.ConfigurationProperty | undefined;
    private _serviceConnectDefaults;
    get serviceConnectDefaults(): AwsEcsCluster.ServiceConnectDefaultsPropertyOutputReference;
    putServiceConnectDefaults(value: AwsEcsCluster.ServiceConnectDefaultsProperty): void;
    resetServiceConnectDefaults(): void;
    get serviceConnectDefaultsInput(): AwsEcsCluster.ServiceConnectDefaultsProperty | undefined;
    private _setting;
    get setting(): AwsEcsCluster.SettingPropertyList;
    putSetting(value: AwsEcsCluster.SettingProperty[] | cdktn.IResolvable): void;
    resetSetting(): void;
    get settingInput(): cdktn.IResolvable | AwsEcsCluster.SettingProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsEcsClusterLogConfigurationPropertyToTerraform(struct?: AwsEcsCluster.LogConfigurationPropertyOutputReference | AwsEcsCluster.LogConfigurationProperty): any;
export declare function awsEcsClusterLogConfigurationPropertyToHclTerraform(struct?: AwsEcsCluster.LogConfigurationPropertyOutputReference | AwsEcsCluster.LogConfigurationProperty): any;
export declare function awsEcsClusterExecuteCommandConfigurationPropertyToTerraform(struct?: AwsEcsCluster.ExecuteCommandConfigurationPropertyOutputReference | AwsEcsCluster.ExecuteCommandConfigurationProperty): any;
export declare function awsEcsClusterExecuteCommandConfigurationPropertyToHclTerraform(struct?: AwsEcsCluster.ExecuteCommandConfigurationPropertyOutputReference | AwsEcsCluster.ExecuteCommandConfigurationProperty): any;
export declare function awsEcsClusterManagedStorageConfigurationPropertyToTerraform(struct?: AwsEcsCluster.ManagedStorageConfigurationPropertyOutputReference | AwsEcsCluster.ManagedStorageConfigurationProperty): any;
export declare function awsEcsClusterManagedStorageConfigurationPropertyToHclTerraform(struct?: AwsEcsCluster.ManagedStorageConfigurationPropertyOutputReference | AwsEcsCluster.ManagedStorageConfigurationProperty): any;
export declare function awsEcsClusterConfigurationPropertyToTerraform(struct?: AwsEcsCluster.ConfigurationPropertyOutputReference | AwsEcsCluster.ConfigurationProperty): any;
export declare function awsEcsClusterConfigurationPropertyToHclTerraform(struct?: AwsEcsCluster.ConfigurationPropertyOutputReference | AwsEcsCluster.ConfigurationProperty): any;
export declare function awsEcsClusterServiceConnectDefaultsPropertyToTerraform(struct?: AwsEcsCluster.ServiceConnectDefaultsPropertyOutputReference | AwsEcsCluster.ServiceConnectDefaultsProperty): any;
export declare function awsEcsClusterServiceConnectDefaultsPropertyToHclTerraform(struct?: AwsEcsCluster.ServiceConnectDefaultsPropertyOutputReference | AwsEcsCluster.ServiceConnectDefaultsProperty): any;
export declare function awsEcsClusterSettingPropertyToTerraform(struct?: AwsEcsCluster.SettingProperty | cdktn.IResolvable): any;
export declare function awsEcsClusterSettingPropertyToHclTerraform(struct?: AwsEcsCluster.SettingProperty | cdktn.IResolvable): any;
export declare namespace AwsEcsCluster {
    interface LogConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_cluster#cloud_watch_encryption_enabled AwsEcsCluster#cloud_watch_encryption_enabled}
        */
        readonly cloudWatchEncryptionEnabled?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_cluster#cloud_watch_log_group_name AwsEcsCluster#cloud_watch_log_group_name}
        */
        readonly cloudWatchLogGroupName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_cluster#s3_bucket_encryption_enabled AwsEcsCluster#s3_bucket_encryption_enabled}
        */
        readonly s3BucketEncryptionEnabled?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_cluster#s3_bucket_name AwsEcsCluster#s3_bucket_name}
        */
        readonly s3BucketName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_cluster#s3_key_prefix AwsEcsCluster#s3_key_prefix}
        */
        readonly s3KeyPrefix?: string;
    }
    class LogConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): LogConfigurationProperty | undefined;
        set internalValue(value: LogConfigurationProperty | undefined);
        private _cloudWatchEncryptionEnabled?;
        get cloudWatchEncryptionEnabled(): boolean | cdktn.IResolvable;
        set cloudWatchEncryptionEnabled(value: boolean | cdktn.IResolvable);
        resetCloudWatchEncryptionEnabled(): void;
        get cloudWatchEncryptionEnabledInput(): boolean | cdktn.IResolvable | undefined;
        private _cloudWatchLogGroupName?;
        get cloudWatchLogGroupName(): string;
        set cloudWatchLogGroupName(value: string);
        resetCloudWatchLogGroupName(): void;
        get cloudWatchLogGroupNameInput(): string | undefined;
        private _s3BucketEncryptionEnabled?;
        get s3BucketEncryptionEnabled(): boolean | cdktn.IResolvable;
        set s3BucketEncryptionEnabled(value: boolean | cdktn.IResolvable);
        resetS3BucketEncryptionEnabled(): void;
        get s3BucketEncryptionEnabledInput(): boolean | cdktn.IResolvable | undefined;
        private _s3BucketName?;
        get s3BucketName(): string;
        set s3BucketName(value: string);
        resetS3BucketName(): void;
        get s3BucketNameInput(): string | undefined;
        private _s3KeyPrefix?;
        get s3KeyPrefix(): string;
        set s3KeyPrefix(value: string);
        resetS3KeyPrefix(): void;
        get s3KeyPrefixInput(): string | undefined;
    }
    interface ExecuteCommandConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_cluster#kms_key_id AwsEcsCluster#kms_key_id}
        */
        readonly kmsKeyId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_cluster#logging AwsEcsCluster#logging}
        */
        readonly logging?: string;
        /**
        * log_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_cluster#log_configuration AwsEcsCluster#log_configuration}
        */
        readonly logConfiguration?: LogConfigurationProperty;
    }
    class ExecuteCommandConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ExecuteCommandConfigurationProperty | undefined;
        set internalValue(value: ExecuteCommandConfigurationProperty | undefined);
        private _kmsKeyId?;
        get kmsKeyId(): string;
        set kmsKeyId(value: string);
        resetKmsKeyId(): void;
        get kmsKeyIdInput(): string | undefined;
        private _logging?;
        get logging(): string;
        set logging(value: string);
        resetLogging(): void;
        get loggingInput(): string | undefined;
        private _logConfiguration;
        get logConfiguration(): LogConfigurationPropertyOutputReference;
        putLogConfiguration(value: LogConfigurationProperty): void;
        resetLogConfiguration(): void;
        get logConfigurationInput(): LogConfigurationProperty | undefined;
    }
    interface ManagedStorageConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_cluster#fargate_ephemeral_storage_kms_key_id AwsEcsCluster#fargate_ephemeral_storage_kms_key_id}
        */
        readonly fargateEphemeralStorageKmsKeyId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_cluster#kms_key_id AwsEcsCluster#kms_key_id}
        */
        readonly kmsKeyId?: string;
    }
    class ManagedStorageConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ManagedStorageConfigurationProperty | undefined;
        set internalValue(value: ManagedStorageConfigurationProperty | undefined);
        private _fargateEphemeralStorageKmsKeyId?;
        get fargateEphemeralStorageKmsKeyId(): string;
        set fargateEphemeralStorageKmsKeyId(value: string);
        resetFargateEphemeralStorageKmsKeyId(): void;
        get fargateEphemeralStorageKmsKeyIdInput(): string | undefined;
        private _kmsKeyId?;
        get kmsKeyId(): string;
        set kmsKeyId(value: string);
        resetKmsKeyId(): void;
        get kmsKeyIdInput(): string | undefined;
    }
    interface ConfigurationProperty {
        /**
        * execute_command_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_cluster#execute_command_configuration AwsEcsCluster#execute_command_configuration}
        */
        readonly executeCommandConfiguration?: ExecuteCommandConfigurationProperty;
        /**
        * managed_storage_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_cluster#managed_storage_configuration AwsEcsCluster#managed_storage_configuration}
        */
        readonly managedStorageConfiguration?: ManagedStorageConfigurationProperty;
    }
    class ConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ConfigurationProperty | undefined;
        set internalValue(value: ConfigurationProperty | undefined);
        private _executeCommandConfiguration;
        get executeCommandConfiguration(): ExecuteCommandConfigurationPropertyOutputReference;
        putExecuteCommandConfiguration(value: ExecuteCommandConfigurationProperty): void;
        resetExecuteCommandConfiguration(): void;
        get executeCommandConfigurationInput(): ExecuteCommandConfigurationProperty | undefined;
        private _managedStorageConfiguration;
        get managedStorageConfiguration(): ManagedStorageConfigurationPropertyOutputReference;
        putManagedStorageConfiguration(value: ManagedStorageConfigurationProperty): void;
        resetManagedStorageConfiguration(): void;
        get managedStorageConfigurationInput(): ManagedStorageConfigurationProperty | undefined;
    }
    interface ServiceConnectDefaultsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_cluster#namespace AwsEcsCluster#namespace}
        */
        readonly namespace: string;
    }
    class ServiceConnectDefaultsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ServiceConnectDefaultsProperty | undefined;
        set internalValue(value: ServiceConnectDefaultsProperty | undefined);
        private _namespace?;
        get namespace(): string;
        set namespace(value: string);
        get namespaceInput(): string | undefined;
    }
    interface SettingProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_cluster#name AwsEcsCluster#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_cluster#value AwsEcsCluster#value}
        */
        readonly value: string;
    }
    class SettingPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SettingProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SettingProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class SettingPropertyList extends cdktn.ComplexList {
        internalValue?: SettingProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SettingPropertyOutputReference;
    }
}
