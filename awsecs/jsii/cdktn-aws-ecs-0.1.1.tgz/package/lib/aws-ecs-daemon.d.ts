import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsEcsDaemonConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_daemon#capacity_provider_arns AwsEcsDaemon#capacity_provider_arns}
    */
    readonly capacityProviderArns: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_daemon#cluster_arn AwsEcsDaemon#cluster_arn}
    */
    readonly clusterArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_daemon#daemon_task_definition_arn AwsEcsDaemon#daemon_task_definition_arn}
    */
    readonly daemonTaskDefinitionArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_daemon#enable_ecs_managed_tags AwsEcsDaemon#enable_ecs_managed_tags}
    */
    readonly enableEcsManagedTags?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_daemon#enable_execute_command AwsEcsDaemon#enable_execute_command}
    */
    readonly enableExecuteCommand?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_daemon#name AwsEcsDaemon#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_daemon#propagate_tags AwsEcsDaemon#propagate_tags}
    */
    readonly propagateTags?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_daemon#region AwsEcsDaemon#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_daemon#tags AwsEcsDaemon#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * deployment_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_daemon#deployment_configuration AwsEcsDaemon#deployment_configuration}
    */
    readonly deploymentConfiguration?: AwsEcsDaemon.DeploymentConfigurationProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_daemon#timeouts AwsEcsDaemon#timeouts}
    */
    readonly timeouts?: AwsEcsDaemon.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_daemon aws_ecs_daemon}
*/
export declare class AwsEcsDaemon extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_ecs_daemon";
    /**
    * Generates CDKTN code for importing a AwsEcsDaemon resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsEcsDaemon to import
    * @param importFromId The id of the existing AwsEcsDaemon that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_daemon#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsEcsDaemon to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_daemon aws_ecs_daemon} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsEcsDaemonConfig
    */
    constructor(scope: Construct, id: string, config: AwsEcsDaemonConfig);
    get arn(): string;
    private _capacityProviderArns?;
    get capacityProviderArns(): string[];
    set capacityProviderArns(value: string[]);
    get capacityProviderArnsInput(): string[] | undefined;
    private _clusterArn?;
    get clusterArn(): string;
    set clusterArn(value: string);
    resetClusterArn(): void;
    get clusterArnInput(): string | undefined;
    private _daemonTaskDefinitionArn?;
    get daemonTaskDefinitionArn(): string;
    set daemonTaskDefinitionArn(value: string);
    get daemonTaskDefinitionArnInput(): string | undefined;
    get deploymentArn(): string;
    private _enableEcsManagedTags?;
    get enableEcsManagedTags(): boolean | cdktn.IResolvable;
    set enableEcsManagedTags(value: boolean | cdktn.IResolvable);
    resetEnableEcsManagedTags(): void;
    get enableEcsManagedTagsInput(): boolean | cdktn.IResolvable | undefined;
    private _enableExecuteCommand?;
    get enableExecuteCommand(): boolean | cdktn.IResolvable;
    set enableExecuteCommand(value: boolean | cdktn.IResolvable);
    resetEnableExecuteCommand(): void;
    get enableExecuteCommandInput(): boolean | cdktn.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _propagateTags?;
    get propagateTags(): string;
    set propagateTags(value: string);
    resetPropagateTags(): void;
    get propagateTagsInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get status(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    private _deploymentConfiguration;
    get deploymentConfiguration(): AwsEcsDaemon.DeploymentConfigurationPropertyList;
    putDeploymentConfiguration(value: AwsEcsDaemon.DeploymentConfigurationProperty[] | cdktn.IResolvable): void;
    resetDeploymentConfiguration(): void;
    get deploymentConfigurationInput(): cdktn.IResolvable | AwsEcsDaemon.DeploymentConfigurationProperty[] | undefined;
    private _timeouts;
    get timeouts(): AwsEcsDaemon.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsEcsDaemon.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsEcsDaemon.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsEcsDaemonAlarmsPropertyToTerraform(struct?: AwsEcsDaemon.AlarmsProperty | cdktn.IResolvable): any;
export declare function awsEcsDaemonAlarmsPropertyToHclTerraform(struct?: AwsEcsDaemon.AlarmsProperty | cdktn.IResolvable): any;
export declare function awsEcsDaemonDeploymentConfigurationPropertyToTerraform(struct?: AwsEcsDaemon.DeploymentConfigurationProperty | cdktn.IResolvable): any;
export declare function awsEcsDaemonDeploymentConfigurationPropertyToHclTerraform(struct?: AwsEcsDaemon.DeploymentConfigurationProperty | cdktn.IResolvable): any;
export declare function awsEcsDaemonTimeoutsPropertyToTerraform(struct?: AwsEcsDaemon.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsEcsDaemonTimeoutsPropertyToHclTerraform(struct?: AwsEcsDaemon.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsEcsDaemon {
    interface AlarmsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_daemon#alarm_names AwsEcsDaemon#alarm_names}
        */
        readonly alarmNames?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_daemon#enable AwsEcsDaemon#enable}
        */
        readonly enable?: boolean | cdktn.IResolvable;
    }
    class AlarmsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AlarmsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: AlarmsProperty | cdktn.IResolvable | undefined);
        private _alarmNames?;
        get alarmNames(): string[];
        set alarmNames(value: string[]);
        resetAlarmNames(): void;
        get alarmNamesInput(): string[] | undefined;
        private _enable?;
        get enable(): boolean | cdktn.IResolvable;
        set enable(value: boolean | cdktn.IResolvable);
        resetEnable(): void;
        get enableInput(): boolean | cdktn.IResolvable | undefined;
    }
    class AlarmsPropertyList extends cdktn.ComplexList {
        internalValue?: AlarmsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AlarmsPropertyOutputReference;
    }
    interface DeploymentConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_daemon#bake_time_in_minutes AwsEcsDaemon#bake_time_in_minutes}
        */
        readonly bakeTimeInMinutes?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_daemon#drain_percent AwsEcsDaemon#drain_percent}
        */
        readonly drainPercent?: number;
        /**
        * alarms block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_daemon#alarms AwsEcsDaemon#alarms}
        */
        readonly alarms?: AlarmsProperty[] | cdktn.IResolvable;
    }
    class DeploymentConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DeploymentConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DeploymentConfigurationProperty | cdktn.IResolvable | undefined);
        private _bakeTimeInMinutes?;
        get bakeTimeInMinutes(): number;
        set bakeTimeInMinutes(value: number);
        resetBakeTimeInMinutes(): void;
        get bakeTimeInMinutesInput(): number | undefined;
        private _drainPercent?;
        get drainPercent(): number;
        set drainPercent(value: number);
        resetDrainPercent(): void;
        get drainPercentInput(): number | undefined;
        private _alarms;
        get alarms(): AlarmsPropertyList;
        putAlarms(value: AlarmsProperty[] | cdktn.IResolvable): void;
        resetAlarms(): void;
        get alarmsInput(): cdktn.IResolvable | AlarmsProperty[] | undefined;
    }
    class DeploymentConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: DeploymentConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DeploymentConfigurationPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_daemon#create AwsEcsDaemon#create}
        */
        readonly create?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Setting a timeout for a Delete operation is only applicable if changes are saved into state before the destroy operation occurs.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_daemon#delete AwsEcsDaemon#delete}
        */
        readonly delete?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_daemon#update AwsEcsDaemon#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
