import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsEcsTaskDefinitionConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_task_definition#container_definitions AwsEcsTaskDefinition#container_definitions}
    */
    readonly containerDefinitions: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_task_definition#cpu AwsEcsTaskDefinition#cpu}
    */
    readonly cpu?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_task_definition#enable_fault_injection AwsEcsTaskDefinition#enable_fault_injection}
    */
    readonly enableFaultInjection?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_task_definition#execution_role_arn AwsEcsTaskDefinition#execution_role_arn}
    */
    readonly executionRoleArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_task_definition#family AwsEcsTaskDefinition#family}
    */
    readonly family: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_task_definition#id AwsEcsTaskDefinition#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_task_definition#ipc_mode AwsEcsTaskDefinition#ipc_mode}
    */
    readonly ipcMode?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_task_definition#memory AwsEcsTaskDefinition#memory}
    */
    readonly memory?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_task_definition#network_mode AwsEcsTaskDefinition#network_mode}
    */
    readonly networkMode?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_task_definition#pid_mode AwsEcsTaskDefinition#pid_mode}
    */
    readonly pidMode?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_task_definition#region AwsEcsTaskDefinition#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_task_definition#requires_compatibilities AwsEcsTaskDefinition#requires_compatibilities}
    */
    readonly requiresCompatibilities?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_task_definition#skip_destroy AwsEcsTaskDefinition#skip_destroy}
    */
    readonly skipDestroy?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_task_definition#tags AwsEcsTaskDefinition#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_task_definition#tags_all AwsEcsTaskDefinition#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_task_definition#task_role_arn AwsEcsTaskDefinition#task_role_arn}
    */
    readonly taskRoleArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_task_definition#track_latest AwsEcsTaskDefinition#track_latest}
    */
    readonly trackLatest?: boolean | cdktn.IResolvable;
    /**
    * ephemeral_storage block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_task_definition#ephemeral_storage AwsEcsTaskDefinition#ephemeral_storage}
    */
    readonly ephemeralStorage?: AwsEcsTaskDefinition.EphemeralStorageProperty;
    /**
    * placement_constraints block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_task_definition#placement_constraints AwsEcsTaskDefinition#placement_constraints}
    */
    readonly placementConstraints?: AwsEcsTaskDefinition.PlacementConstraintsProperty[] | cdktn.IResolvable;
    /**
    * proxy_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_task_definition#proxy_configuration AwsEcsTaskDefinition#proxy_configuration}
    */
    readonly proxyConfiguration?: AwsEcsTaskDefinition.ProxyConfigurationProperty;
    /**
    * runtime_platform block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_task_definition#runtime_platform AwsEcsTaskDefinition#runtime_platform}
    */
    readonly runtimePlatform?: AwsEcsTaskDefinition.RuntimePlatformProperty;
    /**
    * volume block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_task_definition#volume AwsEcsTaskDefinition#volume}
    */
    readonly volume?: AwsEcsTaskDefinition.VolumeProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_task_definition aws_ecs_task_definition}
*/
export declare class AwsEcsTaskDefinition extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_ecs_task_definition";
    /**
    * Generates CDKTN code for importing a AwsEcsTaskDefinition resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsEcsTaskDefinition to import
    * @param importFromId The id of the existing AwsEcsTaskDefinition that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_task_definition#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsEcsTaskDefinition to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_task_definition aws_ecs_task_definition} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsEcsTaskDefinitionConfig
    */
    constructor(scope: Construct, id: string, config: AwsEcsTaskDefinitionConfig);
    get arn(): string;
    get arnWithoutRevision(): string;
    private _containerDefinitions?;
    get containerDefinitions(): string;
    set containerDefinitions(value: string);
    get containerDefinitionsInput(): string | undefined;
    private _cpu?;
    get cpu(): string;
    set cpu(value: string);
    resetCpu(): void;
    get cpuInput(): string | undefined;
    private _enableFaultInjection?;
    get enableFaultInjection(): boolean | cdktn.IResolvable;
    set enableFaultInjection(value: boolean | cdktn.IResolvable);
    resetEnableFaultInjection(): void;
    get enableFaultInjectionInput(): boolean | cdktn.IResolvable | undefined;
    private _executionRoleArn?;
    get executionRoleArn(): string;
    set executionRoleArn(value: string);
    resetExecutionRoleArn(): void;
    get executionRoleArnInput(): string | undefined;
    private _family?;
    get family(): string;
    set family(value: string);
    get familyInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _ipcMode?;
    get ipcMode(): string;
    set ipcMode(value: string);
    resetIpcMode(): void;
    get ipcModeInput(): string | undefined;
    private _memory?;
    get memory(): string;
    set memory(value: string);
    resetMemory(): void;
    get memoryInput(): string | undefined;
    private _networkMode?;
    get networkMode(): string;
    set networkMode(value: string);
    resetNetworkMode(): void;
    get networkModeInput(): string | undefined;
    private _pidMode?;
    get pidMode(): string;
    set pidMode(value: string);
    resetPidMode(): void;
    get pidModeInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _requiresCompatibilities?;
    get requiresCompatibilities(): string[];
    set requiresCompatibilities(value: string[]);
    resetRequiresCompatibilities(): void;
    get requiresCompatibilitiesInput(): string[] | undefined;
    get revision(): number;
    private _skipDestroy?;
    get skipDestroy(): boolean | cdktn.IResolvable;
    set skipDestroy(value: boolean | cdktn.IResolvable);
    resetSkipDestroy(): void;
    get skipDestroyInput(): boolean | cdktn.IResolvable | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _taskRoleArn?;
    get taskRoleArn(): string;
    set taskRoleArn(value: string);
    resetTaskRoleArn(): void;
    get taskRoleArnInput(): string | undefined;
    private _trackLatest?;
    get trackLatest(): boolean | cdktn.IResolvable;
    set trackLatest(value: boolean | cdktn.IResolvable);
    resetTrackLatest(): void;
    get trackLatestInput(): boolean | cdktn.IResolvable | undefined;
    private _ephemeralStorage;
    get ephemeralStorage(): AwsEcsTaskDefinition.EphemeralStoragePropertyOutputReference;
    putEphemeralStorage(value: AwsEcsTaskDefinition.EphemeralStorageProperty): void;
    resetEphemeralStorage(): void;
    get ephemeralStorageInput(): AwsEcsTaskDefinition.EphemeralStorageProperty | undefined;
    private _placementConstraints;
    get placementConstraints(): AwsEcsTaskDefinition.PlacementConstraintsPropertyList;
    putPlacementConstraints(value: AwsEcsTaskDefinition.PlacementConstraintsProperty[] | cdktn.IResolvable): void;
    resetPlacementConstraints(): void;
    get placementConstraintsInput(): cdktn.IResolvable | AwsEcsTaskDefinition.PlacementConstraintsProperty[] | undefined;
    private _proxyConfiguration;
    get proxyConfiguration(): AwsEcsTaskDefinition.ProxyConfigurationPropertyOutputReference;
    putProxyConfiguration(value: AwsEcsTaskDefinition.ProxyConfigurationProperty): void;
    resetProxyConfiguration(): void;
    get proxyConfigurationInput(): AwsEcsTaskDefinition.ProxyConfigurationProperty | undefined;
    private _runtimePlatform;
    get runtimePlatform(): AwsEcsTaskDefinition.RuntimePlatformPropertyOutputReference;
    putRuntimePlatform(value: AwsEcsTaskDefinition.RuntimePlatformProperty): void;
    resetRuntimePlatform(): void;
    get runtimePlatformInput(): AwsEcsTaskDefinition.RuntimePlatformProperty | undefined;
    private _volume;
    get volume(): AwsEcsTaskDefinition.VolumePropertyList;
    putVolume(value: AwsEcsTaskDefinition.VolumeProperty[] | cdktn.IResolvable): void;
    resetVolume(): void;
    get volumeInput(): cdktn.IResolvable | AwsEcsTaskDefinition.VolumeProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsEcsTaskDefinitionEphemeralStoragePropertyToTerraform(struct?: AwsEcsTaskDefinition.EphemeralStoragePropertyOutputReference | AwsEcsTaskDefinition.EphemeralStorageProperty): any;
export declare function awsEcsTaskDefinitionEphemeralStoragePropertyToHclTerraform(struct?: AwsEcsTaskDefinition.EphemeralStoragePropertyOutputReference | AwsEcsTaskDefinition.EphemeralStorageProperty): any;
export declare function awsEcsTaskDefinitionPlacementConstraintsPropertyToTerraform(struct?: AwsEcsTaskDefinition.PlacementConstraintsProperty | cdktn.IResolvable): any;
export declare function awsEcsTaskDefinitionPlacementConstraintsPropertyToHclTerraform(struct?: AwsEcsTaskDefinition.PlacementConstraintsProperty | cdktn.IResolvable): any;
export declare function awsEcsTaskDefinitionProxyConfigurationPropertyToTerraform(struct?: AwsEcsTaskDefinition.ProxyConfigurationPropertyOutputReference | AwsEcsTaskDefinition.ProxyConfigurationProperty): any;
export declare function awsEcsTaskDefinitionProxyConfigurationPropertyToHclTerraform(struct?: AwsEcsTaskDefinition.ProxyConfigurationPropertyOutputReference | AwsEcsTaskDefinition.ProxyConfigurationProperty): any;
export declare function awsEcsTaskDefinitionRuntimePlatformPropertyToTerraform(struct?: AwsEcsTaskDefinition.RuntimePlatformPropertyOutputReference | AwsEcsTaskDefinition.RuntimePlatformProperty): any;
export declare function awsEcsTaskDefinitionRuntimePlatformPropertyToHclTerraform(struct?: AwsEcsTaskDefinition.RuntimePlatformPropertyOutputReference | AwsEcsTaskDefinition.RuntimePlatformProperty): any;
export declare function awsEcsTaskDefinitionDockerVolumeConfigurationPropertyToTerraform(struct?: AwsEcsTaskDefinition.DockerVolumeConfigurationPropertyOutputReference | AwsEcsTaskDefinition.DockerVolumeConfigurationProperty): any;
export declare function awsEcsTaskDefinitionDockerVolumeConfigurationPropertyToHclTerraform(struct?: AwsEcsTaskDefinition.DockerVolumeConfigurationPropertyOutputReference | AwsEcsTaskDefinition.DockerVolumeConfigurationProperty): any;
export declare function awsEcsTaskDefinitionVolumeEfsVolumeConfigurationAuthorizationConfigPropertyToTerraform(struct?: AwsEcsTaskDefinition.VolumeEfsVolumeConfigurationAuthorizationConfigPropertyOutputReference | AwsEcsTaskDefinition.VolumeEfsVolumeConfigurationAuthorizationConfigProperty): any;
export declare function awsEcsTaskDefinitionVolumeEfsVolumeConfigurationAuthorizationConfigPropertyToHclTerraform(struct?: AwsEcsTaskDefinition.VolumeEfsVolumeConfigurationAuthorizationConfigPropertyOutputReference | AwsEcsTaskDefinition.VolumeEfsVolumeConfigurationAuthorizationConfigProperty): any;
export declare function awsEcsTaskDefinitionEfsVolumeConfigurationPropertyToTerraform(struct?: AwsEcsTaskDefinition.EfsVolumeConfigurationPropertyOutputReference | AwsEcsTaskDefinition.EfsVolumeConfigurationProperty): any;
export declare function awsEcsTaskDefinitionEfsVolumeConfigurationPropertyToHclTerraform(struct?: AwsEcsTaskDefinition.EfsVolumeConfigurationPropertyOutputReference | AwsEcsTaskDefinition.EfsVolumeConfigurationProperty): any;
export declare function awsEcsTaskDefinitionVolumeFsxWindowsFileServerVolumeConfigurationAuthorizationConfigPropertyToTerraform(struct?: AwsEcsTaskDefinition.VolumeFsxWindowsFileServerVolumeConfigurationAuthorizationConfigPropertyOutputReference | AwsEcsTaskDefinition.VolumeFsxWindowsFileServerVolumeConfigurationAuthorizationConfigProperty): any;
export declare function awsEcsTaskDefinitionVolumeFsxWindowsFileServerVolumeConfigurationAuthorizationConfigPropertyToHclTerraform(struct?: AwsEcsTaskDefinition.VolumeFsxWindowsFileServerVolumeConfigurationAuthorizationConfigPropertyOutputReference | AwsEcsTaskDefinition.VolumeFsxWindowsFileServerVolumeConfigurationAuthorizationConfigProperty): any;
export declare function awsEcsTaskDefinitionFsxWindowsFileServerVolumeConfigurationPropertyToTerraform(struct?: AwsEcsTaskDefinition.FsxWindowsFileServerVolumeConfigurationPropertyOutputReference | AwsEcsTaskDefinition.FsxWindowsFileServerVolumeConfigurationProperty): any;
export declare function awsEcsTaskDefinitionFsxWindowsFileServerVolumeConfigurationPropertyToHclTerraform(struct?: AwsEcsTaskDefinition.FsxWindowsFileServerVolumeConfigurationPropertyOutputReference | AwsEcsTaskDefinition.FsxWindowsFileServerVolumeConfigurationProperty): any;
export declare function awsEcsTaskDefinitionS3filesVolumeConfigurationPropertyToTerraform(struct?: AwsEcsTaskDefinition.S3filesVolumeConfigurationPropertyOutputReference | AwsEcsTaskDefinition.S3filesVolumeConfigurationProperty): any;
export declare function awsEcsTaskDefinitionS3filesVolumeConfigurationPropertyToHclTerraform(struct?: AwsEcsTaskDefinition.S3filesVolumeConfigurationPropertyOutputReference | AwsEcsTaskDefinition.S3filesVolumeConfigurationProperty): any;
export declare function awsEcsTaskDefinitionVolumePropertyToTerraform(struct?: AwsEcsTaskDefinition.VolumeProperty | cdktn.IResolvable): any;
export declare function awsEcsTaskDefinitionVolumePropertyToHclTerraform(struct?: AwsEcsTaskDefinition.VolumeProperty | cdktn.IResolvable): any;
export declare namespace AwsEcsTaskDefinition {
    interface EphemeralStorageProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_task_definition#size_in_gib AwsEcsTaskDefinition#size_in_gib}
        */
        readonly sizeInGib: number;
    }
    class EphemeralStoragePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): EphemeralStorageProperty | undefined;
        set internalValue(value: EphemeralStorageProperty | undefined);
        private _sizeInGib?;
        get sizeInGib(): number;
        set sizeInGib(value: number);
        get sizeInGibInput(): number | undefined;
    }
    interface PlacementConstraintsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_task_definition#expression AwsEcsTaskDefinition#expression}
        */
        readonly expression?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_task_definition#type AwsEcsTaskDefinition#type}
        */
        readonly type: string;
    }
    class PlacementConstraintsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): PlacementConstraintsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: PlacementConstraintsProperty | cdktn.IResolvable | undefined);
        private _expression?;
        get expression(): string;
        set expression(value: string);
        resetExpression(): void;
        get expressionInput(): string | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
    }
    class PlacementConstraintsPropertyList extends cdktn.ComplexList {
        internalValue?: PlacementConstraintsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): PlacementConstraintsPropertyOutputReference;
    }
    interface ProxyConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_task_definition#container_name AwsEcsTaskDefinition#container_name}
        */
        readonly containerName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_task_definition#properties AwsEcsTaskDefinition#properties}
        */
        readonly properties?: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_task_definition#type AwsEcsTaskDefinition#type}
        */
        readonly type?: string;
    }
    class ProxyConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ProxyConfigurationProperty | undefined;
        set internalValue(value: ProxyConfigurationProperty | undefined);
        private _containerName?;
        get containerName(): string;
        set containerName(value: string);
        get containerNameInput(): string | undefined;
        private _properties?;
        get properties(): {
            [key: string]: string;
        };
        set properties(value: {
            [key: string]: string;
        });
        resetProperties(): void;
        get propertiesInput(): {
            [key: string]: string;
        } | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        resetType(): void;
        get typeInput(): string | undefined;
    }
    interface RuntimePlatformProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_task_definition#cpu_architecture AwsEcsTaskDefinition#cpu_architecture}
        */
        readonly cpuArchitecture?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_task_definition#operating_system_family AwsEcsTaskDefinition#operating_system_family}
        */
        readonly operatingSystemFamily?: string;
    }
    class RuntimePlatformPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RuntimePlatformProperty | undefined;
        set internalValue(value: RuntimePlatformProperty | undefined);
        private _cpuArchitecture?;
        get cpuArchitecture(): string;
        set cpuArchitecture(value: string);
        resetCpuArchitecture(): void;
        get cpuArchitectureInput(): string | undefined;
        private _operatingSystemFamily?;
        get operatingSystemFamily(): string;
        set operatingSystemFamily(value: string);
        resetOperatingSystemFamily(): void;
        get operatingSystemFamilyInput(): string | undefined;
    }
    interface DockerVolumeConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_task_definition#autoprovision AwsEcsTaskDefinition#autoprovision}
        */
        readonly autoprovision?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_task_definition#driver AwsEcsTaskDefinition#driver}
        */
        readonly driver?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_task_definition#driver_opts AwsEcsTaskDefinition#driver_opts}
        */
        readonly driverOpts?: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_task_definition#labels AwsEcsTaskDefinition#labels}
        */
        readonly labels?: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_task_definition#scope AwsEcsTaskDefinition#scope}
        */
        readonly scope?: string;
    }
    class DockerVolumeConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DockerVolumeConfigurationProperty | undefined;
        set internalValue(value: DockerVolumeConfigurationProperty | undefined);
        private _autoprovision?;
        get autoprovision(): boolean | cdktn.IResolvable;
        set autoprovision(value: boolean | cdktn.IResolvable);
        resetAutoprovision(): void;
        get autoprovisionInput(): boolean | cdktn.IResolvable | undefined;
        private _driver?;
        get driver(): string;
        set driver(value: string);
        resetDriver(): void;
        get driverInput(): string | undefined;
        private _driverOpts?;
        get driverOpts(): {
            [key: string]: string;
        };
        set driverOpts(value: {
            [key: string]: string;
        });
        resetDriverOpts(): void;
        get driverOptsInput(): {
            [key: string]: string;
        } | undefined;
        private _labels?;
        get labels(): {
            [key: string]: string;
        };
        set labels(value: {
            [key: string]: string;
        });
        resetLabels(): void;
        get labelsInput(): {
            [key: string]: string;
        } | undefined;
        private _scope?;
        get scope(): string;
        set scope(value: string);
        resetScope(): void;
        get scopeInput(): string | undefined;
    }
    interface VolumeEfsVolumeConfigurationAuthorizationConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_task_definition#access_point_id AwsEcsTaskDefinition#access_point_id}
        */
        readonly accessPointId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_task_definition#iam AwsEcsTaskDefinition#iam}
        */
        readonly iam?: string;
    }
    class VolumeEfsVolumeConfigurationAuthorizationConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): VolumeEfsVolumeConfigurationAuthorizationConfigProperty | undefined;
        set internalValue(value: VolumeEfsVolumeConfigurationAuthorizationConfigProperty | undefined);
        private _accessPointId?;
        get accessPointId(): string;
        set accessPointId(value: string);
        resetAccessPointId(): void;
        get accessPointIdInput(): string | undefined;
        private _iam?;
        get iam(): string;
        set iam(value: string);
        resetIam(): void;
        get iamInput(): string | undefined;
    }
    interface EfsVolumeConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_task_definition#file_system_id AwsEcsTaskDefinition#file_system_id}
        */
        readonly fileSystemId: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_task_definition#root_directory AwsEcsTaskDefinition#root_directory}
        */
        readonly rootDirectory?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_task_definition#transit_encryption AwsEcsTaskDefinition#transit_encryption}
        */
        readonly transitEncryption?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_task_definition#transit_encryption_port AwsEcsTaskDefinition#transit_encryption_port}
        */
        readonly transitEncryptionPort?: number;
        /**
        * authorization_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_task_definition#authorization_config AwsEcsTaskDefinition#authorization_config}
        */
        readonly authorizationConfig?: VolumeEfsVolumeConfigurationAuthorizationConfigProperty;
    }
    class EfsVolumeConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): EfsVolumeConfigurationProperty | undefined;
        set internalValue(value: EfsVolumeConfigurationProperty | undefined);
        private _fileSystemId?;
        get fileSystemId(): string;
        set fileSystemId(value: string);
        get fileSystemIdInput(): string | undefined;
        private _rootDirectory?;
        get rootDirectory(): string;
        set rootDirectory(value: string);
        resetRootDirectory(): void;
        get rootDirectoryInput(): string | undefined;
        private _transitEncryption?;
        get transitEncryption(): string;
        set transitEncryption(value: string);
        resetTransitEncryption(): void;
        get transitEncryptionInput(): string | undefined;
        private _transitEncryptionPort?;
        get transitEncryptionPort(): number;
        set transitEncryptionPort(value: number);
        resetTransitEncryptionPort(): void;
        get transitEncryptionPortInput(): number | undefined;
        private _authorizationConfig;
        get authorizationConfig(): VolumeEfsVolumeConfigurationAuthorizationConfigPropertyOutputReference;
        putAuthorizationConfig(value: VolumeEfsVolumeConfigurationAuthorizationConfigProperty): void;
        resetAuthorizationConfig(): void;
        get authorizationConfigInput(): VolumeEfsVolumeConfigurationAuthorizationConfigProperty | undefined;
    }
    interface VolumeFsxWindowsFileServerVolumeConfigurationAuthorizationConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_task_definition#credentials_parameter AwsEcsTaskDefinition#credentials_parameter}
        */
        readonly credentialsParameter: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_task_definition#domain AwsEcsTaskDefinition#domain}
        */
        readonly domain: string;
    }
    class VolumeFsxWindowsFileServerVolumeConfigurationAuthorizationConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): VolumeFsxWindowsFileServerVolumeConfigurationAuthorizationConfigProperty | undefined;
        set internalValue(value: VolumeFsxWindowsFileServerVolumeConfigurationAuthorizationConfigProperty | undefined);
        private _credentialsParameter?;
        get credentialsParameter(): string;
        set credentialsParameter(value: string);
        get credentialsParameterInput(): string | undefined;
        private _domain?;
        get domain(): string;
        set domain(value: string);
        get domainInput(): string | undefined;
    }
    interface FsxWindowsFileServerVolumeConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_task_definition#file_system_id AwsEcsTaskDefinition#file_system_id}
        */
        readonly fileSystemId: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_task_definition#root_directory AwsEcsTaskDefinition#root_directory}
        */
        readonly rootDirectory: string;
        /**
        * authorization_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_task_definition#authorization_config AwsEcsTaskDefinition#authorization_config}
        */
        readonly authorizationConfig: VolumeFsxWindowsFileServerVolumeConfigurationAuthorizationConfigProperty;
    }
    class FsxWindowsFileServerVolumeConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): FsxWindowsFileServerVolumeConfigurationProperty | undefined;
        set internalValue(value: FsxWindowsFileServerVolumeConfigurationProperty | undefined);
        private _fileSystemId?;
        get fileSystemId(): string;
        set fileSystemId(value: string);
        get fileSystemIdInput(): string | undefined;
        private _rootDirectory?;
        get rootDirectory(): string;
        set rootDirectory(value: string);
        get rootDirectoryInput(): string | undefined;
        private _authorizationConfig;
        get authorizationConfig(): VolumeFsxWindowsFileServerVolumeConfigurationAuthorizationConfigPropertyOutputReference;
        putAuthorizationConfig(value: VolumeFsxWindowsFileServerVolumeConfigurationAuthorizationConfigProperty): void;
        get authorizationConfigInput(): VolumeFsxWindowsFileServerVolumeConfigurationAuthorizationConfigProperty | undefined;
    }
    interface S3filesVolumeConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_task_definition#access_point_arn AwsEcsTaskDefinition#access_point_arn}
        */
        readonly accessPointArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_task_definition#file_system_arn AwsEcsTaskDefinition#file_system_arn}
        */
        readonly fileSystemArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_task_definition#root_directory AwsEcsTaskDefinition#root_directory}
        */
        readonly rootDirectory?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_task_definition#transit_encryption_port AwsEcsTaskDefinition#transit_encryption_port}
        */
        readonly transitEncryptionPort?: number;
    }
    class S3filesVolumeConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): S3filesVolumeConfigurationProperty | undefined;
        set internalValue(value: S3filesVolumeConfigurationProperty | undefined);
        private _accessPointArn?;
        get accessPointArn(): string;
        set accessPointArn(value: string);
        resetAccessPointArn(): void;
        get accessPointArnInput(): string | undefined;
        private _fileSystemArn?;
        get fileSystemArn(): string;
        set fileSystemArn(value: string);
        get fileSystemArnInput(): string | undefined;
        private _rootDirectory?;
        get rootDirectory(): string;
        set rootDirectory(value: string);
        resetRootDirectory(): void;
        get rootDirectoryInput(): string | undefined;
        private _transitEncryptionPort?;
        get transitEncryptionPort(): number;
        set transitEncryptionPort(value: number);
        resetTransitEncryptionPort(): void;
        get transitEncryptionPortInput(): number | undefined;
    }
    interface VolumeProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_task_definition#configure_at_launch AwsEcsTaskDefinition#configure_at_launch}
        */
        readonly configureAtLaunch?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_task_definition#host_path AwsEcsTaskDefinition#host_path}
        */
        readonly hostPath?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_task_definition#name AwsEcsTaskDefinition#name}
        */
        readonly name: string;
        /**
        * docker_volume_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_task_definition#docker_volume_configuration AwsEcsTaskDefinition#docker_volume_configuration}
        */
        readonly dockerVolumeConfiguration?: DockerVolumeConfigurationProperty;
        /**
        * efs_volume_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_task_definition#efs_volume_configuration AwsEcsTaskDefinition#efs_volume_configuration}
        */
        readonly efsVolumeConfiguration?: EfsVolumeConfigurationProperty;
        /**
        * fsx_windows_file_server_volume_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_task_definition#fsx_windows_file_server_volume_configuration AwsEcsTaskDefinition#fsx_windows_file_server_volume_configuration}
        */
        readonly fsxWindowsFileServerVolumeConfiguration?: FsxWindowsFileServerVolumeConfigurationProperty;
        /**
        * s3files_volume_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_task_definition#s3files_volume_configuration AwsEcsTaskDefinition#s3files_volume_configuration}
        */
        readonly s3FilesVolumeConfiguration?: S3filesVolumeConfigurationProperty;
    }
    class VolumePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): VolumeProperty | cdktn.IResolvable | undefined;
        set internalValue(value: VolumeProperty | cdktn.IResolvable | undefined);
        private _configureAtLaunch?;
        get configureAtLaunch(): boolean | cdktn.IResolvable;
        set configureAtLaunch(value: boolean | cdktn.IResolvable);
        resetConfigureAtLaunch(): void;
        get configureAtLaunchInput(): boolean | cdktn.IResolvable | undefined;
        private _hostPath?;
        get hostPath(): string;
        set hostPath(value: string);
        resetHostPath(): void;
        get hostPathInput(): string | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _dockerVolumeConfiguration;
        get dockerVolumeConfiguration(): DockerVolumeConfigurationPropertyOutputReference;
        putDockerVolumeConfiguration(value: DockerVolumeConfigurationProperty): void;
        resetDockerVolumeConfiguration(): void;
        get dockerVolumeConfigurationInput(): DockerVolumeConfigurationProperty | undefined;
        private _efsVolumeConfiguration;
        get efsVolumeConfiguration(): EfsVolumeConfigurationPropertyOutputReference;
        putEfsVolumeConfiguration(value: EfsVolumeConfigurationProperty): void;
        resetEfsVolumeConfiguration(): void;
        get efsVolumeConfigurationInput(): EfsVolumeConfigurationProperty | undefined;
        private _fsxWindowsFileServerVolumeConfiguration;
        get fsxWindowsFileServerVolumeConfiguration(): FsxWindowsFileServerVolumeConfigurationPropertyOutputReference;
        putFsxWindowsFileServerVolumeConfiguration(value: FsxWindowsFileServerVolumeConfigurationProperty): void;
        resetFsxWindowsFileServerVolumeConfiguration(): void;
        get fsxWindowsFileServerVolumeConfigurationInput(): FsxWindowsFileServerVolumeConfigurationProperty | undefined;
        private _s3FilesVolumeConfiguration;
        get s3FilesVolumeConfiguration(): S3filesVolumeConfigurationPropertyOutputReference;
        putS3FilesVolumeConfiguration(value: S3filesVolumeConfigurationProperty): void;
        resetS3FilesVolumeConfiguration(): void;
        get s3FilesVolumeConfigurationInput(): S3filesVolumeConfigurationProperty | undefined;
    }
    class VolumePropertyList extends cdktn.ComplexList {
        internalValue?: VolumeProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): VolumePropertyOutputReference;
    }
}
