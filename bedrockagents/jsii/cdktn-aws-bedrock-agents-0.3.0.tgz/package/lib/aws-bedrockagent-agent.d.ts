import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsAgentConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_agent#agent_collaboration AwsAgent#agent_collaboration}
    */
    readonly agentCollaboration?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_agent#agent_name AwsAgent#agent_name}
    */
    readonly agentName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_agent#agent_resource_role_arn AwsAgent#agent_resource_role_arn}
    */
    readonly agentResourceRoleArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_agent#customer_encryption_key_arn AwsAgent#customer_encryption_key_arn}
    */
    readonly customerEncryptionKeyArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_agent#description AwsAgent#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_agent#foundation_model AwsAgent#foundation_model}
    */
    readonly foundationModel: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_agent#guardrail_configuration AwsAgent#guardrail_configuration}
    */
    readonly guardrailConfiguration?: AwsAgent.GuardrailConfigurationProperty[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_agent#idle_session_ttl_in_seconds AwsAgent#idle_session_ttl_in_seconds}
    */
    readonly idleSessionTtlInSeconds?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_agent#instruction AwsAgent#instruction}
    */
    readonly instruction?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_agent#memory_configuration AwsAgent#memory_configuration}
    */
    readonly memoryConfiguration?: AwsAgent.MemoryConfigurationProperty[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_agent#prepare_agent AwsAgent#prepare_agent}
    */
    readonly prepareAgent?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_agent#prompt_override_configuration AwsAgent#prompt_override_configuration}
    */
    readonly promptOverrideConfiguration?: AwsAgent.PromptOverrideConfigurationProperty[] | cdktn.IResolvable;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_agent#region AwsAgent#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_agent#skip_resource_in_use_check AwsAgent#skip_resource_in_use_check}
    */
    readonly skipResourceInUseCheck?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_agent#tags AwsAgent#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_agent#timeouts AwsAgent#timeouts}
    */
    readonly timeouts?: AwsAgent.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_agent aws_bedrockagent_agent}
*/
export declare class AwsAgent extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_bedrockagent_agent";
    /**
    * Generates CDKTN code for importing a AwsAgent resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsAgent to import
    * @param importFromId The id of the existing AwsAgent that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_agent#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsAgent to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_agent aws_bedrockagent_agent} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsAgentConfig
    */
    constructor(scope: Construct, id: string, config: AwsAgentConfig);
    get agentArn(): string;
    private _agentCollaboration?;
    get agentCollaboration(): string;
    set agentCollaboration(value: string);
    resetAgentCollaboration(): void;
    get agentCollaborationInput(): string | undefined;
    get agentId(): string;
    private _agentName?;
    get agentName(): string;
    set agentName(value: string);
    get agentNameInput(): string | undefined;
    private _agentResourceRoleArn?;
    get agentResourceRoleArn(): string;
    set agentResourceRoleArn(value: string);
    get agentResourceRoleArnInput(): string | undefined;
    get agentVersion(): string;
    private _customerEncryptionKeyArn?;
    get customerEncryptionKeyArn(): string;
    set customerEncryptionKeyArn(value: string);
    resetCustomerEncryptionKeyArn(): void;
    get customerEncryptionKeyArnInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _foundationModel?;
    get foundationModel(): string;
    set foundationModel(value: string);
    get foundationModelInput(): string | undefined;
    private _guardrailConfiguration;
    get guardrailConfiguration(): AwsAgent.GuardrailConfigurationPropertyList;
    putGuardrailConfiguration(value: AwsAgent.GuardrailConfigurationProperty[] | cdktn.IResolvable): void;
    resetGuardrailConfiguration(): void;
    get guardrailConfigurationInput(): cdktn.IResolvable | AwsAgent.GuardrailConfigurationProperty[] | undefined;
    get id(): string;
    private _idleSessionTtlInSeconds?;
    get idleSessionTtlInSeconds(): number;
    set idleSessionTtlInSeconds(value: number);
    resetIdleSessionTtlInSeconds(): void;
    get idleSessionTtlInSecondsInput(): number | undefined;
    private _instruction?;
    get instruction(): string;
    set instruction(value: string);
    resetInstruction(): void;
    get instructionInput(): string | undefined;
    private _memoryConfiguration;
    get memoryConfiguration(): AwsAgent.MemoryConfigurationPropertyList;
    putMemoryConfiguration(value: AwsAgent.MemoryConfigurationProperty[] | cdktn.IResolvable): void;
    resetMemoryConfiguration(): void;
    get memoryConfigurationInput(): cdktn.IResolvable | AwsAgent.MemoryConfigurationProperty[] | undefined;
    private _prepareAgent?;
    get prepareAgent(): boolean | cdktn.IResolvable;
    set prepareAgent(value: boolean | cdktn.IResolvable);
    resetPrepareAgent(): void;
    get prepareAgentInput(): boolean | cdktn.IResolvable | undefined;
    get preparedAt(): string;
    private _promptOverrideConfiguration;
    get promptOverrideConfiguration(): AwsAgent.PromptOverrideConfigurationPropertyList;
    putPromptOverrideConfiguration(value: AwsAgent.PromptOverrideConfigurationProperty[] | cdktn.IResolvable): void;
    resetPromptOverrideConfiguration(): void;
    get promptOverrideConfigurationInput(): cdktn.IResolvable | AwsAgent.PromptOverrideConfigurationProperty[] | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _skipResourceInUseCheck?;
    get skipResourceInUseCheck(): boolean | cdktn.IResolvable;
    set skipResourceInUseCheck(value: boolean | cdktn.IResolvable);
    resetSkipResourceInUseCheck(): void;
    get skipResourceInUseCheckInput(): boolean | cdktn.IResolvable | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    private _timeouts;
    get timeouts(): AwsAgent.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsAgent.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsAgent.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsAgentGuardrailConfigurationPropertyToTerraform(struct?: AwsAgent.GuardrailConfigurationProperty | cdktn.IResolvable): any;
export declare function awsAgentGuardrailConfigurationPropertyToHclTerraform(struct?: AwsAgent.GuardrailConfigurationProperty | cdktn.IResolvable): any;
export declare function awsAgentSessionSummaryConfigurationPropertyToTerraform(struct?: AwsAgent.SessionSummaryConfigurationProperty | cdktn.IResolvable): any;
export declare function awsAgentSessionSummaryConfigurationPropertyToHclTerraform(struct?: AwsAgent.SessionSummaryConfigurationProperty | cdktn.IResolvable): any;
export declare function awsAgentMemoryConfigurationPropertyToTerraform(struct?: AwsAgent.MemoryConfigurationProperty | cdktn.IResolvable): any;
export declare function awsAgentMemoryConfigurationPropertyToHclTerraform(struct?: AwsAgent.MemoryConfigurationProperty | cdktn.IResolvable): any;
export declare function awsAgentInferenceConfigurationPropertyToTerraform(struct?: AwsAgent.InferenceConfigurationProperty | cdktn.IResolvable): any;
export declare function awsAgentInferenceConfigurationPropertyToHclTerraform(struct?: AwsAgent.InferenceConfigurationProperty | cdktn.IResolvable): any;
export declare function awsAgentPromptConfigurationsPropertyToTerraform(struct?: AwsAgent.PromptConfigurationsProperty | cdktn.IResolvable): any;
export declare function awsAgentPromptConfigurationsPropertyToHclTerraform(struct?: AwsAgent.PromptConfigurationsProperty | cdktn.IResolvable): any;
export declare function awsAgentPromptOverrideConfigurationPropertyToTerraform(struct?: AwsAgent.PromptOverrideConfigurationProperty | cdktn.IResolvable): any;
export declare function awsAgentPromptOverrideConfigurationPropertyToHclTerraform(struct?: AwsAgent.PromptOverrideConfigurationProperty | cdktn.IResolvable): any;
export declare function awsAgentTimeoutsPropertyToTerraform(struct?: AwsAgent.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsAgentTimeoutsPropertyToHclTerraform(struct?: AwsAgent.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsAgent {
    interface GuardrailConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_agent#guardrail_identifier AwsAgent#guardrail_identifier}
        */
        readonly guardrailIdentifier?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_agent#guardrail_version AwsAgent#guardrail_version}
        */
        readonly guardrailVersion?: string;
    }
    class GuardrailConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): GuardrailConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: GuardrailConfigurationProperty | cdktn.IResolvable | undefined);
        private _guardrailIdentifier?;
        get guardrailIdentifier(): string;
        set guardrailIdentifier(value: string);
        resetGuardrailIdentifier(): void;
        get guardrailIdentifierInput(): string | undefined;
        private _guardrailVersion?;
        get guardrailVersion(): string;
        set guardrailVersion(value: string);
        resetGuardrailVersion(): void;
        get guardrailVersionInput(): string | undefined;
    }
    class GuardrailConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: GuardrailConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): GuardrailConfigurationPropertyOutputReference;
    }
    interface SessionSummaryConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_agent#max_recent_sessions AwsAgent#max_recent_sessions}
        */
        readonly maxRecentSessions?: number;
    }
    class SessionSummaryConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SessionSummaryConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SessionSummaryConfigurationProperty | cdktn.IResolvable | undefined);
        private _maxRecentSessions?;
        get maxRecentSessions(): number;
        set maxRecentSessions(value: number);
        resetMaxRecentSessions(): void;
        get maxRecentSessionsInput(): number | undefined;
    }
    class SessionSummaryConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: SessionSummaryConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SessionSummaryConfigurationPropertyOutputReference;
    }
    interface MemoryConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_agent#enabled_memory_types AwsAgent#enabled_memory_types}
        */
        readonly enabledMemoryTypes?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_agent#session_summary_configuration AwsAgent#session_summary_configuration}
        */
        readonly sessionSummaryConfiguration?: SessionSummaryConfigurationProperty[] | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_agent#storage_days AwsAgent#storage_days}
        */
        readonly storageDays?: number;
    }
    class MemoryConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): MemoryConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: MemoryConfigurationProperty | cdktn.IResolvable | undefined);
        private _enabledMemoryTypes?;
        get enabledMemoryTypes(): string[];
        set enabledMemoryTypes(value: string[]);
        resetEnabledMemoryTypes(): void;
        get enabledMemoryTypesInput(): string[] | undefined;
        private _sessionSummaryConfiguration;
        get sessionSummaryConfiguration(): SessionSummaryConfigurationPropertyList;
        putSessionSummaryConfiguration(value: SessionSummaryConfigurationProperty[] | cdktn.IResolvable): void;
        resetSessionSummaryConfiguration(): void;
        get sessionSummaryConfigurationInput(): cdktn.IResolvable | SessionSummaryConfigurationProperty[] | undefined;
        private _storageDays?;
        get storageDays(): number;
        set storageDays(value: number);
        resetStorageDays(): void;
        get storageDaysInput(): number | undefined;
    }
    class MemoryConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: MemoryConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): MemoryConfigurationPropertyOutputReference;
    }
    interface InferenceConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_agent#max_length AwsAgent#max_length}
        */
        readonly maxLength?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_agent#stop_sequences AwsAgent#stop_sequences}
        */
        readonly stopSequences?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_agent#temperature AwsAgent#temperature}
        */
        readonly temperature?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_agent#top_k AwsAgent#top_k}
        */
        readonly topK?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_agent#top_p AwsAgent#top_p}
        */
        readonly topP?: number;
    }
    class InferenceConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): InferenceConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: InferenceConfigurationProperty | cdktn.IResolvable | undefined);
        private _maxLength?;
        get maxLength(): number;
        set maxLength(value: number);
        resetMaxLength(): void;
        get maxLengthInput(): number | undefined;
        private _stopSequences?;
        get stopSequences(): string[];
        set stopSequences(value: string[]);
        resetStopSequences(): void;
        get stopSequencesInput(): string[] | undefined;
        private _temperature?;
        get temperature(): number;
        set temperature(value: number);
        resetTemperature(): void;
        get temperatureInput(): number | undefined;
        private _topK?;
        get topK(): number;
        set topK(value: number);
        resetTopK(): void;
        get topKInput(): number | undefined;
        private _topP?;
        get topP(): number;
        set topP(value: number);
        resetTopP(): void;
        get topPInput(): number | undefined;
    }
    class InferenceConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: InferenceConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): InferenceConfigurationPropertyOutputReference;
    }
    interface PromptConfigurationsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_agent#base_prompt_template AwsAgent#base_prompt_template}
        */
        readonly basePromptTemplate?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_agent#inference_configuration AwsAgent#inference_configuration}
        */
        readonly inferenceConfiguration?: InferenceConfigurationProperty[] | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_agent#parser_mode AwsAgent#parser_mode}
        */
        readonly parserMode?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_agent#prompt_creation_mode AwsAgent#prompt_creation_mode}
        */
        readonly promptCreationMode?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_agent#prompt_state AwsAgent#prompt_state}
        */
        readonly promptState?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_agent#prompt_type AwsAgent#prompt_type}
        */
        readonly promptType?: string;
    }
    class PromptConfigurationsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): PromptConfigurationsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: PromptConfigurationsProperty | cdktn.IResolvable | undefined);
        private _basePromptTemplate?;
        get basePromptTemplate(): string;
        set basePromptTemplate(value: string);
        resetBasePromptTemplate(): void;
        get basePromptTemplateInput(): string | undefined;
        private _inferenceConfiguration;
        get inferenceConfiguration(): InferenceConfigurationPropertyList;
        putInferenceConfiguration(value: InferenceConfigurationProperty[] | cdktn.IResolvable): void;
        resetInferenceConfiguration(): void;
        get inferenceConfigurationInput(): cdktn.IResolvable | InferenceConfigurationProperty[] | undefined;
        private _parserMode?;
        get parserMode(): string;
        set parserMode(value: string);
        resetParserMode(): void;
        get parserModeInput(): string | undefined;
        private _promptCreationMode?;
        get promptCreationMode(): string;
        set promptCreationMode(value: string);
        resetPromptCreationMode(): void;
        get promptCreationModeInput(): string | undefined;
        private _promptState?;
        get promptState(): string;
        set promptState(value: string);
        resetPromptState(): void;
        get promptStateInput(): string | undefined;
        private _promptType?;
        get promptType(): string;
        set promptType(value: string);
        resetPromptType(): void;
        get promptTypeInput(): string | undefined;
    }
    class PromptConfigurationsPropertyList extends cdktn.ComplexList {
        internalValue?: PromptConfigurationsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): PromptConfigurationsPropertyOutputReference;
    }
    interface PromptOverrideConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_agent#override_lambda AwsAgent#override_lambda}
        */
        readonly overrideLambda?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_agent#prompt_configurations AwsAgent#prompt_configurations}
        */
        readonly promptConfigurations?: PromptConfigurationsProperty[] | cdktn.IResolvable;
    }
    class PromptOverrideConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): PromptOverrideConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: PromptOverrideConfigurationProperty | cdktn.IResolvable | undefined);
        private _overrideLambda?;
        get overrideLambda(): string;
        set overrideLambda(value: string);
        resetOverrideLambda(): void;
        get overrideLambdaInput(): string | undefined;
        private _promptConfigurations;
        get promptConfigurations(): PromptConfigurationsPropertyList;
        putPromptConfigurations(value: PromptConfigurationsProperty[] | cdktn.IResolvable): void;
        resetPromptConfigurations(): void;
        get promptConfigurationsInput(): cdktn.IResolvable | PromptConfigurationsProperty[] | undefined;
    }
    class PromptOverrideConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: PromptOverrideConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): PromptOverrideConfigurationPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_agent#create AwsAgent#create}
        */
        readonly create?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Setting a timeout for a Delete operation is only applicable if changes are saved into state before the destroy operation occurs.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_agent#delete AwsAgent#delete}
        */
        readonly delete?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_agent#update AwsAgent#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
