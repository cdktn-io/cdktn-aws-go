import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsDataSourceConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_data_source#data_deletion_policy AwsDataSource#data_deletion_policy}
    */
    readonly dataDeletionPolicy?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_data_source#description AwsDataSource#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_data_source#knowledge_base_id AwsDataSource#knowledge_base_id}
    */
    readonly knowledgeBaseId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_data_source#name AwsDataSource#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_data_source#region AwsDataSource#region}
    */
    readonly region?: string;
    /**
    * data_source_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_data_source#data_source_configuration AwsDataSource#data_source_configuration}
    */
    readonly dataSourceConfiguration?: AwsDataSource.DataSourceConfigurationProperty[] | cdktn.IResolvable;
    /**
    * server_side_encryption_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_data_source#server_side_encryption_configuration AwsDataSource#server_side_encryption_configuration}
    */
    readonly serverSideEncryptionConfiguration?: AwsDataSource.ServerSideEncryptionConfigurationProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_data_source#timeouts AwsDataSource#timeouts}
    */
    readonly timeouts?: AwsDataSource.TimeoutsProperty;
    /**
    * vector_ingestion_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_data_source#vector_ingestion_configuration AwsDataSource#vector_ingestion_configuration}
    */
    readonly vectorIngestionConfiguration?: AwsDataSource.VectorIngestionConfigurationProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_data_source aws_bedrockagent_data_source}
*/
export declare class AwsDataSource extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_bedrockagent_data_source";
    /**
    * Generates CDKTN code for importing a AwsDataSource resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsDataSource to import
    * @param importFromId The id of the existing AwsDataSource that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_data_source#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsDataSource to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_data_source aws_bedrockagent_data_source} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsDataSourceConfig
    */
    constructor(scope: Construct, id: string, config: AwsDataSourceConfig);
    private _dataDeletionPolicy?;
    get dataDeletionPolicy(): string;
    set dataDeletionPolicy(value: string);
    resetDataDeletionPolicy(): void;
    get dataDeletionPolicyInput(): string | undefined;
    get dataSourceId(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get id(): string;
    private _knowledgeBaseId?;
    get knowledgeBaseId(): string;
    set knowledgeBaseId(value: string);
    get knowledgeBaseIdInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _dataSourceConfiguration;
    get dataSourceConfiguration(): AwsDataSource.DataSourceConfigurationPropertyList;
    putDataSourceConfiguration(value: AwsDataSource.DataSourceConfigurationProperty[] | cdktn.IResolvable): void;
    resetDataSourceConfiguration(): void;
    get dataSourceConfigurationInput(): cdktn.IResolvable | AwsDataSource.DataSourceConfigurationProperty[] | undefined;
    private _serverSideEncryptionConfiguration;
    get serverSideEncryptionConfiguration(): AwsDataSource.ServerSideEncryptionConfigurationPropertyList;
    putServerSideEncryptionConfiguration(value: AwsDataSource.ServerSideEncryptionConfigurationProperty[] | cdktn.IResolvable): void;
    resetServerSideEncryptionConfiguration(): void;
    get serverSideEncryptionConfigurationInput(): cdktn.IResolvable | AwsDataSource.ServerSideEncryptionConfigurationProperty[] | undefined;
    private _timeouts;
    get timeouts(): AwsDataSource.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsDataSource.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsDataSource.TimeoutsProperty | undefined;
    private _vectorIngestionConfiguration;
    get vectorIngestionConfiguration(): AwsDataSource.VectorIngestionConfigurationPropertyList;
    putVectorIngestionConfiguration(value: AwsDataSource.VectorIngestionConfigurationProperty[] | cdktn.IResolvable): void;
    resetVectorIngestionConfiguration(): void;
    get vectorIngestionConfigurationInput(): cdktn.IResolvable | AwsDataSource.VectorIngestionConfigurationProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsDataSourceDataSourceConfigurationConfluenceConfigurationCrawlerConfigurationFilterConfigurationPatternObjectFilterFiltersPropertyToTerraform(struct?: AwsDataSource.DataSourceConfigurationConfluenceConfigurationCrawlerConfigurationFilterConfigurationPatternObjectFilterFiltersProperty | cdktn.IResolvable): any;
export declare function awsDataSourceDataSourceConfigurationConfluenceConfigurationCrawlerConfigurationFilterConfigurationPatternObjectFilterFiltersPropertyToHclTerraform(struct?: AwsDataSource.DataSourceConfigurationConfluenceConfigurationCrawlerConfigurationFilterConfigurationPatternObjectFilterFiltersProperty | cdktn.IResolvable): any;
export declare function awsDataSourceDataSourceConfigurationConfluenceConfigurationCrawlerConfigurationFilterConfigurationPatternObjectFilterPropertyToTerraform(struct?: AwsDataSource.DataSourceConfigurationConfluenceConfigurationCrawlerConfigurationFilterConfigurationPatternObjectFilterProperty | cdktn.IResolvable): any;
export declare function awsDataSourceDataSourceConfigurationConfluenceConfigurationCrawlerConfigurationFilterConfigurationPatternObjectFilterPropertyToHclTerraform(struct?: AwsDataSource.DataSourceConfigurationConfluenceConfigurationCrawlerConfigurationFilterConfigurationPatternObjectFilterProperty | cdktn.IResolvable): any;
export declare function awsDataSourceDataSourceConfigurationConfluenceConfigurationCrawlerConfigurationFilterConfigurationPropertyToTerraform(struct?: AwsDataSource.DataSourceConfigurationConfluenceConfigurationCrawlerConfigurationFilterConfigurationProperty | cdktn.IResolvable): any;
export declare function awsDataSourceDataSourceConfigurationConfluenceConfigurationCrawlerConfigurationFilterConfigurationPropertyToHclTerraform(struct?: AwsDataSource.DataSourceConfigurationConfluenceConfigurationCrawlerConfigurationFilterConfigurationProperty | cdktn.IResolvable): any;
export declare function awsDataSourceDataSourceConfigurationConfluenceConfigurationCrawlerConfigurationPropertyToTerraform(struct?: AwsDataSource.DataSourceConfigurationConfluenceConfigurationCrawlerConfigurationProperty | cdktn.IResolvable): any;
export declare function awsDataSourceDataSourceConfigurationConfluenceConfigurationCrawlerConfigurationPropertyToHclTerraform(struct?: AwsDataSource.DataSourceConfigurationConfluenceConfigurationCrawlerConfigurationProperty | cdktn.IResolvable): any;
export declare function awsDataSourceDataSourceConfigurationConfluenceConfigurationSourceConfigurationPropertyToTerraform(struct?: AwsDataSource.DataSourceConfigurationConfluenceConfigurationSourceConfigurationProperty | cdktn.IResolvable): any;
export declare function awsDataSourceDataSourceConfigurationConfluenceConfigurationSourceConfigurationPropertyToHclTerraform(struct?: AwsDataSource.DataSourceConfigurationConfluenceConfigurationSourceConfigurationProperty | cdktn.IResolvable): any;
export declare function awsDataSourceConfluenceConfigurationPropertyToTerraform(struct?: AwsDataSource.ConfluenceConfigurationProperty | cdktn.IResolvable): any;
export declare function awsDataSourceConfluenceConfigurationPropertyToHclTerraform(struct?: AwsDataSource.ConfluenceConfigurationProperty | cdktn.IResolvable): any;
export declare function awsDataSourceDeletionProtectionConfigurationPropertyToTerraform(struct?: AwsDataSource.DeletionProtectionConfigurationProperty | cdktn.IResolvable): any;
export declare function awsDataSourceDeletionProtectionConfigurationPropertyToHclTerraform(struct?: AwsDataSource.DeletionProtectionConfigurationProperty | cdktn.IResolvable): any;
export declare function awsDataSourceAudioExtractionConfigurationPropertyToTerraform(struct?: AwsDataSource.AudioExtractionConfigurationProperty | cdktn.IResolvable): any;
export declare function awsDataSourceAudioExtractionConfigurationPropertyToHclTerraform(struct?: AwsDataSource.AudioExtractionConfigurationProperty | cdktn.IResolvable): any;
export declare function awsDataSourceImageExtractionConfigurationPropertyToTerraform(struct?: AwsDataSource.ImageExtractionConfigurationProperty | cdktn.IResolvable): any;
export declare function awsDataSourceImageExtractionConfigurationPropertyToHclTerraform(struct?: AwsDataSource.ImageExtractionConfigurationProperty | cdktn.IResolvable): any;
export declare function awsDataSourceVideoExtractionConfigurationPropertyToTerraform(struct?: AwsDataSource.VideoExtractionConfigurationProperty | cdktn.IResolvable): any;
export declare function awsDataSourceVideoExtractionConfigurationPropertyToHclTerraform(struct?: AwsDataSource.VideoExtractionConfigurationProperty | cdktn.IResolvable): any;
export declare function awsDataSourceMediaExtractionConfigurationPropertyToTerraform(struct?: AwsDataSource.MediaExtractionConfigurationProperty | cdktn.IResolvable): any;
export declare function awsDataSourceMediaExtractionConfigurationPropertyToHclTerraform(struct?: AwsDataSource.MediaExtractionConfigurationProperty | cdktn.IResolvable): any;
export declare function awsDataSourceManagedKnowledgeBaseConnectorConfigurationPropertyToTerraform(struct?: AwsDataSource.ManagedKnowledgeBaseConnectorConfigurationProperty | cdktn.IResolvable): any;
export declare function awsDataSourceManagedKnowledgeBaseConnectorConfigurationPropertyToHclTerraform(struct?: AwsDataSource.ManagedKnowledgeBaseConnectorConfigurationProperty | cdktn.IResolvable): any;
export declare function awsDataSourceS3ConfigurationPropertyToTerraform(struct?: AwsDataSource.S3ConfigurationProperty | cdktn.IResolvable): any;
export declare function awsDataSourceS3ConfigurationPropertyToHclTerraform(struct?: AwsDataSource.S3ConfigurationProperty | cdktn.IResolvable): any;
export declare function awsDataSourceDataSourceConfigurationSalesforceConfigurationCrawlerConfigurationFilterConfigurationPatternObjectFilterFiltersPropertyToTerraform(struct?: AwsDataSource.DataSourceConfigurationSalesforceConfigurationCrawlerConfigurationFilterConfigurationPatternObjectFilterFiltersProperty | cdktn.IResolvable): any;
export declare function awsDataSourceDataSourceConfigurationSalesforceConfigurationCrawlerConfigurationFilterConfigurationPatternObjectFilterFiltersPropertyToHclTerraform(struct?: AwsDataSource.DataSourceConfigurationSalesforceConfigurationCrawlerConfigurationFilterConfigurationPatternObjectFilterFiltersProperty | cdktn.IResolvable): any;
export declare function awsDataSourceDataSourceConfigurationSalesforceConfigurationCrawlerConfigurationFilterConfigurationPatternObjectFilterPropertyToTerraform(struct?: AwsDataSource.DataSourceConfigurationSalesforceConfigurationCrawlerConfigurationFilterConfigurationPatternObjectFilterProperty | cdktn.IResolvable): any;
export declare function awsDataSourceDataSourceConfigurationSalesforceConfigurationCrawlerConfigurationFilterConfigurationPatternObjectFilterPropertyToHclTerraform(struct?: AwsDataSource.DataSourceConfigurationSalesforceConfigurationCrawlerConfigurationFilterConfigurationPatternObjectFilterProperty | cdktn.IResolvable): any;
export declare function awsDataSourceDataSourceConfigurationSalesforceConfigurationCrawlerConfigurationFilterConfigurationPropertyToTerraform(struct?: AwsDataSource.DataSourceConfigurationSalesforceConfigurationCrawlerConfigurationFilterConfigurationProperty | cdktn.IResolvable): any;
export declare function awsDataSourceDataSourceConfigurationSalesforceConfigurationCrawlerConfigurationFilterConfigurationPropertyToHclTerraform(struct?: AwsDataSource.DataSourceConfigurationSalesforceConfigurationCrawlerConfigurationFilterConfigurationProperty | cdktn.IResolvable): any;
export declare function awsDataSourceDataSourceConfigurationSalesforceConfigurationCrawlerConfigurationPropertyToTerraform(struct?: AwsDataSource.DataSourceConfigurationSalesforceConfigurationCrawlerConfigurationProperty | cdktn.IResolvable): any;
export declare function awsDataSourceDataSourceConfigurationSalesforceConfigurationCrawlerConfigurationPropertyToHclTerraform(struct?: AwsDataSource.DataSourceConfigurationSalesforceConfigurationCrawlerConfigurationProperty | cdktn.IResolvable): any;
export declare function awsDataSourceDataSourceConfigurationSalesforceConfigurationSourceConfigurationPropertyToTerraform(struct?: AwsDataSource.DataSourceConfigurationSalesforceConfigurationSourceConfigurationProperty | cdktn.IResolvable): any;
export declare function awsDataSourceDataSourceConfigurationSalesforceConfigurationSourceConfigurationPropertyToHclTerraform(struct?: AwsDataSource.DataSourceConfigurationSalesforceConfigurationSourceConfigurationProperty | cdktn.IResolvable): any;
export declare function awsDataSourceSalesforceConfigurationPropertyToTerraform(struct?: AwsDataSource.SalesforceConfigurationProperty | cdktn.IResolvable): any;
export declare function awsDataSourceSalesforceConfigurationPropertyToHclTerraform(struct?: AwsDataSource.SalesforceConfigurationProperty | cdktn.IResolvable): any;
export declare function awsDataSourceDataSourceConfigurationSharePointConfigurationCrawlerConfigurationFilterConfigurationPatternObjectFilterFiltersPropertyToTerraform(struct?: AwsDataSource.DataSourceConfigurationSharePointConfigurationCrawlerConfigurationFilterConfigurationPatternObjectFilterFiltersProperty | cdktn.IResolvable): any;
export declare function awsDataSourceDataSourceConfigurationSharePointConfigurationCrawlerConfigurationFilterConfigurationPatternObjectFilterFiltersPropertyToHclTerraform(struct?: AwsDataSource.DataSourceConfigurationSharePointConfigurationCrawlerConfigurationFilterConfigurationPatternObjectFilterFiltersProperty | cdktn.IResolvable): any;
export declare function awsDataSourceDataSourceConfigurationSharePointConfigurationCrawlerConfigurationFilterConfigurationPatternObjectFilterPropertyToTerraform(struct?: AwsDataSource.DataSourceConfigurationSharePointConfigurationCrawlerConfigurationFilterConfigurationPatternObjectFilterProperty | cdktn.IResolvable): any;
export declare function awsDataSourceDataSourceConfigurationSharePointConfigurationCrawlerConfigurationFilterConfigurationPatternObjectFilterPropertyToHclTerraform(struct?: AwsDataSource.DataSourceConfigurationSharePointConfigurationCrawlerConfigurationFilterConfigurationPatternObjectFilterProperty | cdktn.IResolvable): any;
export declare function awsDataSourceDataSourceConfigurationSharePointConfigurationCrawlerConfigurationFilterConfigurationPropertyToTerraform(struct?: AwsDataSource.DataSourceConfigurationSharePointConfigurationCrawlerConfigurationFilterConfigurationProperty | cdktn.IResolvable): any;
export declare function awsDataSourceDataSourceConfigurationSharePointConfigurationCrawlerConfigurationFilterConfigurationPropertyToHclTerraform(struct?: AwsDataSource.DataSourceConfigurationSharePointConfigurationCrawlerConfigurationFilterConfigurationProperty | cdktn.IResolvable): any;
export declare function awsDataSourceDataSourceConfigurationSharePointConfigurationCrawlerConfigurationPropertyToTerraform(struct?: AwsDataSource.DataSourceConfigurationSharePointConfigurationCrawlerConfigurationProperty | cdktn.IResolvable): any;
export declare function awsDataSourceDataSourceConfigurationSharePointConfigurationCrawlerConfigurationPropertyToHclTerraform(struct?: AwsDataSource.DataSourceConfigurationSharePointConfigurationCrawlerConfigurationProperty | cdktn.IResolvable): any;
export declare function awsDataSourceDataSourceConfigurationSharePointConfigurationSourceConfigurationPropertyToTerraform(struct?: AwsDataSource.DataSourceConfigurationSharePointConfigurationSourceConfigurationProperty | cdktn.IResolvable): any;
export declare function awsDataSourceDataSourceConfigurationSharePointConfigurationSourceConfigurationPropertyToHclTerraform(struct?: AwsDataSource.DataSourceConfigurationSharePointConfigurationSourceConfigurationProperty | cdktn.IResolvable): any;
export declare function awsDataSourceSharePointConfigurationPropertyToTerraform(struct?: AwsDataSource.SharePointConfigurationProperty | cdktn.IResolvable): any;
export declare function awsDataSourceSharePointConfigurationPropertyToHclTerraform(struct?: AwsDataSource.SharePointConfigurationProperty | cdktn.IResolvable): any;
export declare function awsDataSourceCrawlerLimitsPropertyToTerraform(struct?: AwsDataSource.CrawlerLimitsProperty | cdktn.IResolvable): any;
export declare function awsDataSourceCrawlerLimitsPropertyToHclTerraform(struct?: AwsDataSource.CrawlerLimitsProperty | cdktn.IResolvable): any;
export declare function awsDataSourceDataSourceConfigurationWebConfigurationCrawlerConfigurationPropertyToTerraform(struct?: AwsDataSource.DataSourceConfigurationWebConfigurationCrawlerConfigurationProperty | cdktn.IResolvable): any;
export declare function awsDataSourceDataSourceConfigurationWebConfigurationCrawlerConfigurationPropertyToHclTerraform(struct?: AwsDataSource.DataSourceConfigurationWebConfigurationCrawlerConfigurationProperty | cdktn.IResolvable): any;
export declare function awsDataSourceSeedUrlsPropertyToTerraform(struct?: AwsDataSource.SeedUrlsProperty | cdktn.IResolvable): any;
export declare function awsDataSourceSeedUrlsPropertyToHclTerraform(struct?: AwsDataSource.SeedUrlsProperty | cdktn.IResolvable): any;
export declare function awsDataSourceUrlConfigurationPropertyToTerraform(struct?: AwsDataSource.UrlConfigurationProperty | cdktn.IResolvable): any;
export declare function awsDataSourceUrlConfigurationPropertyToHclTerraform(struct?: AwsDataSource.UrlConfigurationProperty | cdktn.IResolvable): any;
export declare function awsDataSourceDataSourceConfigurationWebConfigurationSourceConfigurationPropertyToTerraform(struct?: AwsDataSource.DataSourceConfigurationWebConfigurationSourceConfigurationProperty | cdktn.IResolvable): any;
export declare function awsDataSourceDataSourceConfigurationWebConfigurationSourceConfigurationPropertyToHclTerraform(struct?: AwsDataSource.DataSourceConfigurationWebConfigurationSourceConfigurationProperty | cdktn.IResolvable): any;
export declare function awsDataSourceWebConfigurationPropertyToTerraform(struct?: AwsDataSource.WebConfigurationProperty | cdktn.IResolvable): any;
export declare function awsDataSourceWebConfigurationPropertyToHclTerraform(struct?: AwsDataSource.WebConfigurationProperty | cdktn.IResolvable): any;
export declare function awsDataSourceDataSourceConfigurationPropertyToTerraform(struct?: AwsDataSource.DataSourceConfigurationProperty | cdktn.IResolvable): any;
export declare function awsDataSourceDataSourceConfigurationPropertyToHclTerraform(struct?: AwsDataSource.DataSourceConfigurationProperty | cdktn.IResolvable): any;
export declare function awsDataSourceServerSideEncryptionConfigurationPropertyToTerraform(struct?: AwsDataSource.ServerSideEncryptionConfigurationProperty | cdktn.IResolvable): any;
export declare function awsDataSourceServerSideEncryptionConfigurationPropertyToHclTerraform(struct?: AwsDataSource.ServerSideEncryptionConfigurationProperty | cdktn.IResolvable): any;
export declare function awsDataSourceTimeoutsPropertyToTerraform(struct?: AwsDataSource.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsDataSourceTimeoutsPropertyToHclTerraform(struct?: AwsDataSource.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsDataSourceFixedSizeChunkingConfigurationPropertyToTerraform(struct?: AwsDataSource.FixedSizeChunkingConfigurationProperty | cdktn.IResolvable): any;
export declare function awsDataSourceFixedSizeChunkingConfigurationPropertyToHclTerraform(struct?: AwsDataSource.FixedSizeChunkingConfigurationProperty | cdktn.IResolvable): any;
export declare function awsDataSourceLevelConfigurationPropertyToTerraform(struct?: AwsDataSource.LevelConfigurationProperty | cdktn.IResolvable): any;
export declare function awsDataSourceLevelConfigurationPropertyToHclTerraform(struct?: AwsDataSource.LevelConfigurationProperty | cdktn.IResolvable): any;
export declare function awsDataSourceHierarchicalChunkingConfigurationPropertyToTerraform(struct?: AwsDataSource.HierarchicalChunkingConfigurationProperty | cdktn.IResolvable): any;
export declare function awsDataSourceHierarchicalChunkingConfigurationPropertyToHclTerraform(struct?: AwsDataSource.HierarchicalChunkingConfigurationProperty | cdktn.IResolvable): any;
export declare function awsDataSourceSemanticChunkingConfigurationPropertyToTerraform(struct?: AwsDataSource.SemanticChunkingConfigurationProperty | cdktn.IResolvable): any;
export declare function awsDataSourceSemanticChunkingConfigurationPropertyToHclTerraform(struct?: AwsDataSource.SemanticChunkingConfigurationProperty | cdktn.IResolvable): any;
export declare function awsDataSourceChunkingConfigurationPropertyToTerraform(struct?: AwsDataSource.ChunkingConfigurationProperty | cdktn.IResolvable): any;
export declare function awsDataSourceChunkingConfigurationPropertyToHclTerraform(struct?: AwsDataSource.ChunkingConfigurationProperty | cdktn.IResolvable): any;
export declare function awsDataSourceS3LocationPropertyToTerraform(struct?: AwsDataSource.S3LocationProperty | cdktn.IResolvable): any;
export declare function awsDataSourceS3LocationPropertyToHclTerraform(struct?: AwsDataSource.S3LocationProperty | cdktn.IResolvable): any;
export declare function awsDataSourceIntermediateStoragePropertyToTerraform(struct?: AwsDataSource.IntermediateStorageProperty | cdktn.IResolvable): any;
export declare function awsDataSourceIntermediateStoragePropertyToHclTerraform(struct?: AwsDataSource.IntermediateStorageProperty | cdktn.IResolvable): any;
export declare function awsDataSourceTransformationLambdaConfigurationPropertyToTerraform(struct?: AwsDataSource.TransformationLambdaConfigurationProperty | cdktn.IResolvable): any;
export declare function awsDataSourceTransformationLambdaConfigurationPropertyToHclTerraform(struct?: AwsDataSource.TransformationLambdaConfigurationProperty | cdktn.IResolvable): any;
export declare function awsDataSourceTransformationFunctionPropertyToTerraform(struct?: AwsDataSource.TransformationFunctionProperty | cdktn.IResolvable): any;
export declare function awsDataSourceTransformationFunctionPropertyToHclTerraform(struct?: AwsDataSource.TransformationFunctionProperty | cdktn.IResolvable): any;
export declare function awsDataSourceTransformationPropertyToTerraform(struct?: AwsDataSource.TransformationProperty | cdktn.IResolvable): any;
export declare function awsDataSourceTransformationPropertyToHclTerraform(struct?: AwsDataSource.TransformationProperty | cdktn.IResolvable): any;
export declare function awsDataSourceCustomTransformationConfigurationPropertyToTerraform(struct?: AwsDataSource.CustomTransformationConfigurationProperty | cdktn.IResolvable): any;
export declare function awsDataSourceCustomTransformationConfigurationPropertyToHclTerraform(struct?: AwsDataSource.CustomTransformationConfigurationProperty | cdktn.IResolvable): any;
export declare function awsDataSourceBedrockDataAutomationConfigurationPropertyToTerraform(struct?: AwsDataSource.BedrockDataAutomationConfigurationProperty | cdktn.IResolvable): any;
export declare function awsDataSourceBedrockDataAutomationConfigurationPropertyToHclTerraform(struct?: AwsDataSource.BedrockDataAutomationConfigurationProperty | cdktn.IResolvable): any;
export declare function awsDataSourceParsingPromptPropertyToTerraform(struct?: AwsDataSource.ParsingPromptProperty | cdktn.IResolvable): any;
export declare function awsDataSourceParsingPromptPropertyToHclTerraform(struct?: AwsDataSource.ParsingPromptProperty | cdktn.IResolvable): any;
export declare function awsDataSourceBedrockFoundationModelConfigurationPropertyToTerraform(struct?: AwsDataSource.BedrockFoundationModelConfigurationProperty | cdktn.IResolvable): any;
export declare function awsDataSourceBedrockFoundationModelConfigurationPropertyToHclTerraform(struct?: AwsDataSource.BedrockFoundationModelConfigurationProperty | cdktn.IResolvable): any;
export declare function awsDataSourceParsingConfigurationPropertyToTerraform(struct?: AwsDataSource.ParsingConfigurationProperty | cdktn.IResolvable): any;
export declare function awsDataSourceParsingConfigurationPropertyToHclTerraform(struct?: AwsDataSource.ParsingConfigurationProperty | cdktn.IResolvable): any;
export declare function awsDataSourceVectorIngestionConfigurationPropertyToTerraform(struct?: AwsDataSource.VectorIngestionConfigurationProperty | cdktn.IResolvable): any;
export declare function awsDataSourceVectorIngestionConfigurationPropertyToHclTerraform(struct?: AwsDataSource.VectorIngestionConfigurationProperty | cdktn.IResolvable): any;
export declare namespace AwsDataSource {
    interface DataSourceConfigurationConfluenceConfigurationCrawlerConfigurationFilterConfigurationPatternObjectFilterFiltersProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_data_source#exclusion_filters AwsDataSource#exclusion_filters}
        */
        readonly exclusionFilters?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_data_source#inclusion_filters AwsDataSource#inclusion_filters}
        */
        readonly inclusionFilters?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_data_source#object_type AwsDataSource#object_type}
        */
        readonly objectType: string;
    }
    class DataSourceConfigurationConfluenceConfigurationCrawlerConfigurationFilterConfigurationPatternObjectFilterFiltersPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DataSourceConfigurationConfluenceConfigurationCrawlerConfigurationFilterConfigurationPatternObjectFilterFiltersProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DataSourceConfigurationConfluenceConfigurationCrawlerConfigurationFilterConfigurationPatternObjectFilterFiltersProperty | cdktn.IResolvable | undefined);
        private _exclusionFilters?;
        get exclusionFilters(): string[];
        set exclusionFilters(value: string[]);
        resetExclusionFilters(): void;
        get exclusionFiltersInput(): string[] | undefined;
        private _inclusionFilters?;
        get inclusionFilters(): string[];
        set inclusionFilters(value: string[]);
        resetInclusionFilters(): void;
        get inclusionFiltersInput(): string[] | undefined;
        private _objectType?;
        get objectType(): string;
        set objectType(value: string);
        get objectTypeInput(): string | undefined;
    }
    class DataSourceConfigurationConfluenceConfigurationCrawlerConfigurationFilterConfigurationPatternObjectFilterFiltersPropertyList extends cdktn.ComplexList {
        internalValue?: DataSourceConfigurationConfluenceConfigurationCrawlerConfigurationFilterConfigurationPatternObjectFilterFiltersProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DataSourceConfigurationConfluenceConfigurationCrawlerConfigurationFilterConfigurationPatternObjectFilterFiltersPropertyOutputReference;
    }
    interface DataSourceConfigurationConfluenceConfigurationCrawlerConfigurationFilterConfigurationPatternObjectFilterProperty {
        /**
        * filters block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_data_source#filters AwsDataSource#filters}
        */
        readonly filters?: DataSourceConfigurationConfluenceConfigurationCrawlerConfigurationFilterConfigurationPatternObjectFilterFiltersProperty[] | cdktn.IResolvable;
    }
    class DataSourceConfigurationConfluenceConfigurationCrawlerConfigurationFilterConfigurationPatternObjectFilterPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DataSourceConfigurationConfluenceConfigurationCrawlerConfigurationFilterConfigurationPatternObjectFilterProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DataSourceConfigurationConfluenceConfigurationCrawlerConfigurationFilterConfigurationPatternObjectFilterProperty | cdktn.IResolvable | undefined);
        private _filters;
        get filters(): DataSourceConfigurationConfluenceConfigurationCrawlerConfigurationFilterConfigurationPatternObjectFilterFiltersPropertyList;
        putFilters(value: DataSourceConfigurationConfluenceConfigurationCrawlerConfigurationFilterConfigurationPatternObjectFilterFiltersProperty[] | cdktn.IResolvable): void;
        resetFilters(): void;
        get filtersInput(): cdktn.IResolvable | DataSourceConfigurationConfluenceConfigurationCrawlerConfigurationFilterConfigurationPatternObjectFilterFiltersProperty[] | undefined;
    }
    class DataSourceConfigurationConfluenceConfigurationCrawlerConfigurationFilterConfigurationPatternObjectFilterPropertyList extends cdktn.ComplexList {
        internalValue?: DataSourceConfigurationConfluenceConfigurationCrawlerConfigurationFilterConfigurationPatternObjectFilterProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DataSourceConfigurationConfluenceConfigurationCrawlerConfigurationFilterConfigurationPatternObjectFilterPropertyOutputReference;
    }
    interface DataSourceConfigurationConfluenceConfigurationCrawlerConfigurationFilterConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_data_source#type AwsDataSource#type}
        */
        readonly type: string;
        /**
        * pattern_object_filter block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_data_source#pattern_object_filter AwsDataSource#pattern_object_filter}
        */
        readonly patternObjectFilter?: DataSourceConfigurationConfluenceConfigurationCrawlerConfigurationFilterConfigurationPatternObjectFilterProperty[] | cdktn.IResolvable;
    }
    class DataSourceConfigurationConfluenceConfigurationCrawlerConfigurationFilterConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DataSourceConfigurationConfluenceConfigurationCrawlerConfigurationFilterConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DataSourceConfigurationConfluenceConfigurationCrawlerConfigurationFilterConfigurationProperty | cdktn.IResolvable | undefined);
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
        private _patternObjectFilter;
        get patternObjectFilter(): DataSourceConfigurationConfluenceConfigurationCrawlerConfigurationFilterConfigurationPatternObjectFilterPropertyList;
        putPatternObjectFilter(value: DataSourceConfigurationConfluenceConfigurationCrawlerConfigurationFilterConfigurationPatternObjectFilterProperty[] | cdktn.IResolvable): void;
        resetPatternObjectFilter(): void;
        get patternObjectFilterInput(): cdktn.IResolvable | DataSourceConfigurationConfluenceConfigurationCrawlerConfigurationFilterConfigurationPatternObjectFilterProperty[] | undefined;
    }
    class DataSourceConfigurationConfluenceConfigurationCrawlerConfigurationFilterConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: DataSourceConfigurationConfluenceConfigurationCrawlerConfigurationFilterConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DataSourceConfigurationConfluenceConfigurationCrawlerConfigurationFilterConfigurationPropertyOutputReference;
    }
    interface DataSourceConfigurationConfluenceConfigurationCrawlerConfigurationProperty {
        /**
        * filter_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_data_source#filter_configuration AwsDataSource#filter_configuration}
        */
        readonly filterConfiguration?: DataSourceConfigurationConfluenceConfigurationCrawlerConfigurationFilterConfigurationProperty[] | cdktn.IResolvable;
    }
    class DataSourceConfigurationConfluenceConfigurationCrawlerConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DataSourceConfigurationConfluenceConfigurationCrawlerConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DataSourceConfigurationConfluenceConfigurationCrawlerConfigurationProperty | cdktn.IResolvable | undefined);
        private _filterConfiguration;
        get filterConfiguration(): DataSourceConfigurationConfluenceConfigurationCrawlerConfigurationFilterConfigurationPropertyList;
        putFilterConfiguration(value: DataSourceConfigurationConfluenceConfigurationCrawlerConfigurationFilterConfigurationProperty[] | cdktn.IResolvable): void;
        resetFilterConfiguration(): void;
        get filterConfigurationInput(): cdktn.IResolvable | DataSourceConfigurationConfluenceConfigurationCrawlerConfigurationFilterConfigurationProperty[] | undefined;
    }
    class DataSourceConfigurationConfluenceConfigurationCrawlerConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: DataSourceConfigurationConfluenceConfigurationCrawlerConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DataSourceConfigurationConfluenceConfigurationCrawlerConfigurationPropertyOutputReference;
    }
    interface DataSourceConfigurationConfluenceConfigurationSourceConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_data_source#auth_type AwsDataSource#auth_type}
        */
        readonly authType: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_data_source#credentials_secret_arn AwsDataSource#credentials_secret_arn}
        */
        readonly credentialsSecretArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_data_source#host_type AwsDataSource#host_type}
        */
        readonly hostType: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_data_source#host_url AwsDataSource#host_url}
        */
        readonly hostUrl: string;
    }
    class DataSourceConfigurationConfluenceConfigurationSourceConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DataSourceConfigurationConfluenceConfigurationSourceConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DataSourceConfigurationConfluenceConfigurationSourceConfigurationProperty | cdktn.IResolvable | undefined);
        private _authType?;
        get authType(): string;
        set authType(value: string);
        get authTypeInput(): string | undefined;
        private _credentialsSecretArn?;
        get credentialsSecretArn(): string;
        set credentialsSecretArn(value: string);
        get credentialsSecretArnInput(): string | undefined;
        private _hostType?;
        get hostType(): string;
        set hostType(value: string);
        get hostTypeInput(): string | undefined;
        private _hostUrl?;
        get hostUrl(): string;
        set hostUrl(value: string);
        get hostUrlInput(): string | undefined;
    }
    class DataSourceConfigurationConfluenceConfigurationSourceConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: DataSourceConfigurationConfluenceConfigurationSourceConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DataSourceConfigurationConfluenceConfigurationSourceConfigurationPropertyOutputReference;
    }
    interface ConfluenceConfigurationProperty {
        /**
        * crawler_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_data_source#crawler_configuration AwsDataSource#crawler_configuration}
        */
        readonly crawlerConfiguration?: DataSourceConfigurationConfluenceConfigurationCrawlerConfigurationProperty[] | cdktn.IResolvable;
        /**
        * source_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_data_source#source_configuration AwsDataSource#source_configuration}
        */
        readonly sourceConfiguration?: DataSourceConfigurationConfluenceConfigurationSourceConfigurationProperty[] | cdktn.IResolvable;
    }
    class ConfluenceConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ConfluenceConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ConfluenceConfigurationProperty | cdktn.IResolvable | undefined);
        private _crawlerConfiguration;
        get crawlerConfiguration(): DataSourceConfigurationConfluenceConfigurationCrawlerConfigurationPropertyList;
        putCrawlerConfiguration(value: DataSourceConfigurationConfluenceConfigurationCrawlerConfigurationProperty[] | cdktn.IResolvable): void;
        resetCrawlerConfiguration(): void;
        get crawlerConfigurationInput(): cdktn.IResolvable | DataSourceConfigurationConfluenceConfigurationCrawlerConfigurationProperty[] | undefined;
        private _sourceConfiguration;
        get sourceConfiguration(): DataSourceConfigurationConfluenceConfigurationSourceConfigurationPropertyList;
        putSourceConfiguration(value: DataSourceConfigurationConfluenceConfigurationSourceConfigurationProperty[] | cdktn.IResolvable): void;
        resetSourceConfiguration(): void;
        get sourceConfigurationInput(): cdktn.IResolvable | DataSourceConfigurationConfluenceConfigurationSourceConfigurationProperty[] | undefined;
    }
    class ConfluenceConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: ConfluenceConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ConfluenceConfigurationPropertyOutputReference;
    }
    interface DeletionProtectionConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_data_source#deletion_protection_status AwsDataSource#deletion_protection_status}
        */
        readonly deletionProtectionStatus: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_data_source#deletion_protection_threshold AwsDataSource#deletion_protection_threshold}
        */
        readonly deletionProtectionThreshold?: number;
    }
    class DeletionProtectionConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DeletionProtectionConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DeletionProtectionConfigurationProperty | cdktn.IResolvable | undefined);
        private _deletionProtectionStatus?;
        get deletionProtectionStatus(): string;
        set deletionProtectionStatus(value: string);
        get deletionProtectionStatusInput(): string | undefined;
        private _deletionProtectionThreshold?;
        get deletionProtectionThreshold(): number;
        set deletionProtectionThreshold(value: number);
        resetDeletionProtectionThreshold(): void;
        get deletionProtectionThresholdInput(): number | undefined;
    }
    class DeletionProtectionConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: DeletionProtectionConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DeletionProtectionConfigurationPropertyOutputReference;
    }
    interface AudioExtractionConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_data_source#audio_extraction_status AwsDataSource#audio_extraction_status}
        */
        readonly audioExtractionStatus: string;
    }
    class AudioExtractionConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AudioExtractionConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: AudioExtractionConfigurationProperty | cdktn.IResolvable | undefined);
        private _audioExtractionStatus?;
        get audioExtractionStatus(): string;
        set audioExtractionStatus(value: string);
        get audioExtractionStatusInput(): string | undefined;
    }
    class AudioExtractionConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: AudioExtractionConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AudioExtractionConfigurationPropertyOutputReference;
    }
    interface ImageExtractionConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_data_source#image_extraction_status AwsDataSource#image_extraction_status}
        */
        readonly imageExtractionStatus: string;
    }
    class ImageExtractionConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ImageExtractionConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ImageExtractionConfigurationProperty | cdktn.IResolvable | undefined);
        private _imageExtractionStatus?;
        get imageExtractionStatus(): string;
        set imageExtractionStatus(value: string);
        get imageExtractionStatusInput(): string | undefined;
    }
    class ImageExtractionConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: ImageExtractionConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ImageExtractionConfigurationPropertyOutputReference;
    }
    interface VideoExtractionConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_data_source#video_extraction_status AwsDataSource#video_extraction_status}
        */
        readonly videoExtractionStatus: string;
    }
    class VideoExtractionConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): VideoExtractionConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: VideoExtractionConfigurationProperty | cdktn.IResolvable | undefined);
        private _videoExtractionStatus?;
        get videoExtractionStatus(): string;
        set videoExtractionStatus(value: string);
        get videoExtractionStatusInput(): string | undefined;
    }
    class VideoExtractionConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: VideoExtractionConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): VideoExtractionConfigurationPropertyOutputReference;
    }
    interface MediaExtractionConfigurationProperty {
        /**
        * audio_extraction_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_data_source#audio_extraction_configuration AwsDataSource#audio_extraction_configuration}
        */
        readonly audioExtractionConfiguration?: AudioExtractionConfigurationProperty[] | cdktn.IResolvable;
        /**
        * image_extraction_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_data_source#image_extraction_configuration AwsDataSource#image_extraction_configuration}
        */
        readonly imageExtractionConfiguration?: ImageExtractionConfigurationProperty[] | cdktn.IResolvable;
        /**
        * video_extraction_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_data_source#video_extraction_configuration AwsDataSource#video_extraction_configuration}
        */
        readonly videoExtractionConfiguration?: VideoExtractionConfigurationProperty[] | cdktn.IResolvable;
    }
    class MediaExtractionConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): MediaExtractionConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: MediaExtractionConfigurationProperty | cdktn.IResolvable | undefined);
        private _audioExtractionConfiguration;
        get audioExtractionConfiguration(): AudioExtractionConfigurationPropertyList;
        putAudioExtractionConfiguration(value: AudioExtractionConfigurationProperty[] | cdktn.IResolvable): void;
        resetAudioExtractionConfiguration(): void;
        get audioExtractionConfigurationInput(): cdktn.IResolvable | AudioExtractionConfigurationProperty[] | undefined;
        private _imageExtractionConfiguration;
        get imageExtractionConfiguration(): ImageExtractionConfigurationPropertyList;
        putImageExtractionConfiguration(value: ImageExtractionConfigurationProperty[] | cdktn.IResolvable): void;
        resetImageExtractionConfiguration(): void;
        get imageExtractionConfigurationInput(): cdktn.IResolvable | ImageExtractionConfigurationProperty[] | undefined;
        private _videoExtractionConfiguration;
        get videoExtractionConfiguration(): VideoExtractionConfigurationPropertyList;
        putVideoExtractionConfiguration(value: VideoExtractionConfigurationProperty[] | cdktn.IResolvable): void;
        resetVideoExtractionConfiguration(): void;
        get videoExtractionConfigurationInput(): cdktn.IResolvable | VideoExtractionConfigurationProperty[] | undefined;
    }
    class MediaExtractionConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: MediaExtractionConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): MediaExtractionConfigurationPropertyOutputReference;
    }
    interface ManagedKnowledgeBaseConnectorConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_data_source#connector_parameters AwsDataSource#connector_parameters}
        */
        readonly connectorParameters?: string;
        /**
        * deletion_protection_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_data_source#deletion_protection_configuration AwsDataSource#deletion_protection_configuration}
        */
        readonly deletionProtectionConfiguration?: DeletionProtectionConfigurationProperty[] | cdktn.IResolvable;
        /**
        * media_extraction_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_data_source#media_extraction_configuration AwsDataSource#media_extraction_configuration}
        */
        readonly mediaExtractionConfiguration?: MediaExtractionConfigurationProperty[] | cdktn.IResolvable;
    }
    class ManagedKnowledgeBaseConnectorConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ManagedKnowledgeBaseConnectorConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ManagedKnowledgeBaseConnectorConfigurationProperty | cdktn.IResolvable | undefined);
        private _connectorParameters?;
        get connectorParameters(): string;
        set connectorParameters(value: string);
        resetConnectorParameters(): void;
        get connectorParametersInput(): string | undefined;
        private _deletionProtectionConfiguration;
        get deletionProtectionConfiguration(): DeletionProtectionConfigurationPropertyList;
        putDeletionProtectionConfiguration(value: DeletionProtectionConfigurationProperty[] | cdktn.IResolvable): void;
        resetDeletionProtectionConfiguration(): void;
        get deletionProtectionConfigurationInput(): cdktn.IResolvable | DeletionProtectionConfigurationProperty[] | undefined;
        private _mediaExtractionConfiguration;
        get mediaExtractionConfiguration(): MediaExtractionConfigurationPropertyList;
        putMediaExtractionConfiguration(value: MediaExtractionConfigurationProperty[] | cdktn.IResolvable): void;
        resetMediaExtractionConfiguration(): void;
        get mediaExtractionConfigurationInput(): cdktn.IResolvable | MediaExtractionConfigurationProperty[] | undefined;
    }
    class ManagedKnowledgeBaseConnectorConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: ManagedKnowledgeBaseConnectorConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ManagedKnowledgeBaseConnectorConfigurationPropertyOutputReference;
    }
    interface S3ConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_data_source#bucket_arn AwsDataSource#bucket_arn}
        */
        readonly bucketArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_data_source#bucket_owner_account_id AwsDataSource#bucket_owner_account_id}
        */
        readonly bucketOwnerAccountId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_data_source#inclusion_prefixes AwsDataSource#inclusion_prefixes}
        */
        readonly inclusionPrefixes?: string[];
    }
    class S3ConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): S3ConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: S3ConfigurationProperty | cdktn.IResolvable | undefined);
        private _bucketArn?;
        get bucketArn(): string;
        set bucketArn(value: string);
        get bucketArnInput(): string | undefined;
        private _bucketOwnerAccountId?;
        get bucketOwnerAccountId(): string;
        set bucketOwnerAccountId(value: string);
        resetBucketOwnerAccountId(): void;
        get bucketOwnerAccountIdInput(): string | undefined;
        private _inclusionPrefixes?;
        get inclusionPrefixes(): string[];
        set inclusionPrefixes(value: string[]);
        resetInclusionPrefixes(): void;
        get inclusionPrefixesInput(): string[] | undefined;
    }
    class S3ConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: S3ConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): S3ConfigurationPropertyOutputReference;
    }
    interface DataSourceConfigurationSalesforceConfigurationCrawlerConfigurationFilterConfigurationPatternObjectFilterFiltersProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_data_source#exclusion_filters AwsDataSource#exclusion_filters}
        */
        readonly exclusionFilters?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_data_source#inclusion_filters AwsDataSource#inclusion_filters}
        */
        readonly inclusionFilters?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_data_source#object_type AwsDataSource#object_type}
        */
        readonly objectType: string;
    }
    class DataSourceConfigurationSalesforceConfigurationCrawlerConfigurationFilterConfigurationPatternObjectFilterFiltersPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DataSourceConfigurationSalesforceConfigurationCrawlerConfigurationFilterConfigurationPatternObjectFilterFiltersProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DataSourceConfigurationSalesforceConfigurationCrawlerConfigurationFilterConfigurationPatternObjectFilterFiltersProperty | cdktn.IResolvable | undefined);
        private _exclusionFilters?;
        get exclusionFilters(): string[];
        set exclusionFilters(value: string[]);
        resetExclusionFilters(): void;
        get exclusionFiltersInput(): string[] | undefined;
        private _inclusionFilters?;
        get inclusionFilters(): string[];
        set inclusionFilters(value: string[]);
        resetInclusionFilters(): void;
        get inclusionFiltersInput(): string[] | undefined;
        private _objectType?;
        get objectType(): string;
        set objectType(value: string);
        get objectTypeInput(): string | undefined;
    }
    class DataSourceConfigurationSalesforceConfigurationCrawlerConfigurationFilterConfigurationPatternObjectFilterFiltersPropertyList extends cdktn.ComplexList {
        internalValue?: DataSourceConfigurationSalesforceConfigurationCrawlerConfigurationFilterConfigurationPatternObjectFilterFiltersProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DataSourceConfigurationSalesforceConfigurationCrawlerConfigurationFilterConfigurationPatternObjectFilterFiltersPropertyOutputReference;
    }
    interface DataSourceConfigurationSalesforceConfigurationCrawlerConfigurationFilterConfigurationPatternObjectFilterProperty {
        /**
        * filters block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_data_source#filters AwsDataSource#filters}
        */
        readonly filters?: DataSourceConfigurationSalesforceConfigurationCrawlerConfigurationFilterConfigurationPatternObjectFilterFiltersProperty[] | cdktn.IResolvable;
    }
    class DataSourceConfigurationSalesforceConfigurationCrawlerConfigurationFilterConfigurationPatternObjectFilterPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DataSourceConfigurationSalesforceConfigurationCrawlerConfigurationFilterConfigurationPatternObjectFilterProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DataSourceConfigurationSalesforceConfigurationCrawlerConfigurationFilterConfigurationPatternObjectFilterProperty | cdktn.IResolvable | undefined);
        private _filters;
        get filters(): DataSourceConfigurationSalesforceConfigurationCrawlerConfigurationFilterConfigurationPatternObjectFilterFiltersPropertyList;
        putFilters(value: DataSourceConfigurationSalesforceConfigurationCrawlerConfigurationFilterConfigurationPatternObjectFilterFiltersProperty[] | cdktn.IResolvable): void;
        resetFilters(): void;
        get filtersInput(): cdktn.IResolvable | DataSourceConfigurationSalesforceConfigurationCrawlerConfigurationFilterConfigurationPatternObjectFilterFiltersProperty[] | undefined;
    }
    class DataSourceConfigurationSalesforceConfigurationCrawlerConfigurationFilterConfigurationPatternObjectFilterPropertyList extends cdktn.ComplexList {
        internalValue?: DataSourceConfigurationSalesforceConfigurationCrawlerConfigurationFilterConfigurationPatternObjectFilterProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DataSourceConfigurationSalesforceConfigurationCrawlerConfigurationFilterConfigurationPatternObjectFilterPropertyOutputReference;
    }
    interface DataSourceConfigurationSalesforceConfigurationCrawlerConfigurationFilterConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_data_source#type AwsDataSource#type}
        */
        readonly type: string;
        /**
        * pattern_object_filter block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_data_source#pattern_object_filter AwsDataSource#pattern_object_filter}
        */
        readonly patternObjectFilter?: DataSourceConfigurationSalesforceConfigurationCrawlerConfigurationFilterConfigurationPatternObjectFilterProperty[] | cdktn.IResolvable;
    }
    class DataSourceConfigurationSalesforceConfigurationCrawlerConfigurationFilterConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DataSourceConfigurationSalesforceConfigurationCrawlerConfigurationFilterConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DataSourceConfigurationSalesforceConfigurationCrawlerConfigurationFilterConfigurationProperty | cdktn.IResolvable | undefined);
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
        private _patternObjectFilter;
        get patternObjectFilter(): DataSourceConfigurationSalesforceConfigurationCrawlerConfigurationFilterConfigurationPatternObjectFilterPropertyList;
        putPatternObjectFilter(value: DataSourceConfigurationSalesforceConfigurationCrawlerConfigurationFilterConfigurationPatternObjectFilterProperty[] | cdktn.IResolvable): void;
        resetPatternObjectFilter(): void;
        get patternObjectFilterInput(): cdktn.IResolvable | DataSourceConfigurationSalesforceConfigurationCrawlerConfigurationFilterConfigurationPatternObjectFilterProperty[] | undefined;
    }
    class DataSourceConfigurationSalesforceConfigurationCrawlerConfigurationFilterConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: DataSourceConfigurationSalesforceConfigurationCrawlerConfigurationFilterConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DataSourceConfigurationSalesforceConfigurationCrawlerConfigurationFilterConfigurationPropertyOutputReference;
    }
    interface DataSourceConfigurationSalesforceConfigurationCrawlerConfigurationProperty {
        /**
        * filter_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_data_source#filter_configuration AwsDataSource#filter_configuration}
        */
        readonly filterConfiguration?: DataSourceConfigurationSalesforceConfigurationCrawlerConfigurationFilterConfigurationProperty[] | cdktn.IResolvable;
    }
    class DataSourceConfigurationSalesforceConfigurationCrawlerConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DataSourceConfigurationSalesforceConfigurationCrawlerConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DataSourceConfigurationSalesforceConfigurationCrawlerConfigurationProperty | cdktn.IResolvable | undefined);
        private _filterConfiguration;
        get filterConfiguration(): DataSourceConfigurationSalesforceConfigurationCrawlerConfigurationFilterConfigurationPropertyList;
        putFilterConfiguration(value: DataSourceConfigurationSalesforceConfigurationCrawlerConfigurationFilterConfigurationProperty[] | cdktn.IResolvable): void;
        resetFilterConfiguration(): void;
        get filterConfigurationInput(): cdktn.IResolvable | DataSourceConfigurationSalesforceConfigurationCrawlerConfigurationFilterConfigurationProperty[] | undefined;
    }
    class DataSourceConfigurationSalesforceConfigurationCrawlerConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: DataSourceConfigurationSalesforceConfigurationCrawlerConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DataSourceConfigurationSalesforceConfigurationCrawlerConfigurationPropertyOutputReference;
    }
    interface DataSourceConfigurationSalesforceConfigurationSourceConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_data_source#auth_type AwsDataSource#auth_type}
        */
        readonly authType: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_data_source#credentials_secret_arn AwsDataSource#credentials_secret_arn}
        */
        readonly credentialsSecretArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_data_source#host_url AwsDataSource#host_url}
        */
        readonly hostUrl: string;
    }
    class DataSourceConfigurationSalesforceConfigurationSourceConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DataSourceConfigurationSalesforceConfigurationSourceConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DataSourceConfigurationSalesforceConfigurationSourceConfigurationProperty | cdktn.IResolvable | undefined);
        private _authType?;
        get authType(): string;
        set authType(value: string);
        get authTypeInput(): string | undefined;
        private _credentialsSecretArn?;
        get credentialsSecretArn(): string;
        set credentialsSecretArn(value: string);
        get credentialsSecretArnInput(): string | undefined;
        private _hostUrl?;
        get hostUrl(): string;
        set hostUrl(value: string);
        get hostUrlInput(): string | undefined;
    }
    class DataSourceConfigurationSalesforceConfigurationSourceConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: DataSourceConfigurationSalesforceConfigurationSourceConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DataSourceConfigurationSalesforceConfigurationSourceConfigurationPropertyOutputReference;
    }
    interface SalesforceConfigurationProperty {
        /**
        * crawler_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_data_source#crawler_configuration AwsDataSource#crawler_configuration}
        */
        readonly crawlerConfiguration?: DataSourceConfigurationSalesforceConfigurationCrawlerConfigurationProperty[] | cdktn.IResolvable;
        /**
        * source_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_data_source#source_configuration AwsDataSource#source_configuration}
        */
        readonly sourceConfiguration?: DataSourceConfigurationSalesforceConfigurationSourceConfigurationProperty[] | cdktn.IResolvable;
    }
    class SalesforceConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SalesforceConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SalesforceConfigurationProperty | cdktn.IResolvable | undefined);
        private _crawlerConfiguration;
        get crawlerConfiguration(): DataSourceConfigurationSalesforceConfigurationCrawlerConfigurationPropertyList;
        putCrawlerConfiguration(value: DataSourceConfigurationSalesforceConfigurationCrawlerConfigurationProperty[] | cdktn.IResolvable): void;
        resetCrawlerConfiguration(): void;
        get crawlerConfigurationInput(): cdktn.IResolvable | DataSourceConfigurationSalesforceConfigurationCrawlerConfigurationProperty[] | undefined;
        private _sourceConfiguration;
        get sourceConfiguration(): DataSourceConfigurationSalesforceConfigurationSourceConfigurationPropertyList;
        putSourceConfiguration(value: DataSourceConfigurationSalesforceConfigurationSourceConfigurationProperty[] | cdktn.IResolvable): void;
        resetSourceConfiguration(): void;
        get sourceConfigurationInput(): cdktn.IResolvable | DataSourceConfigurationSalesforceConfigurationSourceConfigurationProperty[] | undefined;
    }
    class SalesforceConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: SalesforceConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SalesforceConfigurationPropertyOutputReference;
    }
    interface DataSourceConfigurationSharePointConfigurationCrawlerConfigurationFilterConfigurationPatternObjectFilterFiltersProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_data_source#exclusion_filters AwsDataSource#exclusion_filters}
        */
        readonly exclusionFilters?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_data_source#inclusion_filters AwsDataSource#inclusion_filters}
        */
        readonly inclusionFilters?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_data_source#object_type AwsDataSource#object_type}
        */
        readonly objectType: string;
    }
    class DataSourceConfigurationSharePointConfigurationCrawlerConfigurationFilterConfigurationPatternObjectFilterFiltersPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DataSourceConfigurationSharePointConfigurationCrawlerConfigurationFilterConfigurationPatternObjectFilterFiltersProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DataSourceConfigurationSharePointConfigurationCrawlerConfigurationFilterConfigurationPatternObjectFilterFiltersProperty | cdktn.IResolvable | undefined);
        private _exclusionFilters?;
        get exclusionFilters(): string[];
        set exclusionFilters(value: string[]);
        resetExclusionFilters(): void;
        get exclusionFiltersInput(): string[] | undefined;
        private _inclusionFilters?;
        get inclusionFilters(): string[];
        set inclusionFilters(value: string[]);
        resetInclusionFilters(): void;
        get inclusionFiltersInput(): string[] | undefined;
        private _objectType?;
        get objectType(): string;
        set objectType(value: string);
        get objectTypeInput(): string | undefined;
    }
    class DataSourceConfigurationSharePointConfigurationCrawlerConfigurationFilterConfigurationPatternObjectFilterFiltersPropertyList extends cdktn.ComplexList {
        internalValue?: DataSourceConfigurationSharePointConfigurationCrawlerConfigurationFilterConfigurationPatternObjectFilterFiltersProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DataSourceConfigurationSharePointConfigurationCrawlerConfigurationFilterConfigurationPatternObjectFilterFiltersPropertyOutputReference;
    }
    interface DataSourceConfigurationSharePointConfigurationCrawlerConfigurationFilterConfigurationPatternObjectFilterProperty {
        /**
        * filters block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_data_source#filters AwsDataSource#filters}
        */
        readonly filters?: DataSourceConfigurationSharePointConfigurationCrawlerConfigurationFilterConfigurationPatternObjectFilterFiltersProperty[] | cdktn.IResolvable;
    }
    class DataSourceConfigurationSharePointConfigurationCrawlerConfigurationFilterConfigurationPatternObjectFilterPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DataSourceConfigurationSharePointConfigurationCrawlerConfigurationFilterConfigurationPatternObjectFilterProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DataSourceConfigurationSharePointConfigurationCrawlerConfigurationFilterConfigurationPatternObjectFilterProperty | cdktn.IResolvable | undefined);
        private _filters;
        get filters(): DataSourceConfigurationSharePointConfigurationCrawlerConfigurationFilterConfigurationPatternObjectFilterFiltersPropertyList;
        putFilters(value: DataSourceConfigurationSharePointConfigurationCrawlerConfigurationFilterConfigurationPatternObjectFilterFiltersProperty[] | cdktn.IResolvable): void;
        resetFilters(): void;
        get filtersInput(): cdktn.IResolvable | DataSourceConfigurationSharePointConfigurationCrawlerConfigurationFilterConfigurationPatternObjectFilterFiltersProperty[] | undefined;
    }
    class DataSourceConfigurationSharePointConfigurationCrawlerConfigurationFilterConfigurationPatternObjectFilterPropertyList extends cdktn.ComplexList {
        internalValue?: DataSourceConfigurationSharePointConfigurationCrawlerConfigurationFilterConfigurationPatternObjectFilterProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DataSourceConfigurationSharePointConfigurationCrawlerConfigurationFilterConfigurationPatternObjectFilterPropertyOutputReference;
    }
    interface DataSourceConfigurationSharePointConfigurationCrawlerConfigurationFilterConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_data_source#type AwsDataSource#type}
        */
        readonly type: string;
        /**
        * pattern_object_filter block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_data_source#pattern_object_filter AwsDataSource#pattern_object_filter}
        */
        readonly patternObjectFilter?: DataSourceConfigurationSharePointConfigurationCrawlerConfigurationFilterConfigurationPatternObjectFilterProperty[] | cdktn.IResolvable;
    }
    class DataSourceConfigurationSharePointConfigurationCrawlerConfigurationFilterConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DataSourceConfigurationSharePointConfigurationCrawlerConfigurationFilterConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DataSourceConfigurationSharePointConfigurationCrawlerConfigurationFilterConfigurationProperty | cdktn.IResolvable | undefined);
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
        private _patternObjectFilter;
        get patternObjectFilter(): DataSourceConfigurationSharePointConfigurationCrawlerConfigurationFilterConfigurationPatternObjectFilterPropertyList;
        putPatternObjectFilter(value: DataSourceConfigurationSharePointConfigurationCrawlerConfigurationFilterConfigurationPatternObjectFilterProperty[] | cdktn.IResolvable): void;
        resetPatternObjectFilter(): void;
        get patternObjectFilterInput(): cdktn.IResolvable | DataSourceConfigurationSharePointConfigurationCrawlerConfigurationFilterConfigurationPatternObjectFilterProperty[] | undefined;
    }
    class DataSourceConfigurationSharePointConfigurationCrawlerConfigurationFilterConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: DataSourceConfigurationSharePointConfigurationCrawlerConfigurationFilterConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DataSourceConfigurationSharePointConfigurationCrawlerConfigurationFilterConfigurationPropertyOutputReference;
    }
    interface DataSourceConfigurationSharePointConfigurationCrawlerConfigurationProperty {
        /**
        * filter_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_data_source#filter_configuration AwsDataSource#filter_configuration}
        */
        readonly filterConfiguration?: DataSourceConfigurationSharePointConfigurationCrawlerConfigurationFilterConfigurationProperty[] | cdktn.IResolvable;
    }
    class DataSourceConfigurationSharePointConfigurationCrawlerConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DataSourceConfigurationSharePointConfigurationCrawlerConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DataSourceConfigurationSharePointConfigurationCrawlerConfigurationProperty | cdktn.IResolvable | undefined);
        private _filterConfiguration;
        get filterConfiguration(): DataSourceConfigurationSharePointConfigurationCrawlerConfigurationFilterConfigurationPropertyList;
        putFilterConfiguration(value: DataSourceConfigurationSharePointConfigurationCrawlerConfigurationFilterConfigurationProperty[] | cdktn.IResolvable): void;
        resetFilterConfiguration(): void;
        get filterConfigurationInput(): cdktn.IResolvable | DataSourceConfigurationSharePointConfigurationCrawlerConfigurationFilterConfigurationProperty[] | undefined;
    }
    class DataSourceConfigurationSharePointConfigurationCrawlerConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: DataSourceConfigurationSharePointConfigurationCrawlerConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DataSourceConfigurationSharePointConfigurationCrawlerConfigurationPropertyOutputReference;
    }
    interface DataSourceConfigurationSharePointConfigurationSourceConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_data_source#auth_type AwsDataSource#auth_type}
        */
        readonly authType: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_data_source#credentials_secret_arn AwsDataSource#credentials_secret_arn}
        */
        readonly credentialsSecretArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_data_source#domain AwsDataSource#domain}
        */
        readonly domain: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_data_source#host_type AwsDataSource#host_type}
        */
        readonly hostType: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_data_source#site_urls AwsDataSource#site_urls}
        */
        readonly siteUrls: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_data_source#tenant_id AwsDataSource#tenant_id}
        */
        readonly tenantId?: string;
    }
    class DataSourceConfigurationSharePointConfigurationSourceConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DataSourceConfigurationSharePointConfigurationSourceConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DataSourceConfigurationSharePointConfigurationSourceConfigurationProperty | cdktn.IResolvable | undefined);
        private _authType?;
        get authType(): string;
        set authType(value: string);
        get authTypeInput(): string | undefined;
        private _credentialsSecretArn?;
        get credentialsSecretArn(): string;
        set credentialsSecretArn(value: string);
        get credentialsSecretArnInput(): string | undefined;
        private _domain?;
        get domain(): string;
        set domain(value: string);
        get domainInput(): string | undefined;
        private _hostType?;
        get hostType(): string;
        set hostType(value: string);
        get hostTypeInput(): string | undefined;
        private _siteUrls?;
        get siteUrls(): string[];
        set siteUrls(value: string[]);
        get siteUrlsInput(): string[] | undefined;
        private _tenantId?;
        get tenantId(): string;
        set tenantId(value: string);
        resetTenantId(): void;
        get tenantIdInput(): string | undefined;
    }
    class DataSourceConfigurationSharePointConfigurationSourceConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: DataSourceConfigurationSharePointConfigurationSourceConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DataSourceConfigurationSharePointConfigurationSourceConfigurationPropertyOutputReference;
    }
    interface SharePointConfigurationProperty {
        /**
        * crawler_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_data_source#crawler_configuration AwsDataSource#crawler_configuration}
        */
        readonly crawlerConfiguration?: DataSourceConfigurationSharePointConfigurationCrawlerConfigurationProperty[] | cdktn.IResolvable;
        /**
        * source_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_data_source#source_configuration AwsDataSource#source_configuration}
        */
        readonly sourceConfiguration?: DataSourceConfigurationSharePointConfigurationSourceConfigurationProperty[] | cdktn.IResolvable;
    }
    class SharePointConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SharePointConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SharePointConfigurationProperty | cdktn.IResolvable | undefined);
        private _crawlerConfiguration;
        get crawlerConfiguration(): DataSourceConfigurationSharePointConfigurationCrawlerConfigurationPropertyList;
        putCrawlerConfiguration(value: DataSourceConfigurationSharePointConfigurationCrawlerConfigurationProperty[] | cdktn.IResolvable): void;
        resetCrawlerConfiguration(): void;
        get crawlerConfigurationInput(): cdktn.IResolvable | DataSourceConfigurationSharePointConfigurationCrawlerConfigurationProperty[] | undefined;
        private _sourceConfiguration;
        get sourceConfiguration(): DataSourceConfigurationSharePointConfigurationSourceConfigurationPropertyList;
        putSourceConfiguration(value: DataSourceConfigurationSharePointConfigurationSourceConfigurationProperty[] | cdktn.IResolvable): void;
        resetSourceConfiguration(): void;
        get sourceConfigurationInput(): cdktn.IResolvable | DataSourceConfigurationSharePointConfigurationSourceConfigurationProperty[] | undefined;
    }
    class SharePointConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: SharePointConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SharePointConfigurationPropertyOutputReference;
    }
    interface CrawlerLimitsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_data_source#max_pages AwsDataSource#max_pages}
        */
        readonly maxPages?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_data_source#rate_limit AwsDataSource#rate_limit}
        */
        readonly rateLimit?: number;
    }
    class CrawlerLimitsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CrawlerLimitsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CrawlerLimitsProperty | cdktn.IResolvable | undefined);
        private _maxPages?;
        get maxPages(): number;
        set maxPages(value: number);
        resetMaxPages(): void;
        get maxPagesInput(): number | undefined;
        private _rateLimit?;
        get rateLimit(): number;
        set rateLimit(value: number);
        resetRateLimit(): void;
        get rateLimitInput(): number | undefined;
    }
    class CrawlerLimitsPropertyList extends cdktn.ComplexList {
        internalValue?: CrawlerLimitsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CrawlerLimitsPropertyOutputReference;
    }
    interface DataSourceConfigurationWebConfigurationCrawlerConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_data_source#exclusion_filters AwsDataSource#exclusion_filters}
        */
        readonly exclusionFilters?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_data_source#inclusion_filters AwsDataSource#inclusion_filters}
        */
        readonly inclusionFilters?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_data_source#scope AwsDataSource#scope}
        */
        readonly scope?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_data_source#user_agent AwsDataSource#user_agent}
        */
        readonly userAgent?: string;
        /**
        * crawler_limits block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_data_source#crawler_limits AwsDataSource#crawler_limits}
        */
        readonly crawlerLimits?: CrawlerLimitsProperty[] | cdktn.IResolvable;
    }
    class DataSourceConfigurationWebConfigurationCrawlerConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DataSourceConfigurationWebConfigurationCrawlerConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DataSourceConfigurationWebConfigurationCrawlerConfigurationProperty | cdktn.IResolvable | undefined);
        private _exclusionFilters?;
        get exclusionFilters(): string[];
        set exclusionFilters(value: string[]);
        resetExclusionFilters(): void;
        get exclusionFiltersInput(): string[] | undefined;
        private _inclusionFilters?;
        get inclusionFilters(): string[];
        set inclusionFilters(value: string[]);
        resetInclusionFilters(): void;
        get inclusionFiltersInput(): string[] | undefined;
        private _scope?;
        get scope(): string;
        set scope(value: string);
        resetScope(): void;
        get scopeInput(): string | undefined;
        private _userAgent?;
        get userAgent(): string;
        set userAgent(value: string);
        resetUserAgent(): void;
        get userAgentInput(): string | undefined;
        private _crawlerLimits;
        get crawlerLimits(): CrawlerLimitsPropertyList;
        putCrawlerLimits(value: CrawlerLimitsProperty[] | cdktn.IResolvable): void;
        resetCrawlerLimits(): void;
        get crawlerLimitsInput(): cdktn.IResolvable | CrawlerLimitsProperty[] | undefined;
    }
    class DataSourceConfigurationWebConfigurationCrawlerConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: DataSourceConfigurationWebConfigurationCrawlerConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DataSourceConfigurationWebConfigurationCrawlerConfigurationPropertyOutputReference;
    }
    interface SeedUrlsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_data_source#url AwsDataSource#url}
        */
        readonly url?: string;
    }
    class SeedUrlsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SeedUrlsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SeedUrlsProperty | cdktn.IResolvable | undefined);
        private _url?;
        get url(): string;
        set url(value: string);
        resetUrl(): void;
        get urlInput(): string | undefined;
    }
    class SeedUrlsPropertyList extends cdktn.ComplexList {
        internalValue?: SeedUrlsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SeedUrlsPropertyOutputReference;
    }
    interface UrlConfigurationProperty {
        /**
        * seed_urls block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_data_source#seed_urls AwsDataSource#seed_urls}
        */
        readonly seedUrls?: SeedUrlsProperty[] | cdktn.IResolvable;
    }
    class UrlConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): UrlConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: UrlConfigurationProperty | cdktn.IResolvable | undefined);
        private _seedUrls;
        get seedUrls(): SeedUrlsPropertyList;
        putSeedUrls(value: SeedUrlsProperty[] | cdktn.IResolvable): void;
        resetSeedUrls(): void;
        get seedUrlsInput(): cdktn.IResolvable | SeedUrlsProperty[] | undefined;
    }
    class UrlConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: UrlConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): UrlConfigurationPropertyOutputReference;
    }
    interface DataSourceConfigurationWebConfigurationSourceConfigurationProperty {
        /**
        * url_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_data_source#url_configuration AwsDataSource#url_configuration}
        */
        readonly urlConfiguration?: UrlConfigurationProperty[] | cdktn.IResolvable;
    }
    class DataSourceConfigurationWebConfigurationSourceConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DataSourceConfigurationWebConfigurationSourceConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DataSourceConfigurationWebConfigurationSourceConfigurationProperty | cdktn.IResolvable | undefined);
        private _urlConfiguration;
        get urlConfiguration(): UrlConfigurationPropertyList;
        putUrlConfiguration(value: UrlConfigurationProperty[] | cdktn.IResolvable): void;
        resetUrlConfiguration(): void;
        get urlConfigurationInput(): cdktn.IResolvable | UrlConfigurationProperty[] | undefined;
    }
    class DataSourceConfigurationWebConfigurationSourceConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: DataSourceConfigurationWebConfigurationSourceConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DataSourceConfigurationWebConfigurationSourceConfigurationPropertyOutputReference;
    }
    interface WebConfigurationProperty {
        /**
        * crawler_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_data_source#crawler_configuration AwsDataSource#crawler_configuration}
        */
        readonly crawlerConfiguration?: DataSourceConfigurationWebConfigurationCrawlerConfigurationProperty[] | cdktn.IResolvable;
        /**
        * source_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_data_source#source_configuration AwsDataSource#source_configuration}
        */
        readonly sourceConfiguration?: DataSourceConfigurationWebConfigurationSourceConfigurationProperty[] | cdktn.IResolvable;
    }
    class WebConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WebConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WebConfigurationProperty | cdktn.IResolvable | undefined);
        private _crawlerConfiguration;
        get crawlerConfiguration(): DataSourceConfigurationWebConfigurationCrawlerConfigurationPropertyList;
        putCrawlerConfiguration(value: DataSourceConfigurationWebConfigurationCrawlerConfigurationProperty[] | cdktn.IResolvable): void;
        resetCrawlerConfiguration(): void;
        get crawlerConfigurationInput(): cdktn.IResolvable | DataSourceConfigurationWebConfigurationCrawlerConfigurationProperty[] | undefined;
        private _sourceConfiguration;
        get sourceConfiguration(): DataSourceConfigurationWebConfigurationSourceConfigurationPropertyList;
        putSourceConfiguration(value: DataSourceConfigurationWebConfigurationSourceConfigurationProperty[] | cdktn.IResolvable): void;
        resetSourceConfiguration(): void;
        get sourceConfigurationInput(): cdktn.IResolvable | DataSourceConfigurationWebConfigurationSourceConfigurationProperty[] | undefined;
    }
    class WebConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: WebConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WebConfigurationPropertyOutputReference;
    }
    interface DataSourceConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_data_source#type AwsDataSource#type}
        */
        readonly type: string;
        /**
        * confluence_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_data_source#confluence_configuration AwsDataSource#confluence_configuration}
        */
        readonly confluenceConfiguration?: ConfluenceConfigurationProperty[] | cdktn.IResolvable;
        /**
        * managed_knowledge_base_connector_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_data_source#managed_knowledge_base_connector_configuration AwsDataSource#managed_knowledge_base_connector_configuration}
        */
        readonly managedKnowledgeBaseConnectorConfiguration?: ManagedKnowledgeBaseConnectorConfigurationProperty[] | cdktn.IResolvable;
        /**
        * s3_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_data_source#s3_configuration AwsDataSource#s3_configuration}
        */
        readonly s3Configuration?: S3ConfigurationProperty[] | cdktn.IResolvable;
        /**
        * salesforce_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_data_source#salesforce_configuration AwsDataSource#salesforce_configuration}
        */
        readonly salesforceConfiguration?: SalesforceConfigurationProperty[] | cdktn.IResolvable;
        /**
        * share_point_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_data_source#share_point_configuration AwsDataSource#share_point_configuration}
        */
        readonly sharePointConfiguration?: SharePointConfigurationProperty[] | cdktn.IResolvable;
        /**
        * web_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_data_source#web_configuration AwsDataSource#web_configuration}
        */
        readonly webConfiguration?: WebConfigurationProperty[] | cdktn.IResolvable;
    }
    class DataSourceConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DataSourceConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DataSourceConfigurationProperty | cdktn.IResolvable | undefined);
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
        private _confluenceConfiguration;
        get confluenceConfiguration(): ConfluenceConfigurationPropertyList;
        putConfluenceConfiguration(value: ConfluenceConfigurationProperty[] | cdktn.IResolvable): void;
        resetConfluenceConfiguration(): void;
        get confluenceConfigurationInput(): cdktn.IResolvable | ConfluenceConfigurationProperty[] | undefined;
        private _managedKnowledgeBaseConnectorConfiguration;
        get managedKnowledgeBaseConnectorConfiguration(): ManagedKnowledgeBaseConnectorConfigurationPropertyList;
        putManagedKnowledgeBaseConnectorConfiguration(value: ManagedKnowledgeBaseConnectorConfigurationProperty[] | cdktn.IResolvable): void;
        resetManagedKnowledgeBaseConnectorConfiguration(): void;
        get managedKnowledgeBaseConnectorConfigurationInput(): cdktn.IResolvable | ManagedKnowledgeBaseConnectorConfigurationProperty[] | undefined;
        private _s3Configuration;
        get s3Configuration(): S3ConfigurationPropertyList;
        putS3Configuration(value: S3ConfigurationProperty[] | cdktn.IResolvable): void;
        resetS3Configuration(): void;
        get s3ConfigurationInput(): cdktn.IResolvable | S3ConfigurationProperty[] | undefined;
        private _salesforceConfiguration;
        get salesforceConfiguration(): SalesforceConfigurationPropertyList;
        putSalesforceConfiguration(value: SalesforceConfigurationProperty[] | cdktn.IResolvable): void;
        resetSalesforceConfiguration(): void;
        get salesforceConfigurationInput(): cdktn.IResolvable | SalesforceConfigurationProperty[] | undefined;
        private _sharePointConfiguration;
        get sharePointConfiguration(): SharePointConfigurationPropertyList;
        putSharePointConfiguration(value: SharePointConfigurationProperty[] | cdktn.IResolvable): void;
        resetSharePointConfiguration(): void;
        get sharePointConfigurationInput(): cdktn.IResolvable | SharePointConfigurationProperty[] | undefined;
        private _webConfiguration;
        get webConfiguration(): WebConfigurationPropertyList;
        putWebConfiguration(value: WebConfigurationProperty[] | cdktn.IResolvable): void;
        resetWebConfiguration(): void;
        get webConfigurationInput(): cdktn.IResolvable | WebConfigurationProperty[] | undefined;
    }
    class DataSourceConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: DataSourceConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DataSourceConfigurationPropertyOutputReference;
    }
    interface ServerSideEncryptionConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_data_source#kms_key_arn AwsDataSource#kms_key_arn}
        */
        readonly kmsKeyArn?: string;
    }
    class ServerSideEncryptionConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ServerSideEncryptionConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ServerSideEncryptionConfigurationProperty | cdktn.IResolvable | undefined);
        private _kmsKeyArn?;
        get kmsKeyArn(): string;
        set kmsKeyArn(value: string);
        resetKmsKeyArn(): void;
        get kmsKeyArnInput(): string | undefined;
    }
    class ServerSideEncryptionConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: ServerSideEncryptionConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ServerSideEncryptionConfigurationPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_data_source#create AwsDataSource#create}
        */
        readonly create?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Setting a timeout for a Delete operation is only applicable if changes are saved into state before the destroy operation occurs.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_data_source#delete AwsDataSource#delete}
        */
        readonly delete?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_data_source#update AwsDataSource#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
    interface FixedSizeChunkingConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_data_source#max_tokens AwsDataSource#max_tokens}
        */
        readonly maxTokens: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_data_source#overlap_percentage AwsDataSource#overlap_percentage}
        */
        readonly overlapPercentage: number;
    }
    class FixedSizeChunkingConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): FixedSizeChunkingConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: FixedSizeChunkingConfigurationProperty | cdktn.IResolvable | undefined);
        private _maxTokens?;
        get maxTokens(): number;
        set maxTokens(value: number);
        get maxTokensInput(): number | undefined;
        private _overlapPercentage?;
        get overlapPercentage(): number;
        set overlapPercentage(value: number);
        get overlapPercentageInput(): number | undefined;
    }
    class FixedSizeChunkingConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: FixedSizeChunkingConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): FixedSizeChunkingConfigurationPropertyOutputReference;
    }
    interface LevelConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_data_source#max_tokens AwsDataSource#max_tokens}
        */
        readonly maxTokens: number;
    }
    class LevelConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): LevelConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: LevelConfigurationProperty | cdktn.IResolvable | undefined);
        private _maxTokens?;
        get maxTokens(): number;
        set maxTokens(value: number);
        get maxTokensInput(): number | undefined;
    }
    class LevelConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: LevelConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): LevelConfigurationPropertyOutputReference;
    }
    interface HierarchicalChunkingConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_data_source#overlap_tokens AwsDataSource#overlap_tokens}
        */
        readonly overlapTokens: number;
        /**
        * level_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_data_source#level_configuration AwsDataSource#level_configuration}
        */
        readonly levelConfiguration?: LevelConfigurationProperty[] | cdktn.IResolvable;
    }
    class HierarchicalChunkingConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): HierarchicalChunkingConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: HierarchicalChunkingConfigurationProperty | cdktn.IResolvable | undefined);
        private _overlapTokens?;
        get overlapTokens(): number;
        set overlapTokens(value: number);
        get overlapTokensInput(): number | undefined;
        private _levelConfiguration;
        get levelConfiguration(): LevelConfigurationPropertyList;
        putLevelConfiguration(value: LevelConfigurationProperty[] | cdktn.IResolvable): void;
        resetLevelConfiguration(): void;
        get levelConfigurationInput(): cdktn.IResolvable | LevelConfigurationProperty[] | undefined;
    }
    class HierarchicalChunkingConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: HierarchicalChunkingConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): HierarchicalChunkingConfigurationPropertyOutputReference;
    }
    interface SemanticChunkingConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_data_source#breakpoint_percentile_threshold AwsDataSource#breakpoint_percentile_threshold}
        */
        readonly breakpointPercentileThreshold: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_data_source#buffer_size AwsDataSource#buffer_size}
        */
        readonly bufferSize: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_data_source#max_token AwsDataSource#max_token}
        */
        readonly maxToken: number;
    }
    class SemanticChunkingConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SemanticChunkingConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SemanticChunkingConfigurationProperty | cdktn.IResolvable | undefined);
        private _breakpointPercentileThreshold?;
        get breakpointPercentileThreshold(): number;
        set breakpointPercentileThreshold(value: number);
        get breakpointPercentileThresholdInput(): number | undefined;
        private _bufferSize?;
        get bufferSize(): number;
        set bufferSize(value: number);
        get bufferSizeInput(): number | undefined;
        private _maxToken?;
        get maxToken(): number;
        set maxToken(value: number);
        get maxTokenInput(): number | undefined;
    }
    class SemanticChunkingConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: SemanticChunkingConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SemanticChunkingConfigurationPropertyOutputReference;
    }
    interface ChunkingConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_data_source#chunking_strategy AwsDataSource#chunking_strategy}
        */
        readonly chunkingStrategy: string;
        /**
        * fixed_size_chunking_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_data_source#fixed_size_chunking_configuration AwsDataSource#fixed_size_chunking_configuration}
        */
        readonly fixedSizeChunkingConfiguration?: FixedSizeChunkingConfigurationProperty[] | cdktn.IResolvable;
        /**
        * hierarchical_chunking_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_data_source#hierarchical_chunking_configuration AwsDataSource#hierarchical_chunking_configuration}
        */
        readonly hierarchicalChunkingConfiguration?: HierarchicalChunkingConfigurationProperty[] | cdktn.IResolvable;
        /**
        * semantic_chunking_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_data_source#semantic_chunking_configuration AwsDataSource#semantic_chunking_configuration}
        */
        readonly semanticChunkingConfiguration?: SemanticChunkingConfigurationProperty[] | cdktn.IResolvable;
    }
    class ChunkingConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ChunkingConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ChunkingConfigurationProperty | cdktn.IResolvable | undefined);
        private _chunkingStrategy?;
        get chunkingStrategy(): string;
        set chunkingStrategy(value: string);
        get chunkingStrategyInput(): string | undefined;
        private _fixedSizeChunkingConfiguration;
        get fixedSizeChunkingConfiguration(): FixedSizeChunkingConfigurationPropertyList;
        putFixedSizeChunkingConfiguration(value: FixedSizeChunkingConfigurationProperty[] | cdktn.IResolvable): void;
        resetFixedSizeChunkingConfiguration(): void;
        get fixedSizeChunkingConfigurationInput(): cdktn.IResolvable | FixedSizeChunkingConfigurationProperty[] | undefined;
        private _hierarchicalChunkingConfiguration;
        get hierarchicalChunkingConfiguration(): HierarchicalChunkingConfigurationPropertyList;
        putHierarchicalChunkingConfiguration(value: HierarchicalChunkingConfigurationProperty[] | cdktn.IResolvable): void;
        resetHierarchicalChunkingConfiguration(): void;
        get hierarchicalChunkingConfigurationInput(): cdktn.IResolvable | HierarchicalChunkingConfigurationProperty[] | undefined;
        private _semanticChunkingConfiguration;
        get semanticChunkingConfiguration(): SemanticChunkingConfigurationPropertyList;
        putSemanticChunkingConfiguration(value: SemanticChunkingConfigurationProperty[] | cdktn.IResolvable): void;
        resetSemanticChunkingConfiguration(): void;
        get semanticChunkingConfigurationInput(): cdktn.IResolvable | SemanticChunkingConfigurationProperty[] | undefined;
    }
    class ChunkingConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: ChunkingConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ChunkingConfigurationPropertyOutputReference;
    }
    interface S3LocationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_data_source#uri AwsDataSource#uri}
        */
        readonly uri: string;
    }
    class S3LocationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): S3LocationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: S3LocationProperty | cdktn.IResolvable | undefined);
        private _uri?;
        get uri(): string;
        set uri(value: string);
        get uriInput(): string | undefined;
    }
    class S3LocationPropertyList extends cdktn.ComplexList {
        internalValue?: S3LocationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): S3LocationPropertyOutputReference;
    }
    interface IntermediateStorageProperty {
        /**
        * s3_location block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_data_source#s3_location AwsDataSource#s3_location}
        */
        readonly s3Location?: S3LocationProperty[] | cdktn.IResolvable;
    }
    class IntermediateStoragePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): IntermediateStorageProperty | cdktn.IResolvable | undefined;
        set internalValue(value: IntermediateStorageProperty | cdktn.IResolvable | undefined);
        private _s3Location;
        get s3Location(): S3LocationPropertyList;
        putS3Location(value: S3LocationProperty[] | cdktn.IResolvable): void;
        resetS3Location(): void;
        get s3LocationInput(): cdktn.IResolvable | S3LocationProperty[] | undefined;
    }
    class IntermediateStoragePropertyList extends cdktn.ComplexList {
        internalValue?: IntermediateStorageProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): IntermediateStoragePropertyOutputReference;
    }
    interface TransformationLambdaConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_data_source#lambda_arn AwsDataSource#lambda_arn}
        */
        readonly lambdaArn: string;
    }
    class TransformationLambdaConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TransformationLambdaConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TransformationLambdaConfigurationProperty | cdktn.IResolvable | undefined);
        private _lambdaArn?;
        get lambdaArn(): string;
        set lambdaArn(value: string);
        get lambdaArnInput(): string | undefined;
    }
    class TransformationLambdaConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: TransformationLambdaConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TransformationLambdaConfigurationPropertyOutputReference;
    }
    interface TransformationFunctionProperty {
        /**
        * transformation_lambda_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_data_source#transformation_lambda_configuration AwsDataSource#transformation_lambda_configuration}
        */
        readonly transformationLambdaConfiguration?: TransformationLambdaConfigurationProperty[] | cdktn.IResolvable;
    }
    class TransformationFunctionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TransformationFunctionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TransformationFunctionProperty | cdktn.IResolvable | undefined);
        private _transformationLambdaConfiguration;
        get transformationLambdaConfiguration(): TransformationLambdaConfigurationPropertyList;
        putTransformationLambdaConfiguration(value: TransformationLambdaConfigurationProperty[] | cdktn.IResolvable): void;
        resetTransformationLambdaConfiguration(): void;
        get transformationLambdaConfigurationInput(): cdktn.IResolvable | TransformationLambdaConfigurationProperty[] | undefined;
    }
    class TransformationFunctionPropertyList extends cdktn.ComplexList {
        internalValue?: TransformationFunctionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TransformationFunctionPropertyOutputReference;
    }
    interface TransformationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_data_source#step_to_apply AwsDataSource#step_to_apply}
        */
        readonly stepToApply: string;
        /**
        * transformation_function block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_data_source#transformation_function AwsDataSource#transformation_function}
        */
        readonly transformationFunction?: TransformationFunctionProperty[] | cdktn.IResolvable;
    }
    class TransformationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TransformationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TransformationProperty | cdktn.IResolvable | undefined);
        private _stepToApply?;
        get stepToApply(): string;
        set stepToApply(value: string);
        get stepToApplyInput(): string | undefined;
        private _transformationFunction;
        get transformationFunction(): TransformationFunctionPropertyList;
        putTransformationFunction(value: TransformationFunctionProperty[] | cdktn.IResolvable): void;
        resetTransformationFunction(): void;
        get transformationFunctionInput(): cdktn.IResolvable | TransformationFunctionProperty[] | undefined;
    }
    class TransformationPropertyList extends cdktn.ComplexList {
        internalValue?: TransformationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TransformationPropertyOutputReference;
    }
    interface CustomTransformationConfigurationProperty {
        /**
        * intermediate_storage block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_data_source#intermediate_storage AwsDataSource#intermediate_storage}
        */
        readonly intermediateStorage?: IntermediateStorageProperty[] | cdktn.IResolvable;
        /**
        * transformation block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_data_source#transformation AwsDataSource#transformation}
        */
        readonly transformation?: TransformationProperty[] | cdktn.IResolvable;
    }
    class CustomTransformationConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CustomTransformationConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CustomTransformationConfigurationProperty | cdktn.IResolvable | undefined);
        private _intermediateStorage;
        get intermediateStorage(): IntermediateStoragePropertyList;
        putIntermediateStorage(value: IntermediateStorageProperty[] | cdktn.IResolvable): void;
        resetIntermediateStorage(): void;
        get intermediateStorageInput(): cdktn.IResolvable | IntermediateStorageProperty[] | undefined;
        private _transformation;
        get transformation(): TransformationPropertyList;
        putTransformation(value: TransformationProperty[] | cdktn.IResolvable): void;
        resetTransformation(): void;
        get transformationInput(): cdktn.IResolvable | TransformationProperty[] | undefined;
    }
    class CustomTransformationConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: CustomTransformationConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CustomTransformationConfigurationPropertyOutputReference;
    }
    interface BedrockDataAutomationConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_data_source#parsing_modality AwsDataSource#parsing_modality}
        */
        readonly parsingModality?: string;
    }
    class BedrockDataAutomationConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): BedrockDataAutomationConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: BedrockDataAutomationConfigurationProperty | cdktn.IResolvable | undefined);
        private _parsingModality?;
        get parsingModality(): string;
        set parsingModality(value: string);
        resetParsingModality(): void;
        get parsingModalityInput(): string | undefined;
    }
    class BedrockDataAutomationConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: BedrockDataAutomationConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): BedrockDataAutomationConfigurationPropertyOutputReference;
    }
    interface ParsingPromptProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_data_source#parsing_prompt_string AwsDataSource#parsing_prompt_string}
        */
        readonly parsingPromptString: string;
    }
    class ParsingPromptPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ParsingPromptProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ParsingPromptProperty | cdktn.IResolvable | undefined);
        private _parsingPromptString?;
        get parsingPromptString(): string;
        set parsingPromptString(value: string);
        get parsingPromptStringInput(): string | undefined;
    }
    class ParsingPromptPropertyList extends cdktn.ComplexList {
        internalValue?: ParsingPromptProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ParsingPromptPropertyOutputReference;
    }
    interface BedrockFoundationModelConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_data_source#model_arn AwsDataSource#model_arn}
        */
        readonly modelArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_data_source#parsing_modality AwsDataSource#parsing_modality}
        */
        readonly parsingModality?: string;
        /**
        * parsing_prompt block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_data_source#parsing_prompt AwsDataSource#parsing_prompt}
        */
        readonly parsingPrompt?: ParsingPromptProperty[] | cdktn.IResolvable;
    }
    class BedrockFoundationModelConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): BedrockFoundationModelConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: BedrockFoundationModelConfigurationProperty | cdktn.IResolvable | undefined);
        private _modelArn?;
        get modelArn(): string;
        set modelArn(value: string);
        get modelArnInput(): string | undefined;
        private _parsingModality?;
        get parsingModality(): string;
        set parsingModality(value: string);
        resetParsingModality(): void;
        get parsingModalityInput(): string | undefined;
        private _parsingPrompt;
        get parsingPrompt(): ParsingPromptPropertyList;
        putParsingPrompt(value: ParsingPromptProperty[] | cdktn.IResolvable): void;
        resetParsingPrompt(): void;
        get parsingPromptInput(): cdktn.IResolvable | ParsingPromptProperty[] | undefined;
    }
    class BedrockFoundationModelConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: BedrockFoundationModelConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): BedrockFoundationModelConfigurationPropertyOutputReference;
    }
    interface ParsingConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_data_source#parsing_strategy AwsDataSource#parsing_strategy}
        */
        readonly parsingStrategy: string;
        /**
        * bedrock_data_automation_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_data_source#bedrock_data_automation_configuration AwsDataSource#bedrock_data_automation_configuration}
        */
        readonly bedrockDataAutomationConfiguration?: BedrockDataAutomationConfigurationProperty[] | cdktn.IResolvable;
        /**
        * bedrock_foundation_model_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_data_source#bedrock_foundation_model_configuration AwsDataSource#bedrock_foundation_model_configuration}
        */
        readonly bedrockFoundationModelConfiguration?: BedrockFoundationModelConfigurationProperty[] | cdktn.IResolvable;
    }
    class ParsingConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ParsingConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ParsingConfigurationProperty | cdktn.IResolvable | undefined);
        private _parsingStrategy?;
        get parsingStrategy(): string;
        set parsingStrategy(value: string);
        get parsingStrategyInput(): string | undefined;
        private _bedrockDataAutomationConfiguration;
        get bedrockDataAutomationConfiguration(): BedrockDataAutomationConfigurationPropertyList;
        putBedrockDataAutomationConfiguration(value: BedrockDataAutomationConfigurationProperty[] | cdktn.IResolvable): void;
        resetBedrockDataAutomationConfiguration(): void;
        get bedrockDataAutomationConfigurationInput(): cdktn.IResolvable | BedrockDataAutomationConfigurationProperty[] | undefined;
        private _bedrockFoundationModelConfiguration;
        get bedrockFoundationModelConfiguration(): BedrockFoundationModelConfigurationPropertyList;
        putBedrockFoundationModelConfiguration(value: BedrockFoundationModelConfigurationProperty[] | cdktn.IResolvable): void;
        resetBedrockFoundationModelConfiguration(): void;
        get bedrockFoundationModelConfigurationInput(): cdktn.IResolvable | BedrockFoundationModelConfigurationProperty[] | undefined;
    }
    class ParsingConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: ParsingConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ParsingConfigurationPropertyOutputReference;
    }
    interface VectorIngestionConfigurationProperty {
        /**
        * chunking_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_data_source#chunking_configuration AwsDataSource#chunking_configuration}
        */
        readonly chunkingConfiguration?: ChunkingConfigurationProperty[] | cdktn.IResolvable;
        /**
        * custom_transformation_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_data_source#custom_transformation_configuration AwsDataSource#custom_transformation_configuration}
        */
        readonly customTransformationConfiguration?: CustomTransformationConfigurationProperty[] | cdktn.IResolvable;
        /**
        * parsing_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_data_source#parsing_configuration AwsDataSource#parsing_configuration}
        */
        readonly parsingConfiguration?: ParsingConfigurationProperty[] | cdktn.IResolvable;
    }
    class VectorIngestionConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): VectorIngestionConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: VectorIngestionConfigurationProperty | cdktn.IResolvable | undefined);
        private _chunkingConfiguration;
        get chunkingConfiguration(): ChunkingConfigurationPropertyList;
        putChunkingConfiguration(value: ChunkingConfigurationProperty[] | cdktn.IResolvable): void;
        resetChunkingConfiguration(): void;
        get chunkingConfigurationInput(): cdktn.IResolvable | ChunkingConfigurationProperty[] | undefined;
        private _customTransformationConfiguration;
        get customTransformationConfiguration(): CustomTransformationConfigurationPropertyList;
        putCustomTransformationConfiguration(value: CustomTransformationConfigurationProperty[] | cdktn.IResolvable): void;
        resetCustomTransformationConfiguration(): void;
        get customTransformationConfigurationInput(): cdktn.IResolvable | CustomTransformationConfigurationProperty[] | undefined;
        private _parsingConfiguration;
        get parsingConfiguration(): ParsingConfigurationPropertyList;
        putParsingConfiguration(value: ParsingConfigurationProperty[] | cdktn.IResolvable): void;
        resetParsingConfiguration(): void;
        get parsingConfigurationInput(): cdktn.IResolvable | ParsingConfigurationProperty[] | undefined;
    }
    class VectorIngestionConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: VectorIngestionConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): VectorIngestionConfigurationPropertyOutputReference;
    }
}
