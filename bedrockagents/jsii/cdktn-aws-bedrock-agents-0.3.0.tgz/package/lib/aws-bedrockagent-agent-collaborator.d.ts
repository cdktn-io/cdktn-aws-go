import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsAgentCollaboratorConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_agent_collaborator#agent_id AwsAgentCollaborator#agent_id}
    */
    readonly agentId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_agent_collaborator#agent_version AwsAgentCollaborator#agent_version}
    */
    readonly agentVersion?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_agent_collaborator#collaboration_instruction AwsAgentCollaborator#collaboration_instruction}
    */
    readonly collaborationInstruction: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_agent_collaborator#collaborator_name AwsAgentCollaborator#collaborator_name}
    */
    readonly collaboratorName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_agent_collaborator#prepare_agent AwsAgentCollaborator#prepare_agent}
    */
    readonly prepareAgent?: boolean | cdktn.IResolvable;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_agent_collaborator#region AwsAgentCollaborator#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_agent_collaborator#relay_conversation_history AwsAgentCollaborator#relay_conversation_history}
    */
    readonly relayConversationHistory?: string;
    /**
    * agent_descriptor block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_agent_collaborator#agent_descriptor AwsAgentCollaborator#agent_descriptor}
    */
    readonly agentDescriptor?: AwsAgentCollaborator.AgentDescriptorProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_agent_collaborator#timeouts AwsAgentCollaborator#timeouts}
    */
    readonly timeouts?: AwsAgentCollaborator.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_agent_collaborator aws_bedrockagent_agent_collaborator}
*/
export declare class AwsAgentCollaborator extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_bedrockagent_agent_collaborator";
    /**
    * Generates CDKTN code for importing a AwsAgentCollaborator resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsAgentCollaborator to import
    * @param importFromId The id of the existing AwsAgentCollaborator that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_agent_collaborator#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsAgentCollaborator to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_agent_collaborator aws_bedrockagent_agent_collaborator} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsAgentCollaboratorConfig
    */
    constructor(scope: Construct, id: string, config: AwsAgentCollaboratorConfig);
    private _agentId?;
    get agentId(): string;
    set agentId(value: string);
    get agentIdInput(): string | undefined;
    private _agentVersion?;
    get agentVersion(): string;
    set agentVersion(value: string);
    resetAgentVersion(): void;
    get agentVersionInput(): string | undefined;
    private _collaborationInstruction?;
    get collaborationInstruction(): string;
    set collaborationInstruction(value: string);
    get collaborationInstructionInput(): string | undefined;
    get collaboratorId(): string;
    private _collaboratorName?;
    get collaboratorName(): string;
    set collaboratorName(value: string);
    get collaboratorNameInput(): string | undefined;
    get id(): string;
    private _prepareAgent?;
    get prepareAgent(): boolean | cdktn.IResolvable;
    set prepareAgent(value: boolean | cdktn.IResolvable);
    resetPrepareAgent(): void;
    get prepareAgentInput(): boolean | cdktn.IResolvable | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _relayConversationHistory?;
    get relayConversationHistory(): string;
    set relayConversationHistory(value: string);
    resetRelayConversationHistory(): void;
    get relayConversationHistoryInput(): string | undefined;
    private _agentDescriptor;
    get agentDescriptor(): AwsAgentCollaborator.AgentDescriptorPropertyList;
    putAgentDescriptor(value: AwsAgentCollaborator.AgentDescriptorProperty[] | cdktn.IResolvable): void;
    resetAgentDescriptor(): void;
    get agentDescriptorInput(): cdktn.IResolvable | AwsAgentCollaborator.AgentDescriptorProperty[] | undefined;
    private _timeouts;
    get timeouts(): AwsAgentCollaborator.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsAgentCollaborator.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsAgentCollaborator.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsAgentCollaboratorAgentDescriptorPropertyToTerraform(struct?: AwsAgentCollaborator.AgentDescriptorProperty | cdktn.IResolvable): any;
export declare function awsAgentCollaboratorAgentDescriptorPropertyToHclTerraform(struct?: AwsAgentCollaborator.AgentDescriptorProperty | cdktn.IResolvable): any;
export declare function awsAgentCollaboratorTimeoutsPropertyToTerraform(struct?: AwsAgentCollaborator.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsAgentCollaboratorTimeoutsPropertyToHclTerraform(struct?: AwsAgentCollaborator.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsAgentCollaborator {
    interface AgentDescriptorProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_agent_collaborator#alias_arn AwsAgentCollaborator#alias_arn}
        */
        readonly aliasArn: string;
    }
    class AgentDescriptorPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AgentDescriptorProperty | cdktn.IResolvable | undefined;
        set internalValue(value: AgentDescriptorProperty | cdktn.IResolvable | undefined);
        private _aliasArn?;
        get aliasArn(): string;
        set aliasArn(value: string);
        get aliasArnInput(): string | undefined;
    }
    class AgentDescriptorPropertyList extends cdktn.ComplexList {
        internalValue?: AgentDescriptorProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AgentDescriptorPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_agent_collaborator#create AwsAgentCollaborator#create}
        */
        readonly create?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Setting a timeout for a Delete operation is only applicable if changes are saved into state before the destroy operation occurs.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_agent_collaborator#delete AwsAgentCollaborator#delete}
        */
        readonly delete?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_agent_collaborator#update AwsAgentCollaborator#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
