import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsAgentActionGroupConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_agent_action_group#action_group_name AwsAgentActionGroup#action_group_name}
    */
    readonly actionGroupName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_agent_action_group#action_group_state AwsAgentActionGroup#action_group_state}
    */
    readonly actionGroupState?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_agent_action_group#agent_id AwsAgentActionGroup#agent_id}
    */
    readonly agentId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_agent_action_group#agent_version AwsAgentActionGroup#agent_version}
    */
    readonly agentVersion: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_agent_action_group#description AwsAgentActionGroup#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_agent_action_group#parent_action_group_signature AwsAgentActionGroup#parent_action_group_signature}
    */
    readonly parentActionGroupSignature?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_agent_action_group#prepare_agent AwsAgentActionGroup#prepare_agent}
    */
    readonly prepareAgent?: boolean | cdktn.IResolvable;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_agent_action_group#region AwsAgentActionGroup#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_agent_action_group#skip_resource_in_use_check AwsAgentActionGroup#skip_resource_in_use_check}
    */
    readonly skipResourceInUseCheck?: boolean | cdktn.IResolvable;
    /**
    * action_group_executor block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_agent_action_group#action_group_executor AwsAgentActionGroup#action_group_executor}
    */
    readonly actionGroupExecutor?: AwsAgentActionGroup.ActionGroupExecutorProperty[] | cdktn.IResolvable;
    /**
    * api_schema block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_agent_action_group#api_schema AwsAgentActionGroup#api_schema}
    */
    readonly apiSchema?: AwsAgentActionGroup.ApiSchemaProperty[] | cdktn.IResolvable;
    /**
    * function_schema block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_agent_action_group#function_schema AwsAgentActionGroup#function_schema}
    */
    readonly functionSchema?: AwsAgentActionGroup.FunctionSchemaProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_agent_action_group#timeouts AwsAgentActionGroup#timeouts}
    */
    readonly timeouts?: AwsAgentActionGroup.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_agent_action_group aws_bedrockagent_agent_action_group}
*/
export declare class AwsAgentActionGroup extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_bedrockagent_agent_action_group";
    /**
    * Generates CDKTN code for importing a AwsAgentActionGroup resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsAgentActionGroup to import
    * @param importFromId The id of the existing AwsAgentActionGroup that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_agent_action_group#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsAgentActionGroup to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_agent_action_group aws_bedrockagent_agent_action_group} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsAgentActionGroupConfig
    */
    constructor(scope: Construct, id: string, config: AwsAgentActionGroupConfig);
    get actionGroupId(): string;
    private _actionGroupName?;
    get actionGroupName(): string;
    set actionGroupName(value: string);
    get actionGroupNameInput(): string | undefined;
    private _actionGroupState?;
    get actionGroupState(): string;
    set actionGroupState(value: string);
    resetActionGroupState(): void;
    get actionGroupStateInput(): string | undefined;
    private _agentId?;
    get agentId(): string;
    set agentId(value: string);
    get agentIdInput(): string | undefined;
    private _agentVersion?;
    get agentVersion(): string;
    set agentVersion(value: string);
    get agentVersionInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get id(): string;
    private _parentActionGroupSignature?;
    get parentActionGroupSignature(): string;
    set parentActionGroupSignature(value: string);
    resetParentActionGroupSignature(): void;
    get parentActionGroupSignatureInput(): string | undefined;
    private _prepareAgent?;
    get prepareAgent(): boolean | cdktn.IResolvable;
    set prepareAgent(value: boolean | cdktn.IResolvable);
    resetPrepareAgent(): void;
    get prepareAgentInput(): boolean | cdktn.IResolvable | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _skipResourceInUseCheck?;
    get skipResourceInUseCheck(): boolean | cdktn.IResolvable;
    set skipResourceInUseCheck(value: boolean | cdktn.IResolvable);
    resetSkipResourceInUseCheck(): void;
    get skipResourceInUseCheckInput(): boolean | cdktn.IResolvable | undefined;
    private _actionGroupExecutor;
    get actionGroupExecutor(): AwsAgentActionGroup.ActionGroupExecutorPropertyList;
    putActionGroupExecutor(value: AwsAgentActionGroup.ActionGroupExecutorProperty[] | cdktn.IResolvable): void;
    resetActionGroupExecutor(): void;
    get actionGroupExecutorInput(): cdktn.IResolvable | AwsAgentActionGroup.ActionGroupExecutorProperty[] | undefined;
    private _apiSchema;
    get apiSchema(): AwsAgentActionGroup.ApiSchemaPropertyList;
    putApiSchema(value: AwsAgentActionGroup.ApiSchemaProperty[] | cdktn.IResolvable): void;
    resetApiSchema(): void;
    get apiSchemaInput(): cdktn.IResolvable | AwsAgentActionGroup.ApiSchemaProperty[] | undefined;
    private _functionSchema;
    get functionSchema(): AwsAgentActionGroup.FunctionSchemaPropertyList;
    putFunctionSchema(value: AwsAgentActionGroup.FunctionSchemaProperty[] | cdktn.IResolvable): void;
    resetFunctionSchema(): void;
    get functionSchemaInput(): cdktn.IResolvable | AwsAgentActionGroup.FunctionSchemaProperty[] | undefined;
    private _timeouts;
    get timeouts(): AwsAgentActionGroup.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsAgentActionGroup.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsAgentActionGroup.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsAgentActionGroupActionGroupExecutorPropertyToTerraform(struct?: AwsAgentActionGroup.ActionGroupExecutorProperty | cdktn.IResolvable): any;
export declare function awsAgentActionGroupActionGroupExecutorPropertyToHclTerraform(struct?: AwsAgentActionGroup.ActionGroupExecutorProperty | cdktn.IResolvable): any;
export declare function awsAgentActionGroupS3PropertyToTerraform(struct?: AwsAgentActionGroup.S3Property | cdktn.IResolvable): any;
export declare function awsAgentActionGroupS3PropertyToHclTerraform(struct?: AwsAgentActionGroup.S3Property | cdktn.IResolvable): any;
export declare function awsAgentActionGroupApiSchemaPropertyToTerraform(struct?: AwsAgentActionGroup.ApiSchemaProperty | cdktn.IResolvable): any;
export declare function awsAgentActionGroupApiSchemaPropertyToHclTerraform(struct?: AwsAgentActionGroup.ApiSchemaProperty | cdktn.IResolvable): any;
export declare function awsAgentActionGroupParametersPropertyToTerraform(struct?: AwsAgentActionGroup.ParametersProperty | cdktn.IResolvable): any;
export declare function awsAgentActionGroupParametersPropertyToHclTerraform(struct?: AwsAgentActionGroup.ParametersProperty | cdktn.IResolvable): any;
export declare function awsAgentActionGroupFunctionsPropertyToTerraform(struct?: AwsAgentActionGroup.FunctionsProperty | cdktn.IResolvable): any;
export declare function awsAgentActionGroupFunctionsPropertyToHclTerraform(struct?: AwsAgentActionGroup.FunctionsProperty | cdktn.IResolvable): any;
export declare function awsAgentActionGroupMemberFunctionsPropertyToTerraform(struct?: AwsAgentActionGroup.MemberFunctionsProperty | cdktn.IResolvable): any;
export declare function awsAgentActionGroupMemberFunctionsPropertyToHclTerraform(struct?: AwsAgentActionGroup.MemberFunctionsProperty | cdktn.IResolvable): any;
export declare function awsAgentActionGroupFunctionSchemaPropertyToTerraform(struct?: AwsAgentActionGroup.FunctionSchemaProperty | cdktn.IResolvable): any;
export declare function awsAgentActionGroupFunctionSchemaPropertyToHclTerraform(struct?: AwsAgentActionGroup.FunctionSchemaProperty | cdktn.IResolvable): any;
export declare function awsAgentActionGroupTimeoutsPropertyToTerraform(struct?: AwsAgentActionGroup.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsAgentActionGroupTimeoutsPropertyToHclTerraform(struct?: AwsAgentActionGroup.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsAgentActionGroup {
    interface ActionGroupExecutorProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_agent_action_group#custom_control AwsAgentActionGroup#custom_control}
        */
        readonly customControl?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_agent_action_group#lambda AwsAgentActionGroup#lambda}
        */
        readonly lambda?: string;
    }
    class ActionGroupExecutorPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ActionGroupExecutorProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ActionGroupExecutorProperty | cdktn.IResolvable | undefined);
        private _customControl?;
        get customControl(): string;
        set customControl(value: string);
        resetCustomControl(): void;
        get customControlInput(): string | undefined;
        private _lambda?;
        get lambda(): string;
        set lambda(value: string);
        resetLambda(): void;
        get lambdaInput(): string | undefined;
    }
    class ActionGroupExecutorPropertyList extends cdktn.ComplexList {
        internalValue?: ActionGroupExecutorProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ActionGroupExecutorPropertyOutputReference;
    }
    interface S3Property {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_agent_action_group#s3_bucket_name AwsAgentActionGroup#s3_bucket_name}
        */
        readonly s3BucketName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_agent_action_group#s3_object_key AwsAgentActionGroup#s3_object_key}
        */
        readonly s3ObjectKey?: string;
    }
    class S3PropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): S3Property | cdktn.IResolvable | undefined;
        set internalValue(value: S3Property | cdktn.IResolvable | undefined);
        private _s3BucketName?;
        get s3BucketName(): string;
        set s3BucketName(value: string);
        resetS3BucketName(): void;
        get s3BucketNameInput(): string | undefined;
        private _s3ObjectKey?;
        get s3ObjectKey(): string;
        set s3ObjectKey(value: string);
        resetS3ObjectKey(): void;
        get s3ObjectKeyInput(): string | undefined;
    }
    class S3PropertyList extends cdktn.ComplexList {
        internalValue?: S3Property[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): S3PropertyOutputReference;
    }
    interface ApiSchemaProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_agent_action_group#payload AwsAgentActionGroup#payload}
        */
        readonly payload?: string;
        /**
        * s3 block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_agent_action_group#s3 AwsAgentActionGroup#s3}
        */
        readonly s3?: S3Property[] | cdktn.IResolvable;
    }
    class ApiSchemaPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ApiSchemaProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ApiSchemaProperty | cdktn.IResolvable | undefined);
        private _payload?;
        get payload(): string;
        set payload(value: string);
        resetPayload(): void;
        get payloadInput(): string | undefined;
        private _s3;
        get s3(): S3PropertyList;
        putS3(value: S3Property[] | cdktn.IResolvable): void;
        resetS3(): void;
        get s3Input(): cdktn.IResolvable | S3Property[] | undefined;
    }
    class ApiSchemaPropertyList extends cdktn.ComplexList {
        internalValue?: ApiSchemaProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ApiSchemaPropertyOutputReference;
    }
    interface ParametersProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_agent_action_group#description AwsAgentActionGroup#description}
        */
        readonly description?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_agent_action_group#map_block_key AwsAgentActionGroup#map_block_key}
        */
        readonly mapBlockKey: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_agent_action_group#required AwsAgentActionGroup#required}
        */
        readonly required?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_agent_action_group#type AwsAgentActionGroup#type}
        */
        readonly type: string;
    }
    class ParametersPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ParametersProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ParametersProperty | cdktn.IResolvable | undefined);
        private _description?;
        get description(): string;
        set description(value: string);
        resetDescription(): void;
        get descriptionInput(): string | undefined;
        private _mapBlockKey?;
        get mapBlockKey(): string;
        set mapBlockKey(value: string);
        get mapBlockKeyInput(): string | undefined;
        private _required?;
        get required(): boolean | cdktn.IResolvable;
        set required(value: boolean | cdktn.IResolvable);
        resetRequired(): void;
        get requiredInput(): boolean | cdktn.IResolvable | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
    }
    class ParametersPropertyList extends cdktn.ComplexList {
        internalValue?: ParametersProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ParametersPropertyOutputReference;
    }
    interface FunctionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_agent_action_group#description AwsAgentActionGroup#description}
        */
        readonly description?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_agent_action_group#name AwsAgentActionGroup#name}
        */
        readonly name: string;
        /**
        * parameters block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_agent_action_group#parameters AwsAgentActionGroup#parameters}
        */
        readonly parameters?: ParametersProperty[] | cdktn.IResolvable;
    }
    class FunctionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): FunctionsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: FunctionsProperty | cdktn.IResolvable | undefined);
        private _description?;
        get description(): string;
        set description(value: string);
        resetDescription(): void;
        get descriptionInput(): string | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _parameters;
        get parameters(): ParametersPropertyList;
        putParameters(value: ParametersProperty[] | cdktn.IResolvable): void;
        resetParameters(): void;
        get parametersInput(): cdktn.IResolvable | ParametersProperty[] | undefined;
    }
    class FunctionsPropertyList extends cdktn.ComplexList {
        internalValue?: FunctionsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): FunctionsPropertyOutputReference;
    }
    interface MemberFunctionsProperty {
        /**
        * functions block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_agent_action_group#functions AwsAgentActionGroup#functions}
        */
        readonly functions?: FunctionsProperty[] | cdktn.IResolvable;
    }
    class MemberFunctionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): MemberFunctionsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: MemberFunctionsProperty | cdktn.IResolvable | undefined);
        private _functions;
        get functions(): FunctionsPropertyList;
        putFunctions(value: FunctionsProperty[] | cdktn.IResolvable): void;
        resetFunctions(): void;
        get functionsInput(): cdktn.IResolvable | FunctionsProperty[] | undefined;
    }
    class MemberFunctionsPropertyList extends cdktn.ComplexList {
        internalValue?: MemberFunctionsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): MemberFunctionsPropertyOutputReference;
    }
    interface FunctionSchemaProperty {
        /**
        * member_functions block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_agent_action_group#member_functions AwsAgentActionGroup#member_functions}
        */
        readonly memberFunctions?: MemberFunctionsProperty[] | cdktn.IResolvable;
    }
    class FunctionSchemaPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): FunctionSchemaProperty | cdktn.IResolvable | undefined;
        set internalValue(value: FunctionSchemaProperty | cdktn.IResolvable | undefined);
        private _memberFunctions;
        get memberFunctions(): MemberFunctionsPropertyList;
        putMemberFunctions(value: MemberFunctionsProperty[] | cdktn.IResolvable): void;
        resetMemberFunctions(): void;
        get memberFunctionsInput(): cdktn.IResolvable | MemberFunctionsProperty[] | undefined;
    }
    class FunctionSchemaPropertyList extends cdktn.ComplexList {
        internalValue?: FunctionSchemaProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): FunctionSchemaPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_agent_action_group#create AwsAgentActionGroup#create}
        */
        readonly create?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagent_agent_action_group#update AwsAgentActionGroup#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
