import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsCodepipelineConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#execution_mode AwsCodepipeline#execution_mode}
    */
    readonly executionMode?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#id AwsCodepipeline#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#name AwsCodepipeline#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#pipeline_type AwsCodepipeline#pipeline_type}
    */
    readonly pipelineType?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#region AwsCodepipeline#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#role_arn AwsCodepipeline#role_arn}
    */
    readonly roleArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#tags AwsCodepipeline#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#tags_all AwsCodepipeline#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * artifact_store block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#artifact_store AwsCodepipeline#artifact_store}
    */
    readonly artifactStore: AwsCodepipeline.ArtifactStoreProperty[] | cdktn.IResolvable;
    /**
    * stage block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#stage AwsCodepipeline#stage}
    */
    readonly stage: AwsCodepipeline.StageProperty[] | cdktn.IResolvable;
    /**
    * trigger block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#trigger AwsCodepipeline#trigger}
    */
    readonly trigger?: AwsCodepipeline.TriggerProperty[] | cdktn.IResolvable;
    /**
    * variable block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#variable AwsCodepipeline#variable}
    */
    readonly variable?: AwsCodepipeline.VariableProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline aws_codepipeline}
*/
export declare class AwsCodepipeline extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_codepipeline";
    /**
    * Generates CDKTN code for importing a AwsCodepipeline resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsCodepipeline to import
    * @param importFromId The id of the existing AwsCodepipeline that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsCodepipeline to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline aws_codepipeline} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsCodepipelineConfig
    */
    constructor(scope: Construct, id: string, config: AwsCodepipelineConfig);
    get arn(): string;
    private _executionMode?;
    get executionMode(): string;
    set executionMode(value: string);
    resetExecutionMode(): void;
    get executionModeInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _pipelineType?;
    get pipelineType(): string;
    set pipelineType(value: string);
    resetPipelineType(): void;
    get pipelineTypeInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _roleArn?;
    get roleArn(): string;
    set roleArn(value: string);
    get roleArnInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _triggerAll;
    get triggerAll(): AwsCodepipeline.TriggerAllPropertyList;
    private _artifactStore;
    get artifactStore(): AwsCodepipeline.ArtifactStorePropertyList;
    putArtifactStore(value: AwsCodepipeline.ArtifactStoreProperty[] | cdktn.IResolvable): void;
    get artifactStoreInput(): cdktn.IResolvable | AwsCodepipeline.ArtifactStoreProperty[] | undefined;
    private _stage;
    get stage(): AwsCodepipeline.StagePropertyList;
    putStage(value: AwsCodepipeline.StageProperty[] | cdktn.IResolvable): void;
    get stageInput(): cdktn.IResolvable | AwsCodepipeline.StageProperty[] | undefined;
    private _trigger;
    get trigger(): AwsCodepipeline.TriggerPropertyList;
    putTrigger(value: AwsCodepipeline.TriggerProperty[] | cdktn.IResolvable): void;
    resetTrigger(): void;
    get triggerInput(): cdktn.IResolvable | AwsCodepipeline.TriggerProperty[] | undefined;
    private _variable;
    get variable(): AwsCodepipeline.VariablePropertyList;
    putVariable(value: AwsCodepipeline.VariableProperty[] | cdktn.IResolvable): void;
    resetVariable(): void;
    get variableInput(): cdktn.IResolvable | AwsCodepipeline.VariableProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsCodepipelineTriggerAllGitConfigurationPullRequestBranchesPropertyToTerraform(struct?: AwsCodepipeline.TriggerAllGitConfigurationPullRequestBranchesProperty): any;
export declare function awsCodepipelineTriggerAllGitConfigurationPullRequestBranchesPropertyToHclTerraform(struct?: AwsCodepipeline.TriggerAllGitConfigurationPullRequestBranchesProperty): any;
export declare function awsCodepipelineTriggerAllGitConfigurationPullRequestFilePathsPropertyToTerraform(struct?: AwsCodepipeline.TriggerAllGitConfigurationPullRequestFilePathsProperty): any;
export declare function awsCodepipelineTriggerAllGitConfigurationPullRequestFilePathsPropertyToHclTerraform(struct?: AwsCodepipeline.TriggerAllGitConfigurationPullRequestFilePathsProperty): any;
export declare function awsCodepipelineTriggerAllGitConfigurationPullRequestPropertyToTerraform(struct?: AwsCodepipeline.TriggerAllGitConfigurationPullRequestProperty): any;
export declare function awsCodepipelineTriggerAllGitConfigurationPullRequestPropertyToHclTerraform(struct?: AwsCodepipeline.TriggerAllGitConfigurationPullRequestProperty): any;
export declare function awsCodepipelineTriggerAllGitConfigurationPushBranchesPropertyToTerraform(struct?: AwsCodepipeline.TriggerAllGitConfigurationPushBranchesProperty): any;
export declare function awsCodepipelineTriggerAllGitConfigurationPushBranchesPropertyToHclTerraform(struct?: AwsCodepipeline.TriggerAllGitConfigurationPushBranchesProperty): any;
export declare function awsCodepipelineTriggerAllGitConfigurationPushFilePathsPropertyToTerraform(struct?: AwsCodepipeline.TriggerAllGitConfigurationPushFilePathsProperty): any;
export declare function awsCodepipelineTriggerAllGitConfigurationPushFilePathsPropertyToHclTerraform(struct?: AwsCodepipeline.TriggerAllGitConfigurationPushFilePathsProperty): any;
export declare function awsCodepipelineTriggerAllGitConfigurationPushTagsPropertyToTerraform(struct?: AwsCodepipeline.TriggerAllGitConfigurationPushTagsProperty): any;
export declare function awsCodepipelineTriggerAllGitConfigurationPushTagsPropertyToHclTerraform(struct?: AwsCodepipeline.TriggerAllGitConfigurationPushTagsProperty): any;
export declare function awsCodepipelineTriggerAllGitConfigurationPushPropertyToTerraform(struct?: AwsCodepipeline.TriggerAllGitConfigurationPushProperty): any;
export declare function awsCodepipelineTriggerAllGitConfigurationPushPropertyToHclTerraform(struct?: AwsCodepipeline.TriggerAllGitConfigurationPushProperty): any;
export declare function awsCodepipelineTriggerAllGitConfigurationPropertyToTerraform(struct?: AwsCodepipeline.TriggerAllGitConfigurationProperty): any;
export declare function awsCodepipelineTriggerAllGitConfigurationPropertyToHclTerraform(struct?: AwsCodepipeline.TriggerAllGitConfigurationProperty): any;
export declare function awsCodepipelineTriggerAllPropertyToTerraform(struct?: AwsCodepipeline.TriggerAllProperty): any;
export declare function awsCodepipelineTriggerAllPropertyToHclTerraform(struct?: AwsCodepipeline.TriggerAllProperty): any;
export declare function awsCodepipelineEncryptionKeyPropertyToTerraform(struct?: AwsCodepipeline.EncryptionKeyPropertyOutputReference | AwsCodepipeline.EncryptionKeyProperty): any;
export declare function awsCodepipelineEncryptionKeyPropertyToHclTerraform(struct?: AwsCodepipeline.EncryptionKeyPropertyOutputReference | AwsCodepipeline.EncryptionKeyProperty): any;
export declare function awsCodepipelineArtifactStorePropertyToTerraform(struct?: AwsCodepipeline.ArtifactStoreProperty | cdktn.IResolvable): any;
export declare function awsCodepipelineArtifactStorePropertyToHclTerraform(struct?: AwsCodepipeline.ArtifactStoreProperty | cdktn.IResolvable): any;
export declare function awsCodepipelineOutputArtifactsForComputeActionPropertyToTerraform(struct?: AwsCodepipeline.OutputArtifactsForComputeActionProperty | cdktn.IResolvable): any;
export declare function awsCodepipelineOutputArtifactsForComputeActionPropertyToHclTerraform(struct?: AwsCodepipeline.OutputArtifactsForComputeActionProperty | cdktn.IResolvable): any;
export declare function awsCodepipelineActionPropertyToTerraform(struct?: AwsCodepipeline.ActionProperty | cdktn.IResolvable): any;
export declare function awsCodepipelineActionPropertyToHclTerraform(struct?: AwsCodepipeline.ActionProperty | cdktn.IResolvable): any;
export declare function awsCodepipelineStageBeforeEntryConditionRuleRuleTypeIdPropertyToTerraform(struct?: AwsCodepipeline.StageBeforeEntryConditionRuleRuleTypeIdPropertyOutputReference | AwsCodepipeline.StageBeforeEntryConditionRuleRuleTypeIdProperty): any;
export declare function awsCodepipelineStageBeforeEntryConditionRuleRuleTypeIdPropertyToHclTerraform(struct?: AwsCodepipeline.StageBeforeEntryConditionRuleRuleTypeIdPropertyOutputReference | AwsCodepipeline.StageBeforeEntryConditionRuleRuleTypeIdProperty): any;
export declare function awsCodepipelineStageBeforeEntryConditionRulePropertyToTerraform(struct?: AwsCodepipeline.StageBeforeEntryConditionRuleProperty | cdktn.IResolvable): any;
export declare function awsCodepipelineStageBeforeEntryConditionRulePropertyToHclTerraform(struct?: AwsCodepipeline.StageBeforeEntryConditionRuleProperty | cdktn.IResolvable): any;
export declare function awsCodepipelineStageBeforeEntryConditionPropertyToTerraform(struct?: AwsCodepipeline.StageBeforeEntryConditionPropertyOutputReference | AwsCodepipeline.StageBeforeEntryConditionProperty): any;
export declare function awsCodepipelineStageBeforeEntryConditionPropertyToHclTerraform(struct?: AwsCodepipeline.StageBeforeEntryConditionPropertyOutputReference | AwsCodepipeline.StageBeforeEntryConditionProperty): any;
export declare function awsCodepipelineBeforeEntryPropertyToTerraform(struct?: AwsCodepipeline.BeforeEntryPropertyOutputReference | AwsCodepipeline.BeforeEntryProperty): any;
export declare function awsCodepipelineBeforeEntryPropertyToHclTerraform(struct?: AwsCodepipeline.BeforeEntryPropertyOutputReference | AwsCodepipeline.BeforeEntryProperty): any;
export declare function awsCodepipelineStageOnFailureConditionRuleRuleTypeIdPropertyToTerraform(struct?: AwsCodepipeline.StageOnFailureConditionRuleRuleTypeIdPropertyOutputReference | AwsCodepipeline.StageOnFailureConditionRuleRuleTypeIdProperty): any;
export declare function awsCodepipelineStageOnFailureConditionRuleRuleTypeIdPropertyToHclTerraform(struct?: AwsCodepipeline.StageOnFailureConditionRuleRuleTypeIdPropertyOutputReference | AwsCodepipeline.StageOnFailureConditionRuleRuleTypeIdProperty): any;
export declare function awsCodepipelineStageOnFailureConditionRulePropertyToTerraform(struct?: AwsCodepipeline.StageOnFailureConditionRuleProperty | cdktn.IResolvable): any;
export declare function awsCodepipelineStageOnFailureConditionRulePropertyToHclTerraform(struct?: AwsCodepipeline.StageOnFailureConditionRuleProperty | cdktn.IResolvable): any;
export declare function awsCodepipelineStageOnFailureConditionPropertyToTerraform(struct?: AwsCodepipeline.StageOnFailureConditionPropertyOutputReference | AwsCodepipeline.StageOnFailureConditionProperty): any;
export declare function awsCodepipelineStageOnFailureConditionPropertyToHclTerraform(struct?: AwsCodepipeline.StageOnFailureConditionPropertyOutputReference | AwsCodepipeline.StageOnFailureConditionProperty): any;
export declare function awsCodepipelineRetryConfigurationPropertyToTerraform(struct?: AwsCodepipeline.RetryConfigurationPropertyOutputReference | AwsCodepipeline.RetryConfigurationProperty): any;
export declare function awsCodepipelineRetryConfigurationPropertyToHclTerraform(struct?: AwsCodepipeline.RetryConfigurationPropertyOutputReference | AwsCodepipeline.RetryConfigurationProperty): any;
export declare function awsCodepipelineOnFailurePropertyToTerraform(struct?: AwsCodepipeline.OnFailurePropertyOutputReference | AwsCodepipeline.OnFailureProperty): any;
export declare function awsCodepipelineOnFailurePropertyToHclTerraform(struct?: AwsCodepipeline.OnFailurePropertyOutputReference | AwsCodepipeline.OnFailureProperty): any;
export declare function awsCodepipelineStageOnSuccessConditionRuleRuleTypeIdPropertyToTerraform(struct?: AwsCodepipeline.StageOnSuccessConditionRuleRuleTypeIdPropertyOutputReference | AwsCodepipeline.StageOnSuccessConditionRuleRuleTypeIdProperty): any;
export declare function awsCodepipelineStageOnSuccessConditionRuleRuleTypeIdPropertyToHclTerraform(struct?: AwsCodepipeline.StageOnSuccessConditionRuleRuleTypeIdPropertyOutputReference | AwsCodepipeline.StageOnSuccessConditionRuleRuleTypeIdProperty): any;
export declare function awsCodepipelineStageOnSuccessConditionRulePropertyToTerraform(struct?: AwsCodepipeline.StageOnSuccessConditionRuleProperty | cdktn.IResolvable): any;
export declare function awsCodepipelineStageOnSuccessConditionRulePropertyToHclTerraform(struct?: AwsCodepipeline.StageOnSuccessConditionRuleProperty | cdktn.IResolvable): any;
export declare function awsCodepipelineStageOnSuccessConditionPropertyToTerraform(struct?: AwsCodepipeline.StageOnSuccessConditionPropertyOutputReference | AwsCodepipeline.StageOnSuccessConditionProperty): any;
export declare function awsCodepipelineStageOnSuccessConditionPropertyToHclTerraform(struct?: AwsCodepipeline.StageOnSuccessConditionPropertyOutputReference | AwsCodepipeline.StageOnSuccessConditionProperty): any;
export declare function awsCodepipelineOnSuccessPropertyToTerraform(struct?: AwsCodepipeline.OnSuccessPropertyOutputReference | AwsCodepipeline.OnSuccessProperty): any;
export declare function awsCodepipelineOnSuccessPropertyToHclTerraform(struct?: AwsCodepipeline.OnSuccessPropertyOutputReference | AwsCodepipeline.OnSuccessProperty): any;
export declare function awsCodepipelineStagePropertyToTerraform(struct?: AwsCodepipeline.StageProperty | cdktn.IResolvable): any;
export declare function awsCodepipelineStagePropertyToHclTerraform(struct?: AwsCodepipeline.StageProperty | cdktn.IResolvable): any;
export declare function awsCodepipelineTriggerGitConfigurationPullRequestBranchesPropertyToTerraform(struct?: AwsCodepipeline.TriggerGitConfigurationPullRequestBranchesPropertyOutputReference | AwsCodepipeline.TriggerGitConfigurationPullRequestBranchesProperty): any;
export declare function awsCodepipelineTriggerGitConfigurationPullRequestBranchesPropertyToHclTerraform(struct?: AwsCodepipeline.TriggerGitConfigurationPullRequestBranchesPropertyOutputReference | AwsCodepipeline.TriggerGitConfigurationPullRequestBranchesProperty): any;
export declare function awsCodepipelineTriggerGitConfigurationPullRequestFilePathsPropertyToTerraform(struct?: AwsCodepipeline.TriggerGitConfigurationPullRequestFilePathsPropertyOutputReference | AwsCodepipeline.TriggerGitConfigurationPullRequestFilePathsProperty): any;
export declare function awsCodepipelineTriggerGitConfigurationPullRequestFilePathsPropertyToHclTerraform(struct?: AwsCodepipeline.TriggerGitConfigurationPullRequestFilePathsPropertyOutputReference | AwsCodepipeline.TriggerGitConfigurationPullRequestFilePathsProperty): any;
export declare function awsCodepipelineTriggerGitConfigurationPullRequestPropertyToTerraform(struct?: AwsCodepipeline.TriggerGitConfigurationPullRequestProperty | cdktn.IResolvable): any;
export declare function awsCodepipelineTriggerGitConfigurationPullRequestPropertyToHclTerraform(struct?: AwsCodepipeline.TriggerGitConfigurationPullRequestProperty | cdktn.IResolvable): any;
export declare function awsCodepipelineTriggerGitConfigurationPushBranchesPropertyToTerraform(struct?: AwsCodepipeline.TriggerGitConfigurationPushBranchesPropertyOutputReference | AwsCodepipeline.TriggerGitConfigurationPushBranchesProperty): any;
export declare function awsCodepipelineTriggerGitConfigurationPushBranchesPropertyToHclTerraform(struct?: AwsCodepipeline.TriggerGitConfigurationPushBranchesPropertyOutputReference | AwsCodepipeline.TriggerGitConfigurationPushBranchesProperty): any;
export declare function awsCodepipelineTriggerGitConfigurationPushFilePathsPropertyToTerraform(struct?: AwsCodepipeline.TriggerGitConfigurationPushFilePathsPropertyOutputReference | AwsCodepipeline.TriggerGitConfigurationPushFilePathsProperty): any;
export declare function awsCodepipelineTriggerGitConfigurationPushFilePathsPropertyToHclTerraform(struct?: AwsCodepipeline.TriggerGitConfigurationPushFilePathsPropertyOutputReference | AwsCodepipeline.TriggerGitConfigurationPushFilePathsProperty): any;
export declare function awsCodepipelineTriggerGitConfigurationPushTagsPropertyToTerraform(struct?: AwsCodepipeline.TriggerGitConfigurationPushTagsPropertyOutputReference | AwsCodepipeline.TriggerGitConfigurationPushTagsProperty): any;
export declare function awsCodepipelineTriggerGitConfigurationPushTagsPropertyToHclTerraform(struct?: AwsCodepipeline.TriggerGitConfigurationPushTagsPropertyOutputReference | AwsCodepipeline.TriggerGitConfigurationPushTagsProperty): any;
export declare function awsCodepipelineTriggerGitConfigurationPushPropertyToTerraform(struct?: AwsCodepipeline.TriggerGitConfigurationPushProperty | cdktn.IResolvable): any;
export declare function awsCodepipelineTriggerGitConfigurationPushPropertyToHclTerraform(struct?: AwsCodepipeline.TriggerGitConfigurationPushProperty | cdktn.IResolvable): any;
export declare function awsCodepipelineTriggerGitConfigurationPropertyToTerraform(struct?: AwsCodepipeline.TriggerGitConfigurationPropertyOutputReference | AwsCodepipeline.TriggerGitConfigurationProperty): any;
export declare function awsCodepipelineTriggerGitConfigurationPropertyToHclTerraform(struct?: AwsCodepipeline.TriggerGitConfigurationPropertyOutputReference | AwsCodepipeline.TriggerGitConfigurationProperty): any;
export declare function awsCodepipelineTriggerPropertyToTerraform(struct?: AwsCodepipeline.TriggerProperty | cdktn.IResolvable): any;
export declare function awsCodepipelineTriggerPropertyToHclTerraform(struct?: AwsCodepipeline.TriggerProperty | cdktn.IResolvable): any;
export declare function awsCodepipelineVariablePropertyToTerraform(struct?: AwsCodepipeline.VariableProperty | cdktn.IResolvable): any;
export declare function awsCodepipelineVariablePropertyToHclTerraform(struct?: AwsCodepipeline.VariableProperty | cdktn.IResolvable): any;
export declare namespace AwsCodepipeline {
    interface TriggerAllGitConfigurationPullRequestBranchesProperty {
    }
    class TriggerAllGitConfigurationPullRequestBranchesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TriggerAllGitConfigurationPullRequestBranchesProperty | undefined;
        set internalValue(value: TriggerAllGitConfigurationPullRequestBranchesProperty | undefined);
        get excludes(): string[];
        get includes(): string[];
    }
    class TriggerAllGitConfigurationPullRequestBranchesPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TriggerAllGitConfigurationPullRequestBranchesPropertyOutputReference;
    }
    interface TriggerAllGitConfigurationPullRequestFilePathsProperty {
    }
    class TriggerAllGitConfigurationPullRequestFilePathsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TriggerAllGitConfigurationPullRequestFilePathsProperty | undefined;
        set internalValue(value: TriggerAllGitConfigurationPullRequestFilePathsProperty | undefined);
        get excludes(): string[];
        get includes(): string[];
    }
    class TriggerAllGitConfigurationPullRequestFilePathsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TriggerAllGitConfigurationPullRequestFilePathsPropertyOutputReference;
    }
    interface TriggerAllGitConfigurationPullRequestProperty {
    }
    class TriggerAllGitConfigurationPullRequestPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TriggerAllGitConfigurationPullRequestProperty | undefined;
        set internalValue(value: TriggerAllGitConfigurationPullRequestProperty | undefined);
        private _branches;
        get branches(): TriggerAllGitConfigurationPullRequestBranchesPropertyList;
        get events(): string[];
        private _filePaths;
        get filePaths(): TriggerAllGitConfigurationPullRequestFilePathsPropertyList;
    }
    class TriggerAllGitConfigurationPullRequestPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TriggerAllGitConfigurationPullRequestPropertyOutputReference;
    }
    interface TriggerAllGitConfigurationPushBranchesProperty {
    }
    class TriggerAllGitConfigurationPushBranchesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TriggerAllGitConfigurationPushBranchesProperty | undefined;
        set internalValue(value: TriggerAllGitConfigurationPushBranchesProperty | undefined);
        get excludes(): string[];
        get includes(): string[];
    }
    class TriggerAllGitConfigurationPushBranchesPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TriggerAllGitConfigurationPushBranchesPropertyOutputReference;
    }
    interface TriggerAllGitConfigurationPushFilePathsProperty {
    }
    class TriggerAllGitConfigurationPushFilePathsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TriggerAllGitConfigurationPushFilePathsProperty | undefined;
        set internalValue(value: TriggerAllGitConfigurationPushFilePathsProperty | undefined);
        get excludes(): string[];
        get includes(): string[];
    }
    class TriggerAllGitConfigurationPushFilePathsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TriggerAllGitConfigurationPushFilePathsPropertyOutputReference;
    }
    interface TriggerAllGitConfigurationPushTagsProperty {
    }
    class TriggerAllGitConfigurationPushTagsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TriggerAllGitConfigurationPushTagsProperty | undefined;
        set internalValue(value: TriggerAllGitConfigurationPushTagsProperty | undefined);
        get excludes(): string[];
        get includes(): string[];
    }
    class TriggerAllGitConfigurationPushTagsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TriggerAllGitConfigurationPushTagsPropertyOutputReference;
    }
    interface TriggerAllGitConfigurationPushProperty {
    }
    class TriggerAllGitConfigurationPushPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TriggerAllGitConfigurationPushProperty | undefined;
        set internalValue(value: TriggerAllGitConfigurationPushProperty | undefined);
        private _branches;
        get branches(): TriggerAllGitConfigurationPushBranchesPropertyList;
        private _filePaths;
        get filePaths(): TriggerAllGitConfigurationPushFilePathsPropertyList;
        private _tags;
        get tags(): TriggerAllGitConfigurationPushTagsPropertyList;
    }
    class TriggerAllGitConfigurationPushPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TriggerAllGitConfigurationPushPropertyOutputReference;
    }
    interface TriggerAllGitConfigurationProperty {
    }
    class TriggerAllGitConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TriggerAllGitConfigurationProperty | undefined;
        set internalValue(value: TriggerAllGitConfigurationProperty | undefined);
        private _pullRequest;
        get pullRequest(): TriggerAllGitConfigurationPullRequestPropertyList;
        private _push;
        get push(): TriggerAllGitConfigurationPushPropertyList;
        get sourceActionName(): string;
    }
    class TriggerAllGitConfigurationPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TriggerAllGitConfigurationPropertyOutputReference;
    }
    interface TriggerAllProperty {
    }
    class TriggerAllPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TriggerAllProperty | undefined;
        set internalValue(value: TriggerAllProperty | undefined);
        private _gitConfiguration;
        get gitConfiguration(): TriggerAllGitConfigurationPropertyList;
        get providerType(): string;
    }
    class TriggerAllPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TriggerAllPropertyOutputReference;
    }
    interface EncryptionKeyProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#id AwsCodepipeline#id}
        *
        * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
        * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
        */
        readonly id: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#type AwsCodepipeline#type}
        */
        readonly type: string;
    }
    class EncryptionKeyPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): EncryptionKeyProperty | undefined;
        set internalValue(value: EncryptionKeyProperty | undefined);
        private _id?;
        get id(): string;
        set id(value: string);
        get idInput(): string | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
    }
    interface ArtifactStoreProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#location AwsCodepipeline#location}
        */
        readonly location: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#region AwsCodepipeline#region}
        */
        readonly region?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#type AwsCodepipeline#type}
        */
        readonly type: string;
        /**
        * encryption_key block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#encryption_key AwsCodepipeline#encryption_key}
        */
        readonly encryptionKey?: EncryptionKeyProperty;
    }
    class ArtifactStorePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ArtifactStoreProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ArtifactStoreProperty | cdktn.IResolvable | undefined);
        private _location?;
        get location(): string;
        set location(value: string);
        get locationInput(): string | undefined;
        private _region?;
        get region(): string;
        set region(value: string);
        resetRegion(): void;
        get regionInput(): string | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
        private _encryptionKey;
        get encryptionKey(): EncryptionKeyPropertyOutputReference;
        putEncryptionKey(value: EncryptionKeyProperty): void;
        resetEncryptionKey(): void;
        get encryptionKeyInput(): EncryptionKeyProperty | undefined;
    }
    class ArtifactStorePropertyList extends cdktn.ComplexList {
        internalValue?: ArtifactStoreProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ArtifactStorePropertyOutputReference;
    }
    interface OutputArtifactsForComputeActionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#files AwsCodepipeline#files}
        */
        readonly files?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#name AwsCodepipeline#name}
        */
        readonly name: string;
    }
    class OutputArtifactsForComputeActionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): OutputArtifactsForComputeActionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: OutputArtifactsForComputeActionProperty | cdktn.IResolvable | undefined);
        private _files?;
        get files(): string[];
        set files(value: string[]);
        resetFiles(): void;
        get filesInput(): string[] | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
    }
    class OutputArtifactsForComputeActionPropertyList extends cdktn.ComplexList {
        internalValue?: OutputArtifactsForComputeActionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): OutputArtifactsForComputeActionPropertyOutputReference;
    }
    interface ActionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#category AwsCodepipeline#category}
        */
        readonly category: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#commands AwsCodepipeline#commands}
        */
        readonly commands?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#configuration AwsCodepipeline#configuration}
        */
        readonly configuration?: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#input_artifacts AwsCodepipeline#input_artifacts}
        */
        readonly inputArtifacts?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#name AwsCodepipeline#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#namespace AwsCodepipeline#namespace}
        */
        readonly namespace?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#output_artifacts AwsCodepipeline#output_artifacts}
        */
        readonly outputArtifacts?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#output_variables AwsCodepipeline#output_variables}
        */
        readonly outputVariables?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#owner AwsCodepipeline#owner}
        */
        readonly owner: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#provider AwsCodepipeline#provider}
        */
        readonly provider: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#region AwsCodepipeline#region}
        */
        readonly region?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#role_arn AwsCodepipeline#role_arn}
        */
        readonly roleArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#run_order AwsCodepipeline#run_order}
        */
        readonly runOrder?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#timeout_in_minutes AwsCodepipeline#timeout_in_minutes}
        */
        readonly timeoutInMinutes?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#version AwsCodepipeline#version}
        */
        readonly version: string;
        /**
        * output_artifacts_for_compute_action block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#output_artifacts_for_compute_action AwsCodepipeline#output_artifacts_for_compute_action}
        */
        readonly outputArtifactsForComputeAction?: OutputArtifactsForComputeActionProperty[] | cdktn.IResolvable;
    }
    class ActionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ActionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ActionProperty | cdktn.IResolvable | undefined);
        private _category?;
        get category(): string;
        set category(value: string);
        get categoryInput(): string | undefined;
        private _commands?;
        get commands(): string[];
        set commands(value: string[]);
        resetCommands(): void;
        get commandsInput(): string[] | undefined;
        private _configuration?;
        get configuration(): {
            [key: string]: string;
        };
        set configuration(value: {
            [key: string]: string;
        });
        resetConfiguration(): void;
        get configurationInput(): {
            [key: string]: string;
        } | undefined;
        private _inputArtifacts?;
        get inputArtifacts(): string[];
        set inputArtifacts(value: string[]);
        resetInputArtifacts(): void;
        get inputArtifactsInput(): string[] | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _namespace?;
        get namespace(): string;
        set namespace(value: string);
        resetNamespace(): void;
        get namespaceInput(): string | undefined;
        private _outputArtifacts?;
        get outputArtifacts(): string[];
        set outputArtifacts(value: string[]);
        resetOutputArtifacts(): void;
        get outputArtifactsInput(): string[] | undefined;
        private _outputVariables?;
        get outputVariables(): string[];
        set outputVariables(value: string[]);
        resetOutputVariables(): void;
        get outputVariablesInput(): string[] | undefined;
        private _owner?;
        get owner(): string;
        set owner(value: string);
        get ownerInput(): string | undefined;
        private _provider?;
        get provider(): string;
        set provider(value: string);
        get providerInput(): string | undefined;
        private _region?;
        get region(): string;
        set region(value: string);
        resetRegion(): void;
        get regionInput(): string | undefined;
        private _roleArn?;
        get roleArn(): string;
        set roleArn(value: string);
        resetRoleArn(): void;
        get roleArnInput(): string | undefined;
        private _runOrder?;
        get runOrder(): number;
        set runOrder(value: number);
        resetRunOrder(): void;
        get runOrderInput(): number | undefined;
        private _timeoutInMinutes?;
        get timeoutInMinutes(): number;
        set timeoutInMinutes(value: number);
        resetTimeoutInMinutes(): void;
        get timeoutInMinutesInput(): number | undefined;
        private _version?;
        get version(): string;
        set version(value: string);
        get versionInput(): string | undefined;
        private _outputArtifactsForComputeAction;
        get outputArtifactsForComputeAction(): OutputArtifactsForComputeActionPropertyList;
        putOutputArtifactsForComputeAction(value: OutputArtifactsForComputeActionProperty[] | cdktn.IResolvable): void;
        resetOutputArtifactsForComputeAction(): void;
        get outputArtifactsForComputeActionInput(): cdktn.IResolvable | OutputArtifactsForComputeActionProperty[] | undefined;
    }
    class ActionPropertyList extends cdktn.ComplexList {
        internalValue?: ActionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ActionPropertyOutputReference;
    }
    interface StageBeforeEntryConditionRuleRuleTypeIdProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#category AwsCodepipeline#category}
        */
        readonly category: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#owner AwsCodepipeline#owner}
        */
        readonly owner?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#provider AwsCodepipeline#provider}
        */
        readonly provider: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#version AwsCodepipeline#version}
        */
        readonly version?: string;
    }
    class StageBeforeEntryConditionRuleRuleTypeIdPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): StageBeforeEntryConditionRuleRuleTypeIdProperty | undefined;
        set internalValue(value: StageBeforeEntryConditionRuleRuleTypeIdProperty | undefined);
        private _category?;
        get category(): string;
        set category(value: string);
        get categoryInput(): string | undefined;
        private _owner?;
        get owner(): string;
        set owner(value: string);
        resetOwner(): void;
        get ownerInput(): string | undefined;
        private _provider?;
        get provider(): string;
        set provider(value: string);
        get providerInput(): string | undefined;
        private _version?;
        get version(): string;
        set version(value: string);
        resetVersion(): void;
        get versionInput(): string | undefined;
    }
    interface StageBeforeEntryConditionRuleProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#commands AwsCodepipeline#commands}
        */
        readonly commands?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#configuration AwsCodepipeline#configuration}
        */
        readonly configuration?: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#input_artifacts AwsCodepipeline#input_artifacts}
        */
        readonly inputArtifacts?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#name AwsCodepipeline#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#region AwsCodepipeline#region}
        */
        readonly region?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#role_arn AwsCodepipeline#role_arn}
        */
        readonly roleArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#timeout_in_minutes AwsCodepipeline#timeout_in_minutes}
        */
        readonly timeoutInMinutes?: number;
        /**
        * rule_type_id block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#rule_type_id AwsCodepipeline#rule_type_id}
        */
        readonly ruleTypeId: StageBeforeEntryConditionRuleRuleTypeIdProperty;
    }
    class StageBeforeEntryConditionRulePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): StageBeforeEntryConditionRuleProperty | cdktn.IResolvable | undefined;
        set internalValue(value: StageBeforeEntryConditionRuleProperty | cdktn.IResolvable | undefined);
        private _commands?;
        get commands(): string[];
        set commands(value: string[]);
        resetCommands(): void;
        get commandsInput(): string[] | undefined;
        private _configuration?;
        get configuration(): {
            [key: string]: string;
        };
        set configuration(value: {
            [key: string]: string;
        });
        resetConfiguration(): void;
        get configurationInput(): {
            [key: string]: string;
        } | undefined;
        private _inputArtifacts?;
        get inputArtifacts(): string[];
        set inputArtifacts(value: string[]);
        resetInputArtifacts(): void;
        get inputArtifactsInput(): string[] | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _region?;
        get region(): string;
        set region(value: string);
        resetRegion(): void;
        get regionInput(): string | undefined;
        private _roleArn?;
        get roleArn(): string;
        set roleArn(value: string);
        resetRoleArn(): void;
        get roleArnInput(): string | undefined;
        private _timeoutInMinutes?;
        get timeoutInMinutes(): number;
        set timeoutInMinutes(value: number);
        resetTimeoutInMinutes(): void;
        get timeoutInMinutesInput(): number | undefined;
        private _ruleTypeId;
        get ruleTypeId(): StageBeforeEntryConditionRuleRuleTypeIdPropertyOutputReference;
        putRuleTypeId(value: StageBeforeEntryConditionRuleRuleTypeIdProperty): void;
        get ruleTypeIdInput(): StageBeforeEntryConditionRuleRuleTypeIdProperty | undefined;
    }
    class StageBeforeEntryConditionRulePropertyList extends cdktn.ComplexList {
        internalValue?: StageBeforeEntryConditionRuleProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): StageBeforeEntryConditionRulePropertyOutputReference;
    }
    interface StageBeforeEntryConditionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#result AwsCodepipeline#result}
        */
        readonly result?: string;
        /**
        * rule block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#rule AwsCodepipeline#rule}
        */
        readonly rule: StageBeforeEntryConditionRuleProperty[] | cdktn.IResolvable;
    }
    class StageBeforeEntryConditionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): StageBeforeEntryConditionProperty | undefined;
        set internalValue(value: StageBeforeEntryConditionProperty | undefined);
        private _result?;
        get result(): string;
        set result(value: string);
        resetResult(): void;
        get resultInput(): string | undefined;
        private _rule;
        get rule(): StageBeforeEntryConditionRulePropertyList;
        putRule(value: StageBeforeEntryConditionRuleProperty[] | cdktn.IResolvable): void;
        get ruleInput(): cdktn.IResolvable | StageBeforeEntryConditionRuleProperty[] | undefined;
    }
    interface BeforeEntryProperty {
        /**
        * condition block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#condition AwsCodepipeline#condition}
        */
        readonly condition: StageBeforeEntryConditionProperty;
    }
    class BeforeEntryPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): BeforeEntryProperty | undefined;
        set internalValue(value: BeforeEntryProperty | undefined);
        private _condition;
        get condition(): StageBeforeEntryConditionPropertyOutputReference;
        putCondition(value: StageBeforeEntryConditionProperty): void;
        get conditionInput(): StageBeforeEntryConditionProperty | undefined;
    }
    interface StageOnFailureConditionRuleRuleTypeIdProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#category AwsCodepipeline#category}
        */
        readonly category: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#owner AwsCodepipeline#owner}
        */
        readonly owner?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#provider AwsCodepipeline#provider}
        */
        readonly provider: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#version AwsCodepipeline#version}
        */
        readonly version?: string;
    }
    class StageOnFailureConditionRuleRuleTypeIdPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): StageOnFailureConditionRuleRuleTypeIdProperty | undefined;
        set internalValue(value: StageOnFailureConditionRuleRuleTypeIdProperty | undefined);
        private _category?;
        get category(): string;
        set category(value: string);
        get categoryInput(): string | undefined;
        private _owner?;
        get owner(): string;
        set owner(value: string);
        resetOwner(): void;
        get ownerInput(): string | undefined;
        private _provider?;
        get provider(): string;
        set provider(value: string);
        get providerInput(): string | undefined;
        private _version?;
        get version(): string;
        set version(value: string);
        resetVersion(): void;
        get versionInput(): string | undefined;
    }
    interface StageOnFailureConditionRuleProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#commands AwsCodepipeline#commands}
        */
        readonly commands?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#configuration AwsCodepipeline#configuration}
        */
        readonly configuration?: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#input_artifacts AwsCodepipeline#input_artifacts}
        */
        readonly inputArtifacts?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#name AwsCodepipeline#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#region AwsCodepipeline#region}
        */
        readonly region?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#role_arn AwsCodepipeline#role_arn}
        */
        readonly roleArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#timeout_in_minutes AwsCodepipeline#timeout_in_minutes}
        */
        readonly timeoutInMinutes?: number;
        /**
        * rule_type_id block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#rule_type_id AwsCodepipeline#rule_type_id}
        */
        readonly ruleTypeId: StageOnFailureConditionRuleRuleTypeIdProperty;
    }
    class StageOnFailureConditionRulePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): StageOnFailureConditionRuleProperty | cdktn.IResolvable | undefined;
        set internalValue(value: StageOnFailureConditionRuleProperty | cdktn.IResolvable | undefined);
        private _commands?;
        get commands(): string[];
        set commands(value: string[]);
        resetCommands(): void;
        get commandsInput(): string[] | undefined;
        private _configuration?;
        get configuration(): {
            [key: string]: string;
        };
        set configuration(value: {
            [key: string]: string;
        });
        resetConfiguration(): void;
        get configurationInput(): {
            [key: string]: string;
        } | undefined;
        private _inputArtifacts?;
        get inputArtifacts(): string[];
        set inputArtifacts(value: string[]);
        resetInputArtifacts(): void;
        get inputArtifactsInput(): string[] | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _region?;
        get region(): string;
        set region(value: string);
        resetRegion(): void;
        get regionInput(): string | undefined;
        private _roleArn?;
        get roleArn(): string;
        set roleArn(value: string);
        resetRoleArn(): void;
        get roleArnInput(): string | undefined;
        private _timeoutInMinutes?;
        get timeoutInMinutes(): number;
        set timeoutInMinutes(value: number);
        resetTimeoutInMinutes(): void;
        get timeoutInMinutesInput(): number | undefined;
        private _ruleTypeId;
        get ruleTypeId(): StageOnFailureConditionRuleRuleTypeIdPropertyOutputReference;
        putRuleTypeId(value: StageOnFailureConditionRuleRuleTypeIdProperty): void;
        get ruleTypeIdInput(): StageOnFailureConditionRuleRuleTypeIdProperty | undefined;
    }
    class StageOnFailureConditionRulePropertyList extends cdktn.ComplexList {
        internalValue?: StageOnFailureConditionRuleProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): StageOnFailureConditionRulePropertyOutputReference;
    }
    interface StageOnFailureConditionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#result AwsCodepipeline#result}
        */
        readonly result?: string;
        /**
        * rule block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#rule AwsCodepipeline#rule}
        */
        readonly rule: StageOnFailureConditionRuleProperty[] | cdktn.IResolvable;
    }
    class StageOnFailureConditionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): StageOnFailureConditionProperty | undefined;
        set internalValue(value: StageOnFailureConditionProperty | undefined);
        private _result?;
        get result(): string;
        set result(value: string);
        resetResult(): void;
        get resultInput(): string | undefined;
        private _rule;
        get rule(): StageOnFailureConditionRulePropertyList;
        putRule(value: StageOnFailureConditionRuleProperty[] | cdktn.IResolvable): void;
        get ruleInput(): cdktn.IResolvable | StageOnFailureConditionRuleProperty[] | undefined;
    }
    interface RetryConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#retry_mode AwsCodepipeline#retry_mode}
        */
        readonly retryMode?: string;
    }
    class RetryConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RetryConfigurationProperty | undefined;
        set internalValue(value: RetryConfigurationProperty | undefined);
        private _retryMode?;
        get retryMode(): string;
        set retryMode(value: string);
        resetRetryMode(): void;
        get retryModeInput(): string | undefined;
    }
    interface OnFailureProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#result AwsCodepipeline#result}
        */
        readonly result?: string;
        /**
        * condition block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#condition AwsCodepipeline#condition}
        */
        readonly condition?: StageOnFailureConditionProperty;
        /**
        * retry_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#retry_configuration AwsCodepipeline#retry_configuration}
        */
        readonly retryConfiguration?: RetryConfigurationProperty;
    }
    class OnFailurePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): OnFailureProperty | undefined;
        set internalValue(value: OnFailureProperty | undefined);
        private _result?;
        get result(): string;
        set result(value: string);
        resetResult(): void;
        get resultInput(): string | undefined;
        private _condition;
        get condition(): StageOnFailureConditionPropertyOutputReference;
        putCondition(value: StageOnFailureConditionProperty): void;
        resetCondition(): void;
        get conditionInput(): StageOnFailureConditionProperty | undefined;
        private _retryConfiguration;
        get retryConfiguration(): RetryConfigurationPropertyOutputReference;
        putRetryConfiguration(value: RetryConfigurationProperty): void;
        resetRetryConfiguration(): void;
        get retryConfigurationInput(): RetryConfigurationProperty | undefined;
    }
    interface StageOnSuccessConditionRuleRuleTypeIdProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#category AwsCodepipeline#category}
        */
        readonly category: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#owner AwsCodepipeline#owner}
        */
        readonly owner?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#provider AwsCodepipeline#provider}
        */
        readonly provider: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#version AwsCodepipeline#version}
        */
        readonly version?: string;
    }
    class StageOnSuccessConditionRuleRuleTypeIdPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): StageOnSuccessConditionRuleRuleTypeIdProperty | undefined;
        set internalValue(value: StageOnSuccessConditionRuleRuleTypeIdProperty | undefined);
        private _category?;
        get category(): string;
        set category(value: string);
        get categoryInput(): string | undefined;
        private _owner?;
        get owner(): string;
        set owner(value: string);
        resetOwner(): void;
        get ownerInput(): string | undefined;
        private _provider?;
        get provider(): string;
        set provider(value: string);
        get providerInput(): string | undefined;
        private _version?;
        get version(): string;
        set version(value: string);
        resetVersion(): void;
        get versionInput(): string | undefined;
    }
    interface StageOnSuccessConditionRuleProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#commands AwsCodepipeline#commands}
        */
        readonly commands?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#configuration AwsCodepipeline#configuration}
        */
        readonly configuration?: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#input_artifacts AwsCodepipeline#input_artifacts}
        */
        readonly inputArtifacts?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#name AwsCodepipeline#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#region AwsCodepipeline#region}
        */
        readonly region?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#role_arn AwsCodepipeline#role_arn}
        */
        readonly roleArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#timeout_in_minutes AwsCodepipeline#timeout_in_minutes}
        */
        readonly timeoutInMinutes?: number;
        /**
        * rule_type_id block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#rule_type_id AwsCodepipeline#rule_type_id}
        */
        readonly ruleTypeId: StageOnSuccessConditionRuleRuleTypeIdProperty;
    }
    class StageOnSuccessConditionRulePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): StageOnSuccessConditionRuleProperty | cdktn.IResolvable | undefined;
        set internalValue(value: StageOnSuccessConditionRuleProperty | cdktn.IResolvable | undefined);
        private _commands?;
        get commands(): string[];
        set commands(value: string[]);
        resetCommands(): void;
        get commandsInput(): string[] | undefined;
        private _configuration?;
        get configuration(): {
            [key: string]: string;
        };
        set configuration(value: {
            [key: string]: string;
        });
        resetConfiguration(): void;
        get configurationInput(): {
            [key: string]: string;
        } | undefined;
        private _inputArtifacts?;
        get inputArtifacts(): string[];
        set inputArtifacts(value: string[]);
        resetInputArtifacts(): void;
        get inputArtifactsInput(): string[] | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _region?;
        get region(): string;
        set region(value: string);
        resetRegion(): void;
        get regionInput(): string | undefined;
        private _roleArn?;
        get roleArn(): string;
        set roleArn(value: string);
        resetRoleArn(): void;
        get roleArnInput(): string | undefined;
        private _timeoutInMinutes?;
        get timeoutInMinutes(): number;
        set timeoutInMinutes(value: number);
        resetTimeoutInMinutes(): void;
        get timeoutInMinutesInput(): number | undefined;
        private _ruleTypeId;
        get ruleTypeId(): StageOnSuccessConditionRuleRuleTypeIdPropertyOutputReference;
        putRuleTypeId(value: StageOnSuccessConditionRuleRuleTypeIdProperty): void;
        get ruleTypeIdInput(): StageOnSuccessConditionRuleRuleTypeIdProperty | undefined;
    }
    class StageOnSuccessConditionRulePropertyList extends cdktn.ComplexList {
        internalValue?: StageOnSuccessConditionRuleProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): StageOnSuccessConditionRulePropertyOutputReference;
    }
    interface StageOnSuccessConditionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#result AwsCodepipeline#result}
        */
        readonly result?: string;
        /**
        * rule block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#rule AwsCodepipeline#rule}
        */
        readonly rule: StageOnSuccessConditionRuleProperty[] | cdktn.IResolvable;
    }
    class StageOnSuccessConditionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): StageOnSuccessConditionProperty | undefined;
        set internalValue(value: StageOnSuccessConditionProperty | undefined);
        private _result?;
        get result(): string;
        set result(value: string);
        resetResult(): void;
        get resultInput(): string | undefined;
        private _rule;
        get rule(): StageOnSuccessConditionRulePropertyList;
        putRule(value: StageOnSuccessConditionRuleProperty[] | cdktn.IResolvable): void;
        get ruleInput(): cdktn.IResolvable | StageOnSuccessConditionRuleProperty[] | undefined;
    }
    interface OnSuccessProperty {
        /**
        * condition block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#condition AwsCodepipeline#condition}
        */
        readonly condition: StageOnSuccessConditionProperty;
    }
    class OnSuccessPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): OnSuccessProperty | undefined;
        set internalValue(value: OnSuccessProperty | undefined);
        private _condition;
        get condition(): StageOnSuccessConditionPropertyOutputReference;
        putCondition(value: StageOnSuccessConditionProperty): void;
        get conditionInput(): StageOnSuccessConditionProperty | undefined;
    }
    interface StageProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#name AwsCodepipeline#name}
        */
        readonly name: string;
        /**
        * action block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#action AwsCodepipeline#action}
        */
        readonly action: ActionProperty[] | cdktn.IResolvable;
        /**
        * before_entry block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#before_entry AwsCodepipeline#before_entry}
        */
        readonly beforeEntry?: BeforeEntryProperty;
        /**
        * on_failure block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#on_failure AwsCodepipeline#on_failure}
        */
        readonly onFailure?: OnFailureProperty;
        /**
        * on_success block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#on_success AwsCodepipeline#on_success}
        */
        readonly onSuccess?: OnSuccessProperty;
    }
    class StagePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): StageProperty | cdktn.IResolvable | undefined;
        set internalValue(value: StageProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _action;
        get action(): ActionPropertyList;
        putAction(value: ActionProperty[] | cdktn.IResolvable): void;
        get actionInput(): cdktn.IResolvable | ActionProperty[] | undefined;
        private _beforeEntry;
        get beforeEntry(): BeforeEntryPropertyOutputReference;
        putBeforeEntry(value: BeforeEntryProperty): void;
        resetBeforeEntry(): void;
        get beforeEntryInput(): BeforeEntryProperty | undefined;
        private _onFailure;
        get onFailure(): OnFailurePropertyOutputReference;
        putOnFailure(value: OnFailureProperty): void;
        resetOnFailure(): void;
        get onFailureInput(): OnFailureProperty | undefined;
        private _onSuccess;
        get onSuccess(): OnSuccessPropertyOutputReference;
        putOnSuccess(value: OnSuccessProperty): void;
        resetOnSuccess(): void;
        get onSuccessInput(): OnSuccessProperty | undefined;
    }
    class StagePropertyList extends cdktn.ComplexList {
        internalValue?: StageProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): StagePropertyOutputReference;
    }
    interface TriggerGitConfigurationPullRequestBranchesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#excludes AwsCodepipeline#excludes}
        */
        readonly excludes?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#includes AwsCodepipeline#includes}
        */
        readonly includes?: string[];
    }
    class TriggerGitConfigurationPullRequestBranchesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TriggerGitConfigurationPullRequestBranchesProperty | undefined;
        set internalValue(value: TriggerGitConfigurationPullRequestBranchesProperty | undefined);
        private _excludes?;
        get excludes(): string[];
        set excludes(value: string[]);
        resetExcludes(): void;
        get excludesInput(): string[] | undefined;
        private _includes?;
        get includes(): string[];
        set includes(value: string[]);
        resetIncludes(): void;
        get includesInput(): string[] | undefined;
    }
    interface TriggerGitConfigurationPullRequestFilePathsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#excludes AwsCodepipeline#excludes}
        */
        readonly excludes?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#includes AwsCodepipeline#includes}
        */
        readonly includes?: string[];
    }
    class TriggerGitConfigurationPullRequestFilePathsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TriggerGitConfigurationPullRequestFilePathsProperty | undefined;
        set internalValue(value: TriggerGitConfigurationPullRequestFilePathsProperty | undefined);
        private _excludes?;
        get excludes(): string[];
        set excludes(value: string[]);
        resetExcludes(): void;
        get excludesInput(): string[] | undefined;
        private _includes?;
        get includes(): string[];
        set includes(value: string[]);
        resetIncludes(): void;
        get includesInput(): string[] | undefined;
    }
    interface TriggerGitConfigurationPullRequestProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#events AwsCodepipeline#events}
        */
        readonly events?: string[];
        /**
        * branches block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#branches AwsCodepipeline#branches}
        */
        readonly branches?: TriggerGitConfigurationPullRequestBranchesProperty;
        /**
        * file_paths block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#file_paths AwsCodepipeline#file_paths}
        */
        readonly filePaths?: TriggerGitConfigurationPullRequestFilePathsProperty;
    }
    class TriggerGitConfigurationPullRequestPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TriggerGitConfigurationPullRequestProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TriggerGitConfigurationPullRequestProperty | cdktn.IResolvable | undefined);
        private _events?;
        get events(): string[];
        set events(value: string[]);
        resetEvents(): void;
        get eventsInput(): string[] | undefined;
        private _branches;
        get branches(): TriggerGitConfigurationPullRequestBranchesPropertyOutputReference;
        putBranches(value: TriggerGitConfigurationPullRequestBranchesProperty): void;
        resetBranches(): void;
        get branchesInput(): TriggerGitConfigurationPullRequestBranchesProperty | undefined;
        private _filePaths;
        get filePaths(): TriggerGitConfigurationPullRequestFilePathsPropertyOutputReference;
        putFilePaths(value: TriggerGitConfigurationPullRequestFilePathsProperty): void;
        resetFilePaths(): void;
        get filePathsInput(): TriggerGitConfigurationPullRequestFilePathsProperty | undefined;
    }
    class TriggerGitConfigurationPullRequestPropertyList extends cdktn.ComplexList {
        internalValue?: TriggerGitConfigurationPullRequestProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TriggerGitConfigurationPullRequestPropertyOutputReference;
    }
    interface TriggerGitConfigurationPushBranchesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#excludes AwsCodepipeline#excludes}
        */
        readonly excludes?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#includes AwsCodepipeline#includes}
        */
        readonly includes?: string[];
    }
    class TriggerGitConfigurationPushBranchesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TriggerGitConfigurationPushBranchesProperty | undefined;
        set internalValue(value: TriggerGitConfigurationPushBranchesProperty | undefined);
        private _excludes?;
        get excludes(): string[];
        set excludes(value: string[]);
        resetExcludes(): void;
        get excludesInput(): string[] | undefined;
        private _includes?;
        get includes(): string[];
        set includes(value: string[]);
        resetIncludes(): void;
        get includesInput(): string[] | undefined;
    }
    interface TriggerGitConfigurationPushFilePathsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#excludes AwsCodepipeline#excludes}
        */
        readonly excludes?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#includes AwsCodepipeline#includes}
        */
        readonly includes?: string[];
    }
    class TriggerGitConfigurationPushFilePathsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TriggerGitConfigurationPushFilePathsProperty | undefined;
        set internalValue(value: TriggerGitConfigurationPushFilePathsProperty | undefined);
        private _excludes?;
        get excludes(): string[];
        set excludes(value: string[]);
        resetExcludes(): void;
        get excludesInput(): string[] | undefined;
        private _includes?;
        get includes(): string[];
        set includes(value: string[]);
        resetIncludes(): void;
        get includesInput(): string[] | undefined;
    }
    interface TriggerGitConfigurationPushTagsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#excludes AwsCodepipeline#excludes}
        */
        readonly excludes?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#includes AwsCodepipeline#includes}
        */
        readonly includes?: string[];
    }
    class TriggerGitConfigurationPushTagsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TriggerGitConfigurationPushTagsProperty | undefined;
        set internalValue(value: TriggerGitConfigurationPushTagsProperty | undefined);
        private _excludes?;
        get excludes(): string[];
        set excludes(value: string[]);
        resetExcludes(): void;
        get excludesInput(): string[] | undefined;
        private _includes?;
        get includes(): string[];
        set includes(value: string[]);
        resetIncludes(): void;
        get includesInput(): string[] | undefined;
    }
    interface TriggerGitConfigurationPushProperty {
        /**
        * branches block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#branches AwsCodepipeline#branches}
        */
        readonly branches?: TriggerGitConfigurationPushBranchesProperty;
        /**
        * file_paths block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#file_paths AwsCodepipeline#file_paths}
        */
        readonly filePaths?: TriggerGitConfigurationPushFilePathsProperty;
        /**
        * tags block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#tags AwsCodepipeline#tags}
        */
        readonly tags?: TriggerGitConfigurationPushTagsProperty;
    }
    class TriggerGitConfigurationPushPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TriggerGitConfigurationPushProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TriggerGitConfigurationPushProperty | cdktn.IResolvable | undefined);
        private _branches;
        get branches(): TriggerGitConfigurationPushBranchesPropertyOutputReference;
        putBranches(value: TriggerGitConfigurationPushBranchesProperty): void;
        resetBranches(): void;
        get branchesInput(): TriggerGitConfigurationPushBranchesProperty | undefined;
        private _filePaths;
        get filePaths(): TriggerGitConfigurationPushFilePathsPropertyOutputReference;
        putFilePaths(value: TriggerGitConfigurationPushFilePathsProperty): void;
        resetFilePaths(): void;
        get filePathsInput(): TriggerGitConfigurationPushFilePathsProperty | undefined;
        private _tags;
        get tags(): TriggerGitConfigurationPushTagsPropertyOutputReference;
        putTags(value: TriggerGitConfigurationPushTagsProperty): void;
        resetTags(): void;
        get tagsInput(): TriggerGitConfigurationPushTagsProperty | undefined;
    }
    class TriggerGitConfigurationPushPropertyList extends cdktn.ComplexList {
        internalValue?: TriggerGitConfigurationPushProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TriggerGitConfigurationPushPropertyOutputReference;
    }
    interface TriggerGitConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#source_action_name AwsCodepipeline#source_action_name}
        */
        readonly sourceActionName: string;
        /**
        * pull_request block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#pull_request AwsCodepipeline#pull_request}
        */
        readonly pullRequest?: TriggerGitConfigurationPullRequestProperty[] | cdktn.IResolvable;
        /**
        * push block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#push AwsCodepipeline#push}
        */
        readonly push?: TriggerGitConfigurationPushProperty[] | cdktn.IResolvable;
    }
    class TriggerGitConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TriggerGitConfigurationProperty | undefined;
        set internalValue(value: TriggerGitConfigurationProperty | undefined);
        private _sourceActionName?;
        get sourceActionName(): string;
        set sourceActionName(value: string);
        get sourceActionNameInput(): string | undefined;
        private _pullRequest;
        get pullRequest(): TriggerGitConfigurationPullRequestPropertyList;
        putPullRequest(value: TriggerGitConfigurationPullRequestProperty[] | cdktn.IResolvable): void;
        resetPullRequest(): void;
        get pullRequestInput(): cdktn.IResolvable | TriggerGitConfigurationPullRequestProperty[] | undefined;
        private _push;
        get push(): TriggerGitConfigurationPushPropertyList;
        putPush(value: TriggerGitConfigurationPushProperty[] | cdktn.IResolvable): void;
        resetPush(): void;
        get pushInput(): cdktn.IResolvable | TriggerGitConfigurationPushProperty[] | undefined;
    }
    interface TriggerProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#provider_type AwsCodepipeline#provider_type}
        */
        readonly providerType: string;
        /**
        * git_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#git_configuration AwsCodepipeline#git_configuration}
        */
        readonly gitConfiguration: TriggerGitConfigurationProperty;
    }
    class TriggerPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TriggerProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TriggerProperty | cdktn.IResolvable | undefined);
        private _providerType?;
        get providerType(): string;
        set providerType(value: string);
        get providerTypeInput(): string | undefined;
        private _gitConfiguration;
        get gitConfiguration(): TriggerGitConfigurationPropertyOutputReference;
        putGitConfiguration(value: TriggerGitConfigurationProperty): void;
        get gitConfigurationInput(): TriggerGitConfigurationProperty | undefined;
    }
    class TriggerPropertyList extends cdktn.ComplexList {
        internalValue?: TriggerProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TriggerPropertyOutputReference;
    }
    interface VariableProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#default_value AwsCodepipeline#default_value}
        */
        readonly defaultValue?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#description AwsCodepipeline#description}
        */
        readonly description?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codepipeline#name AwsCodepipeline#name}
        */
        readonly name: string;
    }
    class VariablePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): VariableProperty | cdktn.IResolvable | undefined;
        set internalValue(value: VariableProperty | cdktn.IResolvable | undefined);
        private _defaultValue?;
        get defaultValue(): string;
        set defaultValue(value: string);
        resetDefaultValue(): void;
        get defaultValueInput(): string | undefined;
        private _description?;
        get description(): string;
        set description(value: string);
        resetDescription(): void;
        get descriptionInput(): string | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
    }
    class VariablePropertyList extends cdktn.ComplexList {
        internalValue?: VariableProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): VariablePropertyOutputReference;
    }
}
