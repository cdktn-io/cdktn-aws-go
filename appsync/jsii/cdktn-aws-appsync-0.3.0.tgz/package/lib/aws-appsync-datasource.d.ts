import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsDatasourceConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_datasource#api_id AwsDatasource#api_id}
    */
    readonly apiId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_datasource#description AwsDatasource#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_datasource#id AwsDatasource#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_datasource#name AwsDatasource#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_datasource#region AwsDatasource#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_datasource#service_role_arn AwsDatasource#service_role_arn}
    */
    readonly serviceRoleArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_datasource#type AwsDatasource#type}
    */
    readonly type: string;
    /**
    * dynamodb_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_datasource#dynamodb_config AwsDatasource#dynamodb_config}
    */
    readonly dynamodbConfig?: AwsDatasource.DynamodbConfigProperty;
    /**
    * elasticsearch_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_datasource#elasticsearch_config AwsDatasource#elasticsearch_config}
    */
    readonly elasticsearchConfig?: AwsDatasource.ElasticsearchConfigProperty;
    /**
    * event_bridge_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_datasource#event_bridge_config AwsDatasource#event_bridge_config}
    */
    readonly eventBridgeConfig?: AwsDatasource.EventBridgeConfigProperty;
    /**
    * http_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_datasource#http_config AwsDatasource#http_config}
    */
    readonly httpConfig?: AwsDatasource.HttpConfigProperty;
    /**
    * lambda_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_datasource#lambda_config AwsDatasource#lambda_config}
    */
    readonly lambdaConfig?: AwsDatasource.LambdaConfigProperty;
    /**
    * opensearchservice_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_datasource#opensearchservice_config AwsDatasource#opensearchservice_config}
    */
    readonly opensearchserviceConfig?: AwsDatasource.OpensearchserviceConfigProperty;
    /**
    * relational_database_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_datasource#relational_database_config AwsDatasource#relational_database_config}
    */
    readonly relationalDatabaseConfig?: AwsDatasource.RelationalDatabaseConfigProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_datasource aws_appsync_datasource}
*/
export declare class AwsDatasource extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_appsync_datasource";
    /**
    * Generates CDKTN code for importing a AwsDatasource resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsDatasource to import
    * @param importFromId The id of the existing AwsDatasource that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_datasource#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsDatasource to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_datasource aws_appsync_datasource} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsDatasourceConfig
    */
    constructor(scope: Construct, id: string, config: AwsDatasourceConfig);
    private _apiId?;
    get apiId(): string;
    set apiId(value: string);
    get apiIdInput(): string | undefined;
    get arn(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _serviceRoleArn?;
    get serviceRoleArn(): string;
    set serviceRoleArn(value: string);
    resetServiceRoleArn(): void;
    get serviceRoleArnInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _dynamodbConfig;
    get dynamodbConfig(): AwsDatasource.DynamodbConfigPropertyOutputReference;
    putDynamodbConfig(value: AwsDatasource.DynamodbConfigProperty): void;
    resetDynamodbConfig(): void;
    get dynamodbConfigInput(): AwsDatasource.DynamodbConfigProperty | undefined;
    private _elasticsearchConfig;
    get elasticsearchConfig(): AwsDatasource.ElasticsearchConfigPropertyOutputReference;
    putElasticsearchConfig(value: AwsDatasource.ElasticsearchConfigProperty): void;
    resetElasticsearchConfig(): void;
    get elasticsearchConfigInput(): AwsDatasource.ElasticsearchConfigProperty | undefined;
    private _eventBridgeConfig;
    get eventBridgeConfig(): AwsDatasource.EventBridgeConfigPropertyOutputReference;
    putEventBridgeConfig(value: AwsDatasource.EventBridgeConfigProperty): void;
    resetEventBridgeConfig(): void;
    get eventBridgeConfigInput(): AwsDatasource.EventBridgeConfigProperty | undefined;
    private _httpConfig;
    get httpConfig(): AwsDatasource.HttpConfigPropertyOutputReference;
    putHttpConfig(value: AwsDatasource.HttpConfigProperty): void;
    resetHttpConfig(): void;
    get httpConfigInput(): AwsDatasource.HttpConfigProperty | undefined;
    private _lambdaConfig;
    get lambdaConfig(): AwsDatasource.LambdaConfigPropertyOutputReference;
    putLambdaConfig(value: AwsDatasource.LambdaConfigProperty): void;
    resetLambdaConfig(): void;
    get lambdaConfigInput(): AwsDatasource.LambdaConfigProperty | undefined;
    private _opensearchserviceConfig;
    get opensearchserviceConfig(): AwsDatasource.OpensearchserviceConfigPropertyOutputReference;
    putOpensearchserviceConfig(value: AwsDatasource.OpensearchserviceConfigProperty): void;
    resetOpensearchserviceConfig(): void;
    get opensearchserviceConfigInput(): AwsDatasource.OpensearchserviceConfigProperty | undefined;
    private _relationalDatabaseConfig;
    get relationalDatabaseConfig(): AwsDatasource.RelationalDatabaseConfigPropertyOutputReference;
    putRelationalDatabaseConfig(value: AwsDatasource.RelationalDatabaseConfigProperty): void;
    resetRelationalDatabaseConfig(): void;
    get relationalDatabaseConfigInput(): AwsDatasource.RelationalDatabaseConfigProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsDatasourceDeltaSyncConfigPropertyToTerraform(struct?: AwsDatasource.DeltaSyncConfigPropertyOutputReference | AwsDatasource.DeltaSyncConfigProperty): any;
export declare function awsDatasourceDeltaSyncConfigPropertyToHclTerraform(struct?: AwsDatasource.DeltaSyncConfigPropertyOutputReference | AwsDatasource.DeltaSyncConfigProperty): any;
export declare function awsDatasourceDynamodbConfigPropertyToTerraform(struct?: AwsDatasource.DynamodbConfigPropertyOutputReference | AwsDatasource.DynamodbConfigProperty): any;
export declare function awsDatasourceDynamodbConfigPropertyToHclTerraform(struct?: AwsDatasource.DynamodbConfigPropertyOutputReference | AwsDatasource.DynamodbConfigProperty): any;
export declare function awsDatasourceElasticsearchConfigPropertyToTerraform(struct?: AwsDatasource.ElasticsearchConfigPropertyOutputReference | AwsDatasource.ElasticsearchConfigProperty): any;
export declare function awsDatasourceElasticsearchConfigPropertyToHclTerraform(struct?: AwsDatasource.ElasticsearchConfigPropertyOutputReference | AwsDatasource.ElasticsearchConfigProperty): any;
export declare function awsDatasourceEventBridgeConfigPropertyToTerraform(struct?: AwsDatasource.EventBridgeConfigPropertyOutputReference | AwsDatasource.EventBridgeConfigProperty): any;
export declare function awsDatasourceEventBridgeConfigPropertyToHclTerraform(struct?: AwsDatasource.EventBridgeConfigPropertyOutputReference | AwsDatasource.EventBridgeConfigProperty): any;
export declare function awsDatasourceAwsIamConfigPropertyToTerraform(struct?: AwsDatasource.AwsIamConfigPropertyOutputReference | AwsDatasource.AwsIamConfigProperty): any;
export declare function awsDatasourceAwsIamConfigPropertyToHclTerraform(struct?: AwsDatasource.AwsIamConfigPropertyOutputReference | AwsDatasource.AwsIamConfigProperty): any;
export declare function awsDatasourceAuthorizationConfigPropertyToTerraform(struct?: AwsDatasource.AuthorizationConfigPropertyOutputReference | AwsDatasource.AuthorizationConfigProperty): any;
export declare function awsDatasourceAuthorizationConfigPropertyToHclTerraform(struct?: AwsDatasource.AuthorizationConfigPropertyOutputReference | AwsDatasource.AuthorizationConfigProperty): any;
export declare function awsDatasourceHttpConfigPropertyToTerraform(struct?: AwsDatasource.HttpConfigPropertyOutputReference | AwsDatasource.HttpConfigProperty): any;
export declare function awsDatasourceHttpConfigPropertyToHclTerraform(struct?: AwsDatasource.HttpConfigPropertyOutputReference | AwsDatasource.HttpConfigProperty): any;
export declare function awsDatasourceLambdaConfigPropertyToTerraform(struct?: AwsDatasource.LambdaConfigPropertyOutputReference | AwsDatasource.LambdaConfigProperty): any;
export declare function awsDatasourceLambdaConfigPropertyToHclTerraform(struct?: AwsDatasource.LambdaConfigPropertyOutputReference | AwsDatasource.LambdaConfigProperty): any;
export declare function awsDatasourceOpensearchserviceConfigPropertyToTerraform(struct?: AwsDatasource.OpensearchserviceConfigPropertyOutputReference | AwsDatasource.OpensearchserviceConfigProperty): any;
export declare function awsDatasourceOpensearchserviceConfigPropertyToHclTerraform(struct?: AwsDatasource.OpensearchserviceConfigPropertyOutputReference | AwsDatasource.OpensearchserviceConfigProperty): any;
export declare function awsDatasourceHttpEndpointConfigPropertyToTerraform(struct?: AwsDatasource.HttpEndpointConfigPropertyOutputReference | AwsDatasource.HttpEndpointConfigProperty): any;
export declare function awsDatasourceHttpEndpointConfigPropertyToHclTerraform(struct?: AwsDatasource.HttpEndpointConfigPropertyOutputReference | AwsDatasource.HttpEndpointConfigProperty): any;
export declare function awsDatasourceRelationalDatabaseConfigPropertyToTerraform(struct?: AwsDatasource.RelationalDatabaseConfigPropertyOutputReference | AwsDatasource.RelationalDatabaseConfigProperty): any;
export declare function awsDatasourceRelationalDatabaseConfigPropertyToHclTerraform(struct?: AwsDatasource.RelationalDatabaseConfigPropertyOutputReference | AwsDatasource.RelationalDatabaseConfigProperty): any;
export declare namespace AwsDatasource {
    interface DeltaSyncConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_datasource#base_table_ttl AwsDatasource#base_table_ttl}
        */
        readonly baseTableTtl?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_datasource#delta_sync_table_name AwsDatasource#delta_sync_table_name}
        */
        readonly deltaSyncTableName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_datasource#delta_sync_table_ttl AwsDatasource#delta_sync_table_ttl}
        */
        readonly deltaSyncTableTtl?: number;
    }
    class DeltaSyncConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DeltaSyncConfigProperty | undefined;
        set internalValue(value: DeltaSyncConfigProperty | undefined);
        private _baseTableTtl?;
        get baseTableTtl(): number;
        set baseTableTtl(value: number);
        resetBaseTableTtl(): void;
        get baseTableTtlInput(): number | undefined;
        private _deltaSyncTableName?;
        get deltaSyncTableName(): string;
        set deltaSyncTableName(value: string);
        get deltaSyncTableNameInput(): string | undefined;
        private _deltaSyncTableTtl?;
        get deltaSyncTableTtl(): number;
        set deltaSyncTableTtl(value: number);
        resetDeltaSyncTableTtl(): void;
        get deltaSyncTableTtlInput(): number | undefined;
    }
    interface DynamodbConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_datasource#region AwsDatasource#region}
        */
        readonly region?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_datasource#table_name AwsDatasource#table_name}
        */
        readonly tableName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_datasource#use_caller_credentials AwsDatasource#use_caller_credentials}
        */
        readonly useCallerCredentials?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_datasource#versioned AwsDatasource#versioned}
        */
        readonly versioned?: boolean | cdktn.IResolvable;
        /**
        * delta_sync_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_datasource#delta_sync_config AwsDatasource#delta_sync_config}
        */
        readonly deltaSyncConfig?: DeltaSyncConfigProperty;
    }
    class DynamodbConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DynamodbConfigProperty | undefined;
        set internalValue(value: DynamodbConfigProperty | undefined);
        private _region?;
        get region(): string;
        set region(value: string);
        resetRegion(): void;
        get regionInput(): string | undefined;
        private _tableName?;
        get tableName(): string;
        set tableName(value: string);
        get tableNameInput(): string | undefined;
        private _useCallerCredentials?;
        get useCallerCredentials(): boolean | cdktn.IResolvable;
        set useCallerCredentials(value: boolean | cdktn.IResolvable);
        resetUseCallerCredentials(): void;
        get useCallerCredentialsInput(): boolean | cdktn.IResolvable | undefined;
        private _versioned?;
        get versioned(): boolean | cdktn.IResolvable;
        set versioned(value: boolean | cdktn.IResolvable);
        resetVersioned(): void;
        get versionedInput(): boolean | cdktn.IResolvable | undefined;
        private _deltaSyncConfig;
        get deltaSyncConfig(): DeltaSyncConfigPropertyOutputReference;
        putDeltaSyncConfig(value: DeltaSyncConfigProperty): void;
        resetDeltaSyncConfig(): void;
        get deltaSyncConfigInput(): DeltaSyncConfigProperty | undefined;
    }
    interface ElasticsearchConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_datasource#endpoint AwsDatasource#endpoint}
        */
        readonly endpoint: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_datasource#region AwsDatasource#region}
        */
        readonly region?: string;
    }
    class ElasticsearchConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ElasticsearchConfigProperty | undefined;
        set internalValue(value: ElasticsearchConfigProperty | undefined);
        private _endpoint?;
        get endpoint(): string;
        set endpoint(value: string);
        get endpointInput(): string | undefined;
        private _region?;
        get region(): string;
        set region(value: string);
        resetRegion(): void;
        get regionInput(): string | undefined;
    }
    interface EventBridgeConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_datasource#event_bus_arn AwsDatasource#event_bus_arn}
        */
        readonly eventBusArn: string;
    }
    class EventBridgeConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): EventBridgeConfigProperty | undefined;
        set internalValue(value: EventBridgeConfigProperty | undefined);
        private _eventBusArn?;
        get eventBusArn(): string;
        set eventBusArn(value: string);
        get eventBusArnInput(): string | undefined;
    }
    interface AwsIamConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_datasource#signing_region AwsDatasource#signing_region}
        */
        readonly signingRegion?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_datasource#signing_service_name AwsDatasource#signing_service_name}
        */
        readonly signingServiceName?: string;
    }
    class AwsIamConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AwsIamConfigProperty | undefined;
        set internalValue(value: AwsIamConfigProperty | undefined);
        private _signingRegion?;
        get signingRegion(): string;
        set signingRegion(value: string);
        resetSigningRegion(): void;
        get signingRegionInput(): string | undefined;
        private _signingServiceName?;
        get signingServiceName(): string;
        set signingServiceName(value: string);
        resetSigningServiceName(): void;
        get signingServiceNameInput(): string | undefined;
    }
    interface AuthorizationConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_datasource#authorization_type AwsDatasource#authorization_type}
        */
        readonly authorizationType?: string;
        /**
        * aws_iam_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_datasource#aws_iam_config AwsDatasource#aws_iam_config}
        */
        readonly awsIamConfig?: AwsIamConfigProperty;
    }
    class AuthorizationConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AuthorizationConfigProperty | undefined;
        set internalValue(value: AuthorizationConfigProperty | undefined);
        private _authorizationType?;
        get authorizationType(): string;
        set authorizationType(value: string);
        resetAuthorizationType(): void;
        get authorizationTypeInput(): string | undefined;
        private _awsIamConfig;
        get awsIamConfig(): AwsIamConfigPropertyOutputReference;
        putAwsIamConfig(value: AwsIamConfigProperty): void;
        resetAwsIamConfig(): void;
        get awsIamConfigInput(): AwsIamConfigProperty | undefined;
    }
    interface HttpConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_datasource#endpoint AwsDatasource#endpoint}
        */
        readonly endpoint: string;
        /**
        * authorization_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_datasource#authorization_config AwsDatasource#authorization_config}
        */
        readonly authorizationConfig?: AuthorizationConfigProperty;
    }
    class HttpConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): HttpConfigProperty | undefined;
        set internalValue(value: HttpConfigProperty | undefined);
        private _endpoint?;
        get endpoint(): string;
        set endpoint(value: string);
        get endpointInput(): string | undefined;
        private _authorizationConfig;
        get authorizationConfig(): AuthorizationConfigPropertyOutputReference;
        putAuthorizationConfig(value: AuthorizationConfigProperty): void;
        resetAuthorizationConfig(): void;
        get authorizationConfigInput(): AuthorizationConfigProperty | undefined;
    }
    interface LambdaConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_datasource#function_arn AwsDatasource#function_arn}
        */
        readonly functionArn: string;
    }
    class LambdaConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): LambdaConfigProperty | undefined;
        set internalValue(value: LambdaConfigProperty | undefined);
        private _functionArn?;
        get functionArn(): string;
        set functionArn(value: string);
        get functionArnInput(): string | undefined;
    }
    interface OpensearchserviceConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_datasource#endpoint AwsDatasource#endpoint}
        */
        readonly endpoint: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_datasource#region AwsDatasource#region}
        */
        readonly region?: string;
    }
    class OpensearchserviceConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): OpensearchserviceConfigProperty | undefined;
        set internalValue(value: OpensearchserviceConfigProperty | undefined);
        private _endpoint?;
        get endpoint(): string;
        set endpoint(value: string);
        get endpointInput(): string | undefined;
        private _region?;
        get region(): string;
        set region(value: string);
        resetRegion(): void;
        get regionInput(): string | undefined;
    }
    interface HttpEndpointConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_datasource#aws_secret_store_arn AwsDatasource#aws_secret_store_arn}
        */
        readonly awsSecretStoreArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_datasource#database_name AwsDatasource#database_name}
        */
        readonly databaseName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_datasource#db_cluster_identifier AwsDatasource#db_cluster_identifier}
        */
        readonly dbClusterIdentifier: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_datasource#region AwsDatasource#region}
        */
        readonly region?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_datasource#schema AwsDatasource#schema}
        */
        readonly schema?: string;
    }
    class HttpEndpointConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): HttpEndpointConfigProperty | undefined;
        set internalValue(value: HttpEndpointConfigProperty | undefined);
        private _awsSecretStoreArn?;
        get awsSecretStoreArn(): string;
        set awsSecretStoreArn(value: string);
        get awsSecretStoreArnInput(): string | undefined;
        private _databaseName?;
        get databaseName(): string;
        set databaseName(value: string);
        resetDatabaseName(): void;
        get databaseNameInput(): string | undefined;
        private _dbClusterIdentifier?;
        get dbClusterIdentifier(): string;
        set dbClusterIdentifier(value: string);
        get dbClusterIdentifierInput(): string | undefined;
        private _region?;
        get region(): string;
        set region(value: string);
        resetRegion(): void;
        get regionInput(): string | undefined;
        private _schema?;
        get schema(): string;
        set schema(value: string);
        resetSchema(): void;
        get schemaInput(): string | undefined;
    }
    interface RelationalDatabaseConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_datasource#source_type AwsDatasource#source_type}
        */
        readonly sourceType?: string;
        /**
        * http_endpoint_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_datasource#http_endpoint_config AwsDatasource#http_endpoint_config}
        */
        readonly httpEndpointConfig?: HttpEndpointConfigProperty;
    }
    class RelationalDatabaseConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RelationalDatabaseConfigProperty | undefined;
        set internalValue(value: RelationalDatabaseConfigProperty | undefined);
        private _sourceType?;
        get sourceType(): string;
        set sourceType(value: string);
        resetSourceType(): void;
        get sourceTypeInput(): string | undefined;
        private _httpEndpointConfig;
        get httpEndpointConfig(): HttpEndpointConfigPropertyOutputReference;
        putHttpEndpointConfig(value: HttpEndpointConfigProperty): void;
        resetHttpEndpointConfig(): void;
        get httpEndpointConfigInput(): HttpEndpointConfigProperty | undefined;
    }
}
