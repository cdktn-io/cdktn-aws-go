import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsResolverConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_resolver#api_id AwsResolver#api_id}
    */
    readonly apiId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_resolver#code AwsResolver#code}
    */
    readonly code?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_resolver#data_source AwsResolver#data_source}
    */
    readonly dataSource?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_resolver#field AwsResolver#field}
    */
    readonly field: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_resolver#id AwsResolver#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_resolver#kind AwsResolver#kind}
    */
    readonly kind?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_resolver#max_batch_size AwsResolver#max_batch_size}
    */
    readonly maxBatchSize?: number;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_resolver#region AwsResolver#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_resolver#request_template AwsResolver#request_template}
    */
    readonly requestTemplate?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_resolver#response_template AwsResolver#response_template}
    */
    readonly responseTemplate?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_resolver#type AwsResolver#type}
    */
    readonly type: string;
    /**
    * caching_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_resolver#caching_config AwsResolver#caching_config}
    */
    readonly cachingConfig?: AwsResolver.CachingConfigProperty;
    /**
    * pipeline_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_resolver#pipeline_config AwsResolver#pipeline_config}
    */
    readonly pipelineConfig?: AwsResolver.PipelineConfigProperty;
    /**
    * runtime block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_resolver#runtime AwsResolver#runtime}
    */
    readonly runtime?: AwsResolver.RuntimeProperty;
    /**
    * sync_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_resolver#sync_config AwsResolver#sync_config}
    */
    readonly syncConfig?: AwsResolver.SyncConfigProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_resolver aws_appsync_resolver}
*/
export declare class AwsResolver extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_appsync_resolver";
    /**
    * Generates CDKTN code for importing a AwsResolver resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsResolver to import
    * @param importFromId The id of the existing AwsResolver that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_resolver#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsResolver to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_resolver aws_appsync_resolver} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsResolverConfig
    */
    constructor(scope: Construct, id: string, config: AwsResolverConfig);
    private _apiId?;
    get apiId(): string;
    set apiId(value: string);
    get apiIdInput(): string | undefined;
    get arn(): string;
    private _code?;
    get code(): string;
    set code(value: string);
    resetCode(): void;
    get codeInput(): string | undefined;
    private _dataSource?;
    get dataSource(): string;
    set dataSource(value: string);
    resetDataSource(): void;
    get dataSourceInput(): string | undefined;
    private _field?;
    get field(): string;
    set field(value: string);
    get fieldInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _kind?;
    get kind(): string;
    set kind(value: string);
    resetKind(): void;
    get kindInput(): string | undefined;
    private _maxBatchSize?;
    get maxBatchSize(): number;
    set maxBatchSize(value: number);
    resetMaxBatchSize(): void;
    get maxBatchSizeInput(): number | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _requestTemplate?;
    get requestTemplate(): string;
    set requestTemplate(value: string);
    resetRequestTemplate(): void;
    get requestTemplateInput(): string | undefined;
    private _responseTemplate?;
    get responseTemplate(): string;
    set responseTemplate(value: string);
    resetResponseTemplate(): void;
    get responseTemplateInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _cachingConfig;
    get cachingConfig(): AwsResolver.CachingConfigPropertyOutputReference;
    putCachingConfig(value: AwsResolver.CachingConfigProperty): void;
    resetCachingConfig(): void;
    get cachingConfigInput(): AwsResolver.CachingConfigProperty | undefined;
    private _pipelineConfig;
    get pipelineConfig(): AwsResolver.PipelineConfigPropertyOutputReference;
    putPipelineConfig(value: AwsResolver.PipelineConfigProperty): void;
    resetPipelineConfig(): void;
    get pipelineConfigInput(): AwsResolver.PipelineConfigProperty | undefined;
    private _runtime;
    get runtime(): AwsResolver.RuntimePropertyOutputReference;
    putRuntime(value: AwsResolver.RuntimeProperty): void;
    resetRuntime(): void;
    get runtimeInput(): AwsResolver.RuntimeProperty | undefined;
    private _syncConfig;
    get syncConfig(): AwsResolver.SyncConfigPropertyOutputReference;
    putSyncConfig(value: AwsResolver.SyncConfigProperty): void;
    resetSyncConfig(): void;
    get syncConfigInput(): AwsResolver.SyncConfigProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsResolverCachingConfigPropertyToTerraform(struct?: AwsResolver.CachingConfigPropertyOutputReference | AwsResolver.CachingConfigProperty): any;
export declare function awsResolverCachingConfigPropertyToHclTerraform(struct?: AwsResolver.CachingConfigPropertyOutputReference | AwsResolver.CachingConfigProperty): any;
export declare function awsResolverPipelineConfigPropertyToTerraform(struct?: AwsResolver.PipelineConfigPropertyOutputReference | AwsResolver.PipelineConfigProperty): any;
export declare function awsResolverPipelineConfigPropertyToHclTerraform(struct?: AwsResolver.PipelineConfigPropertyOutputReference | AwsResolver.PipelineConfigProperty): any;
export declare function awsResolverRuntimePropertyToTerraform(struct?: AwsResolver.RuntimePropertyOutputReference | AwsResolver.RuntimeProperty): any;
export declare function awsResolverRuntimePropertyToHclTerraform(struct?: AwsResolver.RuntimePropertyOutputReference | AwsResolver.RuntimeProperty): any;
export declare function awsResolverLambdaConflictHandlerConfigPropertyToTerraform(struct?: AwsResolver.LambdaConflictHandlerConfigPropertyOutputReference | AwsResolver.LambdaConflictHandlerConfigProperty): any;
export declare function awsResolverLambdaConflictHandlerConfigPropertyToHclTerraform(struct?: AwsResolver.LambdaConflictHandlerConfigPropertyOutputReference | AwsResolver.LambdaConflictHandlerConfigProperty): any;
export declare function awsResolverSyncConfigPropertyToTerraform(struct?: AwsResolver.SyncConfigPropertyOutputReference | AwsResolver.SyncConfigProperty): any;
export declare function awsResolverSyncConfigPropertyToHclTerraform(struct?: AwsResolver.SyncConfigPropertyOutputReference | AwsResolver.SyncConfigProperty): any;
export declare namespace AwsResolver {
    interface CachingConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_resolver#caching_keys AwsResolver#caching_keys}
        */
        readonly cachingKeys?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_resolver#ttl AwsResolver#ttl}
        */
        readonly ttl?: number;
    }
    class CachingConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CachingConfigProperty | undefined;
        set internalValue(value: CachingConfigProperty | undefined);
        private _cachingKeys?;
        get cachingKeys(): string[];
        set cachingKeys(value: string[]);
        resetCachingKeys(): void;
        get cachingKeysInput(): string[] | undefined;
        private _ttl?;
        get ttl(): number;
        set ttl(value: number);
        resetTtl(): void;
        get ttlInput(): number | undefined;
    }
    interface PipelineConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_resolver#functions AwsResolver#functions}
        */
        readonly functions?: string[];
    }
    class PipelineConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): PipelineConfigProperty | undefined;
        set internalValue(value: PipelineConfigProperty | undefined);
        private _functions?;
        get functions(): string[];
        set functions(value: string[]);
        resetFunctions(): void;
        get functionsInput(): string[] | undefined;
    }
    interface RuntimeProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_resolver#name AwsResolver#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_resolver#runtime_version AwsResolver#runtime_version}
        */
        readonly runtimeVersion: string;
    }
    class RuntimePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RuntimeProperty | undefined;
        set internalValue(value: RuntimeProperty | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _runtimeVersion?;
        get runtimeVersion(): string;
        set runtimeVersion(value: string);
        get runtimeVersionInput(): string | undefined;
    }
    interface LambdaConflictHandlerConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_resolver#lambda_conflict_handler_arn AwsResolver#lambda_conflict_handler_arn}
        */
        readonly lambdaConflictHandlerArn?: string;
    }
    class LambdaConflictHandlerConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): LambdaConflictHandlerConfigProperty | undefined;
        set internalValue(value: LambdaConflictHandlerConfigProperty | undefined);
        private _lambdaConflictHandlerArn?;
        get lambdaConflictHandlerArn(): string;
        set lambdaConflictHandlerArn(value: string);
        resetLambdaConflictHandlerArn(): void;
        get lambdaConflictHandlerArnInput(): string | undefined;
    }
    interface SyncConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_resolver#conflict_detection AwsResolver#conflict_detection}
        */
        readonly conflictDetection?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_resolver#conflict_handler AwsResolver#conflict_handler}
        */
        readonly conflictHandler?: string;
        /**
        * lambda_conflict_handler_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_resolver#lambda_conflict_handler_config AwsResolver#lambda_conflict_handler_config}
        */
        readonly lambdaConflictHandlerConfig?: LambdaConflictHandlerConfigProperty;
    }
    class SyncConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SyncConfigProperty | undefined;
        set internalValue(value: SyncConfigProperty | undefined);
        private _conflictDetection?;
        get conflictDetection(): string;
        set conflictDetection(value: string);
        resetConflictDetection(): void;
        get conflictDetectionInput(): string | undefined;
        private _conflictHandler?;
        get conflictHandler(): string;
        set conflictHandler(value: string);
        resetConflictHandler(): void;
        get conflictHandlerInput(): string | undefined;
        private _lambdaConflictHandlerConfig;
        get lambdaConflictHandlerConfig(): LambdaConflictHandlerConfigPropertyOutputReference;
        putLambdaConflictHandlerConfig(value: LambdaConflictHandlerConfigProperty): void;
        resetLambdaConflictHandlerConfig(): void;
        get lambdaConflictHandlerConfigInput(): LambdaConflictHandlerConfigProperty | undefined;
    }
}
