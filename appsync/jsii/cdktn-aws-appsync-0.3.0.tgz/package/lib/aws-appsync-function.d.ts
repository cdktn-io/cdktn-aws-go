import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsFunctionConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_function#api_id AwsFunction#api_id}
    */
    readonly apiId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_function#code AwsFunction#code}
    */
    readonly code?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_function#data_source AwsFunction#data_source}
    */
    readonly dataSource: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_function#description AwsFunction#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_function#function_version AwsFunction#function_version}
    */
    readonly functionVersion?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_function#id AwsFunction#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_function#max_batch_size AwsFunction#max_batch_size}
    */
    readonly maxBatchSize?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_function#name AwsFunction#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_function#region AwsFunction#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_function#request_mapping_template AwsFunction#request_mapping_template}
    */
    readonly requestMappingTemplate?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_function#response_mapping_template AwsFunction#response_mapping_template}
    */
    readonly responseMappingTemplate?: string;
    /**
    * runtime block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_function#runtime AwsFunction#runtime}
    */
    readonly runtime?: AwsFunction.RuntimeProperty;
    /**
    * sync_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_function#sync_config AwsFunction#sync_config}
    */
    readonly syncConfig?: AwsFunction.SyncConfigProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_function aws_appsync_function}
*/
export declare class AwsFunction extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_appsync_function";
    /**
    * Generates CDKTN code for importing a AwsFunction resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsFunction to import
    * @param importFromId The id of the existing AwsFunction that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_function#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsFunction to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_function aws_appsync_function} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsFunctionConfig
    */
    constructor(scope: Construct, id: string, config: AwsFunctionConfig);
    private _apiId?;
    get apiId(): string;
    set apiId(value: string);
    get apiIdInput(): string | undefined;
    get arn(): string;
    private _code?;
    get code(): string;
    set code(value: string);
    resetCode(): void;
    get codeInput(): string | undefined;
    private _dataSource?;
    get dataSource(): string;
    set dataSource(value: string);
    get dataSourceInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get functionId(): string;
    private _functionVersion?;
    get functionVersion(): string;
    set functionVersion(value: string);
    resetFunctionVersion(): void;
    get functionVersionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _maxBatchSize?;
    get maxBatchSize(): number;
    set maxBatchSize(value: number);
    resetMaxBatchSize(): void;
    get maxBatchSizeInput(): number | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _requestMappingTemplate?;
    get requestMappingTemplate(): string;
    set requestMappingTemplate(value: string);
    resetRequestMappingTemplate(): void;
    get requestMappingTemplateInput(): string | undefined;
    private _responseMappingTemplate?;
    get responseMappingTemplate(): string;
    set responseMappingTemplate(value: string);
    resetResponseMappingTemplate(): void;
    get responseMappingTemplateInput(): string | undefined;
    private _runtime;
    get runtime(): AwsFunction.RuntimePropertyOutputReference;
    putRuntime(value: AwsFunction.RuntimeProperty): void;
    resetRuntime(): void;
    get runtimeInput(): AwsFunction.RuntimeProperty | undefined;
    private _syncConfig;
    get syncConfig(): AwsFunction.SyncConfigPropertyOutputReference;
    putSyncConfig(value: AwsFunction.SyncConfigProperty): void;
    resetSyncConfig(): void;
    get syncConfigInput(): AwsFunction.SyncConfigProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsFunctionRuntimePropertyToTerraform(struct?: AwsFunction.RuntimePropertyOutputReference | AwsFunction.RuntimeProperty): any;
export declare function awsFunctionRuntimePropertyToHclTerraform(struct?: AwsFunction.RuntimePropertyOutputReference | AwsFunction.RuntimeProperty): any;
export declare function awsFunctionLambdaConflictHandlerConfigPropertyToTerraform(struct?: AwsFunction.LambdaConflictHandlerConfigPropertyOutputReference | AwsFunction.LambdaConflictHandlerConfigProperty): any;
export declare function awsFunctionLambdaConflictHandlerConfigPropertyToHclTerraform(struct?: AwsFunction.LambdaConflictHandlerConfigPropertyOutputReference | AwsFunction.LambdaConflictHandlerConfigProperty): any;
export declare function awsFunctionSyncConfigPropertyToTerraform(struct?: AwsFunction.SyncConfigPropertyOutputReference | AwsFunction.SyncConfigProperty): any;
export declare function awsFunctionSyncConfigPropertyToHclTerraform(struct?: AwsFunction.SyncConfigPropertyOutputReference | AwsFunction.SyncConfigProperty): any;
export declare namespace AwsFunction {
    interface RuntimeProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_function#name AwsFunction#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_function#runtime_version AwsFunction#runtime_version}
        */
        readonly runtimeVersion: string;
    }
    class RuntimePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RuntimeProperty | undefined;
        set internalValue(value: RuntimeProperty | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _runtimeVersion?;
        get runtimeVersion(): string;
        set runtimeVersion(value: string);
        get runtimeVersionInput(): string | undefined;
    }
    interface LambdaConflictHandlerConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_function#lambda_conflict_handler_arn AwsFunction#lambda_conflict_handler_arn}
        */
        readonly lambdaConflictHandlerArn?: string;
    }
    class LambdaConflictHandlerConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): LambdaConflictHandlerConfigProperty | undefined;
        set internalValue(value: LambdaConflictHandlerConfigProperty | undefined);
        private _lambdaConflictHandlerArn?;
        get lambdaConflictHandlerArn(): string;
        set lambdaConflictHandlerArn(value: string);
        resetLambdaConflictHandlerArn(): void;
        get lambdaConflictHandlerArnInput(): string | undefined;
    }
    interface SyncConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_function#conflict_detection AwsFunction#conflict_detection}
        */
        readonly conflictDetection?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_function#conflict_handler AwsFunction#conflict_handler}
        */
        readonly conflictHandler?: string;
        /**
        * lambda_conflict_handler_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_function#lambda_conflict_handler_config AwsFunction#lambda_conflict_handler_config}
        */
        readonly lambdaConflictHandlerConfig?: LambdaConflictHandlerConfigProperty;
    }
    class SyncConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SyncConfigProperty | undefined;
        set internalValue(value: SyncConfigProperty | undefined);
        private _conflictDetection?;
        get conflictDetection(): string;
        set conflictDetection(value: string);
        resetConflictDetection(): void;
        get conflictDetectionInput(): string | undefined;
        private _conflictHandler?;
        get conflictHandler(): string;
        set conflictHandler(value: string);
        resetConflictHandler(): void;
        get conflictHandlerInput(): string | undefined;
        private _lambdaConflictHandlerConfig;
        get lambdaConflictHandlerConfig(): LambdaConflictHandlerConfigPropertyOutputReference;
        putLambdaConflictHandlerConfig(value: LambdaConflictHandlerConfigProperty): void;
        resetLambdaConflictHandlerConfig(): void;
        get lambdaConflictHandlerConfigInput(): LambdaConflictHandlerConfigProperty | undefined;
    }
}
