import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsApiConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_api#name AwsApi#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_api#owner_contact AwsApi#owner_contact}
    */
    readonly ownerContact?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_api#region AwsApi#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_api#tags AwsApi#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * event_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_api#event_config AwsApi#event_config}
    */
    readonly eventConfig?: AwsApi.EventConfigProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_api aws_appsync_api}
*/
export declare class AwsApi extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_appsync_api";
    /**
    * Generates CDKTN code for importing a AwsApi resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsApi to import
    * @param importFromId The id of the existing AwsApi that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_api#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsApi to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_api aws_appsync_api} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsApiConfig
    */
    constructor(scope: Construct, id: string, config: AwsApiConfig);
    get apiArn(): string;
    get apiId(): string;
    private _dns;
    get dns(): cdktn.StringMap;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _ownerContact?;
    get ownerContact(): string;
    set ownerContact(value: string);
    resetOwnerContact(): void;
    get ownerContactInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    get wafWebAclArn(): string;
    get xrayEnabled(): cdktn.IResolvable;
    private _eventConfig;
    get eventConfig(): AwsApi.EventConfigPropertyList;
    putEventConfig(value: AwsApi.EventConfigProperty[] | cdktn.IResolvable): void;
    resetEventConfig(): void;
    get eventConfigInput(): cdktn.IResolvable | AwsApi.EventConfigProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsApiCognitoConfigPropertyToTerraform(struct?: AwsApi.CognitoConfigProperty | cdktn.IResolvable): any;
export declare function awsApiCognitoConfigPropertyToHclTerraform(struct?: AwsApi.CognitoConfigProperty | cdktn.IResolvable): any;
export declare function awsApiLambdaAuthorizerConfigPropertyToTerraform(struct?: AwsApi.LambdaAuthorizerConfigProperty | cdktn.IResolvable): any;
export declare function awsApiLambdaAuthorizerConfigPropertyToHclTerraform(struct?: AwsApi.LambdaAuthorizerConfigProperty | cdktn.IResolvable): any;
export declare function awsApiOpenidConnectConfigPropertyToTerraform(struct?: AwsApi.OpenidConnectConfigProperty | cdktn.IResolvable): any;
export declare function awsApiOpenidConnectConfigPropertyToHclTerraform(struct?: AwsApi.OpenidConnectConfigProperty | cdktn.IResolvable): any;
export declare function awsApiAuthProviderPropertyToTerraform(struct?: AwsApi.AuthProviderProperty | cdktn.IResolvable): any;
export declare function awsApiAuthProviderPropertyToHclTerraform(struct?: AwsApi.AuthProviderProperty | cdktn.IResolvable): any;
export declare function awsApiConnectionAuthModePropertyToTerraform(struct?: AwsApi.ConnectionAuthModeProperty | cdktn.IResolvable): any;
export declare function awsApiConnectionAuthModePropertyToHclTerraform(struct?: AwsApi.ConnectionAuthModeProperty | cdktn.IResolvable): any;
export declare function awsApiDefaultPublishAuthModePropertyToTerraform(struct?: AwsApi.DefaultPublishAuthModeProperty | cdktn.IResolvable): any;
export declare function awsApiDefaultPublishAuthModePropertyToHclTerraform(struct?: AwsApi.DefaultPublishAuthModeProperty | cdktn.IResolvable): any;
export declare function awsApiDefaultSubscribeAuthModePropertyToTerraform(struct?: AwsApi.DefaultSubscribeAuthModeProperty | cdktn.IResolvable): any;
export declare function awsApiDefaultSubscribeAuthModePropertyToHclTerraform(struct?: AwsApi.DefaultSubscribeAuthModeProperty | cdktn.IResolvable): any;
export declare function awsApiLogConfigPropertyToTerraform(struct?: AwsApi.LogConfigProperty | cdktn.IResolvable): any;
export declare function awsApiLogConfigPropertyToHclTerraform(struct?: AwsApi.LogConfigProperty | cdktn.IResolvable): any;
export declare function awsApiEventConfigPropertyToTerraform(struct?: AwsApi.EventConfigProperty | cdktn.IResolvable): any;
export declare function awsApiEventConfigPropertyToHclTerraform(struct?: AwsApi.EventConfigProperty | cdktn.IResolvable): any;
export declare namespace AwsApi {
    interface CognitoConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_api#app_id_client_regex AwsApi#app_id_client_regex}
        */
        readonly appIdClientRegex?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_api#aws_region AwsApi#aws_region}
        */
        readonly awsRegion: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_api#user_pool_id AwsApi#user_pool_id}
        */
        readonly userPoolId: string;
    }
    class CognitoConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CognitoConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CognitoConfigProperty | cdktn.IResolvable | undefined);
        private _appIdClientRegex?;
        get appIdClientRegex(): string;
        set appIdClientRegex(value: string);
        resetAppIdClientRegex(): void;
        get appIdClientRegexInput(): string | undefined;
        private _awsRegion?;
        get awsRegion(): string;
        set awsRegion(value: string);
        get awsRegionInput(): string | undefined;
        private _userPoolId?;
        get userPoolId(): string;
        set userPoolId(value: string);
        get userPoolIdInput(): string | undefined;
    }
    class CognitoConfigPropertyList extends cdktn.ComplexList {
        internalValue?: CognitoConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CognitoConfigPropertyOutputReference;
    }
    interface LambdaAuthorizerConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_api#authorizer_result_ttl_in_seconds AwsApi#authorizer_result_ttl_in_seconds}
        */
        readonly authorizerResultTtlInSeconds?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_api#authorizer_uri AwsApi#authorizer_uri}
        */
        readonly authorizerUri: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_api#identity_validation_expression AwsApi#identity_validation_expression}
        */
        readonly identityValidationExpression?: string;
    }
    class LambdaAuthorizerConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): LambdaAuthorizerConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: LambdaAuthorizerConfigProperty | cdktn.IResolvable | undefined);
        private _authorizerResultTtlInSeconds?;
        get authorizerResultTtlInSeconds(): number;
        set authorizerResultTtlInSeconds(value: number);
        resetAuthorizerResultTtlInSeconds(): void;
        get authorizerResultTtlInSecondsInput(): number | undefined;
        private _authorizerUri?;
        get authorizerUri(): string;
        set authorizerUri(value: string);
        get authorizerUriInput(): string | undefined;
        private _identityValidationExpression?;
        get identityValidationExpression(): string;
        set identityValidationExpression(value: string);
        resetIdentityValidationExpression(): void;
        get identityValidationExpressionInput(): string | undefined;
    }
    class LambdaAuthorizerConfigPropertyList extends cdktn.ComplexList {
        internalValue?: LambdaAuthorizerConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): LambdaAuthorizerConfigPropertyOutputReference;
    }
    interface OpenidConnectConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_api#auth_ttl AwsApi#auth_ttl}
        */
        readonly authTtl?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_api#client_id AwsApi#client_id}
        */
        readonly clientId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_api#iat_ttl AwsApi#iat_ttl}
        */
        readonly iatTtl?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_api#issuer AwsApi#issuer}
        */
        readonly issuer: string;
    }
    class OpenidConnectConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): OpenidConnectConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: OpenidConnectConfigProperty | cdktn.IResolvable | undefined);
        private _authTtl?;
        get authTtl(): number;
        set authTtl(value: number);
        resetAuthTtl(): void;
        get authTtlInput(): number | undefined;
        private _clientId?;
        get clientId(): string;
        set clientId(value: string);
        resetClientId(): void;
        get clientIdInput(): string | undefined;
        private _iatTtl?;
        get iatTtl(): number;
        set iatTtl(value: number);
        resetIatTtl(): void;
        get iatTtlInput(): number | undefined;
        private _issuer?;
        get issuer(): string;
        set issuer(value: string);
        get issuerInput(): string | undefined;
    }
    class OpenidConnectConfigPropertyList extends cdktn.ComplexList {
        internalValue?: OpenidConnectConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): OpenidConnectConfigPropertyOutputReference;
    }
    interface AuthProviderProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_api#auth_type AwsApi#auth_type}
        */
        readonly authType: string;
        /**
        * cognito_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_api#cognito_config AwsApi#cognito_config}
        */
        readonly cognitoConfig?: CognitoConfigProperty[] | cdktn.IResolvable;
        /**
        * lambda_authorizer_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_api#lambda_authorizer_config AwsApi#lambda_authorizer_config}
        */
        readonly lambdaAuthorizerConfig?: LambdaAuthorizerConfigProperty[] | cdktn.IResolvable;
        /**
        * openid_connect_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_api#openid_connect_config AwsApi#openid_connect_config}
        */
        readonly openidConnectConfig?: OpenidConnectConfigProperty[] | cdktn.IResolvable;
    }
    class AuthProviderPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AuthProviderProperty | cdktn.IResolvable | undefined;
        set internalValue(value: AuthProviderProperty | cdktn.IResolvable | undefined);
        private _authType?;
        get authType(): string;
        set authType(value: string);
        get authTypeInput(): string | undefined;
        private _cognitoConfig;
        get cognitoConfig(): CognitoConfigPropertyList;
        putCognitoConfig(value: CognitoConfigProperty[] | cdktn.IResolvable): void;
        resetCognitoConfig(): void;
        get cognitoConfigInput(): cdktn.IResolvable | CognitoConfigProperty[] | undefined;
        private _lambdaAuthorizerConfig;
        get lambdaAuthorizerConfig(): LambdaAuthorizerConfigPropertyList;
        putLambdaAuthorizerConfig(value: LambdaAuthorizerConfigProperty[] | cdktn.IResolvable): void;
        resetLambdaAuthorizerConfig(): void;
        get lambdaAuthorizerConfigInput(): cdktn.IResolvable | LambdaAuthorizerConfigProperty[] | undefined;
        private _openidConnectConfig;
        get openidConnectConfig(): OpenidConnectConfigPropertyList;
        putOpenidConnectConfig(value: OpenidConnectConfigProperty[] | cdktn.IResolvable): void;
        resetOpenidConnectConfig(): void;
        get openidConnectConfigInput(): cdktn.IResolvable | OpenidConnectConfigProperty[] | undefined;
    }
    class AuthProviderPropertyList extends cdktn.ComplexList {
        internalValue?: AuthProviderProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AuthProviderPropertyOutputReference;
    }
    interface ConnectionAuthModeProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_api#auth_type AwsApi#auth_type}
        */
        readonly authType: string;
    }
    class ConnectionAuthModePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ConnectionAuthModeProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ConnectionAuthModeProperty | cdktn.IResolvable | undefined);
        private _authType?;
        get authType(): string;
        set authType(value: string);
        get authTypeInput(): string | undefined;
    }
    class ConnectionAuthModePropertyList extends cdktn.ComplexList {
        internalValue?: ConnectionAuthModeProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ConnectionAuthModePropertyOutputReference;
    }
    interface DefaultPublishAuthModeProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_api#auth_type AwsApi#auth_type}
        */
        readonly authType: string;
    }
    class DefaultPublishAuthModePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DefaultPublishAuthModeProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DefaultPublishAuthModeProperty | cdktn.IResolvable | undefined);
        private _authType?;
        get authType(): string;
        set authType(value: string);
        get authTypeInput(): string | undefined;
    }
    class DefaultPublishAuthModePropertyList extends cdktn.ComplexList {
        internalValue?: DefaultPublishAuthModeProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DefaultPublishAuthModePropertyOutputReference;
    }
    interface DefaultSubscribeAuthModeProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_api#auth_type AwsApi#auth_type}
        */
        readonly authType: string;
    }
    class DefaultSubscribeAuthModePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DefaultSubscribeAuthModeProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DefaultSubscribeAuthModeProperty | cdktn.IResolvable | undefined);
        private _authType?;
        get authType(): string;
        set authType(value: string);
        get authTypeInput(): string | undefined;
    }
    class DefaultSubscribeAuthModePropertyList extends cdktn.ComplexList {
        internalValue?: DefaultSubscribeAuthModeProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DefaultSubscribeAuthModePropertyOutputReference;
    }
    interface LogConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_api#cloudwatch_logs_role_arn AwsApi#cloudwatch_logs_role_arn}
        */
        readonly cloudwatchLogsRoleArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_api#log_level AwsApi#log_level}
        */
        readonly logLevel: string;
    }
    class LogConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): LogConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: LogConfigProperty | cdktn.IResolvable | undefined);
        private _cloudwatchLogsRoleArn?;
        get cloudwatchLogsRoleArn(): string;
        set cloudwatchLogsRoleArn(value: string);
        get cloudwatchLogsRoleArnInput(): string | undefined;
        private _logLevel?;
        get logLevel(): string;
        set logLevel(value: string);
        get logLevelInput(): string | undefined;
    }
    class LogConfigPropertyList extends cdktn.ComplexList {
        internalValue?: LogConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): LogConfigPropertyOutputReference;
    }
    interface EventConfigProperty {
        /**
        * auth_provider block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_api#auth_provider AwsApi#auth_provider}
        */
        readonly authProvider?: AuthProviderProperty[] | cdktn.IResolvable;
        /**
        * connection_auth_mode block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_api#connection_auth_mode AwsApi#connection_auth_mode}
        */
        readonly connectionAuthMode?: ConnectionAuthModeProperty[] | cdktn.IResolvable;
        /**
        * default_publish_auth_mode block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_api#default_publish_auth_mode AwsApi#default_publish_auth_mode}
        */
        readonly defaultPublishAuthMode?: DefaultPublishAuthModeProperty[] | cdktn.IResolvable;
        /**
        * default_subscribe_auth_mode block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_api#default_subscribe_auth_mode AwsApi#default_subscribe_auth_mode}
        */
        readonly defaultSubscribeAuthMode?: DefaultSubscribeAuthModeProperty[] | cdktn.IResolvable;
        /**
        * log_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_api#log_config AwsApi#log_config}
        */
        readonly logConfig?: LogConfigProperty[] | cdktn.IResolvable;
    }
    class EventConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EventConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: EventConfigProperty | cdktn.IResolvable | undefined);
        private _authProvider;
        get authProvider(): AuthProviderPropertyList;
        putAuthProvider(value: AuthProviderProperty[] | cdktn.IResolvable): void;
        resetAuthProvider(): void;
        get authProviderInput(): cdktn.IResolvable | AuthProviderProperty[] | undefined;
        private _connectionAuthMode;
        get connectionAuthMode(): ConnectionAuthModePropertyList;
        putConnectionAuthMode(value: ConnectionAuthModeProperty[] | cdktn.IResolvable): void;
        resetConnectionAuthMode(): void;
        get connectionAuthModeInput(): cdktn.IResolvable | ConnectionAuthModeProperty[] | undefined;
        private _defaultPublishAuthMode;
        get defaultPublishAuthMode(): DefaultPublishAuthModePropertyList;
        putDefaultPublishAuthMode(value: DefaultPublishAuthModeProperty[] | cdktn.IResolvable): void;
        resetDefaultPublishAuthMode(): void;
        get defaultPublishAuthModeInput(): cdktn.IResolvable | DefaultPublishAuthModeProperty[] | undefined;
        private _defaultSubscribeAuthMode;
        get defaultSubscribeAuthMode(): DefaultSubscribeAuthModePropertyList;
        putDefaultSubscribeAuthMode(value: DefaultSubscribeAuthModeProperty[] | cdktn.IResolvable): void;
        resetDefaultSubscribeAuthMode(): void;
        get defaultSubscribeAuthModeInput(): cdktn.IResolvable | DefaultSubscribeAuthModeProperty[] | undefined;
        private _logConfig;
        get logConfig(): LogConfigPropertyList;
        putLogConfig(value: LogConfigProperty[] | cdktn.IResolvable): void;
        resetLogConfig(): void;
        get logConfigInput(): cdktn.IResolvable | LogConfigProperty[] | undefined;
    }
    class EventConfigPropertyList extends cdktn.ComplexList {
        internalValue?: EventConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EventConfigPropertyOutputReference;
    }
}
