import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsGraphqlApiConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_graphql_api#api_type AwsGraphqlApi#api_type}
    */
    readonly apiType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_graphql_api#authentication_type AwsGraphqlApi#authentication_type}
    */
    readonly authenticationType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_graphql_api#id AwsGraphqlApi#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_graphql_api#introspection_config AwsGraphqlApi#introspection_config}
    */
    readonly introspectionConfig?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_graphql_api#merged_api_execution_role_arn AwsGraphqlApi#merged_api_execution_role_arn}
    */
    readonly mergedApiExecutionRoleArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_graphql_api#name AwsGraphqlApi#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_graphql_api#query_depth_limit AwsGraphqlApi#query_depth_limit}
    */
    readonly queryDepthLimit?: number;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_graphql_api#region AwsGraphqlApi#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_graphql_api#resolver_count_limit AwsGraphqlApi#resolver_count_limit}
    */
    readonly resolverCountLimit?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_graphql_api#schema AwsGraphqlApi#schema}
    */
    readonly schema?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_graphql_api#tags AwsGraphqlApi#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_graphql_api#tags_all AwsGraphqlApi#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_graphql_api#visibility AwsGraphqlApi#visibility}
    */
    readonly visibility?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_graphql_api#xray_enabled AwsGraphqlApi#xray_enabled}
    */
    readonly xrayEnabled?: boolean | cdktn.IResolvable;
    /**
    * additional_authentication_provider block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_graphql_api#additional_authentication_provider AwsGraphqlApi#additional_authentication_provider}
    */
    readonly additionalAuthenticationProvider?: AwsGraphqlApi.AdditionalAuthenticationProviderProperty[] | cdktn.IResolvable;
    /**
    * enhanced_metrics_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_graphql_api#enhanced_metrics_config AwsGraphqlApi#enhanced_metrics_config}
    */
    readonly enhancedMetricsConfig?: AwsGraphqlApi.EnhancedMetricsConfigProperty;
    /**
    * lambda_authorizer_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_graphql_api#lambda_authorizer_config AwsGraphqlApi#lambda_authorizer_config}
    */
    readonly lambdaAuthorizerConfig?: AwsGraphqlApi.LambdaAuthorizerConfigProperty;
    /**
    * log_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_graphql_api#log_config AwsGraphqlApi#log_config}
    */
    readonly logConfig?: AwsGraphqlApi.LogConfigProperty;
    /**
    * openid_connect_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_graphql_api#openid_connect_config AwsGraphqlApi#openid_connect_config}
    */
    readonly openidConnectConfig?: AwsGraphqlApi.OpenidConnectConfigProperty;
    /**
    * user_pool_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_graphql_api#user_pool_config AwsGraphqlApi#user_pool_config}
    */
    readonly userPoolConfig?: AwsGraphqlApi.UserPoolConfigProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_graphql_api aws_appsync_graphql_api}
*/
export declare class AwsGraphqlApi extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_appsync_graphql_api";
    /**
    * Generates CDKTN code for importing a AwsGraphqlApi resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsGraphqlApi to import
    * @param importFromId The id of the existing AwsGraphqlApi that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_graphql_api#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsGraphqlApi to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_graphql_api aws_appsync_graphql_api} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsGraphqlApiConfig
    */
    constructor(scope: Construct, id: string, config: AwsGraphqlApiConfig);
    private _apiType?;
    get apiType(): string;
    set apiType(value: string);
    resetApiType(): void;
    get apiTypeInput(): string | undefined;
    get arn(): string;
    private _authenticationType?;
    get authenticationType(): string;
    set authenticationType(value: string);
    get authenticationTypeInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _introspectionConfig?;
    get introspectionConfig(): string;
    set introspectionConfig(value: string);
    resetIntrospectionConfig(): void;
    get introspectionConfigInput(): string | undefined;
    private _mergedApiExecutionRoleArn?;
    get mergedApiExecutionRoleArn(): string;
    set mergedApiExecutionRoleArn(value: string);
    resetMergedApiExecutionRoleArn(): void;
    get mergedApiExecutionRoleArnInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _queryDepthLimit?;
    get queryDepthLimit(): number;
    set queryDepthLimit(value: number);
    resetQueryDepthLimit(): void;
    get queryDepthLimitInput(): number | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _resolverCountLimit?;
    get resolverCountLimit(): number;
    set resolverCountLimit(value: number);
    resetResolverCountLimit(): void;
    get resolverCountLimitInput(): number | undefined;
    private _schema?;
    get schema(): string;
    set schema(value: string);
    resetSchema(): void;
    get schemaInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _uris;
    get uris(): cdktn.StringMap;
    private _visibility?;
    get visibility(): string;
    set visibility(value: string);
    resetVisibility(): void;
    get visibilityInput(): string | undefined;
    private _xrayEnabled?;
    get xrayEnabled(): boolean | cdktn.IResolvable;
    set xrayEnabled(value: boolean | cdktn.IResolvable);
    resetXrayEnabled(): void;
    get xrayEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _additionalAuthenticationProvider;
    get additionalAuthenticationProvider(): AwsGraphqlApi.AdditionalAuthenticationProviderPropertyList;
    putAdditionalAuthenticationProvider(value: AwsGraphqlApi.AdditionalAuthenticationProviderProperty[] | cdktn.IResolvable): void;
    resetAdditionalAuthenticationProvider(): void;
    get additionalAuthenticationProviderInput(): cdktn.IResolvable | AwsGraphqlApi.AdditionalAuthenticationProviderProperty[] | undefined;
    private _enhancedMetricsConfig;
    get enhancedMetricsConfig(): AwsGraphqlApi.EnhancedMetricsConfigPropertyOutputReference;
    putEnhancedMetricsConfig(value: AwsGraphqlApi.EnhancedMetricsConfigProperty): void;
    resetEnhancedMetricsConfig(): void;
    get enhancedMetricsConfigInput(): AwsGraphqlApi.EnhancedMetricsConfigProperty | undefined;
    private _lambdaAuthorizerConfig;
    get lambdaAuthorizerConfig(): AwsGraphqlApi.LambdaAuthorizerConfigPropertyOutputReference;
    putLambdaAuthorizerConfig(value: AwsGraphqlApi.LambdaAuthorizerConfigProperty): void;
    resetLambdaAuthorizerConfig(): void;
    get lambdaAuthorizerConfigInput(): AwsGraphqlApi.LambdaAuthorizerConfigProperty | undefined;
    private _logConfig;
    get logConfig(): AwsGraphqlApi.LogConfigPropertyOutputReference;
    putLogConfig(value: AwsGraphqlApi.LogConfigProperty): void;
    resetLogConfig(): void;
    get logConfigInput(): AwsGraphqlApi.LogConfigProperty | undefined;
    private _openidConnectConfig;
    get openidConnectConfig(): AwsGraphqlApi.OpenidConnectConfigPropertyOutputReference;
    putOpenidConnectConfig(value: AwsGraphqlApi.OpenidConnectConfigProperty): void;
    resetOpenidConnectConfig(): void;
    get openidConnectConfigInput(): AwsGraphqlApi.OpenidConnectConfigProperty | undefined;
    private _userPoolConfig;
    get userPoolConfig(): AwsGraphqlApi.UserPoolConfigPropertyOutputReference;
    putUserPoolConfig(value: AwsGraphqlApi.UserPoolConfigProperty): void;
    resetUserPoolConfig(): void;
    get userPoolConfigInput(): AwsGraphqlApi.UserPoolConfigProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsGraphqlApiAdditionalAuthenticationProviderLambdaAuthorizerConfigPropertyToTerraform(struct?: AwsGraphqlApi.AdditionalAuthenticationProviderLambdaAuthorizerConfigPropertyOutputReference | AwsGraphqlApi.AdditionalAuthenticationProviderLambdaAuthorizerConfigProperty): any;
export declare function awsGraphqlApiAdditionalAuthenticationProviderLambdaAuthorizerConfigPropertyToHclTerraform(struct?: AwsGraphqlApi.AdditionalAuthenticationProviderLambdaAuthorizerConfigPropertyOutputReference | AwsGraphqlApi.AdditionalAuthenticationProviderLambdaAuthorizerConfigProperty): any;
export declare function awsGraphqlApiAdditionalAuthenticationProviderOpenidConnectConfigPropertyToTerraform(struct?: AwsGraphqlApi.AdditionalAuthenticationProviderOpenidConnectConfigPropertyOutputReference | AwsGraphqlApi.AdditionalAuthenticationProviderOpenidConnectConfigProperty): any;
export declare function awsGraphqlApiAdditionalAuthenticationProviderOpenidConnectConfigPropertyToHclTerraform(struct?: AwsGraphqlApi.AdditionalAuthenticationProviderOpenidConnectConfigPropertyOutputReference | AwsGraphqlApi.AdditionalAuthenticationProviderOpenidConnectConfigProperty): any;
export declare function awsGraphqlApiAdditionalAuthenticationProviderUserPoolConfigPropertyToTerraform(struct?: AwsGraphqlApi.AdditionalAuthenticationProviderUserPoolConfigPropertyOutputReference | AwsGraphqlApi.AdditionalAuthenticationProviderUserPoolConfigProperty): any;
export declare function awsGraphqlApiAdditionalAuthenticationProviderUserPoolConfigPropertyToHclTerraform(struct?: AwsGraphqlApi.AdditionalAuthenticationProviderUserPoolConfigPropertyOutputReference | AwsGraphqlApi.AdditionalAuthenticationProviderUserPoolConfigProperty): any;
export declare function awsGraphqlApiAdditionalAuthenticationProviderPropertyToTerraform(struct?: AwsGraphqlApi.AdditionalAuthenticationProviderProperty | cdktn.IResolvable): any;
export declare function awsGraphqlApiAdditionalAuthenticationProviderPropertyToHclTerraform(struct?: AwsGraphqlApi.AdditionalAuthenticationProviderProperty | cdktn.IResolvable): any;
export declare function awsGraphqlApiEnhancedMetricsConfigPropertyToTerraform(struct?: AwsGraphqlApi.EnhancedMetricsConfigPropertyOutputReference | AwsGraphqlApi.EnhancedMetricsConfigProperty): any;
export declare function awsGraphqlApiEnhancedMetricsConfigPropertyToHclTerraform(struct?: AwsGraphqlApi.EnhancedMetricsConfigPropertyOutputReference | AwsGraphqlApi.EnhancedMetricsConfigProperty): any;
export declare function awsGraphqlApiLambdaAuthorizerConfigPropertyToTerraform(struct?: AwsGraphqlApi.LambdaAuthorizerConfigPropertyOutputReference | AwsGraphqlApi.LambdaAuthorizerConfigProperty): any;
export declare function awsGraphqlApiLambdaAuthorizerConfigPropertyToHclTerraform(struct?: AwsGraphqlApi.LambdaAuthorizerConfigPropertyOutputReference | AwsGraphqlApi.LambdaAuthorizerConfigProperty): any;
export declare function awsGraphqlApiLogConfigPropertyToTerraform(struct?: AwsGraphqlApi.LogConfigPropertyOutputReference | AwsGraphqlApi.LogConfigProperty): any;
export declare function awsGraphqlApiLogConfigPropertyToHclTerraform(struct?: AwsGraphqlApi.LogConfigPropertyOutputReference | AwsGraphqlApi.LogConfigProperty): any;
export declare function awsGraphqlApiOpenidConnectConfigPropertyToTerraform(struct?: AwsGraphqlApi.OpenidConnectConfigPropertyOutputReference | AwsGraphqlApi.OpenidConnectConfigProperty): any;
export declare function awsGraphqlApiOpenidConnectConfigPropertyToHclTerraform(struct?: AwsGraphqlApi.OpenidConnectConfigPropertyOutputReference | AwsGraphqlApi.OpenidConnectConfigProperty): any;
export declare function awsGraphqlApiUserPoolConfigPropertyToTerraform(struct?: AwsGraphqlApi.UserPoolConfigPropertyOutputReference | AwsGraphqlApi.UserPoolConfigProperty): any;
export declare function awsGraphqlApiUserPoolConfigPropertyToHclTerraform(struct?: AwsGraphqlApi.UserPoolConfigPropertyOutputReference | AwsGraphqlApi.UserPoolConfigProperty): any;
export declare namespace AwsGraphqlApi {
    interface AdditionalAuthenticationProviderLambdaAuthorizerConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_graphql_api#authorizer_result_ttl_in_seconds AwsGraphqlApi#authorizer_result_ttl_in_seconds}
        */
        readonly authorizerResultTtlInSeconds?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_graphql_api#authorizer_uri AwsGraphqlApi#authorizer_uri}
        */
        readonly authorizerUri: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_graphql_api#identity_validation_expression AwsGraphqlApi#identity_validation_expression}
        */
        readonly identityValidationExpression?: string;
    }
    class AdditionalAuthenticationProviderLambdaAuthorizerConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AdditionalAuthenticationProviderLambdaAuthorizerConfigProperty | undefined;
        set internalValue(value: AdditionalAuthenticationProviderLambdaAuthorizerConfigProperty | undefined);
        private _authorizerResultTtlInSeconds?;
        get authorizerResultTtlInSeconds(): number;
        set authorizerResultTtlInSeconds(value: number);
        resetAuthorizerResultTtlInSeconds(): void;
        get authorizerResultTtlInSecondsInput(): number | undefined;
        private _authorizerUri?;
        get authorizerUri(): string;
        set authorizerUri(value: string);
        get authorizerUriInput(): string | undefined;
        private _identityValidationExpression?;
        get identityValidationExpression(): string;
        set identityValidationExpression(value: string);
        resetIdentityValidationExpression(): void;
        get identityValidationExpressionInput(): string | undefined;
    }
    interface AdditionalAuthenticationProviderOpenidConnectConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_graphql_api#auth_ttl AwsGraphqlApi#auth_ttl}
        */
        readonly authTtl?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_graphql_api#client_id AwsGraphqlApi#client_id}
        */
        readonly clientId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_graphql_api#iat_ttl AwsGraphqlApi#iat_ttl}
        */
        readonly iatTtl?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_graphql_api#issuer AwsGraphqlApi#issuer}
        */
        readonly issuer: string;
    }
    class AdditionalAuthenticationProviderOpenidConnectConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AdditionalAuthenticationProviderOpenidConnectConfigProperty | undefined;
        set internalValue(value: AdditionalAuthenticationProviderOpenidConnectConfigProperty | undefined);
        private _authTtl?;
        get authTtl(): number;
        set authTtl(value: number);
        resetAuthTtl(): void;
        get authTtlInput(): number | undefined;
        private _clientId?;
        get clientId(): string;
        set clientId(value: string);
        resetClientId(): void;
        get clientIdInput(): string | undefined;
        private _iatTtl?;
        get iatTtl(): number;
        set iatTtl(value: number);
        resetIatTtl(): void;
        get iatTtlInput(): number | undefined;
        private _issuer?;
        get issuer(): string;
        set issuer(value: string);
        get issuerInput(): string | undefined;
    }
    interface AdditionalAuthenticationProviderUserPoolConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_graphql_api#app_id_client_regex AwsGraphqlApi#app_id_client_regex}
        */
        readonly appIdClientRegex?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_graphql_api#aws_region AwsGraphqlApi#aws_region}
        */
        readonly awsRegion?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_graphql_api#user_pool_id AwsGraphqlApi#user_pool_id}
        */
        readonly userPoolId: string;
    }
    class AdditionalAuthenticationProviderUserPoolConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AdditionalAuthenticationProviderUserPoolConfigProperty | undefined;
        set internalValue(value: AdditionalAuthenticationProviderUserPoolConfigProperty | undefined);
        private _appIdClientRegex?;
        get appIdClientRegex(): string;
        set appIdClientRegex(value: string);
        resetAppIdClientRegex(): void;
        get appIdClientRegexInput(): string | undefined;
        private _awsRegion?;
        get awsRegion(): string;
        set awsRegion(value: string);
        resetAwsRegion(): void;
        get awsRegionInput(): string | undefined;
        private _userPoolId?;
        get userPoolId(): string;
        set userPoolId(value: string);
        get userPoolIdInput(): string | undefined;
    }
    interface AdditionalAuthenticationProviderProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_graphql_api#authentication_type AwsGraphqlApi#authentication_type}
        */
        readonly authenticationType: string;
        /**
        * lambda_authorizer_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_graphql_api#lambda_authorizer_config AwsGraphqlApi#lambda_authorizer_config}
        */
        readonly lambdaAuthorizerConfig?: AdditionalAuthenticationProviderLambdaAuthorizerConfigProperty;
        /**
        * openid_connect_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_graphql_api#openid_connect_config AwsGraphqlApi#openid_connect_config}
        */
        readonly openidConnectConfig?: AdditionalAuthenticationProviderOpenidConnectConfigProperty;
        /**
        * user_pool_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_graphql_api#user_pool_config AwsGraphqlApi#user_pool_config}
        */
        readonly userPoolConfig?: AdditionalAuthenticationProviderUserPoolConfigProperty;
    }
    class AdditionalAuthenticationProviderPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AdditionalAuthenticationProviderProperty | cdktn.IResolvable | undefined;
        set internalValue(value: AdditionalAuthenticationProviderProperty | cdktn.IResolvable | undefined);
        private _authenticationType?;
        get authenticationType(): string;
        set authenticationType(value: string);
        get authenticationTypeInput(): string | undefined;
        private _lambdaAuthorizerConfig;
        get lambdaAuthorizerConfig(): AdditionalAuthenticationProviderLambdaAuthorizerConfigPropertyOutputReference;
        putLambdaAuthorizerConfig(value: AdditionalAuthenticationProviderLambdaAuthorizerConfigProperty): void;
        resetLambdaAuthorizerConfig(): void;
        get lambdaAuthorizerConfigInput(): AdditionalAuthenticationProviderLambdaAuthorizerConfigProperty | undefined;
        private _openidConnectConfig;
        get openidConnectConfig(): AdditionalAuthenticationProviderOpenidConnectConfigPropertyOutputReference;
        putOpenidConnectConfig(value: AdditionalAuthenticationProviderOpenidConnectConfigProperty): void;
        resetOpenidConnectConfig(): void;
        get openidConnectConfigInput(): AdditionalAuthenticationProviderOpenidConnectConfigProperty | undefined;
        private _userPoolConfig;
        get userPoolConfig(): AdditionalAuthenticationProviderUserPoolConfigPropertyOutputReference;
        putUserPoolConfig(value: AdditionalAuthenticationProviderUserPoolConfigProperty): void;
        resetUserPoolConfig(): void;
        get userPoolConfigInput(): AdditionalAuthenticationProviderUserPoolConfigProperty | undefined;
    }
    class AdditionalAuthenticationProviderPropertyList extends cdktn.ComplexList {
        internalValue?: AdditionalAuthenticationProviderProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AdditionalAuthenticationProviderPropertyOutputReference;
    }
    interface EnhancedMetricsConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_graphql_api#data_source_level_metrics_behavior AwsGraphqlApi#data_source_level_metrics_behavior}
        */
        readonly dataSourceLevelMetricsBehavior: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_graphql_api#operation_level_metrics_config AwsGraphqlApi#operation_level_metrics_config}
        */
        readonly operationLevelMetricsConfig: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_graphql_api#resolver_level_metrics_behavior AwsGraphqlApi#resolver_level_metrics_behavior}
        */
        readonly resolverLevelMetricsBehavior: string;
    }
    class EnhancedMetricsConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): EnhancedMetricsConfigProperty | undefined;
        set internalValue(value: EnhancedMetricsConfigProperty | undefined);
        private _dataSourceLevelMetricsBehavior?;
        get dataSourceLevelMetricsBehavior(): string;
        set dataSourceLevelMetricsBehavior(value: string);
        get dataSourceLevelMetricsBehaviorInput(): string | undefined;
        private _operationLevelMetricsConfig?;
        get operationLevelMetricsConfig(): string;
        set operationLevelMetricsConfig(value: string);
        get operationLevelMetricsConfigInput(): string | undefined;
        private _resolverLevelMetricsBehavior?;
        get resolverLevelMetricsBehavior(): string;
        set resolverLevelMetricsBehavior(value: string);
        get resolverLevelMetricsBehaviorInput(): string | undefined;
    }
    interface LambdaAuthorizerConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_graphql_api#authorizer_result_ttl_in_seconds AwsGraphqlApi#authorizer_result_ttl_in_seconds}
        */
        readonly authorizerResultTtlInSeconds?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_graphql_api#authorizer_uri AwsGraphqlApi#authorizer_uri}
        */
        readonly authorizerUri: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_graphql_api#identity_validation_expression AwsGraphqlApi#identity_validation_expression}
        */
        readonly identityValidationExpression?: string;
    }
    class LambdaAuthorizerConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): LambdaAuthorizerConfigProperty | undefined;
        set internalValue(value: LambdaAuthorizerConfigProperty | undefined);
        private _authorizerResultTtlInSeconds?;
        get authorizerResultTtlInSeconds(): number;
        set authorizerResultTtlInSeconds(value: number);
        resetAuthorizerResultTtlInSeconds(): void;
        get authorizerResultTtlInSecondsInput(): number | undefined;
        private _authorizerUri?;
        get authorizerUri(): string;
        set authorizerUri(value: string);
        get authorizerUriInput(): string | undefined;
        private _identityValidationExpression?;
        get identityValidationExpression(): string;
        set identityValidationExpression(value: string);
        resetIdentityValidationExpression(): void;
        get identityValidationExpressionInput(): string | undefined;
    }
    interface LogConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_graphql_api#cloudwatch_logs_role_arn AwsGraphqlApi#cloudwatch_logs_role_arn}
        */
        readonly cloudwatchLogsRoleArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_graphql_api#exclude_verbose_content AwsGraphqlApi#exclude_verbose_content}
        */
        readonly excludeVerboseContent?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_graphql_api#field_log_level AwsGraphqlApi#field_log_level}
        */
        readonly fieldLogLevel: string;
    }
    class LogConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): LogConfigProperty | undefined;
        set internalValue(value: LogConfigProperty | undefined);
        private _cloudwatchLogsRoleArn?;
        get cloudwatchLogsRoleArn(): string;
        set cloudwatchLogsRoleArn(value: string);
        get cloudwatchLogsRoleArnInput(): string | undefined;
        private _excludeVerboseContent?;
        get excludeVerboseContent(): boolean | cdktn.IResolvable;
        set excludeVerboseContent(value: boolean | cdktn.IResolvable);
        resetExcludeVerboseContent(): void;
        get excludeVerboseContentInput(): boolean | cdktn.IResolvable | undefined;
        private _fieldLogLevel?;
        get fieldLogLevel(): string;
        set fieldLogLevel(value: string);
        get fieldLogLevelInput(): string | undefined;
    }
    interface OpenidConnectConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_graphql_api#auth_ttl AwsGraphqlApi#auth_ttl}
        */
        readonly authTtl?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_graphql_api#client_id AwsGraphqlApi#client_id}
        */
        readonly clientId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_graphql_api#iat_ttl AwsGraphqlApi#iat_ttl}
        */
        readonly iatTtl?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_graphql_api#issuer AwsGraphqlApi#issuer}
        */
        readonly issuer: string;
    }
    class OpenidConnectConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): OpenidConnectConfigProperty | undefined;
        set internalValue(value: OpenidConnectConfigProperty | undefined);
        private _authTtl?;
        get authTtl(): number;
        set authTtl(value: number);
        resetAuthTtl(): void;
        get authTtlInput(): number | undefined;
        private _clientId?;
        get clientId(): string;
        set clientId(value: string);
        resetClientId(): void;
        get clientIdInput(): string | undefined;
        private _iatTtl?;
        get iatTtl(): number;
        set iatTtl(value: number);
        resetIatTtl(): void;
        get iatTtlInput(): number | undefined;
        private _issuer?;
        get issuer(): string;
        set issuer(value: string);
        get issuerInput(): string | undefined;
    }
    interface UserPoolConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_graphql_api#app_id_client_regex AwsGraphqlApi#app_id_client_regex}
        */
        readonly appIdClientRegex?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_graphql_api#aws_region AwsGraphqlApi#aws_region}
        */
        readonly awsRegion?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_graphql_api#default_action AwsGraphqlApi#default_action}
        */
        readonly defaultAction: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appsync_graphql_api#user_pool_id AwsGraphqlApi#user_pool_id}
        */
        readonly userPoolId: string;
    }
    class UserPoolConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): UserPoolConfigProperty | undefined;
        set internalValue(value: UserPoolConfigProperty | undefined);
        private _appIdClientRegex?;
        get appIdClientRegex(): string;
        set appIdClientRegex(value: string);
        resetAppIdClientRegex(): void;
        get appIdClientRegexInput(): string | undefined;
        private _awsRegion?;
        get awsRegion(): string;
        set awsRegion(value: string);
        resetAwsRegion(): void;
        get awsRegionInput(): string | undefined;
        private _defaultAction?;
        get defaultAction(): string;
        set defaultAction(value: string);
        get defaultActionInput(): string | undefined;
        private _userPoolId?;
        get userPoolId(): string;
        set userPoolId(value: string);
        get userPoolIdInput(): string | undefined;
    }
}
