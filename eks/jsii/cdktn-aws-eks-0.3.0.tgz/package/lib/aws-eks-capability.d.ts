import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsCapabilityConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_capability#capability_name AwsCapability#capability_name}
    */
    readonly capabilityName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_capability#cluster_name AwsCapability#cluster_name}
    */
    readonly clusterName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_capability#delete_propagation_policy AwsCapability#delete_propagation_policy}
    */
    readonly deletePropagationPolicy: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_capability#region AwsCapability#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_capability#role_arn AwsCapability#role_arn}
    */
    readonly roleArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_capability#tags AwsCapability#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_capability#type AwsCapability#type}
    */
    readonly type: string;
    /**
    * configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_capability#configuration AwsCapability#configuration}
    */
    readonly configuration?: AwsCapability.ConfigurationProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_capability#timeouts AwsCapability#timeouts}
    */
    readonly timeouts?: AwsCapability.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_capability aws_eks_capability}
*/
export declare class AwsCapability extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_eks_capability";
    /**
    * Generates CDKTN code for importing a AwsCapability resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsCapability to import
    * @param importFromId The id of the existing AwsCapability that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_capability#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsCapability to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_capability aws_eks_capability} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsCapabilityConfig
    */
    constructor(scope: Construct, id: string, config: AwsCapabilityConfig);
    get arn(): string;
    private _capabilityName?;
    get capabilityName(): string;
    set capabilityName(value: string);
    get capabilityNameInput(): string | undefined;
    private _clusterName?;
    get clusterName(): string;
    set clusterName(value: string);
    get clusterNameInput(): string | undefined;
    private _deletePropagationPolicy?;
    get deletePropagationPolicy(): string;
    set deletePropagationPolicy(value: string);
    get deletePropagationPolicyInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _roleArn?;
    get roleArn(): string;
    set roleArn(value: string);
    get roleArnInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    get version(): string;
    private _configuration;
    get configuration(): AwsCapability.ConfigurationPropertyList;
    putConfiguration(value: AwsCapability.ConfigurationProperty[] | cdktn.IResolvable): void;
    resetConfiguration(): void;
    get configurationInput(): cdktn.IResolvable | AwsCapability.ConfigurationProperty[] | undefined;
    private _timeouts;
    get timeouts(): AwsCapability.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsCapability.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsCapability.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsCapabilityAwsIdcPropertyToTerraform(struct?: AwsCapability.AwsIdcProperty | cdktn.IResolvable): any;
export declare function awsCapabilityAwsIdcPropertyToHclTerraform(struct?: AwsCapability.AwsIdcProperty | cdktn.IResolvable): any;
export declare function awsCapabilityNetworkAccessPropertyToTerraform(struct?: AwsCapability.NetworkAccessProperty | cdktn.IResolvable): any;
export declare function awsCapabilityNetworkAccessPropertyToHclTerraform(struct?: AwsCapability.NetworkAccessProperty | cdktn.IResolvable): any;
export declare function awsCapabilityIdentityPropertyToTerraform(struct?: AwsCapability.IdentityProperty | cdktn.IResolvable): any;
export declare function awsCapabilityIdentityPropertyToHclTerraform(struct?: AwsCapability.IdentityProperty | cdktn.IResolvable): any;
export declare function awsCapabilityRbacRoleMappingPropertyToTerraform(struct?: AwsCapability.RbacRoleMappingProperty | cdktn.IResolvable): any;
export declare function awsCapabilityRbacRoleMappingPropertyToHclTerraform(struct?: AwsCapability.RbacRoleMappingProperty | cdktn.IResolvable): any;
export declare function awsCapabilityArgoCdPropertyToTerraform(struct?: AwsCapability.ArgoCdProperty | cdktn.IResolvable): any;
export declare function awsCapabilityArgoCdPropertyToHclTerraform(struct?: AwsCapability.ArgoCdProperty | cdktn.IResolvable): any;
export declare function awsCapabilityConfigurationPropertyToTerraform(struct?: AwsCapability.ConfigurationProperty | cdktn.IResolvable): any;
export declare function awsCapabilityConfigurationPropertyToHclTerraform(struct?: AwsCapability.ConfigurationProperty | cdktn.IResolvable): any;
export declare function awsCapabilityTimeoutsPropertyToTerraform(struct?: AwsCapability.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsCapabilityTimeoutsPropertyToHclTerraform(struct?: AwsCapability.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsCapability {
    interface AwsIdcProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_capability#idc_instance_arn AwsCapability#idc_instance_arn}
        */
        readonly idcInstanceArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_capability#idc_region AwsCapability#idc_region}
        */
        readonly idcRegion?: string;
    }
    class AwsIdcPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AwsIdcProperty | cdktn.IResolvable | undefined;
        set internalValue(value: AwsIdcProperty | cdktn.IResolvable | undefined);
        private _idcInstanceArn?;
        get idcInstanceArn(): string;
        set idcInstanceArn(value: string);
        get idcInstanceArnInput(): string | undefined;
        get idcManagedApplicationArn(): string;
        private _idcRegion?;
        get idcRegion(): string;
        set idcRegion(value: string);
        resetIdcRegion(): void;
        get idcRegionInput(): string | undefined;
    }
    class AwsIdcPropertyList extends cdktn.ComplexList {
        internalValue?: AwsIdcProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AwsIdcPropertyOutputReference;
    }
    interface NetworkAccessProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_capability#vpce_ids AwsCapability#vpce_ids}
        */
        readonly vpceIds?: string[];
    }
    class NetworkAccessPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): NetworkAccessProperty | cdktn.IResolvable | undefined;
        set internalValue(value: NetworkAccessProperty | cdktn.IResolvable | undefined);
        private _vpceIds?;
        get vpceIds(): string[];
        set vpceIds(value: string[]);
        resetVpceIds(): void;
        get vpceIdsInput(): string[] | undefined;
    }
    class NetworkAccessPropertyList extends cdktn.ComplexList {
        internalValue?: NetworkAccessProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): NetworkAccessPropertyOutputReference;
    }
    interface IdentityProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_capability#id AwsCapability#id}
        *
        * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
        * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
        */
        readonly id: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_capability#type AwsCapability#type}
        */
        readonly type: string;
    }
    class IdentityPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): IdentityProperty | cdktn.IResolvable | undefined;
        set internalValue(value: IdentityProperty | cdktn.IResolvable | undefined);
        private _id?;
        get id(): string;
        set id(value: string);
        get idInput(): string | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
    }
    class IdentityPropertyList extends cdktn.ComplexList {
        internalValue?: IdentityProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): IdentityPropertyOutputReference;
    }
    interface RbacRoleMappingProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_capability#role AwsCapability#role}
        */
        readonly role: string;
        /**
        * identity block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_capability#identity AwsCapability#identity}
        */
        readonly identity?: IdentityProperty[] | cdktn.IResolvable;
    }
    class RbacRoleMappingPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RbacRoleMappingProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RbacRoleMappingProperty | cdktn.IResolvable | undefined);
        private _role?;
        get role(): string;
        set role(value: string);
        get roleInput(): string | undefined;
        private _identity;
        get identity(): IdentityPropertyList;
        putIdentity(value: IdentityProperty[] | cdktn.IResolvable): void;
        resetIdentity(): void;
        get identityInput(): cdktn.IResolvable | IdentityProperty[] | undefined;
    }
    class RbacRoleMappingPropertyList extends cdktn.ComplexList {
        internalValue?: RbacRoleMappingProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RbacRoleMappingPropertyOutputReference;
    }
    interface ArgoCdProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_capability#namespace AwsCapability#namespace}
        */
        readonly namespace?: string;
        /**
        * aws_idc block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_capability#aws_idc AwsCapability#aws_idc}
        */
        readonly awsIdc?: AwsIdcProperty[] | cdktn.IResolvable;
        /**
        * network_access block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_capability#network_access AwsCapability#network_access}
        */
        readonly networkAccess?: NetworkAccessProperty[] | cdktn.IResolvable;
        /**
        * rbac_role_mapping block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_capability#rbac_role_mapping AwsCapability#rbac_role_mapping}
        */
        readonly rbacRoleMapping?: RbacRoleMappingProperty[] | cdktn.IResolvable;
    }
    class ArgoCdPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ArgoCdProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ArgoCdProperty | cdktn.IResolvable | undefined);
        private _namespace?;
        get namespace(): string;
        set namespace(value: string);
        resetNamespace(): void;
        get namespaceInput(): string | undefined;
        get serverUrl(): string;
        private _awsIdc;
        get awsIdc(): AwsIdcPropertyList;
        putAwsIdc(value: AwsIdcProperty[] | cdktn.IResolvable): void;
        resetAwsIdc(): void;
        get awsIdcInput(): cdktn.IResolvable | AwsIdcProperty[] | undefined;
        private _networkAccess;
        get networkAccess(): NetworkAccessPropertyList;
        putNetworkAccess(value: NetworkAccessProperty[] | cdktn.IResolvable): void;
        resetNetworkAccess(): void;
        get networkAccessInput(): cdktn.IResolvable | NetworkAccessProperty[] | undefined;
        private _rbacRoleMapping;
        get rbacRoleMapping(): RbacRoleMappingPropertyList;
        putRbacRoleMapping(value: RbacRoleMappingProperty[] | cdktn.IResolvable): void;
        resetRbacRoleMapping(): void;
        get rbacRoleMappingInput(): cdktn.IResolvable | RbacRoleMappingProperty[] | undefined;
    }
    class ArgoCdPropertyList extends cdktn.ComplexList {
        internalValue?: ArgoCdProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ArgoCdPropertyOutputReference;
    }
    interface ConfigurationProperty {
        /**
        * argo_cd block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_capability#argo_cd AwsCapability#argo_cd}
        */
        readonly argoCd?: ArgoCdProperty[] | cdktn.IResolvable;
    }
    class ConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ConfigurationProperty | cdktn.IResolvable | undefined);
        private _argoCd;
        get argoCd(): ArgoCdPropertyList;
        putArgoCd(value: ArgoCdProperty[] | cdktn.IResolvable): void;
        resetArgoCd(): void;
        get argoCdInput(): cdktn.IResolvable | ArgoCdProperty[] | undefined;
    }
    class ConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: ConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ConfigurationPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_capability#create AwsCapability#create}
        */
        readonly create?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Setting a timeout for a Delete operation is only applicable if changes are saved into state before the destroy operation occurs.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_capability#delete AwsCapability#delete}
        */
        readonly delete?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_capability#update AwsCapability#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
