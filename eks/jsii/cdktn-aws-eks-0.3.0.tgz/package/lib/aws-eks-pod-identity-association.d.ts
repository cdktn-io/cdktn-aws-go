import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsPodIdentityAssociationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_pod_identity_association#cluster_name AwsPodIdentityAssociation#cluster_name}
    */
    readonly clusterName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_pod_identity_association#disable_session_tags AwsPodIdentityAssociation#disable_session_tags}
    */
    readonly disableSessionTags?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_pod_identity_association#namespace AwsPodIdentityAssociation#namespace}
    */
    readonly namespace: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_pod_identity_association#policy AwsPodIdentityAssociation#policy}
    */
    readonly policy?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_pod_identity_association#region AwsPodIdentityAssociation#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_pod_identity_association#role_arn AwsPodIdentityAssociation#role_arn}
    */
    readonly roleArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_pod_identity_association#service_account AwsPodIdentityAssociation#service_account}
    */
    readonly serviceAccount: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_pod_identity_association#tags AwsPodIdentityAssociation#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_pod_identity_association#target_role_arn AwsPodIdentityAssociation#target_role_arn}
    */
    readonly targetRoleArn?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_pod_identity_association aws_eks_pod_identity_association}
*/
export declare class AwsPodIdentityAssociation extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_eks_pod_identity_association";
    /**
    * Generates CDKTN code for importing a AwsPodIdentityAssociation resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsPodIdentityAssociation to import
    * @param importFromId The id of the existing AwsPodIdentityAssociation that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_pod_identity_association#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsPodIdentityAssociation to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_pod_identity_association aws_eks_pod_identity_association} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsPodIdentityAssociationConfig
    */
    constructor(scope: Construct, id: string, config: AwsPodIdentityAssociationConfig);
    get associationArn(): string;
    get associationId(): string;
    private _clusterName?;
    get clusterName(): string;
    set clusterName(value: string);
    get clusterNameInput(): string | undefined;
    private _disableSessionTags?;
    get disableSessionTags(): boolean | cdktn.IResolvable;
    set disableSessionTags(value: boolean | cdktn.IResolvable);
    resetDisableSessionTags(): void;
    get disableSessionTagsInput(): boolean | cdktn.IResolvable | undefined;
    get externalId(): string;
    get id(): string;
    private _namespace?;
    get namespace(): string;
    set namespace(value: string);
    get namespaceInput(): string | undefined;
    private _policy?;
    get policy(): string;
    set policy(value: string);
    resetPolicy(): void;
    get policyInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _roleArn?;
    get roleArn(): string;
    set roleArn(value: string);
    get roleArnInput(): string | undefined;
    private _serviceAccount?;
    get serviceAccount(): string;
    set serviceAccount(value: string);
    get serviceAccountInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    private _targetRoleArn?;
    get targetRoleArn(): string;
    set targetRoleArn(value: string);
    resetTargetRoleArn(): void;
    get targetRoleArnInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
