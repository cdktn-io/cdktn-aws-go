import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsAccessPolicyAssociationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_access_policy_association#cluster_name AwsAccessPolicyAssociation#cluster_name}
    */
    readonly clusterName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_access_policy_association#id AwsAccessPolicyAssociation#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_access_policy_association#policy_arn AwsAccessPolicyAssociation#policy_arn}
    */
    readonly policyArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_access_policy_association#principal_arn AwsAccessPolicyAssociation#principal_arn}
    */
    readonly principalArn: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_access_policy_association#region AwsAccessPolicyAssociation#region}
    */
    readonly region?: string;
    /**
    * access_scope block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_access_policy_association#access_scope AwsAccessPolicyAssociation#access_scope}
    */
    readonly accessScope: AwsAccessPolicyAssociation.AccessScopeProperty;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_access_policy_association#timeouts AwsAccessPolicyAssociation#timeouts}
    */
    readonly timeouts?: AwsAccessPolicyAssociation.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_access_policy_association aws_eks_access_policy_association}
*/
export declare class AwsAccessPolicyAssociation extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_eks_access_policy_association";
    /**
    * Generates CDKTN code for importing a AwsAccessPolicyAssociation resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsAccessPolicyAssociation to import
    * @param importFromId The id of the existing AwsAccessPolicyAssociation that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_access_policy_association#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsAccessPolicyAssociation to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_access_policy_association aws_eks_access_policy_association} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsAccessPolicyAssociationConfig
    */
    constructor(scope: Construct, id: string, config: AwsAccessPolicyAssociationConfig);
    get associatedAt(): string;
    private _clusterName?;
    get clusterName(): string;
    set clusterName(value: string);
    get clusterNameInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get modifiedAt(): string;
    private _policyArn?;
    get policyArn(): string;
    set policyArn(value: string);
    get policyArnInput(): string | undefined;
    private _principalArn?;
    get principalArn(): string;
    set principalArn(value: string);
    get principalArnInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _accessScope;
    get accessScope(): AwsAccessPolicyAssociation.AccessScopePropertyOutputReference;
    putAccessScope(value: AwsAccessPolicyAssociation.AccessScopeProperty): void;
    get accessScopeInput(): AwsAccessPolicyAssociation.AccessScopeProperty | undefined;
    private _timeouts;
    get timeouts(): AwsAccessPolicyAssociation.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsAccessPolicyAssociation.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsAccessPolicyAssociation.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsAccessPolicyAssociationAccessScopePropertyToTerraform(struct?: AwsAccessPolicyAssociation.AccessScopePropertyOutputReference | AwsAccessPolicyAssociation.AccessScopeProperty): any;
export declare function awsAccessPolicyAssociationAccessScopePropertyToHclTerraform(struct?: AwsAccessPolicyAssociation.AccessScopePropertyOutputReference | AwsAccessPolicyAssociation.AccessScopeProperty): any;
export declare function awsAccessPolicyAssociationTimeoutsPropertyToTerraform(struct?: AwsAccessPolicyAssociation.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsAccessPolicyAssociationTimeoutsPropertyToHclTerraform(struct?: AwsAccessPolicyAssociation.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsAccessPolicyAssociation {
    interface AccessScopeProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_access_policy_association#namespaces AwsAccessPolicyAssociation#namespaces}
        */
        readonly namespaces?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_access_policy_association#type AwsAccessPolicyAssociation#type}
        */
        readonly type: string;
    }
    class AccessScopePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AccessScopeProperty | undefined;
        set internalValue(value: AccessScopeProperty | undefined);
        private _namespaces?;
        get namespaces(): string[];
        set namespaces(value: string[]);
        resetNamespaces(): void;
        get namespacesInput(): string[] | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_access_policy_association#create AwsAccessPolicyAssociation#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_access_policy_association#delete AwsAccessPolicyAssociation#delete}
        */
        readonly delete?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
    }
}
