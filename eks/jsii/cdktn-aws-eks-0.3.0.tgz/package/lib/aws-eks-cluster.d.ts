import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsClusterConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#bootstrap_self_managed_addons AwsCluster#bootstrap_self_managed_addons}
    */
    readonly bootstrapSelfManagedAddons?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#deletion_protection AwsCluster#deletion_protection}
    */
    readonly deletionProtection?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#enabled_cluster_log_types AwsCluster#enabled_cluster_log_types}
    */
    readonly enabledClusterLogTypes?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#force_update_version AwsCluster#force_update_version}
    */
    readonly forceUpdateVersion?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#id AwsCluster#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#name AwsCluster#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#region AwsCluster#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#role_arn AwsCluster#role_arn}
    */
    readonly roleArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#tags AwsCluster#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#tags_all AwsCluster#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#version AwsCluster#version}
    */
    readonly version?: string;
    /**
    * access_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#access_config AwsCluster#access_config}
    */
    readonly accessConfig?: AwsCluster.AccessConfigProperty;
    /**
    * compute_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#compute_config AwsCluster#compute_config}
    */
    readonly computeConfig?: AwsCluster.ComputeConfigProperty;
    /**
    * control_plane_scaling_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#control_plane_scaling_config AwsCluster#control_plane_scaling_config}
    */
    readonly controlPlaneScalingConfig?: AwsCluster.ControlPlaneScalingConfigProperty;
    /**
    * encryption_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#encryption_config AwsCluster#encryption_config}
    */
    readonly encryptionConfig?: AwsCluster.EncryptionConfigProperty;
    /**
    * kube_api_server_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#kube_api_server_config AwsCluster#kube_api_server_config}
    */
    readonly kubeApiServerConfig?: AwsCluster.KubeApiServerConfigProperty;
    /**
    * kube_controller_manager_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#kube_controller_manager_config AwsCluster#kube_controller_manager_config}
    */
    readonly kubeControllerManagerConfig?: AwsCluster.KubeControllerManagerConfigProperty;
    /**
    * kube_scheduler_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#kube_scheduler_config AwsCluster#kube_scheduler_config}
    */
    readonly kubeSchedulerConfig?: AwsCluster.KubeSchedulerConfigProperty;
    /**
    * kubernetes_network_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#kubernetes_network_config AwsCluster#kubernetes_network_config}
    */
    readonly kubernetesNetworkConfig?: AwsCluster.KubernetesNetworkConfigProperty;
    /**
    * outpost_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#outpost_config AwsCluster#outpost_config}
    */
    readonly outpostConfig?: AwsCluster.OutpostConfigProperty;
    /**
    * remote_network_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#remote_network_config AwsCluster#remote_network_config}
    */
    readonly remoteNetworkConfig?: AwsCluster.RemoteNetworkConfigProperty;
    /**
    * storage_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#storage_config AwsCluster#storage_config}
    */
    readonly storageConfig?: AwsCluster.StorageConfigProperty;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#timeouts AwsCluster#timeouts}
    */
    readonly timeouts?: AwsCluster.TimeoutsProperty;
    /**
    * upgrade_policy block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#upgrade_policy AwsCluster#upgrade_policy}
    */
    readonly upgradePolicy?: AwsCluster.UpgradePolicyProperty;
    /**
    * vpc_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#vpc_config AwsCluster#vpc_config}
    */
    readonly vpcConfig: AwsCluster.VpcConfigProperty;
    /**
    * zonal_shift_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#zonal_shift_config AwsCluster#zonal_shift_config}
    */
    readonly zonalShiftConfig?: AwsCluster.ZonalShiftConfigProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster aws_eks_cluster}
*/
export declare class AwsCluster extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_eks_cluster";
    /**
    * Generates CDKTN code for importing a AwsCluster resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsCluster to import
    * @param importFromId The id of the existing AwsCluster that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsCluster to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster aws_eks_cluster} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsClusterConfig
    */
    constructor(scope: Construct, id: string, config: AwsClusterConfig);
    get arn(): string;
    private _bootstrapSelfManagedAddons?;
    get bootstrapSelfManagedAddons(): boolean | cdktn.IResolvable;
    set bootstrapSelfManagedAddons(value: boolean | cdktn.IResolvable);
    resetBootstrapSelfManagedAddons(): void;
    get bootstrapSelfManagedAddonsInput(): boolean | cdktn.IResolvable | undefined;
    private _certificateAuthority;
    get certificateAuthority(): AwsCluster.CertificateAuthorityPropertyList;
    get clusterId(): string;
    get createdAt(): string;
    private _deletionProtection?;
    get deletionProtection(): boolean | cdktn.IResolvable;
    set deletionProtection(value: boolean | cdktn.IResolvable);
    resetDeletionProtection(): void;
    get deletionProtectionInput(): boolean | cdktn.IResolvable | undefined;
    private _enabledClusterLogTypes?;
    get enabledClusterLogTypes(): string[];
    set enabledClusterLogTypes(value: string[]);
    resetEnabledClusterLogTypes(): void;
    get enabledClusterLogTypesInput(): string[] | undefined;
    get endpoint(): string;
    private _forceUpdateVersion?;
    get forceUpdateVersion(): boolean | cdktn.IResolvable;
    set forceUpdateVersion(value: boolean | cdktn.IResolvable);
    resetForceUpdateVersion(): void;
    get forceUpdateVersionInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _identity;
    get identity(): AwsCluster.IdentityPropertyList;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get platformVersion(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _roleArn?;
    get roleArn(): string;
    set roleArn(value: string);
    get roleArnInput(): string | undefined;
    get status(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _version?;
    get version(): string;
    set version(value: string);
    resetVersion(): void;
    get versionInput(): string | undefined;
    private _accessConfig;
    get accessConfig(): AwsCluster.AccessConfigPropertyOutputReference;
    putAccessConfig(value: AwsCluster.AccessConfigProperty): void;
    resetAccessConfig(): void;
    get accessConfigInput(): AwsCluster.AccessConfigProperty | undefined;
    private _computeConfig;
    get computeConfig(): AwsCluster.ComputeConfigPropertyOutputReference;
    putComputeConfig(value: AwsCluster.ComputeConfigProperty): void;
    resetComputeConfig(): void;
    get computeConfigInput(): AwsCluster.ComputeConfigProperty | undefined;
    private _controlPlaneScalingConfig;
    get controlPlaneScalingConfig(): AwsCluster.ControlPlaneScalingConfigPropertyOutputReference;
    putControlPlaneScalingConfig(value: AwsCluster.ControlPlaneScalingConfigProperty): void;
    resetControlPlaneScalingConfig(): void;
    get controlPlaneScalingConfigInput(): AwsCluster.ControlPlaneScalingConfigProperty | undefined;
    private _encryptionConfig;
    get encryptionConfig(): AwsCluster.EncryptionConfigPropertyOutputReference;
    putEncryptionConfig(value: AwsCluster.EncryptionConfigProperty): void;
    resetEncryptionConfig(): void;
    get encryptionConfigInput(): AwsCluster.EncryptionConfigProperty | undefined;
    private _kubeApiServerConfig;
    get kubeApiServerConfig(): AwsCluster.KubeApiServerConfigPropertyOutputReference;
    putKubeApiServerConfig(value: AwsCluster.KubeApiServerConfigProperty): void;
    resetKubeApiServerConfig(): void;
    get kubeApiServerConfigInput(): AwsCluster.KubeApiServerConfigProperty | undefined;
    private _kubeControllerManagerConfig;
    get kubeControllerManagerConfig(): AwsCluster.KubeControllerManagerConfigPropertyOutputReference;
    putKubeControllerManagerConfig(value: AwsCluster.KubeControllerManagerConfigProperty): void;
    resetKubeControllerManagerConfig(): void;
    get kubeControllerManagerConfigInput(): AwsCluster.KubeControllerManagerConfigProperty | undefined;
    private _kubeSchedulerConfig;
    get kubeSchedulerConfig(): AwsCluster.KubeSchedulerConfigPropertyOutputReference;
    putKubeSchedulerConfig(value: AwsCluster.KubeSchedulerConfigProperty): void;
    resetKubeSchedulerConfig(): void;
    get kubeSchedulerConfigInput(): AwsCluster.KubeSchedulerConfigProperty | undefined;
    private _kubernetesNetworkConfig;
    get kubernetesNetworkConfig(): AwsCluster.KubernetesNetworkConfigPropertyOutputReference;
    putKubernetesNetworkConfig(value: AwsCluster.KubernetesNetworkConfigProperty): void;
    resetKubernetesNetworkConfig(): void;
    get kubernetesNetworkConfigInput(): AwsCluster.KubernetesNetworkConfigProperty | undefined;
    private _outpostConfig;
    get outpostConfig(): AwsCluster.OutpostConfigPropertyOutputReference;
    putOutpostConfig(value: AwsCluster.OutpostConfigProperty): void;
    resetOutpostConfig(): void;
    get outpostConfigInput(): AwsCluster.OutpostConfigProperty | undefined;
    private _remoteNetworkConfig;
    get remoteNetworkConfig(): AwsCluster.RemoteNetworkConfigPropertyOutputReference;
    putRemoteNetworkConfig(value: AwsCluster.RemoteNetworkConfigProperty): void;
    resetRemoteNetworkConfig(): void;
    get remoteNetworkConfigInput(): AwsCluster.RemoteNetworkConfigProperty | undefined;
    private _storageConfig;
    get storageConfig(): AwsCluster.StorageConfigPropertyOutputReference;
    putStorageConfig(value: AwsCluster.StorageConfigProperty): void;
    resetStorageConfig(): void;
    get storageConfigInput(): AwsCluster.StorageConfigProperty | undefined;
    private _timeouts;
    get timeouts(): AwsCluster.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsCluster.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsCluster.TimeoutsProperty | undefined;
    private _upgradePolicy;
    get upgradePolicy(): AwsCluster.UpgradePolicyPropertyOutputReference;
    putUpgradePolicy(value: AwsCluster.UpgradePolicyProperty): void;
    resetUpgradePolicy(): void;
    get upgradePolicyInput(): AwsCluster.UpgradePolicyProperty | undefined;
    private _vpcConfig;
    get vpcConfig(): AwsCluster.VpcConfigPropertyOutputReference;
    putVpcConfig(value: AwsCluster.VpcConfigProperty): void;
    get vpcConfigInput(): AwsCluster.VpcConfigProperty | undefined;
    private _zonalShiftConfig;
    get zonalShiftConfig(): AwsCluster.ZonalShiftConfigPropertyOutputReference;
    putZonalShiftConfig(value: AwsCluster.ZonalShiftConfigProperty): void;
    resetZonalShiftConfig(): void;
    get zonalShiftConfigInput(): AwsCluster.ZonalShiftConfigProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsClusterCertificateAuthorityPropertyToTerraform(struct?: AwsCluster.CertificateAuthorityProperty): any;
export declare function awsClusterCertificateAuthorityPropertyToHclTerraform(struct?: AwsCluster.CertificateAuthorityProperty): any;
export declare function awsClusterOidcPropertyToTerraform(struct?: AwsCluster.OidcProperty): any;
export declare function awsClusterOidcPropertyToHclTerraform(struct?: AwsCluster.OidcProperty): any;
export declare function awsClusterIdentityPropertyToTerraform(struct?: AwsCluster.IdentityProperty): any;
export declare function awsClusterIdentityPropertyToHclTerraform(struct?: AwsCluster.IdentityProperty): any;
export declare function awsClusterAccessConfigPropertyToTerraform(struct?: AwsCluster.AccessConfigPropertyOutputReference | AwsCluster.AccessConfigProperty): any;
export declare function awsClusterAccessConfigPropertyToHclTerraform(struct?: AwsCluster.AccessConfigPropertyOutputReference | AwsCluster.AccessConfigProperty): any;
export declare function awsClusterComputeConfigPropertyToTerraform(struct?: AwsCluster.ComputeConfigPropertyOutputReference | AwsCluster.ComputeConfigProperty): any;
export declare function awsClusterComputeConfigPropertyToHclTerraform(struct?: AwsCluster.ComputeConfigPropertyOutputReference | AwsCluster.ComputeConfigProperty): any;
export declare function awsClusterControlPlaneScalingConfigPropertyToTerraform(struct?: AwsCluster.ControlPlaneScalingConfigPropertyOutputReference | AwsCluster.ControlPlaneScalingConfigProperty): any;
export declare function awsClusterControlPlaneScalingConfigPropertyToHclTerraform(struct?: AwsCluster.ControlPlaneScalingConfigPropertyOutputReference | AwsCluster.ControlPlaneScalingConfigProperty): any;
export declare function awsClusterProviderPropertyToTerraform(struct?: AwsCluster.ProviderPropertyOutputReference | AwsCluster.ProviderProperty): any;
export declare function awsClusterProviderPropertyToHclTerraform(struct?: AwsCluster.ProviderPropertyOutputReference | AwsCluster.ProviderProperty): any;
export declare function awsClusterEncryptionConfigPropertyToTerraform(struct?: AwsCluster.EncryptionConfigPropertyOutputReference | AwsCluster.EncryptionConfigProperty): any;
export declare function awsClusterEncryptionConfigPropertyToHclTerraform(struct?: AwsCluster.EncryptionConfigPropertyOutputReference | AwsCluster.EncryptionConfigProperty): any;
export declare function awsClusterServiceNodePortRangePropertyToTerraform(struct?: AwsCluster.ServiceNodePortRangePropertyOutputReference | AwsCluster.ServiceNodePortRangeProperty): any;
export declare function awsClusterServiceNodePortRangePropertyToHclTerraform(struct?: AwsCluster.ServiceNodePortRangePropertyOutputReference | AwsCluster.ServiceNodePortRangeProperty): any;
export declare function awsClusterKubeApiServerConfigPropertyToTerraform(struct?: AwsCluster.KubeApiServerConfigPropertyOutputReference | AwsCluster.KubeApiServerConfigProperty): any;
export declare function awsClusterKubeApiServerConfigPropertyToHclTerraform(struct?: AwsCluster.KubeApiServerConfigPropertyOutputReference | AwsCluster.KubeApiServerConfigProperty): any;
export declare function awsClusterHorizontalPodAutoscalerControllerConfigPropertyToTerraform(struct?: AwsCluster.HorizontalPodAutoscalerControllerConfigPropertyOutputReference | AwsCluster.HorizontalPodAutoscalerControllerConfigProperty): any;
export declare function awsClusterHorizontalPodAutoscalerControllerConfigPropertyToHclTerraform(struct?: AwsCluster.HorizontalPodAutoscalerControllerConfigPropertyOutputReference | AwsCluster.HorizontalPodAutoscalerControllerConfigProperty): any;
export declare function awsClusterKubeControllerManagerConfigPropertyToTerraform(struct?: AwsCluster.KubeControllerManagerConfigPropertyOutputReference | AwsCluster.KubeControllerManagerConfigProperty): any;
export declare function awsClusterKubeControllerManagerConfigPropertyToHclTerraform(struct?: AwsCluster.KubeControllerManagerConfigPropertyOutputReference | AwsCluster.KubeControllerManagerConfigProperty): any;
export declare function awsClusterResourcePropertyToTerraform(struct?: AwsCluster.ResourceProperty | cdktn.IResolvable): any;
export declare function awsClusterResourcePropertyToHclTerraform(struct?: AwsCluster.ResourceProperty | cdktn.IResolvable): any;
export declare function awsClusterScoringStrategyPropertyToTerraform(struct?: AwsCluster.ScoringStrategyPropertyOutputReference | AwsCluster.ScoringStrategyProperty): any;
export declare function awsClusterScoringStrategyPropertyToHclTerraform(struct?: AwsCluster.ScoringStrategyPropertyOutputReference | AwsCluster.ScoringStrategyProperty): any;
export declare function awsClusterNodeResourcesFitPropertyToTerraform(struct?: AwsCluster.NodeResourcesFitPropertyOutputReference | AwsCluster.NodeResourcesFitProperty): any;
export declare function awsClusterNodeResourcesFitPropertyToHclTerraform(struct?: AwsCluster.NodeResourcesFitPropertyOutputReference | AwsCluster.NodeResourcesFitProperty): any;
export declare function awsClusterKubeSchedulerConfigPropertyToTerraform(struct?: AwsCluster.KubeSchedulerConfigPropertyOutputReference | AwsCluster.KubeSchedulerConfigProperty): any;
export declare function awsClusterKubeSchedulerConfigPropertyToHclTerraform(struct?: AwsCluster.KubeSchedulerConfigPropertyOutputReference | AwsCluster.KubeSchedulerConfigProperty): any;
export declare function awsClusterElasticLoadBalancingPropertyToTerraform(struct?: AwsCluster.ElasticLoadBalancingPropertyOutputReference | AwsCluster.ElasticLoadBalancingProperty): any;
export declare function awsClusterElasticLoadBalancingPropertyToHclTerraform(struct?: AwsCluster.ElasticLoadBalancingPropertyOutputReference | AwsCluster.ElasticLoadBalancingProperty): any;
export declare function awsClusterKubernetesNetworkConfigPropertyToTerraform(struct?: AwsCluster.KubernetesNetworkConfigPropertyOutputReference | AwsCluster.KubernetesNetworkConfigProperty): any;
export declare function awsClusterKubernetesNetworkConfigPropertyToHclTerraform(struct?: AwsCluster.KubernetesNetworkConfigPropertyOutputReference | AwsCluster.KubernetesNetworkConfigProperty): any;
export declare function awsClusterControlPlanePlacementPropertyToTerraform(struct?: AwsCluster.ControlPlanePlacementPropertyOutputReference | AwsCluster.ControlPlanePlacementProperty): any;
export declare function awsClusterControlPlanePlacementPropertyToHclTerraform(struct?: AwsCluster.ControlPlanePlacementPropertyOutputReference | AwsCluster.ControlPlanePlacementProperty): any;
export declare function awsClusterEtcdPlacementPropertyToTerraform(struct?: AwsCluster.EtcdPlacementPropertyOutputReference | AwsCluster.EtcdPlacementProperty): any;
export declare function awsClusterEtcdPlacementPropertyToHclTerraform(struct?: AwsCluster.EtcdPlacementPropertyOutputReference | AwsCluster.EtcdPlacementProperty): any;
export declare function awsClusterOutpostConfigPropertyToTerraform(struct?: AwsCluster.OutpostConfigPropertyOutputReference | AwsCluster.OutpostConfigProperty): any;
export declare function awsClusterOutpostConfigPropertyToHclTerraform(struct?: AwsCluster.OutpostConfigPropertyOutputReference | AwsCluster.OutpostConfigProperty): any;
export declare function awsClusterRemoteNodeNetworksPropertyToTerraform(struct?: AwsCluster.RemoteNodeNetworksPropertyOutputReference | AwsCluster.RemoteNodeNetworksProperty): any;
export declare function awsClusterRemoteNodeNetworksPropertyToHclTerraform(struct?: AwsCluster.RemoteNodeNetworksPropertyOutputReference | AwsCluster.RemoteNodeNetworksProperty): any;
export declare function awsClusterRemotePodNetworksPropertyToTerraform(struct?: AwsCluster.RemotePodNetworksPropertyOutputReference | AwsCluster.RemotePodNetworksProperty): any;
export declare function awsClusterRemotePodNetworksPropertyToHclTerraform(struct?: AwsCluster.RemotePodNetworksPropertyOutputReference | AwsCluster.RemotePodNetworksProperty): any;
export declare function awsClusterRemoteNetworkConfigPropertyToTerraform(struct?: AwsCluster.RemoteNetworkConfigPropertyOutputReference | AwsCluster.RemoteNetworkConfigProperty): any;
export declare function awsClusterRemoteNetworkConfigPropertyToHclTerraform(struct?: AwsCluster.RemoteNetworkConfigPropertyOutputReference | AwsCluster.RemoteNetworkConfigProperty): any;
export declare function awsClusterBlockStoragePropertyToTerraform(struct?: AwsCluster.BlockStoragePropertyOutputReference | AwsCluster.BlockStorageProperty): any;
export declare function awsClusterBlockStoragePropertyToHclTerraform(struct?: AwsCluster.BlockStoragePropertyOutputReference | AwsCluster.BlockStorageProperty): any;
export declare function awsClusterStorageConfigPropertyToTerraform(struct?: AwsCluster.StorageConfigPropertyOutputReference | AwsCluster.StorageConfigProperty): any;
export declare function awsClusterStorageConfigPropertyToHclTerraform(struct?: AwsCluster.StorageConfigPropertyOutputReference | AwsCluster.StorageConfigProperty): any;
export declare function awsClusterTimeoutsPropertyToTerraform(struct?: AwsCluster.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsClusterTimeoutsPropertyToHclTerraform(struct?: AwsCluster.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsClusterUpgradePolicyPropertyToTerraform(struct?: AwsCluster.UpgradePolicyPropertyOutputReference | AwsCluster.UpgradePolicyProperty): any;
export declare function awsClusterUpgradePolicyPropertyToHclTerraform(struct?: AwsCluster.UpgradePolicyPropertyOutputReference | AwsCluster.UpgradePolicyProperty): any;
export declare function awsClusterVpcConfigPropertyToTerraform(struct?: AwsCluster.VpcConfigPropertyOutputReference | AwsCluster.VpcConfigProperty): any;
export declare function awsClusterVpcConfigPropertyToHclTerraform(struct?: AwsCluster.VpcConfigPropertyOutputReference | AwsCluster.VpcConfigProperty): any;
export declare function awsClusterZonalShiftConfigPropertyToTerraform(struct?: AwsCluster.ZonalShiftConfigPropertyOutputReference | AwsCluster.ZonalShiftConfigProperty): any;
export declare function awsClusterZonalShiftConfigPropertyToHclTerraform(struct?: AwsCluster.ZonalShiftConfigPropertyOutputReference | AwsCluster.ZonalShiftConfigProperty): any;
export declare namespace AwsCluster {
    interface CertificateAuthorityProperty {
    }
    class CertificateAuthorityPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CertificateAuthorityProperty | undefined;
        set internalValue(value: CertificateAuthorityProperty | undefined);
        get data(): string;
    }
    class CertificateAuthorityPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CertificateAuthorityPropertyOutputReference;
    }
    interface OidcProperty {
    }
    class OidcPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): OidcProperty | undefined;
        set internalValue(value: OidcProperty | undefined);
        get issuer(): string;
    }
    class OidcPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): OidcPropertyOutputReference;
    }
    interface IdentityProperty {
    }
    class IdentityPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): IdentityProperty | undefined;
        set internalValue(value: IdentityProperty | undefined);
        private _oidc;
        get oidc(): OidcPropertyList;
    }
    class IdentityPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): IdentityPropertyOutputReference;
    }
    interface AccessConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#authentication_mode AwsCluster#authentication_mode}
        */
        readonly authenticationMode?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#bootstrap_cluster_creator_admin_permissions AwsCluster#bootstrap_cluster_creator_admin_permissions}
        */
        readonly bootstrapClusterCreatorAdminPermissions?: boolean | cdktn.IResolvable;
    }
    class AccessConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AccessConfigProperty | undefined;
        set internalValue(value: AccessConfigProperty | undefined);
        private _authenticationMode?;
        get authenticationMode(): string;
        set authenticationMode(value: string);
        resetAuthenticationMode(): void;
        get authenticationModeInput(): string | undefined;
        private _bootstrapClusterCreatorAdminPermissions?;
        get bootstrapClusterCreatorAdminPermissions(): boolean | cdktn.IResolvable;
        set bootstrapClusterCreatorAdminPermissions(value: boolean | cdktn.IResolvable);
        resetBootstrapClusterCreatorAdminPermissions(): void;
        get bootstrapClusterCreatorAdminPermissionsInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface ComputeConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#enabled AwsCluster#enabled}
        */
        readonly enabled?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#node_pools AwsCluster#node_pools}
        */
        readonly nodePools?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#node_role_arn AwsCluster#node_role_arn}
        */
        readonly nodeRoleArn?: string;
    }
    class ComputeConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ComputeConfigProperty | undefined;
        set internalValue(value: ComputeConfigProperty | undefined);
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        resetEnabled(): void;
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
        private _nodePools?;
        get nodePools(): string[];
        set nodePools(value: string[]);
        resetNodePools(): void;
        get nodePoolsInput(): string[] | undefined;
        private _nodeRoleArn?;
        get nodeRoleArn(): string;
        set nodeRoleArn(value: string);
        resetNodeRoleArn(): void;
        get nodeRoleArnInput(): string | undefined;
    }
    interface ControlPlaneScalingConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#tier AwsCluster#tier}
        */
        readonly tier?: string;
    }
    class ControlPlaneScalingConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ControlPlaneScalingConfigProperty | undefined;
        set internalValue(value: ControlPlaneScalingConfigProperty | undefined);
        private _tier?;
        get tier(): string;
        set tier(value: string);
        resetTier(): void;
        get tierInput(): string | undefined;
    }
    interface ProviderProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#key_arn AwsCluster#key_arn}
        */
        readonly keyArn: string;
    }
    class ProviderPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ProviderProperty | undefined;
        set internalValue(value: ProviderProperty | undefined);
        private _keyArn?;
        get keyArn(): string;
        set keyArn(value: string);
        get keyArnInput(): string | undefined;
    }
    interface EncryptionConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#resources AwsCluster#resources}
        */
        readonly resources: string[];
        /**
        * provider block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#provider AwsCluster#provider}
        */
        readonly provider: ProviderProperty;
    }
    class EncryptionConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): EncryptionConfigProperty | undefined;
        set internalValue(value: EncryptionConfigProperty | undefined);
        private _resources?;
        get resources(): string[];
        set resources(value: string[]);
        get resourcesInput(): string[] | undefined;
        private _provider;
        get provider(): ProviderPropertyOutputReference;
        putProvider(value: ProviderProperty): void;
        get providerInput(): ProviderProperty | undefined;
    }
    interface ServiceNodePortRangeProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#max_port AwsCluster#max_port}
        */
        readonly maxPort?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#min_port AwsCluster#min_port}
        */
        readonly minPort?: number;
    }
    class ServiceNodePortRangePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ServiceNodePortRangeProperty | undefined;
        set internalValue(value: ServiceNodePortRangeProperty | undefined);
        private _maxPort?;
        get maxPort(): number;
        set maxPort(value: number);
        resetMaxPort(): void;
        get maxPortInput(): number | undefined;
        private _minPort?;
        get minPort(): number;
        set minPort(value: number);
        resetMinPort(): void;
        get minPortInput(): number | undefined;
    }
    interface KubeApiServerConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#event_ttl AwsCluster#event_ttl}
        */
        readonly eventTtl?: string;
        /**
        * service_node_port_range block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#service_node_port_range AwsCluster#service_node_port_range}
        */
        readonly serviceNodePortRange?: ServiceNodePortRangeProperty;
    }
    class KubeApiServerConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): KubeApiServerConfigProperty | undefined;
        set internalValue(value: KubeApiServerConfigProperty | undefined);
        private _eventTtl?;
        get eventTtl(): string;
        set eventTtl(value: string);
        resetEventTtl(): void;
        get eventTtlInput(): string | undefined;
        private _serviceNodePortRange;
        get serviceNodePortRange(): ServiceNodePortRangePropertyOutputReference;
        putServiceNodePortRange(value: ServiceNodePortRangeProperty): void;
        resetServiceNodePortRange(): void;
        get serviceNodePortRangeInput(): ServiceNodePortRangeProperty | undefined;
    }
    interface HorizontalPodAutoscalerControllerConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#horizontal_pod_autoscaler_sync_period AwsCluster#horizontal_pod_autoscaler_sync_period}
        */
        readonly horizontalPodAutoscalerSyncPeriod?: string;
    }
    class HorizontalPodAutoscalerControllerConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): HorizontalPodAutoscalerControllerConfigProperty | undefined;
        set internalValue(value: HorizontalPodAutoscalerControllerConfigProperty | undefined);
        private _horizontalPodAutoscalerSyncPeriod?;
        get horizontalPodAutoscalerSyncPeriod(): string;
        set horizontalPodAutoscalerSyncPeriod(value: string);
        resetHorizontalPodAutoscalerSyncPeriod(): void;
        get horizontalPodAutoscalerSyncPeriodInput(): string | undefined;
    }
    interface KubeControllerManagerConfigProperty {
        /**
        * horizontal_pod_autoscaler_controller_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#horizontal_pod_autoscaler_controller_config AwsCluster#horizontal_pod_autoscaler_controller_config}
        */
        readonly horizontalPodAutoscalerControllerConfig?: HorizontalPodAutoscalerControllerConfigProperty;
    }
    class KubeControllerManagerConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): KubeControllerManagerConfigProperty | undefined;
        set internalValue(value: KubeControllerManagerConfigProperty | undefined);
        private _horizontalPodAutoscalerControllerConfig;
        get horizontalPodAutoscalerControllerConfig(): HorizontalPodAutoscalerControllerConfigPropertyOutputReference;
        putHorizontalPodAutoscalerControllerConfig(value: HorizontalPodAutoscalerControllerConfigProperty): void;
        resetHorizontalPodAutoscalerControllerConfig(): void;
        get horizontalPodAutoscalerControllerConfigInput(): HorizontalPodAutoscalerControllerConfigProperty | undefined;
    }
    interface ResourceProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#name AwsCluster#name}
        */
        readonly name?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#weight AwsCluster#weight}
        */
        readonly weight?: number;
    }
    class ResourcePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ResourceProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ResourceProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        resetName(): void;
        get nameInput(): string | undefined;
        private _weight?;
        get weight(): number;
        set weight(value: number);
        resetWeight(): void;
        get weightInput(): number | undefined;
    }
    class ResourcePropertyList extends cdktn.ComplexList {
        internalValue?: ResourceProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ResourcePropertyOutputReference;
    }
    interface ScoringStrategyProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#type AwsCluster#type}
        */
        readonly type?: string;
        /**
        * resource block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#resource AwsCluster#resource}
        */
        readonly resource?: ResourceProperty[] | cdktn.IResolvable;
    }
    class ScoringStrategyPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ScoringStrategyProperty | undefined;
        set internalValue(value: ScoringStrategyProperty | undefined);
        private _type?;
        get type(): string;
        set type(value: string);
        resetType(): void;
        get typeInput(): string | undefined;
        private _resource;
        get resource(): ResourcePropertyList;
        putResource(value: ResourceProperty[] | cdktn.IResolvable): void;
        resetResource(): void;
        get resourceInput(): cdktn.IResolvable | ResourceProperty[] | undefined;
    }
    interface NodeResourcesFitProperty {
        /**
        * scoring_strategy block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#scoring_strategy AwsCluster#scoring_strategy}
        */
        readonly scoringStrategy?: ScoringStrategyProperty;
    }
    class NodeResourcesFitPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): NodeResourcesFitProperty | undefined;
        set internalValue(value: NodeResourcesFitProperty | undefined);
        private _scoringStrategy;
        get scoringStrategy(): ScoringStrategyPropertyOutputReference;
        putScoringStrategy(value: ScoringStrategyProperty): void;
        resetScoringStrategy(): void;
        get scoringStrategyInput(): ScoringStrategyProperty | undefined;
    }
    interface KubeSchedulerConfigProperty {
        /**
        * node_resources_fit block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#node_resources_fit AwsCluster#node_resources_fit}
        */
        readonly nodeResourcesFit?: NodeResourcesFitProperty;
    }
    class KubeSchedulerConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): KubeSchedulerConfigProperty | undefined;
        set internalValue(value: KubeSchedulerConfigProperty | undefined);
        private _nodeResourcesFit;
        get nodeResourcesFit(): NodeResourcesFitPropertyOutputReference;
        putNodeResourcesFit(value: NodeResourcesFitProperty): void;
        resetNodeResourcesFit(): void;
        get nodeResourcesFitInput(): NodeResourcesFitProperty | undefined;
    }
    interface ElasticLoadBalancingProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#enabled AwsCluster#enabled}
        */
        readonly enabled?: boolean | cdktn.IResolvable;
    }
    class ElasticLoadBalancingPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ElasticLoadBalancingProperty | undefined;
        set internalValue(value: ElasticLoadBalancingProperty | undefined);
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        resetEnabled(): void;
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface KubernetesNetworkConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#ip_family AwsCluster#ip_family}
        */
        readonly ipFamily?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#service_ipv4_cidr AwsCluster#service_ipv4_cidr}
        */
        readonly serviceIpv4Cidr?: string;
        /**
        * elastic_load_balancing block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#elastic_load_balancing AwsCluster#elastic_load_balancing}
        */
        readonly elasticLoadBalancing?: ElasticLoadBalancingProperty;
    }
    class KubernetesNetworkConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): KubernetesNetworkConfigProperty | undefined;
        set internalValue(value: KubernetesNetworkConfigProperty | undefined);
        private _ipFamily?;
        get ipFamily(): string;
        set ipFamily(value: string);
        resetIpFamily(): void;
        get ipFamilyInput(): string | undefined;
        private _serviceIpv4Cidr?;
        get serviceIpv4Cidr(): string;
        set serviceIpv4Cidr(value: string);
        resetServiceIpv4Cidr(): void;
        get serviceIpv4CidrInput(): string | undefined;
        get serviceIpv6Cidr(): string;
        private _elasticLoadBalancing;
        get elasticLoadBalancing(): ElasticLoadBalancingPropertyOutputReference;
        putElasticLoadBalancing(value: ElasticLoadBalancingProperty): void;
        resetElasticLoadBalancing(): void;
        get elasticLoadBalancingInput(): ElasticLoadBalancingProperty | undefined;
    }
    interface ControlPlanePlacementProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#group_name AwsCluster#group_name}
        */
        readonly groupName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#spread_level AwsCluster#spread_level}
        */
        readonly spreadLevel?: string;
    }
    class ControlPlanePlacementPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ControlPlanePlacementProperty | undefined;
        set internalValue(value: ControlPlanePlacementProperty | undefined);
        private _groupName?;
        get groupName(): string;
        set groupName(value: string);
        resetGroupName(): void;
        get groupNameInput(): string | undefined;
        private _spreadLevel?;
        get spreadLevel(): string;
        set spreadLevel(value: string);
        resetSpreadLevel(): void;
        get spreadLevelInput(): string | undefined;
    }
    interface EtcdPlacementProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#spread_level AwsCluster#spread_level}
        */
        readonly spreadLevel?: string;
    }
    class EtcdPlacementPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): EtcdPlacementProperty | undefined;
        set internalValue(value: EtcdPlacementProperty | undefined);
        private _spreadLevel?;
        get spreadLevel(): string;
        set spreadLevel(value: string);
        resetSpreadLevel(): void;
        get spreadLevelInput(): string | undefined;
    }
    interface OutpostConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#control_plane_instance_type AwsCluster#control_plane_instance_type}
        */
        readonly controlPlaneInstanceType: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#etcd_instance_type AwsCluster#etcd_instance_type}
        */
        readonly etcdInstanceType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#outpost_arns AwsCluster#outpost_arns}
        */
        readonly outpostArns: string[];
        /**
        * control_plane_placement block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#control_plane_placement AwsCluster#control_plane_placement}
        */
        readonly controlPlanePlacement?: ControlPlanePlacementProperty;
        /**
        * etcd_placement block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#etcd_placement AwsCluster#etcd_placement}
        */
        readonly etcdPlacement?: EtcdPlacementProperty;
    }
    class OutpostConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): OutpostConfigProperty | undefined;
        set internalValue(value: OutpostConfigProperty | undefined);
        private _controlPlaneInstanceType?;
        get controlPlaneInstanceType(): string;
        set controlPlaneInstanceType(value: string);
        get controlPlaneInstanceTypeInput(): string | undefined;
        private _etcdInstanceType?;
        get etcdInstanceType(): string;
        set etcdInstanceType(value: string);
        resetEtcdInstanceType(): void;
        get etcdInstanceTypeInput(): string | undefined;
        private _outpostArns?;
        get outpostArns(): string[];
        set outpostArns(value: string[]);
        get outpostArnsInput(): string[] | undefined;
        private _controlPlanePlacement;
        get controlPlanePlacement(): ControlPlanePlacementPropertyOutputReference;
        putControlPlanePlacement(value: ControlPlanePlacementProperty): void;
        resetControlPlanePlacement(): void;
        get controlPlanePlacementInput(): ControlPlanePlacementProperty | undefined;
        private _etcdPlacement;
        get etcdPlacement(): EtcdPlacementPropertyOutputReference;
        putEtcdPlacement(value: EtcdPlacementProperty): void;
        resetEtcdPlacement(): void;
        get etcdPlacementInput(): EtcdPlacementProperty | undefined;
    }
    interface RemoteNodeNetworksProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#cidrs AwsCluster#cidrs}
        */
        readonly cidrs?: string[];
    }
    class RemoteNodeNetworksPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RemoteNodeNetworksProperty | undefined;
        set internalValue(value: RemoteNodeNetworksProperty | undefined);
        private _cidrs?;
        get cidrs(): string[];
        set cidrs(value: string[]);
        resetCidrs(): void;
        get cidrsInput(): string[] | undefined;
    }
    interface RemotePodNetworksProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#cidrs AwsCluster#cidrs}
        */
        readonly cidrs?: string[];
    }
    class RemotePodNetworksPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RemotePodNetworksProperty | undefined;
        set internalValue(value: RemotePodNetworksProperty | undefined);
        private _cidrs?;
        get cidrs(): string[];
        set cidrs(value: string[]);
        resetCidrs(): void;
        get cidrsInput(): string[] | undefined;
    }
    interface RemoteNetworkConfigProperty {
        /**
        * remote_node_networks block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#remote_node_networks AwsCluster#remote_node_networks}
        */
        readonly remoteNodeNetworks?: RemoteNodeNetworksProperty;
        /**
        * remote_pod_networks block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#remote_pod_networks AwsCluster#remote_pod_networks}
        */
        readonly remotePodNetworks?: RemotePodNetworksProperty;
    }
    class RemoteNetworkConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RemoteNetworkConfigProperty | undefined;
        set internalValue(value: RemoteNetworkConfigProperty | undefined);
        private _remoteNodeNetworks;
        get remoteNodeNetworks(): RemoteNodeNetworksPropertyOutputReference;
        putRemoteNodeNetworks(value: RemoteNodeNetworksProperty): void;
        resetRemoteNodeNetworks(): void;
        get remoteNodeNetworksInput(): RemoteNodeNetworksProperty | undefined;
        private _remotePodNetworks;
        get remotePodNetworks(): RemotePodNetworksPropertyOutputReference;
        putRemotePodNetworks(value: RemotePodNetworksProperty): void;
        resetRemotePodNetworks(): void;
        get remotePodNetworksInput(): RemotePodNetworksProperty | undefined;
    }
    interface BlockStorageProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#enabled AwsCluster#enabled}
        */
        readonly enabled?: boolean | cdktn.IResolvable;
    }
    class BlockStoragePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): BlockStorageProperty | undefined;
        set internalValue(value: BlockStorageProperty | undefined);
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        resetEnabled(): void;
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface StorageConfigProperty {
        /**
        * block_storage block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#block_storage AwsCluster#block_storage}
        */
        readonly blockStorage?: BlockStorageProperty;
    }
    class StorageConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): StorageConfigProperty | undefined;
        set internalValue(value: StorageConfigProperty | undefined);
        private _blockStorage;
        get blockStorage(): BlockStoragePropertyOutputReference;
        putBlockStorage(value: BlockStorageProperty): void;
        resetBlockStorage(): void;
        get blockStorageInput(): BlockStorageProperty | undefined;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#create AwsCluster#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#delete AwsCluster#delete}
        */
        readonly delete?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#update AwsCluster#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
    interface UpgradePolicyProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#support_type AwsCluster#support_type}
        */
        readonly supportType?: string;
    }
    class UpgradePolicyPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): UpgradePolicyProperty | undefined;
        set internalValue(value: UpgradePolicyProperty | undefined);
        private _supportType?;
        get supportType(): string;
        set supportType(value: string);
        resetSupportType(): void;
        get supportTypeInput(): string | undefined;
    }
    interface VpcConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#control_plane_egress_mode AwsCluster#control_plane_egress_mode}
        */
        readonly controlPlaneEgressMode?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#endpoint_private_access AwsCluster#endpoint_private_access}
        */
        readonly endpointPrivateAccess?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#endpoint_public_access AwsCluster#endpoint_public_access}
        */
        readonly endpointPublicAccess?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#public_access_cidrs AwsCluster#public_access_cidrs}
        */
        readonly publicAccessCidrs?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#security_group_ids AwsCluster#security_group_ids}
        */
        readonly securityGroupIds?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#subnet_ids AwsCluster#subnet_ids}
        */
        readonly subnetIds: string[];
    }
    class VpcConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): VpcConfigProperty | undefined;
        set internalValue(value: VpcConfigProperty | undefined);
        get clusterSecurityGroupId(): string;
        private _controlPlaneEgressMode?;
        get controlPlaneEgressMode(): string;
        set controlPlaneEgressMode(value: string);
        resetControlPlaneEgressMode(): void;
        get controlPlaneEgressModeInput(): string | undefined;
        private _endpointPrivateAccess?;
        get endpointPrivateAccess(): boolean | cdktn.IResolvable;
        set endpointPrivateAccess(value: boolean | cdktn.IResolvable);
        resetEndpointPrivateAccess(): void;
        get endpointPrivateAccessInput(): boolean | cdktn.IResolvable | undefined;
        private _endpointPublicAccess?;
        get endpointPublicAccess(): boolean | cdktn.IResolvable;
        set endpointPublicAccess(value: boolean | cdktn.IResolvable);
        resetEndpointPublicAccess(): void;
        get endpointPublicAccessInput(): boolean | cdktn.IResolvable | undefined;
        private _publicAccessCidrs?;
        get publicAccessCidrs(): string[];
        set publicAccessCidrs(value: string[]);
        resetPublicAccessCidrs(): void;
        get publicAccessCidrsInput(): string[] | undefined;
        private _securityGroupIds?;
        get securityGroupIds(): string[];
        set securityGroupIds(value: string[]);
        resetSecurityGroupIds(): void;
        get securityGroupIdsInput(): string[] | undefined;
        private _subnetIds?;
        get subnetIds(): string[];
        set subnetIds(value: string[]);
        get subnetIdsInput(): string[] | undefined;
        get vpcId(): string;
    }
    interface ZonalShiftConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/eks_cluster#enabled AwsCluster#enabled}
        */
        readonly enabled?: boolean | cdktn.IResolvable;
    }
    class ZonalShiftConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ZonalShiftConfigProperty | undefined;
        set internalValue(value: ZonalShiftConfigProperty | undefined);
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        resetEnabled(): void;
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
    }
}
