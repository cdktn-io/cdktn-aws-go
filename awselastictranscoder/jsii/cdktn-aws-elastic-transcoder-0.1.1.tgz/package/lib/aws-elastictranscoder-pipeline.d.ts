import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsElastictranscoderPipelineConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elastictranscoder_pipeline#aws_kms_key_arn AwsElastictranscoderPipeline#aws_kms_key_arn}
    */
    readonly awsKmsKeyArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elastictranscoder_pipeline#id AwsElastictranscoderPipeline#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elastictranscoder_pipeline#input_bucket AwsElastictranscoderPipeline#input_bucket}
    */
    readonly inputBucket: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elastictranscoder_pipeline#name AwsElastictranscoderPipeline#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elastictranscoder_pipeline#output_bucket AwsElastictranscoderPipeline#output_bucket}
    */
    readonly outputBucket?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elastictranscoder_pipeline#region AwsElastictranscoderPipeline#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elastictranscoder_pipeline#role AwsElastictranscoderPipeline#role}
    */
    readonly role: string;
    /**
    * content_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elastictranscoder_pipeline#content_config AwsElastictranscoderPipeline#content_config}
    */
    readonly contentConfig?: AwsElastictranscoderPipeline.ContentConfigProperty;
    /**
    * content_config_permissions block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elastictranscoder_pipeline#content_config_permissions AwsElastictranscoderPipeline#content_config_permissions}
    */
    readonly contentConfigPermissions?: AwsElastictranscoderPipeline.ContentConfigPermissionsProperty[] | cdktn.IResolvable;
    /**
    * notifications block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elastictranscoder_pipeline#notifications AwsElastictranscoderPipeline#notifications}
    */
    readonly notifications?: AwsElastictranscoderPipeline.NotificationsProperty;
    /**
    * thumbnail_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elastictranscoder_pipeline#thumbnail_config AwsElastictranscoderPipeline#thumbnail_config}
    */
    readonly thumbnailConfig?: AwsElastictranscoderPipeline.ThumbnailConfigProperty;
    /**
    * thumbnail_config_permissions block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elastictranscoder_pipeline#thumbnail_config_permissions AwsElastictranscoderPipeline#thumbnail_config_permissions}
    */
    readonly thumbnailConfigPermissions?: AwsElastictranscoderPipeline.ThumbnailConfigPermissionsProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elastictranscoder_pipeline aws_elastictranscoder_pipeline}
*/
export declare class AwsElastictranscoderPipeline extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_elastictranscoder_pipeline";
    /**
    * Generates CDKTN code for importing a AwsElastictranscoderPipeline resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsElastictranscoderPipeline to import
    * @param importFromId The id of the existing AwsElastictranscoderPipeline that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elastictranscoder_pipeline#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsElastictranscoderPipeline to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elastictranscoder_pipeline aws_elastictranscoder_pipeline} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsElastictranscoderPipelineConfig
    */
    constructor(scope: Construct, id: string, config: AwsElastictranscoderPipelineConfig);
    get arn(): string;
    private _awsKmsKeyArn?;
    get awsKmsKeyArn(): string;
    set awsKmsKeyArn(value: string);
    resetAwsKmsKeyArn(): void;
    get awsKmsKeyArnInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _inputBucket?;
    get inputBucket(): string;
    set inputBucket(value: string);
    get inputBucketInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _outputBucket?;
    get outputBucket(): string;
    set outputBucket(value: string);
    resetOutputBucket(): void;
    get outputBucketInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _role?;
    get role(): string;
    set role(value: string);
    get roleInput(): string | undefined;
    private _contentConfig;
    get contentConfig(): AwsElastictranscoderPipeline.ContentConfigPropertyOutputReference;
    putContentConfig(value: AwsElastictranscoderPipeline.ContentConfigProperty): void;
    resetContentConfig(): void;
    get contentConfigInput(): AwsElastictranscoderPipeline.ContentConfigProperty | undefined;
    private _contentConfigPermissions;
    get contentConfigPermissions(): AwsElastictranscoderPipeline.ContentConfigPermissionsPropertyList;
    putContentConfigPermissions(value: AwsElastictranscoderPipeline.ContentConfigPermissionsProperty[] | cdktn.IResolvable): void;
    resetContentConfigPermissions(): void;
    get contentConfigPermissionsInput(): cdktn.IResolvable | AwsElastictranscoderPipeline.ContentConfigPermissionsProperty[] | undefined;
    private _notifications;
    get notifications(): AwsElastictranscoderPipeline.NotificationsPropertyOutputReference;
    putNotifications(value: AwsElastictranscoderPipeline.NotificationsProperty): void;
    resetNotifications(): void;
    get notificationsInput(): AwsElastictranscoderPipeline.NotificationsProperty | undefined;
    private _thumbnailConfig;
    get thumbnailConfig(): AwsElastictranscoderPipeline.ThumbnailConfigPropertyOutputReference;
    putThumbnailConfig(value: AwsElastictranscoderPipeline.ThumbnailConfigProperty): void;
    resetThumbnailConfig(): void;
    get thumbnailConfigInput(): AwsElastictranscoderPipeline.ThumbnailConfigProperty | undefined;
    private _thumbnailConfigPermissions;
    get thumbnailConfigPermissions(): AwsElastictranscoderPipeline.ThumbnailConfigPermissionsPropertyList;
    putThumbnailConfigPermissions(value: AwsElastictranscoderPipeline.ThumbnailConfigPermissionsProperty[] | cdktn.IResolvable): void;
    resetThumbnailConfigPermissions(): void;
    get thumbnailConfigPermissionsInput(): cdktn.IResolvable | AwsElastictranscoderPipeline.ThumbnailConfigPermissionsProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsElastictranscoderPipelineContentConfigPropertyToTerraform(struct?: AwsElastictranscoderPipeline.ContentConfigPropertyOutputReference | AwsElastictranscoderPipeline.ContentConfigProperty): any;
export declare function awsElastictranscoderPipelineContentConfigPropertyToHclTerraform(struct?: AwsElastictranscoderPipeline.ContentConfigPropertyOutputReference | AwsElastictranscoderPipeline.ContentConfigProperty): any;
export declare function awsElastictranscoderPipelineContentConfigPermissionsPropertyToTerraform(struct?: AwsElastictranscoderPipeline.ContentConfigPermissionsProperty | cdktn.IResolvable): any;
export declare function awsElastictranscoderPipelineContentConfigPermissionsPropertyToHclTerraform(struct?: AwsElastictranscoderPipeline.ContentConfigPermissionsProperty | cdktn.IResolvable): any;
export declare function awsElastictranscoderPipelineNotificationsPropertyToTerraform(struct?: AwsElastictranscoderPipeline.NotificationsPropertyOutputReference | AwsElastictranscoderPipeline.NotificationsProperty): any;
export declare function awsElastictranscoderPipelineNotificationsPropertyToHclTerraform(struct?: AwsElastictranscoderPipeline.NotificationsPropertyOutputReference | AwsElastictranscoderPipeline.NotificationsProperty): any;
export declare function awsElastictranscoderPipelineThumbnailConfigPropertyToTerraform(struct?: AwsElastictranscoderPipeline.ThumbnailConfigPropertyOutputReference | AwsElastictranscoderPipeline.ThumbnailConfigProperty): any;
export declare function awsElastictranscoderPipelineThumbnailConfigPropertyToHclTerraform(struct?: AwsElastictranscoderPipeline.ThumbnailConfigPropertyOutputReference | AwsElastictranscoderPipeline.ThumbnailConfigProperty): any;
export declare function awsElastictranscoderPipelineThumbnailConfigPermissionsPropertyToTerraform(struct?: AwsElastictranscoderPipeline.ThumbnailConfigPermissionsProperty | cdktn.IResolvable): any;
export declare function awsElastictranscoderPipelineThumbnailConfigPermissionsPropertyToHclTerraform(struct?: AwsElastictranscoderPipeline.ThumbnailConfigPermissionsProperty | cdktn.IResolvable): any;
export declare namespace AwsElastictranscoderPipeline {
    interface ContentConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elastictranscoder_pipeline#bucket AwsElastictranscoderPipeline#bucket}
        */
        readonly bucket?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elastictranscoder_pipeline#storage_class AwsElastictranscoderPipeline#storage_class}
        */
        readonly storageClass?: string;
    }
    class ContentConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ContentConfigProperty | undefined;
        set internalValue(value: ContentConfigProperty | undefined);
        private _bucket?;
        get bucket(): string;
        set bucket(value: string);
        resetBucket(): void;
        get bucketInput(): string | undefined;
        private _storageClass?;
        get storageClass(): string;
        set storageClass(value: string);
        resetStorageClass(): void;
        get storageClassInput(): string | undefined;
    }
    interface ContentConfigPermissionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elastictranscoder_pipeline#access AwsElastictranscoderPipeline#access}
        */
        readonly access?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elastictranscoder_pipeline#grantee AwsElastictranscoderPipeline#grantee}
        */
        readonly grantee?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elastictranscoder_pipeline#grantee_type AwsElastictranscoderPipeline#grantee_type}
        */
        readonly granteeType?: string;
    }
    class ContentConfigPermissionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ContentConfigPermissionsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ContentConfigPermissionsProperty | cdktn.IResolvable | undefined);
        private _access?;
        get access(): string[];
        set access(value: string[]);
        resetAccess(): void;
        get accessInput(): string[] | undefined;
        private _grantee?;
        get grantee(): string;
        set grantee(value: string);
        resetGrantee(): void;
        get granteeInput(): string | undefined;
        private _granteeType?;
        get granteeType(): string;
        set granteeType(value: string);
        resetGranteeType(): void;
        get granteeTypeInput(): string | undefined;
    }
    class ContentConfigPermissionsPropertyList extends cdktn.ComplexList {
        internalValue?: ContentConfigPermissionsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ContentConfigPermissionsPropertyOutputReference;
    }
    interface NotificationsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elastictranscoder_pipeline#completed AwsElastictranscoderPipeline#completed}
        */
        readonly completed?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elastictranscoder_pipeline#error AwsElastictranscoderPipeline#error}
        */
        readonly error?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elastictranscoder_pipeline#progressing AwsElastictranscoderPipeline#progressing}
        */
        readonly progressing?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elastictranscoder_pipeline#warning AwsElastictranscoderPipeline#warning}
        */
        readonly warning?: string;
    }
    class NotificationsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): NotificationsProperty | undefined;
        set internalValue(value: NotificationsProperty | undefined);
        private _completed?;
        get completed(): string;
        set completed(value: string);
        resetCompleted(): void;
        get completedInput(): string | undefined;
        private _error?;
        get error(): string;
        set error(value: string);
        resetError(): void;
        get errorInput(): string | undefined;
        private _progressing?;
        get progressing(): string;
        set progressing(value: string);
        resetProgressing(): void;
        get progressingInput(): string | undefined;
        private _warning?;
        get warning(): string;
        set warning(value: string);
        resetWarning(): void;
        get warningInput(): string | undefined;
    }
    interface ThumbnailConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elastictranscoder_pipeline#bucket AwsElastictranscoderPipeline#bucket}
        */
        readonly bucket?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elastictranscoder_pipeline#storage_class AwsElastictranscoderPipeline#storage_class}
        */
        readonly storageClass?: string;
    }
    class ThumbnailConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ThumbnailConfigProperty | undefined;
        set internalValue(value: ThumbnailConfigProperty | undefined);
        private _bucket?;
        get bucket(): string;
        set bucket(value: string);
        resetBucket(): void;
        get bucketInput(): string | undefined;
        private _storageClass?;
        get storageClass(): string;
        set storageClass(value: string);
        resetStorageClass(): void;
        get storageClassInput(): string | undefined;
    }
    interface ThumbnailConfigPermissionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elastictranscoder_pipeline#access AwsElastictranscoderPipeline#access}
        */
        readonly access?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elastictranscoder_pipeline#grantee AwsElastictranscoderPipeline#grantee}
        */
        readonly grantee?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elastictranscoder_pipeline#grantee_type AwsElastictranscoderPipeline#grantee_type}
        */
        readonly granteeType?: string;
    }
    class ThumbnailConfigPermissionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ThumbnailConfigPermissionsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ThumbnailConfigPermissionsProperty | cdktn.IResolvable | undefined);
        private _access?;
        get access(): string[];
        set access(value: string[]);
        resetAccess(): void;
        get accessInput(): string[] | undefined;
        private _grantee?;
        get grantee(): string;
        set grantee(value: string);
        resetGrantee(): void;
        get granteeInput(): string | undefined;
        private _granteeType?;
        get granteeType(): string;
        set granteeType(value: string);
        resetGranteeType(): void;
        get granteeTypeInput(): string | undefined;
    }
    class ThumbnailConfigPermissionsPropertyList extends cdktn.ComplexList {
        internalValue?: ThumbnailConfigPermissionsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ThumbnailConfigPermissionsPropertyOutputReference;
    }
}
