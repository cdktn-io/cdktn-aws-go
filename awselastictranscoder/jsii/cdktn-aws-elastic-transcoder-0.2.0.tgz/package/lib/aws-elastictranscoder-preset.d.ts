import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfPresetConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elastictranscoder_preset#container TfPreset#container}
    */
    readonly container: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elastictranscoder_preset#description TfPreset#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elastictranscoder_preset#id TfPreset#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elastictranscoder_preset#name TfPreset#name}
    */
    readonly name?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elastictranscoder_preset#region TfPreset#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elastictranscoder_preset#type TfPreset#type}
    */
    readonly type?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elastictranscoder_preset#video_codec_options TfPreset#video_codec_options}
    */
    readonly videoCodecOptions?: {
        [key: string]: string;
    };
    /**
    * audio block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elastictranscoder_preset#audio TfPreset#audio}
    */
    readonly audio?: TfPreset.AudioProperty;
    /**
    * audio_codec_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elastictranscoder_preset#audio_codec_options TfPreset#audio_codec_options}
    */
    readonly audioCodecOptions?: TfPreset.AudioCodecOptionsProperty;
    /**
    * thumbnails block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elastictranscoder_preset#thumbnails TfPreset#thumbnails}
    */
    readonly thumbnails?: TfPreset.ThumbnailsProperty;
    /**
    * video block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elastictranscoder_preset#video TfPreset#video}
    */
    readonly video?: TfPreset.VideoProperty;
    /**
    * video_watermarks block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elastictranscoder_preset#video_watermarks TfPreset#video_watermarks}
    */
    readonly videoWatermarks?: TfPreset.VideoWatermarksProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elastictranscoder_preset aws_elastictranscoder_preset}
*/
export declare class TfPreset extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_elastictranscoder_preset";
    /**
    * Generates CDKTN code for importing a TfPreset resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfPreset to import
    * @param importFromId The id of the existing TfPreset that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elastictranscoder_preset#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfPreset to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elastictranscoder_preset aws_elastictranscoder_preset} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfPresetConfig
    */
    constructor(scope: Construct, id: string, config: TfPresetConfig);
    get arn(): string;
    private _container?;
    get container(): string;
    set container(value: string);
    get containerInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
    private _videoCodecOptions?;
    get videoCodecOptions(): {
        [key: string]: string;
    };
    set videoCodecOptions(value: {
        [key: string]: string;
    });
    resetVideoCodecOptions(): void;
    get videoCodecOptionsInput(): {
        [key: string]: string;
    } | undefined;
    private _audio;
    get audio(): TfPreset.AudioPropertyOutputReference;
    putAudio(value: TfPreset.AudioProperty): void;
    resetAudio(): void;
    get audioInput(): TfPreset.AudioProperty | undefined;
    private _audioCodecOptions;
    get audioCodecOptions(): TfPreset.AudioCodecOptionsPropertyOutputReference;
    putAudioCodecOptions(value: TfPreset.AudioCodecOptionsProperty): void;
    resetAudioCodecOptions(): void;
    get audioCodecOptionsInput(): TfPreset.AudioCodecOptionsProperty | undefined;
    private _thumbnails;
    get thumbnails(): TfPreset.ThumbnailsPropertyOutputReference;
    putThumbnails(value: TfPreset.ThumbnailsProperty): void;
    resetThumbnails(): void;
    get thumbnailsInput(): TfPreset.ThumbnailsProperty | undefined;
    private _video;
    get video(): TfPreset.VideoPropertyOutputReference;
    putVideo(value: TfPreset.VideoProperty): void;
    resetVideo(): void;
    get videoInput(): TfPreset.VideoProperty | undefined;
    private _videoWatermarks;
    get videoWatermarks(): TfPreset.VideoWatermarksPropertyList;
    putVideoWatermarks(value: TfPreset.VideoWatermarksProperty[] | cdktn.IResolvable): void;
    resetVideoWatermarks(): void;
    get videoWatermarksInput(): cdktn.IResolvable | TfPreset.VideoWatermarksProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfPresetAudioPropertyToTerraform(struct?: TfPreset.AudioPropertyOutputReference | TfPreset.AudioProperty): any;
export declare function tfPresetAudioPropertyToHclTerraform(struct?: TfPreset.AudioPropertyOutputReference | TfPreset.AudioProperty): any;
export declare function tfPresetAudioCodecOptionsPropertyToTerraform(struct?: TfPreset.AudioCodecOptionsPropertyOutputReference | TfPreset.AudioCodecOptionsProperty): any;
export declare function tfPresetAudioCodecOptionsPropertyToHclTerraform(struct?: TfPreset.AudioCodecOptionsPropertyOutputReference | TfPreset.AudioCodecOptionsProperty): any;
export declare function tfPresetThumbnailsPropertyToTerraform(struct?: TfPreset.ThumbnailsPropertyOutputReference | TfPreset.ThumbnailsProperty): any;
export declare function tfPresetThumbnailsPropertyToHclTerraform(struct?: TfPreset.ThumbnailsPropertyOutputReference | TfPreset.ThumbnailsProperty): any;
export declare function tfPresetVideoPropertyToTerraform(struct?: TfPreset.VideoPropertyOutputReference | TfPreset.VideoProperty): any;
export declare function tfPresetVideoPropertyToHclTerraform(struct?: TfPreset.VideoPropertyOutputReference | TfPreset.VideoProperty): any;
export declare function tfPresetVideoWatermarksPropertyToTerraform(struct?: TfPreset.VideoWatermarksProperty | cdktn.IResolvable): any;
export declare function tfPresetVideoWatermarksPropertyToHclTerraform(struct?: TfPreset.VideoWatermarksProperty | cdktn.IResolvable): any;
export declare namespace TfPreset {
    interface AudioProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elastictranscoder_preset#audio_packing_mode TfPreset#audio_packing_mode}
        */
        readonly audioPackingMode?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elastictranscoder_preset#bit_rate TfPreset#bit_rate}
        */
        readonly bitRate?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elastictranscoder_preset#channels TfPreset#channels}
        */
        readonly channels?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elastictranscoder_preset#codec TfPreset#codec}
        */
        readonly codec?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elastictranscoder_preset#sample_rate TfPreset#sample_rate}
        */
        readonly sampleRate?: string;
    }
    class AudioPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AudioProperty | undefined;
        set internalValue(value: AudioProperty | undefined);
        private _audioPackingMode?;
        get audioPackingMode(): string;
        set audioPackingMode(value: string);
        resetAudioPackingMode(): void;
        get audioPackingModeInput(): string | undefined;
        private _bitRate?;
        get bitRate(): string;
        set bitRate(value: string);
        resetBitRate(): void;
        get bitRateInput(): string | undefined;
        private _channels?;
        get channels(): string;
        set channels(value: string);
        resetChannels(): void;
        get channelsInput(): string | undefined;
        private _codec?;
        get codec(): string;
        set codec(value: string);
        resetCodec(): void;
        get codecInput(): string | undefined;
        private _sampleRate?;
        get sampleRate(): string;
        set sampleRate(value: string);
        resetSampleRate(): void;
        get sampleRateInput(): string | undefined;
    }
    interface AudioCodecOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elastictranscoder_preset#bit_depth TfPreset#bit_depth}
        */
        readonly bitDepth?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elastictranscoder_preset#bit_order TfPreset#bit_order}
        */
        readonly bitOrder?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elastictranscoder_preset#profile TfPreset#profile}
        */
        readonly profile?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elastictranscoder_preset#signed TfPreset#signed}
        */
        readonly signed?: string;
    }
    class AudioCodecOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AudioCodecOptionsProperty | undefined;
        set internalValue(value: AudioCodecOptionsProperty | undefined);
        private _bitDepth?;
        get bitDepth(): string;
        set bitDepth(value: string);
        resetBitDepth(): void;
        get bitDepthInput(): string | undefined;
        private _bitOrder?;
        get bitOrder(): string;
        set bitOrder(value: string);
        resetBitOrder(): void;
        get bitOrderInput(): string | undefined;
        private _profile?;
        get profile(): string;
        set profile(value: string);
        resetProfile(): void;
        get profileInput(): string | undefined;
        private _signed?;
        get signed(): string;
        set signed(value: string);
        resetSigned(): void;
        get signedInput(): string | undefined;
    }
    interface ThumbnailsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elastictranscoder_preset#aspect_ratio TfPreset#aspect_ratio}
        */
        readonly aspectRatio?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elastictranscoder_preset#format TfPreset#format}
        */
        readonly format?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elastictranscoder_preset#interval TfPreset#interval}
        */
        readonly interval?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elastictranscoder_preset#max_height TfPreset#max_height}
        */
        readonly maxHeight?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elastictranscoder_preset#max_width TfPreset#max_width}
        */
        readonly maxWidth?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elastictranscoder_preset#padding_policy TfPreset#padding_policy}
        */
        readonly paddingPolicy?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elastictranscoder_preset#resolution TfPreset#resolution}
        */
        readonly resolution?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elastictranscoder_preset#sizing_policy TfPreset#sizing_policy}
        */
        readonly sizingPolicy?: string;
    }
    class ThumbnailsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ThumbnailsProperty | undefined;
        set internalValue(value: ThumbnailsProperty | undefined);
        private _aspectRatio?;
        get aspectRatio(): string;
        set aspectRatio(value: string);
        resetAspectRatio(): void;
        get aspectRatioInput(): string | undefined;
        private _format?;
        get format(): string;
        set format(value: string);
        resetFormat(): void;
        get formatInput(): string | undefined;
        private _interval?;
        get interval(): string;
        set interval(value: string);
        resetInterval(): void;
        get intervalInput(): string | undefined;
        private _maxHeight?;
        get maxHeight(): string;
        set maxHeight(value: string);
        resetMaxHeight(): void;
        get maxHeightInput(): string | undefined;
        private _maxWidth?;
        get maxWidth(): string;
        set maxWidth(value: string);
        resetMaxWidth(): void;
        get maxWidthInput(): string | undefined;
        private _paddingPolicy?;
        get paddingPolicy(): string;
        set paddingPolicy(value: string);
        resetPaddingPolicy(): void;
        get paddingPolicyInput(): string | undefined;
        private _resolution?;
        get resolution(): string;
        set resolution(value: string);
        resetResolution(): void;
        get resolutionInput(): string | undefined;
        private _sizingPolicy?;
        get sizingPolicy(): string;
        set sizingPolicy(value: string);
        resetSizingPolicy(): void;
        get sizingPolicyInput(): string | undefined;
    }
    interface VideoProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elastictranscoder_preset#aspect_ratio TfPreset#aspect_ratio}
        */
        readonly aspectRatio?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elastictranscoder_preset#bit_rate TfPreset#bit_rate}
        */
        readonly bitRate?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elastictranscoder_preset#codec TfPreset#codec}
        */
        readonly codec?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elastictranscoder_preset#display_aspect_ratio TfPreset#display_aspect_ratio}
        */
        readonly displayAspectRatio?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elastictranscoder_preset#fixed_gop TfPreset#fixed_gop}
        */
        readonly fixedGop?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elastictranscoder_preset#frame_rate TfPreset#frame_rate}
        */
        readonly frameRate?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elastictranscoder_preset#keyframes_max_dist TfPreset#keyframes_max_dist}
        */
        readonly keyframesMaxDist?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elastictranscoder_preset#max_frame_rate TfPreset#max_frame_rate}
        */
        readonly maxFrameRate?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elastictranscoder_preset#max_height TfPreset#max_height}
        */
        readonly maxHeight?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elastictranscoder_preset#max_width TfPreset#max_width}
        */
        readonly maxWidth?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elastictranscoder_preset#padding_policy TfPreset#padding_policy}
        */
        readonly paddingPolicy?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elastictranscoder_preset#resolution TfPreset#resolution}
        */
        readonly resolution?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elastictranscoder_preset#sizing_policy TfPreset#sizing_policy}
        */
        readonly sizingPolicy?: string;
    }
    class VideoPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): VideoProperty | undefined;
        set internalValue(value: VideoProperty | undefined);
        private _aspectRatio?;
        get aspectRatio(): string;
        set aspectRatio(value: string);
        resetAspectRatio(): void;
        get aspectRatioInput(): string | undefined;
        private _bitRate?;
        get bitRate(): string;
        set bitRate(value: string);
        resetBitRate(): void;
        get bitRateInput(): string | undefined;
        private _codec?;
        get codec(): string;
        set codec(value: string);
        resetCodec(): void;
        get codecInput(): string | undefined;
        private _displayAspectRatio?;
        get displayAspectRatio(): string;
        set displayAspectRatio(value: string);
        resetDisplayAspectRatio(): void;
        get displayAspectRatioInput(): string | undefined;
        private _fixedGop?;
        get fixedGop(): string;
        set fixedGop(value: string);
        resetFixedGop(): void;
        get fixedGopInput(): string | undefined;
        private _frameRate?;
        get frameRate(): string;
        set frameRate(value: string);
        resetFrameRate(): void;
        get frameRateInput(): string | undefined;
        private _keyframesMaxDist?;
        get keyframesMaxDist(): string;
        set keyframesMaxDist(value: string);
        resetKeyframesMaxDist(): void;
        get keyframesMaxDistInput(): string | undefined;
        private _maxFrameRate?;
        get maxFrameRate(): string;
        set maxFrameRate(value: string);
        resetMaxFrameRate(): void;
        get maxFrameRateInput(): string | undefined;
        private _maxHeight?;
        get maxHeight(): string;
        set maxHeight(value: string);
        resetMaxHeight(): void;
        get maxHeightInput(): string | undefined;
        private _maxWidth?;
        get maxWidth(): string;
        set maxWidth(value: string);
        resetMaxWidth(): void;
        get maxWidthInput(): string | undefined;
        private _paddingPolicy?;
        get paddingPolicy(): string;
        set paddingPolicy(value: string);
        resetPaddingPolicy(): void;
        get paddingPolicyInput(): string | undefined;
        private _resolution?;
        get resolution(): string;
        set resolution(value: string);
        resetResolution(): void;
        get resolutionInput(): string | undefined;
        private _sizingPolicy?;
        get sizingPolicy(): string;
        set sizingPolicy(value: string);
        resetSizingPolicy(): void;
        get sizingPolicyInput(): string | undefined;
    }
    interface VideoWatermarksProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elastictranscoder_preset#horizontal_align TfPreset#horizontal_align}
        */
        readonly horizontalAlign?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elastictranscoder_preset#horizontal_offset TfPreset#horizontal_offset}
        */
        readonly horizontalOffset?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elastictranscoder_preset#id TfPreset#id}
        *
        * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
        * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
        */
        readonly id?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elastictranscoder_preset#max_height TfPreset#max_height}
        */
        readonly maxHeight?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elastictranscoder_preset#max_width TfPreset#max_width}
        */
        readonly maxWidth?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elastictranscoder_preset#opacity TfPreset#opacity}
        */
        readonly opacity?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elastictranscoder_preset#sizing_policy TfPreset#sizing_policy}
        */
        readonly sizingPolicy?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elastictranscoder_preset#target TfPreset#target}
        */
        readonly target?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elastictranscoder_preset#vertical_align TfPreset#vertical_align}
        */
        readonly verticalAlign?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elastictranscoder_preset#vertical_offset TfPreset#vertical_offset}
        */
        readonly verticalOffset?: string;
    }
    class VideoWatermarksPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): VideoWatermarksProperty | cdktn.IResolvable | undefined;
        set internalValue(value: VideoWatermarksProperty | cdktn.IResolvable | undefined);
        private _horizontalAlign?;
        get horizontalAlign(): string;
        set horizontalAlign(value: string);
        resetHorizontalAlign(): void;
        get horizontalAlignInput(): string | undefined;
        private _horizontalOffset?;
        get horizontalOffset(): string;
        set horizontalOffset(value: string);
        resetHorizontalOffset(): void;
        get horizontalOffsetInput(): string | undefined;
        private _id?;
        get id(): string;
        set id(value: string);
        resetId(): void;
        get idInput(): string | undefined;
        private _maxHeight?;
        get maxHeight(): string;
        set maxHeight(value: string);
        resetMaxHeight(): void;
        get maxHeightInput(): string | undefined;
        private _maxWidth?;
        get maxWidth(): string;
        set maxWidth(value: string);
        resetMaxWidth(): void;
        get maxWidthInput(): string | undefined;
        private _opacity?;
        get opacity(): string;
        set opacity(value: string);
        resetOpacity(): void;
        get opacityInput(): string | undefined;
        private _sizingPolicy?;
        get sizingPolicy(): string;
        set sizingPolicy(value: string);
        resetSizingPolicy(): void;
        get sizingPolicyInput(): string | undefined;
        private _target?;
        get target(): string;
        set target(value: string);
        resetTarget(): void;
        get targetInput(): string | undefined;
        private _verticalAlign?;
        get verticalAlign(): string;
        set verticalAlign(value: string);
        resetVerticalAlign(): void;
        get verticalAlignInput(): string | undefined;
        private _verticalOffset?;
        get verticalOffset(): string;
        set verticalOffset(value: string);
        resetVerticalOffset(): void;
        get verticalOffsetInput(): string | undefined;
    }
    class VideoWatermarksPropertyList extends cdktn.ComplexList {
        internalValue?: VideoWatermarksProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): VideoWatermarksPropertyOutputReference;
    }
}
