import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsApplicationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_application#kms_key_arn AwsApplication#kms_key_arn}
    */
    readonly kmsKeyArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_application#name AwsApplication#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_application#region AwsApplication#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_application#tags AwsApplication#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * app_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_application#app_config AwsApplication#app_config}
    */
    readonly appConfig?: AwsApplication.AppConfigProperty[] | cdktn.IResolvable;
    /**
    * data_source block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_application#data_source AwsApplication#data_source}
    */
    readonly dataSource?: AwsApplication.DataSourceProperty[] | cdktn.IResolvable;
    /**
    * iam_identity_center_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_application#iam_identity_center_options AwsApplication#iam_identity_center_options}
    */
    readonly iamIdentityCenterOptions?: AwsApplication.IamIdentityCenterOptionsProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_application#timeouts AwsApplication#timeouts}
    */
    readonly timeouts?: AwsApplication.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_application aws_opensearch_application}
*/
export declare class AwsApplication extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_opensearch_application";
    /**
    * Generates CDKTN code for importing a AwsApplication resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsApplication to import
    * @param importFromId The id of the existing AwsApplication that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_application#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsApplication to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_application aws_opensearch_application} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsApplicationConfig
    */
    constructor(scope: Construct, id: string, config: AwsApplicationConfig);
    get arn(): string;
    get endpoint(): string;
    get id(): string;
    private _kmsKeyArn?;
    get kmsKeyArn(): string;
    set kmsKeyArn(value: string);
    resetKmsKeyArn(): void;
    get kmsKeyArnInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    private _appConfig;
    get appConfig(): AwsApplication.AppConfigPropertyList;
    putAppConfig(value: AwsApplication.AppConfigProperty[] | cdktn.IResolvable): void;
    resetAppConfig(): void;
    get appConfigInput(): cdktn.IResolvable | AwsApplication.AppConfigProperty[] | undefined;
    private _dataSource;
    get dataSource(): AwsApplication.DataSourcePropertyList;
    putDataSource(value: AwsApplication.DataSourceProperty[] | cdktn.IResolvable): void;
    resetDataSource(): void;
    get dataSourceInput(): cdktn.IResolvable | AwsApplication.DataSourceProperty[] | undefined;
    private _iamIdentityCenterOptions;
    get iamIdentityCenterOptions(): AwsApplication.IamIdentityCenterOptionsPropertyList;
    putIamIdentityCenterOptions(value: AwsApplication.IamIdentityCenterOptionsProperty[] | cdktn.IResolvable): void;
    resetIamIdentityCenterOptions(): void;
    get iamIdentityCenterOptionsInput(): cdktn.IResolvable | AwsApplication.IamIdentityCenterOptionsProperty[] | undefined;
    private _timeouts;
    get timeouts(): AwsApplication.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsApplication.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsApplication.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsApplicationAppConfigPropertyToTerraform(struct?: AwsApplication.AppConfigProperty | cdktn.IResolvable): any;
export declare function awsApplicationAppConfigPropertyToHclTerraform(struct?: AwsApplication.AppConfigProperty | cdktn.IResolvable): any;
export declare function awsApplicationDataSourcePropertyToTerraform(struct?: AwsApplication.DataSourceProperty | cdktn.IResolvable): any;
export declare function awsApplicationDataSourcePropertyToHclTerraform(struct?: AwsApplication.DataSourceProperty | cdktn.IResolvable): any;
export declare function awsApplicationIamIdentityCenterOptionsPropertyToTerraform(struct?: AwsApplication.IamIdentityCenterOptionsProperty | cdktn.IResolvable): any;
export declare function awsApplicationIamIdentityCenterOptionsPropertyToHclTerraform(struct?: AwsApplication.IamIdentityCenterOptionsProperty | cdktn.IResolvable): any;
export declare function awsApplicationTimeoutsPropertyToTerraform(struct?: AwsApplication.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsApplicationTimeoutsPropertyToHclTerraform(struct?: AwsApplication.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsApplication {
    interface AppConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_application#key AwsApplication#key}
        */
        readonly key?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_application#value AwsApplication#value}
        */
        readonly value?: string;
    }
    class AppConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AppConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: AppConfigProperty | cdktn.IResolvable | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        resetKey(): void;
        get keyInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        resetValue(): void;
        get valueInput(): string | undefined;
    }
    class AppConfigPropertyList extends cdktn.ComplexList {
        internalValue?: AppConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AppConfigPropertyOutputReference;
    }
    interface DataSourceProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_application#data_source_arn AwsApplication#data_source_arn}
        */
        readonly dataSourceArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_application#data_source_description AwsApplication#data_source_description}
        */
        readonly dataSourceDescription?: string;
    }
    class DataSourcePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DataSourceProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DataSourceProperty | cdktn.IResolvable | undefined);
        private _dataSourceArn?;
        get dataSourceArn(): string;
        set dataSourceArn(value: string);
        resetDataSourceArn(): void;
        get dataSourceArnInput(): string | undefined;
        private _dataSourceDescription?;
        get dataSourceDescription(): string;
        set dataSourceDescription(value: string);
        resetDataSourceDescription(): void;
        get dataSourceDescriptionInput(): string | undefined;
    }
    class DataSourcePropertyList extends cdktn.ComplexList {
        internalValue?: DataSourceProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DataSourcePropertyOutputReference;
    }
    interface IamIdentityCenterOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_application#enabled AwsApplication#enabled}
        */
        readonly enabled?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_application#iam_identity_center_instance_arn AwsApplication#iam_identity_center_instance_arn}
        */
        readonly iamIdentityCenterInstanceArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_application#iam_role_for_identity_center_application_arn AwsApplication#iam_role_for_identity_center_application_arn}
        */
        readonly iamRoleForIdentityCenterApplicationArn?: string;
    }
    class IamIdentityCenterOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): IamIdentityCenterOptionsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: IamIdentityCenterOptionsProperty | cdktn.IResolvable | undefined);
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        resetEnabled(): void;
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
        get iamIdentityCenterApplicationArn(): string;
        private _iamIdentityCenterInstanceArn?;
        get iamIdentityCenterInstanceArn(): string;
        set iamIdentityCenterInstanceArn(value: string);
        resetIamIdentityCenterInstanceArn(): void;
        get iamIdentityCenterInstanceArnInput(): string | undefined;
        private _iamRoleForIdentityCenterApplicationArn?;
        get iamRoleForIdentityCenterApplicationArn(): string;
        set iamRoleForIdentityCenterApplicationArn(value: string);
        resetIamRoleForIdentityCenterApplicationArn(): void;
        get iamRoleForIdentityCenterApplicationArnInput(): string | undefined;
    }
    class IamIdentityCenterOptionsPropertyList extends cdktn.ComplexList {
        internalValue?: IamIdentityCenterOptionsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): IamIdentityCenterOptionsPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_application#create AwsApplication#create}
        */
        readonly create?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Setting a timeout for a Delete operation is only applicable if changes are saved into state before the destroy operation occurs.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_application#delete AwsApplication#delete}
        */
        readonly delete?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_application#update AwsApplication#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
