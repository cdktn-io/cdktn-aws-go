import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsVpcEndpointConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_vpc_endpoint#domain_arn AwsVpcEndpoint#domain_arn}
    */
    readonly domainArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_vpc_endpoint#id AwsVpcEndpoint#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_vpc_endpoint#region AwsVpcEndpoint#region}
    */
    readonly region?: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_vpc_endpoint#timeouts AwsVpcEndpoint#timeouts}
    */
    readonly timeouts?: AwsVpcEndpoint.TimeoutsProperty;
    /**
    * vpc_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_vpc_endpoint#vpc_options AwsVpcEndpoint#vpc_options}
    */
    readonly vpcOptions: AwsVpcEndpoint.VpcOptionsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_vpc_endpoint aws_opensearch_vpc_endpoint}
*/
export declare class AwsVpcEndpoint extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_opensearch_vpc_endpoint";
    /**
    * Generates CDKTN code for importing a AwsVpcEndpoint resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsVpcEndpoint to import
    * @param importFromId The id of the existing AwsVpcEndpoint that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_vpc_endpoint#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsVpcEndpoint to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_vpc_endpoint aws_opensearch_vpc_endpoint} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsVpcEndpointConfig
    */
    constructor(scope: Construct, id: string, config: AwsVpcEndpointConfig);
    private _domainArn?;
    get domainArn(): string;
    set domainArn(value: string);
    get domainArnInput(): string | undefined;
    get endpoint(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _timeouts;
    get timeouts(): AwsVpcEndpoint.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsVpcEndpoint.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsVpcEndpoint.TimeoutsProperty | undefined;
    private _vpcOptions;
    get vpcOptions(): AwsVpcEndpoint.VpcOptionsPropertyOutputReference;
    putVpcOptions(value: AwsVpcEndpoint.VpcOptionsProperty): void;
    get vpcOptionsInput(): AwsVpcEndpoint.VpcOptionsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsVpcEndpointTimeoutsPropertyToTerraform(struct?: AwsVpcEndpoint.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsVpcEndpointTimeoutsPropertyToHclTerraform(struct?: AwsVpcEndpoint.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsVpcEndpointVpcOptionsPropertyToTerraform(struct?: AwsVpcEndpoint.VpcOptionsPropertyOutputReference | AwsVpcEndpoint.VpcOptionsProperty): any;
export declare function awsVpcEndpointVpcOptionsPropertyToHclTerraform(struct?: AwsVpcEndpoint.VpcOptionsPropertyOutputReference | AwsVpcEndpoint.VpcOptionsProperty): any;
export declare namespace AwsVpcEndpoint {
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_vpc_endpoint#create AwsVpcEndpoint#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_vpc_endpoint#delete AwsVpcEndpoint#delete}
        */
        readonly delete?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_vpc_endpoint#update AwsVpcEndpoint#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
    interface VpcOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_vpc_endpoint#security_group_ids AwsVpcEndpoint#security_group_ids}
        */
        readonly securityGroupIds?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_vpc_endpoint#subnet_ids AwsVpcEndpoint#subnet_ids}
        */
        readonly subnetIds: string[];
    }
    class VpcOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): VpcOptionsProperty | undefined;
        set internalValue(value: VpcOptionsProperty | undefined);
        get availabilityZones(): string[];
        private _securityGroupIds?;
        get securityGroupIds(): string[];
        set securityGroupIds(value: string[]);
        resetSecurityGroupIds(): void;
        get securityGroupIdsInput(): string[] | undefined;
        private _subnetIds?;
        get subnetIds(): string[];
        set subnetIds(value: string[]);
        get subnetIdsInput(): string[] | undefined;
        get vpcId(): string;
    }
}
