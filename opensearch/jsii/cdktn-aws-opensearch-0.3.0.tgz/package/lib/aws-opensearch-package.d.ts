import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsPackageConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_package#engine_version AwsPackage#engine_version}
    */
    readonly engineVersion?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_package#id AwsPackage#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_package#package_description AwsPackage#package_description}
    */
    readonly packageDescription?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_package#package_name AwsPackage#package_name}
    */
    readonly packageName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_package#package_type AwsPackage#package_type}
    */
    readonly packageType: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_package#region AwsPackage#region}
    */
    readonly region?: string;
    /**
    * package_source block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_package#package_source AwsPackage#package_source}
    */
    readonly packageSource: AwsPackage.PackageSourceProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_package aws_opensearch_package}
*/
export declare class AwsPackage extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_opensearch_package";
    /**
    * Generates CDKTN code for importing a AwsPackage resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsPackage to import
    * @param importFromId The id of the existing AwsPackage that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_package#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsPackage to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_package aws_opensearch_package} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsPackageConfig
    */
    constructor(scope: Construct, id: string, config: AwsPackageConfig);
    get availablePackageVersion(): string;
    private _engineVersion?;
    get engineVersion(): string;
    set engineVersion(value: string);
    resetEngineVersion(): void;
    get engineVersionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _packageDescription?;
    get packageDescription(): string;
    set packageDescription(value: string);
    resetPackageDescription(): void;
    get packageDescriptionInput(): string | undefined;
    get packageId(): string;
    private _packageName?;
    get packageName(): string;
    set packageName(value: string);
    get packageNameInput(): string | undefined;
    private _packageType?;
    get packageType(): string;
    set packageType(value: string);
    get packageTypeInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _packageSource;
    get packageSource(): AwsPackage.PackageSourcePropertyOutputReference;
    putPackageSource(value: AwsPackage.PackageSourceProperty): void;
    get packageSourceInput(): AwsPackage.PackageSourceProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsPackagePackageSourcePropertyToTerraform(struct?: AwsPackage.PackageSourcePropertyOutputReference | AwsPackage.PackageSourceProperty): any;
export declare function awsPackagePackageSourcePropertyToHclTerraform(struct?: AwsPackage.PackageSourcePropertyOutputReference | AwsPackage.PackageSourceProperty): any;
export declare namespace AwsPackage {
    interface PackageSourceProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_package#s3_bucket_name AwsPackage#s3_bucket_name}
        */
        readonly s3BucketName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_package#s3_key AwsPackage#s3_key}
        */
        readonly s3Key: string;
    }
    class PackageSourcePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): PackageSourceProperty | undefined;
        set internalValue(value: PackageSourceProperty | undefined);
        private _s3BucketName?;
        get s3BucketName(): string;
        set s3BucketName(value: string);
        get s3BucketNameInput(): string | undefined;
        private _s3Key?;
        get s3Key(): string;
        set s3Key(value: string);
        get s3KeyInput(): string | undefined;
    }
}
