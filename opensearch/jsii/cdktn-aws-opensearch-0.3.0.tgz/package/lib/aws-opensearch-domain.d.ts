import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsDomainConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#access_policies AwsDomain#access_policies}
    */
    readonly accessPolicies?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#advanced_options AwsDomain#advanced_options}
    */
    readonly advancedOptions?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#domain_name AwsDomain#domain_name}
    */
    readonly domainName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#engine_version AwsDomain#engine_version}
    */
    readonly engineVersion?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#id AwsDomain#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#ip_address_type AwsDomain#ip_address_type}
    */
    readonly ipAddressType?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#region AwsDomain#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#tags AwsDomain#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#tags_all AwsDomain#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * advanced_security_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#advanced_security_options AwsDomain#advanced_security_options}
    */
    readonly advancedSecurityOptions?: AwsDomain.AdvancedSecurityOptionsProperty;
    /**
    * aiml_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#aiml_options AwsDomain#aiml_options}
    */
    readonly aimlOptions?: AwsDomain.AimlOptionsProperty;
    /**
    * auto_tune_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#auto_tune_options AwsDomain#auto_tune_options}
    */
    readonly autoTuneOptions?: AwsDomain.AutoTuneOptionsProperty;
    /**
    * cluster_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#cluster_config AwsDomain#cluster_config}
    */
    readonly clusterConfig?: AwsDomain.ClusterConfigProperty;
    /**
    * cognito_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#cognito_options AwsDomain#cognito_options}
    */
    readonly cognitoOptions?: AwsDomain.CognitoOptionsProperty;
    /**
    * deployment_strategy_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#deployment_strategy_options AwsDomain#deployment_strategy_options}
    */
    readonly deploymentStrategyOptions?: AwsDomain.DeploymentStrategyOptionsProperty;
    /**
    * domain_endpoint_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#domain_endpoint_options AwsDomain#domain_endpoint_options}
    */
    readonly domainEndpointOptions?: AwsDomain.DomainEndpointOptionsProperty;
    /**
    * ebs_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#ebs_options AwsDomain#ebs_options}
    */
    readonly ebsOptions?: AwsDomain.EbsOptionsProperty;
    /**
    * encrypt_at_rest block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#encrypt_at_rest AwsDomain#encrypt_at_rest}
    */
    readonly encryptAtRest?: AwsDomain.EncryptAtRestProperty;
    /**
    * identity_center_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#identity_center_options AwsDomain#identity_center_options}
    */
    readonly identityCenterOptions?: AwsDomain.IdentityCenterOptionsProperty;
    /**
    * log_publishing_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#log_publishing_options AwsDomain#log_publishing_options}
    */
    readonly logPublishingOptions?: AwsDomain.LogPublishingOptionsProperty[] | cdktn.IResolvable;
    /**
    * node_to_node_encryption block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#node_to_node_encryption AwsDomain#node_to_node_encryption}
    */
    readonly nodeToNodeEncryption?: AwsDomain.NodeToNodeEncryptionProperty;
    /**
    * off_peak_window_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#off_peak_window_options AwsDomain#off_peak_window_options}
    */
    readonly offPeakWindowOptions?: AwsDomain.OffPeakWindowOptionsProperty;
    /**
    * snapshot_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#snapshot_options AwsDomain#snapshot_options}
    */
    readonly snapshotOptions?: AwsDomain.SnapshotOptionsProperty;
    /**
    * software_update_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#software_update_options AwsDomain#software_update_options}
    */
    readonly softwareUpdateOptions?: AwsDomain.SoftwareUpdateOptionsProperty;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#timeouts AwsDomain#timeouts}
    */
    readonly timeouts?: AwsDomain.TimeoutsProperty;
    /**
    * vpc_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#vpc_options AwsDomain#vpc_options}
    */
    readonly vpcOptions?: AwsDomain.VpcOptionsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain aws_opensearch_domain}
*/
export declare class AwsDomain extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_opensearch_domain";
    /**
    * Generates CDKTN code for importing a AwsDomain resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsDomain to import
    * @param importFromId The id of the existing AwsDomain that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsDomain to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain aws_opensearch_domain} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsDomainConfig
    */
    constructor(scope: Construct, id: string, config: AwsDomainConfig);
    private _accessPolicies?;
    get accessPolicies(): string;
    set accessPolicies(value: string);
    resetAccessPolicies(): void;
    get accessPoliciesInput(): string | undefined;
    private _advancedOptions?;
    get advancedOptions(): {
        [key: string]: string;
    };
    set advancedOptions(value: {
        [key: string]: string;
    });
    resetAdvancedOptions(): void;
    get advancedOptionsInput(): {
        [key: string]: string;
    } | undefined;
    get arn(): string;
    get dashboardEndpoint(): string;
    get dashboardEndpointV2(): string;
    get domainEndpointV2HostedZoneId(): string;
    get domainId(): string;
    private _domainName?;
    get domainName(): string;
    set domainName(value: string);
    get domainNameInput(): string | undefined;
    get endpoint(): string;
    get endpointV2(): string;
    private _engineVersion?;
    get engineVersion(): string;
    set engineVersion(value: string);
    resetEngineVersion(): void;
    get engineVersionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _ipAddressType?;
    get ipAddressType(): string;
    set ipAddressType(value: string);
    resetIpAddressType(): void;
    get ipAddressTypeInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _advancedSecurityOptions;
    get advancedSecurityOptions(): AwsDomain.AdvancedSecurityOptionsPropertyOutputReference;
    putAdvancedSecurityOptions(value: AwsDomain.AdvancedSecurityOptionsProperty): void;
    resetAdvancedSecurityOptions(): void;
    get advancedSecurityOptionsInput(): AwsDomain.AdvancedSecurityOptionsProperty | undefined;
    private _aimlOptions;
    get aimlOptions(): AwsDomain.AimlOptionsPropertyOutputReference;
    putAimlOptions(value: AwsDomain.AimlOptionsProperty): void;
    resetAimlOptions(): void;
    get aimlOptionsInput(): AwsDomain.AimlOptionsProperty | undefined;
    private _autoTuneOptions;
    get autoTuneOptions(): AwsDomain.AutoTuneOptionsPropertyOutputReference;
    putAutoTuneOptions(value: AwsDomain.AutoTuneOptionsProperty): void;
    resetAutoTuneOptions(): void;
    get autoTuneOptionsInput(): AwsDomain.AutoTuneOptionsProperty | undefined;
    private _clusterConfig;
    get clusterConfig(): AwsDomain.ClusterConfigPropertyOutputReference;
    putClusterConfig(value: AwsDomain.ClusterConfigProperty): void;
    resetClusterConfig(): void;
    get clusterConfigInput(): AwsDomain.ClusterConfigProperty | undefined;
    private _cognitoOptions;
    get cognitoOptions(): AwsDomain.CognitoOptionsPropertyOutputReference;
    putCognitoOptions(value: AwsDomain.CognitoOptionsProperty): void;
    resetCognitoOptions(): void;
    get cognitoOptionsInput(): AwsDomain.CognitoOptionsProperty | undefined;
    private _deploymentStrategyOptions;
    get deploymentStrategyOptions(): AwsDomain.DeploymentStrategyOptionsPropertyOutputReference;
    putDeploymentStrategyOptions(value: AwsDomain.DeploymentStrategyOptionsProperty): void;
    resetDeploymentStrategyOptions(): void;
    get deploymentStrategyOptionsInput(): AwsDomain.DeploymentStrategyOptionsProperty | undefined;
    private _domainEndpointOptions;
    get domainEndpointOptions(): AwsDomain.DomainEndpointOptionsPropertyOutputReference;
    putDomainEndpointOptions(value: AwsDomain.DomainEndpointOptionsProperty): void;
    resetDomainEndpointOptions(): void;
    get domainEndpointOptionsInput(): AwsDomain.DomainEndpointOptionsProperty | undefined;
    private _ebsOptions;
    get ebsOptions(): AwsDomain.EbsOptionsPropertyOutputReference;
    putEbsOptions(value: AwsDomain.EbsOptionsProperty): void;
    resetEbsOptions(): void;
    get ebsOptionsInput(): AwsDomain.EbsOptionsProperty | undefined;
    private _encryptAtRest;
    get encryptAtRest(): AwsDomain.EncryptAtRestPropertyOutputReference;
    putEncryptAtRest(value: AwsDomain.EncryptAtRestProperty): void;
    resetEncryptAtRest(): void;
    get encryptAtRestInput(): AwsDomain.EncryptAtRestProperty | undefined;
    private _identityCenterOptions;
    get identityCenterOptions(): AwsDomain.IdentityCenterOptionsPropertyOutputReference;
    putIdentityCenterOptions(value: AwsDomain.IdentityCenterOptionsProperty): void;
    resetIdentityCenterOptions(): void;
    get identityCenterOptionsInput(): AwsDomain.IdentityCenterOptionsProperty | undefined;
    private _logPublishingOptions;
    get logPublishingOptions(): AwsDomain.LogPublishingOptionsPropertyList;
    putLogPublishingOptions(value: AwsDomain.LogPublishingOptionsProperty[] | cdktn.IResolvable): void;
    resetLogPublishingOptions(): void;
    get logPublishingOptionsInput(): cdktn.IResolvable | AwsDomain.LogPublishingOptionsProperty[] | undefined;
    private _nodeToNodeEncryption;
    get nodeToNodeEncryption(): AwsDomain.NodeToNodeEncryptionPropertyOutputReference;
    putNodeToNodeEncryption(value: AwsDomain.NodeToNodeEncryptionProperty): void;
    resetNodeToNodeEncryption(): void;
    get nodeToNodeEncryptionInput(): AwsDomain.NodeToNodeEncryptionProperty | undefined;
    private _offPeakWindowOptions;
    get offPeakWindowOptions(): AwsDomain.OffPeakWindowOptionsPropertyOutputReference;
    putOffPeakWindowOptions(value: AwsDomain.OffPeakWindowOptionsProperty): void;
    resetOffPeakWindowOptions(): void;
    get offPeakWindowOptionsInput(): AwsDomain.OffPeakWindowOptionsProperty | undefined;
    private _snapshotOptions;
    get snapshotOptions(): AwsDomain.SnapshotOptionsPropertyOutputReference;
    putSnapshotOptions(value: AwsDomain.SnapshotOptionsProperty): void;
    resetSnapshotOptions(): void;
    get snapshotOptionsInput(): AwsDomain.SnapshotOptionsProperty | undefined;
    private _softwareUpdateOptions;
    get softwareUpdateOptions(): AwsDomain.SoftwareUpdateOptionsPropertyOutputReference;
    putSoftwareUpdateOptions(value: AwsDomain.SoftwareUpdateOptionsProperty): void;
    resetSoftwareUpdateOptions(): void;
    get softwareUpdateOptionsInput(): AwsDomain.SoftwareUpdateOptionsProperty | undefined;
    private _timeouts;
    get timeouts(): AwsDomain.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsDomain.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsDomain.TimeoutsProperty | undefined;
    private _vpcOptions;
    get vpcOptions(): AwsDomain.VpcOptionsPropertyOutputReference;
    putVpcOptions(value: AwsDomain.VpcOptionsProperty): void;
    resetVpcOptions(): void;
    get vpcOptionsInput(): AwsDomain.VpcOptionsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsDomainJwtOptionsPropertyToTerraform(struct?: AwsDomain.JwtOptionsPropertyOutputReference | AwsDomain.JwtOptionsProperty): any;
export declare function awsDomainJwtOptionsPropertyToHclTerraform(struct?: AwsDomain.JwtOptionsPropertyOutputReference | AwsDomain.JwtOptionsProperty): any;
export declare function awsDomainMasterUserOptionsPropertyToTerraform(struct?: AwsDomain.MasterUserOptionsPropertyOutputReference | AwsDomain.MasterUserOptionsProperty): any;
export declare function awsDomainMasterUserOptionsPropertyToHclTerraform(struct?: AwsDomain.MasterUserOptionsPropertyOutputReference | AwsDomain.MasterUserOptionsProperty): any;
export declare function awsDomainAdvancedSecurityOptionsPropertyToTerraform(struct?: AwsDomain.AdvancedSecurityOptionsPropertyOutputReference | AwsDomain.AdvancedSecurityOptionsProperty): any;
export declare function awsDomainAdvancedSecurityOptionsPropertyToHclTerraform(struct?: AwsDomain.AdvancedSecurityOptionsPropertyOutputReference | AwsDomain.AdvancedSecurityOptionsProperty): any;
export declare function awsDomainNaturalLanguageQueryGenerationOptionsPropertyToTerraform(struct?: AwsDomain.NaturalLanguageQueryGenerationOptionsPropertyOutputReference | AwsDomain.NaturalLanguageQueryGenerationOptionsProperty): any;
export declare function awsDomainNaturalLanguageQueryGenerationOptionsPropertyToHclTerraform(struct?: AwsDomain.NaturalLanguageQueryGenerationOptionsPropertyOutputReference | AwsDomain.NaturalLanguageQueryGenerationOptionsProperty): any;
export declare function awsDomainS3VectorsEnginePropertyToTerraform(struct?: AwsDomain.S3VectorsEnginePropertyOutputReference | AwsDomain.S3VectorsEngineProperty): any;
export declare function awsDomainS3VectorsEnginePropertyToHclTerraform(struct?: AwsDomain.S3VectorsEnginePropertyOutputReference | AwsDomain.S3VectorsEngineProperty): any;
export declare function awsDomainServerlessVectorAccelerationPropertyToTerraform(struct?: AwsDomain.ServerlessVectorAccelerationPropertyOutputReference | AwsDomain.ServerlessVectorAccelerationProperty): any;
export declare function awsDomainServerlessVectorAccelerationPropertyToHclTerraform(struct?: AwsDomain.ServerlessVectorAccelerationPropertyOutputReference | AwsDomain.ServerlessVectorAccelerationProperty): any;
export declare function awsDomainAimlOptionsPropertyToTerraform(struct?: AwsDomain.AimlOptionsPropertyOutputReference | AwsDomain.AimlOptionsProperty): any;
export declare function awsDomainAimlOptionsPropertyToHclTerraform(struct?: AwsDomain.AimlOptionsPropertyOutputReference | AwsDomain.AimlOptionsProperty): any;
export declare function awsDomainDurationPropertyToTerraform(struct?: AwsDomain.DurationPropertyOutputReference | AwsDomain.DurationProperty): any;
export declare function awsDomainDurationPropertyToHclTerraform(struct?: AwsDomain.DurationPropertyOutputReference | AwsDomain.DurationProperty): any;
export declare function awsDomainMaintenanceSchedulePropertyToTerraform(struct?: AwsDomain.MaintenanceScheduleProperty | cdktn.IResolvable): any;
export declare function awsDomainMaintenanceSchedulePropertyToHclTerraform(struct?: AwsDomain.MaintenanceScheduleProperty | cdktn.IResolvable): any;
export declare function awsDomainAutoTuneOptionsPropertyToTerraform(struct?: AwsDomain.AutoTuneOptionsPropertyOutputReference | AwsDomain.AutoTuneOptionsProperty): any;
export declare function awsDomainAutoTuneOptionsPropertyToHclTerraform(struct?: AwsDomain.AutoTuneOptionsPropertyOutputReference | AwsDomain.AutoTuneOptionsProperty): any;
export declare function awsDomainColdStorageOptionsPropertyToTerraform(struct?: AwsDomain.ColdStorageOptionsPropertyOutputReference | AwsDomain.ColdStorageOptionsProperty): any;
export declare function awsDomainColdStorageOptionsPropertyToHclTerraform(struct?: AwsDomain.ColdStorageOptionsPropertyOutputReference | AwsDomain.ColdStorageOptionsProperty): any;
export declare function awsDomainNodeConfigPropertyToTerraform(struct?: AwsDomain.NodeConfigPropertyOutputReference | AwsDomain.NodeConfigProperty): any;
export declare function awsDomainNodeConfigPropertyToHclTerraform(struct?: AwsDomain.NodeConfigPropertyOutputReference | AwsDomain.NodeConfigProperty): any;
export declare function awsDomainNodeOptionsPropertyToTerraform(struct?: AwsDomain.NodeOptionsProperty | cdktn.IResolvable): any;
export declare function awsDomainNodeOptionsPropertyToHclTerraform(struct?: AwsDomain.NodeOptionsProperty | cdktn.IResolvable): any;
export declare function awsDomainZoneAwarenessConfigPropertyToTerraform(struct?: AwsDomain.ZoneAwarenessConfigPropertyOutputReference | AwsDomain.ZoneAwarenessConfigProperty): any;
export declare function awsDomainZoneAwarenessConfigPropertyToHclTerraform(struct?: AwsDomain.ZoneAwarenessConfigPropertyOutputReference | AwsDomain.ZoneAwarenessConfigProperty): any;
export declare function awsDomainClusterConfigPropertyToTerraform(struct?: AwsDomain.ClusterConfigPropertyOutputReference | AwsDomain.ClusterConfigProperty): any;
export declare function awsDomainClusterConfigPropertyToHclTerraform(struct?: AwsDomain.ClusterConfigPropertyOutputReference | AwsDomain.ClusterConfigProperty): any;
export declare function awsDomainCognitoOptionsPropertyToTerraform(struct?: AwsDomain.CognitoOptionsPropertyOutputReference | AwsDomain.CognitoOptionsProperty): any;
export declare function awsDomainCognitoOptionsPropertyToHclTerraform(struct?: AwsDomain.CognitoOptionsPropertyOutputReference | AwsDomain.CognitoOptionsProperty): any;
export declare function awsDomainDeploymentStrategyOptionsPropertyToTerraform(struct?: AwsDomain.DeploymentStrategyOptionsPropertyOutputReference | AwsDomain.DeploymentStrategyOptionsProperty): any;
export declare function awsDomainDeploymentStrategyOptionsPropertyToHclTerraform(struct?: AwsDomain.DeploymentStrategyOptionsPropertyOutputReference | AwsDomain.DeploymentStrategyOptionsProperty): any;
export declare function awsDomainDomainEndpointOptionsPropertyToTerraform(struct?: AwsDomain.DomainEndpointOptionsPropertyOutputReference | AwsDomain.DomainEndpointOptionsProperty): any;
export declare function awsDomainDomainEndpointOptionsPropertyToHclTerraform(struct?: AwsDomain.DomainEndpointOptionsPropertyOutputReference | AwsDomain.DomainEndpointOptionsProperty): any;
export declare function awsDomainEbsOptionsPropertyToTerraform(struct?: AwsDomain.EbsOptionsPropertyOutputReference | AwsDomain.EbsOptionsProperty): any;
export declare function awsDomainEbsOptionsPropertyToHclTerraform(struct?: AwsDomain.EbsOptionsPropertyOutputReference | AwsDomain.EbsOptionsProperty): any;
export declare function awsDomainEncryptAtRestPropertyToTerraform(struct?: AwsDomain.EncryptAtRestPropertyOutputReference | AwsDomain.EncryptAtRestProperty): any;
export declare function awsDomainEncryptAtRestPropertyToHclTerraform(struct?: AwsDomain.EncryptAtRestPropertyOutputReference | AwsDomain.EncryptAtRestProperty): any;
export declare function awsDomainIdentityCenterOptionsPropertyToTerraform(struct?: AwsDomain.IdentityCenterOptionsPropertyOutputReference | AwsDomain.IdentityCenterOptionsProperty): any;
export declare function awsDomainIdentityCenterOptionsPropertyToHclTerraform(struct?: AwsDomain.IdentityCenterOptionsPropertyOutputReference | AwsDomain.IdentityCenterOptionsProperty): any;
export declare function awsDomainLogPublishingOptionsPropertyToTerraform(struct?: AwsDomain.LogPublishingOptionsProperty | cdktn.IResolvable): any;
export declare function awsDomainLogPublishingOptionsPropertyToHclTerraform(struct?: AwsDomain.LogPublishingOptionsProperty | cdktn.IResolvable): any;
export declare function awsDomainNodeToNodeEncryptionPropertyToTerraform(struct?: AwsDomain.NodeToNodeEncryptionPropertyOutputReference | AwsDomain.NodeToNodeEncryptionProperty): any;
export declare function awsDomainNodeToNodeEncryptionPropertyToHclTerraform(struct?: AwsDomain.NodeToNodeEncryptionPropertyOutputReference | AwsDomain.NodeToNodeEncryptionProperty): any;
export declare function awsDomainWindowStartTimePropertyToTerraform(struct?: AwsDomain.WindowStartTimePropertyOutputReference | AwsDomain.WindowStartTimeProperty): any;
export declare function awsDomainWindowStartTimePropertyToHclTerraform(struct?: AwsDomain.WindowStartTimePropertyOutputReference | AwsDomain.WindowStartTimeProperty): any;
export declare function awsDomainOffPeakWindowPropertyToTerraform(struct?: AwsDomain.OffPeakWindowPropertyOutputReference | AwsDomain.OffPeakWindowProperty): any;
export declare function awsDomainOffPeakWindowPropertyToHclTerraform(struct?: AwsDomain.OffPeakWindowPropertyOutputReference | AwsDomain.OffPeakWindowProperty): any;
export declare function awsDomainOffPeakWindowOptionsPropertyToTerraform(struct?: AwsDomain.OffPeakWindowOptionsPropertyOutputReference | AwsDomain.OffPeakWindowOptionsProperty): any;
export declare function awsDomainOffPeakWindowOptionsPropertyToHclTerraform(struct?: AwsDomain.OffPeakWindowOptionsPropertyOutputReference | AwsDomain.OffPeakWindowOptionsProperty): any;
export declare function awsDomainSnapshotOptionsPropertyToTerraform(struct?: AwsDomain.SnapshotOptionsPropertyOutputReference | AwsDomain.SnapshotOptionsProperty): any;
export declare function awsDomainSnapshotOptionsPropertyToHclTerraform(struct?: AwsDomain.SnapshotOptionsPropertyOutputReference | AwsDomain.SnapshotOptionsProperty): any;
export declare function awsDomainSoftwareUpdateOptionsPropertyToTerraform(struct?: AwsDomain.SoftwareUpdateOptionsPropertyOutputReference | AwsDomain.SoftwareUpdateOptionsProperty): any;
export declare function awsDomainSoftwareUpdateOptionsPropertyToHclTerraform(struct?: AwsDomain.SoftwareUpdateOptionsPropertyOutputReference | AwsDomain.SoftwareUpdateOptionsProperty): any;
export declare function awsDomainTimeoutsPropertyToTerraform(struct?: AwsDomain.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsDomainTimeoutsPropertyToHclTerraform(struct?: AwsDomain.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsDomainVpcOptionsPropertyToTerraform(struct?: AwsDomain.VpcOptionsPropertyOutputReference | AwsDomain.VpcOptionsProperty): any;
export declare function awsDomainVpcOptionsPropertyToHclTerraform(struct?: AwsDomain.VpcOptionsPropertyOutputReference | AwsDomain.VpcOptionsProperty): any;
export declare namespace AwsDomain {
    interface JwtOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#enabled AwsDomain#enabled}
        */
        readonly enabled?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#jwks_url AwsDomain#jwks_url}
        */
        readonly jwksUrl?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#public_key AwsDomain#public_key}
        */
        readonly publicKey?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#roles_key AwsDomain#roles_key}
        */
        readonly rolesKey?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#subject_key AwsDomain#subject_key}
        */
        readonly subjectKey?: string;
    }
    class JwtOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): JwtOptionsProperty | undefined;
        set internalValue(value: JwtOptionsProperty | undefined);
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        resetEnabled(): void;
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
        private _jwksUrl?;
        get jwksUrl(): string;
        set jwksUrl(value: string);
        resetJwksUrl(): void;
        get jwksUrlInput(): string | undefined;
        private _publicKey?;
        get publicKey(): string;
        set publicKey(value: string);
        resetPublicKey(): void;
        get publicKeyInput(): string | undefined;
        private _rolesKey?;
        get rolesKey(): string;
        set rolesKey(value: string);
        resetRolesKey(): void;
        get rolesKeyInput(): string | undefined;
        private _subjectKey?;
        get subjectKey(): string;
        set subjectKey(value: string);
        resetSubjectKey(): void;
        get subjectKeyInput(): string | undefined;
    }
    interface MasterUserOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#master_user_arn AwsDomain#master_user_arn}
        */
        readonly masterUserArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#master_user_name AwsDomain#master_user_name}
        */
        readonly masterUserName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#master_user_password AwsDomain#master_user_password}
        */
        readonly masterUserPassword?: string;
    }
    class MasterUserOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): MasterUserOptionsProperty | undefined;
        set internalValue(value: MasterUserOptionsProperty | undefined);
        private _masterUserArn?;
        get masterUserArn(): string;
        set masterUserArn(value: string);
        resetMasterUserArn(): void;
        get masterUserArnInput(): string | undefined;
        private _masterUserName?;
        get masterUserName(): string;
        set masterUserName(value: string);
        resetMasterUserName(): void;
        get masterUserNameInput(): string | undefined;
        private _masterUserPassword?;
        get masterUserPassword(): string;
        set masterUserPassword(value: string);
        resetMasterUserPassword(): void;
        get masterUserPasswordInput(): string | undefined;
    }
    interface AdvancedSecurityOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#anonymous_auth_enabled AwsDomain#anonymous_auth_enabled}
        */
        readonly anonymousAuthEnabled?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#enabled AwsDomain#enabled}
        */
        readonly enabled: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#internal_user_database_enabled AwsDomain#internal_user_database_enabled}
        */
        readonly internalUserDatabaseEnabled?: boolean | cdktn.IResolvable;
        /**
        * jwt_options block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#jwt_options AwsDomain#jwt_options}
        */
        readonly jwtOptions?: JwtOptionsProperty;
        /**
        * master_user_options block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#master_user_options AwsDomain#master_user_options}
        */
        readonly masterUserOptions?: MasterUserOptionsProperty;
    }
    class AdvancedSecurityOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AdvancedSecurityOptionsProperty | undefined;
        set internalValue(value: AdvancedSecurityOptionsProperty | undefined);
        private _anonymousAuthEnabled?;
        get anonymousAuthEnabled(): boolean | cdktn.IResolvable;
        set anonymousAuthEnabled(value: boolean | cdktn.IResolvable);
        resetAnonymousAuthEnabled(): void;
        get anonymousAuthEnabledInput(): boolean | cdktn.IResolvable | undefined;
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
        private _internalUserDatabaseEnabled?;
        get internalUserDatabaseEnabled(): boolean | cdktn.IResolvable;
        set internalUserDatabaseEnabled(value: boolean | cdktn.IResolvable);
        resetInternalUserDatabaseEnabled(): void;
        get internalUserDatabaseEnabledInput(): boolean | cdktn.IResolvable | undefined;
        private _jwtOptions;
        get jwtOptions(): JwtOptionsPropertyOutputReference;
        putJwtOptions(value: JwtOptionsProperty): void;
        resetJwtOptions(): void;
        get jwtOptionsInput(): JwtOptionsProperty | undefined;
        private _masterUserOptions;
        get masterUserOptions(): MasterUserOptionsPropertyOutputReference;
        putMasterUserOptions(value: MasterUserOptionsProperty): void;
        resetMasterUserOptions(): void;
        get masterUserOptionsInput(): MasterUserOptionsProperty | undefined;
    }
    interface NaturalLanguageQueryGenerationOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#desired_state AwsDomain#desired_state}
        */
        readonly desiredState?: string;
    }
    class NaturalLanguageQueryGenerationOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): NaturalLanguageQueryGenerationOptionsProperty | undefined;
        set internalValue(value: NaturalLanguageQueryGenerationOptionsProperty | undefined);
        private _desiredState?;
        get desiredState(): string;
        set desiredState(value: string);
        resetDesiredState(): void;
        get desiredStateInput(): string | undefined;
    }
    interface S3VectorsEngineProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#enabled AwsDomain#enabled}
        */
        readonly enabled?: boolean | cdktn.IResolvable;
    }
    class S3VectorsEnginePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): S3VectorsEngineProperty | undefined;
        set internalValue(value: S3VectorsEngineProperty | undefined);
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        resetEnabled(): void;
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface ServerlessVectorAccelerationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#enabled AwsDomain#enabled}
        */
        readonly enabled?: boolean | cdktn.IResolvable;
    }
    class ServerlessVectorAccelerationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ServerlessVectorAccelerationProperty | undefined;
        set internalValue(value: ServerlessVectorAccelerationProperty | undefined);
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        resetEnabled(): void;
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface AimlOptionsProperty {
        /**
        * natural_language_query_generation_options block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#natural_language_query_generation_options AwsDomain#natural_language_query_generation_options}
        */
        readonly naturalLanguageQueryGenerationOptions?: NaturalLanguageQueryGenerationOptionsProperty;
        /**
        * s3_vectors_engine block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#s3_vectors_engine AwsDomain#s3_vectors_engine}
        */
        readonly s3VectorsEngine?: S3VectorsEngineProperty;
        /**
        * serverless_vector_acceleration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#serverless_vector_acceleration AwsDomain#serverless_vector_acceleration}
        */
        readonly serverlessVectorAcceleration?: ServerlessVectorAccelerationProperty;
    }
    class AimlOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AimlOptionsProperty | undefined;
        set internalValue(value: AimlOptionsProperty | undefined);
        private _naturalLanguageQueryGenerationOptions;
        get naturalLanguageQueryGenerationOptions(): NaturalLanguageQueryGenerationOptionsPropertyOutputReference;
        putNaturalLanguageQueryGenerationOptions(value: NaturalLanguageQueryGenerationOptionsProperty): void;
        resetNaturalLanguageQueryGenerationOptions(): void;
        get naturalLanguageQueryGenerationOptionsInput(): NaturalLanguageQueryGenerationOptionsProperty | undefined;
        private _s3VectorsEngine;
        get s3VectorsEngine(): S3VectorsEnginePropertyOutputReference;
        putS3VectorsEngine(value: S3VectorsEngineProperty): void;
        resetS3VectorsEngine(): void;
        get s3VectorsEngineInput(): S3VectorsEngineProperty | undefined;
        private _serverlessVectorAcceleration;
        get serverlessVectorAcceleration(): ServerlessVectorAccelerationPropertyOutputReference;
        putServerlessVectorAcceleration(value: ServerlessVectorAccelerationProperty): void;
        resetServerlessVectorAcceleration(): void;
        get serverlessVectorAccelerationInput(): ServerlessVectorAccelerationProperty | undefined;
    }
    interface DurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#unit AwsDomain#unit}
        */
        readonly unit: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#value AwsDomain#value}
        */
        readonly value: number;
    }
    class DurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DurationProperty | undefined;
        set internalValue(value: DurationProperty | undefined);
        private _unit?;
        get unit(): string;
        set unit(value: string);
        get unitInput(): string | undefined;
        private _value?;
        get value(): number;
        set value(value: number);
        get valueInput(): number | undefined;
    }
    interface MaintenanceScheduleProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#cron_expression_for_recurrence AwsDomain#cron_expression_for_recurrence}
        */
        readonly cronExpressionForRecurrence: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#start_at AwsDomain#start_at}
        */
        readonly startAt: string;
        /**
        * duration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#duration AwsDomain#duration}
        */
        readonly duration: DurationProperty;
    }
    class MaintenanceSchedulePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): MaintenanceScheduleProperty | cdktn.IResolvable | undefined;
        set internalValue(value: MaintenanceScheduleProperty | cdktn.IResolvable | undefined);
        private _cronExpressionForRecurrence?;
        get cronExpressionForRecurrence(): string;
        set cronExpressionForRecurrence(value: string);
        get cronExpressionForRecurrenceInput(): string | undefined;
        private _startAt?;
        get startAt(): string;
        set startAt(value: string);
        get startAtInput(): string | undefined;
        private _duration;
        get duration(): DurationPropertyOutputReference;
        putDuration(value: DurationProperty): void;
        get durationInput(): DurationProperty | undefined;
    }
    class MaintenanceSchedulePropertyList extends cdktn.ComplexList {
        internalValue?: MaintenanceScheduleProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): MaintenanceSchedulePropertyOutputReference;
    }
    interface AutoTuneOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#desired_state AwsDomain#desired_state}
        */
        readonly desiredState: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#rollback_on_disable AwsDomain#rollback_on_disable}
        */
        readonly rollbackOnDisable?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#use_off_peak_window AwsDomain#use_off_peak_window}
        */
        readonly useOffPeakWindow?: boolean | cdktn.IResolvable;
        /**
        * maintenance_schedule block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#maintenance_schedule AwsDomain#maintenance_schedule}
        */
        readonly maintenanceSchedule?: MaintenanceScheduleProperty[] | cdktn.IResolvable;
    }
    class AutoTuneOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AutoTuneOptionsProperty | undefined;
        set internalValue(value: AutoTuneOptionsProperty | undefined);
        private _desiredState?;
        get desiredState(): string;
        set desiredState(value: string);
        get desiredStateInput(): string | undefined;
        private _rollbackOnDisable?;
        get rollbackOnDisable(): string;
        set rollbackOnDisable(value: string);
        resetRollbackOnDisable(): void;
        get rollbackOnDisableInput(): string | undefined;
        private _useOffPeakWindow?;
        get useOffPeakWindow(): boolean | cdktn.IResolvable;
        set useOffPeakWindow(value: boolean | cdktn.IResolvable);
        resetUseOffPeakWindow(): void;
        get useOffPeakWindowInput(): boolean | cdktn.IResolvable | undefined;
        private _maintenanceSchedule;
        get maintenanceSchedule(): MaintenanceSchedulePropertyList;
        putMaintenanceSchedule(value: MaintenanceScheduleProperty[] | cdktn.IResolvable): void;
        resetMaintenanceSchedule(): void;
        get maintenanceScheduleInput(): cdktn.IResolvable | MaintenanceScheduleProperty[] | undefined;
    }
    interface ColdStorageOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#enabled AwsDomain#enabled}
        */
        readonly enabled?: boolean | cdktn.IResolvable;
    }
    class ColdStorageOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ColdStorageOptionsProperty | undefined;
        set internalValue(value: ColdStorageOptionsProperty | undefined);
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        resetEnabled(): void;
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface NodeConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#count AwsDomain#count}
        */
        readonly count?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#enabled AwsDomain#enabled}
        */
        readonly enabled?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#type AwsDomain#type}
        */
        readonly type?: string;
    }
    class NodeConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): NodeConfigProperty | undefined;
        set internalValue(value: NodeConfigProperty | undefined);
        private _count?;
        get count(): number;
        set count(value: number);
        resetCount(): void;
        get countInput(): number | undefined;
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        resetEnabled(): void;
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        resetType(): void;
        get typeInput(): string | undefined;
    }
    interface NodeOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#node_type AwsDomain#node_type}
        */
        readonly nodeType?: string;
        /**
        * node_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#node_config AwsDomain#node_config}
        */
        readonly nodeConfig?: NodeConfigProperty;
    }
    class NodeOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): NodeOptionsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: NodeOptionsProperty | cdktn.IResolvable | undefined);
        private _nodeType?;
        get nodeType(): string;
        set nodeType(value: string);
        resetNodeType(): void;
        get nodeTypeInput(): string | undefined;
        private _nodeConfig;
        get nodeConfig(): NodeConfigPropertyOutputReference;
        putNodeConfig(value: NodeConfigProperty): void;
        resetNodeConfig(): void;
        get nodeConfigInput(): NodeConfigProperty | undefined;
    }
    class NodeOptionsPropertyList extends cdktn.ComplexList {
        internalValue?: NodeOptionsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): NodeOptionsPropertyOutputReference;
    }
    interface ZoneAwarenessConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#availability_zone_count AwsDomain#availability_zone_count}
        */
        readonly availabilityZoneCount?: number;
    }
    class ZoneAwarenessConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ZoneAwarenessConfigProperty | undefined;
        set internalValue(value: ZoneAwarenessConfigProperty | undefined);
        private _availabilityZoneCount?;
        get availabilityZoneCount(): number;
        set availabilityZoneCount(value: number);
        resetAvailabilityZoneCount(): void;
        get availabilityZoneCountInput(): number | undefined;
    }
    interface ClusterConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#dedicated_master_count AwsDomain#dedicated_master_count}
        */
        readonly dedicatedMasterCount?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#dedicated_master_enabled AwsDomain#dedicated_master_enabled}
        */
        readonly dedicatedMasterEnabled?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#dedicated_master_type AwsDomain#dedicated_master_type}
        */
        readonly dedicatedMasterType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#instance_count AwsDomain#instance_count}
        */
        readonly instanceCount?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#instance_type AwsDomain#instance_type}
        */
        readonly instanceType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#multi_az_with_standby_enabled AwsDomain#multi_az_with_standby_enabled}
        */
        readonly multiAzWithStandbyEnabled?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#warm_count AwsDomain#warm_count}
        */
        readonly warmCount?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#warm_enabled AwsDomain#warm_enabled}
        */
        readonly warmEnabled?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#warm_type AwsDomain#warm_type}
        */
        readonly warmType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#zone_awareness_enabled AwsDomain#zone_awareness_enabled}
        */
        readonly zoneAwarenessEnabled?: boolean | cdktn.IResolvable;
        /**
        * cold_storage_options block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#cold_storage_options AwsDomain#cold_storage_options}
        */
        readonly coldStorageOptions?: ColdStorageOptionsProperty;
        /**
        * node_options block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#node_options AwsDomain#node_options}
        */
        readonly nodeOptions?: NodeOptionsProperty[] | cdktn.IResolvable;
        /**
        * zone_awareness_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#zone_awareness_config AwsDomain#zone_awareness_config}
        */
        readonly zoneAwarenessConfig?: ZoneAwarenessConfigProperty;
    }
    class ClusterConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ClusterConfigProperty | undefined;
        set internalValue(value: ClusterConfigProperty | undefined);
        private _dedicatedMasterCount?;
        get dedicatedMasterCount(): number;
        set dedicatedMasterCount(value: number);
        resetDedicatedMasterCount(): void;
        get dedicatedMasterCountInput(): number | undefined;
        private _dedicatedMasterEnabled?;
        get dedicatedMasterEnabled(): boolean | cdktn.IResolvable;
        set dedicatedMasterEnabled(value: boolean | cdktn.IResolvable);
        resetDedicatedMasterEnabled(): void;
        get dedicatedMasterEnabledInput(): boolean | cdktn.IResolvable | undefined;
        private _dedicatedMasterType?;
        get dedicatedMasterType(): string;
        set dedicatedMasterType(value: string);
        resetDedicatedMasterType(): void;
        get dedicatedMasterTypeInput(): string | undefined;
        private _instanceCount?;
        get instanceCount(): number;
        set instanceCount(value: number);
        resetInstanceCount(): void;
        get instanceCountInput(): number | undefined;
        private _instanceType?;
        get instanceType(): string;
        set instanceType(value: string);
        resetInstanceType(): void;
        get instanceTypeInput(): string | undefined;
        private _multiAzWithStandbyEnabled?;
        get multiAzWithStandbyEnabled(): boolean | cdktn.IResolvable;
        set multiAzWithStandbyEnabled(value: boolean | cdktn.IResolvable);
        resetMultiAzWithStandbyEnabled(): void;
        get multiAzWithStandbyEnabledInput(): boolean | cdktn.IResolvable | undefined;
        private _warmCount?;
        get warmCount(): number;
        set warmCount(value: number);
        resetWarmCount(): void;
        get warmCountInput(): number | undefined;
        private _warmEnabled?;
        get warmEnabled(): boolean | cdktn.IResolvable;
        set warmEnabled(value: boolean | cdktn.IResolvable);
        resetWarmEnabled(): void;
        get warmEnabledInput(): boolean | cdktn.IResolvable | undefined;
        private _warmType?;
        get warmType(): string;
        set warmType(value: string);
        resetWarmType(): void;
        get warmTypeInput(): string | undefined;
        private _zoneAwarenessEnabled?;
        get zoneAwarenessEnabled(): boolean | cdktn.IResolvable;
        set zoneAwarenessEnabled(value: boolean | cdktn.IResolvable);
        resetZoneAwarenessEnabled(): void;
        get zoneAwarenessEnabledInput(): boolean | cdktn.IResolvable | undefined;
        private _coldStorageOptions;
        get coldStorageOptions(): ColdStorageOptionsPropertyOutputReference;
        putColdStorageOptions(value: ColdStorageOptionsProperty): void;
        resetColdStorageOptions(): void;
        get coldStorageOptionsInput(): ColdStorageOptionsProperty | undefined;
        private _nodeOptions;
        get nodeOptions(): NodeOptionsPropertyList;
        putNodeOptions(value: NodeOptionsProperty[] | cdktn.IResolvable): void;
        resetNodeOptions(): void;
        get nodeOptionsInput(): cdktn.IResolvable | NodeOptionsProperty[] | undefined;
        private _zoneAwarenessConfig;
        get zoneAwarenessConfig(): ZoneAwarenessConfigPropertyOutputReference;
        putZoneAwarenessConfig(value: ZoneAwarenessConfigProperty): void;
        resetZoneAwarenessConfig(): void;
        get zoneAwarenessConfigInput(): ZoneAwarenessConfigProperty | undefined;
    }
    interface CognitoOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#enabled AwsDomain#enabled}
        */
        readonly enabled?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#identity_pool_id AwsDomain#identity_pool_id}
        */
        readonly identityPoolId: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#role_arn AwsDomain#role_arn}
        */
        readonly roleArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#user_pool_id AwsDomain#user_pool_id}
        */
        readonly userPoolId: string;
    }
    class CognitoOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CognitoOptionsProperty | undefined;
        set internalValue(value: CognitoOptionsProperty | undefined);
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        resetEnabled(): void;
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
        private _identityPoolId?;
        get identityPoolId(): string;
        set identityPoolId(value: string);
        get identityPoolIdInput(): string | undefined;
        private _roleArn?;
        get roleArn(): string;
        set roleArn(value: string);
        get roleArnInput(): string | undefined;
        private _userPoolId?;
        get userPoolId(): string;
        set userPoolId(value: string);
        get userPoolIdInput(): string | undefined;
    }
    interface DeploymentStrategyOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#deployment_strategy AwsDomain#deployment_strategy}
        */
        readonly deploymentStrategy: string;
    }
    class DeploymentStrategyOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DeploymentStrategyOptionsProperty | undefined;
        set internalValue(value: DeploymentStrategyOptionsProperty | undefined);
        private _deploymentStrategy?;
        get deploymentStrategy(): string;
        set deploymentStrategy(value: string);
        get deploymentStrategyInput(): string | undefined;
    }
    interface DomainEndpointOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#custom_endpoint AwsDomain#custom_endpoint}
        */
        readonly customEndpoint?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#custom_endpoint_certificate_arn AwsDomain#custom_endpoint_certificate_arn}
        */
        readonly customEndpointCertificateArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#custom_endpoint_enabled AwsDomain#custom_endpoint_enabled}
        */
        readonly customEndpointEnabled?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#enforce_https AwsDomain#enforce_https}
        */
        readonly enforceHttps?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#tls_security_policy AwsDomain#tls_security_policy}
        */
        readonly tlsSecurityPolicy?: string;
    }
    class DomainEndpointOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DomainEndpointOptionsProperty | undefined;
        set internalValue(value: DomainEndpointOptionsProperty | undefined);
        private _customEndpoint?;
        get customEndpoint(): string;
        set customEndpoint(value: string);
        resetCustomEndpoint(): void;
        get customEndpointInput(): string | undefined;
        private _customEndpointCertificateArn?;
        get customEndpointCertificateArn(): string;
        set customEndpointCertificateArn(value: string);
        resetCustomEndpointCertificateArn(): void;
        get customEndpointCertificateArnInput(): string | undefined;
        private _customEndpointEnabled?;
        get customEndpointEnabled(): boolean | cdktn.IResolvable;
        set customEndpointEnabled(value: boolean | cdktn.IResolvable);
        resetCustomEndpointEnabled(): void;
        get customEndpointEnabledInput(): boolean | cdktn.IResolvable | undefined;
        private _enforceHttps?;
        get enforceHttps(): boolean | cdktn.IResolvable;
        set enforceHttps(value: boolean | cdktn.IResolvable);
        resetEnforceHttps(): void;
        get enforceHttpsInput(): boolean | cdktn.IResolvable | undefined;
        private _tlsSecurityPolicy?;
        get tlsSecurityPolicy(): string;
        set tlsSecurityPolicy(value: string);
        resetTlsSecurityPolicy(): void;
        get tlsSecurityPolicyInput(): string | undefined;
    }
    interface EbsOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#ebs_enabled AwsDomain#ebs_enabled}
        */
        readonly ebsEnabled: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#iops AwsDomain#iops}
        */
        readonly iops?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#throughput AwsDomain#throughput}
        */
        readonly throughput?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#volume_size AwsDomain#volume_size}
        */
        readonly volumeSize?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#volume_type AwsDomain#volume_type}
        */
        readonly volumeType?: string;
    }
    class EbsOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): EbsOptionsProperty | undefined;
        set internalValue(value: EbsOptionsProperty | undefined);
        private _ebsEnabled?;
        get ebsEnabled(): boolean | cdktn.IResolvable;
        set ebsEnabled(value: boolean | cdktn.IResolvable);
        get ebsEnabledInput(): boolean | cdktn.IResolvable | undefined;
        private _iops?;
        get iops(): number;
        set iops(value: number);
        resetIops(): void;
        get iopsInput(): number | undefined;
        private _throughput?;
        get throughput(): number;
        set throughput(value: number);
        resetThroughput(): void;
        get throughputInput(): number | undefined;
        private _volumeSize?;
        get volumeSize(): number;
        set volumeSize(value: number);
        resetVolumeSize(): void;
        get volumeSizeInput(): number | undefined;
        private _volumeType?;
        get volumeType(): string;
        set volumeType(value: string);
        resetVolumeType(): void;
        get volumeTypeInput(): string | undefined;
    }
    interface EncryptAtRestProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#enabled AwsDomain#enabled}
        */
        readonly enabled: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#kms_key_id AwsDomain#kms_key_id}
        */
        readonly kmsKeyId?: string;
    }
    class EncryptAtRestPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): EncryptAtRestProperty | undefined;
        set internalValue(value: EncryptAtRestProperty | undefined);
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
        private _kmsKeyId?;
        get kmsKeyId(): string;
        set kmsKeyId(value: string);
        resetKmsKeyId(): void;
        get kmsKeyIdInput(): string | undefined;
    }
    interface IdentityCenterOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#enabled_api_access AwsDomain#enabled_api_access}
        */
        readonly enabledApiAccess?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#identity_center_instance_arn AwsDomain#identity_center_instance_arn}
        */
        readonly identityCenterInstanceArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#roles_key AwsDomain#roles_key}
        */
        readonly rolesKey?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#subject_key AwsDomain#subject_key}
        */
        readonly subjectKey?: string;
    }
    class IdentityCenterOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): IdentityCenterOptionsProperty | undefined;
        set internalValue(value: IdentityCenterOptionsProperty | undefined);
        private _enabledApiAccess?;
        get enabledApiAccess(): boolean | cdktn.IResolvable;
        set enabledApiAccess(value: boolean | cdktn.IResolvable);
        resetEnabledApiAccess(): void;
        get enabledApiAccessInput(): boolean | cdktn.IResolvable | undefined;
        private _identityCenterInstanceArn?;
        get identityCenterInstanceArn(): string;
        set identityCenterInstanceArn(value: string);
        resetIdentityCenterInstanceArn(): void;
        get identityCenterInstanceArnInput(): string | undefined;
        private _rolesKey?;
        get rolesKey(): string;
        set rolesKey(value: string);
        resetRolesKey(): void;
        get rolesKeyInput(): string | undefined;
        private _subjectKey?;
        get subjectKey(): string;
        set subjectKey(value: string);
        resetSubjectKey(): void;
        get subjectKeyInput(): string | undefined;
    }
    interface LogPublishingOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#cloudwatch_log_group_arn AwsDomain#cloudwatch_log_group_arn}
        */
        readonly cloudwatchLogGroupArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#enabled AwsDomain#enabled}
        */
        readonly enabled?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#log_type AwsDomain#log_type}
        */
        readonly logType: string;
    }
    class LogPublishingOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): LogPublishingOptionsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: LogPublishingOptionsProperty | cdktn.IResolvable | undefined);
        private _cloudwatchLogGroupArn?;
        get cloudwatchLogGroupArn(): string;
        set cloudwatchLogGroupArn(value: string);
        get cloudwatchLogGroupArnInput(): string | undefined;
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        resetEnabled(): void;
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
        private _logType?;
        get logType(): string;
        set logType(value: string);
        get logTypeInput(): string | undefined;
    }
    class LogPublishingOptionsPropertyList extends cdktn.ComplexList {
        internalValue?: LogPublishingOptionsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): LogPublishingOptionsPropertyOutputReference;
    }
    interface NodeToNodeEncryptionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#enabled AwsDomain#enabled}
        */
        readonly enabled: boolean | cdktn.IResolvable;
    }
    class NodeToNodeEncryptionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): NodeToNodeEncryptionProperty | undefined;
        set internalValue(value: NodeToNodeEncryptionProperty | undefined);
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface WindowStartTimeProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#hours AwsDomain#hours}
        */
        readonly hours?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#minutes AwsDomain#minutes}
        */
        readonly minutes?: number;
    }
    class WindowStartTimePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): WindowStartTimeProperty | undefined;
        set internalValue(value: WindowStartTimeProperty | undefined);
        private _hours?;
        get hours(): number;
        set hours(value: number);
        resetHours(): void;
        get hoursInput(): number | undefined;
        private _minutes?;
        get minutes(): number;
        set minutes(value: number);
        resetMinutes(): void;
        get minutesInput(): number | undefined;
    }
    interface OffPeakWindowProperty {
        /**
        * window_start_time block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#window_start_time AwsDomain#window_start_time}
        */
        readonly windowStartTime?: WindowStartTimeProperty;
    }
    class OffPeakWindowPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): OffPeakWindowProperty | undefined;
        set internalValue(value: OffPeakWindowProperty | undefined);
        private _windowStartTime;
        get windowStartTime(): WindowStartTimePropertyOutputReference;
        putWindowStartTime(value: WindowStartTimeProperty): void;
        resetWindowStartTime(): void;
        get windowStartTimeInput(): WindowStartTimeProperty | undefined;
    }
    interface OffPeakWindowOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#enabled AwsDomain#enabled}
        */
        readonly enabled?: boolean | cdktn.IResolvable;
        /**
        * off_peak_window block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#off_peak_window AwsDomain#off_peak_window}
        */
        readonly offPeakWindow?: OffPeakWindowProperty;
    }
    class OffPeakWindowOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): OffPeakWindowOptionsProperty | undefined;
        set internalValue(value: OffPeakWindowOptionsProperty | undefined);
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        resetEnabled(): void;
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
        private _offPeakWindow;
        get offPeakWindow(): OffPeakWindowPropertyOutputReference;
        putOffPeakWindow(value: OffPeakWindowProperty): void;
        resetOffPeakWindow(): void;
        get offPeakWindowInput(): OffPeakWindowProperty | undefined;
    }
    interface SnapshotOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#automated_snapshot_start_hour AwsDomain#automated_snapshot_start_hour}
        */
        readonly automatedSnapshotStartHour: number;
    }
    class SnapshotOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SnapshotOptionsProperty | undefined;
        set internalValue(value: SnapshotOptionsProperty | undefined);
        private _automatedSnapshotStartHour?;
        get automatedSnapshotStartHour(): number;
        set automatedSnapshotStartHour(value: number);
        get automatedSnapshotStartHourInput(): number | undefined;
    }
    interface SoftwareUpdateOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#auto_software_update_enabled AwsDomain#auto_software_update_enabled}
        */
        readonly autoSoftwareUpdateEnabled?: boolean | cdktn.IResolvable;
    }
    class SoftwareUpdateOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SoftwareUpdateOptionsProperty | undefined;
        set internalValue(value: SoftwareUpdateOptionsProperty | undefined);
        private _autoSoftwareUpdateEnabled?;
        get autoSoftwareUpdateEnabled(): boolean | cdktn.IResolvable;
        set autoSoftwareUpdateEnabled(value: boolean | cdktn.IResolvable);
        resetAutoSoftwareUpdateEnabled(): void;
        get autoSoftwareUpdateEnabledInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#create AwsDomain#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#delete AwsDomain#delete}
        */
        readonly delete?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#update AwsDomain#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
    interface VpcOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#security_group_ids AwsDomain#security_group_ids}
        */
        readonly securityGroupIds?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#subnet_ids AwsDomain#subnet_ids}
        */
        readonly subnetIds?: string[];
    }
    class VpcOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): VpcOptionsProperty | undefined;
        set internalValue(value: VpcOptionsProperty | undefined);
        get availabilityZones(): string[];
        private _securityGroupIds?;
        get securityGroupIds(): string[];
        set securityGroupIds(value: string[]);
        resetSecurityGroupIds(): void;
        get securityGroupIdsInput(): string[] | undefined;
        private _subnetIds?;
        get subnetIds(): string[];
        set subnetIds(value: string[]);
        resetSubnetIds(): void;
        get subnetIdsInput(): string[] | undefined;
        get vpcId(): string;
    }
}
