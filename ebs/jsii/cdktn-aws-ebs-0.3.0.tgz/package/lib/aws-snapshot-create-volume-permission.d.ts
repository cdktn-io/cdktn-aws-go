import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsSnapshotCreateVolumePermissionConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/snapshot_create_volume_permission#account_id AwsSnapshotCreateVolumePermission#account_id}
    */
    readonly accountId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/snapshot_create_volume_permission#id AwsSnapshotCreateVolumePermission#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/snapshot_create_volume_permission#region AwsSnapshotCreateVolumePermission#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/snapshot_create_volume_permission#snapshot_id AwsSnapshotCreateVolumePermission#snapshot_id}
    */
    readonly snapshotId: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/snapshot_create_volume_permission#timeouts AwsSnapshotCreateVolumePermission#timeouts}
    */
    readonly timeouts?: AwsSnapshotCreateVolumePermission.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/snapshot_create_volume_permission aws_snapshot_create_volume_permission}
*/
export declare class AwsSnapshotCreateVolumePermission extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_snapshot_create_volume_permission";
    /**
    * Generates CDKTN code for importing a AwsSnapshotCreateVolumePermission resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsSnapshotCreateVolumePermission to import
    * @param importFromId The id of the existing AwsSnapshotCreateVolumePermission that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/snapshot_create_volume_permission#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsSnapshotCreateVolumePermission to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/snapshot_create_volume_permission aws_snapshot_create_volume_permission} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsSnapshotCreateVolumePermissionConfig
    */
    constructor(scope: Construct, id: string, config: AwsSnapshotCreateVolumePermissionConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    get accountIdInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _snapshotId?;
    get snapshotId(): string;
    set snapshotId(value: string);
    get snapshotIdInput(): string | undefined;
    private _timeouts;
    get timeouts(): AwsSnapshotCreateVolumePermission.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsSnapshotCreateVolumePermission.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsSnapshotCreateVolumePermission.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsSnapshotCreateVolumePermissionTimeoutsPropertyToTerraform(struct?: AwsSnapshotCreateVolumePermission.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsSnapshotCreateVolumePermissionTimeoutsPropertyToHclTerraform(struct?: AwsSnapshotCreateVolumePermission.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsSnapshotCreateVolumePermission {
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/snapshot_create_volume_permission#create AwsSnapshotCreateVolumePermission#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/snapshot_create_volume_permission#delete AwsSnapshotCreateVolumePermission#delete}
        */
        readonly delete?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
    }
}
