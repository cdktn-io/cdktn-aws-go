import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsEncryptionByDefaultConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ebs_encryption_by_default#id DataAwsEncryptionByDefault#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ebs_encryption_by_default#region DataAwsEncryptionByDefault#region}
    */
    readonly region?: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ebs_encryption_by_default#timeouts DataAwsEncryptionByDefault#timeouts}
    */
    readonly timeouts?: DataAwsEncryptionByDefault.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ebs_encryption_by_default aws_ebs_encryption_by_default}
*/
export declare class DataAwsEncryptionByDefault extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_ebs_encryption_by_default";
    /**
    * Generates CDKTN code for importing a DataAwsEncryptionByDefault resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsEncryptionByDefault to import
    * @param importFromId The id of the existing DataAwsEncryptionByDefault that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ebs_encryption_by_default#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsEncryptionByDefault to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ebs_encryption_by_default aws_ebs_encryption_by_default} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsEncryptionByDefaultConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataAwsEncryptionByDefaultConfig);
    get enabled(): cdktn.IResolvable;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _timeouts;
    get timeouts(): DataAwsEncryptionByDefault.TimeoutsPropertyOutputReference;
    putTimeouts(value: DataAwsEncryptionByDefault.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | DataAwsEncryptionByDefault.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataAwsEncryptionByDefaultTimeoutsPropertyToTerraform(struct?: DataAwsEncryptionByDefault.TimeoutsProperty | cdktn.IResolvable): any;
export declare function dataAwsEncryptionByDefaultTimeoutsPropertyToHclTerraform(struct?: DataAwsEncryptionByDefault.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace DataAwsEncryptionByDefault {
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ebs_encryption_by_default#read DataAwsEncryptionByDefault#read}
        */
        readonly read?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _read?;
        get read(): string;
        set read(value: string);
        resetRead(): void;
        get readInput(): string | undefined;
    }
}
