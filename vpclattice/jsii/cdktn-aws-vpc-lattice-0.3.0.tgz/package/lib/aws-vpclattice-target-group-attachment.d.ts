import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsTargetGroupAttachmentConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpclattice_target_group_attachment#id AwsTargetGroupAttachment#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpclattice_target_group_attachment#region AwsTargetGroupAttachment#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpclattice_target_group_attachment#target_group_identifier AwsTargetGroupAttachment#target_group_identifier}
    */
    readonly targetGroupIdentifier: string;
    /**
    * target block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpclattice_target_group_attachment#target AwsTargetGroupAttachment#target}
    */
    readonly target: AwsTargetGroupAttachment.TargetProperty;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpclattice_target_group_attachment#timeouts AwsTargetGroupAttachment#timeouts}
    */
    readonly timeouts?: AwsTargetGroupAttachment.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpclattice_target_group_attachment aws_vpclattice_target_group_attachment}
*/
export declare class AwsTargetGroupAttachment extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_vpclattice_target_group_attachment";
    /**
    * Generates CDKTN code for importing a AwsTargetGroupAttachment resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsTargetGroupAttachment to import
    * @param importFromId The id of the existing AwsTargetGroupAttachment that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpclattice_target_group_attachment#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsTargetGroupAttachment to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpclattice_target_group_attachment aws_vpclattice_target_group_attachment} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsTargetGroupAttachmentConfig
    */
    constructor(scope: Construct, id: string, config: AwsTargetGroupAttachmentConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _targetGroupIdentifier?;
    get targetGroupIdentifier(): string;
    set targetGroupIdentifier(value: string);
    get targetGroupIdentifierInput(): string | undefined;
    private _target;
    get target(): AwsTargetGroupAttachment.TargetPropertyOutputReference;
    putTarget(value: AwsTargetGroupAttachment.TargetProperty): void;
    get targetInput(): AwsTargetGroupAttachment.TargetProperty | undefined;
    private _timeouts;
    get timeouts(): AwsTargetGroupAttachment.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsTargetGroupAttachment.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsTargetGroupAttachment.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsTargetGroupAttachmentTargetPropertyToTerraform(struct?: AwsTargetGroupAttachment.TargetPropertyOutputReference | AwsTargetGroupAttachment.TargetProperty): any;
export declare function awsTargetGroupAttachmentTargetPropertyToHclTerraform(struct?: AwsTargetGroupAttachment.TargetPropertyOutputReference | AwsTargetGroupAttachment.TargetProperty): any;
export declare function awsTargetGroupAttachmentTimeoutsPropertyToTerraform(struct?: AwsTargetGroupAttachment.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsTargetGroupAttachmentTimeoutsPropertyToHclTerraform(struct?: AwsTargetGroupAttachment.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsTargetGroupAttachment {
    interface TargetProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpclattice_target_group_attachment#id AwsTargetGroupAttachment#id}
        *
        * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
        * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
        */
        readonly id: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpclattice_target_group_attachment#port AwsTargetGroupAttachment#port}
        */
        readonly port?: number;
    }
    class TargetPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TargetProperty | undefined;
        set internalValue(value: TargetProperty | undefined);
        private _id?;
        get id(): string;
        set id(value: string);
        get idInput(): string | undefined;
        private _port?;
        get port(): number;
        set port(value: number);
        resetPort(): void;
        get portInput(): number | undefined;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpclattice_target_group_attachment#create AwsTargetGroupAttachment#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpclattice_target_group_attachment#delete AwsTargetGroupAttachment#delete}
        */
        readonly delete?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
    }
}
