import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsServiceNetworkVpcAssociationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpclattice_service_network_vpc_association#id AwsServiceNetworkVpcAssociation#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpclattice_service_network_vpc_association#private_dns_enabled AwsServiceNetworkVpcAssociation#private_dns_enabled}
    */
    readonly privateDnsEnabled?: boolean | cdktn.IResolvable;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpclattice_service_network_vpc_association#region AwsServiceNetworkVpcAssociation#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpclattice_service_network_vpc_association#security_group_ids AwsServiceNetworkVpcAssociation#security_group_ids}
    */
    readonly securityGroupIds?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpclattice_service_network_vpc_association#service_network_identifier AwsServiceNetworkVpcAssociation#service_network_identifier}
    */
    readonly serviceNetworkIdentifier: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpclattice_service_network_vpc_association#tags AwsServiceNetworkVpcAssociation#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpclattice_service_network_vpc_association#tags_all AwsServiceNetworkVpcAssociation#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpclattice_service_network_vpc_association#vpc_identifier AwsServiceNetworkVpcAssociation#vpc_identifier}
    */
    readonly vpcIdentifier: string;
    /**
    * dns_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpclattice_service_network_vpc_association#dns_options AwsServiceNetworkVpcAssociation#dns_options}
    */
    readonly dnsOptions?: AwsServiceNetworkVpcAssociation.DnsOptionsProperty;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpclattice_service_network_vpc_association#timeouts AwsServiceNetworkVpcAssociation#timeouts}
    */
    readonly timeouts?: AwsServiceNetworkVpcAssociation.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpclattice_service_network_vpc_association aws_vpclattice_service_network_vpc_association}
*/
export declare class AwsServiceNetworkVpcAssociation extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_vpclattice_service_network_vpc_association";
    /**
    * Generates CDKTN code for importing a AwsServiceNetworkVpcAssociation resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsServiceNetworkVpcAssociation to import
    * @param importFromId The id of the existing AwsServiceNetworkVpcAssociation that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpclattice_service_network_vpc_association#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsServiceNetworkVpcAssociation to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpclattice_service_network_vpc_association aws_vpclattice_service_network_vpc_association} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsServiceNetworkVpcAssociationConfig
    */
    constructor(scope: Construct, id: string, config: AwsServiceNetworkVpcAssociationConfig);
    get arn(): string;
    get createdBy(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _privateDnsEnabled?;
    get privateDnsEnabled(): boolean | cdktn.IResolvable;
    set privateDnsEnabled(value: boolean | cdktn.IResolvable);
    resetPrivateDnsEnabled(): void;
    get privateDnsEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _securityGroupIds?;
    get securityGroupIds(): string[];
    set securityGroupIds(value: string[]);
    resetSecurityGroupIds(): void;
    get securityGroupIdsInput(): string[] | undefined;
    private _serviceNetworkIdentifier?;
    get serviceNetworkIdentifier(): string;
    set serviceNetworkIdentifier(value: string);
    get serviceNetworkIdentifierInput(): string | undefined;
    get status(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _vpcIdentifier?;
    get vpcIdentifier(): string;
    set vpcIdentifier(value: string);
    get vpcIdentifierInput(): string | undefined;
    private _dnsOptions;
    get dnsOptions(): AwsServiceNetworkVpcAssociation.DnsOptionsPropertyOutputReference;
    putDnsOptions(value: AwsServiceNetworkVpcAssociation.DnsOptionsProperty): void;
    resetDnsOptions(): void;
    get dnsOptionsInput(): AwsServiceNetworkVpcAssociation.DnsOptionsProperty | undefined;
    private _timeouts;
    get timeouts(): AwsServiceNetworkVpcAssociation.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsServiceNetworkVpcAssociation.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsServiceNetworkVpcAssociation.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsServiceNetworkVpcAssociationDnsOptionsPropertyToTerraform(struct?: AwsServiceNetworkVpcAssociation.DnsOptionsPropertyOutputReference | AwsServiceNetworkVpcAssociation.DnsOptionsProperty): any;
export declare function awsServiceNetworkVpcAssociationDnsOptionsPropertyToHclTerraform(struct?: AwsServiceNetworkVpcAssociation.DnsOptionsPropertyOutputReference | AwsServiceNetworkVpcAssociation.DnsOptionsProperty): any;
export declare function awsServiceNetworkVpcAssociationTimeoutsPropertyToTerraform(struct?: AwsServiceNetworkVpcAssociation.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsServiceNetworkVpcAssociationTimeoutsPropertyToHclTerraform(struct?: AwsServiceNetworkVpcAssociation.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsServiceNetworkVpcAssociation {
    interface DnsOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpclattice_service_network_vpc_association#private_dns_preference AwsServiceNetworkVpcAssociation#private_dns_preference}
        */
        readonly privateDnsPreference?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpclattice_service_network_vpc_association#private_dns_specified_domains AwsServiceNetworkVpcAssociation#private_dns_specified_domains}
        */
        readonly privateDnsSpecifiedDomains?: string[];
    }
    class DnsOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DnsOptionsProperty | undefined;
        set internalValue(value: DnsOptionsProperty | undefined);
        private _privateDnsPreference?;
        get privateDnsPreference(): string;
        set privateDnsPreference(value: string);
        resetPrivateDnsPreference(): void;
        get privateDnsPreferenceInput(): string | undefined;
        private _privateDnsSpecifiedDomains?;
        get privateDnsSpecifiedDomains(): string[];
        set privateDnsSpecifiedDomains(value: string[]);
        resetPrivateDnsSpecifiedDomains(): void;
        get privateDnsSpecifiedDomainsInput(): string[] | undefined;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpclattice_service_network_vpc_association#create AwsServiceNetworkVpcAssociation#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpclattice_service_network_vpc_association#delete AwsServiceNetworkVpcAssociation#delete}
        */
        readonly delete?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpclattice_service_network_vpc_association#update AwsServiceNetworkVpcAssociation#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
