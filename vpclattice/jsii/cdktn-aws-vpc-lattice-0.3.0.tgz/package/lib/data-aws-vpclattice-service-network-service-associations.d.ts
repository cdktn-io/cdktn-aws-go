import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsServiceNetworkServiceAssociationsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/vpclattice_service_network_service_associations#region DataAwsServiceNetworkServiceAssociations#region}
    */
    readonly region?: string;
    /**
    * ID or ARN of the Service.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/vpclattice_service_network_service_associations#service_identifier DataAwsServiceNetworkServiceAssociations#service_identifier}
    */
    readonly serviceIdentifier?: string;
    /**
    * ID or ARN of the Service Network.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/vpclattice_service_network_service_associations#service_network_identifier DataAwsServiceNetworkServiceAssociations#service_network_identifier}
    */
    readonly serviceNetworkIdentifier?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/vpclattice_service_network_service_associations aws_vpclattice_service_network_service_associations}
*/
export declare class DataAwsServiceNetworkServiceAssociations extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_vpclattice_service_network_service_associations";
    /**
    * Generates CDKTN code for importing a DataAwsServiceNetworkServiceAssociations resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsServiceNetworkServiceAssociations to import
    * @param importFromId The id of the existing DataAwsServiceNetworkServiceAssociations that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/vpclattice_service_network_service_associations#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsServiceNetworkServiceAssociations to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/vpclattice_service_network_service_associations aws_vpclattice_service_network_service_associations} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsServiceNetworkServiceAssociationsConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataAwsServiceNetworkServiceAssociationsConfig);
    private _items;
    get items(): DataAwsServiceNetworkServiceAssociations.ItemsPropertyList;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _serviceIdentifier?;
    get serviceIdentifier(): string;
    set serviceIdentifier(value: string);
    resetServiceIdentifier(): void;
    get serviceIdentifierInput(): string | undefined;
    private _serviceNetworkIdentifier?;
    get serviceNetworkIdentifier(): string;
    set serviceNetworkIdentifier(value: string);
    resetServiceNetworkIdentifier(): void;
    get serviceNetworkIdentifierInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataAwsServiceNetworkServiceAssociationsDnsEntryPropertyToTerraform(struct?: DataAwsServiceNetworkServiceAssociations.DnsEntryProperty): any;
export declare function dataAwsServiceNetworkServiceAssociationsDnsEntryPropertyToHclTerraform(struct?: DataAwsServiceNetworkServiceAssociations.DnsEntryProperty): any;
export declare function dataAwsServiceNetworkServiceAssociationsItemsPropertyToTerraform(struct?: DataAwsServiceNetworkServiceAssociations.ItemsProperty): any;
export declare function dataAwsServiceNetworkServiceAssociationsItemsPropertyToHclTerraform(struct?: DataAwsServiceNetworkServiceAssociations.ItemsProperty): any;
export declare namespace DataAwsServiceNetworkServiceAssociations {
    interface DnsEntryProperty {
    }
    class DnsEntryPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DnsEntryProperty | undefined;
        set internalValue(value: DnsEntryProperty | undefined);
        get domainName(): string;
        get hostedZoneId(): string;
    }
    class DnsEntryPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DnsEntryPropertyOutputReference;
    }
    interface ItemsProperty {
    }
    class ItemsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ItemsProperty | undefined;
        set internalValue(value: ItemsProperty | undefined);
        get arn(): string;
        get createdAt(): string;
        get createdBy(): string;
        get customDomainName(): string;
        private _dnsEntry;
        get dnsEntry(): DnsEntryPropertyList;
        get id(): string;
        get serviceArn(): string;
        get serviceId(): string;
        get serviceName(): string;
        get serviceNetworkArn(): string;
        get serviceNetworkId(): string;
        get serviceNetworkName(): string;
        get status(): string;
    }
    class ItemsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ItemsPropertyOutputReference;
    }
}
